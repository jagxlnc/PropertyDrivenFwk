#-----------------------------------------------------------------------------------------------------
# dumpConfig.py
#
# This wsadmin script will browse a cell and record settings of fundamental server and resource
# configurations in a property file using a nested syntax for subcomponents.
# 
# The resulting output file can be used to track changes to an existing system or can be used to 
# apply the settings to a new cell. See the updateEnvironment.py script for how this is done.  
#
# This script will print out a model application server configuration that can be used as a template
# server when creating cluster members. 
#
# Invocation notes:
#     There has been a major update in the parameter handling of the scripts.  The script still
#     supports the old style, which we'll refer to as the legacy format.
#
# Invocation:
#     ${WAS_PROFILE_ROOT}/bin/wsadmin.sh -lang jython -f dumpConfig.py [-outdir output-directory] 
#                                                                      [-timestamp string] 
#                                                                      [-filename output-file-name]
#                                                                      [-directive directive-parm1 directive-parm2 directive-parm3 directive-parm4]
#                                                                      [-directive2 directive2-parm]
#                                                                      ...
#                                                                      [-directiven directiven-parm]
#
# Optional parameters:
#     -outdir - an optional directory that the output file will be placed in - defaults to current directory
#     -timestamp - Specifies a string (usually a timestamp) that will be added to output file name, defaults to current date and time
#     -filename - Specifies the actual file to create (including directory).  If specified, outdir and timestamp will be ignored
#     -directive - One of the special directives (see below).  The dumpClusterServerAsTemplate directive must be used as the first
#                  directive as that position supports multiple parms.
#     -directive2+ - Additional directives can be added. If the directive takes a parameter it can be specified following the
#                    directive
# Wildcard support:
#     Some of the directives can be filtered with the -pattern directive or by using wildcard patterns (e.g. "Server*") as arguments. See the
#     documentation on each directive to see what is supported
# 
#     The default wildcard character can be overridden by specifiying "-wildcard char" (e.g., -wildcard @ ).  The -wildcard option should be specified
#     before the options needing wildcard support. 
#
#
# Support for -conntype NONE
#   The script has been tightened up to remove certain dependencies on AdminControl and
#   can now be run without connecting to the Deployment Manager or standalone application server. Run
#   the script using the profile of the Deployment Manager or the standalone server that you wish
#   to export:
#
#   $WAS_HOME/wsadmin.sh -conntype NONE -f dumpConfig.py [arguments}
#
#   Known issues: Some of the OSGi related AdminTask functions do not run in this
#   mode and will cause error messages to be printed. If you run into this or any other
#   issue, run the script while connected to an adminstrative server.
#
# Legacy Invocation:
# 		${WAS_PROFILE_ROOT}/bin/wsadmin.sh -lang jython -f dumpConfig.py output-directory timestamp [-directive directive-parms]
# 
# Legacy Required Arguments:
#    output-directory - the directory the property file is written to
#    timestamp - a timestamp string that will be appended to the hostname of the deployment manager to
#                create the file name
#
# Optional Directive Overview:
#
# If no directive is specified, a standard set of configuration items will be output to the file.
#
# All components (with optional exclusions)
#    -all [-skipblas] [-skipassets] [-skipsecurity]
#
# Filtering application server components:
#    For all options that generate application server settings, the -excludeFilter and 
#    -includeFilter parameters can be used to filter which server components are
#    included in the output. Each of these options takes an argument that is a list of server WCCM 
#    component names separated by the + character.  To use this feature, use one of the following
#    pairings:
#       -excludeFilter <component-list>    
#       -excludeFilter ALL -includeFilter <componentList>
#
#    Examples:
#       -excludeFilter All -includeFilter PMIService+PMIModule+JavaProcessDef
#       -excludeFilter AdminService+RasLoggingService
#
#    For a list of filterable components, see the getFilterSettings function.
#
#    The following items are disabled by default for performance reasons and must be explitly enabled with -includeFilter:
#        ServerEntry (or EndPoint) - server named port information
#
# Generating a list of nodes (and optionally servers):
#   -nodes [-includeservers]
#
#   The -nodes option will produce a list of managed and unmanaged nodes, include the Deployment Manager node. 
#   Including the -includeservers options will provide high level server information for servers on that node.
#   This will also produce a list of nodegroup definitions.
#  
#
# Dumping a cluster
#    -cluster cluster-name [-server server-name] [-printTemplates true] 
#                           [-skipMemberDetails]
#                           [-resources [-memberresources] [-passwords [-tempdir <dirname>] ] ]
#                           [-comparable true]
#                   If the -cluster option is specified, then this would be the name of 
#                   the application server cluster to process. Only the cluster and cluster member
#                   configurations will be recorded to the property file.
#
#                   Specifying the -server option will limit the cluster members written to just
#                   those whose name matches the server-name pattern.
#
#                   Specifying the -resources option will cause resources related to the cluster
#                   to be written as well.  This addresses resources at cluster scope but not resources
#                   defined at a specific server scope. To include resources defined at server scope
#                   for matching cluster members, add the -memberresources command-line option.
#                   If you specify -passwords, any passwords associated
#                   with the resources will be written as their encoded values instead of "******"
#
#                   Specifying "-printTemplates false" will prevent the cluster templates from being 
#                   written. The default behaviour is to print templates
#
#                   The -skipMemberDetails option is used only when exporting dynamic clusters. If specified,
#                   the cluster members will still be listed, application server component settings will not
#                   be exported. This is useful in most cases since the cluster template settings are used to
#                   define settings for all cluster members.
#
#                   The -comparable option will cause certain configuration items 
#                   to be inserted as comments in order to facilitate cross-version comparison 
#                   of output files. Currently thread pools and transport chains are affected by this support.
#     
#    -cluster -pattern cluster-name-pattern [-wildcard char] [-server server-name] [-printTemplates true] 
#                                           [-resources [-passwords [-tempdir <dirname>] ]  ]
#                    Dumps out clusters with names that match the wildcard pattern
#                    The -server, -resources and -printTemplates options work as above.
# Dumping all clusters:
#
#    -clusters             - Will dump all cluster configurations
#                    -clusters [-dynamiconly] [-foreign]
#
# Dumping a cluster template:
# Create a cluster template definition property file from a cluster member settings. There are several ways
#           to do this:
#   -dumpClusterServerAsTemplate cluster-name member-name member-node   
#          Writes the property file for the cluster template to a file in the output-directory.
#          Properties for the template are pulled from the specified cluster member
#   -dumpClusterServerAsTemplate cluster-name member-name member-node output-file
#          Ignores the output-directory and timestamp parms and writes to the specified output file
#          Properties for the template are pulled from the specified cluster member
#   -dumpClusterServerAsTemplate cluster-name -any
#          Properties are written to an ouput file in the output-directory
#          The script pulls the properties from a cluster-member determined dynamically
#   -dumpClusterServerAsTemplate cluster-name -any output-file
#          Properties are written to the specified output file.
#          The script pulls the properties from a cluster-member determined dynamically
# 	
#    Note that this function adds the clusterTemplate.overrideSettings = true setting
#    to the property file, which when processed by updateEnvironment script will cause 
#    custom properties and JVM generic args to be replaced instead of merged.
#
#  Create cluster template with variableMembers fields. 
#      -dumpVariableClusterTemplate [-sourceCluster source-Name | -cluster source-Name] [-sourceServer server-name -sourceNode nodename] [-targetCluster target-Name]
#                                  [ -targetServers [new-server-list | VAR] ] [-targetNodes [node-list | VAR]] [-targetPerNode [count | VAR] ] [-targetMemberPrefix membernameprefix]
#                                  [ -filename outputfile]
#   
#       The resulting property file can be fed to the updateEnvironment script to create a cluster
#       with members who's settings will be based on the specified cluster member or application server. These settings
#       are stored in the property file, so the new cluster can be created in a different cell than the source server.
#
#       For more information on the variableMembers syntax, see the updateEnvironment.py script.
#
#       The string VAR can be specified as the value for targetServers,targetNodes,and targetPerNode.
#       If done, the variables #{NEW_CLUSTER_NODES}, #{NEW_CLUSTER_SERVERS}, and #{NEW_CLUSTER_PER_NODE}
#       should be specified in a variable file.
#
#  Creating a Dynamic Cluster template file from a standard Cluster:
#      -converToDynamic source-cluster-name [-targetcluster dynamic-cluster-name] [-usetemplate true] 
#                                          [-nodegroup Node-group-name] [-targetserver template-source-server]
#                                          [-targetnode template-source-ndoe]
#      where source-cluster-name is standard cluster to base off of
#            dynamic-cluster-name is name to use with new cluster (defaults to Dynamic_[source-cluster-name])
#            Node-group-name is name to use for new NodeGroup for Dyanmic cluster (defaults to NodeGroup_[source-cluster-name])
#            -usetemplate controls wether to do dump existing cluster template as new template (defaults to false)
#            -targetserver and -targetnode control which cluster member to use a template (defaults to first cluster member)
#
#  Dump standalone application servers
#   -appservers [-targetserver server-name] [-targetnode node-name] 
#               [ -skipappserver] [-dmgr] [-nodeagents] [-odr] [-resources]  
#               [-comparable true]
#
#   To dump DEPLOYMENT_MANAGER, NODE_AGENT, and ONDEMAND_ROUTER specify the corresponding option (-dmgr, -nodeagents, -odr). You
#   can limit the output to only the special types by specify -skipappserver to skip servers of type APPLICATION_SERVER.
#
#   The -comparable option will cause certain configuration items 
#   to be inserted as comments in order to facilitate cross-version comparison 
#   of output files. Currently thread pools and transport chains are affected by this support.
#
#
#  Dump all application servers, including cluster members in the appserver section:
#    -allappservers [-targetserver server-name] [-targetnode node-name] [ -skipappserver] [-dmgr] [-nodeagents] [-odr] [-resources]
#
#  Dumping a WebSphere template definition
#    The dumpConfig script has some limited support for finding various configuration templates and writing their properties
#    in the same format as the regular configuration items. The command line syntax for this is:
#       -template WCCM-Configuration-Type [-templatepattern substring-or-wildcard-pattern]   [configuration type specific options]
#     
#    Where -templatepattern can be used to specify the second argument to AdminConfig.listTemplates() which can either be a substring of the
#    display name or a wildcard pattern.
#
#    The configuration type specific options are a subset of the various dumpConfig
#    options that are used to export specific items. See the table below for some of the options
#      WCCM_TYPE    Supported options
#      ---------    -----------------
#      Server       -targetserver -targetnode -targetservertype
#      
#
#  Dump SIBus JMS resources
#   -sibjms [-pattern wildcard-pattern] [-targetcluster cluster-name] [-targetnode node-name] [-targetserver server-name] [-targetcell true]
#
#    Dumps the definitions for SIBus JMS resources.  The output for this directive can be narrowed down by specifying 
#    a wildcard pattern for resource names and/or scope target values to limit it to resources defined at a specific scope.
#
#  Dump WebSphere MQ JMS resources
#   -mqjms [-pattern wildcard-pattern] [-targetcluster cluster-name] [-targetnode node-name] [-targetserver server-name] [-targetcell true]
#
#    Dumps the definitions for WebSphere MQ JMS resources.  The output for this directive can be narrowed down by specifying 
#    a wildcard pattern for resource names and/or scope target values to limit it to resources defined at a specific scope.
#
#
#  Dump SIBus definitions
#   -sibus [optional-busname] [-includeUUID true] [-pattern wildcard-pattern] [-destination wildcard-pattern] [-busMember wildcard-pattern]
#
#		Can be used to dump all buses or a specific ID. UUID properties are not printed out 
#   unless "-includeUUID true" flag is added to command line.  The optional-busname can be a wild card pattern
#   and the -pattern option can also be used to filter which buses are processed. 
#
#   The -busMember option can be used to restrict bus member definitions to a
#   single bus member or multiple bus members that match a pattern. When this option is used, only queue destinations
#   associated with that bus member will be printed out.
#
#   The -destination option can be used to restrict which TopicSpace and Queue destinations
#   are printed out.
#
# 
#
#  Dump JDBC resource definitions
#  -jdbc [-pattern wildcard-pattern] [-targetprovider wildcard-pattern] [-targetcluster cluster-name] [-targetnode node-name] [-targetserver server-name] [-targetcell true]
#
#    Dumps the definitions for JDBC resources.  The output for this directive can be 
#    narrowed down by using a combination of:
#       -pattern: to specify a wildcard pattern for JDBC Connection Factory names,  
#       -targetprovider: to specify a wildcard pattern for JDBC provider names
#       -targetcluster, 
#       -targetnode, 
#       -targetserver, 
#       -targetcell:    : scope target values to limit to JDBC Providers defined at a specific scope.
#
#
#  Dump JAAS authentication alias
# -authalias [-passwords [-tempdir <dirname>] ]
#
#      Normally passwords are exported as "*******", but by specifying the -passwords file, 
#      the script will parse the security.xml file and pull the encoded values out and write them
#      to the output file. -tempdir can be used to specify a temporary directory.
#
#  Dump WebSphere Variables
# -vars [-targetcluster cluster-name] [-targetnode node-name] [-targetserver server-name] [-targetcell true]
#
#  Dump namespace bindings
# -nsbindings
#
#  Dump virtual hosts
# -virtualhosts
#
#  Dump unmanaged nodes
# -unmanagednodes
#
#  Dump Shared Libraries Definitions
# -libraries
# 
#  Dump Work Manager definitions
# -workmanager [-targetcluster <cluster-name|cluster-pattern>] [-targetnode <node-name> [targetserver <server-name>] [-wildcard <character>] 
# 
#  Dump WebServer definitions
# -webservers
# 
#  Dump Data Replication Domains
# -repdomain
# 
#  Dump Object Cache Instances
# -objectcache [-targetcluster <cluster-name|cluster-pattern>] [-targetnode <node-name> [targetserver <server-name>] [-wildcard <character>] 
#
#  Dump application deployment configurations
# -appdeployment [target-application-name] [-pattern regular-expression-pattern] [-wildcard wildcard-character] [-includeFilter filter-string] [-excludeFilter filterString]
#    where
#        target-application-name can be a full name or name with wildcard character
#        wildcard-character is the character to use for wildcard replacement in target-application-name, defaults to *
#        regular-expression-pattern is a jython-supported regular expression - you can use this instead of target-application-name+wildcard
#        filterString is list of filterable types to be used to restrict output - see the getFilterSettings method for list of types,
#
#
#  Dump Coregroup settings
# -coregroup
#
#  Dump Scheduler settings
# -schedulers [-targetcluster <cluster-name|cluster-pattern>] [-targetnode <node-name> [targetserver <server-name>] [-wildcard <character>] 
#
#  Dump J2CResourceAdapters configured outside an application
# -j2c [-builtins] [-targetcluster <cluster-name|cluster-pattern>] [-targetnode <node-name> [targetserver <server-name>] [-wildcard <character>] 
#
# Mail Providers and Mail Sessions
# -mail [-targetcluster <cluster-name|cluster-pattern>] [-targetnode <node-name> [targetserver <server-name>] [-wildcard <character>] 
#
# URL Providers and URL Resources
# -url [-targetcluster <cluster-name|cluster-pattern>] [-targetnode <node-name> [targetserver <server-name>] [-wildcard <character>] 
#
# Timers
# -timers [-targetcluster <cluster-name|cluster-pattern>] [-targetnode <node-name> [targetserver <server-name>] [-wildcard <character>]     
#
# Assets
#  -assets
#
# Business Level Applications (includes assets)
#  -blas
#
# Configuration items related to OSGI applications. Including assets, BLAs, local and remote bundle repository.
# This option will filter out BLAs that are not OSGI applications.
#  -osgi
#
# Intelligent Management Configuration Options.
#   Dumps custom actions, health policies
#   -im
#
# Custom actions
#   -customactions
#
# Health policies
#   -healthpolicy or -healthpolicies
#
# Service policies
#    -servicepolicy or -servicepolicies
#
# Work Classes
#    -workclass or -workclasses
#
# Intelligent Management Controllers
#    -imcontrollers
#-----------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------
# Utility method to write to wsadmin log file (e.g. wsadmin.traceout)
import java.util.logging.Logger as JavaLogger
javaLogger = None
def wsadminTrace(traceString):
  global javaLogger
  if (javaLogger == None):
    javaLogger = JavaLogger.getLogger("dumpConfig")
  
  javaLogger.info(traceString)
#enddef


import java.io.ByteArrayOutputStream
import java.io.PrintStream
import java.lang.System

class PrintLineFilter:
  def __init__(self):
    pass
  
  def filterLine(self,outputline):
    return 0

#enddef PrintLineFilter

class AuthenticationAliasPrintLineFilter(PrintLineFilter):
  aliasKeys = ['dspropAttrs.prop.authDataAlias = ',
               'dspropAttrs.prop.xaRecoveryAuthAlias = ',
               'mapAttrs.prop.authDataAlias = ',
               'mappingModule.prop.authDataAlias = ',
               'mapping.prop.authDataAlias = ',
               'prop.authenticationAlias = ',
               'prop.interEngineAuthAlias = ',
               'prop.mediationsAuthAlias =',
               'dataStore.prop.authAlias = ',
               'prop.xaRecoveryAuthAlias = ',
               
              ]
               
  def __init__(self):
    self.aliasList = []
  
  def filterLine(self, outputline):
    retval = 0
    if (isEmpty(outputline)):
      return 0
      
    if (outputline.startswith("#")):
      return 0
      
    for aliasKey in self.aliasKeys:
      keypos = outputline.find(aliasKey)
      if (keypos >= 0):
        aliasvalue = outputline[keypos+len(aliasKey):].strip()
        if aliasvalue != '[]' and  aliasvalue != '' and not aliasvalue in self.aliasList:
          self.aliasList.append(aliasvalue)
        break
    
    return 0
  #enddef filterLine
  
  def getAliasList(self):
    return self.aliasList
  
#enddef class     
  
printLineFilterList = []

def addPrintLineFilter(printLineFilter):
  global printLineFilterList
  
  printLineFilterList.append(printLineFilter)
#enddef

def removePrintLineFilter(printLineFilter):
  global printLineFilterList
  printLineFilterList.remove(printLineFilter)

def filterPrintLine(printline):
  
  global printLineFilterList
  for plf in printLineFilterList:
    if (plf.filterLine(printline)):
      break
  
  return
#enddef 

import org.xml.sax.helpers.DefaultHandler

class XMLHandler(org.xml.sax.helpers.DefaultHandler):
  
  def __init__(self):
    self.startingPrefix = ""
    self.prefix = ""
    self.currentElement = ""
    self.topElement = ""
    self.listedElements = ""
    self.idxMap = {}
    
  def __init__(self,startingPrefix,topElement,listedElements):
    self.startingPrefix = startingPrefix
    self.prefix = startingPrefix
    self.currentElement = ""
    self.topElement = topElement
    self.listedElemets = ""
    self.idxMap = {}
    
    if (listedElements != None):
      for listedElement in listedElements:
        self.idxMap[listedElement] = 0
    
  
  
  def endElement(self,uri, localName, qName):
    
    tempName = ""
    
    # See if we need to pop off list count
    lastTokenPos = self.prefix.rfind(".")
    lastToken = self.prefix[lastTokenPos+1:]
    if lastToken.isdigit():
      self.prefix = self.prefix[:lastTokenPos]
    
    if (localName != None and self.prefix.endswith(localName)):
      tempName = localName
      self.prefix = self.prefix[0:-(len(localName)+1)]
    elif (qName != None and self.prefix.endswith(qName)):
      tempName = qName
      self.prefix = self.prefix[0:-(len(qName)+1)]
        
    # Reset all indices for nested elements under this element
    for key in self.idxMap.keys():
      if key.startswith("%s." % tempName):
        #print "Resetting %s to 0" % key
        self.idxMap[key] = 0
    
    
    
  #enddef
  
  def startElement(self,uri, localName, qName, attributes):
    #print "startElement [%s] [%s] [%s]" % (uri, localName, qName)
    newName = None
    
    if (localName != None):
      newName = localName
    elif (qName != None):
      newName = localName
    
    if (newName != self.topElement):
      self.prefix = "%s.%s" % (self.prefix, newName)
    
    # See if this needs to be indexed
    for key in self.idxMap.keys():
      if (self.prefix.endswith(key)):
        lastIdx = self.idxMap[key]
        newIdx = lastIdx + 1
        self.idxMap[key] = newIdx
        self.prefix = "%s.%d" % (self.prefix,newIdx)
    
    # Build dictionary of attribute key/val so we can
    # print in sorted order
    attrDict = {}
    attrKeys = []
      
    if (attributes != None and int(attributes.getLength()) > 0):
      for idx in range(0,int(attributes.getLength())):
        propName = attributes.getLocalName(idx)
        if (isEmpty(propName)):
          propName = attributes.getQName(idx)
         
        propVal = attributes.getValue(idx)
        attrDict[propName] = propVal
        attrKeys.append(propName)
    
    # Special handling of common identifiers
    if "name" in attrKeys:
      printLine("%s.prop.name = %s" % (self.prefix,attrDict["name"]))
    if "identifier" in attrKeys:
      printLine("%s.prop.identifier = %s" % (self.prefix,attrDict["identifier"]))
    
    # Now print attributes in sorted order
    attrKeys.sort()  
    for propName in attrKeys:
      if (propName == "name" or propName == "identifier"):
        continue
      propVal = attrDict[propName]
      printLine("%s.prop.%s = %s" % (self.prefix,propName,propVal))
        
    
  #enddef
#endclass

def parseXML(filename,xmlHandler,deleteFile=1):
  try:
    import javax.xml.parsers.SAXParserFactory
    spf = javax.xml.parsers.SAXParserFactory.newInstance()
    spf.setNamespaceAware(1)
    saxParser = spf.newSAXParser()
    
    import java.io.File
    
    fh = java.io.File(filename)
    saxParser.parse(fh,xmlHandler)
    
    if (deleteFile):
      fh.delete()
    
    
    
  except:
    _app_message("Error parsing file %s" % filename,"exception")
#enddef

  
storedCellName = None
storedCellId = None

storedForeignServerTypes = None

provId = 0
id=0
dsId = 0
nsbId = 0
libId = 0
wmProvId=0
wmId = 0
jmsProvId = 0


# Dictionary used to cache node JRE information
nodeSDKs = {}
sdksSupported = 1

import sys
import re

# @JJM
SEPARATOR = java.lang.System.getProperty("line.separator")



#------------------------------------------------------------------------------------------------------
global fileId

#-----------------------------------------------------------------------------
# Utility method that will only call AdminConfig.showAttribute() for the name
# if it has to because the name has a left parenthesis in it
#-----------------------------------------------------------------------------
def splitOffName(configId):
  retval = ""
  try:
    parentokens = configId.split("(")
    if (len(parentokens) == 2):
      retval = parentokens[0]
      if (retval.startswith('"')):
        retval = retval[1:]
    
    if (isEmpty(retval)):
      # Name must have had ( in it or was not part of ID
      retval = AdminConfig.showAttribute(configId,"name")
  except:
    pass
  
  return retval

#------------------------------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------------------------------
def getCellName():
  global storedCellName
  
  if (isEmpty(storedCellName)):
    try:
      storedCellName = AdminControl.getCell()
    except:
      cells = AdminConfig.getid("/Cell:/").splitlines()
      for cell in cells:
        if (not isEmpty(cell)):
          storedCellName = splitOffName(cell)
          break
        
  
  return storedCellName

def getCellId():
  global storedCellId
  if (isEmpty(storedCellId)):
    storedCellId = AdminConfig.getid("/Cell:%s/"%getCellName())
  
  return storedCellId

storedHostName = ""
def getStoredHostName():
  global storedHostName
  if (isEmpty(storedHostName)):
    try:
      storedHostName = AdminControl.getHost()
    except:
      storedHostName = "NONE"

  return storedHostName


# Cached settings
attributeCache = {}
typeList = []
taskMethods = []
configMethods = None

#-------------------------------------------------------------------------------
# checkConfigType
#
# This method is a workaround for the fact that AdminConfig.getObjectType() is not
# available in 6.1
#-------------------------------------------------------------------------------
def checkConfigType(configId,expectedType):
  retval = 0
  
  if (isEmpty(configId)):
    return 0
  
  if (checkGetObjectType()):
    configType = AdminConfig.getObjectType(configId)
    if (configType == expectedType):
      retval = 1    
  else:
    searchString = "#%s_" % expectedType
    if (configId.find(searchString) >= 0):
      retval = 1
  
  return retval
  
#-------------------------------------------------------
def checkGetObjectType():
  
  global configMethods
  retval = 0
  
  if (configMethods == None):
    configMethods = AdminConfig.help()
  
  if (configMethods.find("getObjectType") >= 0):
    retval = 1
  
  return retval

#-------------------------------------------------------------------------------
# callGetObjectType
#-------------------------------------------------------------------------------
def callGetObjectType(configId):
  configType = None
  
  if (checkGetObjectType()):
    configType = AdminConfig.getObjectType(configId)
  else:
    #Parse it out if possible
    splits = configId.split("#")
    
    lastToken = splits[-1]
    configType = lastToken.split("_")[0]
    
    if (configType not in getTypeList()):
      # Not a valid type
      configType = None    
  
  return configType

#---------------------------------------------------------------------------------
# getTaskMethods()
#
# Gets the list of AdminTask method names
#---------------------------------------------------------------------------------
def getTaskMethods():
  global taskMethods
  try:
    if (len(taskMethods) == 0):
      tlist = AdminTask.help("-commands").splitlines()
      for mname in tlist:
        spaceIndex = mname.find(" ")
        if (spaceIndex > 0):
          taskMethods.append(mname[0:spaceIndex])
        else:
          taskMethods.append(mname)
      
  except:
    taskMethods.append("N/A")
    pass
  
  return taskMethods

#---------------------------------------------------------------------------------
# isValidTaskMethod
#
# Confirm that the specified method name is valid for AdminTask. Used to support
# various versions
#---------------------------------------------------------------------------------
def isValidTaskMethod(methodName):
  retval = 0
  methods = getTaskMethods()
  if (methodName in methods):
    retval = 1
  
  return retval


#------------------------------------------------------------------------------
# getForeignServerTypes
#------------------------------------------------------------------------------
def getForeignServerTypes():
  global storedForeignServerTypes
  if storedForeignServerTypes == None:  
    storedForeignServerTypes = []
  
  if (len(storedForeignServerTypes) == 0):
    if isValidTaskMethod("listForeignServerTypes"):
      tempList = AdminTask.listForeignServerTypes().splitlines()
      for t in tempList:
        if (not isEmpty(t)):
          storedForeignServerTypes.append(t)
  
  return storedForeignServerTypes
    

#---------------------------------------------------------------------------------
# getTypeList()
#
# Loads the list of WCCM types. The list is cached so only one AdminConfig call is 
# made inthe wsadmin session
#---------------------------------------------------------------------------------
def getTypeList():
  global typeList
  if (len(typeList) == 0):
    typeList.extend(AdminConfig.types().splitlines())
  
  return typeList

#---------------------------------------------------------------------------------
# Confirm that this is a valid type
#---------------------------------------------------------------------------------
def isValidType(wccmType):
  retval = 0
  tl = getTypeList()
  if wccmType in tl:
    retval = 1
  
  return retval
  
  

#---------------------------------------------------------------------------------
# getAttributeInfo
# 
# Parameters:
#
#   configurationType - The name of a WCCM type (e.g. "DataSource")
#
# Returns a list that represents the lines of AdminConfig.attributes(configurationType)
#---------------------------------------------------------------------------------
def getAttributeInfo(configurationType):
  global attributeCache
  
  attributeInfo = attributeCache.get(configurationType)
  if (attributeInfo == None):
    attributeInfo = AdminConfig.attributes(configurationType).splitlines()
    attributeCache[configurationType] = attributeInfo
  
  return attributeInfo

#---------------------------------------------------------------------
# isValidAttribute
#
# Used to check if attribute is valid (for backlevel compatibility)
#---------------------------------------------------------------------
def isValidAttribute(configurationType,attributeName):
  retval = 0
  
  attributeInfo = getAttributeInfo(configurationType)
  if (attributeInfo != None):
    for ai in attributeInfo:
      if (not ai.startswith(attributeName)):
        continue
      
      aname = ai
      firstSpace = ai.find(" ")
      if (firstSpace > 0):
        aname = ai[0:firstSpace]
      
      if (aname == attributeName):
        retval = 1
        break

      
  return retval    

#---------------------------------------------------------------------------------
# getRequestedServerTypes
#---------------------------------------------------------------------------------
def getRequestedServerTypes(parmMap):
  serverTypes = []
  
  if (parmMap != None):
    serverTypes = parmMap.get("-serverTypes","")
    if (type(serverTypes) == type("") and isEmpty(serverTypes)):
      serverTypes = parmMap.get("-servertypes","")
    
    if (type(serverTypes) != type([])):
       if (isEmpty(serverTypes)):
         serverTypes = []
         parmMap["-serverTypes"] = serverTypes
       else:
         serverTypes = servertTypes.split("+")
         parmMap["-serverTypes"] = serverTypes
  
  return serverTypes

#---------------------------------------------------------------------------------
# getSimpleSubComponentAttributes
#
# Parameters:
#   configurationType - The name of a WCCM type (e.g. "DataSource")
#
# Returns: A list of [attributeName,attributeType] pairs for each attribute
# of the specified configuration type that is also a WCCM type.  Lists and references
# are ignored.
#    Example result:  [ ["connectionPool","ConnectionPool"], ["preTestConfig","ConnectionTest"],["mapping","MappingModule"] ]
#---------------------------------------------------------------------------------
def getSimpleSubComponentAttributes(configurationType,includeReferences=0,allowSubClasses = 0):
  retval = []
  baseTypes = ["String","int","boolean"]
  attributeInfo = getAttributeInfo(configurationType)
  for attributeLine in attributeInfo:
    firstSpace = attributeLine.find(" ")
    if (firstSpace <= 0):
      continue
    attributeName = attributeLine[:firstSpace]
    attributeType = attributeLine[firstSpace+1:].strip()
    
    if (attributeType.endswith("*")):
      # List type - skip
      continue
    
    if (attributeType.find("(") >= 0):
      if (not allowSubClasses or attributeType.find("ENUM(") >= 0):
        # ENUM or various subtypes - skip
        continue
    
    if (attributeType in baseTypes):
      # skip
      continue
      
    if (attributeType == "J2EEResourcePropertySet"):
      continue
    
    if (attributeType.find("@") >= 0):
      if not includeReferences:
        # reference - skip
        continue
      else:
        attributeType = attributeType[0:attributeType.find("@")]
    
    # Finally, if its in the master list, good to go
    if (attributeType in getTypeList()):
      retval.append([attributeName,attributeType])
    else:
      if (allowSubClasses and attributeType.find("(") >= 0):
        # Need to handle this
        retval.append([attributeName,attributeType])
      
  
  return retval

#-------------------------------------------------------------------------------
# getPropertyAttributes
#-------------------------------------------------------------------------------
def getPropertyAttributes(configurationType):
  retval = []
  attributeInfo = getAttributeInfo(configurationType)
  for attributeLine in attributeInfo:
    firstSpace = attributeLine.find(" ")
    if (firstSpace <= 0):
      continue
    attributeName = attributeLine[:firstSpace]
    attributeType = attributeLine[firstSpace+1:].strip()
    
    if (attributeType == "J2EEResourcePropertySet" or
        (attributeType.startswith("Property(") and attributeType.endswith("*")) or
        (attributeType == "Property*")):
          retval.append( [attributeName,attributeType])
  
  retval.sort()
  
  return retval


    
#---------------------------------------------------------------------------------
# getListAttributes
#
# Parameters:
#   configurationType - The name of a WCCM type (e.g. "DataSource")

# Returns a list of attribute names that are list-type as determined
# by their AdminConfig.attributes() definition
#---------------------------------------------------------------------------------
def getListAttributes(configurationType):
  retval = []
  attributeInfo = getAttributeInfo(configurationType)
  for attributeLine in attributeInfo:
    firstSpace = attributeLine.find(" ")
    if (firstSpace <= 0):
      continue
    attributeName = attributeLine[:firstSpace]
    attributeType = attributeLine[firstSpace+1:].strip()
    
    if (attributeType.endswith("*")):
      retval.append(attributeName)
  
  return retval


#----------------------------------------------------
# formatExceptionData
#
# Formats exception data for _app_message or _app_trace
#
# Parameters:
#   tnow - timestamp string to use
#
# Returns formatted string
#----------------------------------------------------
def formatExceptionData(tnow):
    import traceback
    
    resultString = ""
    exceptionString = tnow
    exc_type,exc_value,exc_traceback = sys.exc_info()
    exceptionString = "%s %s %s" % (tnow, exc_type, exc_value)
    
    resultString = exceptionString
    
    resultString = resultString + "\n" + "%s Frame stack:"% tnow
    try:
      stacklist = traceback.extract_stack()
      for stackdata in stacklist:
        stackfile,stackln,stackfn,stacktext = stackdata
        
        # Remove calls to _app_message from stack
        if (stackfn != None and stackfn.find("_app_message") >=0):
              break
        if (stacktext != None and stacktext.find("_app_message") >= 0):
              break
        
        resultString = resultString + "\n" + '%s   File "%s", line %s, in %s' % (tnow, stackfile, stackln, stackfn)

    except:
      resultString = resultString + "\n" + "error gettng stack"
      pass    

    resultString = resultString + "\n" + "%s Exception stack:" % tnow
    try:
      tb = sys.exc_info()[2]
      tblist = traceback.extract_tb(tb,10)
      for tbdata in tblist:
        stackfile,stackln,stackfn,stacktext = tbdata          
        resultString = resultString + "\n" + '%s   File "%s", line %s, in %s' % (tnow, stackfile, stackln, stackfn)
        if (stacktext != None and stacktext != ""):
            resultString = resultString + "\n" + "%s    %s" % (tnow,stacktext)
    except:
      resultString = resultString + "\n" + "error getting exception stack"
      pass
      
    return resultString
    
#------------------------------------------------------------
# _app_message - Used to produce formatted message for stdout
#------------------------------------------------------------
def _app_message(instr,exception=None):

    exceptionString = None
    
    from java.util import Date
    from java.text import SimpleDateFormat
    
    now = Date()
    sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS z")
    tnow = "[%s]" % (sdf.format(now))
    
    print "%s %s" % (tnow, instr)
    
    if (exception == "exception"):
      exceptionString = formatExceptionData(tnow)
      print exceptionString

    return exceptionString

#------------------------------------------------------------------------------------------------------
def isEmpty(var):
        return (var == "" or var == None or var == "[]" or str(var) == "['']")
#------------------------------------------------------------------------------------------------------
def printLine(inStr):
        global fileId
        filterPrintLine(inStr)
        
        print >> fileId, inStr


#------------------------------------------------------------------------------------------------------
# wsadminToDictionary - turn a string of bracketed key value pairs into a dictionary
# Example:
#		[ [com.ibm.websphere.baseProductVersion 6.1.0.35] [com.ibm.websphere.nodeOperatingSystem aix] ]
#   OR
# '{password=, logMissingTransactionContext=false, readAhead=Default, tempQueueNamePrefix=, shareDurableSubscriptions=InCluster, targetTransportChain=,
#   authDataAlias=ConfigurationScriptingDmgr/Dude, userName=, targetSignificance=Preferred, shareDataSourceWithCMP=false, providerEndPoints=, 
#  nonPersistentMapping=ExpressNonPersistent, persistentMapping=ReliablePersistent, clientID=, jndiName=jms/SampleSIBQueueCF, manageCachedHandles=false, 
#  category=, busName=SampleBus, targetType=BusMember, xaRecoveryAuthAlias=Dude3, description=, connectionProximity=Bus, target=SampleCluster, name=SampleSIBQueueCF}'
#------------------------------------------------------------------------------------------------------
def wsadminToDictionary(inStr):
    outDictionary = {}
    if (len(inStr)>0 and inStr[0]=='[' and inStr[-1]==']'):
        inStr = inStr[1:-1]
        tlist = inStr.split(" ")
        currentKey = ""
        currentVal = ""
        for token in tlist:
          if (isEmpty(token)):
              continue
          if (token[0] == "["):
              token = token[1:]
              currentKey = token
              currentVal = ""
              continue
          
          if (token[-1] == "]"):
              token = token[:-1]
              currentVal = token
          if (currentKey != "" and currentVal != ""):
              outDictionary[currentKey] = currentVal
              currentKey = ""
              currentVal = ""
    elif (len(inStr) > 0 and inStr[0] =='{' and inStr[-1] == '}'):
      splitOn = ","
      
      if (inStr.find(", ") >0):
        splitOn = ", "
        
      # Parse the second format
      inStr = inStr[1:-1]
      tlist = inStr.split(splitOn)
      for tempToken in tlist:
          val = ""
          key = ""
          equalPos = tempToken.find("=")
          if (equalPos < 0):
            key = tempToken
          else:
            key = tempToken[0:equalPos]
            val = tempToken[equalPos+1:]
                    
          key = key.lstrip()
          val = val.rstrip()
          outDictionary[key] = val
    
    return outDictionary
    

def wsadminToList(inStr):
    """
    Translates strings returned by wsadmin functions representing arrays "[ foo bar ]" to real python arrays ['foo', 'bar']
    
    @return: a Python list
    
    >>> wsadminToList("[ foo bar ]")
    ['foo', 'bar']
    >>> wsadminToList("[foo bar]")
    ['foo', 'bar']
    >>> wsadminToList("[ [cell ifa61] [serverType APPLICATION_SERVER] ]")
    ['cell ifa61', 'serverType APPLICATION_SERVER']
    >>> wsadminToList('[(cells/adev61/nodes/foo/servers/dmgr|server.xml#NameServer_1) "Deployment Manager(cells/adev61/nodes/foo/servers/dmgr|server.xml#CellManager_1)"]')
    ['(cells/adev61/nodes/foo/servers/dmgr|server.xml#NameServer_1)', '"Deployment Manager(cells/adev61/nodes/foo/servers/dmgr|server.xml#CellManager_1)"']
    >>> wsadminToList('[TEST_PROP(cells/aci61|resources.xml#J2EEResourceProperty_1271379509181) "wsrp.consumer.cookieforward.sabs:params"(cells/aci61|resources.xml#J2EEResourceProperty_1275873189713) "wer wer(cells/aci61|resources.xml#J2EEResourceProperty_1275875033329)" sfsdf(Sfsdfsdf(cells/aci61|resources.xml#J2EEResourceProperty_1275875113971)]')
    ['TEST_PROP(cells/aci61|resources.xml#J2EEResourceProperty_1271379509181)', '"wsrp.consumer.cookieforward.sabs:params"(cells/aci61|resources.xml#J2EEResourceProperty_1275873189713)', '"wer wer(cells/aci61|resources.xml#J2EEResourceProperty_1275875033329)"', 'sfsdf(Sfsdfsdf(cells/aci61|resources.xml#J2EEResourceProperty_1275875113971)']
    """
    outList = []

    if not inStr: return outList

    if inStr.startswith('[ [') and inStr.endswith('] ]'):
        tmpList = inStr[3:-3].split('] [')
    elif inStr.startswith('[') and inStr.endswith(']'):
        tmpList = []
        inQuotes = 0
        current = ""
        for char in inStr[1:-1]:
            if len(current) == 0 and char == '"':
                inQuotes = 1
                current = '"'
            elif char == '"':
                inQuotes = 0
                current += '"'
            elif not inQuotes and char == " ":
                tmpList.append(current)
                current = ""
            else:
                current += char
        if len(current) > 0: tmpList.append(current)
    else:
        tmpList = inStr.splitlines()

    for item in tmpList:
        item = item.rstrip()
        if len(item) > 0: outList.append(item)
    return outList


#------------------------------------------------------------------------------------------------------
def wsadminToListOld(inStr):
        outList=[]
        if (len(inStr)>0 and inStr[0]=='[' and inStr[-1]==']'):
          inStr = inStr[1:-1]
          if(inStr.startswith('"')):
              k = inStr.split('" ')
              tmpList=[]
              for item in k:
                  if(item.startswith('"')):
                      item = item[1:]
                  if(item.endswith('"')):
                      item = item[:-1]
                  
                  tmpList.append(item)
          else:
              tmpList = inStr.split(" ")
        else:
          tmpList = inStr.split(SEPARATOR)  #splits for Windows or Linux
        for item in tmpList:
                item = item.rstrip();        #removes any Windows "\r"
                if (len(item)>0):
                        outList.append(item)
        return outList
#endDef

# parseAssetToDictionary - Used to convert output of viewAsset to a dictionary
#
#wsadmin>print AdminTask.viewAsset('[-assetID WebSphere:assetname=log4j-1.2.8.jar ]')
#Options for asset. (AssetOptions)
#
#
#
# Asset settings.
#
#
#*Asset name (name): [log4j-1.2.8.jar]
#Default binding properties (defaultBindingProps): []
#Asset description (description): [Log4j jar]
#Asset binaries destination URL (destination): [${USER_INSTALL_ROOT}/installedAssets/log4j-1.2.8.jar/BASE/log4j-1.2.8.jar]
#Asset type aspects (typeAspect): [WebSphere:spec=Java archive]
#Asset relationships (relationship): []
#File permissions (filePermission): [.*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755]
#Validate asset (validate): [false]

def parseAssetToDictionary(inStr):
  retval = {}
  
  try:
    strLines = inStr.splitlines()
    for inLine in strLines:
      colonPos = inLine.find(":")
      if (colonPos > 0):
        promptStr = inLine[0:colonPos]
        valStr = inLine[colonPos+1:]
        
        keyStr = promptStr
        
        # See if there is a parenthesised short name
        openParen = promptStr.find("(")
        closeParen = promptStr.find(")")
        if (openParen >= 0 and closeParen > 0):
          keyStr = promptStr[openParen+1:closeParen]
        else:
          keyStr = promptStr.strip()
        
        # Now remove brackets from val
        valStr = valStr.strip()
        if valStr[0] == '[' and valStr[-1] == ']':
          valStr = valStr[1:-1]
        
        retval[keyStr] = valStr
          
  except:
    _app_message("parseAssetToDictionary Error parsing the following string:\n%s" % inStr,"exception")
    
  return retval
#enddef

def parseCompUnitToDictionary(inStr):
  retval = {}
  removeKeys = []
  countMap = {}
  cuKeys = []
  
  try:
    keyPrefix = ""
    strLines = inStr.splitlines()
    for inLine in strLines:
      colonPos = inLine.find(":")
      if (colonPos > 0):
        promptStr = inLine[0:colonPos]
        valStr = inLine[colonPos+1:]
        
        keyStr = promptStr
        
        # See if there is a parenthesised short name
        openParen = promptStr.find("(")
        closeParen = promptStr.find(")")
        if (openParen >= 0 and closeParen > 0):
          keyStr = promptStr[openParen+1:closeParen]
        else:
          continue
          #keyStr = promptStr.strip()
          
        if (keyPrefix != ""):
          oKeyStr = keyStr
          keyStr = "%s.prop.%s" % (keyPrefix,keyStr)
          
          # See if there are multiple values
          cidx = 0
          if retval.has_key(keyStr):
            
            # Store current value as .1.
            new1Key = "%s.1.prop.%s" % (keyPrefix,oKeyStr)
            if (new1Key not in cuKeys):
              if keyStr in cuKeys:
                cuKeys[cuKeys.index(keyStr)] = new1Key
              
              retval[new1Key] = retval[keyStr]
            
            if countMap.has_key(keyStr):
              cidx = countMap[keyStr] + 1
            else:
              cidx = 2
              
            countMap[keyStr] = cidx
            
            if keyStr not in removeKeys:
              removeKeys.append(keyStr)
            
            keyStr = "%s.%d.prop.%s" % (keyPrefix,cidx,oKeyStr)
          #end if need to be indexed  
        #endif section
        
        # Now remove brackets from val
        valStr = valStr.strip()
        if len(valStr) > 0 and valStr[0] == '[' and valStr[-1] == ']':
          valStr = valStr[1:-1]
        
        retval[keyStr] = valStr
        cuKeys.append(keyStr)
      else:
        lastKeyPrefix = keyPrefix
        inLine = inLine.strip()
        
        # See if there was a parenthesised section
        openparen = inLine.rfind("(")
        if (openparen >= 0):
          if (inLine.endswith(")")):
            closeparen = inLine.rfind(")")
            if (closeparen >= 0):
              keyPrefix = inLine[openparen+1:-1]
        
    
    for key in removeKeys:
      del retval[key]
  except:
    _app_message("parseCompUnitToDictionary Error parsing the following string:\n%s" % inStr,"exception")
    
  return cuKeys,retval



#------------------------------------------------------------------------------------------------------
def toKeyValue(inStr):
    s = inStr[1:-1]
    k = s[:s.find(' ')]
    v = s[len(k) + 1:]
    return k,v

#------------------------------------------------------------------------------------------------------
def getCookieId(inStr):
  return inStr[inStr.find("("):]
#------------------------------------------------------------------------------------------------------
def getId(inStr):
  if (inStr.startswith("(") and inStr.endswith(")")):
    return inStr[1:-1]
  return inStr
#------------------------------------------------------------------------------------------------------
def isArray(inStr):
  if (inStr.startswith("[") and inStr.endswith("]")):
    return 1
    
  return 0
#------------------------------------------------------------------------------------------------------
def isId(inStr):
  if (inStr.rfind("#") > 0 and inStr.rfind("/") > 0 and inStr.endswith(")")):
    return 1
  return 0
#------------------------------------------------------------------------------------------------------
def toList(inStr):
    if (inStr.startswith('"') and inStr.endswith('"')):
      inStr = inStr[1:-1]
    return inStr.split(" ")
#------------------------------------------------------------------------------------------------------
def toKeyValue(inStr):
    s = inStr[1:-1]
    k = s[:s.find(' ')]
    v = s[len(k) + 1:]
    return k,v
#------------------------------------------------------------------------------------------------------
def getValue(inStr):
    return inStr[inStr.find(":") + 1:].strip()
#------------------------------------------------------------------------------------------------------
def getScope(inStr):
        c=n=s=dc=app=dep=""
        inStr = inStr[:inStr.find("|")]
        a = inStr.split("/")
        #print a
        
        if (inStr.find("dynamicclusters") > -1):
          # This could be a resource at dynamic cluster template level
          dc = a[3]
          
          if (inStr.find("servers") > -1):
            s = a[5]
        else:
          if (inStr.find("applications") > -1):
            app = a[3]
            
            if (inStr.find("deployments") > -1):
              dep=a[5]
          
          else:
            if (inStr.find("clusters") > -1):
                c = a[3]
            else:
                if (inStr.find("servers") > -1):
                        n = a[3]
                        s = a[5]
                else:
                        if (inStr.find("node") > -1):
                                n = a[3]
                                
        return c, n, s, dc, app, dep

#------------------------------------------------------------------------------------------------------
def getScopeId(cluster, node, server, dyncluster=None, appName=None, appDeployment=None):
    result = ''
    if (not isEmpty(dyncluster)):
      if (not isEmpty(server)):
        result = AdminConfig.getid("/DynamicCluster:%s/Server:%s/" % (dyncluster,server))
      else:
        result = AdminConfig.getid("/DynamicCluster:%s/Server:%s/" % (dyncluster,server))
    elif (not isEmpty(appName)):
      if (not isEmpty(appDeployment)):
        result = AdminConfig.getid("/Deployment:%s/" % appDeployment)
      else:
        result = ""
    elif (not isEmpty(cluster)):
        result = AdminConfig.getid("/ServerCluster:%s/"% cluster)
    elif (not isEmpty(node) and not isEmpty(server)):
        result = AdminConfig.getid("/Node:%s/Server:%s/" % (node,server))
    elif (not isEmpty(node)):
        result = AdminConfig.getid("/Node:%s/" % node)
    else:
        # Cell scope
        cells = AdminConfig.list("Cell").split(SEPARATOR)
        for cell in cells:
            result = cell
            break
    
    return result


#-------------------------------------------------------------------------------
# getObjectsAtScope
#    Can be used to find a list of objects that match the specified scope
#    and suffix string. The suffix string can specify a WCCM to return a list
#    or a type/name combination to return a list of one object that matches.
#
# Parameters:
#    suffixString - in syntax for getid, e.g. "URLProvider:/" or "J2CResourceAdapter:WebSphere MQ Resource Adapter/"                                         
#    cluster (optional) - cluster to search under
#    node (optional) - node to search under
#    server (optional) - server to search under. Can also be used to specify template of dynamic cluster
#    dyncluster (optional) - dynamic cluster to search under
#    appName (optional) - application to search under
#    appDeployment (optional) - application deployment to search under
#
# Returns a list of configuration IDs, will be empty if no match found
#-------------------------------------------------------------------------------
def getObjectsAtScope(suffixString,cluster, node, server, dyncluster=None, appName=None, appDeployment=None):
    if not suffixString.endswith("/"):
      suffixString = "%s/" % suffixString
    
    result = []
    if (not isEmpty(dyncluster)):
      if (not isEmpty(server)):
        result = AdminConfig.getid("/DynamicCluster:%s/Server:%s/%s" % (dyncluster,server,suffixString)).splitlines()
      else:
        result = AdminConfig.getid("/DynamicCluster:%s/Server:%s/%s" % (dyncluster,dyncluster,suffixString)).splitlines()
    elif (not isEmpty(appName)):
      if (not isEmpty(appDeployment)):
        result = AdminConfig.getid("/Deployment:%s/%s" % (appDeployment,suffixString)).splitlines()
      else:
        result = []
    elif (not isEmpty(cluster)):
        result = AdminConfig.getid("/ServerCluster:%s/%s"% (cluster,suffixString)).splitlines()
    elif (not isEmpty(node) and not isEmpty(server)):
        result = AdminConfig.getid("/Node:%s/Server:%s/%s" % (node,server,suffixString)).splitlines()
    elif (not isEmpty(node)):
        result = AdminConfig.getid("/Node:%s/%s" % (node,suffixString)).splitlines()
    else:
        # Cell scope
        result = AdminConfig.getid("/Cell:%s/%s" % (getCellName(),suffixString)).splitlines()
            
    
    if (len(result) == 1 and isEmpty(result[0])):
      result = []
      
    return result
				
				
#-------------------------------------------------------------------------------------------
# @JJM-
# getNodeForServer
#  
# Given a serverId, return a node ID by parsing the server ID for the nodes name and
# then call AdminConfig.getid
#-------------------------------------------------------------------------------------------
def getNodeForServer(serverId):
    result = ""
    
    components = serverId.split("/")
    idx = 0
    nodeName  = ""
    if ("nodes" in components):
      nodeName = components[components.index("nodes")+1]
    
    if (not isEmpty(nodeName)):
      result = AdminConfig.getid("/Node:%s/" % (nodeName))
    
    return result
    
#-------------------------------------------------------------------------------------------
# @JJM-
# getNodeNameForServer
#  
# Given a serverId, return a node name by parsing the server ID for the nodes name
#-------------------------------------------------------------------------------------------
def getNodeNameForServer(serverId):
    result = ""
    
    components = serverId.split("/")
    idx = 0
    nodeName  = ""
    while (idx < len(components)):
        if (components[idx] == "nodes"):
            nodeName = components[idx+1]
            break;
        
        idx += 1
    
    if (isEmpty(nodeName) and serverId.find("templates/servertypes") > 0):
      nodeName = "[TEMPLATE]"
    
    result = nodeName
    
    return result

#-------------------------------------------------------------------------
# Parses xml string of the following format and returns name/value tuple
# <Property name="webserverName" value="ScriptingCell_ScriptingNode1_IHS1"/>
#
#
def parsePropertyXML(xmlstring):
  retval = None
  
  if (xmlstring != None and xmlstring.startswith("<Property")):
    nameidx = xmlstring.find('name="')
    valueidx = xmlstring.find('value="')
    if (nameidx > 0 and valueidx > 0):
      nameend = xmlstring.find('"',nameidx+6)
      valueend = xmlstring.find('"',valueidx+7)
      nameval = xmlstring[nameidx+6:nameend]
      valueval = xmlstring[valueidx+7:valueend]
      retval = (nameval,valueval)
     
  return retval    
      
      
      
  
  return retval




#-----------------------------------------------------------------------------------------------------
# wildcardToRegExpString - converts a string that treats asterisk as wild card to regular expression 
# string,  "Hello*" -> "Hello.*?"
#-----------------------------------------------------------------------------------------------------  
def wildcardToRegExpString(inStr,wildcard='*'):
  retval = ""
  if (isEmpty(inStr)):
    retval = ".*"
  elif (inStr.find(wildcard) <0):
    # Not a supported syntax
    retval = inStr
  else:
    prefix = "";
    if (inStr.startswith(wildcard)):
      prefix = ".*?"
    suffix = ""
    if (inStr.endswith(wildcard)):
      suffix = ".*?";
    else:
      suffix = "$"
    
    tokens = inStr.split(wildcard)
    retval = ""
    for token in tokens:
      if (retval == ""):
        retval = token
      elif (token != ""):
        retval = "%s.*?%s" % (retval,token)
    
    retval = "%s%s%s" % (prefix,retval,suffix)
    
    
  return retval
#---------------------------------------------------------------------------------------------------------
# filterList - apply a pattern to a list of IDs by getting the name attribute of each configuration item
# and checking to see if it matches the pattern
#---------------------------------------------------------------------------------------------------------
def filterList(inList, pattern):
	retval = []
	if (isEmpty(pattern)):
		return inList
	
	for configId in inList:
		if (isEmpty(configId)):
			continue
		
		try:
			nameValue = AdminConfig.showAttribute(configId,"name")
			#print "Matching %s against %s" % (pattern,nameValue)
			if (not re.match(pattern,nameValue)):
						#print "No match"
						continue
			else:
				#print "Matched"
				retval.append(configId)
					
		except:
			exc_type,exc_value,exc_traceback = sys.exc_info()
			exceptionString = "%s %s" % (exc_type, exc_value)
			print "Pattern matching exception: %s" %exceptionString	
	
	return retval


#--------------------------------------------------------------------------------------
# checkPossibleWildcardMatch
#--------------------------------------------------------------------------------------
def checkPossibleWildcardMatch(value, pattern, wildcard="*"):
  result = 0
  try:
    #See if already a regular expression
    if (pattern.find(wildcard) >= 0 and pattern.find(".*") < 0):
      # Convert to regular expression
      pattern =  wildcardToRegExpString(pattern,wildcard)
    
    
    
    if (pattern.find("*") < 0):
      # Test for equality, nothing else
      if (pattern == value):
        result = 1
    elif (re.match(pattern,value)):
      result = 1     
  except:
    _app_message("Pattern matching problem: %s %s %s" % (value, pattern, wildcard),"exception")
  
  
  
  return result

#--------------------------------------------------------------------------------------
# getMatchingClusters
#--------------------------------------------------------------------------------------
def getMatchingClusters(clusterPattern,wildcard="*",dynamicOnly=0):
  retval = {}
  tempList = []
  if (dynamicOnly):
    tempList = AdminConfig.getid("/DynamicCluster:/").splitlines()
  else:
    tempList = AdminConfig.getid("/ServerCluster:/").splitlines()
  
  for clusterId in tempList:
    if (isEmpty(clusterId)): continue
    clusterName = AdminConfig.showAttribute(clusterId,"name")
    if (checkPossibleWildcardMatch(clusterName, clusterPattern,wildcard)):
      retval[clusterName] = clusterId
  
  return retval


#---------------------------------------------------------------------------------------------
# listResourceCandidatesAtScope
#
# This method will build a list of configuration items that can be used as a first-pass list
# when trying to find items at a specific scope which may or may not include wildcard matching.
#
# Use this function instead of a brute-force AdminConfig.list(resourceType) to improve 
# performance.
#---------------------------------------------------------------------------------------------
def listResourceCandidatesAtScope(resourceType,targetCluster,targetNode,targetServer,targetCell,wildcard="*",serverList=None,membersList=None):
  retval = None
  
  if (not isEmpty(targetCluster) and targetCluster.find(wildcard) < 0 and membersList == None):
    clusterId = AdminConfig.getid("/ServerCluster:%s/" % targetCluster)
    if (not isEmpty(clusterId)):
      retval = AdminConfig.list(resourceType,clusterId).splitlines()
    else:
      retval = []
  elif (not isEmpty(targetNode) and targetNode.find(wildcard) < 0):
    if (isEmpty(targetServer)):
      nodeId = AdminConfig.getid("/Node:%s/" % targetNode)
      if (not isEmpty(nodeId)):
        tempval = AdminConfig.list(resourceType,nodeId).splitlines()
        retval = []
        for tempid in tempval:
          # Filter out server scoped items
          if (isEmpty(tempid) or tempid.find("/server") >= 0):
            continue
          retval.append(tempid)
      else:
        retval = []
    elif (targetServer.find(wildcard) < 0):
      serverId = AdminConfig.getid("/Node:%s/Server:%s/"% (targetNode,targetServer))
      if (not isEmpty(serverId)):
        retval = AdminConfig.list(resourceType,serverId).splitlines()
      else:
        retval = []
  elif (targetCell != None and targetCell.lower() == "true"):
    tempval = AdminConfig.list(resourceType).splitlines()
    retval = []
    for tempid in tempval:
      if (isEmpty(tempid) or
          tempid.find("/cluster") >= 0 or
          tempid.find("/node") >= 0 or
          tempid.find("/deploy") >= 0 or
          tempid.find("/dynamic") >= 0 or
          tempid.find("/application") >= 0):
            #Not at cellscope
            continue
      else:
        # At cell scope
        retval.append(tempid)
  
  if (retval == None):
    # List everything of type
    retval = AdminConfig.list(resourceType).splitlines()
  
  if (len(retval) == 1 and isEmpty(retval[0])):
    retval = []
  
  return retval
    


#------------------------------------------------------------------------------
# resourceMatchArgs
#------------------------------------------------------------------------------
def resourceMatchArgs(c,n,s,targetCluster,targetNode,targetServer,targetCell,wildcard,resourceName=None,namePattern=None,serverList=None,membersList=None):

  retval = 1
    
  if (not isEmpty(targetCluster)):
    memberMatch = 0
    if (membersList != None):
      if (not isEmpty(n) and not isEmpty(s)):
        member = (n,s)
        if (member not in membersList):
           retval = 0
        else:
          memberMatch = 1      
    if (not memberMatch and  not checkPossibleWildcardMatch(c, targetCluster, wildcard)):
      retval = 0
  
  if (not isEmpty(targetNode)):
    if ((targetNode != n)):
      retval = 0
      
    if (not isEmpty(targetServer)):
      if (targetServer != s):
        retval = 0
    elif (not isEmpty(s)):
      retval = 0
  
  
  if (not isEmpty(targetCell) and targetCell.lower() == "true"):
    if (not (isEmpty(c) and isEmpty(n) and isEmpty(s))):
      retval = 0

  if (isEmpty(targetServer) and serverList != None and [n,s] not in serverList):
    retval = 0
  
  # Check to see if we match the name pattern
  if (not isEmpty(namePattern) and not isEmpty(resourceName)):
      if (not re.match(namePattern,resourceName)):
        #print "No match"
        retval = 0

  return retval

#---------------------------------------------------------------------------------
#
#---------------------------------------------------------------------------------
def printScopeLines(prefix,pCluster,pNode,pServer,pDynCluster,pApp,pAppDeployment):
  
	printLine("%s.cluster = %s" % (prefix, pCluster))
	printLine("%s.node = %s" % (prefix, pNode))
	printLine("%s.server = %s" % (prefix, pServer))
	
	if (not isEmpty(pDynCluster)):
	  printLine("%s.dynamicCluster = %s" % (prefix, pDynCluster))
	  
	if (not isEmpty(pApp)):
	  printLine("%s.application = %s" % (prefix,pApp))
	
	if (not isEmpty(pAppDeployment)):
	  printLine("%s.deployment = %s" % (prefix,pAppDeployment))

#enddef


#--------------------------------------------------------------------------------------
# getApplicationsInCluster
#
# Returns a list of applications in a specific cluster
#--------------------------------------------------------------------------------------
def getApplicationsInCluster(clusterName):
  cellName = getCellName()
  retval = []
  tempString = AdminApp.list("WebSphere:cell=%s,cluster=%s" % (cellName, clusterName))
  if (not isEmpty(tempString)):
    retval = tempString.splitlines()
  
  return retval

#--------------------------------------------------------------------------------------
# getApplicationsInClusters
#
# Returns a list of applications deployed to clusters in a list.
#--------------------------------------------------------------------------------------
def getApplicationsInClusters(clusterList):
  retval = []
  for clusterName in clusterList:
    applications = getApplicationsInCluster(clusterName)
    for application in applications:
      if (application in retval): continue
      
      retval.append(application)
  
  return retval
  

#------------------------------------------------------------------------------------------------------
def printJMSProviderInfo(provider, pCluster, pNode, pServer,pDynCluster="",pApp="",pAppDeployment=""):
    global jmsProvId
    
    if (isEmpty(provider)):
      return
      
    prefix = "app.mqjms.provider.%d" % (jmsProvId)

    printLine("%s.cluster = %s" % (prefix, pCluster))
    printLine("%s.node = %s" % (prefix, pNode))
    printLine("%s.server = %s" % (prefix, pServer))

    if (not isEmpty(pDynCluster)):
      printLine("%s.dynamicCluster = %s" % (prefix, pDynCluster))
    
    if (not isEmpty(pApp)):
      printLine("%s.application = %s" % (prefix,pApp))
  
    if (not isEmpty(pAppDeployment)):
      printLine("%s.deployment = %s" % (prefix,pAppDeployment))
    

    
    
    n = AdminConfig.showAttribute(provider,"name")
    
    printLine("%s.name = %s" % (prefix, n))
    printSimpleProperties("%s.prop" % prefix, provider, ["name"])
    dumpResourceProperties(provider,"propertySet", "%s.propertySet" % prefix)
    
    
    # Ok, let's see if there is a corresponding resource adapter
    if (not isEmpty(pDynCluster)):
      if (not isEmpty(pServer)):
        ra = AdminConfig.getid("/DynamicCluster:%s/Server:%s/J2CResourceAdapter:WebSphere MQ Resource Adapter/" % (pDynCluster,pServer))
      else:
        ra = ""
     
    elif (not isEmpty(pApp)):
      if (not isEmpty(pAppDeployment)):
        ra = AdminConfig.getid("/Deployment:%s/J2CResourceAdapter:WebSphere MQ Resource Adapter/" % pAppDeployment)
      else:
        ra = ""
    elif (isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer)):
      ra = AdminConfig.getid("/Cell:%s/J2CResourceAdapter:WebSphere MQ Resource Adapter/" % AdminConfig.showAttribute(AdminConfig.getid("/Cell:/"),"name"))
    elif (not isEmpty(pCluster)):
      ra = AdminConfig.getid("/ServerCluster:%s/J2CResourceAdapter:WebSphere MQ Resource Adapter/" % pCluster)
    elif (not isEmpty(pServer) and not isEmpty(pNode)):
      ra = AdminConfig.getid("/Node:%s/Server:%s/J2CResourceAdapter:WebSphere MQ Resource Adapter/" % (pNode,pServer))
    elif (not isEmpty(pNode) and isEmpty(pServer)):
      ra = AdminConfig.getid("/Node:%s/J2CResourceAdapter:WebSphere MQ Resource Adapter/" % (pNode))
    else:
      ra = ""
    
    if (not isEmpty(ra)):
      raName = splitOffName(ra)
      printLine("%s.resourceAdapter.name = %s" % (prefix,raName))
      printSimpleProperties("%s.resourceAdapter.prop" %prefix,ra,["name"])
      dumpResourceProperties(ra,"propertySet","%s.resourceAdapter.propertySet" % prefix)
      
    printLine(" ")
          

#------------------------------------------------------------------------------------------------------
def printMQTopic(prefix,topic):
    if (isEmpty(topic)):
      return
      
    tname = AdminConfig.showAttribute(topic,'name')
    printLine("%s.name = %s" % (prefix, tname))
    
    printSimpleProperties("%s.prop" % prefix, topic, ["name"]) 
    
    dumpResourceProperties(topic,"propertySet","%s.propertySet" % prefix)

#------------------------------------------------------------------------------------------------------
def printMQQueue(prefix, queue):
  
    if (isEmpty(queue)):
      return

    qname = AdminConfig.showAttribute(queue,'name')
    printLine("%s.name = %s" % (prefix, qname))
    
    printSimpleProperties("%s.prop" % prefix, queue, ["name"]) 
    
    dumpResourceProperties(queue,"propertySet","%s.propertySet" % prefix)
    



#-----------------------------------------------------------------------------------------------------
# printMQJMSActivateSpec
#-----------------------------------------------------------------------------------------------------
def printMQJMSActivateSpec(prefix, actspec):

  actspecnamemap = { 'wAS_EndpointInitialState': 'WAS_EndpointInitialState' }
  if (not isEmpty(actspec)):
      actspecdict = wsadminToDictionary(AdminTask.showWMQActivationSpec(actspec))
      printDictionary(prefix,inputDictionary=actspecdict,keyMap=actspecnamemap)
              



#------------------------------------------------------------------------------------------------------
# printMQGenericConnectionFactory - also works for Topic
#------------------------------------------------------------------------------------------------------
def printMQGenericConnectionFactory(prefix,cf) :

  try:    
    cfname = AdminConfig.showAttribute(cf,'name')
    printLine("%s.name = %s" % (prefix, cfname))
    
    printSimpleProperties("%s.prop" % prefix, cf,["name"])
    
    cfConnectionPool = AdminConfig.showAttribute(cf,'connectionPool')
    if (cfConnectionPool != ''):
      printSimpleProperties("%s.connectionPool.prop" % (prefix), cfConnectionPool)
      printCustomProperties("%s.connectionPool.customProperties" % prefix, cfConnectionPool, "properties")
    
    try:  
      cfMappingModules = AdminConfig.list('MappingModule',cf).split(SEPARATOR)
      if (len(cfMappingModules) > 0 and cfMappingModules[0] != ''):
        printProperties("%s.mappingModule.prop" % (prefix), cfMappingModules[0])
    except:
      eString = _app_message("Error printing MQ CF mapping module","exception")
      printLine("# Error printing MQ CF mapping module\n#%s" % eString)
      
      
    cfSessionPool = AdminConfig.showAttribute(cf,'sessionPool')
    if (not isEmpty(cfSessionPool)):
      printSimpleProperties("%s.sessionPool.prop" % (prefix), cfSessionPool)
    
    printCustomProperties("%s.customProperties" % prefix, cf, "properties")
    
    dumpResourceProperties(cf,"propertySet","%s.propertySet" % prefix)
  except:
    eString = _app_message("Error printing MQ connection factory","exception")
    printLine("# Error printing MQ connection factory %s %s\n#%s" % (prefix,cf,eString))
 

#------------------------------------------------------------------------------------------------------
# printProviderInfo
#   Prints JDBCProvider information (Not including datasources)
#------------------------------------------------------------------------------------------------------
def printProviderInfo(provider, pCluster, pNode, pServer,pDynCluster="",pApp="",pAppDeployment="",parmMap=None):
    global provId
    prefix = "app.jdbc.provider.%d" % (provId)
    
    if (parmMap != None and parmMap.get("-printid",0)):
      printLine("# Source ID: %s" % provider)

    printLine("%s.cluster = %s" % (prefix, pCluster))
    printLine("%s.node = %s" % (prefix, pNode))
    printLine("%s.server = %s" % (prefix, pServer))
    if (not isEmpty(pDynCluster)):
      printLine("%s.dynamicCluster = %s" % (prefix, pDynCluster))
    
    if (not isEmpty(pApp)):
      printLine("%s.application = %s" % (prefix,pApp))
  
    if (not isEmpty(pAppDeployment)):
      printLine("%s.deployment = %s" % (prefix,pAppDeployment))
      
    printLine(" ")

    incKeys = ['name', 'description', 'implementationClassName', 'classpath', 'nativepath', 'providerType','xa' ]
    provProps = collectSimpleProperties(None, "prop",provider, [])
    for attr in incKeys:
        #value= AdminConfig.showAttribute(provider,attr)
        value = provProps.get("prop.%s" % attr)
        if (value == "[]"):
            continue
        if (value == None):
          value = ""
        printLine("%s.prop.%s = %s" % (prefix, attr, value))
    
    printLine(" ")
    printLine("# Optional: templateName can be used instead of properties to create a new provider. name is still required")
    printLine("#%s.templateName = " % (prefix))

    printLine(" ")

#------------------------------------------------------------------------------------------------------
# printProperties
# 
# This method uses a recursive algorithm to print a configuation items properties and the properties of 
# subitems. The logic and formatting behind this method is not as nice as the printSimpleProperties method.
#
# Parameters:
#    prefix - the prefix to use when printing configuration information
#    objId - The configuration ID of the item to print
#-------------------------------------------------------------------------------------------------------
def printProperties(prefix,objId):
        if (isEmpty(objId)): return
        skipTags = ["managedObject", "server"]
        attrs = AdminConfig.show(objId).split(SEPARATOR)
        for attr in attrs:
                key,val= toKeyValue(attr)
                if (key == "server"):
                        val = AdminConfig.showAttribute(val,"name")
                        nodeName = getNodeNameForServer(val)
                        webPort, adminPort = getWebServerPortInfo(nodeName,val)
                        printLine("%s.name = %s" % (prefix, val))
                        printLine("%s.nodeName = %s" % (prefix, nodeName))
                        printLine("%s.webPort = %s" % (prefix, webPort))
                        printLine("%s.adminPort = %s" % (prefix, adminPort))

                if (key in skipTags): continue
                if (isEmpty(val)): continue

                if (val.startswith('"') and val.endswith('"')):
                        val = val[1:-1]

                if (isArray(val)):
                        arrayList = wsadminToList(val)
                        idCount = 0
                        for arr in arrayList:
                                moduleExt =""
                                idCount = idCount + 1
                                if (isId(arr) == 1):
                                        printProperties("%s.%s.%s%d.prop" % (prefix, key, moduleExt, idCount),arr)
                                else:
                                        printLine("%s.%s.%s%d.prop = %s" % (prefix, key, moduleExt, idCount,arr))
                        printLine("%s.%s.count = %d" % (prefix, key,idCount))
                        continue

                if (isId(val) == 1):
                        printProperties("%s.%s" % (prefix, key),val)
                else:
                        printLine("%s.%s = %s" % (prefix, key,val))

#------------------------------------------------------------------------------------------------------
# @JJM-
# printSimpleProperties
#
# With the default options, this method only prints only simple properties of a configuration object, 
# skipping lists and nested elements. 
#
# With the expanded options it can handle custom properties, resource properties, nested items and
# list attributes.
#
# Parameters:
#   prefix - The prefix to use. The output will be in the format prefix.key = value
#   objId - The configuration ID to format.
#   optionalSkipList - A list of attributes to ignore.
#   includeBlanks - If this value is 1, attributes with an empty value will be printed out.
#   printSimpleChildren - if true, attributes that are a base WCCM type will be included in output
#   childrenSkipList - an optional  list of attributes to leave out
#   printPropertyAttributes - if 1, then properties and resourceProperties will be included in output
#   useAttrNameWithProperties - if 1, then attribute name of resource property set will be included
#   includeReferenceChildren - if 1, properties of reference attributes will be included
#   printListChildren - if 1, list attributes of WCCM types will be included in output
#   printChildType - if 1, a type key will be included with name of WCCM type for child attribute
#   collectDict - a dictionary passed in to this method that the key/values will be stored in for use by caller
#   identifierMap - an optional map that lists the identifier attributes (e.g. "name") to be used with specific
#                   configuration types.  These identifiers will be printed first before other attributes
#   sortListChildren - optional if 1, then lists of child configuration IDs will be sorted before being written out
#------------------------------------------------------------------------------------------------------
def printSimpleProperties(prefix,objId, optionalSkipList=[],includeBlanks=0,printSimpleChildren=0,childrenSkipList=None,
                          printPropertyAttributes=0,useAttrNameWithProperties=0,includeReferenceChildren=0,printListChildren=0,
                          printChildType=0,collectDict=None,identifierMap=None,sortListChildren=0):
  try:
    if (isEmpty(objId)): return
    	
    skipTags = ["managedObject", "server"]
    
    # Get the key/value information to parse
    attrs = AdminConfig.show(objId).split(SEPARATOR)
    
    childDict = {}
    listDict = {}

		# Print identifying attributes at the start of the output
		# Identifiers will not have a ".prop." in the key
    identifierList = None
    
    if (identifierMap != None):
      configType = callGetObjectType(objId)
      identifierList = identifierMap.get(configType,[])
    
    if (identifierList != None and len(identifierList) > 0):
      # print identifiers
      tempPrefix = prefix
      if (tempPrefix.endswith(".prop")):
        tempPrefix = tempPrefix[:-5]
      
      for identifierAttribute in identifierList:
        val = AdminConfig.showAttribute(objId,identifierAttribute)
        if (val == "None"):
          val = ""
        printLine("%s.%s = %s" % (tempPrefix,identifierAttribute,val))
        if (collectDict != None):
            collectDict["%s.%s" % (tempPrefix,identifierAttribute)] = val          
    
    # Loop through the AdminConfig.show() output
    for attr in attrs:
    	  # Parse the line into key value pairs
        key,val= toKeyValue(attr)
        
        if (key in skipTags and isId(val)):
          continue
        if (optionalSkipList != None and key in optionalSkipList):
          if (collectDict != None):
            collectDict["%s.%s" % (prefix,key)] = val  
          continue
        if (identifierList != None and key in identifierList):
          continue
                  
        if (isEmpty(val)): 
          if (not includeBlanks): 
            continue
          else:
            val = ""
        
        if (val.startswith('"') and val.endswith('"')):
            val = val[1:-1]
        
        if (collectDict != None):
          collectDict["%s.%s" % (prefix,key)] = val 
        
        if (isArray(val)): 
          listDict[key] = val
          continue
        if (isId(val) == 1):
          childDict[key] = val
          continue
        else:
          printLine("%s.%s = %s" % (prefix, key,val))

    configType = None
    childPrefixRoot = prefix
    if (printSimpleChildren or printPropertyAttributes):
      if (childPrefixRoot.endswith(".prop")):
        childPrefixRoot = childPrefixRoot[:-5]

      configType = callGetObjectType(objId)
    
    if (printPropertyAttributes):
      if (not isEmpty(configType)):
        propertyAttrList = getPropertyAttributes(configType)
        
        
        rpcount = 0
        pcount = 0
        for pattr in propertyAttrList:
          attrName = pattr[0]
          attrType = pattr[1]
          
          # Make sure this name is not in the dictionary for listed children
          if (listDict.has_key(attrName)):
            del listDict[attrName]
          
          if (attrType == "J2EEResourcePropertySet"):
            rpcount += 1
          else:
            pcount +1
        
        for pattr in propertyAttrList:
          attrName = pattr[0]
          attrType = pattr[1]
          
          pprefix = childPrefixRoot
          
          if (attrType == "J2EEResourcePropertySet"):
            
            if (useAttrNameWithProperties or (rpcount > 1)):
              pprefix = "%s.%s" % (childPrefixRoot,attrName)
            
            dumpResourceProperties(objId,attrName,pprefix)
          else:
            pprefix = "%s.%s" % (childPrefixRoot,attrName)
            printCustomProperties(pprefix, objId, attributeName=attrName)
            
            
    
    if (printSimpleChildren):
      
      
      if (not isEmpty(configType)):
        subItemList = getSimpleSubComponentAttributes(configType,includeReferenceChildren,
                      allowSubClasses = printChildType)
         
        
        for subItem in subItemList:
          subAttribute = subItem[0]
          subType = subItem[1]
        
          if (childrenSkipList != None and subAttribute in childrenSkipList):
            continue
        
          childPrefix = "%s.%s.prop" % (childPrefixRoot,subAttribute)
          
          # At this point, we should already know the ID of the child
          # from the parsing of show above
          childId = childDict.get(subAttribute)
          if (not isEmpty(childId)):
            printLine("%s.%s.type = %s" % (childPrefixRoot,subAttribute,callGetObjectType(childId)))
            printSimpleProperties(childPrefix,childId, optionalSkipList=[],includeBlanks=includeBlanks,printSimpleChildren=1,
                                  childrenSkipList=childrenSkipList,printListChildren=printListChildren,
                                  printChildType=printChildType,printPropertyAttributes=printPropertyAttributes,
                                  collectDict=collectDict,identifierMap=identifierMap,sortListChildren=sortListChildren)
  
    if (printListChildren):
    	
    	tempKeyList = [lkey for lkey in listDict.keys()]
    	tempKeyList.sort()
      
      for lkey in tempKeyList:
        cfgList = wsadminToList(listDict[lkey])
        lidx = 0
        if (sortListChildren):
          cfgList.sort()
        for cfg in cfgList:
          if (isEmpty(cfg)):
            continue
          if (childrenSkipList != None and lkey in childrenSkipList):
            continue
            
          lidx += 1
          lprefix = "%s.%s.%d.prop" % (childPrefixRoot,lkey,lidx)
          if (printChildType):
            printLine("%s.%s.%d.type = %s" % (childPrefixRoot,lkey,lidx,callGetObjectType(cfg)))
          printSimpleProperties(lprefix,cfg,optionalSkipList=[],includeBlanks=includeBlanks,printSimpleChildren=1,childrenSkipList=childrenSkipList,printListChildren=1,
                                printChildType=printChildType,printPropertyAttributes=printPropertyAttributes,
                                collectDict=collectDict,identifierMap=identifierMap)
        
        if (lidx > 0):
          printLine("%s.%s.count = %d" % (childPrefixRoot,lkey,lidx))
  except:
    _app_message("Exception in printSimpleProperties(%s)"%objId,"exception")
    raise    


#enddef printSimpleProperties

#--------------------------------------------------------------------------------------------
# Put key/value pairs from configuration item into property set
#--------------------------------------------------------------------------------------------
def collectSimpleProperties(props, prefix,objId, optionalSkipList=[],nestedIds=None):
  
    isDict = 0
    if (props == None):
      props = java.util.Properties()
    elif (type(props) == type({})):
      isDict = 1
    
  
    if (objId == ""): return
    skipTags = ["managedObject", "server"]
    attrs = []
    try:
      attrs = AdminConfig.show(objId).split(SEPARATOR)
    except:
      _app_message("Unable to run AdminConfig.show(%s)" % objId,"exception")
      raise StandardError("Unable to run AdminConfig.show(%s)" % objId)
    for attr in attrs:
        key,val= toKeyValue(attr)
        
        if (key in skipTags): continue
        if (key in optionalSkipList): continue
        if (isEmpty(val)): continue
        
        #remove "quotes" from value
        if (val.startswith('"') and val.endswith('"')):
            val = val[1:-1]
        
        if (isArray(val)):
          if (nestedIds != None):
            nestedIds["%s.%s" % (prefix,key)] = val
          continue
        if (isId(val) == 1):
          if (nestedIds != None):
            nestedIds["%s.%s" % (prefix,key)] = val
          continue
        else:
          if (isDict):
            props["%s.%s" % (prefix, key)] = val
          else:
            props.put("%s.%s" % (prefix, key) ,val)
  
    return props  

#------------------------------------------------------------------------------
# printDictionary - Utility for printing out a dictionary with key/value pairs.
#                   Designed to work with AdminTask.showXXX and wsadminToDictionary
#
#
# prefix - prefix to append to property keys
# inputDictionary - dictionary to print
# identifierKeys - List of keys to print first (without .prop.)
# keyMap - optional map with alternate key names to use
#------------------------------------------------------------------------------
def printDictionary(prefix,inputDictionary,identifierKeys=["name"],keyMap=None):
  try:
     
    if (keyMap == None):
      keyMap = {}
      
    # Prep sorted list
    keyList = []
    for key in inputDictionary.keys():
      if (keyMap.has_key(key)):
        inputDictionary[keyMap[key]] = inputDictionary[key]
        keyList.append(keyMap[key])
      else:
        keyList.append(key)
    
    keyList.sort()
    
    for idkey in identifierKeys:
      name = inputDictionary.get(idkey,"")
      printLine("%s.%s = %s" % (prefix, idkey, name))
    
    for key in keyList:
        if (key in identifierKeys):
            continue
        val = inputDictionary[key]
        
        if (val == "null"):
          val = ""
                 
        printLine("%s.prop.%s = %s" % (prefix, key, val))
          
    
  except:
    _app_message("Unexpected error in printDictionary()","exception")

#-----------------------------------------------------------------------------------------------------
# printCustomProperties
#-----------------------------------------------------------------------------------------------------
def printCustomPropertiesOriginal(prefix, objId, attributeName="customProperties"):

    
    customProperties =AdminConfig.showAttribute(objId,attributeName)
    tempList = []
    if (not isEmpty(customProperties)):
      for cpropsitem in wsadminToList(customProperties):
        if (isEmpty(cpropsitem)):
          continue
        cpProperties = collectSimpleProperties(None, "prop",cpropsitem, [])
        
        cpropdesc = cpProperties.get("prop.description")
        cpropname = cpProperties.get("prop.name")
        cpropval = cpProperties.get("prop.value")
        
        if (cpropval == None):
          cpropval = ""

        if isEmpty(cpropdesc):
          #printLine("%s.prop.%s = %s" % (prefix,   cpropname, cpropval))
          tempList.append("%s.prop.%s = %s" % (prefix,   cpropname, cpropval))
        else:
          #printLine("%s.prop.%s = %s|%s" % (prefix,   cpropname, cpropval, cpropdesc))
          tempList.append("%s.prop.%s = %s|%s" % (prefix,   cpropname, cpropval, cpropdesc))
      
      tempList.sort()
      for tempStr in tempList:
        printLine(tempStr)
						

#-----------------------------------------------------------------------------------------------------
# printCustomProperties
#
# Formats the custom properties of a configuration item given the item and attribute
# name for the custom properties.  Properties are formatted using the format:  <prefix>.prop.key = value[|descr]
#
# This implemenation relies on parsing of the results from AdminConfig.showall(objId,attributeName)
# where objId is the configuration item with custom properties and attributeName is the attribute
# that returns the list of custom property IDs.
# 
# Parameters:
#    prefix - The prefix to use with output
#    objId  - The configuration item with custom properties
#    attributeName - the attribute to be formatted, defaults to "customProperties"
#-----------------------------------------------------------------------------------------------------
def printCustomProperties(prefix, objId, attributeName="customProperties"):
  try:
    try:
      propertyText = AdminConfig.showall(objId, attributeName)
    except:
      # Might be a back level that does not have this property
      propertyText = ""
      
    tempList = []
    if (not isEmpty(propertyText)):
      
      # Trim the string down to remove the opening "[propertyName ["  and last "]]"
      firstPos = propertyText.find("[[")
      if (firstPos > 0):
        propertyText = propertyText[firstPos+1:-2]
        #print "Modded text"
        #print propertyText
        # Convert newlines into spaces
        propertyTextLines = propertyText.split(SEPARATOR)
    
        reformedText = ""
        for line in propertyTextLines:
          if reformedText == "":
            reformedText = line
          else:
            reformedText = "%s %s" % (reformedText,line)
    
        # Ok, now we want to split on " [["
        propertyList = reformedText.split(" [[")
        for prop in propertyList:
          if ( not prop.startswith("[[")):
            prop = "[[%s" % prop
          
          prop = prop[1:-1]
          #print prop
          
          # Now we need to split the attributes
          attribs = prop.split("] ")
          cpProperties = java.util.Properties()
          for attrib in attribs:
            if (attrib.endswith("[]")):
              # Blank
              attrib = "%s]" % attrib
            elif (not attrib.endswith("]")):
              attrib = "%s]" % attrib
            
            #print attrib
            key,val = toKeyValue(attrib)
            if val.startswith('"') and val.endswith('"'):
              val = val[1:-1]
            if val == "[]":
              val = ""
            
            cpProperties.put(key,val)
        
          #print "%s" % cpProperties
          cpropdesc = cpProperties.get("description")
          cpropname = cpProperties.get("name")
          cpropval = cpProperties.get("value")
        
          if (cpropval == None):
            cpropval = ""
          else:
            cpropval = cpropval.strip()
            
          if isEmpty(cpropdesc):
            #printLine("%s.prop.%s = %s" % (prefix,   cpropname, cpropval))
            tempList.append("%s.prop.%s = %s" % (prefix,   cpropname, cpropval))
          else:
            #printLine("%s.prop.%s = %s|%s" % (prefix,   cpropname, cpropval, cpropdesc))     
            tempList.append("%s.prop.%s = %s|%s" % (prefix,   cpropname, cpropval, cpropdesc.strip()))
          

        
        if (len(tempList) > 0):
          tempList.sort()
          for tempStr in tempList:
            printLine(tempStr)
  except:
    eString = _app_message("Unexpected error in printCustomProperties()","exception") 
    printLine("#Unexpected error in printCustomProperties()\n#%s" % eString)


#---------------------------------------------------------------------------
# printDescriptivePropertyGroup
#---------------------------------------------------------------------------
def printDescriptivePropertyGroup(prefix,parentId=None,attributeName=None,dpgId=None):
  try:
    if (isEmpty(dpgId)):
      if (not isEmpty(parentId) and not isEmpty(attributeName)) :
        dpgId = AdminConfig.showAttribute(parentId,attributeName)
    
    if (not isEmpty(dpgId)):
      nestedIds = {}
      dpgProps = {}
      collectSimpleProperties(dpgProps, "dpg",dpgId, nestedIds=nestedIds)
      
      dpgName = dpgProps.get("dpg.name")
      printLine("%s.name = %s" % (prefix,dpgName))
      
      propertyGroups = nestedIds.get("dpg.propertyGroups")
      properties = nestedIds.get("dpg.properties")
      
      if (not isEmpty(propertyGroups)):
        pgList = wsadminToList(propertyGroups)
        pgIdx = 0
        for pg in pgList:
          if (isEmpty(pg)):
            continue
          pgIdx += 1  
          pgPrefix = "%s.propertyGroups.%d" % (prefix,pgIdx)
          printDescriptivePropertyGroup(pgPrefix,dpgId=pg)
      
      if (not isEmpty(properties)):
        propList = wsadminToList(properties)
        propIdx = 0
        for prop in propList:
          if (isEmpty(prop)):
            continue
          dpNestedIds = {}
          dpProps = {}
          collectSimpleProperties(dpProps, "dp",prop, nestedIds=dpNestedIds)
          
          propName = dpProps.get("dp.name")
          propVal = dpProps.get("dp.value")
          propDesc = dpProps.get("dp.description","")
          
          if (isEmpty(propDesc)):
            printLine("%s.properties.prop.%s = %s" % (prefix,propName,propVal))
          else:
            printLine("%s.properties.prop.%s = %s|%s" % (prefix,propName,propVal,propDesc))
          
        
          
          
          
      
      
  except:
    _app_message("Unexpected problem in printDescriptivePropertyGroup(%s)" % prefix,"exception")
    

#------------------------------------------------------------------------------------------------------
def getWebServerPortInfo(nodeName,wsName):
      webPort = adminPort = ""
      se = AdminConfig.getid("/Cell:%s/Node:%s/ServerIndex:/ServerEntry:%s/" % (getCellName(),nodeName,wsName) )
      if (not isEmpty(se)):
        seps=wsadminToList(AdminConfig.showAttribute(se,"specialEndpoints"))
        for sep in seps:
            if (isEmpty(sep)):
              continue
            if ("WEBSERVER_ADDRESS" == AdminConfig.showAttribute(sep,"endPointName")):
                webPort = AdminConfig.showAttribute(AdminConfig.showAttribute(sep,"endPoint"),"port")
            if ("WEBSERVER_ADMIN_ADDRESS" == AdminConfig.showAttribute(sep,"endPointName")):
                adminPort = AdminConfig.showAttribute(AdminConfig.showAttribute( sep,"endPoint"),"port")
            if (not isEmpty(webPort) and not isEmpty(adminPort)):
              break
            
      return webPort, adminPort

#-------------------------------------------------------------------------------
def dumpCell(**options):
  try:
    cellName = getCellName()
    cellId = getCellId()
    
    printLine("app.cell.name = %s" % cellName)
    printSimpleProperties("app.cell.prop",cellId,["name"],printSimpleChildren=1,
                           printPropertyAttributes=1,useAttrNameWithProperties=1,printListChildren=1)
  except:
    _app_message("Unexpected error in dumpCell","exception")




#------------------------------------------------------------------------------------------------------
def printDataSourceInfo(ds,parmMap=None):
    global provId
    global dsId
    keys = ['connectionPool', 'properties', 'mapping', 'propertySet']
    incKeys = ['authMechanismPreference', 'description', 'jndiName', 'statementCacheSize', 'authDataAlias', 'datasourceHelperClassname', 'manageCachedHandles', 'xaRecoveryAuthAlias', 'diagnoseConnectionUsage', 'logMissingTransactionContext']
    cpKeys = ['agedTimeout', 'connectionTimeout', 'freePoolDistributionTableSize', 'maxConnections', 'minConnections', 'numberOfFreePoolPartitions', 'numberOfSharedPoolPartitions', 'numberOfUnsharedPoolPartitions', 'purgePolicy', 'reapTime', 'stuckThreshold', 'stuckTime', 'stuckTimerTime', 'surgeCreationInterval', 'surgeThreshold', 'testConnection', 'testConnectionInterval', 'unusedTimeout' ]
    
    prefix = "app.jdbc.provider.%d.ds.%d" % (provId,dsId)
    
    nestedIds = {}
    dsProps = collectSimpleProperties(None, "ds.prop",ds,nestedIds=nestedIds)
    
    if (parmMap != None and parmMap.get("-printid",0)):
      printLine("# Source ID: %s" % ds)
    
    printLine("%s.dsAttrs.prop.name = %s" % (prefix, dsProps.get("ds.prop.name")))
    printLine(" ")
    
    # dspropAttrs attributes
    for attr in incKeys:
    		val = dsProps.get("ds.prop.%s" % attr)
    		if (val == None):
    			val = ""
    		printLine("%s.dspropAttrs.prop.%s = %s" % (prefix, attr, val))
    
    printLine(" ")
    
    # See if a CMP factory is needed
    cmpfactory = None
    cmpList = AdminConfig.list("CMPConnectorFactory").split(SEPARATOR)
    for cmp in cmpList:
    		if (isEmpty(cmp)):
    				continue
    		if (ds == AdminConfig.showAttribute(cmp,"cmpDatasource")):
    				cmpfactory = cmp
    				break
    
    if (cmpfactory == None):
    		printLine("%s.createCMPFactory = false" % prefix)
    else:
    		printLine("%s.createCMPFactory = true" % prefix)
    
    printLine(" ")

    # mapping attributes
    #mId = AdminConfig.showAttribute(ds,"mapping")
    mId = nestedIds.get("ds.prop.mapping")
    if not (isEmpty(mId)):
        attrs =  AdminConfig.showall(mId).split(SEPARATOR)
        for attr in attrs:
            k,v = toKeyValue(attr)
    	    printLine("%s.mapAttrs.prop.%s = %s" % (prefix, k,v))

        printLine(" ")
	
	  
    #mId = AdminConfig.showAttribute(ds,"connectionPool")
    mId = nestedIds.get("ds.prop.connectionPool")
    if not (isEmpty(mId)):
    	cpProps = collectSimpleProperties(None, "connpool.prop",mId)
    	for key in cpKeys:
    		value = cpProps.get("connpool.prop.%s" % key)
    		if (value == None):
    			value = ""
    		printLine("%s.connpool.prop.%s = %s" % (prefix, key,value))
    	
    	printCustomProperties("%s.connpool.customProperties" % (prefix), mId, "properties")
    	printLine(" ")

    
    #mId = AdminConfig.showAttribute(ds,"propertySet")
    mId = nestedIds.get("ds.prop.propertySet")
    if not (isEmpty(mId)):
    	printCustomProperties("%s.rpAttrs" % (prefix), mId, "resourceProperties")

    	printLine(" ")



    printLine(" ")

#------------------------------------------------------------------------------------------------------
def printSchedulerProviderInfo(prefix,provider, pCluster, pNode, pServer,pDynCluster=None,pApp=None,pAppDeployment=None):

  
  printLine("%s.cluster = %s" % (prefix, pCluster))
  printLine("%s.node = %s" % (prefix, pNode))
  printLine("%s.server = %s" % (prefix, pServer))
  
  if (not isEmpty(pDynCluster)):
    printLine("%s.dynamicCluster = %s" % (prefix, pDynCluster))
    
  if (not isEmpty(pApp)):
    printLine("%s.application = %s" % (prefix,pApp))
  
  if (not isEmpty(pAppDeployment)):
    printLine("%s.deployment = %s" % (prefix,pAppDeployment))
  
  printLine(" ")
  
  providerName = AdminConfig.showAttribute(provider,"name")
  printLine("%s.name = %s" % (prefix,providerName))
  printSimpleProperties("%s.prop" % prefix, provider,["name"])

      
  printLine(" ")

#--------------------------------------------------------------------------------------------------------
def printScheduler(prefix,scheduler):
 
  schedulerName = AdminConfig.showAttribute(scheduler,"name")
  printLine("%s.name = %s" % (prefix,schedulerName))
  
  printSimpleProperties("%s.prop" % prefix,scheduler, ["name"],includeBlanks=0)
  
  dumpResourceProperties(scheduler,"propertySet",prefix)    
  
	
	
	

#------------------------------------------------------------------------------------------------------
# @JJM
def dumpSchedulers(targetCluster=None,targetNode=None,targetServer=None,wildcard="*",serverList=None,membersList=None):
  schedulerProvId = 0
  schedulerId = 0
  
  prtheader = 1
  providers = AdminConfig.list("SchedulerProvider").split(SEPARATOR)
  if (providers[0] == ''): return
  for provider in providers:
      
      if (isEmpty(provider)):
        continue
      
      c,n,s,dc,app,appdep = getScope(provider)
      
      # See if we match target scope filters
      if (not isEmpty(targetCluster)):
        memberMatch = 0
        if (membersList != None):
          if (not isEmpty(n) and not isEmpty(s)):
            member = (n,s)
            if (member not in membersList):
              continue
            else:
              memberMatch = 1
              
        if (not memberMatch and not checkPossibleWildcardMatch(c, targetCluster, wildcard)):
          continue
          

      if (not isEmpty(targetNode)):
        if ((targetNode != n)):
          continue
          
        if (not isEmpty(targetServer)):
          if (targetServer != s):
            continue
        elif (not isEmpty(s)):
          continue          
          
      if (isEmpty(targetServer) and serverList != None and [n,s] not in serverList):
        continue
      
      schedulers = AdminConfig.list("SchedulerConfiguration",provider).split(SEPARATOR)
      if (isEmpty(schedulers)): continue
        
      if (prtheader):
        prtheader = 0
        printLine("")
        printLine("#---------------------------------------------------------------")
        printLine("# Scheduler")
        printLine("#---------------------------------------------------------------")
        printLine("")
        
      schedulerProvId = schedulerProvId + 1
        
      prefix = "app.scheduler.provider.%d" % (schedulerProvId)
      printSchedulerProviderInfo(prefix,provider,c,n,s,dc,app,appdep)
      
      schedulerId = 0
      for scheduler in schedulers:
        if (isEmpty(scheduler)): continue
        schedulerId = schedulerId + 1
        prefix = "app.scheduler.provider.%d.scheduler.%d" % (schedulerProvId, schedulerId)
        
        printScheduler(prefix,scheduler)
        
      printLine("app.scheduler.provider.%d.scheduler.count = %d" % (schedulerProvId, schedulerId))
      printLine("")
  
  
  printLine("app.scheduler.provider.count = %d" % (schedulerProvId))

#wsadmin>print AdminConfig.show("DefaultTimerManager(cells/ScriptingCell|resources-pme.xml#TimerManagerInfo_Default)")
#[description "WebSphere Default TimerManager"]
#[jndiName tm/default]
#[name DefaultTimerManager]
#[numAlarmThreads 2]
#[provider TimerManagerProvider(cells/ScriptingCell|resources-pme.xml#TimerManagerProvider_1)]
#[serviceNames []]


#------------------------------------------------------------------------------------------------------
# isDefaultTimer: utility method to determine if defined timer is a default and shouldn't be exported
#------------------------------------------------------------------------------------------------------
defaultTimer = {'tm.numAlarmThreads': '2', 'tm.jndiName': 'tm/default', 'tm.description': 'WebSphere Default TimerManager', 'tm.name': 'DefaultTimerManager'}
def isDefaultTimer(tm):
  global defaultTimer
  retval = 0
  props = {}
  collectSimpleProperties(props,"tm",tm)
  if (props == defaultTimer):
    retval = 1
   
  return retval

#wsadmin>print AdminConfig.attributes("TimerManagerInfo")
#category String
#defTranClass String
#description String
#jndiName String
#name String
#numAlarmThreads int
#propertySet J2EEResourcePropertySet
#provider J2EEResourceProvider@
#providerType String
#referenceable Referenceable@
#serviceNames String*


#------------------------------------------------------------------------------------------------------
# dumpTimerManagers
#------------------------------------------------------------------------------------------------------
def dumpTimerManagers(pattern="",targetCluster="",targetNode="",targetServer="",targetCell="",wildcard="*",parmMap=None,serverList=None,membersList=None):
  try:
    prtheader = 0
    
    if (parmMap == None):
      parmMap = {}
    
    ignoredefaults = 0  
    if (parmMap.get("ignoredefaults","true").lower() == "true"):
      ignoredefaults = 1
    timerproviders = []
    timerinfos = listResourceCandidatesAtScope("TimerManagerInfo",targetCluster,targetNode,targetServer,targetCell,wildcard="*",serverList=None,membersList=membersList)
    for tm in timerinfos:
      if (isEmpty(tm)):
        continue
      if (ignoredefaults):
        if (isDefaultTimer(tm)):
          continue
        
      c,n,s,dc,app,appdep = getScope(tm)
      tempProviders = getObjectsAtScope("TimerManagerProvider:/",c,n,s,dc,app,appdep)
      for tprovider in tempProviders:
        if (tprovider not in timerproviders):
          timerproviders.append(tprovider)
          
    timerproviders.sort()

    providerIdx = 0
    for timerprovider in timerproviders:
      
      if (isEmpty(timerprovider)):
        #Empty string
        continue
      
      
      providerName = AdminConfig.showAttribute(timerprovider,"name")
          
      c,n,s,dc,app,appdep = getScope(timerprovider)
      scopeid = getScopeId(c,n,s,dc,app,appdep)
      
      if (not resourceMatchArgs(c,n,s,targetCluster,targetNode,targetServer,targetCell,wildcard,resourceName=providerName,namePattern=pattern,serverList=serverList,membersList=membersList)):
        continue
      
      if (prtheader):
        prtheader = 0
        printLine("")
        printLine("#-------------------------------------")
        printLine("# TimerManager")
        printLine("#-------------------------------------")
      
      providerIdx += 1
      printLine("")
      printScopeLines("app.timer.provider.%d" % (providerIdx),c,n,s,dc,app,appdep)
      printLine("")
      printLine("app.timer.provider.%d.name = %s" % (providerIdx,providerName))
      printSimpleProperties("app.timer.provider.%d.prop" % providerIdx, timerprovider, ["name"], printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1)
                          
      timerinfos = AdminConfig.list("TimerManagerInfo",timerprovider).splitlines()
      infoIdx = 0
      for timerinfo in timerinfos:
        if (isEmpty(timerinfo)):
          continue
        infoIdx += 1
        printLine("")
        infoName = AdminConfig.showAttribute(timerinfo,"name")
        printLine("app.timer.provider.%d.timermanager.%d.name = %s" % (providerIdx,infoIdx,infoName))
        printSimpleProperties("app.timer.provider.%d.timermanager.%d.prop" % (providerIdx,infoIdx), timerinfo, ["name"], printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1)
      
      if (infoIdx > 0):
        printLine("")
        printLine("app.timer.provider.%d.timermanager.count = %d" % (providerIdx,infoIdx))
    
        
    if (providerIdx > 0):
      printLine("app.timer.provider.count = %d" % providerIdx)
      

  except:
    _app_message("Unexpected error in dumpTimerManagers","exception")
  

#------------------------------------------------------------------------------------------------------
# printWorkManagerProviderInfo
#------------------------------------------------------------------------------------------------------
def printWorkManagerProviderInfo(provider, pCluster, pNode, pServer,pDynCluster="",pApp="",pAppDeployment=""):
  global wmProvId
  prefix = "app.workmanager.provider.%d" % (wmProvId)

  printLine("%s.cluster = %s" % (prefix, pCluster))
  printLine("%s.node = %s" % (prefix, pNode))
  printLine("%s.server = %s" % (prefix, pServer))

  if (not isEmpty(pDynCluster)):
      printLine("%s.dynamicCluster = %s" % (prefix,pDynCluster))
    
  if (not isEmpty(pApp)):
      printLine("%s.application = %s" % (prefix,pApp))
  
  if (not isEmpty(pAppDeployment)):
      printLine("%s.deployment = %s" % (prefix,pAppDeployment))       
  
  
  printLine(" ")

  incKeys = ['name', 'description' ]
  for attr in incKeys:
    value= AdminConfig.showAttribute(provider,attr)
    if (value == "[]"):
      continue
    printLine("%s.prop.%s = %s" % (prefix, attr, value))
      
  printLine(" ")

#--------------------------------------------------------------------------------------------------------
# printWorkManager
#--------------------------------------------------------------------------------------------------------
def printWorkManager(workmanager):

	global wmProvId
	global wmId
	
	prefix = "app.workmanager.provider.%d.workmanager.%d" % (wmProvId, wmId)

	printLine("%s.name = %s" % (prefix, AdminConfig.showAttribute(workmanager,"name")))
	printSimpleProperties("%s.prop" % prefix,workmanager, ["name"])
	
	dumpResourceProperties(workmanager,"propertySet",prefix)
	



#-----------------------------------------------------------------------------------------------------
# isDefaultWorkManager
#
# Check some basic properties to see if this is a work manager that has common default values
#-----------------------------------------------------------------------------------------------------
ardWM = {'wm.threadPriority': '5', 'wm.name': 'AsyncRequestDispatcherWorkManager', 'wm.jndiName': 'wm/ard', 'wm.numAlarmThreads': '5', 'wm.workReqQFullAction': '1', 'wm.workTimeout': '10000', 'wm.maxThreads': '50', 'wm.isGrowable': 'false', 'wm.isDistributable': 'false', 'wm.serviceNames': 'UserWorkArea;security;AppProfileService;com.ibm.ws.i18n;zos.wlm', 'wm.workReqQSize': '0', 'wm.minThreads': '1'}
defaultWM = {'wm.threadPriority': '5', 'wm.name': 'DefaultWorkManager', 'wm.jndiName': 'wm/default', 'wm.category': 'Default', 'wm.numAlarmThreads': '5', 'wm.workReqQFullAction': '0', 'wm.description': 'WebSphere Default WorkManager', 'wm.workTimeout': '0', 'wm.maxThreads': '10', 'wm.isGrowable': 'false', 'wm.isDistributable': 'false', 'wm.serviceNames': 'AppProfileService;com.ibm.ws.i18n;security;UserWorkArea;zos.wlm', 'wm.workReqQSize': '0', 'wm.minThreads': '1'}


def isDefaultWorkManager(wmid) :
  global ardWM
  global defaultWM
  
  result = 0
  props = {}
  collectSimpleProperties(props,"wm",wmid)
  if (props == ardWM or props == defaultWM):
    result = 1
  
  return result

#------------------------------------------------------------------------------------------------------
# @JJM
def dumpWorkManagers(targetCluster=None,targetNode=None,targetServer=None,wildcard="*",serverList=None,membersList=None):
  global wmProvId
  global wmId
  
  prtheader = 1
  
  wmProvId = 0
  providers = AdminConfig.list("WorkManagerProvider").split(SEPARATOR)
  if (providers[0] == ''): return
  for provider in providers:
      c,n,s,dc,app,appdep = getScope(provider)
      
      if (not isEmpty(targetCluster)):
        memberMatch = 0
        if (membersList != None):
          if (not isEmpty(n) and not isEmpty(s)):
            member = (n,s)
            if (member not in membersList):
               continue
            else:
              memberMatch = 1        
              
        if (not memberMatch and not checkPossibleWildcardMatch(c, targetCluster, wildcard)):
          continue

      if (not isEmpty(targetNode)):
        if ((targetNode != n)):
          continue
          
        if (not isEmpty(targetServer)):
          if (targetServer != s):
            continue
        elif (not isEmpty(s)):
          continue
      
      if (isEmpty(targetServer) and serverList != None and [n,s] not in serverList):
        continue          
          
      workmanagers = AdminConfig.list("WorkManagerInfo",provider).split(SEPARATOR)
      if (isEmpty(workmanagers)): 
        continue
      
      wmId = 0
      wmList = []
      for workmanager in workmanagers:
        if (isEmpty(workmanager)): 
          continue
        
        if (isDefaultWorkManager(workmanager)) :
          continue
          
        wmList.append(workmanager)
      
      if (len(wmList) > 0):
        
          if (prtheader):
             printLine("")
             printLine("#------------------------------------------------------------")  
             printLine("# Work Managers")
             printLine("#------------------------------------------------------------")  
             prtheader = 0
             
          wmProvId = wmProvId + 1
          
          printWorkManagerProviderInfo(provider,c,n,s,dc,app,appdep)
          
          for workmanager in wmList:
              wmId = wmId + 1
              printWorkManager(workmanager)
        
          printLine("app.workmanager.provider.%d.workmanager.count = %d" % (wmProvId, wmId))
          printLine("")
  
  
  printLine("app.workmanager.provider.count = %d" % (wmProvId))



#------------------------------------------------------------------------------------------------------
def dumpMQJMS(pattern=None,targetCluster=None,targetNode=None,targetServer=None,targetCell=None,wildcard="*",serverList=None,membersList=None):
  global jmsProvId
  
  
  
  providers = AdminConfig.list("JMSProvider").split(SEPARATOR)
  if (len(providers) == 0 or providers[0] == ''):
    return
  
  jmsProvId = 0
  
  for provider in providers:
    if (isEmpty(provider)):
      continue
    n = AdminConfig.showAttribute(provider,"name")
    if (n == "WebSphere MQ JMS Provider") :
      c,n,s,dc,app,appdep = getScope(provider)
      scopeid = getScopeId(c,n,s,dc,app,appdep)
      
      
      # See if we match target scope filters
      if (not isEmpty(targetCluster)):
        memberMatch = 0
        if (membersList != None):
          if (not isEmpty(n) and not isEmpty(s)):
            member = (n,s)
            if (member not in membersList):
              continue
            else:
              memberMatch = 1
              
        if (not memberMatch and not checkPossibleWildcardMatch(c, targetCluster, wildcard)):
          continue        
        
      if (not isEmpty(targetNode)):
        if ((targetNode != n)):
          continue
        if (not isEmpty(targetServer)):
          if (targetServer != s):
            continue
        elif (not isEmpty(s)):
          continue
          
      if (not isEmpty(targetCell) and targetCell.lower() == "true"):
        if (not (isEmpty(c) and isEmpty(n) and isEmpty(s))):
          continue
          
      if (isEmpty(targetServer) and serverList != None and [n,s] not in serverList):
        continue          
      
      
      queueConnectionFactories = filterList(AdminConfig.list("MQQueueConnectionFactory",provider).split(SEPARATOR),pattern)
      topicConnectionFactories = filterList(AdminConfig.list("MQTopicConnectionFactory",provider).split(SEPARATOR),pattern)
      genericConnectionFactories = filterList(AdminConfig.list("MQConnectionFactory",provider).split(SEPARATOR),pattern)
      queues = filterList(AdminConfig.list("MQQueue",provider).split(SEPARATOR),pattern)
      topics = filterList(AdminConfig.list("MQTopic",provider).split(SEPARATOR),pattern)
      actspecs = []
      try:
        #wsadminTrace("About to call listWMQActivationSpecs(%s)"% scopeid)
        if (isValidTaskMethod("listWMQActivationSpecs")):
          actspecs = filterList(AdminTask.listWMQActivationSpecs(scopeid).split(SEPARATOR),pattern)
        #wsadminTrace("Back from call listWMQActivationSpecs(%s) = %s"% (scopeid,actspecs))
      except:
        # before v7 or bad scope
        actspecs = []
        
        
      
      printprovider = 0
      if (len(queues) > 0 and queues[0] != ''):
        printprovider = 1
      if (len(queueConnectionFactories) > 0 and queueConnectionFactories[0] != ''):
        printprovider = 1
      if (len(genericConnectionFactories) > 0 and genericConnectionFactories[0] != ''):
        printprovider = 1
      if (len(topics) > 0 and topics[0] != ''):
        printprovider = 1    
      if (len(actspecs) > 0 and actspecs[0] != ''):
        printprovider = 1
        
      if (printprovider == 0):
        # Special case - see if this has the Turn off MQ feature enabled
        propertySetId = AdminConfig.showAttribute(provider,"propertySet")
        if (not isEmpty(propertySetId)):
          rprops = collectResourceProperties(provider,"propertySet","mq")
          if (rprops.get("mq.resourceProperties.prop.com.ibm.ejs.jms.disableWMQSupport")):
            printprovider = 1
      
      if (printprovider) :
        jmsProvId = jmsProvId + 1
        
        
        printJMSProviderInfo(provider,c,n,s,dc,app,appdep)
        
        jmsQueueCFId = 0
        for cf in queueConnectionFactories:
          if (isEmpty(cf)): continue
          jmsQueueCFId = jmsQueueCFId + 1
          prefix = "app.mqjms.provider.%d.queueConnectionFactory.%d" % (jmsProvId, jmsQueueCFId)
          printMQGenericConnectionFactory(prefix,cf)
          
        
        printLine("app.mqjms.provider.%d.queueConnectionFactory.count = %d" % (jmsProvId, jmsQueueCFId))

        topicId = 0
        for cf in topicConnectionFactories:
          if (isEmpty(cf)): continue
          topicId = topicId + 1
          prefix = "app.mqjms.provider.%d.topicConnectionFactory.%d" % (jmsProvId, topicId)
          printMQGenericConnectionFactory(prefix,cf)
        
        printLine("app.mqjms.provider.%d.topicConnectionFactory.count = %d" % (jmsProvId, topicId))

        
        genericId = 0
        for cf in genericConnectionFactories:
          if (isEmpty(cf)): continue
          genericId = genericId + 1
          prefix = "app.mqjms.provider.%d.genericConnectionFactory.%d" % (jmsProvId, genericId)
          printMQGenericConnectionFactory(prefix,cf)
        
        printLine("app.mqjms.provider.%d.genericConnectionFactory.count = %d" % (jmsProvId, genericId))
        
        jmsQueueId = 0
        for queue in queues:
          if (isEmpty(queue)): continue
          jmsQueueId = jmsQueueId + 1
          prefix = "app.mqjms.provider.%d.queue.%d" % (jmsProvId, jmsQueueId)
          printMQQueue(prefix,queue) 
        
        printLine("app.mqjms.provider.%d.queue.count = %d" % (jmsProvId, jmsQueueId))
        
        printLine("")
        
        jmsTopicId = 0
        for topic in topics:
          if (isEmpty(topic)): continue
          jmsTopicId = jmsTopicId + 1
          topicprefix = "app.mqjms.provider.%d.topic.%d" % (jmsProvId, jmsTopicId)
          printMQTopic(topicprefix,topic)
        
        printLine("app.mqjms.provider.%d.topic.count = %d\n" % (jmsProvId, jmsTopicId))
        
        actSpecId = 0
        for actspec in actspecs:
          if (isEmpty(actspec)): continue
          actSpecId = actSpecId + 1
          actspecprefix = "app.mqjms.provider.%d.activationSpec.%d" % (jmsProvId, actSpecId)
          printMQJMSActivateSpec(actspecprefix, actspec)
        
        printLine("app.mqjms.provider.%d.activationSpec.count = %d" % (jmsProvId, actSpecId))
        
        printLine(" ")
        
          
    
  printLine("app.mqjms.provider.count = %d\n" % (jmsProvId))
	
#-----------------------------------------------------------------------------------------------------
def printSIBJMSProviderInfo(provider,prefix,cluster,node,server,pDynCluster="",pApp="",pAppDeployment=""):
    
    
    if (cluster == None):
        cluster = ""
    if (node == None):
        node = ""
    if (server == None):
        server = ""
        
    printLine("%s.cluster = %s" % (prefix,cluster))
    printLine("%s.node = %s" % (prefix,node))
    printLine("%s.server = %s" % (prefix,server))
    
    if (not isEmpty(pDynCluster)):
      printLine("%s.dynamicCluster = %s" % (prefix, pDynCluster))
    
    if (not isEmpty(pApp)):
      printLine("%s.application = %s" % (prefix,pApp))
  
    if (not isEmpty(pAppDeployment)):
      printLine("%s.deployment = %s" % (prefix,pAppDeployment))
    
    
    
    printSimpleProperties(prefix,provider)

#-----------------------------------------------------------------------------------------------------
#def printSIBMJMSQueueConnectionFactories(prefix, qcflist):
#		idx = 0
#		for qcf in qcflist:
#				if (not isEmpty(qcf)):
#						idx = idx + 1
#				
#						qcfdict = wsadminToDictionary(AdminTask.showSIBJMSConnectionFactory(qcf))
#
#						
#						name = qcfdict.get("name","")
#						printLine("%s.queueConnectionFactories.%d.name = %s" % (prefix, idx, name))
#						for key in qcfdict.keys():
#								if (key == "name"):
#										continue
#								val = qcfdict[key]
#								printLine("%s.queueConnectionFactories.%d.prop.%s = %s" % (prefix, idx, key, val))
#		
#		printLine("%s.queueConnectionFactories.count = %d" % (prefix, idx))

#-----------------------------------------------------------------------------------------------------
#def printSIBMJMSTopicConnectionFactories(prefix, tcflist):
#		idx = 0
#		for tcf in tcflist:
#				if (not isEmpty(tcf)):
#						idx = idx + 1
#				
#						tcfdict = wsadminToDictionary(AdminTask.showSIBJMSConnectionFactory(tcf))
#						name = tcfdict.get("name","")
#						printLine("%s.topicConnectionFactories.%d.name = %s" % (prefix, idx, name))
#						for key in tcfdict.keys():
#								if (key == "name"):
#										continue
#								val = tcfdict[key]
#								printLine("%s.topicConnectionFactories.%d.prop.%s = %s" % (prefix, idx, key, val))
#		
#		
#		printLine("%s.topicConnectionFactories.count = %d" % (prefix, idx))

#-----------------------------------------------------------------------------------------------------
#def printSIBMJMSGenericConnectionFactories(prefix, tcflist):
#		
#		idx = 0
#		for tcf in tcflist:
#				if (not isEmpty(tcf)):
#						idx = idx + 1
#				
#						
#						tcfdict = wsadminToDictionary(AdminTask.showSIBJMSConnectionFactory(tcf))
#						
#						name = tcfdict.get("name","")
#						printLine("%s.genericConnectionFactories.%d.name = %s" % (prefix, idx, name))
#						for key in tcfdict.keys():
#								if (key == "name"):
#										continue
#								val = tcfdict[key]
#								printLine("%s.genericConnectionFactories.%d.prop.%s = %s" % (prefix, idx, key, val))
#		
#		
#		printLine("%s.genericConnectionFactories.count = %d" % (prefix, idx))
												
#-----------------------------------------------------------------------------------------------------
def printSIBMJMSConnectionFactories(prefix, tcflist):
		
		idx = 0
		for tcf in tcflist:
				if (not isEmpty(tcf)):
						idx = idx + 1
						if (idx > 1):
								printLine(" ")
						tcfdict = wsadminToDictionary(AdminTask.showSIBJMSConnectionFactory(tcf))
						tprefix = "%s.%d" % (prefix,idx)
						printDictionary(prefix=tprefix,inputDictionary=tcfdict,identifierKeys=["name"],keyMap=None)
						
						try:
						  mapping = AdminConfig.showAttribute(tcf,"mapping")
						  if (not isEmpty(mapping)):
						    printSimpleProperties("%s.%d.mapping.prop" % (prefix,idx), mapping)
						except:
						  pass
						
						cfConnectionPool = AdminConfig.showAttribute(tcf,'connectionPool')
						if (cfConnectionPool != ''):
								printSimpleProperties("%s.%d.connectionPool.prop" % (prefix,idx), cfConnectionPool)
								customProps = wsadminToList(AdminConfig.showAttribute(cfConnectionPool, "properties"))
								pidx = 0
								for propid in customProps:
										if (isEmpty(propid)):
												continue
												
										pname = AdminConfig.showAttribute(propid,"name")
										pval = AdminConfig.showAttribute(propid,"value")
										pdesc = AdminConfig.showAttribute(propid,"description")
										if (isEmpty(pdesc)):
												printLine("%s.%d.connectionPool.customProperties.prop.%s = %s" % (prefix, idx, pname,pval))
										else:
												printLine("%s.%d.connectionPool.customProperties.prop.%s = %s|%s" % (prefix, idx, pname,pval,pdesc))
										
		printLine("%s.count = %d" % (prefix, idx))

#-----------------------------------------------------------------------------------------------------
def printSIBJMSQueues(prefix, queueList):

	idx = 0
	for queue in queueList:
			if (not isEmpty(queue)):
					idx = idx + 1
					if (idx > 1):
							printLine(" ")
					
					queuedict = wsadminToDictionary(AdminTask.showSIBJMSQueue(queue))
					qprefix = "%s.queues.%d" % (prefix,idx)
					printDictionary(prefix=qprefix,inputDictionary=queuedict,identifierKeys=["name"],keyMap=None)

	printLine("%s.queues.count = %d" % (prefix,idx))

#-----------------------------------------------------------------------------------------------------
def printSIBJMSTopics(prefix, topicList):

	idx = 0
	for topic in topicList:
			if (not isEmpty(topic)):
					idx = idx + 1
					if (idx > 1):
							printLine(" ")
					
					topicdict = wsadminToDictionary(AdminTask.showSIBJMSTopic(topic))
					tprefix = "%s.topics.%d" % (prefix,idx)
					printDictionary(prefix=tprefix,inputDictionary=topicdict,identifierKeys=["name"],keyMap=None)
					
	printLine("%s.topics.count = %d" % (prefix,idx))	
				
#-----------------------------------------------------------------------------------------------------
def printSIBJMSActivateSpecs(prefix, actspecList):

  actspecnamemap = { 'wAS_EndpointInitialState': 'WAS_EndpointInitialState' }
  idx = 0
  for actspec in actspecList:
      if (not isEmpty(actspec)):
          idx = idx + 1
          if (idx > 1):
              printLine(" ")
          
          
          actspecdict = wsadminToDictionary(AdminTask.showSIBJMSActivationSpec(actspec))
          
          name = actspecdict.get("name","")
          printLine("%s.activationSpecs.%d.name = %s" % (prefix, idx, name))
          
          sortedkeys = actspecdict.keys()
          sortedkeys.sort()
          for key in sortedkeys:
              if (key == "name"):
                  continue
              val = actspecdict[key]
              
              if (actspecnamemap.has_key(key)):
                #Print alternative key
                key = actspecnamemap.get(key)
              
              printLine("%s.activationSpecs.%d.prop.%s = %s" % (prefix, idx, key, val))   
  
  printLine("%s.activationSpecs.count = %d" % (prefix,idx))  
		
#-----------------------------------------------------------------------------------------------------
#WASX8007I: Detailed help for command group: SIBJMSAdminCommands
#
#Description: A group of commands that help configure SIB JMS connection factories, queues and topics.
#
#Commands:
#createSIBJMSActivationSpec - Create an activation specification in the SIB JMS resource adapter.
#createSIBJMSConnectionFactory - Create a SIB JMS connection factory at the scope identified by the target object.
#createSIBJMSQueue - Create a SIB JMS queue at the scope identified by the target object.
#createSIBJMSTopic - Create a SIB JMS topic at the scope identified by the target object.
#deleteSIBJMSActivationSpec - Delete given SIB JMS activation specification.
#deleteSIBJMSConnectionFactory - Delete the supplied SIB JMS connection factory.
#deleteSIBJMSQueue - Delete the supplied SIB JMS queue.
#deleteSIBJMSTopic - Delete the supplied SIB JMS topic.
#listSIBJMSActivationSpecs - List activation specifications on the SIB JMS resource adapter in given scope.
#listSIBJMSConnectionFactories - List all SIB JMS connection factories of the specified type at the specified scope.
#listSIBJMSQueues - List all SIB JMS queues at the specified scope.
#listSIBJMSTopics - List all SIB JMS topics at the specified scope.
#modifySIBJMSActivationSpec - Modify the attributes of the given SIB JMS activation specification.
#modifySIBJMSConnectionFactory - Modify the attributes of the supplied SIB JMS connection factory using the supplied attribute values.
#modifySIBJMSQueue - Modify the attributes of the supplied SIB JMS queue using the supplied attribute values.
#modifySIBJMSTopic - Modify the attributes of the supplied SIB JMS topic using the supplied attribute values.
#showSIBJMSActivationSpec - Show the attributes of target SIB JMS activation specification.
#showSIBJMSConnectionFactory - Return a list containing the SIB JMS connection factory's attribute names and values.
#showSIBJMSQueue - Return a list containing the SIB JMS queue's attribute names and values.
#showSIBJMSTopic - Return a list containing the SIB JMS topic's attribute names and values.

def dumpSIBJMS(pattern=None,targetCluster=None,targetNode=None,targetServer=None,targetCell=None,wildcard="*",serverList=None,membersList=None):
    
    
    providers = AdminConfig.list("J2CResourceAdapter").split(SEPARATOR)
    if (len(providers) == 0 or providers[0] == ''):
        return

    printLine("\n#---------------------------------------------------------------------------------")
    printLine("# SIBus JMS Resource Definitions")
    printLine("#---------------------------------------------------------------------------------")
    
    sibjmsId = 0
    for provider in providers:
        if (isEmpty(provider)):
            continue
            
        name = AdminConfig.showAttribute(provider,"name")
        if (name != "SIB JMS Resource Adapter"):
            continue
            
        c,n,s,dc,app,appdep = getScope(provider)
        scopeid = getScopeId(c,n,s,dc,app,appdep)
        
        #print "c:%s n:%s s:%s dc:%s app:%s appdep:%s scope:%s name:%s" % (c,n,s,dc,app,appdep,scopeid,name)
        
        if (not isEmpty(targetCluster)):
          memberMatch = 0
          if (membersList != None):
            if (not isEmpty(n) and not isEmpty(s)):
              member = (n,s)
              if (member not in membersList):
                continue
              else:
                memberMatch = 1
                
          if (not memberMatch and not checkPossibleWildcardMatch(c, targetCluster, wildcard)):
            continue
        
        if (not isEmpty(targetNode)):
          if ((targetNode != n)):
            continue
            
          if (not isEmpty(targetServer)):
            if (targetServer != s):
              continue
          elif (not isEmpty(s)):
            continue
        
        
        if (not isEmpty(targetCell) and targetCell.lower() == "true"):
          if (not (isEmpty(c) and isEmpty(n) and isEmpty(s))):
            continue

        if (isEmpty(targetServer) and serverList != None and [n,s] not in serverList):
          continue
            
        
        # See if there are entities defined at this scope
        
        
        connectionFactories = filterList(AdminTask.listSIBJMSConnectionFactories(scopeid).split(SEPARATOR),pattern)
        queueConnectionFactories = filterList(AdminTask.listSIBJMSConnectionFactories(scopeid, "-type queue").split(SEPARATOR),pattern)
        topicConnectionFactories = filterList(AdminTask.listSIBJMSConnectionFactories(scopeid, "-type topic").split(SEPARATOR),pattern)
        
        topics = filterList(AdminTask.listSIBJMSTopics(scopeid).split(SEPARATOR),pattern)
        queues = filterList(AdminTask.listSIBJMSQueues(scopeid).split(SEPARATOR),pattern)
        
        actspecs = filterList(AdminTask.listSIBJMSActivationSpecs(scopeid).split(SEPARATOR),pattern)
        
        printProvider = 0
        if (len(connectionFactories) > 0 and connectionFactories[0] != ''):
            printProvider = 1
        if (len(queueConnectionFactories) > 0 and queueConnectionFactories[0] != ''):
            printProvider = 1
        if (len(topicConnectionFactories) > 0 and topicConnectionFactories[0] != ''):
            printProvider = 1
        if (len(topics) > 0 and topics[0] != ''):
            printProvider = 1
        if (len(queues) > 0 and queues[0] != ''):
            printProvider = 1
        if (len(actspecs) > 0 and actspecs[0] != ''):
            printProvider = 1
            
        if (printProvider):
            sibjmsId = sibjmsId + 1
            
            if (sibjmsId > 1):
                printLine(" ")
            
            prefix = "app.sibjms.provider.%d" % sibjmsId
            printSIBJMSProviderInfo(provider,prefix,c,n,s,dc,app,appdep)
            
            printSIBMJMSConnectionFactories("%s.genericConnectionFactories" % prefix, connectionFactories)
            printLine(" ")
            printSIBMJMSConnectionFactories("%s.queueConnectionFactories" % prefix, queueConnectionFactories)
            printLine(" ")
            printSIBMJMSConnectionFactories("%s.topicConnectionFactories" % prefix, topicConnectionFactories)
            printLine(" ")
            printSIBJMSQueues(prefix, queues)
            printLine(" ")
            printSIBJMSTopics(prefix, topics)
            printLine(" ")
            printSIBJMSActivateSpecs(prefix, actspecs)
            
    #endfor each provider
    
    printLine("app.sibjms.provider.count =  %d\n" % sibjmsId)
        

def dumpSingleConnectionFactoryForGenericJMS(gfid, prefix,parmMap=None):
  try:
      cfname = AdminConfig.showAttribute(gfid,"name")
      printLine("%s.name = %s" % (prefix,cfname))
      printSimpleProperties("%s.prop" % (prefix), gfid, ["name"])
      
      cfConnectionPool = AdminConfig.showAttribute(gfid,'connectionPool')
      if (cfConnectionPool != ''):
        printSimpleProperties("%s.connectionPool.prop" % (prefix), cfConnectionPool)
        printCustomProperties("%s.connectionPool.customProperties" % (prefix), cfConnectionPool, "properties")
        
      cfMappingModules = AdminConfig.list('MappingModule',gfid).split(SEPARATOR)
      if (len(cfMappingModules) > 0 and cfMappingModules[0] != ''):
        printProperties("%s.mapping.prop" % (prefix), cfMappingModules[0])
        
        
      cfSessionPool = AdminConfig.showAttribute(gfid,'sessionPool')
      if (cfSessionPool != ''):
        printSimpleProperties("%s.sessionPool.prop" % (prefix), cfSessionPool)
      
      printCustomProperties("%s.customProperties" % (prefix), gfid, "properties")
      
      dumpResourceProperties(gfid,"propertySet","%s.propertySet" % (prefix))
      
      connTestId = AdminConfig.showAttribute(gfid,"preTestConfig")
      if (not isEmpty(connTestId)):
        printSimpleProperties("%s.preTestConfig.prop" % (prefix), connTestId)
    
    
  except:
    _app_message("Unexpected error in dumpSingleConnectionFactoryForGenericJMS","exception")
    raise
    
def dumpConnectionFactoriesForGenericJMS(jmsprovider,prefix,parmMap=None):
  try:
    factoryList = AdminConfig.list("GenericJMSConnectionFactory",jmsprovider).splitlines()
    genericCFList = []
    queueCFList = []
    topicCFList = []
    
    for factoryId in factoryList:
      if (factoryId):
        factoryType = AdminConfig.showAttribute(factoryId,"type")
        if (factoryType == "QUEUE"):
          queueCFList.append(factoryId)
        elif (factoryType == "TOPIC"):
          topicCFList.append(factoryId)
        else:
          genericCFList.append(factoryId)
        
    fidx = 0
    for gfid in genericCFList:
      fidx += 1
      dumpSingleConnectionFactoryForGenericJMS(gfid, "%s.genericConnectionFactories.%d" % (prefix,fidx),parmMap)

    fidx = 0
    for gfid in queueCFList:
      fidx += 1
      dumpSingleConnectionFactoryForGenericJMS(gfid, "%s.queueConnectionFactories.%d" % (prefix,fidx),parmMap)

    fidx = 0
    for gfid in topicCFList:
      fidx += 1
      dumpSingleConnectionFactoryForGenericJMS(gfid, "%s.topicConnectionFactories.%d" % (prefix,fidx),parmMap)
        
    
  except:
    _app_message("Unexpected error in dumpConnectionFactoriesForGenericJMS","exception")
    raise


def dumpSingleDestinationForGenericJMS(destinationId,prefix,parmMap=None):
  try:
    destinationName = AdminConfig.showAttribute(destinationId,"name")
    
    printLine("%s.name = %s" % (prefix,destinationName))
    printSimpleProperties("%s.prop" % prefix,destinationId, ["name"])
    dumpResourceProperties(destinationId,"propertySet","%s.propertySet" % (prefix))
    
  except:
    _app_message("Unexpected error in dumpSingleDestinationForGenericJMS","exception")

def dumpDestinationsForGenericJMS(jmsprovider, prefix, parmMap=None):
  try:
    queueList = []
    topicList = []
    destinationList = AdminConfig.list("GenericJMSDestination",jmsprovider).splitlines()
    for destinationId in destinationList:
      if (destinationId):
        dtype = AdminConfig.showAttribute(destinationId,"type")
        if (dtype == "QUEUE"):
          queueList.append(destinationId)
        else:
          topicList.append(destinationId)
    
    qidx = 0
    for queueId in queueList:
      qidx += 1
      dumpSingleDestinationForGenericJMS(queueId,"%s.queues.%d" % (prefix,qidx),parmMap)

    tidx = 0
    for topicId in topicList:
      tidx += 1
      dumpSingleDestinationForGenericJMS(topicId,"%s.topics.%d" % (prefix,tidx),parmMap)
                
  except:
    _app_message("Unexpected error in dumDestinationsForGenericJMS","exception")

#-----------------------------------------------------------------
# dumpGenericJMS
#-----------------------------------------------------------------				
def dumpGenericJMS(pattern="",targetCluster="",targetNode="",targetServer="",targetCell="",parmMap=None,serverList=None):
  try:
    prtheader = 1
    
    if (parmMap == None):
      parmMap = {}
    
    wildcard = parmMap.get("wildcard","*")
    
    jmsproviders = AdminConfig.list("JMSProvider").splitlines()
    
    
    providerIdx = 0
    for jmsprovider in jmsproviders:
      if (not jmsprovider):
        #Empty string
        continue
      
      tempString = jmsprovider
      if (tempString.startswith('"') or tempString.startswith("'")):
        tempString = tempString[1:-1]
      if (tempString.startswith("WebSphere JMS Provider(") or tempString.startswith("WebSphere MQ JMS Provider(")):
        continue
      
      providerName = AdminConfig.showAttribute(jmsprovider,"name")
          
      c,n,s,dc,app,appdep = getScope(jmsprovider)
      scopeid = getScopeId(c,n,s,dc,app,appdep)
      
      if (not resourceMatchArgs(c,n,s,targetCluster,targetNode,targetServer,targetCell,wildcard,resourceName=providerName,namePattern=pattern,serverList=serverList)):
        continue
        
      
      if (prtheader):
        prtheader = 0
        printLine("")
        printLine("#-------------------------------------------------------------------------------")
        printLine("# Generic JMS Providers")
        printLine("#-------------------------------------------------------------------------------")
      else:
        printLine("")
        
      providerIdx +=1 
      
      prefix = "app.genericjms.provider.%d" % providerIdx
      
      printLine("%s.cluster = %s" % (prefix,c))
      printLine("%s.node = %s" % (prefix,n))
      printLine("%s.server = %s" % (prefix,s))
      
      if (not isEmpty(dc)):
        printLine("%s.dynamicCluster = %s" % (prefix,dc))
      
      if (not isEmpty(app)):
        printLine("%s.application = %s" % (prefix,app))
      
      if (not isEmpty(appdep)):
        printLine("%s.deployment = %s" % (prefix,appdep))
      
      printLine("%s.name = %s" % (prefix, providerName))  
      
      printSimpleProperties("%s.prop" % prefix, jmsprovider, ["name"])
      dumpResourceProperties(jmsprovider,"propertySet","%s.propertySet" % prefix)
      
      dumpConnectionFactoriesForGenericJMS(jmsprovider,prefix,parmMap)
      dumpDestinationsForGenericJMS(jmsprovider, prefix, parmMap)
    
    if (providerIdx > 0):
      printLine("\napp.genericjms.provider.count = %d" % providerIdx)
      

        
      
      
      
      
  except:
    _app_message("Unexpected error in dumpGenericJMS","exception")
    
    
#-------------------------------------------------------------------------------
# dumpResoruceEnvironmentProviders
#-------------------------------------------------------------------------------
def dumpResourceEnvironmentProviders(pattern="",targetCluster="",targetNode="",targetServer="",targetCell="",wildcard="*",parmMap=None,serverList=None,membersList=None):
  
  if not isValidType("ResourceEnvironmentProvider"):
    return
    
  try:
    providerIdx = 0
    prtheader = 1
    
    if (parmMap == None):
      parmMap = {}
    
    providers = listResourceCandidatesAtScope("ResourceEnvironmentProvider",targetCluster,targetNode,targetServer,targetCell,wildcard="*",serverList=None,membersList=membersList)
    for provider in providers:
      if (isEmpty(provider)):
        continue  
      c,n,s,dc,app,appdep = getScope(provider)
      
      providerName = AdminConfig.showAttribute(provider,"name")
      
      if (not resourceMatchArgs(c,n,s,targetCluster,targetNode,targetServer,targetCell,wildcard,resourceName=providerName,namePattern=pattern,serverList=serverList,membersList=membersList)):
        continue
      
      if (prtheader):
        printLine("\n#----------------------------------------------")
        printLine("# Resource Environment Providers")
        printLine("#----------------------------------------------")
        prtheader = 0
      
      printLine("")
      providerIdx += 1
      
      prefix = "app.resourceEnvProvider.%d" % providerIdx
      printScopeLines(prefix,c,n,s,dc,app,appdep)
      printLine("%s.name = %s" % (prefix,providerName))
      printSimpleProperties("%s.prop"%prefix, provider, ["name"], printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,printListChildren=1,printChildType=1,useAttrNameWithProperties=1,includeBlanks = 1)
      
      entries = AdminConfig.list("ResourceEnvEntry",provider).splitlines()
      eidx = 0
      for ree in entries:
        if (isEmpty(ree)):
          continue
        eidx += 1
        eprefix = "%s.entries.%d" % (prefix,eidx)
        entryName = splitOffName(ree)
        printLine("%s.name = %s" % (eprefix,entryName))
        printSimpleProperties("%s.prop"%eprefix, ree, ["name"], printSimpleChildren=1,childrenSkipList=["provider"],includeReferenceChildren=1,
                          printPropertyAttributes=1,printListChildren=1,printChildType=1,useAttrNameWithProperties=1,includeBlanks = 1) 
      if (eidx > 0):
        printLine("\n%s.entries.count = %d" % (prefix,eidx))
    
    if (providerIdx > 0):
      printLine("app.resourceEnvProvider.count = %d\n" % providerIdx)
         
        
      
  except:
    _app_message("Unexpected error in dumpResourceEnvironmentProviders","exception")    
          
#-------------------------------------------------------------------------------
# dumpURL
#-------------------------------------------------------------------------------
def dumpURL(pattern="",targetCluster="",targetNode="",targetServer="",targetCell="",wildcard="*",parmMap=None,serverList=None,membersList=None):
  try:
    providerIdx = 0
    prtheader = 1
    
    if (parmMap == None):
      parmMap = {}
    
    urlproviders = []
    urls = listResourceCandidatesAtScope("URL",targetCluster,targetNode,targetServer,targetCell,wildcard="*",serverList=None,membersList=membersList)
    for url in urls:
      c,n,s,dc,app,appdep = getScope(url)
      tempProviders = getObjectsAtScope("URLProvider:/",c,n,s,dc,app,appdep)
      for tprovider in tempProviders:
        if (tprovider not in urlproviders):
          urlproviders.append(tprovider)
    
    urlproviders.sort()
      
      
    for urlprovider in urlproviders:
    
      if (isEmpty(urlprovider)):
        #Empty string
        continue
      
     
      providerName = AdminConfig.showAttribute(urlprovider,"name")
          
      c,n,s,dc,app,appdep = getScope(urlprovider)
      scopeid = getScopeId(c,n,s,dc,app,appdep)
      
      if (not resourceMatchArgs(c,n,s,targetCluster,targetNode,targetServer,targetCell,wildcard,resourceName=providerName,namePattern=pattern,serverList=serverList,membersList=membersList)):
        continue
      
      if (prtheader):
        prtheader = 0
        printLine("")
        printLine("#-------------------------------------")
        printLine("# URL")
        printLine("#-------------------------------------")
      
      providerIdx += 1
      printLine("")
      printScopeLines("app.url.provider.%d" % (providerIdx),c,n,s,dc,app,appdep)
      printLine("")
      printLine("app.url.provider.%d.name = %s" % (providerIdx,providerName))
      printSimpleProperties("app.url.provider.%d.prop" % providerIdx, urlprovider, ["name"], printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1)
                          
      urls = AdminConfig.list("URL",urlprovider).splitlines()
      urlIdx = 0
      for url in urls:
        if (isEmpty(url)):
          continue
        urlIdx += 1
        printLine("")
        urlName = AdminConfig.showAttribute(url,"name")
        printLine("app.url.provider.%d.url.%d.name = %s" % (providerIdx,urlIdx,urlName))
        printSimpleProperties("app.url.provider.%d.url.%d.prop" % (providerIdx,urlIdx), url, ["name"], printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1)
      
      if (urlIdx > 0):
        printLine("")
        printLine("app.url.provider.%d.url.count = %d" % (providerIdx,urlIdx))
        
    
    if (providerIdx > 0):
      printLine("app.url.provider.count = %d" % providerIdx)
      
      
  except:
    _app_message("Unexpected error in dumpURL","exception")
    raise
          
#------------------------------------------------------------------------------------------------------------------
# dumpMail
#------------------------------------------------------------------------------------------------------------------ 
def dumpMail(pattern="",targetCluster="",targetNode="",targetServer="",targetCell="",wildcard="*",parmMap=None,serverList=None,membersList=None):
  try:
    providerIdx = 0
    prtheader = 1
    
    if (parmMap == None):
      parmMap = {}
    
    mailproviders = []
    mailSessions = listResourceCandidatesAtScope("MailSession",targetCluster,targetNode,targetServer,targetCell,wildcard="*",serverList=None,membersList=membersList)
    for mailSession in mailSessions:
      c,n,s,dc,app,appdep = getScope(mailSession)
      tempProviders = getObjectsAtScope("MailProvider:/",c,n,s,dc,app,appdep)
      for tprovider in tempProviders:
        if (tprovider not in mailproviders):
          mailproviders.append(tprovider)
    
    mailproviders.sort()
      
      
    for mailprovider in mailproviders:
    
      if (isEmpty(mailprovider)):
        #Empty string
        continue
      
     
      providerName = AdminConfig.showAttribute(mailprovider,"name")
          
      c,n,s,dc,app,appdep = getScope(mailprovider)
      scopeid = getScopeId(c,n,s,dc,app,appdep)
      
      if (not resourceMatchArgs(c,n,s,targetCluster,targetNode,targetServer,targetCell,wildcard,resourceName=providerName,namePattern=pattern,serverList=serverList,membersList=membersList)):
        continue
      
      if (prtheader):
        prtheader = 0
        printLine("")
        printLine("#-------------------------------------")
        printLine("# MailProvider")
        printLine("#-------------------------------------")
      
      providerIdx += 1
      printLine("")
      printScopeLines("app.mail.provider.%d" % (providerIdx),c,n,s,dc,app,appdep)
      printLine("")
      printLine("app.mail.provider.%d.name = %s" % (providerIdx,providerName))
      printSimpleProperties("app.mail.provider.%d.prop" % providerIdx, mailprovider, ["name"], printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1)
      
      protocolProviders = wsadminToList(AdminConfig.showAttribute(mailprovider,"protocolProviders"))
      ppidx = 0
      for pp in protocolProviders:
        if (isEmpty(pp)):
          continue
        ppidx += 1
        printSimpleProperties("app.mail.provider.%d.protocolProviders.%d.prop" % (providerIdx,ppidx),pp)
                          
      sessions = AdminConfig.list("MailSession",mailprovider).splitlines()
      sessionIdx = 0
      for session in sessions:
        if (isEmpty(session)):
          continue
        sessionIdx += 1
        printLine("")
        sessionName = AdminConfig.showAttribute(session,"name")
        printLine("app.mail.provider.%d.mailsession.%d.name = %s" % (providerIdx,sessionIdx,sessionName))
        printSimpleProperties("app.mail.provider.%d.mailsession.%d.prop" % (providerIdx,sessionIdx), session, ["name","provider"], printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,includeReferenceChildren=1)
        
        
      
      if (sessionIdx > 0):
        printLine("")
        printLine("app.mail.provider.%d.mailsession.count = %d" % (providerIdx,sessionIdx))
        
    
    if (providerIdx > 0):
      printLine("app.mail.provider.count = %d" % providerIdx)
      
      
  except:
    _app_message("Unexpected error in dumpMail","exception")
    raise
          
  
  		

#------------------------------------------------------------------------------------------------------
def dumpJdbc(pattern=None,targetCluster=None,targetNode=None,targetServer=None,targetCell=None,wildcard="*",serverList=None,parmMap=None,membersList=None,inputProviderList=None):
  global provId
  global dsId
  
  # Some parameters may have been only passed in the parmMap
  # dependin on how this function was called.
  if (parmMap!= None):
    if (pattern==None):
      pattern=parmMap.get("-pattern")
    if (parmMap.has_key("-wildcard")):
      wildcard=parmMap.get("-wildcard")
    if (targetCluster==None):
      targetCluster = parmMap.get("-targetcluster")
    if (targetNode == None):
      targetNode = parmMap.get("-targetnode")
    if (targetServer == None):
      targetServer = parmMap.get("-targetnode")
    if (targetCell==None):
      targetCell = parmMap.get("-targetCell")
      
  
  providers = None
  if (inputProviderList != None):
    providers = inputProviderList
  else:
    providers = AdminConfig.list("JDBCProvider").split(SEPARATOR)

  if (providers[0] == ''): return
    
  if (parmMap == None):
    parmMap = {}
    
  printLine("\n#--------------------------------------------------------------------------------------")
  printLine("# JDBC Providers and Data Sources")
  printLine("#--------------------------------------------------------------------------------------")
  targetProvider = parmMap.get("-targetprovider",None)
  
  filterSettings = getFilterSettings(parmMap)
  
  for provider in providers: 
    pn = splitOffName(provider)
    
    if (pn.startswith("Cloudscape")): continue
    if (pn.startswith("Derby")): continue
    c,n,s,dc,app,appdep = getScope(provider)
    
    
    if (not isEmpty(targetProvider)):
      if (not checkPossibleWildcardMatch(pn,targetProvider,wildcard)):
        continue
    
    # See if we match target scope filters
    if (not isEmpty(targetCluster)):
      memberMatch = 0
      if (membersList != None):
        if (not isEmpty(n) and not isEmpty(s)):
          member = (n,s)
          if (member not in membersList):
            continue
          else:
            memberMatch = 1
            
      if (not memberMatch and not checkPossibleWildcardMatch(c, targetCluster, wildcard)):
        continue
        
    if (not isEmpty(targetNode)):
      if ((targetNode != n)):
        continue
      if (not isEmpty(targetServer)):
        if (targetServer != s):
          continue
      elif (not isEmpty(s)):
        continue
            
    if (not isEmpty(targetCell) and targetCell.lower() == "true"):
        if (not (isEmpty(c) and isEmpty(n) and isEmpty(s))):
          continue
          
    if (isEmpty(targetServer) and serverList != None and [n,s] not in serverList):
      continue
    
    dss = filterList(AdminConfig.list("DataSource", provider).split(SEPARATOR),pattern)
    if ((not isEmpty(dss) and len(dss) > 0) or (inputProviderList != None)):
      
      provId = provId + 1
  
      printProviderInfo(provider,c,n,s,dc,app,appdep,parmMap=parmMap)   
    
      dsId = 0
      for ds in dss: 
        if (isEmpty(ds)): continue
        dsId = dsId + 1
        printDataSourceInfo(ds,parmMap=parmMap)   
     
      printLine("app.jdbc.provider.%d.ds.count = %d" % (provId, dsId))
      printLine(" ")
    #endif data sources
    
    if (filterSettings.get("WAS40DataSource",1)):
      was4ds = filterList(AdminConfig.list("WAS40DataSource",provider).splitlines(),pattern)
      if (not isEmpty(was4ds) and len(was4ds) > 0):
        dsId = 0
        for ds in was4ds:
          if (isEmpty(ds)): 
            continue
          dsId +=1
          dsPrefix = "app.jdbc.provider.%d.was40ds.%d" % (provId,dsId)
          dsName = AdminConfig.showAttribute(ds,"name")
          printLine("")
          printLine("%s.name = %s" % (dsPrefix,dsName))
          printSimpleProperties("%s.prop"%dsPrefix,ds, optionalSkipList=["name"],includeBlanks=0,printSimpleChildren=1,childrenSkipList=None,
                            printPropertyAttributes=1,useAttrNameWithProperties=1)
          
        printLine("")
        printLine("app.jdbc.provider.%d.was40ds.count = %d" % (provId,dsId))
        printLine("")
        
        
        
   
  printLine("app.jdbc.provider.count = %d" % (provId))
  printLine(" ")
   
   
#------------------------------------------------------------------------------------------------------
def printVariables(entryList, cluster, node, server):
	global id
	prefix="app.wasenv"

	printHeader = 1
	
	
	if (len(entryList) == 1 and isEmpty(entryList[0])):
			printHeader = 0
	elif (len(entryList) == 0):
			printHeader = 0
			
	if (printHeader):
			printLine(" ")
			printLine("#")
			if (not isEmpty(cluster)):
					printLine("# WebSphere Variables defined at cluster scope: %s" % cluster)
			elif (not isEmpty(server)):
					printLine("# WebSphere Variables defined at server scope: %s on node %s" % (server, node))
			elif (not isEmpty(node)):
					printLine("# WebSphere Variables defined at node scope: %s" % (node))
			else:
					printLine("# WebSphere Variables defined at cell scope")
			printLine("#")
			printLine(" ")
	
	vardict = {}
	for cellEntry in entryList:
		if (not isEmpty(cellEntry)):
			
			props = {}
			collectSimpleProperties(props, "var",cellEntry)
			varName = props.get("var.symbolicName","")
			varVal = props.get("var.value","")
			varDesc = props.get("var.description","")
			
			#varName = AdminConfig.showAttribute(cellEntry, "symbolicName")
			#varVal = AdminConfig.showAttribute(cellEntry, "value")
			#varDesc = AdminConfig.showAttribute(cellEntry, "description")
			
			if (isEmpty(varDesc)):
			  vardict[varName] = varVal
			else:
			  vardict[varName] = "%s | %s" % (varVal,varDesc)
			  
	sortedkeys = vardict.keys()
	sortedkeys.sort()
	
	for key in sortedkeys:
			id = id + 1
			printLine("%s.%d.cluster = %s" % (prefix, id, cluster))
			printLine("%s.%d.node    = %s" % (prefix, id, node))
			printLine("%s.%d.server  = %s" % (prefix, id, server))
			if (isEmpty(varDesc)):
					varDesc = " " 
			printLine("%s.%d.env.prop.%s = %s" % (prefix, id, key, vardict[key]))
			printLine(" ")
			
#------------------------------------------------------------------------------------------------------
# @JJM - Keeping this around - although now using better formatted function below
def dumpWebServersOriginal():
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# WebServers Section")
	printLine("#")
	printLine("#------------------------------------------------------------------------------")
	printLine(" ")

	countId = 0

	prefix = "app.webServer"
	execId = AdminConfig.list("WebServer").split(SEPARATOR)

	for p in execId:
		countId = countId + 1
		#printLine("%s.%d.name = %s" % (prefix, countId, AdminConfig.showAttribute(p,"name")))
 		printProperties("%s.%d" % (prefix,countId) ,p)
		printLine(" ")
	printLine("%s.count = %d" % (prefix, countId))
	printLine(" ")


def dumpNodeGroups(**parmMap):
  try:
    if ("listNodeGroups" in getTaskMethods()):
      nodeGroups = AdminTask.listNodeGroups().splitlines()
      ngidx = 0
      for ng in nodeGroups:
        if (isEmpty(ng)):
          continue
        
        ngid = AdminConfig.getid("/NodeGroup:%s/"% ng)
        if (isEmpty(ngid)):
          continue
        ngidx += 1
        if (ngidx == 1):
          printLine("\n#------------\n# Node groups\n#------------")
          
        prefix = "app.nodegroups.%d" % ngidx
        
        printLine("%s.name = %s" % (prefix,ng))
        printSimpleProperties("%s.prop" % prefix,ngid, optionalSkipList=["name"],includeBlanks=0,printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,useAttrNameWithProperties=1,includeReferenceChildren=0,printListChildren=1,
                          printChildType=1)
      if (ngidx > 0):
        printLine("app.nodegroups.count = %s" % ngidx)
          
      
  except:
    _app_message("Unexpected error in dumpNodeGroups","exception")

#----------------------------------------------------------------------------------------------
# dumpManagedNodes
#----------------------------------------------------------------------------------------------
def dumpManagedNodes(parmMap=None):
  try:
    printLine(" ")
    printLine("#------------------------------------------------------------------------------")
    printLine("# Managed nodes")
    printLine("#")
    printLine("#------------------------------------------------------------------------------")
    printLine(" ")
    
    doServers = 0
    if (parmMap != None and parmMap.get("-includeservers","false") != "false"):
      doServers = 1
      
    nodeList = AdminTask.listManagedNodes().splitlines()
    
    nodeList.sort()
    dmgrNode = ""
    try:
      dmgrNode = AdminControl.getNode()
    except:
      dmgr = AdminConfig.getid("/Server:dmgr/")
      if (not isEmpty(dmgr)):
        dmgrNode = getNodeNameForServer(dmgr)
      
    if (not isEmpty(dmgrNode) and (dmgrNode not in nodeList)):
      # Put dmgr first
      tempList = [dmgrNode]
      tempList.extend(nodeList)
      nodeList = tempList
      
    nodeidx = 0
    for nodeName in nodeList:
      if (not isEmpty(nodeName)):
          nodeid = AdminConfig.getid("/Node:%s/"%nodeName)
          if (not isEmpty(nodeid)):
            nodeidx = nodeidx + 1
            if (nodeidx > 1):
              printLine("")
            prefix = "app.managednode.%d" % nodeidx
          
            nodeid = AdminConfig.getid("/Node:%s/"%nodeName)
            
            printLine("%s.nodeName = %s" % (prefix, nodeName))
            printSimpleProperties("%s.prop"%prefix,nodeid,["name"])
            
            
            result = AdminTask.getMetadataProperties(['-nodeName', nodeName])
            nodedict = wsadminToDictionary(result)
            for key in nodedict.keys():
              printLine("%s.metadata.prop.%s = %s" % (prefix,key,nodedict.get(key)))
            
            if (doServers):
              dumpServersOnNode(prefix,nodeid)
  
    printLine("\napp.managednode.count = %d" % (nodeidx))    
  except:
    _app_message("Unexpected error in dumpManagedNodes()","exception")

#---------------------------------------------------------------------
#dumpServersOnNode
#---------------------------------------------------------------------
def dumpServersOnNode(prefix,nodeid):
  try:
    serverList = AdminConfig.list("Server",nodeid).splitlines()
    serverList.sort()
    sidx = 0
    for server in serverList:
      if (isEmpty(server)):
        continue
      sidx = sidx +1
      sprops = {}
      collectSimpleProperties(sprops, "prop",server)
      printLine("%s.servers.%d.name = %s" % (prefix,sidx,sprops.get("prop.name","")))
      
      keylist = []
      for key in sprops.keys():
        keylist.append(key)
      keylist.sort()
      for key in keylist:
        if (key == "prop.name"):continue
        printLine("%s.servers.%d.%s = %s" % (prefix,sidx,key,sprops.get(key)))
    
    printLine("%s.servers.count = %d" % (prefix,sidx))
      
  except:
    _app_message("Unexpected error in dumServersOnNode","exception")
    
#------------------------------------------------------------------------------------------------------
def dumpUnmanagedNodes(parmMap=None):
  printLine(" ")
  printLine("#------------------------------------------------------------------------------")
  printLine("# Unmanaged nodes")
  printLine("#")
  printLine("# Valid OS values are: os400 aix hpux linux solaris windows and os390          ")
  printLine("#------------------------------------------------------------------------------")
  printLine(" ")
  
  doServers = 0
  if (parmMap != None and parmMap.get("-includeservers","false") != "false"):
    doServers = 1
  
  nodeList = wsadminToList(AdminTask.listUnmanagedNodes())
  nodeList.sort()
  nodeidx = 0
  for nodeName in nodeList:
    if (not isEmpty(nodeName)):
        nodeid = AdminConfig.getid("/Node:%s/"%nodeName)
        if (not isEmpty(nodeid)):
          nodeidx = nodeidx + 1
        
          prefix = "app.unmanagednode.%d" % nodeidx
        
          nodeid = AdminConfig.getid("/Node:%s/"%nodeName)
          
          printLine("%s.nodeName = %s" % (prefix, nodeName))
          hostName = AdminConfig.showAttribute(nodeid,"hostName")
          printLine("%s.hostName = %s" % (prefix, hostName))
          
          nodeos = ""
          result = AdminTask.getMetadataProperties(['-nodeName', nodeName])
          nodedict = wsadminToDictionary(result)
          nodeos = nodedict.get("com.ibm.websphere.nodeOperatingSystem","")
          printLine("%s.nodeOperatingSystem = %s" % (prefix,nodeos))
          for key in nodedict.keys():
            printLine("%s.metadata.prop.%s = %s" % (prefix,key,nodedict.get(key)))
          
          if (doServers):
            dumpServersOnNode(prefix,nodeid)

  
  printLine("app.unmanagednode.count = %d" % (nodeidx))
        

	
#------------------------------------------------------------------------------------------------------
def dumpWebServers(parmMap=None,inputWebServerList=None):
  printLine(" ")
  printLine("#------------------------------------------------------------------------------")
  printLine("# WebServers Section - New format")
  printLine("#")
  printLine("#------------------------------------------------------------------------------")
  printLine(" ")

  countId = 0
  
  targetServer = None
  targetNode = None
  targetServerType = None
  
  printId = 0
  
  if (parmMap != None):
    targetServer = parmMap.get("-targetserver",None)
    targetNode = parmMap.get("-targetnode",None)
    targetServerType = parmMap.get("-targetservertype",None)
    printId = parmMap.get("-printid",0)
    
  prefix = "app.webServer"
  webServerList = None
  
  if (inputWebServerList == None):
    webServerList = AdminConfig.list("WebServer").split(SEPARATOR)
  else:
    webServerList = inputWebServerList

  for p in webServerList:
    if (isEmpty(p)):
        continue
      
    serverval = AdminConfig.showAttribute(p,"server")

    servername = AdminConfig.showAttribute(serverval,"name")
    nodeName = getNodeNameForServer(serverval)
    
    # Do any filtering of the server list based on options
    if (targetServer != None and targetServer != servername):
      continue
    if (targetNode != None and targetNone != nodeName):
      continue
    if (targetServerType != None and targetServerType != AdminConfig.showAttribute(p,"webserverType")):
      continue  
    
    countId = countId + 1  
    
    webPort, adminPort = getWebServerPortInfo(nodeName,servername)
    
    
    if (printId):
      printLine("# Server Source ID: %s" % serverval)
      printLine("# WebServer Source ID: %s" % p)
      
    printLine("%s.%d.name = %s" % (prefix, countId, servername))
    printLine("%s.%d.nodeName = %s" % (prefix, countId, nodeName))
    printLine("%s.%d.webPort = %s" % (prefix, countId, webPort))
    printLine("%s.%d.adminPort = %s" % (prefix, countId, adminPort))
    
    printSimpleProperties("%s.%d.prop" % (prefix,countId) ,p, ["name"])
    
    adminServerAuthenticationId = AdminConfig.showAttribute(p,"adminServerAuthentication")
    if not isEmpty(adminServerAuthenticationId):
        printSimpleProperties("%s.%d.adminServerAuthentication.prop" % (prefix,countId) ,adminServerAuthenticationId)
        
    stateManagementId = AdminConfig.showAttribute(p,"stateManagement")
    if (not isEmpty(stateManagementId)):
        printSimpleProperties("%s.%d.stateManagement.prop" % (prefix, countId), stateManagementId)
    
    # Use standard method/syntax for custom properties
    printCustomProperties("%s.%d.properties"% (prefix,countId), p, attributeName="properties")    
                
    
    processDef = AdminConfig.list("JavaProcessDef",serverval)
    if (not isEmpty(processDef)):
      printSimpleProperties("%s.%d.processDef.prop" % (prefix,countId),processDef,printPropertyAttributes=1,useAttrNameWithProperties=1,printSimpleChildren=1,childrenSkipList=["jvmEntries"])
      #execution = AdminConfig.showAttribute(processDef,"execution")
      #if (not isEmpty(execution)):
      #  printSimpleProperties("%s.%d.processDef.execution.prop" % (prefix,countId),execution)
      
    
    pluginProperties = AdminConfig.list("PluginProperties", p)
    if (not isEmpty(pluginProperties)):
        pluginPropertiesList = wsadminToList(pluginProperties)
        printSimpleProperties("%s.%d.pluginProperties.prop" % (prefix, countId), pluginPropertiesList[0])
        
        pluginServerClusterProperties = AdminConfig.list("PluginServerClusterProperties",pluginPropertiesList[0])
        printSimpleProperties("%s.%d.pluginProperties.pluginServerClusterProperties.prop"  % (prefix, countId) , pluginServerClusterProperties)

        # Use standard method/syntax for custom properties
        printCustomProperties("%s.%d.pluginProperties.properties" % (prefix,countId), pluginProperties, attributeName="properties")    
                    
    dumpWebServerIntelligentManagementSettings(servername,nodeName,"%s.%d" %(prefix,countId))
    
    printLine(" ")
    
  printLine("%s.count = %d" % (prefix, countId))
  printLine(" ")

#-----------------------------------------------------------------
# dumpWebServerIntelligentManagementSettings
# In WAS 8.5.5 and later, dump the WebContainer settings related to 
# intelligent management features of the plug-in
#-----------------------------------------------------------------
def dumpWebServerIntelligentManagementSettings(webserverName,webserverNode,prefix):
  
  if (not isValidTaskMethod("enableIntelligentManagement")):
    return
  
  intelId = None
  try:
    intelId = AdminTask.modifyIntelligentManagement("[ -node %s -webserver %s ]" % (webserverNode,webserverName))
  except:
    #print formatExceptionData("")
    intelId = None
  
  prefix = "%s.intelligentManagement" % prefix
  
  if (intelId == None):
    printLine("%s.prop.enabled = false"%prefix)
    return
  
  nestedIds = {}
  props = {}
  collectSimpleProperties(props, "%s.prop"%prefix,intelId, [],nestedIds)
  
  enabledKey = "%s.prop.enabled" % prefix
  enabledVal = props.get(enabledKey)
  
  printLine("%s = %s" % (enabledKey,props.get(enabledKey,"false")))
  for key in props.keys():
    if (key != enabledKey):
      printLine("%s = %s" % (key,props.get(key)))

  # The connector clusters configuration items give us more details on remote cells than       
  # listRemoteCellsFromIntelligentManagement does
  remoteDict = {}
  connectorClusters = wsadminToList(nestedIds.get("%s.prop.connectorClusters" % prefix,"[]"))
  ccidx = 0
  for connectorClusterId in connectorClusters:
    if (isEmpty(connectorClusterId)):
      continue
    connectorDict = {}
    collectSimpleProperties(connectorDict, "prop", connectorClusterId)
    cellIdentifier = connectorDict.get("prop.cellIdentifier","")
    remoteDict[cellIdentifier] = connectorDict
    
    ccidx += 1
    printLine("%s.connectorClusters.%d.cellIdentifier = %s" % (prefix,ccidx,cellIdentifier))
    printSimpleProperties("%s.connectorClusters.%d.prop" % (prefix,ccidx),connectorClusterId,["cellIdentifier"])
  
  if (ccidx > 0):
    printLine("%s.connectorClusters.count = %d" % (prefix,ccidx))
      
      
  remoteCellList =  AdminTask.listRemoteCellsFromIntelligentManagement('[-node %s -webserver %s ]' % (webserverNode,webserverName)).splitlines()
  remoteCellIdx = 0
  for remoteCell in remoteCellList:
    if (isEmpty(remoteCell)):
      continue
    
    split2 = []
    split1 = remoteCell.split(" ")
    if (len(split1) == 2):
      split2 = split1[1].split(":")
    
    if (len(split2) == 2):
      # Correct format
      remoteCellLabel = split1[0]
      remoteCellHost = split2[0]
      remoteCellPort = split2[1]
      
      connectorClusterProps = remoteDict.get(remoteCellLabel,{})
      
      remoteCellIdx += 1
      printLine("%s.remoteCells.%d.prop.host = %s" % (prefix,remoteCellIdx,remoteCellHost))
      printLine("%s.remoteCells.%d.prop.port = %s" % (prefix,remoteCellIdx,remoteCellPort))      
      printLine("%s.remoteCells.%d.prop.cellIdentifier = %s" % (prefix,remoteCellIdx,remoteCellLabel))
      printLine("%s.remoteCells.%d.prop.enabled = %s" % (prefix,remoteCellIdx,connectorClusterProps.get("prop.enabled","")))
      printLine("%s.remoteCells.%d.imSettings.prop.maxRetries = %s" % (prefix,remoteCellIdx,connectorClusterProps.get("prop.maxRetries","")))
      printLine("%s.remoteCells.%d.imSettings.prop.retryInterval = %s" % (prefix,remoteCellIdx,connectorClusterProps.get("prop.retryInterval","")))
      printLine("# Additional arguments for addRemoteCellToIntelligentManagement")
      printLine("%s.remoteCells.%d.importCertificates = true" % (prefix,remoteCellIdx))
      printLine("%s.remoteCells.%d.userid = " % (prefix,remoteCellIdx))
      printLine("%s.remoteCells.%d.password = " % (prefix,remoteCellIdx))
    
  
    
    
  userDefinedLines = wsadminToList(nestedIds.get("%s.prop.userDefinedLines" % prefix,"[]"))
  udlidx = 0
  for udl in userDefinedLines:
    if (isEmpty(udl)):
      continue
    udlidx += 1
    printSimpleProperties("#%s.userDefinedLines.%d.prop" % (prefix,udlidx),udl)

  # The plugin Properties are stored as individual userDefinedLines
  # with entry = <Property name="webserverName" value="ScriptingCell_ScriptingNode1_IHS1"/>
  for udl in userDefinedLines:
    if (isEmpty(udl)):
      continue
    udlprops = {} 
    collectSimpleProperties(udlprops, "prop",udl, [])
    
    nameval = parsePropertyXML(udlprops.get("prop.entry",""))
    if nameval != None:
      printLine("%s.pluginProperties.prop.%s = %s" % (prefix,nameval[0],nameval[1]))
  
  # Note, could also have used listTraceRulesForIntelligentManagement
  traceSpecs = wsadminToList(nestedIds.get("%s.prop.traceSpecs" % prefix,"[]"))
  traceidx = 0
  defaultTraceProps = None
  otherTraceProps = []
  for traceSpecId in traceSpecs:
    if (isEmpty(traceSpecId)):
      continue
    traceprops = {}
    collectSimpleProperties(traceprops,"prop",traceSpecId,[])
    if (traceprops.get("prop.name","") == "default"):
      defaultTraceProps = traceprops
    elif (not isEmpty(traceprops.get("prop.condition",""))):
      otherTraceProps.append(traceprops)
    else:
      print "Unusual trace spec found: %s" % traceProps
  
  if (defaultTraceProps != None):
    printLine("%s.traceSpecs.default.prop.name = %s" % (prefix,defaultTraceProps.get("prop.name","")))
    printLine("%s.traceSpecs.default.prop.spec = %s" % (prefix,defaultTraceProps.get("prop.spec","")))
    
  if (len(otherTraceProps) > 0):
    traceidx = 0
    for traceProps in otherTraceProps:
      if (len(otherTraceProps) == 1 and not isEmpty(traceProps.get("prop.condition"))):
        # single condition format - looks like this is how it works in 8.5.5 so far
        printLine("%s.traceSpecs.conditional.prop.name = %s" % (prefix,traceProps.get("prop.name","")))
        printLine("%s.traceSpecs.conditional.prop.spec = %s" % (prefix,traceProps.get("prop.spec","")))
        printLine("%s.traceSpecs.conditional.prop.condition = %s" % (prefix,traceProps.get("prop.condition","")))
      else:
        # List format - naming convention implies room for growth
        traceidx += 1
        printLine("%s.traceSpecs.conditional.%d.prop.name = %s" % (prefix,traceidx,traceProps.get("prop.name","")))
        printLine("%s.traceSpecs.conditional.%d.prop.spec = %s" % (prefix,traceidx,traceProps.get("prop.spec","")))
        printLine("%s.traceSpecs.conditional.%d.prop.condition = %s" % (prefix,traceidx,traceProps.get("prop.condition","")))
    
    if (traceidx > 1):
      printLine("%s.traceSpecs.conditional.count = %d" % (prefix,traceidx))
      
      
    
    
    
  
  AdminConfig.reset()

#------------------------------------------------------------------------------------------------------
def dumpVirtualHosts():
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# VirtualHosts Section")
	printLine("#")
	printLine("#------------------------------------------------------------------------------")
	printLine(" ")

	prefix = "app.virtualHosts"
	countId = 0

	execId = AdminConfig.list("VirtualHost").split(SEPARATOR)

	for p in execId:
		countId = countId + 1
		printLine("%s.%d.name = %s" % (prefix, countId, AdminConfig.showAttribute(p,"name")))
		aliases = wsadminToList(AdminConfig.showAttribute(p,"aliases"))
		aliasesId = 0
		for s in aliases:
			aliasesId = aliasesId + 1
			printLine("%s.%d.aliases.prop.%d = %s|%s" % (prefix, countId, aliasesId, AdminConfig.showAttribute(s,"hostname"), AdminConfig.showAttribute(s,"port") ))
	printLine("%s.count = %d" % (prefix, countId))
	printLine(" ")
	
#------------------------------------------------------------------------------------------------------
def dumpReplicationDomain():
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# ReplicationDomain Section")
	printLine("#")
	printLine("#------------------------------------------------------------------------------")
	printLine(" ")

	prefix = "app.replicationDomain"
	countId = 0

	execId = AdminConfig.list("DataReplicationDomain").split(SEPARATOR)

	for p in execId:
		if (isEmpty(p)):
				continue
				
		countId = countId + 1
		printLine("%s.%d.name = %s" % (prefix, countId, AdminConfig.showAttribute(p,"name")))
		ddrs = AdminConfig.showAttribute(p,"defaultDataReplicationSettings")
		if (not isEmpty(ddrs)):
				printSimpleProperties("%s.%d.defaultDataReplicationSettings.prop" % (prefix,countId), ddrs, ["name"])
				printLine(" ")
				
		
	printLine("%s.count = %d" % (prefix, countId))
	printLine(" ")


#------------------------------------------------------------------------------------------------------
def dumpReplicationDomainOld():
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# ReplicationDomain Section")
	printLine("#")
	printLine("#------------------------------------------------------------------------------")
	printLine(" ")

	prefix = "app.replicationDomain"
	countId = 0

	execId = AdminConfig.list("DataReplicationDomain").split(SEPARATOR)

	for p in execId:
		countId = countId + 1
		printLine("%s.%d.prop.name = %s" % (prefix, countId, AdminConfig.showAttribute(p,"name")))
		for s in AdminConfig.show(AdminConfig.showAttribute(p,"defaultDataReplicationSettings")).split(SEPARATOR):
			k,v = toKeyValue(s)
			if (isEmpty(v)): v = ""
			if ( not v.startswith("(") ):
				printLine("%s.%d.prop.%s = %s" % (prefix, countId, k, v))
			else:
				for s1 in AdminConfig.show(v).split(SEPARATOR):
					k1,v1 = toKeyValue(s1)
					if (isEmpty(v1)): v1 = ""
					printLine("%s.%d.%s.prop.%s = %s" % (prefix, countId, k, k1, v1))
	printLine("%s.count = %d" % (prefix, countId))
	printLine(" ")

#-----------------------------------------
# dumpURIGroups
#-----------------------------------------
def dumpURIGroups(parmMap=None):
  try:
    if (isValidType("URIGroup")):
      
      filterSettings = getFilterSettings(parmMap)
      
      if (filterSettings.get("URIGroup",1)):
      
        urigroups = AdminConfig.list("URIGroup").splitlines()
        ugidx = 0
        if (len(urigroups) > 0):
          urigroups.sort()
          
          ugidx = 0
          for uriGroupId in urigroups:
            if (isEmpty(uriGroupId)):
              continue
            ugidx +=1 
            
            if (ugidx == 1):
              printLine("\n#---------------------------------------------------------------\n# URI Groups\n#---------------------------------------------------------------")
            else:
              printLine("")
            
            ugName = splitOffName(uriGroupId)
            printLine("app.uriGroup.%d.name = %s" % (ugidx,ugName))
            printLine("app.uriGroup.%d.clearURIPatterns = false" % ugidx)
            printSimpleProperties("app.uriGroup.%d.prop"%ugidx,uriGroupId,["name"])
        
        if (ugidx > 0):
          printLine("\napp.uriGroup.count = %d\n" % ugidx)
  except:
    errmsg = _app_message("Error processing URIGroup Settings","exception")
    printLine("\n#Error processing URIGroup Settings:\n%s"%errmsg)
#------------------------------------------------------------------------------------------------------
# @JJM
def printLibraries(liblist,pattern=None,targetCluster=None,targetNode=None,targetServer=None,targetCell=None,wildcard="*",serverList=None,membersList=None):
    libId = 0
    prefix = "app.library"
    
    for sharedlib in liblist:
        if (isEmpty(sharedlib)):
          continue
        
        c,n,s,dc,app,appdep = getScope(sharedlib)
        
        # See if we match target scope filters
        if (not isEmpty(targetCluster)):
          memberMatch = 0
          if (membersList != None):
            if (not isEmpty(n) and not isEmpty(s)):
              member = (n,s)
              if (member not in membersList):
                 continue
              else:
                memberMatch = 1
          
          
          if (not memberMatch and not checkPossibleWildcardMatch(c, targetCluster, wildcard)):
            continue
            
        if (not isEmpty(targetNode) and not checkPossibleWildcardMatch(n, targetNode, wildcard)):
          continue
        elif (not isEmpty(targetNode)):
          if (not isEmpty(targetServer)):
            if (checkPossibleWildcardMatch(s, targetServer, wildcard)):
              continue
          elif (not isEmpty(s)):
            continue
                
        if (not isEmpty(targetCell) and targetCell.lower() == "true"):
            if (not (isEmpty(c) and isEmpty(n) and isEmpty(s))):
              continue
                  
        if (isEmpty(targetServer) and serverList != None and [n,s] not in serverList):
          continue        
        
        libname = AdminConfig.showAttribute(sharedlib,"name")
        if (not isEmpty(pattern) and not checkPossibleWildcardMatch(libname, pattern, wildcard)):
          continue
        
        libId = libId + 1
        
        printScopeLines("%s.%d" % (prefix,libId),c,n,s,dc,app,appdep)
        printLine("%s.%d.prop.name  = %s" % (prefix, libId, libname))
        printSimpleProperties("%s.%d.prop" % (prefix,libId), sharedlib,["name"])
        printLine(" ")
    
        
    printLine("%s.count = %d" % (prefix,libId))
        
        
		
				
		
		

#------------------------------------------------------------------------------------------------------
def printNsbs(entryList):
    global nsbId
    prefix="app.wasnsb"

    for cellEntry in entryList:
      nsbId = nsbId + 1
      printLine(" ")

      c,n,s,dc,app,appdep = getScope(cellEntry)
      printLine("%s.%d.cluster = %s" % (prefix, nsbId, c))
      printLine("%s.%d.node    = %s" % (prefix, nsbId, n))
      printLine("%s.%d.server  = %s" % (prefix, nsbId, s))
      
      if (not isEmpty(dc)):
          printLine("%s.%d.dynamicCluster = %s" % (prefix,nsbId, dc))
        
      if (not isEmpty(app)):
          printLine("%s.%d.application = %s" % (prefix,nsbId,app))
      
      if (not isEmpty(appdep)):
          printLine("%s.%d.deployment = %s" % (prefix,nsbId,appdep))       
      
      
      
      printLine(" ")
    
      try:
        type = AdminConfig.showAttribute(cellEntry, "corbanameUrl")
        printLine("%s.%d.nsb.type = CORBAObjectNameSpaceBinding" % (prefix, nsbId))
        printLine("%s.%d.nsb.prop.name = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "name")))
        printLine("%s.%d.nsb.prop.corbanameUrl = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "corbanameUrl")))
        printLine("%s.%d.nsb.prop.nameInNameSpace = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "nameInNameSpace")))
        printLine("%s.%d.nsb.prop.federatedContext = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "federatedContext")))
      except:
        pass
    
      try:
        type = AdminConfig.showAttribute(cellEntry, "ejbJndiName")
        printLine("%s.%d.nsb.type = EjbNameSpaceBinding" % (prefix, nsbId))
        printLine("%s.%d.nsb.prop.name = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "name")))
        printLine("%s.%d.nsb.prop.applicationServerName = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "applicationServerName")))
        printLine("%s.%d.nsb.prop.applicationNodeName = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "applicationNodeName")))
        printLine("%s.%d.nsb.prop.nameInNameSpace = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "nameInNameSpace")))
        printLine("%s.%d.nsb.prop.bindingLocation = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "bindingLocation")))
        printLine("%s.%d.nsb.prop.ejbJndiName = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "ejbJndiName")))
      except:
        pass
    
      try:
        type = AdminConfig.showAttribute(cellEntry, "jndiName")
        printLine("%s.%d.nsb.type = IndirectLookupNameSpaceBinding" % (prefix, nsbId))
        printLine("%s.%d.nsb.prop.name = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "name")))
        printLine("%s.%d.nsb.prop.nameInNameSpace = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "nameInNameSpace")))
        printLine("%s.%d.nsb.prop.jndiName = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "jndiName")))
        printLine("%s.%d.nsb.prop.providerURL = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "providerURL")))
        printLine("%s.%d.nsb.prop.initialContextFactory = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "initialContextFactory")))
        custprops=AdminConfig.showAttribute(cellEntry,"otherCtxProperties")
        if (not isEmpty(custprops)):
          for cpropsitem in wsadminToList(custprops):
              cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
              cpropname = AdminConfig.showAttribute(cpropsitem,"name")
              cpropval = AdminConfig.showAttribute(cpropsitem,"value")
              if isEmpty(cpropdesc):
                printLine("%s.%d.nsb.otherCtxProperties.prop.%s = %s" % (prefix, nsbId,  cpropname, cpropval))
              else:
                printLine("%s.%d.nsb.otherCtxProperties.prop.%s = %s|%s" % (prefix,nsbId,   cpropname, cpropval, cpropdesc))
        
      except:
        pass
    
      try:
        type = AdminConfig.showAttribute(cellEntry, "stringToBind")
        printLine("%s.%d.nsb.type = StringNameSpaceBinding" % (prefix, nsbId))
        printLine("%s.%d.nsb.prop.name = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "name")))
        printLine("%s.%d.nsb.prop.nameInNameSpace = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "nameInNameSpace")))
        printLine("%s.%d.nsb.prop.stringToBind = %s" % (prefix, nsbId, AdminConfig.showAttribute(cellEntry, "stringToBind")))
      except:
        pass
    
      printLine(" " )

#-------------------------------------------------------------------------------
# dumpVariableMap - helper method that will dump variable entries associated
# with the variable map found by the specified query
#
# getidQuery - AdminConfig.getid() input, e.g., "/ServerCluster:clusterName/VariableMap:/"
# clusterName,nodeName,serverName - scope values
#-------------------------------------------------------------------------------
def dumpVariableMap(getidQuery,clusterName,nodeName,serverName):
  try:
        webSphereVariableMap = AdminConfig.getid(getidQuery)
        if (not isEmpty(webSphereVariableMap)):
          entries = AdminConfig.showAttribute(webSphereVariableMap, "entries")
          if (len(entries) != 0 and entries != '[]'):
            entryList = None
            try:
              entryList = wsadminToList(entries)
              printVariables(entryList, clusterName, nodeName, serverName)
            except:
              eString = _app_message("Error processing vars","exception")
              printLine("# Error processing vars\n#%s" % eString)
              printLine("# %s " % entries)
              printLine("# %s " % entryList)          
        
        
  except:
    _app_message("Problem in dumpVariableMap(%s)"%getidQuery,"exception")

#------------------------------------------------------------------------------------------------------
def dumpVars(targetCluster=None,targetNode=None,targetServer=None,targetCell=None,wildcard="*",serverList=None,membersList=None):
  printLine(" ")
  printLine("#------------------------------------------------------------------------------")
  printLine("# Environmental variables - ")
  printLine("#    Cell scope    = leave cluster, node, server empty")
  printLine("#    Cluster scope = leave node, server empty ")
  printLine("#    Node scope    = leave cluster, server empty ")
  printLine("#    Server scope  = leave cluster empty ")
  printLine("# Syntax name = value | description")
  printLine("#")
  printLine("#------------------------------------------------------------------------------")
  printLine(" ")
  
  explicitTargets = (not isEmpty(targetCluster) or 
                     not isEmpty(targetNode) or 
                     not isEmpty(targetServer) or 
                     not isEmpty(targetCell) or 
                     serverList != None) 
  
  
  # Cell scoped variables
  if (not explicitTargets or targetCell == "true"):
    cells = AdminConfig.list('Cell').split(SEPARATOR)
    for cell in cells:
      cellName = AdminConfig.showAttribute(cell, "name")
      qstr = "/Cell:"+cellName+"/VariableMap:/"
      dumpVariableMap(qstr,"","","")

    
  # cluster scoped variables
  if (not explicitTargets or not isEmpty(targetCluster)):
    clusters = AdminConfig.list('ServerCluster').split(SEPARATOR)
    for cluster in clusters:
      if (isEmpty(cluster)):continue
      clusterName = AdminConfig.showAttribute(cluster, "name")
      if (isEmpty(targetCluster) or checkPossibleWildcardMatch(clusterName, targetCluster, wildcard)):
        qstr = "/ServerCluster:"+clusterName+"/VariableMap:/"
        dumpVariableMap(qstr,clusterName,"","")
        
        # Do cluster members if necessary
        if (membersList != None):
          for member in membersList:
            qstr = "/Node:%s/Server:%s/VariableMap:/" % (member[0],member[1])
            dumpVariableMap(qstr,"",member[0],member[1])
        
        
  #nodes = AdminConfig.list('Node', cell).split(SEPARATOR)
  if (not explicitTargets or not isEmpty(targetNode)):
    
    nodes = AdminConfig.getid('/Node:/').split(SEPARATOR)
    nodes.sort()
    
    for node in nodes:
      nodename = AdminConfig.showAttribute(node, 'name')
      if (nodename.find('CellManager') > 0): continue
      
      if (isEmpty(targetNode) or checkPossibleWildcardMatch(nodename, targetNode, wildcard) or
          (isEmpty(targetServer) and serverList != None and [nodename] in serverList)):
        
        if (not explicitTargets or (serverList == None and isEmpty(targetServer))):
          # Print node scoped variables
          nodeWebSphereVariableMap = AdminConfig.getid("/Node:"+nodename+"/VariableMap:/")
          qstr = "/Node:"+nodename+"/VariableMap:/"
          dumpVariableMap(qstr,"",nodename,"")
          
          
        if (not explicitTargets or not isEmpty(targetServer) or serverList != None):
          # Print server scoped variables
          servs = AdminConfig.getid('/Node:' + nodename + '/Server:/').split(SEPARATOR)
          servs.sort()
          
          for server in servs:
            if (not isEmpty(server)):
              svrname = AdminConfig.showAttribute(server, 'name')
              if (isEmpty(targetServer) or checkPossibleWildcardMatch(svrname, targetServer, wildcard) or
                   (isEmpty(targetServer) and serverList != None and [nodename,svrname] in serverList)):
                #if (svrname.find('agent') > 0): continue
                qstr = "/Node:"+nodename+"/Server:"+svrname+"/VariableMap:/"
                dumpVariableMap(qstr,"",nodename,svrname)        
      
  printLine("app.wasenv.count = %d\n" % (id))
    

#------------------------------------------------------------------------------
def printTemplateServer():
	printLine(" " )
	printLine("#------------------------------------------------------------------------------")
	printLine("# Application Server Template Properties")
	printLine("#")
	printLine("# Script creates a template server and use it as an template for cluster")
	printLine("# This server is deleted at the end")
	printLine("#------------------------------------------------------------------------------")
	printLine("#	Create application servers")
	#printLine("app.appserver.count = 1")
	printLine("")
	printLine("#	 Application Server Template for Cluster")
	printLine("#	 Replace all TEMPLATE_NODE with actual node name")
	printLine("app.appserver.1.node = TEMPLATE_NODE")
	printLine("")
	printLine("#	The following app server (template) is always deleted!")
	printLine("app.appserver.1.name = serverTemplate")
	printLine("")
	printLine("#	Starting port : required ONLY FOR CUSTOM PORTS. Leave it blank for WebSphere defaults")
	printLine("app.appserver.1.startingport = ")
	printLine("")
	printLine("#	Set WebContainer ThreadPool properties")
	printLine("app.appserver.1.webContainer.threadPool.prop.inactivityTimeout = 3500")
	printLine("app.appserver.1.webContainer.threadPool.prop.isGrowable = false")
	printLine("app.appserver.1.webContainer.threadPool.prop.minimumSize = 10")
	printLine("app.appserver.1.webContainer.threadPool.prop.maximumSize = 50")
	printLine("")
	printLine("#       Set Session Management properties")
	printLine("app.appserver.1.webContainer.sessionManagement.prop.sessionPersistenceMode = DATA_REPLICATION")
	printLine("")
	printLine("#       Optional Database Persistence Session Management properties")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.sessionPersistenceMode = DATABASE")
	
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.accessSessionOnTimeout = true")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.allowSerializedSessionAccess = false")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.enable = true")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.enableCookies = true")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.enableProtocolSwitchRewriting = false")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.enableSSLTracking = false")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.enableSecurityIntegration = false")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.enableUrlRewriting = false")
	printLine("#app.appserver.1.webContainer.sessionManagement.prop.maxWaitTime = 5")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.prop.allowOverflow = true")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.prop.invalidationTimeout = 30")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.prop.maxInMemorySessionCount = 1000")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.prop.scheduleInvalidation = false")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.prop.usingMultiRowSchema = true")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.prop.writeContents = ONLY_UPDATED_ATTRIBUTES")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.prop.writeFrequency = TIME_BASED_WRITE")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.prop.writeInterval = 10")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.invalidationSchedule.prop.firstHour = 14")
	printLine("#app.appserver.1.webContainer.sessionManagement.tuningParams.invalidationSchedule.prop.secondHour = 2")
	printLine("#app.appserver.1.webContainer.sessionManagement.defaultCookieSettings.prop.domain = ")
	printLine("#app.appserver.1.webContainer.sessionManagement.defaultCookieSettings.prop.maximumAge = -1")
	printLine("#app.appserver.1.webContainer.sessionManagement.defaultCookieSettings.prop.name = JSESSIONID")
	printLine("#app.appserver.1.webContainer.sessionManagement.defaultCookieSettings.prop.path = /")
	printLine("#app.appserver.1.webContainer.sessionManagement.defaultCookieSettings.prop.secure = false")
	printLine("#app.appserver.1.webContainer.sessionManagement.sessionDatabasePersistence.prop.datasourceJNDIName = jdbc/Sessions")
	printLine("#app.appserver.1.webContainer.sessionManagement.sessionDatabasePersistence.prop.db2RowSize = ROW_SIZE_32KB")
	printLine("#app.appserver.1.webContainer.sessionManagement.sessionDatabasePersistence.prop.password = *****")
	printLine("#app.appserver.1.webContainer.sessionManagement.sessionDatabasePersistence.prop.tableSpaceName = SESSIONSPACE")
	printLine("#app.appserver.1.webContainer.sessionManagement.sessionDatabasePersistence.prop.userId = db2admin")
	printLine("")
	
	printLine("#       Set Log properties")
	printLine("app.appserver.1.processdef.outputLog.prop.baseHour = 24")
	printLine("app.appserver.1.processdef.outputLog.prop.fileName = \${SERVER_LOG_ROOT}/SystemOut.log")
	printLine("app.appserver.1.processdef.outputLog.prop.formatWrites = true")
	printLine("app.appserver.1.processdef.outputLog.prop.maxNumberOfBackupFiles = 7")
	printLine("app.appserver.1.processdef.outputLog.prop.messageFormatKind = BASIC")
	printLine("app.appserver.1.processdef.outputLog.prop.rolloverPeriod = 24")
	printLine("app.appserver.1.processdef.outputLog.prop.rolloverSize = 1")
	printLine("app.appserver.1.processdef.outputLog.prop.rolloverType = TIME")
	printLine("app.appserver.1.processdef.outputLog.prop.suppressStackTrace = false")
	printLine("app.appserver.1.processdef.outputLog.prop.suppressWrites = false")
	printLine("")

	printLine("app.appserver.1.processdef.errorLog.prop.baseHour = 24")
	printLine("app.appserver.1.processdef.errorLog.prop.fileName = \${SERVER_LOG_ROOT}/SystemErr.log")
	printLine("app.appserver.1.processdef.errorLog.prop.formatWrites = true")
	printLine("app.appserver.1.processdef.errorLog.prop.maxNumberOfBackupFiles = 7")
	printLine("app.appserver.1.processdef.errorLog.prop.messageFormatKind = BASIC")
	printLine("app.appserver.1.processdef.errorLog.prop.rolloverPeriod = 24")
	printLine("app.appserver.1.processdef.errorLog.prop.rolloverSize = 1")
	printLine("app.appserver.1.processdef.errorLog.prop.rolloverType = TIME")
	printLine("app.appserver.1.processdef.errorLog.prop.suppressStackTrace = false")
	printLine("app.appserver.1.processdef.errorLog.prop.suppressWrites = false")
	printLine("")
	
	#@JJM
	printLine("#	Set trace service settings for app servers")
	printLine("app.appserver.1.processdef.traceService.prop.enable = true")
	printLine("app.appserver.1.processdef.traceService.prop.memoryBufferSize = 8")
	printLine("app.appserver.1.processdef.traceService.prop.startupTraceSpecification = *=info")
	printLine("app.appserver.1.processdef.traceService.prop.traceFormat = BASIC")
	printLine("app.appserver.1.processdef.traceService.prop.traceOutputType = SPECIFIED_FILE")
	printLine("app.appserver.1.processdef.traceService.traceLog.prop.fileName = ${SERVER_LOG_ROOT}/trace.log")
	printLine("app.appserver.1.processdef.traceService.traceLog.prop.maxNumberOfBackupFiles = 1")
	printLine("app.appserver.1.processdef.traceService.traceLog.prop.rolloverSize = 20")
	printLine("")

	printLine("#	Set auto-restart for app servers")
	printLine("app.appserver.1.processdef.monitoringpolicy.prop.autoRestart = true")
	printLine("app.appserver.1.processdef.monitoringpolicy.prop.nodeRestartState = PREVIOUS" )
	printLine("")
	
	# @JJM
	printLine("#  Set the working directory for the app servers")
	printLine("app.appserver.1.processdef.process.prop.workingDirectory = ${USER_INSTALL_ROOT}")
	printLine("")
	
	printLine("#	Set initial and maximum heap size properties")
	printLine("#	Attribute names retrieved from JavaVirtualMachine object - AdminConfig.attributes(\"JavaVirtualMachine\")")
	printLine("app.appserver.1.processdef.jvm.prop.debugArgs=\"-Djava.compiler=NONE -Xdebug -Xnoagent -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=7777\"")
	printLine("app.appserver.1.processdef.jvm.prop.genericJvmArguments=\"-Xgcpolicy:optavgpause -Xp256k,64k -Xk32000 -Dibm.dg.trc.print=st_verify -Dsun.rmi.dgc.client.gcInterval=3600000 -Dsun.rmi.dgc.server.gcInterval=3600000\"")

	printLine("app.appserver.1.processdef.jvm.prop.initialHeapSize	= 128")
	printLine("app.appserver.1.processdef.jvm.prop.maximumHeapSize	= 384")
	printLine("app.appserver.1.processdef.jvm.prop.verboseModeGarbageCollection=true")
	printLine("")
	printLine("app.appserver.1.processExecution.prop.processPriority=20")
	printLine("app.appserver.1.processExecution.prop.runAsGroup=was")
	printLine("app.appserver.1.processExecution.prop.runAsUser=wasadmin")
	printLine("app.appserver.1.processExecution.prop.runInProcessGroup=0")
	printLine("app.appserver.1.processExecution.prop.umask=002")
	printLine("")

	printLine("#  Set Webserver plugin settings")
	printLine("app.appserver.1.webserverPluginSettings.prop.ConnectTimeout = 0")
	printLine("app.appserver.1.webserverPluginSettings.prop.ExtendedHandshake = false")
	printLine("app.appserver.1.webserverPluginSettings.prop.MaxConnections = -1")
	printLine("app.appserver.1.webserverPluginSettings.prop.Role = PRIMARY")
	printLine("app.appserver.1.webserverPluginSettings.prop.WaitForContinue = false")
	printLine("app.appserver.1.webserverPluginSettings.prop.ServerIOTimeout =0")
	printLine("")


	printLine("")
	printLine("#	Enable startup service.")
	printLine("app.appserver.1.startupbeansservice.enable = true")
	printLine("")
	printLine("")
	


#-------------------------------------------------------------------------------------
# dumpJavaProcessDef
#-------------------------------------------------------------------------------------
def dumpJavaProcessDef(jpdId, prefix, supportZ):

      printLine(" ")
      # Base properties
      if (supportZ):
          printSimpleProperties("%s.baseProperties.prop" % (prefix), jpdId, [])

      # Monitoringpolicy
      tp = AdminConfig.showAttribute(jpdId,"monitoringPolicy")

      if ( not isEmpty(tp) ):
        printSimpleProperties("%s.monitoringpolicy.prop" % (prefix), tp,[])
        
        #printLine("# Set auto-restart for app servers")
        #printLine("%s.monitoringpolicy.prop.autoRestart = %s" % (prefix,   AdminConfig.showAttribute(tp,"autoRestart")))
        #printLine("%s.monitoringpolicy.prop.nodeRestartState = %s" % (prefix,   AdminConfig.showAttribute(tp,"nodeRestartState")))
        printLine("")
        
        
      # @JJM Working directory
      wd = AdminConfig.showAttribute(jpdId,"workingDirectory")
      if ( not isEmpty(wd)):
        printLine("#  Set working directory for app server")
        printLine("%s.process.prop.workingDirectory = %s" % (prefix,   wd))
        printLine("")
      
      ioRedirect = AdminConfig.showAttribute(jpdId,"ioRedirect")
      if (not isEmpty(ioRedirect)):
          printLine("# native output redirect")
          printSimpleProperties("%s.ioRedirect.prop" % prefix, ioRedirect)
      
      # @JJM Environment properties
      printCustomProperties("%s.environment" % prefix, jpdId, attributeName="environment")
        
      #eplist = wsadminToList(AdminConfig.showAttribute(jpdId, "environment"))
      #if (eplist != None and len(eplist) > 0):
      #    printLine("#  Environment properties of ProcessDef")
      #for ep in eplist:
      #  if ( isEmpty(AdminConfig.showAttribute(ep,"description"))):
      #    descrip = ""
      #  else:
      #    descrip = "|%s" % AdminConfig.showAttribute(ep,"description") 
      #  printLine("%s.environment.prop.%s = %s%s" % (prefix,   AdminConfig.showAttribute(ep,"name"),AdminConfig.showAttribute(ep,"value"), descrip))
      #printLine("")
        
      # JavaVirtualMachine
      tp = AdminConfig.list("JavaVirtualMachine",jpdId)

      printLine("#  Attribute names retrieved from JavaVirtualMachine object - AdminConfig.attributes(\"JavaVirtualMachine\")")
      printLine("%s.jvm.prop.debugArgs = \"%s\"" % (prefix,   AdminConfig.showAttribute(tp,"debugArgs")))
      printLine("%s.jvm.prop.initialHeapSize = %s" % (prefix,   AdminConfig.showAttribute(tp,"initialHeapSize")))
      printLine("%s.jvm.prop.maximumHeapSize = %s" % (prefix,   AdminConfig.showAttribute(tp,"maximumHeapSize")))
      printLine("%s.jvm.prop.verboseModeGarbageCollection = %s" % (prefix,   AdminConfig.showAttribute(tp,"verboseModeGarbageCollection")))
      printLine("%s.jvm.prop.classpath = %s" % (prefix,   AdminConfig.showAttribute(tp,"classpath")))
      printSimpleProperties("%s.jvm.prop" % (prefix), tp, ["debugArgs","initialHeapSize","maximumHeapSize","verboseModeGarbageCollection","genericJvmArguments","classpath"])
      
  
      printLine("#")
      genericArgs = AdminConfig.showAttribute(tp,"genericJvmArguments")
      printLine("# genericJvmArguments can be specified as either a single line")
      printLine("#   or a list of rules that control special editing of the generic arguments")
      printLine("#   The rules are either: ")
      printLine("#            new-argument/replaces-argument/skip-argument")
      printLine("#            remove-argument")
      printLine("#   All arguments in genericJvmArguments will be added to existing settings")
      printLine("#   The items in the list will be added with special handling:")
      printLine("#        If existing argument that starts with skipIfArgExists, the new arg is not added")
      printLine("#        If exisitng argument that starts with replacesArg, that argument is replaced with new value")
      printLine("#        If removeArg is specified, the argument starting with removeArg is removed")
      
      printLine("%s.jvm.prop.genericJvmArguments = \"%s\"" % (prefix,   genericArgs))
      if (not isEmpty(genericArgs)):
          genericArgsList = genericArgs.split()
          argidx = 0
          for genarg in genericArgsList:
              argidx = argidx+1
              printLine("#%s.jvm.genericJvmArguments.%d.newArg =  \"%s\"" % (prefix, argidx,  genarg))
              repstring = ""
              reppos=genarg.find("=")
              if (reppos < 0):
                  reppos=genarg.find(":")
              if (reppos > 0):
                  repstring = genarg[:reppos]
              
              printLine("#%s.jvm.genericJvmArguments.%d.replacesArg =  \"%s\"" % (prefix, argidx,  repstring))
              printLine("#%s.jvm.genericJvmArguments.%d.skipIfArgExists =  \"%s\"" % (prefix, argidx,  repstring))
              
          printLine("#%s.jvm.genericJvmArguments.count = %d" % (prefix, argidx))
      printLine("")


      printCustomProperties("%s.jvm.sys" % (prefix), tp, "systemProperties")      
      #sp = wsadminToList(AdminConfig.showAttribute(tp, "systemProperties"))
      #for sys in sp:
      # if ( isEmpty(AdminConfig.showAttribute(sys,"description"))):
      #   descrip = ""
      # else:
      #   descrip = "|%s" % AdminConfig.showAttribute(sys,"description") 
      # printLine("%s.jvm.sys.prop.%s = %s%s" % (prefix,   AdminConfig.showAttribute(sys,"name"),AdminConfig.showAttribute(sys,"value"), descrip))
      printLine("")
      
      # ProcessExecution 
      if (supportZ):
        tp = AdminConfig.list("ProcessExecution",jpdId).split(SEPARATOR)
        for p in tp:
            for s in AdminConfig.show(p).split(SEPARATOR):
              k,v = toKeyValue(s)
              if (isEmpty(v)): v = ""
              printLine("%s.processExecution.prop.%s= %s" % (prefix,   k, v))
              
      printLine("")



#--------------------------------------------------------------------------------------------
# findTransportChain
# wsadmin>print AdminConfig.getid("/Node:ConfigurationScriptingNode1/Server:MemberOne/TransportChannelService:/TCPInboundChannel:TCP_2/")
# TCP_2(cells/ConfigurationScriptingCell/nodes/ConfigurationScriptingNode1/servers/MemberOne|server.xml#TCPInboundChannel_1306184974251)
# wsadmin>print AdminConfig.getid("/Node:ConfigurationScriptingNode1/Server:MemberOne/TransportChannelService:/Chain:WCInboundDefault/")
# WCInboundDefault(cells/ConfigurationScriptingCell/nodes/ConfigurationScriptingNode1/servers/MemberOne|server.xml#Chain_1306184974251)
#--------------------------------------------------------------------------------------------
def findTransportChain(searchName, server):
		retval = None
		
		# Use list instead of getid since we don't know if server is server or cluster template
		chainList = AdminConfig.list("Chain",server).split(SEPARATOR)
		for chain in chainList:
				if (not isEmpty(chain)):
						name = splitOffName(chain)
						if (name == searchName):
								retval = chain
								break
		
		return retval
		
#--------------------------------------------------------------------------------------------
#
#--------------------------------------------------------------------------------------------
def dumpTransportChain(prefix, chain):
    name = splitOffName(chain)
    printLine("\n# Transport Chain: %s" % name)
    printLine("%s.name = %s" % (prefix, name))
    printSimpleProperties("%s.prop" % prefix, chain, ["name"])
    
    channels = wsadminToList(AdminConfig.showAttribute(chain, "transportChannels"))
    channelidx = 0
    for channel in channels:
        if (not isEmpty(channel)):
            childDict = {}
            channelidx = channelidx + 1
            name = splitOffName(channel)
            printLine("# Channel %s" % name)
            printLine("%s.channels.%d.name = %s" % (prefix, channelidx, name))
            printLine("%s.channels.%d.type = %s" % (prefix,channelidx,callGetObjectType(channel)))
            printSimpleProperties("%s.channels.%d.prop" % (prefix, channelidx), channel, ["name"],printSimpleChildren=1,collectDict=childDict)
            
            printCustomProperties("%s.channels.%d.customProperties" % (prefix, channelidx), channel, "properties")      
            
            threadPool = childDict.get("%s.channels.%d.prop.threadPool" % (prefix,channelidx))
            if (not isEmpty(threadPool)):
              printLine("%s.channels.%d.threadPool.name = %s" % (prefix,channelidx,AdminConfig.showAttribute(threadPool,"name")))
    
    printLine("\n%s.channels.count = %d" % (prefix, channelidx))


def dumpSessionManager(prefix, sessionMgrId):
      
      if (not isEmpty(sessionMgrId)) :
      
        collectDict = {}
        
        printLine("#  Session Management properties")
        printSimpleProperties("%s.prop"% prefix ,sessionMgrId, optionalSkipList=[],includeBlanks=1,printSimpleChildren=0,
                          printPropertyAttributes=1,useAttrNameWithProperties=1,includeReferenceChildren=0,printListChildren=0,
                          printChildType=0,collectDict=collectDict)
        
        sessionPersistenceMode = collectDict.get("%s.prop.sessionPersistenceMode" % prefix)
          
        tuningParams = collectDict.get("%s.prop.tuningParams" % prefix)
        if (not isEmpty(tuningParams)):
          
          printSimpleProperties("%s.tuningParams"%prefix,tuningParams, optionalSkipList=[],includeBlanks=1,printSimpleChildren=1)
        
        
        cookieid = collectDict.get("%s.prop.defaultCookieSettings" % prefix) 
        if (cookieid != "") :
          printSimpleProperties("%s.defaultCookieSettings.prop"%prefix,cookieid)
            
        if (sessionPersistenceMode == "DATABASE") :
            sessionDatabasePersistenceid = collectDict.get("%s.prop.sessionDatabasePersistence"%prefix)
            if (sessionDatabasePersistenceid != "") :
                printSimpleProperties("%s.sessionDatabasePersistence.prop"%prefix,sessionDatabasePersistenceid)
        
        if (sessionPersistenceMode == "DATA_REPLICATION") :
            drssettingsid = collectDict.get("%s.prop.sessionDRSPersistence"%prefix)
            if (drssettingsid != "") :
                printSimpleProperties("%s.sessionDRSPersistence.prop"%prefix,drssettingsid)


#--------------------------------------------------------------------------------------------
# dumpClassloader
#--------------------------------------------------------------------------------------------
def dumpClassloader(prefix,cldr):
    clmode = AdminConfig.showAttribute(cldr,"mode")
          
    printLine("%s.prop.mode = %s" % (prefix, clmode))
    libRefIdx = 0
    libraryRefs = AdminConfig.list("LibraryRef", cldr).split(SEPARATOR)
    for libraryRef in libraryRefs:
        if (isEmpty(LibraryRef)):
          continue
        libRefIdx = libRefIdx+1
        libraryName = AdminConfig.showAttribute(libraryRef,"libraryName")
        sharedClassloader = AdminConfig.showAttribute(libraryRef,"sharedClassloader")
              
        printLine("%s.libraries.%d.prop.libraryName = %s" % (prefix,   libRefIdx, libraryName))
        printLine("%s.libraries.%d.prop.sharedClassloader = %s" % (prefix,   libRefIdx, sharedClassloader))
              
    printLine("%s.libraries.count = %d" % (prefix, libRefIdx))


#--------------------------------------------------------------------------------------------
def dumpAdminServices(prefix,server):
  
  connectors = ["SOAPConnector", "JSR160RMIConnector", "RMIConnector","IPCConnector"]
  adminServiceId = AdminConfig.list("AdminService",server)
  if (not isEmpty(adminServiceId)):
    nestedIds = {}
    serviceprops = 	collectSimpleProperties(None, "%s.adminService.prop" % prefix,adminServiceId,[],nestedIds)
    for key in serviceprops.keys():
      printLine("%s = %s" % (key, serviceprops.get(key)))
    
    for key in nestedIds.keys():
      val = nestedIds.get(key)
      if (isArray(val)):
        continue
      # Ok, if this is an reference to a connector, we'll use the connector type as the value
      for connectorType in connectors:
        if (val.find(connectorType) >= 0):
          printLine("%s = %s" % (key, connectorType))
          break
    
    printCustomProperties("%s.adminService.properties" % prefix, adminServiceId, "properties")
    
    connectorIds = wsadminToList(nestedIds.get("%s.adminService.prop.connectors" % (prefix),"[ ]"))
    connectorIdx = 0
    for connectorId in connectorIds:
      for connectorType in connectors:
        if (connectorId.find(connectorType) >= 0):
          connectorIdx = connectorIdx + 1
          printLine("%s.adminService.connectors.%d.type = %s" % (prefix,connectorIdx,connectorType))
          printSimpleProperties("%s.adminService.connectors.%d.prop"% (prefix,connectorIdx),connectorId,[])
          printCustomProperties("%s.adminService.connectors.%d.properties"% (prefix,connectorIdx), connectorId, "properties")
          break
    printLine("%s.adminService.connectors.count = %d" % (prefix,connectorIdx))
    


# dumpPMIModule
# Recurse through the PMIModule tree and print the module settings 
def dumpPMIModule(prefix, moduleId):
  
  printSimpleProperties("%s.prop" % prefix, moduleId)
  
  subModules = wsadminToList(AdminConfig.showAttribute(moduleId,"pmimodules"))
  
  modidx = 0
  for subModule in subModules:
    if (not isEmpty(subModule)):
      modidx += 1
      dumpPMIModule("%s.pmimodules.%d"  % (prefix,modidx), subModule)
    
    if (modidx > 0):
      printLine("%s.pmimodules.count = %d" % (prefix,modidx))


#------------------------------------------------------------------
# dumpServerSDK
#
# Record the current server SDK (8.5 onwards)
#------------------------------------------------------------------
def dumpServerSDK(prefix,nodeName, serverName):
  global sdksSupported
  global nodeSDKs
  
  if (not sdksSupported):
    return
    
  try:
    sdkList = nodeSDKs.get(nodeName)
    if (sdkList == None):
      sdkList = AdminTask.getAvailableSDKsOnNode("[-nodeName %s]" % nodeName).splitlines()
      nodeSDKs[nodeName] = sdkList
    
    serverSDKString = AdminTask.getServerSDK("[-nodeName %s -serverName %s]" % (nodeName,serverName))
    tempprops = wsadminToDictionary(serverSDKString)
    #print "%s" % tempprops
    serverSDK = tempprops.get("sdkname")
    
    printLine("\n# Available SDKs on this node: %s" % sdkList)
    printLine("%s.sdk = %s\n" % (prefix, serverSDK))
      
  except:
    sdksSupported = 0

#
# getDynamicClusterServerType - Get dynamic cluster server type
# getMiddlewareServerType - Use this command to show the server type of a middleware server
# getServerType - returns the server type of the specified server.
# listForeignServerTypes - Use this command to show all of the middleware server types
# listMiddlewareServerTypes - Use this command to show all of the middleware server types
# listServerTypes - Lists the available serverTypes that have a template.
# listWASServerTypes - Use this command to show all of the middleware server types
# showServerTypeInfo - Show server type information.

#-------------------------------------------------------------------------------
# dumpExternalServer
#
# Start with the ForeignServer definition and then dump other configuration items.
# Parameters
#
#-------------------------------------------------------------------------------
def dumpExternalServer(serverId,prefix):
  
  retval = None
  try:
    foreignId = AdminConfig.list("ForeignServer",serverId)
    if (not isEmpty(foreignId)):
      printCustomProperties("%s.properties" % prefix,foreignId,"properties")
      printDescriptivePropertyGroup("%s.configuration" % prefix,parentId=foreignId,attributeName="configuration")
      
      externalFileServices = AdminConfig.list("ExternalFileService",serverId)
      if (not isEmpty(externalFileServices)):
        efsList = externalFileServices.splitlines()
        efsIndex = 0
        for efs in efsList:
          if (isEmpty(efs)):
            continue
          efsIndex += 1
          printSimpleProperties("%s.externalFileService.%d" % (prefix,efsIndex),efs, 
                                 printSimpleChildren=1, printPropertyAttributes=1,useAttrNameWithProperties=1,
                                 printListChildren=1,printChildType=1)
      
      if (efsIndex > 0):
        printLine("%s.ExternalFileService.count = %d" % (prefix,efsIndex))
      
      namedProcessDefs = AdminConfig.list("NamedProcessDef",serverId)
      if (not isEmpty(namedProcessDefs)):
        npdList = namedProcessDefs.splitlines()
        npdList.sort()
        npdList2 = []
        for npd in npdList:
          npdProps = {}
          npdNested = {}
          collectSimpleProperties(npdProps, "npd", npd, nestedIds=npdNested)
          
          npdName = npdProps.get("npd.name","")
          npdOS = npdProps.get("npd.osnames","")
          npdList2.append((npdName,npdOS,npd,npdProps,npdNested))
        
        # Sort by name/os
        npdList2.sort()
        npdIdx = 0
        for npdt in npdList2:
          npdIdx += 1
          npdName = npdt[0]
          npdOS = npdt[1]
          npd = npdt[2]
          npdProps = npdt[3]
          npdNested = npdt[4]
          printLine("%s.processDefinitions.%d.name = %s" % (prefix,npdIdx,npdName))
          printLine("%s.processDefinitions.%d.osnames = %s" % (prefix,npdIdx,npdOS))
          
          tkeys = npdProps.keys()
          tkeys.sort()
          for key in tkeys:
            if (key == "npd.name" or key == "npd.osnames"):
              continue
            printLine("%s.processDefinitions.%d.prop.%s = %s" % (prefix,npdIdx,key[4:],npdProps[key]))
          
          # Now do nested attributes
          nkeys = npdNested.keys()
          nkeys.sort()
          for tkey in nkeys:
            tid = npdNested[tkey]
            attrName = tkey[4:]
            if (isId(tid)):
              printSimpleProperties("%s.processDefinitions.%d.%s.prop" % (prefix, npdIdx,attrName), tid,printSimpleChildren=1,printListChildren=1)
        if (npdIdx > 0):
          printLine("%s.processDefinitions.count = %d" % (prefix, npdIdx))
              
          
          
          
          
        

      
      
    
  except:
    _app_message("Unexpected problem in dumpExternalServer()","exception")
  
  
  return retval

#--------------------------------------------------------------------------------------------
# getFilterSettings
#--------------------------------------------------------------------------------------------
def getFilterSettings(parmMap):
  
  if (parmMap == None):
    parmMap = {}
  
  filterableComponents = ['ApplicationServer','Classloader','ThreadPoolManager','PMIModule','PMIService','WebserverPluginSettings','ObjectRequestBroker',
                          'SessionManager','MessageListenerService','MessageListenerService','TransactionService','EJBContainer',
                          "WCInboundDefault", "WCInboundDefaultSecure",
                          "HttpQueueInboundDefault","HttpQueueInboundDefaultSecure","WCInboundAdmin","WCInboundAdminSecure",
                          "SIPCInboundDefault", "SIPCInboundDefaultSecure", "SIPCInboundDefaultUDP","SIPContainer", "WebContainer",
                          "PortletContainer","StreamRedirect","TraceService","RASLoggingService","HighPerformanceExtensibleLogging","HTTPAccessLoggingService","JavaProcessDef","ProcessExecution",
                          "StartupBeansService","CustomService","HAManagerService","AdminService","ObjectPoolService","DynamicCache",
                          "JavaPersistenceAPIService","HTTPS_PROXY_CHAIN","HTTP_PROXY_CHAIN",
                          "ProxyServer","ProxySettings","ServerEntry","EndPoint",
                          "InboundBasicMessaging", "InboundSecureMessaging", "InboundBasicMQLink","InboundSecureMQLink",
                          "BootstrapBasicMessaging","BootstrapSecureMessaging","BootstrapTunneledMessaging","BootstrapTunneledSecureMessaging",
                          "OutboundBasicMQLink","OutboundBasicWMQClient","OutboundSecureMQLink","OutboundSecureWMQClient",
                          "DCS","DCS-Secure",
                          "DRSSettings",
                          "Deployment", "ClientModuleDeployment",
                          "DeploymentTargetMapping", "WebModuleDeployment", "ApplicationDeployment", "EJBModuleDeployment", "ConnectorModuleDeployment","ModuleDeployment",
                          "DeployedObjectConfig", "ApplicationConfig", "ModuleConfig", "WebModuleConfig", "EJBModuleConfiguration", "EnterpriseBeanConfig",
                          "URIGroup",  "WorkAreaService", "WorkAreaPartitionService",
                          "WAS40DataSource"]
                          
  filterSettings = parmMap.get("FILTER_SETTINGS",None)
  if (filterSettings != None):
    return filterSettings
  
  filterSettings={"PMIModule":1}
  
  excludeFilter = parmMap.get("-excludeFilter","")
  includeFilter = parmMap.get("-includeFilter","")
  excludeFilterList = []
  includeFilterList = []
  
  if (excludeFilter.find(",")>= 0 ):
    splitchar = ","
  elif (excludeFilter.find(";") >= 0):
    splitchar=";"
  else:
    splitchar = "+"
  
  excludeFilterList.extend(excludeFilter.split(splitchar))
  
  if (excludeFilter.upper().startswith("ALL")):
    excludeFilterList.extend(filterableComponents)
  
  for excludeType in excludeFilterList:
    filterSettings[excludeType] = 0
  
  if (includeFilter.find(",")>= 0 ):
    splitchar = ","
  elif (includeFilter.find(";") >= 0):
    splitchar=";"
  else:
    splitchar = "+"
  
  includeFilterList.extend(includeFilter.split(splitchar))        
  
  for includeType in includeFilterList:
    filterSettings[includeType] = 1    
  
  parmMap["FILTER_SETTINGS"] = filterSettings
  
  return filterSettings

#--------------------------------------------------------------------------------------------
# dumpServerPorts
#--------------------------------------------------------------------------------------------
portNames = ["BOOTSTRAP_ADDRESS","CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS","CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS","DCS_UNICAST_ADDRESS","IPC_CONNECTOR_ADDRESS","ORB_LISTENER_ADDRESS","OVERLAY_TCP_LISTENER_ADDRESS","OVERLAY_UDP_LISTENER_ADDRESS","SAS_SSL_SERVERAUTH_LISTENER_ADDRESS","SIB_ENDPOINT_ADDRESS","SIB_ENDPOINT_SECURE_ADDRESS","SIB_MQ_ENDPOINT_ADDRESS","SIB_MQ_ENDPOINT_SECURE_ADDRESS","SIP_DEFAULTHOST","SIP_DEFAULTHOST_SECURE","SOAP_CONNECTOR_ADDRESS","WC_adminhost","WC_adminhost_secure","WC_defaulthost","WC_defaulthost_secure","XDAGENT_PORT"]
def dumpServerPorts(prefix,serverName,nodeName,parmMap=None):
  try:
    if (parmMap == None):
      parmMap = {}
      
    filterSettings = getFilterSettings(parmMap)
    
    if (filterSettings.get("ServerEntry",0) or filterSettings.get("EndPoint",0)):
       
      se  = AdminConfig.getid("/Node:%s/ServerIndex:/ServerEntry:%s/" % (nodeName,serverName))
      
      if (not isEmpty(se)):
        
          tName = se.split("(")[0]
          if (tName == serverName):
            # Listen
            endpoints = AdminConfig.list("NamedEndPoint",se).splitlines()
            endPointDict = {}
            for nep in endpoints:
              if (isEmpty(nep)): continue
              endPointProps = {}
              subItems = {}
              collectSimpleProperties(endPointProps, "prop",nep, [],subItems)
              endPointProps["prop.endPoint"] = subItems["prop.endPoint"]
              endPointDict[endPointProps["prop.endPointName"]] = endPointProps
            
            endPointNames = endPointDict.keys()
            endPointNames.sort()
            
            if (parmMap.get("-comparable","false").lower() != "false"):
              # Insert any ports that might be part of this release
              for epname in portNames:
                if epname not in endPointNames:
                  endPointNames.append(epname)
                  endPointDict[epname] = {}
              
              endPointNames.sort()
            
            
            epIdx = 0
            printLine("# NamedEndPoint information - set processNamedEndPoints to true")
            printLine("# for updateEnvironment processing ")
            printLine("%s.serverEntry.processNamedEndPoints = false" % prefix)
            for epn in endPointNames:
              epIdx += 1
              endPointProps = endPointDict[epn]
              tprefix = "%s.serverEntry.namedEndPoints.%d" % (prefix,epIdx)
              
              if (len(endPointProps) == 0):
                # Placeholder
                printLine("# Placeholder for cross-version comparisons")
                printLine("# %s.name = %s" % (tprefix,epn))
              else:              
                printLine("%s.name = %s" % (tprefix,epn))
                printSimpleProperties("%s.endPoint.prop"%tprefix,endPointProps["prop.endPoint"])
        
       
      
     
  except:
    _app_message("Error processing server ports","exception")
    
commonThreadNames = ["Default","ORB.thread.pool","SIBFAPInboundThreadPool","SIBFAPThreadPool",
                     "SIBJMSRAThreadPool","TCPChannel.DCS","WMQCommonServices",
                     "WMQJCAResourceAdapter","WebContainer","server.startup"]

#--------------------------------------------------------------------------------------------
# dumpApplicationServer
#
# Write settings for a stand-alone, cluster-member, or server template
# 
# Parameters:
#   prefix - The prefix to use with the output properties: app.cluster.?.clustermember.?
#                                                          app.cluster.?.clusterTemplate
#                                                          app.appserver.?
#   server - The configuration ID of the server or cluster template
#   parmMap - The dictionary of parameters passed in on the command line.  This function 
#             makes use of -excludeFilter and -includeFilter to limit the server components
#             that are written to the output file.
#--------------------------------------------------------------------------------------------
def dumpApplicationServer(prefix,server,parmMap=None):
      global commonThreadNames
       
      if (parmMap == None):  
        parmMap = {}
      
      filterSettings = getFilterSettings(parmMap)
      
        
      
      # @JJM-IC
      # Top-level application server properties and custom properties
      if (filterSettings.get("ApplicationServer",1)):
        appsrvid = AdminConfig.list("ApplicationServer",server)
        printLine("")
        printLine("# ApplicationServer properties")
        printSimpleProperties("%s.applicationServer.prop" % prefix,appsrvid,["id","name"])
        printCustomProperties("%s.applicationServer.properties" % (prefix), appsrvid, "properties")
        printLine(" ")
      
      # Old Thread Pool properties
      if (filterSettings.get("WebContainer",1)):
        tp = ""
        wc = AdminConfig.list("WebContainer",server)
        if (not isEmpty(wc)):
          tp = AdminConfig.list("ThreadPool", wc)
  
        if ( not isEmpty(tp)):
          printLine("#  Set WebContainer ThreadPool properties")
          printLine("%s.webContainer.threadPool.prop.inactivityTimeout = %s" % (prefix,   AdminConfig.showAttribute(tp,"inactivityTimeout")))
          printLine("%s.webContainer.threadPool.prop.isGrowable = %s" % (prefix,   AdminConfig.showAttribute(tp,"isGrowable")))
          printLine("%s.webContainer.threadPool.prop.minimumSize = %s" % (prefix,   AdminConfig.showAttribute(tp,"minimumSize")))
          printLine("")

      # @JJM - Dump classloaders/shared libraries
      if (filterSettings.get("Classloader",1)):
        clidx = 0
        classloaders = AdminConfig.list("Classloader", server).split(SEPARATOR)
        for cldr in classloaders:
            if (cldr == ""):
                continue
            clidx = clidx + 1
            
            clmode = AdminConfig.showAttribute(cldr,"mode")
            
            printLine("%s.classloaders.%d.prop.mode = %s" % (prefix,   clidx, clmode))
            libRefIdx = 0
            libraryRefs = AdminConfig.list("LibraryRef", cldr).split(SEPARATOR)
            for libraryRef in libraryRefs:
                if (isEmpty(libraryRef)): continue
                  
                libRefIdx = libRefIdx+1
                printSimpleProperties("%s.classloaders.%d.libraries.%d.prop" % (prefix,   clidx, libRefIdx), libraryRef, [])
                
            printLine("%s.classloaders.%d.libraries.count = %d" % (prefix,   clidx, libRefIdx))
        
        printLine("%s.classloaders.count = %d" % (prefix,   clidx))
  

      # @JJM - Dump all thread pools
      # This code has support for adding placeholders for better
      # cross version comparisons
      if (filterSettings.get("ThreadPoolManager",1)):
        
        tpm = AdminConfig.list("ThreadPoolManager", server)
        if (tpm != "") :
            printLine("#  Set Thread Pool properties")
            tplist = AdminConfig.list("ThreadPool",tpm).split(SEPARATOR)
            tpidx = 0
            if (tplist != None and len(tplist) > 0):
              # Sort configuration IDs, which should start off with name
              tplist.sort()
              
              # See if we need to put in some placeholders
              if (parmMap.get("-comparable","false").lower() != "false") :
                tpNames = []
                for tp in tplist:
                  tpName = splitOffName(tp)
                  tpNames.append(tpName)
                for commonName in commonThreadNames:
                  if commonName not in tpNames:
                    tplist.append("%s(PLACEHOLDER)"%commonName)
              
                tplist.sort()
                
              
              
            for tp in tplist:
              tpidx = tpidx + 1
              
              if (tp.endswith("(PLACEHOLDER)")):
                tpname =  tp.split("(")[0]
                printLine("#\n# Cross-version placeholder for %s" % tpname)
                printLine("# %s.threadPoolManager.threadPool.%d.prop.name = %s\n#" % (prefix,   tpidx, tpname))
                continue
              
              tpname = splitOffName(tp) 
              printLine("#  %s Thread Pool" % (tpname))
              printLine("%s.threadPoolManager.threadPool.%d.prop.name = %s" % (prefix,   tpidx, tpname))
              printSimpleProperties("%s.threadPoolManager.threadPool.%d.prop" % (prefix,   tpidx), tp, ["name"])
              
            printLine("%s.threadPoolManager.threadPool.count = %d" % (prefix,  tpidx))
            
      #endif ThreadPoolManager in filter settings        
          
      # @JJM WebContainer and Session properties
      if (filterSettings.get("WebContainer",1)):
      
        #printLine("app.appserver.1.webContainer.sessionManagement.prop.sessionPersistenceMode = DATA_REPLICATION")
        webContainerId = AdminConfig.list("WebContainer", server)
        
        if (not isEmpty(webContainerId)):
          printLine(" ")
          printSimpleProperties("%s.webContainer.prop" % (prefix), webContainerId, [])
          printCustomProperties("%s.webContainer.customProperties" % (prefix), webContainerId, "properties")
          
          if (filterSettings.get("SessionManager",1)):
            sessionMgrId = AdminConfig.list("SessionManager", webContainerId)
            if (sessionMgrId != "") :
                # Dump properties
                printLine("#  Session Management properties")
                sessionPersistenceMode = AdminConfig.showAttribute(sessionMgrId,"sessionPersistenceMode")
                
                printLine("%s.webContainer.sessionManagement.prop.sessionPersistenceMode = %s" % (prefix,   sessionPersistenceMode))
                printSimpleProperties("%s.webContainer.sessionManagement.prop" % (prefix), sessionMgrId, ["sessionPersistenceMode"],printPropertyAttributes=1)
                
                
                
                tuningParams = AdminConfig.list("TuningParams",sessionMgrId)
                invalidationSchedule = AdminConfig.list("InvalidationSchedule",tuningParams)
                
                printSimpleProperties("%s.webContainer.sessionManagement.tuningParams.prop" % (prefix), tuningParams, [])
                
      
                
                if (invalidationSchedule != "") :
                    printSimpleProperties("%s.webContainer.sessionManagement.tuningParams.invalidationSchedule.prop" % (prefix), invalidationSchedule, [])
      
                
                cookieid = AdminConfig.showAttribute(sessionMgrId,"defaultCookieSettings")
                if (cookieid != "") :
                    printSimpleProperties("%s.webContainer.sessionManagement.defaultCookieSettings.prop" % (prefix), cookieid, [],1)
                    
                    
                if (sessionPersistenceMode == "DATABASE") :
                    sessionDatabasePersistenceid = AdminConfig.showAttribute(sessionMgrId,"sessionDatabasePersistence")
                    if (sessionDatabasePersistenceid != "") :
                        printSimpleProperties("%s.webContainer.sessionManagement.sessionDatabasePersistence.prop" % (prefix), sessionDatabasePersistenceid, [])
                
                if (sessionPersistenceMode == "DATA_REPLICATION") :
                    drssettingsid = AdminConfig.showAttribute(sessionMgrId,"sessionDRSPersistence")
                    if (drssettingsid != "") :
                        printSimpleProperties("%s.webContainer.sessionManagement.sessionDRSPersistence.prop" % (prefix), drssettingsid, [])
            
            # @JJM end session properties  
            printLine(" ")
          #end if SessionManager included in filter settings
        #endif WebContainerId found  
      #endif WebContainer in filter settings
      
      wcChains = ["WCInboundDefault", "WCInboundDefaultSecure", "HttpQueueInboundDefault","HttpQueueInboundDefaultSecure","WCInboundAdmin","WCInboundAdminSecure"]
      chainIdx = 0
      for chainName in wcChains:
        
        if (filterSettings.get(chainName,1)):
          chain = findTransportChain(chainName,server)
          if (not isEmpty(chain)):
             chainIdx = chainIdx + 1
             if (chainIdx == 1):
                printLine("# Transport Chains")
                printLine("# Note: channels can be shared by different chains")
             dumpTransportChain("%s.webContainer.transportChains.%d" % (prefix,chainIdx), chain)
          elif (parmMap.get("-comparable","false").lower() != "false"):
            # Print a placeholder
            chainIdx += 1
            if (chainIdx == 1):
               printLine("# Transport Chains")
               
            printLine("# Cross-version placeholder\n%s.webContainer.transportChains.%d.name = %s\n#" % (prefix,chainIdx,chainName))

          
      if (chainIdx > 0):
        printLine("%s.webContainer.transportChains.count = %d" % (prefix,chainIdx))
      

      #@JJM-IC PortletContainer
      if (filterSettings.get("PortletContainer",1)):
        
        try:
          portletId = AdminConfig.list("PortletContainer",server)
          if (not isEmpty(portletId)):
            printLine(" ")
            printSimpleProperties("%s.portletContainer.prop" % (prefix), portletId, ["name"])
            printCustomProperties("%s.portletContainer.properties" % (prefix), portletId, "properties")
        except:
          # Not supported
          pass
          
      #endif PortletContainer in filter settings
      
      
      #@JJM-IC SIPContainer
      if (filterSettings.get("SIPContainer",1)):        
        try:
          sipId = AdminConfig.list("SIPContainer",server)
          if (not isEmpty(sipId)):
            printLine(" ")
            printSimpleProperties("%s.sipContainer.prop" % (prefix), sipId, ["name"])
            sipthreadpool = AdminConfig.showAttribute(sipId,"threadPool")
            if (not isEmpty(sipthreadpool)):
              printLine("%s.sipContainer.threadPool.name = %s" % (prefix, AdminConfig.showAttribute(sipthreadpool,"name")))
              
            
            printCustomProperties("%s.sipContainer.properties" % (prefix), sipId, "properties")
            sessionMgrId = AdminConfig.list("SessionManager",sipId)
            if (not isEmpty(sessionMgrId)):
              dumpSessionManager("%s.sipContainer.sessionManager" % (prefix), sessionMgrId)
            
            stackId = None
            if (isValidAttribute("SIPContainer","stack")):
              stackId = AdminConfig.showAttribute(sipId,"stack")
            
            if (not isEmpty(stackId)):
              printSimpleProperties("%s.sipContainer.stack.prop" % (prefix), stackId)
              
              timersId = AdminConfig.showAttribute(stackId,"timers")
              if (not isEmpty(timersId)):
                printSimpleProperties("%s.sipContainer.stack.timers.prop" % prefix, timersId)
        except:
          # Not supported by older versions
          pass
        
        printLine(" ")
        
      #endif SIPContainer in filter

      chainNameList = []
      
      if (filterSettings.get("SIPCInboundDefault",1)):
        chainNameList.append("SIPCInboundDefault")

      if (filterSettings.get("SIPCInboundDefaultSecure",1)):
        chainNameList.append("SIPCInboundDefaultSecure")
        
      if (filterSettings.get("SIPCInboundDefaultUDP",1)):
        chainNameList.append("SIPCInboundDefaultUDP")
      
      if (chainNameList):
        printLine("# SIP Transport Chains")
        chainIdx = 0
        for chainName in chainNameList:
            chain = findTransportChain(chainName,server)
            if (not isEmpty(chain)):
                chainIdx = chainIdx + 1
                dumpTransportChain("%s.sipContainer.transportChains.%d" % (prefix,chainIdx), chain)
            elif (parmMap.get("-comparable","false").lower() != "false"):
              # Print a placeholder
              chainIdx += 1
               
              printLine("# Cross-version placeholder\n%s.sipContainer.transportChains.%d.name = %s\n#" % (prefix,chainIdx,chainName))
        
        printLine("%s.sipContainer.transportChains.count = %d" % (prefix,chainIdx))

            
      
      printLine(" ")
      
      
      # Listener port
      if (filterSettings.get("MessageListenerService",1)):
        lpcount = 0
        mlService = AdminConfig.list('MessageListenerService', server)
        if (not isEmpty(mlService)):
          lports = AdminConfig.list('ListenerPort',mlService).split(SEPARATOR)
        else:
          lports = ""
        
        if (len(lports) > 0 and lports[0] != "") :
          # Print service settings
          printLine("#  Set Message Listener Service properties")
          printSimpleProperties("%s.messageListenerService.prop" % (prefix), mlService, ["enable"])
          
          
          mlsThreadPool = AdminConfig.list('ThreadPool',mlService)
          printSimpleProperties("%s.messageListenerService.threadPool.prop" % (prefix), mlsThreadPool, [])
          
          
          for lport in lports:
            if (isEmpty(lport)): continue
            lpcount = lpcount + 1
            printSimpleProperties("%s.messageListenerService.listenerPorts.%d.prop" % (prefix,   lpcount), lport, [])
            
            
            lp_stateManagement = AdminConfig.list('StateManageable',lport)
            printProperties("%s.messageListenerService.listenerPorts.%d.stateManageable.prop" % (prefix,   lpcount),lp_stateManagement)
          
          printLine("%s.messageListenerService.listenerPorts.count = %d" % (prefix,   lpcount))
          printLine(" ")
      
      #endif MessageListenerService in filter
          
      # Log Properties
      if (filterSettings.get("StreamRedirect",1)):
        ol = AdminConfig.showAttribute(server, 'outputStreamRedirect')
        if ( ol != "" ):
          printLine("#  Set log properties")
          printProperties("%s.processdef.outputLog.prop" % (prefix),ol)
          printLine("")
  
        ol = AdminConfig.showAttribute(server, 'errorStreamRedirect')
        if ( ol != "" ):
          printProperties("%s.processdef.errorLog.prop" % (prefix),ol)
          printLine("")
          
      #endif StreamRedirect in filter settings
        
        
      # @JJM - Trace service
      if (filterSettings.get("TraceService",1)):
        traceServiceId = AdminConfig.list('TraceService',server)
        if (traceServiceId != "") :
            printSimpleProperties("%s.processdef.traceService.prop" % (prefix), traceServiceId, [])
            
            
            traceLogFileId = AdminConfig.showAttribute(traceServiceId,"traceLog")
            if not isEmpty(traceLogFileId) :
                printSimpleProperties("%s.processdef.traceService.traceLog.prop" % (prefix), traceLogFileId, [])
                
                
            printLine("")
      #endif TraceService in filter settings
      
      if (filterSettings.get("RASLoggingService",1)):
        
        rasLoggingServiceId = AdminConfig.list('RASLoggingService',server)
        if (rasLoggingServiceId != "") :
            printSimpleProperties("%s.rasLoggingService.prop" % (prefix), rasLoggingServiceId, [])
            
            
            serviceLogId = AdminConfig.showAttribute(rasLoggingServiceId,"serviceLog")
            if not isEmpty(serviceLogId) :
                printSimpleProperties("%s.rasLoggingService.serviceLog.prop" % (prefix), serviceLogId, [])
                
                
            printLine("")
      #endif RASLoggingService in filter settings   
  
      #V8
      if (filterSettings.get("HighPerformanceExtensibleLogging",1) and isValidType("HighPerformanceExtensibleLogging")):
        try:
          hpeLoggingServiceId = AdminConfig.list('HighPerformanceExtensibleLogging',server)
          if (not isEmpty(hpeLoggingServiceId)) :
            # Use method parameters that will print child components and custom properties
            printSimpleProperties("%s.hpeLoggingService.prop" % (prefix), hpeLoggingServiceId, [],
                                  includeBlanks=0,printSimpleChildren=1,printPropertyAttributes=1)
            printLine("")
        except:
          # Must not be V8
          pass
      #endif HighPerformanceExtensibleLogging in filter settings
      
      if (filterSettings.get("HTTPAccessLoggingService",1)):
        try:
          httpAccessLoggingServiceId = AdminConfig.list("HTTPAccessLoggingService",server)
          if (not isEmpty(httpAccessLoggingServiceId)):
            # New approach includes errorLog,frcaLog,and accessLog attributes
            printSimpleProperties("%s.httpAccessLoggingService.prop" % prefix, httpAccessLoggingServiceId,[],includeBlanks=0,printSimpleChildren=1)
            printLine("")
        except:
          # Must not have this component
          pass
          
      # PMI Settings - Basic enablement only
      if (filterSettings.get("PMIService",1)):
        pmiServiceId = AdminConfig.list('PMIService',server)
        if (pmiServiceId) :    
            printLine("# PMI settings. See updateEnvironment.py for special handling\n# options of enable property")
            printSimpleProperties("%s.pmiService.prop" % (prefix), pmiServiceId, ["initialSpecLevel"])
            
            if (filterSettings.get("PMIModule",1)):
              # Process the PMI modules
              topModuleId = AdminConfig.list("PMIModule",pmiServiceId)
              if (not isEmpty(topModuleId)):
                  subModules = wsadminToList(AdminConfig.showAttribute(topModuleId,"pmimodules"))
                  
                  modidx = 0
                  for subModule in subModules:
                    if (not isEmpty(subModule)):
                      modidx += 1
                      dumpPMIModule("%s.pmiService.pmimodules.%d"  % (prefix,modidx), subModule)
                  
                  if (modidx > 0):
                    printLine("%s.pmiService.pmimodules.count = %d" % (prefix,modidx))
              

          
          
      if (filterSettings.get("JavaProcessDef",1)):
        # zOS servers will have multiple JavaProcessDef - We need to handle that case
        processDefList = wsadminToList(AdminConfig.list("JavaProcessDef",server))
        
        jpdidx = 0
        jpdId = None
        if (len(processDefList) > 1):
            for jpdId in processDefList:
                jpdidx = jpdidx + 1
                dumpJavaProcessDef(jpdId, "%s.processdef.%d" % (prefix,jpdidx),1)
                printLine(" ")
            printLine("%s.processdef.count = %d" % (prefix, jpdidx))
            
            jpdId = processDefList[0]
        elif (len(processDefList) > 0 and not isEmpty(processDefList[0])):
            # Print the single-process-def (classic) version
            jpdId = processDefList[0]
            dumpJavaProcessDef(jpdId, "%s.processdef" % (prefix),0)
        
        printLine(" ")
        
        
        
        
        
  
        # ProcessExecution
        if (filterSettings.get("ProcessExecution",1) and not isEmpty(jpdId)):
          tp = AdminConfig.list("ProcessExecution",jpdId).split(SEPARATOR)
          for p in tp:
                  for s in AdminConfig.show(p).split(SEPARATOR):
                          k,v = toKeyValue(s)
                          if (isEmpty(v)): v = ""
                          printLine("%s.processExecution.prop.%s= %s" % (prefix,   k, v))
          printLine("")
        #endif ProcessExecution in filter settings
      
      #endif JavaProcessDef in filter settings
      
      # @JJM- TransactionService
      if (filterSettings.get("TransactionService",1)):
        tservice = AdminConfig.list("TransactionService",server)
        if (not isEmpty(tservice)):
          for s in AdminConfig.show(tservice).split(SEPARATOR):
            k,v = toKeyValue(s)
            #print "%s %s" % (k,v)
            if (isEmpty(v)): v = ""
            if (k != "context" and k != "properties"):
                printLine("%s.transactionService.prop.%s= %s" % (prefix,   k, v))
  
        printCustomProperties("%s.transactionService.customProperties" % (prefix), tservice, "properties")
        printLine("")
      #endif

      # Webserver Plugin Settings
      if (filterSettings.get("WebserverPluginSettings",1)):
        tp = AdminConfig.list("WebserverPluginSettings",server).split(SEPARATOR)
        for p in tp:
          if (not isEmpty(p)):
            for s in AdminConfig.show(p).split(SEPARATOR):
                k,v = toKeyValue(s)
                if (isEmpty(v)): v = ""
                if (k != "properties"):
                    printLine("%s.webserverPluginSettings.prop.%s= %s" % (prefix,   k, v))
            
            # Note that although there is a properties attribute for the webserverPluginSettings, it
            # is not accessible in 6.1 admin console and nothing is documented for it.
            pprops = AdminConfig.showAttribute(p,"properties")
            if (not isEmpty(pprops)):
                for pprop in wsadminToList(pprops):
                    tpropdesc = AdminConfig.showAttribute(pprop,"description")
                    tpropname = AdminConfig.showAttribute(pprop,"name")
                    tpropval = AdminConfig.showAttribute(pprop,"value")
                
                    if isEmpty(tpropdesc):
                        printLine("%s.webserverPluginSettings.customProperties.prop.%s = %s" % (prefix,   tpropname, tpropval))
                    else:
                        printLine("%s.webserverPluginSettings.customProperties.prop.%s = %s|%s" % (prefix,   tpropname, tpropval, tpropdesc))
            
                  
        printLine("")
      
      # ObjectRequestBroker Service
      if (filterSettings.get('ObjectRequestBroker',1)):
        orb = AdminConfig.list("ObjectRequestBroker",server)
        if (not isEmpty(orb)):
            printLine("# Object Request Broker Service")
            printSimpleProperties("%s.orbService.prop" % (prefix), orb, [])
            
            threadPoolId = AdminConfig.showAttribute(orb,"threadPool")
            if (not isEmpty(threadPoolId)):
                printSimpleProperties("%s.orbService.threadPool.prop" % (prefix), threadPoolId, [])
                
            printCustomProperties("%s.orbService.customProperties" % (prefix), orb, "properties")
            
            # We'll comment out listing interceptors and plugins for now
            #orbInterceptors = AdminConfig.list("Interceptor",orb).splitSEPARATOR)
            #interceptorIdx = 0
            #for interceptor in orbInterceptors:
            #    if (not isEmpty(interceptor)):
            #        interceptorIdx =  interceptorIdx + 1
            #        iname = AdminConfig.showAttribute(interceptor,"name")
            #        printLine("%s.orbService.interceptors.%d.name = %s" % (prefix,interceptorIdx,iname))
            #        #printSimpleProperties("%s.orbService.interceptors.%d.prop" % (prefix,interceptorIdx), interceptor, [])
            #
            #printLine("%s.orbService.interceptors.count = %d" % (prefix,interceptorIdx))
            #
            #orbPlugins = AdminConfig.list("ORBPlugin",orb).split(SEPARATOR)
            #plugIdx = 0
            #for orbPlugin in orbPlugins:
            #    if (not isEmpty(orbPlugin)):
            #        plugIdx = plugIdx + 1
            #        pname = AdminConfig.showAttribute(orbPlugin,"name")
            #        printLine("%s.orbService.plugins.%d.name = %s" % (prefix,plugIdx,pname))
            #        #printSimpleProperties("%s.orbService.plugins.%d.prop" % (prefix,plugIdx), orbPlugin, [])
             #  
            #printLine("%s.orbService.plugins.count = %d" % (prefix,plugIdx))
  
        printLine(" ")
        
      # EJBContainer
      if (filterSettings.get("EJBContainer",1)):
        ejbId = AdminConfig.list("EJBContainer",server)
        if (not isEmpty(ejbId)):
            #print AdminConfig.show(ejbId)
            printLine("# EJBContainer")
            printSimpleProperties("%s.ejbContainer.prop" % (prefix), ejbId, [])
            cacheId = AdminConfig.showAttribute(ejbId, "cacheSettings")
            if (not isEmpty(cacheId)):
                printSimpleProperties("%s.ejbContainer.cacheSettings.prop" % (prefix), cacheId, [])
            drsId = AdminConfig.showAttribute(ejbId, "drsSettings")
            if (not isEmpty(drsId)):
                printSimpleProperties("%s.ejbContainer.drsSettings.prop" % (prefix), drsId, [])
            timerId = AdminConfig.showAttribute(ejbId,"timerSettings")
            if (not isEmpty(timerId)):
                printSimpleProperties("%s.ejbContainer.timerSettings.prop" % (prefix), timerId, [])
              
            
            try:
              if (isValidAttribute("EJBContainer","asyncSettings")):
                asyncid = AdminConfig.showAttribute(ejbId,"asyncSettings")
                if (not isEmpty(asyncid)):
                  printSimpleProperties("%s.ejbContainer.asyncSettings.prop" % (prefix),asyncid,[])
            except:
              # pre 8.0
              pass
     
            printLine(" ")
      #endif EJBContainer in filter settings
      
      # JavaPersistenceAPIService
      if (filterSettings.get("JavaPersistenceAPIService",1) and isValidType("JavaPersistenceAPIService")):
        try:
          jpaId = AdminConfig.list("JavaPersistenceAPIService",server)
          if (not isEmpty(jpaId)):
            printSimpleProperties("%s.javaPersistenceAPIService.prop" % prefix,jpaId,[])
            printCustomProperties("%s.javaPersistenceAPIService.properties" % prefix,jpaId,"properties")
        except:
          # 7.0 onwards
          pass
          
      messagingChains = ["BootstrapBasicMessaging","BootstrapSecureMessaging","BootstrapTunneledMessaging","BootstrapTunneledSecureMessaging",
                         "InboundBasicMessaging", "InboundSecureMessaging", "InboundBasicMQLink","InboundSecureMQLink",
                         "OutboundBasicMQLink","OutboundBasicWMQClient","OutboundSecureMQLink","OutboundSecureWMQClient"]
                    
      chainIdx = 0
      for chainName in messagingChains:
        
        if (filterSettings.get(chainName,1)):
          chain = findTransportChain(chainName,server)
          if (not isEmpty(chain)):
             chainIdx = chainIdx + 1
             if (chainIdx == 1):
                printLine("# Server Messaging Transport Chains")
                printLine("# Note: channels may be shared by different chains")
             dumpTransportChain("%s.messaging.transportChains.%d" % (prefix,chainIdx), chain)
          elif (parmMap.get("-comparable","false").lower() != "false"):
            # Print a placeholder
            chainIdx += 1
            if (chainIdx == 1):
               printLine("# Server Messaging Transport Chains")
               printLine("# Note: channels may be shared by different chains")
               
            printLine("# Cross-version placeholder\n%s.messaging.transportChains.%d.name = %s\n#" % (prefix,chainIdx,chainName)) 
      if (chainIdx > 0):
        printLine("\n%s.messaging.transportChains.count = %d" % (prefix,chainIdx))
      
      # StartupBeansService
      if (filterSettings.get("StartupBeansService",1)):
        tp = AdminConfig.list("StartupBeansService",server)
        if (not isEmpty(tp)):
          printLine("#  Enable startup service.")
          printLine("%s.startupbeansservice.enable = %s" % (prefix,   AdminConfig.showAttribute(tp,"enable")))
          printLine("")
      #endif StartupBeansService
      
      
      if (isValidType("ObjectPoolService") and filterSettings.get("ObjectPoolService",1)):
        op = AdminConfig.list("ObjectPoolService",server)
        if (not isEmpty(op)):
          printLine("# Object pool service")
          printSimpleProperties("%s.objectPoolService.prop"%prefix,op,printPropertyAttributes=1,printSimpleChildren=1)
          printLine("")
      

      if (isValidType("DynamicCache") and filterSettings.get("DynamicCache",1)):
        dc = AdminConfig.list("DynamicCache",server)
        if (not isEmpty(dc)):
          printLine("# DynamicCache service")
          printSimpleProperties("%s.dynamicCache.prop"%prefix,dc,printPropertyAttributes=1,printSimpleChildren=1,printListChildren=1,printChildType=1)
          printLine("")

      # Custom Services
      if (filterSettings.get("CustomService",1)):
        customServices = AdminConfig.list("CustomService",server).split(SEPARATOR)
        sidx = 0
        for service in customServices:
            if (isEmpty(service)):
                continue
            sidx = sidx + 1
            printSimpleProperties("%s.customService.%d.prop" % (prefix,sidx), service, [])
  
            printCustomProperties("%s.customService.%d.customProperties" % (prefix, sidx), service, "properties")
  
                        
            printLine(" ")
        
        printLine("%s.customService.count = %d" % (prefix,sidx))
        printLine(" ")
      #endif CustomService in filter list


      # HA Manager Service
      if (filterSettings.get("HAManagerService",1)):
        haserviceList = AdminConfig.list("HAManagerService",server).split(SEPARATOR)
        if (len(haserviceList) >= 1 and not isEmpty(haserviceList[0])):
            haservice = haserviceList[0]
            
            printSimpleProperties("%s.hamanagerService.prop" % (prefix), haservice, [])
            
            threadPoolId = AdminConfig.showAttribute(haservice,"threadPool")
            if (not isEmpty(threadPoolId)):
                printSimpleProperties("%s.hamanagerService.threadPool.prop" % (prefix), threadPoolId, [])
                
            printCustomProperties("%s.hamanagerService.customProperties" % (prefix), haservice, "properties")
  
            
        printLine(" ")
      #endif HAManagerService in filter settings  
      
      dcsChains = ["DCS","DCS-Secure"]
                    
      chainIdx = 0
      for chainName in dcsChains:
        
        if (filterSettings.get(chainName,1)):
          chain = findTransportChain(chainName,server)
          if (not isEmpty(chain)):
             chainIdx = chainIdx + 1
             if (chainIdx == 1):
                printLine("# DCS Transport Chains")
                printLine("# Note: channels may be shared by different chains")
             dumpTransportChain("%s.dcs.transportChains.%d" % (prefix,chainIdx), chain)
          elif (parmMap.get("-comparable","false").lower() != "false"):
            # Print a placeholder
            chainIdx += 1
            if (chainIdx == 1):
               printLine("# DCS Transport Chains")
               printLine("# Note: channels may be shared by different chains")
               
            printLine("# Cross-version placeholder\n%s.dcs.transportChains.%d.name = %s\n#" % (prefix,chainIdx,chainName)) 
      if (chainIdx > 0):
        printLine("\n%s.dcs.transportChains.count = %d" % (prefix,chainIdx))
      
      
      
      if (filterSettings.get("AdminService",1)):
        dumpAdminServices(prefix,server)
      
        printLine(" ")    
      #endif AdminService in filter settings
      
      
      if (isValidType("WorkAreaService") and filterSettings.get("WorkAreaService",1)):
        workAreaServiceId = AdminConfig.list("WorkAreaService",server)
        if (not isEmpty(workAreaServiceId)):
          printLine("# WorkAreaService")
          printSimpleProperties("%s.workAreaService.prop"%prefix,workAreaServiceId,printSimpleChildren=1,printPropertyAttributes=1)
      
      if (isValidType("WorkAreaPartitionService") and filterSettings.get("WorkAreaPartitionService",1)):
        wapServiceId = AdminConfig.list("WorkAreaPartitionService",server)
        if (not isEmpty(wapServiceId)):
          printLine("# WorkAreaPartitionService")
          printSimpleProperties("%s.workAreaPartitionService.prop"% prefix, wapServiceId,printSimpleChildren=1,
                                printListChildren=1,sortListChildren=1,
                                printPropertyAttributes=1,
                                identifierMap={"WorkAreaPartition":["name"] } )
          printLine("")
      
      
      if (isValidType("CEASettings") and filterSettings.get("CEASettings",1)):
        ceaSettingsId = AdminConfig.list("CEASettings",server)
        if (not isEmpty(ceaSettingsId)):
          printSimpleProperties("%s.CEASettings.prop" %prefix,ceaSettingsId,printSimpleChildren=1,printPropertyAttributes=1)
      
#enddef dumpApplicationServer

def dumpProxySettings(server,basePrefix,parmMap,skipList=None):
  try:
    filterSettings = getFilterSettings(parmMap)
    
    if (filterSettings.get("ProxyServer",1)):
      proxyServerId = AdminConfig.list("ProxyServer",server)
      if (not isEmpty(proxyServerId)):
        printSimpleProperties("%s.proxyServer.prop"%basePrefix,proxyServerId,optionalSkipList=skipList,printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1,useAttrNameWithProperties=1)
    
    if (filterSettings.get("ProxySettings",1)):
      proxySettingsId = AdminConfig.list("ProxySettings",server)
      if (not isEmpty(proxyServerId)):
        printSimpleProperties("%s.proxySettings.prop"%basePrefix,proxySettingsId,optionalSkipList=skipList,printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1,useAttrNameWithProperties=1)
      
  except:
    _app_message("Unexpected error in dumpProxySettings")

#-------------------------------------------------------------------------------
# dumpOnDemandRouter
#
# Writes out settings that are specific to the ODR. 
#-------------------------------------------------------------------------------
def dumpOnDemandRouter(server, basePrefix, parmMap ):
  try:
    filterSettings = getFilterSettings(parmMap)
    
    prefix = "%s.odr" % basePrefix
    
    if (filterSettings.get("HTTPS_PROXY_CHAIN",1) or filterSettings.get("HTTP_PROXY_CHAIN",1)):
      printLine("# On Demand Router Transport Chains")
      chainIdx = 0
      chainNameList = ["HTTPS_PROXY_CHAIN", "HTTP_PROXY_CHAIN"]
      for chainName in chainNameList:
        chain = findTransportChain(chainName,server)
        if (not isEmpty(chain)):
           chainIdx = chainIdx + 1
           dumpTransportChain("%s.transportChains.%d" % (prefix,chainIdx), chain)
      
    dumpProxySettings(server,prefix,parmMap,skipList=["routingPolicy","staticFileServingPolicy","workloadManagementPolicy"])
    
    nodeId = getNodeForServer(server)
    serverName = splitOffName(server)
    rules = AdminConfig.list("Rules",server)
    if (not isEmpty(rules)):
      ridx = 0
      rulelist = rules.splitlines()
      rulelist.sort()
      for ruleId in rulelist:
        if (isEmpty(ruleId)):
          continue
        ruleName = splitOffName(ruleId)
        ridx += 1
        rPrefix = "%s.rules.%d" % (prefix,ridx)
        printLine("%s.name = %s" % (rPrefix,ruleName))
        printSimpleProperties("%s.prop" % rPrefix,ruleId,["name"],printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1)
    
    #print "%s\n%s\n" % (server,nodeId)    
    workclasses = []
    if (not isEmpty(nodeId)):
      workclasses = AdminConfig.list("WorkClass",nodeId).splitlines()
    routingwc = []
    servicewc = []
    for wc in workclasses:
      if (isEmpty(wc)):
        continue
      tokens = wc.split("/")
      if serverName not in tokens:
        continue
      if ("routing" in tokens):
        routingwc.append(wc)
      if ("sla" in tokens):
        servicewc.append(wc)
    
    if (len(routingwc) > 0):
      wcidx = 0
      routingwc.sort()
      for wc in routingwc:
        wcidx += 1
        wcname = splitOffName(wc)
        wcPrefix = "%s.genericRouting.%d" % (prefix,wcidx)
        printLine("%s.name = %s" % (wcPrefix,wcname))
        printSimpleProperties("%s.prop" % wcPrefix,wc,["name"],printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1)
        
      if (wcidx > 0):
        printLine("%s.genericRouting.count = %d" % (prefix,wcidx))

    if (len(servicewc) > 0):
      wcidx = 0
      servicewc.sort()
      for wc in servicewc:
        wcidx += 1
        wcname = splitOffName(wc)
        wcPrefix = "%s.genericService.%d" % (prefix,wcidx)
        printLine("%s.name = %s" % (wcPrefix,wcname))
        printSimpleProperties("%s.prop" % wcPrefix,wc,["name"],printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1)        
        
      if (wcidx > 0):
        printLine("%s.genericRouting.count = %d" % (prefix,wcidx))
    
  except:
    _app_message("Problem in dumpOnDemandRouter","exception")
  
 



#-------------------------------------------------------------------------------------------------------------------
# dumpResourcesForApplicationServer
#-------------------------------------------------------------------------------------------------------------------
def dumpResourcesForApplicationServer(namePattern=None, targetServer=None, targetNode=None, wildcard="*",parmMap=None,serverList = None):
  
      if (not isEmpty(targetServer)):
        _app_message("Dumping resources associated with server %s/%s" % (targetNode,targetServer))
      elif (serverList != None):
        prtlist = [x for x in serverList if len(x) == 2]
        _app_message("Dumping resources associated with servers: %s" % prtlist)
      
      # As we print output, the PrintLineFilter will grab authentication alias
      plf = AuthenticationAliasPrintLineFilter()
      addPrintLineFilter(plf)

      
      dumpLibraries(pattern=namePattern,targetServer=targetServer,targetNode=targetNode,wildcard=wildcard,serverList=serverList)
      dumpVars(targetServer=targetServer,targetNode=targetNode,wildcard=wildcard,serverList=serverList)
      dumpJdbc(pattern=namePattern,targetServer=targetServer,targetNode=targetNode,serverList=serverList)
      dumpMQJMS(pattern=namePattern,targetServer=targetServer,targetNode=targetNode,wildcard=wildcard,serverList=serverList)
      
      #busList = listBusesWithClusterAsMembers(clusterNames)
      
      #dumpSIBus(busList=busList)
      dumpSIBJMS(pattern=namePattern,targetServer=targetServer,targetNode=targetNode,wildcard=wildcard,serverList=serverList)
      
      dumpGenericJMS(pattern=namePattern,targetServer=targetServer,targetNode=targetNode,parmMap=parmMap,serverList=serverList)
      
      dumpWorkManagers(targetNode=targetNode,targetServer=targetServer,wildcard=wildcard,serverList=serverList)
      dumpTimerManagers(targetNode=targetNode,targetServer=targetServer,wildcard=wildcard,serverList=serverList,parmMap=parmMap)
      dumpSchedulers(targetNode=targetNode,targetServer=targetServer,wildcard=wildcard,serverList=serverList)
      dumpMail(targetNode=targetNode,targetServer=targetServer,wildcard=wildcard,serverList=serverList)
      dumpURL(targetNode=targetNode,targetServer=targetServer,wildcard=wildcard,serverList=serverList)
      dumpJ2CResourceAdapters(targetNode=targetNode,targetServer=targetServer,wildcard=wildcard,serverList=serverList)
      dumpObjectCacheProviders(targetNode=targetNode,targetServer=targetServer,wildcard=wildcard,serverList=serverList)
      dumpResourceEnvironmentProviders(targetNode=targetNode,targetServer=targetServer,wildcard=wildcard,serverList=serverList)
      
      
      #applicationList = getApplicationsInClusters(clusterNames)
      #applicationList.sort()
      #dumpApplicationDeployment(applicationList)
      
      # Now we can do JAAS aliases
      removePrintLineFilter(plf)
      
      _app_message("The following JAAS aliases were identified: %s" % plf.getAliasList())
      dumpAuthSection(aliasNameList=plf.getAliasList(),parmMap=parmMap)


#------------------------------------------------------------------------------
# dumpStandaloneApplicationServers
#
# Used to print a list of non-clustered application server definitions
#------------------------------------------------------------------------------
def dumpStandaloneApplicationServers(namePattern=None, includeClusterMembers=0,targetServer=None,targetNode=None,targetCluster=None,parmMap=None,inputServerList=None):
  retval = []
  
  idx = 0
  #appserverlist = AdminConfig.list("ApplicationServer").split(SEPARATOR)
  serverlist = []
  serverTypes = getRequestedServerTypes(parmMap)
  getNodeAgents = 0
  getDmgr = 0
  getODR = 0
  getApplicationServers = 1
  printId = 0
  
  # Process the options
  if (parmMap != None):
    printId = parmMap.get("-printid",0)
    
    # Target server and target node could be passed in
    # options
    if (targetServer == None):
      targetServer = parmMap.get("-targetserver",None)
    if (targetNode == None):
      targetNode = parmMap.get("-targetnode",None)
    
    
    tempNode = parmMap.get("-nodeagents","false")
    if (tempNode == "false"):
      tempNode = parmMap.get("-nodeagent","false")
      
    tempDmgr = parmMap.get("-dmgr","false")
    tempODR = parmMap.get("-odr","false")
    getNodeAgents = (tempNode.lower() in ["true","-nodeagents","-nodeagent"])
    getDmgr = (tempDmgr.lower() in ["true","-dmgr"])
    getODR = (tempODR.lower() in ["true","-odr"])
    
    
    skipAppServer = parmMap.get("-skipappserver","false")
    getApplicationServers = (skipAppServer.lower() not in ["true","-skipappserver"])
  #end process options
  
  # Determine types of servers to support  
  if (getApplicationServers and "APPLICATION_SERVER" not in serverTypes):
    serverTypes.append("APPLICATION_SERVER")
  
  if (getDmgr and "DEPLOYMENT_MANAGER" not in serverTypes):
    serverTypes.append("DEPLOYMENT_MANAGER")
  
  if (getNodeAgents and "NODE_AGENT" not in serverTypes):
    serverTypes.append("NODE_AGENT")
  
  if (getODR and "ONDEMAND_ROUTER" not in serverTypes):
    serverTypes.append("ONDEMAND_ROUTER")
  
  if (inputServerList != None):
    serverlist = inputServerList
  else:
    for stype in serverTypes:
      tempList = AdminTask.listServers("-serverType %s" % stype)
      if (not isEmpty(tempList)):
        serverlist.extend(tempList.splitlines())
  
  # See if targetServer and node were specified in options:
  if (parmMap != None):
    if (targetServer == None):
      targetServer = parmMap.get("-targetserver",None)
    if (targetNode == None):
      targetNode = parmMap.get("-targetNode",None)
     
  for serverId in serverlist:
      
      if (not isEmpty(serverId)):
          #serverId = AdminConfig.showAttribute(app,"server")
          #if (isEmpty(serverId)):
          #    #print "Skipping %s because of missing server definition" % (app)
          #    continue
          
          #print "Processing serverId %s" % (serverId)
              
          serverName = AdminConfig.showAttribute(serverId,"name")
          serverType = AdminConfig.showAttribute(serverId,"serverType")
          

          #if (serverName == "dmgr" and serverName != namePattern and serverName != targetServer):
          #    continue
          
          if (not isEmpty(namePattern)):
            try:
              if (not re.match(namePattern,serverName)):
                continue
            except:
              pass
          
          isClusterMember = 0
          memberId = AdminConfig.getid("/ClusterMember:%s/" % serverName)
          
          
          if (not isEmpty(memberId)):
            if (not includeClusterMembers):
              continue
            else:
              isClusterMember = 1
              #print "%s" % memberId
              if (not isEmpty(targetCluster)):
                searchcluster = "/%s|" % targetCluster
                if (memberId.find(searchcluster) < 0):
                  continue
          elif (not isEmpty(targetCluster)):
            # We don't want standalone servers
            continue
          
          if ( (not isEmpty(targetServer)) and targetServer !=  serverName):
            continue
            
          
          serverNode = getNodeNameForServer(serverId)
          
          # This will block proxy and ODR 
          if isProxyServer(serverId):
            if (serverType != "ONDEMAND_ROUTER"):
              
              continue
          
          serverNode = getNodeNameForServer(serverId)
          
          if ( (not isEmpty(targetNode)) and targetNode != serverNode):
            continue
          
          if (isEmpty(serverNode)):
            # Must be a template
            continue
            
          # Add server node/name to return list
          retval.append([serverNode,serverName])
          
          # Add placeholder for node name
          if [serverNode] not in retval :
            retval.append([serverNode])
            
          
          # Ok, we have a real standalone application server
          idx += 1
          prefix = "app.appserver.%d" % (idx)
          
          if (not isClusterMember):
              printLine("#   Standalone Application Server %s on node %s" % (serverName, serverNode))
          else:
              printLine("#   Clustered Application Server %s on node %s" % (serverName, serverNode))
          
          if (printId):
            printLine("#   Source ID: %s" % serverId)
            
          printLine("%s.name = %s" % (prefix, serverName))
          printLine("%s.node = %s" % (prefix, serverNode))
          printLine("%s.serverType = %s" % (prefix, serverType))
          printLine("")
          printLine("#  Starting port : required ONLY FOR CUSTOM PORTS. Leave it blank for WebSphere defaults")
          printLine("#                : Set the startingport.keepHostNames to true to keep '*' and 'localhost' ports as is")
          printLine("%s.startingport = " %(prefix))
          printLine("%s.startingport.keepHostNames = false"% prefix)
          
          printLine("# Port values will be assigned only to new servers unless this setting is set to true")
          printLine("%s.processPortsOnExistingServer = false" % prefix)
          
          printLine("# If ports are set up, you can optionally specify the virtual host to add")
          printLine("# the ports as aliases to")
          printLine("%s.mapPortsToVirtualHost = " % prefix)
          
          dumpServerSDK(prefix,serverNode, serverName)
          
          dumpServerPorts(prefix,serverName,serverNode,parmMap=parmMap)
          
          if (serverType == "ONDEMAND_ROUTER"):
            dumpOnDemandRouter(serverId, prefix, parmMap )
            printLine("")
          
          dumpApplicationServer(prefix, serverId,parmMap)
  
  printLine(" ")
  printLine("app.appserver.count = %d" % (idx))
  printLine("#------------------------------------------------------------------------------")
  printLine("# Done with application server section")
  printLine("#------------------------------------------------------------------------------")
  
  return retval

#-------------------------------------------------------------------------
# dumpForeignServers
#-------------------------------------------------------------------------
def dumpForeignServers(**options):
  try:
    if (isValidTaskMethod("listForeignServerTypes")):
      ftypes = getForeignServerTypes()
    
    fidx = 0
    for ftype in ftypes:
      
      serverIds = AdminTask.listServers("-serverType %s" % ftype).splitlines()
      
      for serverId in serverIds:
        if (isEmpty(serverId)):
          continue
        fidx += 1
        
        if (fidx == 1):
          printLine("\n#-----------------------------------\n# Foreign Servers (Middleware servers)\n#-----------------------------------")
        
        printLine("")
          
        serverName = splitOffName(serverId)
        serverNode = getNodeNameForServer(serverId)
        prefix = "app.foreignservers.%d" % fidx
        printLine("%s.name = %s" % (prefix,serverName))
        printLine("%s.node = %s" % (prefix,serverNode))
        printLine("%s.type = %s" % (prefix,ftype))
        printSimpleProperties("%s.prop" % prefix,serverId,["name"])
        dumpExternalServer(serverId,prefix)
    if (fidx > 0):
      printLine("app.foreignservers.count = %d" % fidx)    
      
  except:
    _app_message("Unexpected problem in dumpForeignServers")


#------------------------------------------------------------------------------
def isProxyServer(serverId):
	retval = 0
	
	try:
		pslist = AdminConfig.list("ProxyServer", serverId)
		if (not isEmpty(pslist)):
				retval = 1
	except:
		# Might be 6.1
		retval = 0		

	return retval			
	

#------------------------------------------------------------------------------
# dumpClusterServerAsTemplate
#
# This function will create a property file with a cluster template definition for
# the specified cluster. The settings for the template will be pulled from the specified
# server/node parameters.  If the "-any" or "ANY" parameter is passed in for the serverName or 
# nodeName parameters, the first server in the list of cluster members will be used.
# 
# Note that this function adds the clusterTemplate.overrideSettings = true setting
# to the property file, which when processed by updateEnvironment script will cause 
# custom properties and JVM generic args to be replaced instead of merged.
#------------------------------------------------------------------------------
def dumpClusterServerAsTemplate(clusterName, serverName, nodeName=None,parmMap=None):
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# Cluster Section")
	printLine("#")
	printLine("#------------------------------------------------------------------------------")
	printLine("#")

	clusterId = 0
	prefix="app.cluster"
	
	if (serverName == "-any" or serverName == "ANY" or nodeName == "-any" or nodeName == "ANY"):
			clusterMembers = AdminConfig.list("ClusterMember").split(SEPARATOR)
			for clusterMember in clusterMembers :
				if (isEmpty(clusterMember)):
						continue
				serverName = AdminConfig.showAttribute(clusterMember,"memberName")
				nodeName = AdminConfig.showAttribute(clusterMember,"nodeName")
				break
	
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# Cluster template settings pulled from server %s on node %s " % (serverName, nodeName))
	printLine("#------------------------------------------------------------------------------")
	printLine(" ")
	cluster = AdminConfig.getid("/ServerCluster:%s/" % clusterName)
	serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (nodeName, serverName))
	
	if (not isEmpty(cluster) and not isEmpty(serverId)):
						
		clusterId = clusterId + 1
		printLine("#------------------------------------------------------------------------------")
		printLine("# Cluster %d Section" % clusterId)
		printLine("#")
		printLine("#------------------------------------------------------------------------------")
		printLine("#	Cluster Properties")

		clusterName = AdminConfig.showAttribute(cluster, "name")
		printLine("%s.%d.name = %s" % (prefix, clusterId, clusterName))
		printLine("%s.%d.preferlocal = %s" % (prefix, clusterId, AdminConfig.showAttribute(cluster, "preferLocal")))
		repdomain = AdminConfig.getid("/DataReplicationDomain:%s/" % clusterName)
		createDomain = "false"
		if (not isEmpty(repdomain)):
				createDomain = "true"
		printLine("%s.%d.createDomain = %s" % (prefix, clusterId, createDomain))
		printLine(" ")
		printLine("# Cluster starting port is used as seed value for cluster members if ")
		printLine("# they use the @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} macro.")
		printLine("%s.%d.startingport = " % (prefix, clusterId))
		printLine(" ")
		printLine("# This optional setting controls which virtual host the servers")
		printLine("# HTTP/HTTPS ports will be added to as host aliases to the Virtual Host specified here")
		printLine("%s.%d.mapPortsToVirtualHost =" % (prefix, clusterId))
				
				
		printLine(" ")
		

		
		searchName = "templates/clusters/%s/servers" % (clusterName)
		templateId = AdminConfig.listTemplates("Server",searchName)
		templateList = wsadminToList(templateId)
		if (len(templateList) > 0):
			printLine(" ")
			printLine("# Cluster template ")
			printLine("# You can choose to update the clusters template file as well as applying the ")
			printLine("#    settings in this section all existing servers in the template or just to")
			printLine("#    the new members in the cluster")
			printLine("#    These updates will only be done if the cluster already exists ")
			printLine("%s.%d.clusterTemplate.updateTemplate = true" % (prefix, clusterId))
			printLine("%s.%d.clusterTemplate.applyTemplateSettingsToExistingMembers = false" % (prefix, clusterId))
			printLine("%s.%d.clusterTemplate.applyTemplateSettingsToNewMembers = false" % (prefix, clusterId))
			
			printLine(" ")
			printLine("# The override settings flag changes processing of custom/env/system properties in the")
			printLine("# server definition as well as genericJVMArguments.  Any existing settings will be removed")
			printLine("# Use with caution")
			printLine("%s.%d.clusterTemplate.overrideSettings = true" % (prefix,clusterId))
			printLine(" ")
			
			dumpApplicationServer( "%s.%d.clusterTemplate" % (prefix,clusterId), serverId,parmMap)
		printLine(" ")

		printLine("app.cluster.count = %d" % clusterId)
	else:
		print "Error: Invalid cluster or server specified: %s %s %s" % (clusterName, serverName, nodeName)
		raise StandardError("Error: Invalid cluster or server specified: %s %s %s" % (clusterName, serverName, nodeName))

#enddef dumpClusterServerAsTemplate

#------------------------------------------------------------------------------
# dumpVariableClusterTemplate
#
#------------------------------------------------------------------------------
def dumpVariableClusterTemplate(parmMap):
  printLine(" ")
  printLine("#------------------------------------------------------------------------------")
  printLine("# Variable Cluster Definition")
  printLine("#")
  printLine("#------------------------------------------------------------------------------")
  printLine("#")

  clusterId = 0
  prefix="app.cluster"
  
  varPrefix = parmMap.get("-varPrefix","#")
  
  clusterName = parmMap.get("-sourceCluster","")
  if (isEmpty(clusterName)):
    clusterName = parmMap.get("-cluster","")
    
  serverName = parmMap.get("-sourceServer","-any")
  nodeName = parmMap.get("-sourceNode","-any")
  
  targetNodes = parmMap.get("-targetNodes","")
  if (targetNodes == "VAR"):
    targetNodes =  "%s{NEW_CLUSTER_NODES}" % varPrefix
  targetPerNode = parmMap.get("-targetPerNode","")
  if (targetPerNode == "VAR"):
    targetPerNode = "%s{NEW_CLUSTER_PER_NODE}" % varPrefix
  targetServers = parmMap.get("-targetServers","")
  if (targetServers == "VAR"):
    targetServers = "%s{NEW_CLUSTER_SERVERS}" % varPrefix
    
  targetServerCount = parmMap.get("-targetServerCount","")
  if (targetServerCount == "VAR"):
    targetServerCount = "#{NEW_CLUSTER_SERVER_COUNT}"
    
  targetStartingPort = parmMap.get("-targetStartingPort","")
  if (targetStartingPort == "VAR"):
    targetStartingPort = "#{STARTING_PORT}"
  
  targetMemberPrefix = parmMap.get("-targetMemberPrefix","")
  if (not isEmpty(targetMemberPrefix)):
    targetMemberName = "%s_@{DYNAMIC#KEYWORD#NODE_IDX}_@{DYNAMIC#KEYWORD#NODE_MEMBER_IDX}" % targetMemberPrefix
  else:
    targetMemberName = parmMap.get("-targetMemberName","MEMBER_@{DYNAMIC#KEYWORD#NODE_IDX}_@{DYNAMIC#KEYWORD#NODE_MEMBER_IDX}")
    
  
  
  targetClusterName = parmMap.get("-targetCluster","#{NEW_CLUSTER_NAME}")
  
  
  includeClusterMemberSettings = parmMap.get("-includeClusterMemberSettings","false")
  
  if (serverName == "-any" or serverName == "ANY" or nodeName == "-any" or nodeName == "ANY"):
      clusterMembers = AdminConfig.list("ClusterMember",AdminConfig.getid("/ServerCluster:%s/"%clusterName)).split(SEPARATOR)
      for clusterMember in clusterMembers :
        if (isEmpty(clusterMember)):
            continue
        serverName = AdminConfig.showAttribute(clusterMember,"memberName")
        nodeName = AdminConfig.showAttribute(clusterMember,"nodeName")
        break
  
  printLine(" ")
  printLine("#------------------------------------------------------------------------------")
  printLine("# Cluster template settings pulled from server %s on node %s " % (serverName, nodeName))
  printLine("#------------------------------------------------------------------------------")
  printLine(" ")
  cluster = AdminConfig.getid("/ServerCluster:%s/" % clusterName)
  serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (nodeName, serverName))
  
  if (not isEmpty(cluster) and not isEmpty(serverId)):
            
    clusterId = clusterId + 1
    printLine("#------------------------------------------------------------------------------")
    printLine("# Cluster %d Section" % clusterId)
    printLine("#")
    printLine("#------------------------------------------------------------------------------")
    printLine("#  Cluster Properties")

    
    printLine("%s.%d.name = %s" % (prefix, clusterId, targetClusterName))
    printLine("%s.%d.preferlocal = %s" % (prefix, clusterId, AdminConfig.showAttribute(cluster, "preferLocal")))
    repdomain = AdminConfig.getid("/DataReplicationDomain:%s/" % clusterName)
    createDomain = "false"
    if (not isEmpty(repdomain)):
        createDomain = "true"
    printLine("%s.%d.createDomain = %s" % (prefix, clusterId, createDomain))
    printLine(" ")
    printLine("# Cluster starting port is used as seed value for cluster members if ")
    printLine("# they use the @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} macro.")
    printLine("%s.%d.startingport = %s" % (prefix, clusterId,targetStartingPort))
    printLine(" ")
    printLine("# This optional setting controls which virtual host the servers")
    printLine("# HTTP/HTTPS ports will be added to as host aliases")
    printLine("%s.%d.mapPortsToVirtualHost =" % (prefix, clusterId))
        
        
    printLine(" ")
    

    
    
    printLine(" ")
    printLine("# Cluster template ")
    printLine("# You can choose to update the clusters template file as well as applying the ")
    printLine("#    settings in this section all existing servers in the template or just to")
    printLine("#    the new members in the cluster")
    printLine("#    These updates will only be done if the cluster already exists ")
    printLine("%s.%d.clusterTemplate.updateTemplate = true" % (prefix, clusterId))
    printLine("%s.%d.clusterTemplate.applyTemplateSettingsToExistingMembers = false" % (prefix, clusterId))
    printLine("%s.%d.clusterTemplate.applyTemplateSettingsToNewMembers = true" % (prefix, clusterId))
      
    printLine(" ")
    printLine("# The override settings flag changes processing of custom/env/system properties in the")
    printLine("# server definition as well as genericJVMArguments.  Any existing settings will be removed")
    printLine("# Use with caution")
    printLine("%s.%d.clusterTemplate.overrideSettings = false" % (prefix,clusterId))
    printLine(" ")
      
    dumpApplicationServer( "%s.%d.clusterTemplate" % (prefix,clusterId), serverId,parmMap)
    printLine(" ")
    
    printLine("%s.%d.variableMembers = true" % (prefix,clusterId))
    
    if (isEmpty(targetServers)):
      printLine("# You can list specific servers using this syntax")
      printLine("# %s.%d.variableMembers.servers = Node1/Server_1_1 Node1/Server_1_2 Node2/Server_2_1"% (prefix,clusterId))
    else:
      printLine("# You can list specific servers using this syntax")
      printLine("%s.%d.variableMembers.servers = %s"% (prefix,clusterId,targetServers))
      
    
    printLine("#")
    printLine("# You can configure variable node names with this syntax")
    
    if (isEmpty(targetPerNode)):
      printLine("# %s.%d.variableMembers.perNode = 3" % (prefix,clusterId))
    else:
      printLine("%s.%d.variableMembers.perNode = %s" % (prefix,clusterId,targetPerNode))
    
    if (isEmpty(targetNodes)):
      printLine("# %s.%d.variableMembers.nodes = Node1 Node2 Node3 Node4" %  (prefix,clusterId)) 
    else:
      printLine("%s.%d.variableMembers.nodes = %s" %  (prefix,clusterId,targetNodes)) 
      
    if (targetServerCount):
      printLine("%s.%d.variableMembers.serverCount = %s" %  (prefix,clusterId,targetServerCount)) 

    printLine("# If names are generated, the following dyanmic fields will be populated")
    printLine("%s.%d.clustermember.1.name = %s" % (prefix,clusterId,targetMemberName))
    printLine("%s.%d.clustermember.1.node = PLACEHOLDER" % (prefix,clusterId))
    printLine("#%s.%d.clustermember.1.weight = 4" % (prefix,clusterId))
    
    if (targetStartingPort):
      printLine("%s.%d.clustermember.1.startingport = @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT}" % (prefix, clusterId))
      printLine("%s.%d.clustermember.1.startingport.keepHostNames = false" % (prefix,clusterId))
    
    if (includeClusterMemberSettings.lower() == "true"):
      dumpApplicationServer( "%s.%d.clustermember.1" % (prefix,clusterId), serverId,parmMap)
    
    

    printLine("app.cluster.count = %d" % clusterId)
  else:
    print "Error: Invalid cluster or server specified: %s %s %s" % (clusterName, serverName, nodeName)
    raise StandardError("Error: Invalid cluster or server specified: %s %s %s" % (clusterName, serverName, nodeName))

#-------------------------------------------------------------------------------
# createClusterDefinitionFromTemplate(parmMap)
# 
# Utility function that can be used to create a cluster definition file from
# an application server template. The file can then be used to compare against an
# existing definition or to create a new cluster
#-------------------------------------------------------------------------------
def createClusterDefinitionFromTemplate(parmMap):
  try:
    templateName = parmMap.get("-templatename","default")
    memberCount = int(parmMap.get("-membercount",1))
    
    
    templateParms = "[ -name '%s' -serverType APPLICATION_SERVER ]" % templateName
    
    templateList= AdminTask.listServerTemplates(templateParms).splitlines()
  
    if (len(templateList) == 0 or isEmpty(templateList[0])):
      _app_message("Unable to find match for APPLICATION_SERVER template %s" % templateName)
      return
    templateId = templateList[0]
    
    
    
    printLine("# Building cluster definition from template %s " % templateId)
    printLine("# Number of members: %d" % memberCount)
    
    printLine(" " )
    printLine("#------------------------------------------------------------------------------")
    printLine("# Cluster Section")
    printLine("#")
    printLine("#------------------------------------------------------------------------------")
    printLine("#")    

    clusterId = 1
    printLine("#------------------------------------------------------------------------------")
    printLine("# Cluster %d Section" % clusterId)
    printLine("#")
    printLine("#------------------------------------------------------------------------------")
    printLine("#  Cluster Properties")  
    
    prefix="app.cluster"
    clusterName = "GeneratedFromTemplate:%s" % templateName
    printLine("%s.%d.name = %s" % (prefix, clusterId, clusterName))
    printLine("%s.%d.preferlocal = true" % (prefix, clusterId))
    printLine("%s.%d.createDomain = false" % (prefix, clusterId))
    printLine(" ")

    printLine(" ")
    printLine("# Cluster starting port is used as seed value for cluster members if ")
    printLine("# they use the @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} macro.")
    printLine("%s.%d.startingport = " % (prefix, clusterId))
    printLine(" ")
    printLine("# This optional setting controls which virtual host the servers")
    printLine("# HTTP/HTTPS ports will be added to as host aliases to the Virtual Host specified here")
    printLine("%s.%d.mapPortsToVirtualHost =" % (prefix, clusterId))    

    printLine(" ")
    printLine("# Cluster template ")
    printLine("# You can choose to update the clusters template file as well as applying the ")
    printLine("#    settings in this section all existing servers in the template or just to")
    printLine("#    the new members in the cluster")
    printLine("#    These updates will only be done if the cluster already exists ")
    printLine("%s.%d.clusterTemplate.updateTemplate = false" % (prefix, clusterId))
    printLine("%s.%d.clusterTemplate.applyTemplateSettingsToExistingMembers = false" % (prefix, clusterId))
    printLine("%s.%d.clusterTemplate.applyTemplateSettingsToNewMembers = false" % (prefix, clusterId))
    dumpApplicationServer( "%s.%d.clusterTemplate" % (prefix,clusterId), templateId, parmMap)
    
    for memberId in range(1,memberCount+1):

      printLine("%s.%d.clustermember.%d.name = GeneratedMember_%d" % (prefix, clusterId, memberId, memberId))
      printLine("%s.%d.clustermember.%d.node = GeneratedNode_%d" % (prefix, clusterId, memberId, memberId))
      printLine(" ")
      printLine("#  Starting port : required ONLY FOR CUSTOM PORTS. Leave it blank for WebSphere defaults")
      printLine("#  Enter a specific number or @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} if you specified")
      printLine("#  a value for the cluster's startingport")
      printLine("#  Set startingport.keepHostNames to true to avoid renaming of '*' or 'localhost' ports")
      printLine("%s.%d.clustermember.%d.startingport = " % (prefix, clusterId, memberId))
      printLine("%s.%d.clustermember.%d.startingport.keepHostNames = false" % (prefix, clusterId, memberId))
      printLine(" ")
      printLine("#  Weight : Uncomment to change the load balance weight. Leave it blank for defaults")
      printLine("%s.%d.clustermember.%d.weight = %s" % (prefix, clusterId, memberId, "2"))
      printLine(" ")
      
      printLine("# Optional settings for first member creation:")      
      printLine("#  Use (WAS-defined) default template or node/server as a template")
      printLine("#  or leave all 3 blank for WAS default app server")
      printLine("%s.%d.clustermember.%d.defaulttemplate = " % (prefix, clusterId, memberId))
      printLine("%s.%d.clustermember.%d.templatenode = " % (prefix, clusterId, memberId))
      printLine("%s.%d.clustermember.%d.templateserver = " % (prefix, clusterId, memberId))
      printLine(" ")      
      
      # @JJM - Call common routine for formatting application server
      dumpApplicationServer("%s.%d.clustermember.%d" % (prefix, clusterId, memberId),templateId,parmMap)
      
    printLine("app.cluster.1.clustermember.count = %d" % memberId)

    printLine("\n#------------------------------------------------------------------------------")
    printLine("#  Number of Clusters to create")
    printLine("app.cluster.count = 1")
    printLine("#------------------------------------------------------------------------------")
                  
  except:
    _app_message("Unexpected error in createClusterDefinitionFromTemplate","exception")
  


#-------------------------------------------------------------------------------
# dumpDynamicClusterSection
#
# Used to export property definitions of Dynamic Clusters
#-------------------------------------------------------------------------------
def dumpDynamicClusterSection(dynamicClusterList, specificCluster = None,specificServer = None,printTemplates="true",parmMap=None):
  
  if (parmMap == None):
    parmMap = {}
    
  printLine(" ")
  printLine(" " )
  printLine("#------------------------------------------------------------------------------")
  printLine("# Dynamic Cluster Section")
  printLine("#")
  printLine("#------------------------------------------------------------------------------")
  printLine("#")
  
  dynCount = 0
  serverTypes = getRequestedServerTypes(parmMap)
  
  for clusterName in dynamicClusterList:
    
    if (specificCluster != None):
        if (specificCluster.find("*") >= 0):
          # Use regular expression
          try:
            if (not re.match(specificCluster,clusterName)):
              continue
          except:
            print "Error matching against regular expression %s" % specificCluster
        elif (clusterName != specificCluster):
            continue
    
    clusterServerType = "APPLICATION_SERVER"
    if (isValidTaskMethod("getDynamicClusterServerType")):
      clusterServerType = AdminTask.getDynamicClusterServerType(clusterName)
    
    if (len(serverTypes) > 0 and clusterServerType not in serverTypes):
      continue
    
    isForeign = 0
    if clusterServerType in getForeignServerTypes():
      isForeign = 1
      
    if (not isForeign and parmMap != None and 
        (parmMap.get("-foreign","false") == "true" or parmMap.get("-foreign","false") == "-foreign")):
      # Skipping application server dynamic cluster
      
      continue
     
    dynCount +=1 
    
    prefix = "app.dyncluster.%d" % dynCount
    
    printLine(" ")
    printLine("%s.name = %s" % (prefix, clusterName))
    printLine("%s.serverType = %s" % (prefix,clusterServerType))
    
      
    
    cluster =  AdminConfig.getid("/ServerCluster:%s/" % clusterName)
    
    dynamicClusterId = AdminConfig.getid("/DynamicCluster:%s/" % clusterName)
    
    
    if (not isForeign):
      printLine("%s.preferlocal = %s" % (prefix, AdminConfig.showAttribute(cluster, "preferLocal")))
      repdomain = AdminConfig.getid("/DataReplicationDomain:%s/" % clusterName)
      createDomain = "false"
      if (not isEmpty(repdomain)):
        createDomain = "true"
      printLine("%s.createDomain = %s" % (prefix, createDomain))    
    
      printLine("\n#templateName is either default or cell_name/node_name/was_server_name and is used\n#when creating dynamic cluster")
      printLine("%s.templateName =\n" % prefix)
    
    cluster =  AdminConfig.getid("/ServerCluster:%s/" % clusterName)
    
    dynamicClusterId = AdminConfig.getid("/DynamicCluster:%s/" % clusterName)
    
    printSimpleProperties("%s.dc.prop" % prefix, dynamicClusterId, ["name"])
    printCustomProperties("%s.dc.properties" % prefix , dynamicClusterId, "properties")
    printLine(" ")
    
    printLine(" ")
    
    if (not isForeign):
      printLine("# Cluster starting port is used as seed value for cluster members if ")
      printLine("# they use the @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} macro.")
      printLine("%s.startingport = " % (prefix))
      printLine(" ")
      printLine("# This optional setting controls which virtual host the servers")
      printLine("# HTTP/HTTPS ports will be added to as host aliases to the Virtual Host specified here")
      printLine("%s.mapPortsToVirtualHost =" % (prefix))
        
      printLine(" ")
      
      printLine("# These settings control the processing of the clustermember sections. In most cases ")
      printLine("# applying the clusterTemplate settings to the cluster members is enough, but if you ")
      printLine("# have individualized settings on the cluster members (such as ports), then you'll need")
      printLine("# enable the processing ")
      printLine("%s.processAllClusterMemberPorts = false" % prefix)
      printLine("%s.processAllClusterMemberDefinitions = false" %prefix)
      printLine("%s.processNewClusterMemberDefinitions = false" % prefix)
      printLine(" ")   
    
    
    if ((not isForeign) and isEmpty(specificServer) and printTemplates == "true"):
      templateId = AdminConfig.getid("/DynamicCluster:%s/Server:%s/" % (clusterName,clusterName))
      printLine(" ")
      printLine("# Cluster template ")
      printLine("# You can choose to update the clusters template file as well as applying the ")
      printLine("#    settings in this section all existing servers in the template or just to")
      printLine("#    the new members in the cluster")
      printLine("#    ")
      printLine("%s.clusterTemplate.updateTemplate = true" % (prefix))
      printLine("%s.clusterTemplate.applyTemplateSettingsToExistingMembers = false" % (prefix))
      printLine("%s.clusterTemplate.applyTemplateSettingsToNewMembers = true" % (prefix))
      
      if (clusterServerType == "ONDEMAND_ROUTER"):
        dumpOnDemandRouter(templateId, "%s.clusterTemplate" % prefix, parmMap )
        printLine("")

      
      dumpApplicationServer( "%s.clusterTemplate" % (prefix), templateId, parmMap)
    
    memberList = []
    if (isForeign):
      memberList = wsadminToList(AdminConfig.showAttribute(dynamicClusterId,"members"))
    else:
      memberList = wsadminToList(AdminConfig.showAttribute(cluster,"members"))

    memberId = 0
    for member in memberList:
      
      # See if we are searching for a specific server
      if (not isEmpty(specificServer)):
        tempName = AdminConfig.showAttribute(member,"memberName")
        if (specificServer.find("*") >= 0):
          # Use regular expression
          #print specificServer
          try:
            if (not re.match(specificServer,tempName)):
              continue
            #print "Matched %s" % tempName
          except:
            print "Error matching against regular expression %s" % specificServer
        elif (tempName != specificServer):
            continue

        
        
      memberId = memberId + 1
      memberName = AdminConfig.showAttribute(member,"memberName")
      nodeName = AdminConfig.showAttribute(member,"nodeName")
      printLine("%s.clustermember.%d.name = %s" % (prefix,  memberId, memberName))
      printLine("%s.clustermember.%d.node = %s" % (prefix,  memberId, nodeName))
      printLine(" ")
      
      if (not isForeign):
        printLine("#  Starting port : required ONLY FOR CUSTOM PORTS. Leave it blank for WebSphere defaults")
        printLine("#  Enter a specific number or @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} if you specified")
        printLine("#  a value for the cluster's startingport")
        printLine("#  Set the startingport.keepHostNames to true to keep '*' and 'localhost' ports as is")

        printLine("%s.clustermember.%d.startingport = " % (prefix,  memberId))
        printLine("%s.clustermember.%d.startingport.keepHostNames = false" % (prefix,  memberId))
        printLine(" ")
        
        dumpServerPorts("%s.clustermember.%d" % (prefix,memberId),memberName,nodeName,parmMap=parmMap)
        
      printLine("#  Weight : Uncomment to change the load balance weight. Leave it blank for defaults")
      printLine("%s.clustermember.%d.weight = %s" % (prefix, memberId, AdminConfig.showAttribute(member,"weight")))
      printLine(" ")
      
      if (not isForeign):
        printLine("#  Use (WAS-defined) default template or node/server as a template")
        printLine("#  or leave all 3 blank for WAS default app server")
        printLine("%s.clustermember.%d.defaulttemplate = " % (prefix,  memberId))
        printLine("%s.clustermember.%d.templatenode = " % (prefix,  memberId))
        printLine("%s.clustermember.%d.templateserver = " % (prefix,  memberId))
        printLine(" ")
      
      if (not isForeign):
        dumpServerSDK("%s.clustermember.%d" % (prefix, memberId), nodeName, memberName)

      server = AdminConfig.getid("/Node:%s/Server:%s" % (AdminConfig.showAttribute(member,"nodeName"),AdminConfig.showAttribute(member,"memberName")))
     
      # @JJM - Call common routine for formatting application server
      skipMemberDetails = parmMap.get("-skipMemberDetails","false")
      #print "%s\n%s" % (skipMemberDetails,parmMap)
      if (skipMemberDetails != "-skipMemberDetails" and skipMemberDetails != "true"):
        if (not isForeign):
          
          if (clusterServerType == "ONDEMAND_ROUTER"):
            dumpOnDemandRouter(server, "%s.clustermember.%d" % (prefix, memberId), parmMap )
            printLine("")
                    
          dumpApplicationServer("%s.clustermember.%d" % (prefix, memberId),server,parmMap)
        else:
          dumpExternalServer(server, "%s.clustermember.%d" % (prefix,memberId))
          printLine("")

    printLine("")
    printLine("%s.clustermember.count = %d" % (prefix, memberId))
    
  if (dynCount > 0):
    
    printLine("\napp.dyncluster.count = %d" % dynCount  )
    
  
#enddef dumpDynamicClusterSection


#------------------------------------------------------------------------------
def dumpClusterSection(specificCluster = None,specificServer = None,printTemplates="true",parmMap=None):
  
  #print "In dumpClusterSection %s" % parmMap
  filterSettings = getFilterSettings(parmMap)
  
  dynamicClusterList = []
  dynamicClusters = ""
  try:
    if (isValidTaskMethod("listDynamicClusters")):
      try:
        dynamicClusters = AdminTask.listDynamicClusters()
      except:
        pass
      
    #print dynamicClusters
    if (not isEmpty(dynamicClusters)):
      dynamicClusterList = dynamicClusters.splitlines()
      dynamicClusterList.sort()
      #print dynamicClusterList
      if (len(dynamicClusterList) > 0):
        dumpDynamicClusterSection(dynamicClusterList,specificCluster,specificServer,printTemplates,parmMap=parmMap)
        
        if (parmMap != None):
          if parmMap.get("-dynamiconly","not") == "-dynamiconly":
            # Do not print out other clusters
            return
          
          if (parmMap.get("-foreign","false") == "true" or 
              parmMap.get("-foreign","false") == "-foreign"):
                # Do not print out other clusters
                return
           
         
        
  except:
    _app_message("Exception !!!","exception")
    pass

  printLine(" " )
  printLine("#------------------------------------------------------------------------------")
  printLine("# Cluster Section")
  printLine("#")
  printLine("#------------------------------------------------------------------------------")
  printLine("#")
  
  clusterId = 0
  prefix="app.cluster"
  clusters = AdminConfig.list('ServerCluster').split(SEPARATOR)
  clusters.sort()
  for cluster in clusters:
    if (isEmpty(cluster)):continue
    clusterName = AdminConfig.showAttribute(cluster, "name")
    if (clusterName in dynamicClusterList):
      continue
      
    if (specificCluster != None):
        
        if (specificCluster.find("*") >= 0):
          # Use regular expression
          try:
            if (not re.match(specificCluster,clusterName)):
              continue
          except:
            print "Error matching against regular expression %s" % specificCluster
        elif (clusterName != specificCluster):
            continue
            
    clusterId = clusterId + 1
    printLine("#------------------------------------------------------------------------------")
    printLine("# Cluster %d Section" % clusterId)
    printLine("#")
    printLine("#------------------------------------------------------------------------------")
    printLine("#  Cluster Properties")

    clusterName = AdminConfig.showAttribute(cluster, "name")
    printLine("%s.%d.name = %s" % (prefix, clusterId, clusterName))
    printLine("%s.%d.preferlocal = %s" % (prefix, clusterId, AdminConfig.showAttribute(cluster, "preferLocal")))
    repdomain = AdminConfig.getid("/DataReplicationDomain:%s/" % clusterName)
    createDomain = "false"
    if (not isEmpty(repdomain)):
        createDomain = "true"
    printLine("%s.%d.createDomain = %s" % (prefix, clusterId, createDomain))
    printLine(" ")
    
    printLine("# ServerCluster properties")
    collectDict={}
    printSimpleProperties("%s.%d.prop"%(prefix,clusterId),cluster, optionalSkipList=["members","name"],includeBlanks=0,printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,useAttrNameWithProperties=1,includeReferenceChildren=0,printListChildren=1,
                          printChildType=1,collectDict=collectDict)

    if (isValidType("PMEClusterExtension")):
      clusterExtension = AdminConfig.getid("/ServerCluster:%s/PMEClusterExtension:/" % clusterName)
      if (not isEmpty(clusterExtension)):
          printSimpleProperties("%s.%d.PMEClusterExtension.prop"%(prefix,clusterId),clusterExtension, optionalSkipList=None,includeBlanks=0,printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,useAttrNameWithProperties=1,includeReferenceChildren=0,printListChildren=1,
                          printChildType=0,collectDict=collectDict)
      

    if (isValidType("CEASettings") and filterSettings.get("CEASettings",1)):
      ceaSettingsId = AdminConfig.list("CEASettings",cluster)
      if (not isEmpty(ceaSettingsId)):
        printLine(" ")
        printSimpleProperties("%s.%d.CEASettings.prop" %(prefix,clusterId),ceaSettingsId,printSimpleChildren=1,printPropertyAttributes=1)
      
    printLine(" ")
    printLine("# Cluster starting port is used as seed value for cluster members if ")
    printLine("# they use the @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} macro.")
    printLine("%s.%d.startingport = " % (prefix, clusterId))
    printLine(" ")
    printLine("# This optional setting controls which virtual host the servers")
    printLine("# HTTP/HTTPS ports will be added to as host aliases to the Virtual Host specified here")
    printLine("%s.%d.mapPortsToVirtualHost =" % (prefix, clusterId))
        
    memberList = wsadminToList(AdminConfig.showAttribute(cluster,"members"))
    
    # Determine resources scope by looking for server scoped WorkManager
    resourcesScope = ""
    for member in memberList:
      if isEmpty(member):
        break
      else:
        
        tempMember =  AdminConfig.showAttribute(member,"memberName")
        tempNode = AdminConfig.showAttribute(member,"nodeName")
        
        wmId = AdminConfig.getid("/Node:%s/Server:%s/WorkManagerProvider:WorkManagerProvider/WorkManagerInfo:DefaultWorkManager/" % (tempNode,tempMember))
        
        if (isEmpty(wmId)):
          resourcesScope = "cluster"
        else:
          resourcesScope = "server"
      
      break
        
        
    printLine(" ")
    printLine("# Used with first member creation")
    printLine("%s.%d.resourcesScope = %s" % (prefix,clusterId,resourcesScope))
    printLine(" ")
    
    
    if (printTemplates == "true"):
      searchName = "templates/clusters/%s/servers" % (clusterName)
      templateId = AdminConfig.listTemplates("Server",searchName)
      templateList = wsadminToList(templateId)
      if (len(templateList) > 0):
        printLine(" ")
        printLine("# Cluster template ")
        printLine("# You can choose to update the clusters template file as well as applying the ")
        printLine("#    settings in this section all existing servers in the template or just to")
        printLine("#    the new members in the cluster")
        printLine("#    These updates will only be done if the cluster already exists ")
        printLine("%s.%d.clusterTemplate.updateTemplate = false" % (prefix, clusterId))
        printLine("%s.%d.clusterTemplate.applyTemplateSettingsToExistingMembers = false" % (prefix, clusterId))
        printLine("%s.%d.clusterTemplate.applyTemplateSettingsToNewMembers = false" % (prefix, clusterId))
        dumpApplicationServer( "%s.%d.clusterTemplate" % (prefix,clusterId), templateList[0], parmMap)
      printLine(" ")

    memberList = wsadminToList(AdminConfig.showAttribute(cluster,"members"))

    memberId = 0
    for member in memberList:
      
      # See if we are searching for a specific server
      if (not isEmpty(specificServer)):
        tempName = AdminConfig.showAttribute(member,"memberName")
        if (specificServer.find("*") >= 0):
          # Use regular expression
          #print specificServer
          try:
            if (not re.match(specificServer,tempName)):
              continue
            #print "Matched %s" % tempName
          except:
            print "Error matching against regular expression %s" % specificServer
        elif (tempName != specificServer):
            continue

        
        
      memberId = memberId + 1

      printLine("%s.%d.clustermember.%d.name = %s" % (prefix, clusterId, memberId, AdminConfig.showAttribute(member,"memberName")))
      printLine("%s.%d.clustermember.%d.node = %s" % (prefix, clusterId, memberId, AdminConfig.showAttribute(member,"nodeName")))
      printLine(" ")
      printLine("#  Starting port : required ONLY FOR CUSTOM PORTS. Leave it blank for WebSphere defaults")
      printLine("#  Enter a specific number or @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} if you specified")
      printLine("#  a value for the cluster's startingport")
      printLine("#  Set startingport.keepHostNames to true to avoid renaming of '*' or 'localhost' ports")
      printLine("%s.%d.clustermember.%d.startingport = " % (prefix, clusterId, memberId))
      printLine("%s.%d.clustermember.%d.startingport.keepHostNames = false" % (prefix, clusterId, memberId))
      printLine(" ")
      printLine("#  Weight : Uncomment to change the load balance weight. Leave it blank for defaults")
      printLine("%s.%d.clustermember.%d.weight = %s" % (prefix, clusterId, memberId, AdminConfig.showAttribute(member,"weight")))
      printLine(" ")
      
      printLine("# Optional settings for first member creation:")
      printLine("#  Use (WAS-defined) default template or node/server as a template")
      printLine("#  or leave all 3 blank for WAS default app server")
      printLine("%s.%d.clustermember.%d.defaulttemplate = " % (prefix, clusterId, memberId))
      printLine("%s.%d.clustermember.%d.templatenode = " % (prefix, clusterId, memberId))
      printLine("%s.%d.clustermember.%d.templateserver = " % (prefix, clusterId, memberId))
      printLine(" ")

      memberNode = AdminConfig.showAttribute(member,"nodeName")
      memberName = AdminConfig.showAttribute(member,"memberName")
      
      server = AdminConfig.getid("/Node:%s/Server:%s" % (memberNode,memberName))

      dumpServerPorts("%s.%d.clustermember.%d" % (prefix, clusterId, memberId),memberName,memberNode,parmMap)

      dumpServerSDK("%s.%d.clustermember.%d" % (prefix,clusterId, memberId),memberNode, memberName)
      
      
      # @JJM - Call common routine for formatting application server
      dumpApplicationServer("%s.%d.clustermember.%d" % (prefix, clusterId, memberId),server,parmMap)

    printLine("%s.%d.clustermember.count = %d" % (prefix, clusterId, memberId))
  

  printLine("")
  printLine("#------------------------------------------------------------------------------")
  printLine("#  Number of Clusters to create")
  printLine("%s.count = %d" % (prefix, clusterId))
  printLine("#------------------------------------------------------------------------------")
  printLine("")

#-------------------------------------------------------------------------------
# convertToDynamicCluster
#-------------------------------------------------------------------------------
def convertToDynamicCluster(clusterName, **parmMap):
  
  try:
    nodeList = []
    serversPerNode = {}
    
    dynamicName = parmMap.get("-targetcluster","Dynamic_%s"%clusterName)
    nodegroupName = parmMap.get("-nodegroup","NodeGroup_%s"%clusterName)
    
    useTemplate = parmMap.get("-usetemplate","false")
    
    targetServer = parmMap.get("-targetserver","")
    targetNode = parmMap.get("-targetnode","")
    
    clusterId = AdminConfig.getid("/ServerCluster:%s/"%clusterName)
    if (isEmpty(clusterId)):
      _app_message("Cluster %s could not be found" % clusterName)
      raise StandardError("Cluster %s could not be found" % clusterName)
    
    members = wsadminToList(AdminConfig.showAttribute(clusterId,"members"))
    targetFound = 0
    for memberId in members:
      if (isEmpty(memberId)):
        continue
      
      memberNode = AdminConfig.showAttribute(memberId,"nodeName")
      memberName = AdminConfig.showAttribute(memberId,"memberName")
      
      if (isEmpty(targetServer)):
        targetServer = memberName
        targetNode = memberNode
        targetFound = 1
      elif (targetServer == memberName and isEmpty(targetNode)):
        targetNode = memberNode
        targetFound = 1
      
      if (not targetFound and (memberName == targetServer and memberNode == targetNode)):
        targetFound = 1
      
      if (memberNode not in nodeList):
        nodeList.append(memberNode)
        serversPerNode[memberNode] = 1
      else:
        serversPerNode[memberNode] = serversPerNode[memberNode] + 1
      
    minServers = 100
    maxServers = 1
    totalServers = 0
    for nodeName in nodeList:
      sCount = serversPerNode[nodeName]
      totalServers += sCount
      if (sCount > maxServers):
        maxServers = sCount
        
      if (sCount < minServers):
        minServers = sCount
        
    # Step 1 - create a customized node group
    nodeList.sort()
    printLine("\n# Generated NodeGroup.  ")
    printLine("app.nodegroups.1.name = %s" % nodegroupName)
    nidx = 0
    for node in nodeList:  
      nidx += 1
      printLine("app.nodegroups.1.members.%d.prop.nodeName = %s" % (nidx,node))
    printLine("app.nodegroups.1.members.count = %d" % nidx)
    printLine("app.nodegroups.count = 1")
    printLine("app.nodegroups.forceSave = true")
    printLine("")
    
    prefix = "app.dyncluster.1"  
    printLine("%s.name = %s" % (prefix, dynamicName))
    printLine("%s.serverType = APPLICATION_SERVER" % (prefix))  
    
    printLine("%s.preferlocal = %s" % (prefix, AdminConfig.showAttribute(clusterId, "preferLocal")))
    repdomain = AdminConfig.getid("/DataReplicationDomain:%s/" % clusterName)
    createDomain = "false"
    if (not isEmpty(repdomain)):
      createDomain = "true"
    printLine("%s.createDomain = %s" % (prefix, createDomain))
    
    printLine("app.dyncluster.1.dc.prop.maxInstances = %d" % totalServers)
    printLine("app.dyncluster.1.dc.prop.maxNodes = %d" % len(nodeList))
    printLine("app.dyncluster.1.dc.prop.membershipPolicy = node_nodegroup = '%s' AND node_property$com.ibm.websphere.wxdopProductShortName = 'WXDOP'" % (nodegroupName))
    printLine("app.dyncluster.1.dc.prop.minInstances = %d" % (len(nodeList) * minServers))
    printLine("app.dyncluster.1.dc.prop.minNodes = 1")
    printLine("app.dyncluster.1.dc.prop.numVerticalInstances = %d" % maxServers)
    printLine("app.dyncluster.1.dc.prop.operationalMode = manual")
    printLine("app.dyncluster.1.dc.prop.serverInactivityTime = 0")
    printLine("app.dyncluster.1.dc.prop.serverType = APPLICATION_SERVER")
    printLine("app.dyncluster.1.dc.prop.strictIsolationEnabled = false")
    
    
    printLine("\n#templateName is either default or cell_name/node_name/was_server_name and is used\n#when creating dynamic cluster")
    printLine("%s.templateName =\n" % prefix)

    printLine("# Cluster starting port is used as seed value for cluster members if ")
    printLine("# they use the @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} macro.")
    printLine("%s.startingport = " % (prefix))
    printLine(" ")
    printLine("# This optional setting controls which virtual host the servers")
    printLine("# HTTP/HTTPS ports will be added to as host aliases to the Virtual Host specified here")
    printLine("%s.mapPortsToVirtualHost =" % (prefix))
      
    printLine(" ")
    
    printLine("# These settings control the processing of the clustermember sections. In most cases ")
    printLine("# applying the clusterTemplate settings to the cluster members is enough, but if you ")
    printLine("# have individualized settings on the cluster members (such as ports), then you'll need")
    printLine("# enable the processing ")
    printLine("%s.processAllClusterMemberPorts = false" % prefix)
    printLine("%s.processAllClusterMemberDefinitions = false" %prefix)
    printLine("%s.processNewClusterMemberDefinitions = false" % prefix)
    printLine(" ") 
    
    printLine("%s.clusterTemplate.updateTemplate = true\n" % prefix)
    
    
    if (useTemplate in ["yes","true","-usetemplate","usetemplate"]):
      searchName = "templates/clusters/%s/servers" % (clusterName)
      templates = AdminConfig.listTemplates("Server",searchName)
      templateList = wsadminToList(templates)
      if (len(templateList) > 0 and not isEmpty(templateList[0])):
        templateId = templateList[0]
        printLine("\n# Template generated from Cluster %s template" % clusterName)
        dumpApplicationServer( "%s.clusterTemplate" % (prefix), templateId, parmMap)
    else:
      if (targetFound):
        
        serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (targetNode,targetServer))
        printLine("\n# Template generated from Cluster %s member %s\%s template" % (clusterName,targetNode,targetServer))
        dumpApplicationServer( "%s.clusterTemplate" % (prefix), serverId, parmMap)
        
      
      
    
    
    
  except:
    _app_message("Unexpected problem in convertToDynamicCluster","exception")


#-------------------------------------------------------------------------------
# downloadTempFile
#-------------------------------------------------------------------------------
def downloadTempFile(repoPath,tempdir="."):
  import time
  import os
  t0 = time.time()
  tm = time.localtime(t0)
  tempFileName = "%s/tempaa%s.txt" % (tempdir,time.strftime("%Y%m%d_%H%M%S",tm))

  try:
    AdminConfig.extract(repoPath,tempFileName)
    AdminConfig.reset()
  except:
    _app_message("Error accessing %s" % repoPath)
    tempFileName = ""
  
  return tempFileName
  

#--------------------------------------------------------
# buildPasswordDictionary
#
# This method is used to pull encoded password values for J2C Authentication 
# Aliases from the security.xml file
# 
# Returns a dictionary {authentication-id1 = encoded-password1 , ...}
#--------------------------------------------------------
def buildPasswordDictionary(tempdir="."):
  retval = {}
  
  import time
  import os
  t0 = time.time()
  tm = time.localtime(t0)
  tempFileName = "%s/tempaa%s.txt" % (tempdir,time.strftime("%Y%m%d_%H%M%S",tm))

  
  AdminConfig.extract("/cells/%s/security.xml" % getCellName(), tempFileName)
  AdminConfig.reset()
  
  fh = open(tempFileName,"r")
  securityLines = fh.readlines()
  fh.close()
  
  os.remove(tempFileName)
  
  for line in securityLines:
    if (line.find("<authDataEntries") < 0): 
      continue
    
    #<authDataEntries xmi:id="JAASAuthData_1366299426004" alias="db2admin" userId="db2admin" password="{xor}Oz09bSsybTE=" description=""/>
    tokens = line.split('"')
    strippedTokens = [token.strip() for token in tokens]
    
    aliasName  = ""
    password = ""
    for idx in range(0,len(strippedTokens)):
      if (strippedTokens[idx] == 'alias='):
        aliasName = strippedTokens[idx+1]
      
      if (strippedTokens[idx] == 'password=') :
        password = strippedTokens[idx+1]
      
      if (aliasName != "" and password != ""):
        retval[aliasName] = password
        break
    #endfor
    
  #endfor each line in file
  
  return retval
  
#------------------------------------------------------------------------------
# dumpAuthSection
#
# Produces the Authentication Alias section of the output. If the -passwords
# option is specified in the parm map, encoded password values will be in the
# output.
#------------------------------------------------------------------------------
def dumpAuthSection(aliasNameList=None,parmMap=None):
  printLine(" ")
  printLine("#------------------------------------------------------------------------------")
  printLine("# J2C Authentication Section")
  printLine("#")
  printLine("# set allowUpdate to true to allow updates to already defined aliases")
  printLine("#------------------------------------------------------------------------------")
  printLine("#  J2C Authentication Aliases")
  printLine(" ")

  passwordMap = {}
  if (parmMap != None):
    getPasswords = parmMap.get("-passwords","false")
    if (getPasswords.lower() == "true" or getPasswords == "-passwords"):
      passwordMap = buildPasswordDictionary(parmMap.get("-tempdir","."))
    
  prefix="app.j2c.aliases"
  j2c_aliases = AdminConfig.list("JAASAuthData").split(SEPARATOR)
  aliasId = 0
  if (not isEmpty(j2c_aliases)):
    for entry in j2c_aliases:
      if (isEmpty(entry)): continue
      
      aliasProps = {}
      collectSimpleProperties(aliasProps, "prop",entry)
      
      if (aliasNameList != None and aliasProps["prop.alias"] not in aliasNameList):
        # We don't want this alias
        continue
        
      if (len(passwordMap) > 0):
        tempPassword = passwordMap.get(aliasProps["prop.alias"],None)
        if (tempPassword != None):
          aliasProps["prop.password"] = tempPassword
        
      aliasId = aliasId + 1
      printLine("%s.%d.alias = %s" % ( prefix, aliasId, aliasProps["prop.alias"]))
      printLine("%s.%d.userId = %s" % ( prefix, aliasId, aliasProps.get("prop.userId","")))
      printLine("%s.%d.password = %s" % ( prefix, aliasId, aliasProps.get("prop.password","")))
      printLine("%s.%d.description = %s" % ( prefix, aliasId, aliasProps.get("prop.description","")))
      printLine("%s.%d.allowUpdate = false" % ( prefix, aliasId))
      printLine(" ")

  printLine("%s.count = %d" % (prefix, aliasId))


#------------------------------------------------------------------------------
def dumpNameSpaceBindings():
	global nsbId
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# Name Space Bindings - ")
	printLine("#    Cell scope    = leave cluster, node, server empty")
	printLine("#    Cluster scope = leave node, server empty ")
	printLine("#    Node scope    = leave cluster, server empty ")
	printLine("#    Server scope  = leave cluster empty ")
	printLine("#")
	printLine("#------------------------------------------------------------------------------")
	printLine(" ")

	cells = AdminConfig.list('Cell').split(SEPARATOR)
	for cell in cells:
		nsbList = AdminConfig.list("NameSpaceBinding", cell).split(SEPARATOR)
		if (nsbList[0] == ''): continue
		printNsbs(nsbList)
    
	printLine("app.wasnsb.count = %d" % nsbId)

#------------------------------------------------------------------------------
def dumpLibraries(pattern=None,targetCluster=None,targetNode=None,targetServer=None,targetCell=None,wildcard="*",serverList=None,membersList=None):
  
  printLine(" ")
  printLine("#------------------------------------------------------------------------------")
  printLine("# Shared Libraries - ")
  printLine("#    Cell scope    = leave cluster, node, server empty")
  printLine("#    Cluster scope = leave node, server empty ")
  printLine("#    Node scope    = leave cluster, server empty ")
  printLine("#    Server scope  = leave cluster empty ")
  printLine("#")
  printLine("#------------------------------------------------------------------------------")
  printLine(" ")

  libList = AdminConfig.list("Library").splitlines()
  
  printLibraries(libList,pattern,targetCluster,targetNode,targetServer,targetCell,wildcard,serverList,membersList)
    
  


#------------------------------------------------------------------------------
def dumpCluster(dirName,sufix,clusterName,parmMap=None):
	global fileId
	fileId = open("%s/%s_%s_%s.props" % (dirName, getStoredHostName(), clusterName, sufix), "w")
	
	printLine("###############################################################################")
	printLine("# Generated at : %s" % (java.util.Date()))
	printLine("# HostName     : %s" % getStoredHostName())
	printLine("# CellName     : %s" % getCellName())
	printLine("# app.config Application Config file")
	printLine("###############################################################################")
	printLine(" " )

	#printTemplateServer()
	printLine(" " )
	
	printLine(" ")
	dumpClusterSection(clusterName,parmMap=parmMap)
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# End of Config file")
	printLine("#------------------------------------------------------------------------------")
	fileId.close()

#------------------------------------------------------------------------------
# dumpMessageEngines
#------------------------------------------------------------------------------
def dumpMessageEngines(prefix, messageEngineList,includeUUID="false"):

    idx = 0
    for messageEngine in messageEngineList:
        if (not isEmpty(messageEngine)):
            idx=idx+1
            
        name = AdminConfig.showAttribute(messageEngine,"name")
        printLine("%s.messageEngines.%d.name = %s" % (prefix,idx,name))
        excludeProps = ['name']
        if (includeUUID != "true"):
            excludeProps.append("uuid")
            excludeProps.append("busUuid")
        printSimpleProperties("%s.messageEngines.%d.prop" % (prefix, idx), messageEngine, excludeProps)
        
        storeType = AdminConfig.showAttribute(messageEngine,"messageStoreType")
        excludeProps = []
        if (includeUUID != "true"):
            excludeProps.append("uuid")
            excludeProps.append("busUuid")        
        if (storeType == "DATASTORE"):
            printSimpleProperties("%s.messageEngines.%d.dataStore.prop" % (prefix,idx), AdminConfig.showAttribute(messageEngine,"dataStore"),excludeProps)
        elif (storeType == "FILESTORE"):
            printSimpleProperties("%s.messageEngines.%d.fileStore.prop" % (prefix,idx), AdminConfig.showAttribute(messageEngine,"fileStore"),excludeProps)
            
        
        printCustomProperties("%s.messageEngines.%d.customProperties" % (prefix, idx), messageEngine,"properties")
        #custprops=AdminConfig.showAttribute(messageEngine,"properties")
        #if (not isEmpty(custprops)):
        #  for cpropsitem in wsadminToList(custprops):
        #      cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
        #      cpropname = AdminConfig.showAttribute(cpropsitem,"name")
        #      cpropval = AdminConfig.showAttribute(cpropsitem,"value")
        #      if isEmpty(cpropdesc):
        #          printLine("%s.messageEngines.%d.customProperties.prop.%s = %s" % (prefix, idx,  cpropname, cpropval))
        #      else:
        #          printLine("%s.messageEngines.%d.customProperties.prop.%s = %s|%s" % (prefix, idx,  cpropname, cpropval, cpropdesc))
         
        localizationPoints = AdminConfig.showAttribute(messageEngine,"localizationPoints")
        lidx = 0
        if (not isEmpty(localizationPoints)):
          lpList = wsadminToList(localizationPoints)
          lpDict = {}
          for lpoint in lpList:
            if (isEmpty(lpoint)): continue
            lidentifier = AdminConfig.showAttribute(lpoint,"identifier")
            lpType = callGetObjectType(lpoint)
            key = (lpType,lidentifier)
            lpDict[key] = lpoint
            
          lidentifiers = lpDict.keys()
          lidentifiers.sort()
          for lkey in lidentifiers:
              lpoint = lpDict[lkey]
              lpType = lkey[0]
              lidentifier = lkey[1]   
              lidx += 1
              #lprops = collectSimpleProperties({},"%s.messageEngines.%d.localizationPoints.%d.prop" % (prefix, idx,  lidx),lpoint)
              printLine("%s.messageEngines.%d.localizationPoints.%d.identifier = %s" % (prefix, idx,  lidx,lidentifier))
              printLine("%s.messageEngines.%d.localizationPoints.%d.type = %s" % (prefix, idx,  lidx,lpType))
              
              printSimpleProperties("%s.messageEngines.%d.localizationPoints.%d.prop" % (prefix, idx,  lidx),
                                    lpoint,optionalSkipList = ["identifier"],printSimpleChildren=1)
              
              #lppropKeys = lprops.keys()
              #lppropKeys.sort()
              #for lpKey in lppropKeys:
              #  if (lpKey.find("identifier") < 0):
              #    printLine("%s = %s" % (lpKey,lprops.get(lpKey)))
              
            
            
    
    printLine("%s.messageEngines.count = %d" % (prefix,idx))

#enddef

#-------------------------------------------------------------------------------
# dumpSIBMediations
# 
# Returns a map of uuid=mediation names
#-------------------------------------------------------------------------------
def dumpSIBMediations(busName,prefix,includeUUID="false"):
  retval = {}
  try:
    if (not isValidType("SIBDestinationMediation")):
      return

    mediationList = wsadminToList(AdminTask.listSIBMediations('[-bus "%s" ]' % (busName)))
    
    mediationdict = {}
    mediationnames = []
    for mediation in mediationList:
      if (not isEmpty(mediation)):
        mname = AdminConfig.showAttribute(mediation, "mediationName")
        mediationdict[mname] = mediation
        mediationnames.append(mname)
        
    
    
    idx = 0
    
    mediationnames.sort()
    
    for mediationName in mediationnames:
      mediationId = mediationdict.get(mediationName)
      if (not isEmpty(mediationId)):
      
        idx += 1
        if (idx == 1):
          printLine("# mediation definitions for bus (not supported yet in updateEnvironment)")
        else:
          printLine("")

        printLine("%s.mediations.%d.mediationName = %s" % (prefix,idx,mediationName))
        skipList =   ["mediationName"]
        if (includeUUID != None and includeUUID.lower() != "true"):
          skipList.append("uuid")
        collectDict = {}
        mediationPrefix = "%s.mediations.%d.prop" % (prefix,idx)
        printSimpleProperties(mediationPrefix,mediationId, optionalSkipList=skipList,includeBlanks=0,printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,useAttrNameWithProperties=1,includeReferenceChildren=0,printListChildren=1,
                          printChildType=1,collectDict=collectDict)
        uuid = collectDict.get("%s.uuid" % mediationPrefix)
        if (not isEmpty(uuid)):
          retval[uuid] = mediationName
          retval[mediationName] = uuid
    if (idx > 0):
      printLine("\n%s.mediations.count = %d\n" % (prefix,idx))
              
  except:
    _app_message("Unexpected error in dumpSIBmediations","exception")

  return retval

#-------------------------------------------------------------------------------
# dumpSIBForeignDestinations
#-------------------------------------------------------------------------------
def dumpSIBForeignDestinations(busName,prefix,includeUUID="false",destinationTarget=None,destinationTargetPattern=None):
  try:
    if (not isValidType("SIBDestinationForeign")):
      return

    foreignList = wsadminToList(AdminTask.listSIBDestinations('[-bus "%s" -type Foreign]' % (busName)))
    
    foreigndict = {}
    foreignidentifiers = []
    for foreign in foreignList:
      if (not isEmpty(foreign)):
        aidentifier = AdminConfig.showAttribute(foreign, "identifier")
        foreigndict[aidentifier] = foreign
        foreignidentifiers.append(aidentifier)
        
    
    
    idx = 0
    
    foreignidentifiers.sort()
    
    for foreignIdentifier in foreignidentifiers:
      foreignId = foreigndict.get(foreignIdentifier)
      if (not isEmpty(foreignId)):
        # See if we are filtering by destination name
        if (not isEmpty(destinationTarget) or not isEmpty(destinationTargetPattern)):
           if (destinationTargetPattern != None):
              if (not re.match(destinationTargetPattern,foreignIdentifier)):
                continue  
           elif (destinationTarget != foreignIdentifier):
                continue
      
        idx += 1
        if (idx == 1):
          printLine("# foreign definitions for bus (not supported yet in updateEnvironment)")
        else:
          printLine("")

        printLine("%s.foreignDestinations.%d.identifier = %s" % (prefix,idx,foreignIdentifier))
        skipList =   ["identifier"]
        if (includeUUID != None and includeUUID.lower() != "true"):
          skipList.append("uuid")          
        printSimpleProperties("%s.foreignDestinations.%d.prop" % (prefix,idx),foreignId, optionalSkipList=skipList,includeBlanks=0,printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,useAttrNameWithProperties=1,includeReferenceChildren=0,printListChildren=1,
                          printChildType=1)
    if (idx > 0):
      printLine("\n%s.foreignDestinations.count = %d\n" % (prefix,idx))
              
  except:
    _app_message("Unexpected error in dumpSIBForeignDestinations","exception")

#-------------------------------------------------------------------------------
# dumpSIBAliases
#-------------------------------------------------------------------------------
def dumpSIBAliases(busName, prefix,includeUUID="false",busMemberTarget=None,busMemberTargetPattern=None,destinationTarget=None,destinationTargetPattern=None):
  try:
    if (not isValidType("SIBDestinationAlias")):
      return
      
    aliasList = wsadminToList(AdminTask.listSIBDestinations('[-bus "%s" -type Alias]' % (busName)))
    
    aliasdict = {}
    aliasidentifiers = []
    for alias in aliasList:
      if (not isEmpty(alias)):
        aidentifier = AdminConfig.showAttribute(alias, "identifier")
        aliasdict[aidentifier] = alias
        aliasidentifiers.append(aidentifier)
    
    idx = 0
    
    aliasidentifiers.sort()
    
    for aliasIdentifier in aliasidentifiers:
      aliasId = aliasdict.get(aliasIdentifier)
      if (not isEmpty(aliasId)):
        # See if we are filtering by destination name
        if (not isEmpty(destinationTarget) or not isEmpty(destinationTargetPattern)):
           if (destinationTargetPattern != None):
              if (not re.match(destinationTargetPattern,aliasIdentifier)):
                continue  
           elif (destinationTarget != aliasIdentifier):
                continue
      
        idx += 1
        if (idx == 1):
          printLine("# Alias definitions for bus (not supported yet in updateEnvironment)")
        else:
          printLine("")
        
        printLine("%s.aliasDestinations.%d.identifier = %s" % (prefix,idx,aliasIdentifier))
        skipList =   ["identifier"]
        if (includeUUID != None and includeUUID.lower() != "true"):
          skipList.append("uuid")
        printSimpleProperties("%s.aliasDestinations.%d.prop" % (prefix,idx),aliasId, optionalSkipList=skipList,includeBlanks=0,printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,useAttrNameWithProperties=1,includeReferenceChildren=0,printListChildren=1,
                          printChildType=1)
    if (idx > 0):
      printLine("\ns%s.aliasDestinations.count = %d\n" % (prefix,idx))
              
    
  except:
    _app_message("Unexpected error in dumpSIBAliases","exception")

#------------------------------------------------------------------------------
# dumpSIBQueues
#------------------------------------------------------------------------------
def dumpSIBQueues(busName, prefix, includeUUID="false",busMemberTarget=None,busMemberTargetPattern=None,destinationTarget=None,destinationTargetPattern=None,mediationMap=None):

    queueList = wsadminToList(AdminTask.listSIBDestinations('[-bus "%s" -type Queue]' % (busName)))
    
    queuedict = {}
    queueidentifiers = []
    for queue in queueList:
      if (not isEmpty(queue)):
        qidentifier = AdminConfig.showAttribute(queue, "identifier")
        queuedict[qidentifier] = queue
        queueidentifiers.append(qidentifier)
        
    
    
    idx = 0
    
    queueidentifiers.sort()
    
    
    
    for qidentifier in queueidentifiers:
        queue = queuedict[qidentifier]
        if (not isEmpty(queue)):
            
            # Determine target cluster or target server from the localizationPoint
            clusterName = None
            nodeName = None
            serverName = None
            
            localizationPointRefsList = wsadminToList(AdminConfig.showAttribute(queue, "localizationPointRefs"))
            for localizationPoint in localizationPointRefsList:
                if (isEmpty(localizationPoint)): continue
                  
                clusterName = AdminConfig.showAttribute(localizationPoint,"cluster")
                nodeName = AdminConfig.showAttribute(localizationPoint,"node")
                serverName = AdminConfig.showAttribute(localizationPoint,"server")
                break
            #endfor
           
            # If we are matching against patterns or explicit nmae, check them first and skip this
            # bus member if it doesn't match
            if (not isEmpty(busMemberTargetPattern) or not isEmpty(busMemberTarget)):
              compTarget = clusterName
              if (isEmpty(compTarget)):
                compTarget = serverName
              
              if (busMemberTargetPattern != None):
                if (not re.match(busMemberTargetPattern,compTarget)):
                  continue
              elif (busMemberTarget != compTarget):
                continue
            #endif
            
            qidentifier = AdminConfig.showAttribute(queue, "identifier")
            
            # See if we are filtering by destination name
            if (not isEmpty(destinationTarget) or not isEmpty(destinationTargetPattern)):
              if (destinationTargetPattern != None):
                if (not re.match(destinationTargetPattern,qidentifier)):
                  continue  
              elif (destinationTarget != qidentifier):
                continue
            #endif
                 
            idx = idx + 1
            
            printLine("%s.queueDestinations.%d.identifier = %s" % (prefix,idx,qidentifier))
            

          
            if (not isEmpty(clusterName)):
                printLine("%s.queueDestinations.%d.cluster = %s" % (prefix, idx, clusterName))
            else:
                printLine("%s.queueDestinations.%d.cluster = %s" % (prefix, idx, ""))
            
            if (not isEmpty(nodeName)):
                printLine("%s.queueDestinations.%d.node = %s" % (prefix, idx, nodeName))
            else:
                printLine("%s.queueDestinations.%d.node = %s" % (prefix, idx, ""))
                
            if (not isEmpty(serverName)):
                printLine("%s.queueDestinations.%d.server = %s" % (prefix, idx, serverName))
            else:
                printLine("%s.queueDestinations.%d.server = %s" % (prefix, idx, ""))
                    


            # Special handling of exceptionDestination blank values
            val = AdminConfig.showAttribute(queue, "exceptionDestination")
            if (isEmpty(val)):
                val = "''"
            printLine("%s.queueDestinations.%d.prop.exceptionDestination = %s" % (prefix,idx, val))
            
            # now print other properties
            excludeProps = ['identifier', 'exceptionDestination','uuid']
            if (includeUUID != "true"):
                excludeProps.append('uuid')
                excludeProps.append('busUuid')
            
            collectDict = {}
            queuePrefix = "%s.queueDestinations.%d" % (prefix,idx)   
            printSimpleProperties("%s.prop" % (queuePrefix), queue, excludeProps,collectDict=collectDict)
            
            includeContextInfo = 1
            if (includeContextInfo):
              contextInfoList = wsadminToList(AdminConfig.showAttribute(queue, "contextInfo"))
              ciidx = 0
              for contextInfo in contextInfoList:
                if (not isEmpty(contextInfo)):
                    ciidx =  ciidx + 1
                    printSimpleProperties("%s.queueDestinations.%d.contextInfo.%d.prop" % (prefix, idx, ciidx), contextInfo)
              printLine("%s.queueDestinations.%d.contextInfo.count = %d" % (prefix, idx, ciidx))
            
            replyDestination = AdminConfig.showAttribute(queue,"replyDestination")
            if (not isEmpty(replyDestination)):
                printSimpleProperties("%s.queueDestinations.%d.replyDestination.prop" % (prefix,idx), replyDestination)
                
            includeRouting = 0
            if (includeRouting):
              defaultForwardRoutingPathList = wsadminToList(AdminConfig.showAttribute(queue, "defaultForwardRoutingPath"))
              rpidx = 0
              for defaultForwardRoutingPath in defaultForwardRoutingPathList:
                if (not isEmpty(defaultForwardRoutingPath)):
                    rpidx = rpidx + 1
                    printSimpleProperties("%s.queueDestinations.%d.defaultForwardRoutingPath.%d.prop" % (prefix, idx, rpidx), defaultForwardRoutingPath)
              printLine("%s.queueDestinations.%d.defaultForwardRoutingPath.count = %d" % (prefix, idx, rpidx))
            
            
            includeLocalization = 0
            if (includeLocalization):
              localizationPointRefsList = wsadminToList(AdminConfig.showAttribute(queue, "localizationPointRefs"))
              lpidx = 0
              for localizationPoint in localizationPointRefsList:
                lpidx = lpidx + 1
                
                clusterName = AdminConfig.showAttribute(localizationPoint,"cluster")
                nodeName = AdminConfig.showAttribute(localizationPoint,"node")
                serverName = AdminConfig.showAttribute(localizationPoint,"server")
                if (not isEmpty(clusterName)):
                    printLine("%s.queueDestinations.%d.localizationPointRefs.%d.cluster =  %s" % (prefix, idx, lpidx, clusterName))
                
                if (not isEmpty(nodeName)):
                    printLine("%s.queueDestinations.%d.localizationPointRefs.%d.node =  %s" % (prefix, idx, lpidx, nodeName))
                    
                if (not isEmpty(serverName)):
                    printLine("%s.queueDestinations.%d.localizationPointRefs.%d.server =  %s" % (prefix, idx, lpidx, serverName))

                
                printSimpleProperties("%s.queueDestinations.%d.localizationPointRefs.%d.prop" % (prefix, idx, lpidx), localizationPoint, ['cluster','node','server'])
              printLine("%s.queueDestinations.%d.localizationPointRefs.count = %d" % (prefix, idx, lpidx))
                
            
            
            # Not sure if we need to handle these
            destinationMediationRef = collectDict.get("%s.prop.destinationMediationRef" % queuePrefix)
            if (not isEmpty(destinationMediationRef)):
              refProps = {}
              printSimpleProperties("%s.destinationMediationRef.prop" % queuePrefix,destinationMediationRef,
                                    collectDict=refProps,printSimpleChildren=1,printListChildren=1,printChildType=1)
              if (mediationMap != None):
                mediationUuid = refProps.get("%s.destinationMediationRef.prop.mediationUuid" % queuePrefix)
                if (not isEmpty(mediationUuid)):
                  mediationName = mediationMap.get(mediationUuid)
                  if (not isEmpty(mediationName)):
                    printLine("%s.destinationMediationRef.mediationName = %s" % (queuePrefix,mediationName))
            
            
            printLine(" ")
                
            
    
    printLine("%s.queueDestinations.count = %d" % (prefix,idx))
    printLine(" ")

#------------------------------------------------------------------------------
# dumpSIBTopics
#------------------------------------------------------------------------------
def dumpSIBTopics(busName, prefix,includeUUID="false",destinationTarget=None,destinationTargetPattern=None,mediationMap=None):

    topicList = wsadminToList(AdminTask.listSIBDestinations('[-bus "%s" -type TopicSpace]' % (busName)))
    
    topicdict = {}
    topicidentifiers = []
    for topic in topicList:
      if (not isEmpty(topic)):
        tidentifier = AdminConfig.showAttribute(topic, "identifier")
        topicdict[tidentifier] = topic
        topicidentifiers.append(tidentifier)
    
    topicidentifiers.sort()
        
    
    idx = 0
    for tidentifier in topicidentifiers:
        topic = topicdict[tidentifier]
    
        if (not isEmpty(topic)):
            
            #tidentifier = AdminConfig.showAttribute(topic, "identifier")
            
            # See if we are filtering by destination name
            if (not isEmpty(destinationTarget) or not isEmpty(destinationTargetPattern)):
              if (destinationTargetPattern != None):
                if (not re.match(destinationTargetPattern,tidentifier)):
                  continue
              elif (destinationTarget != tidentifier):
                continue
            #endif
            
            idx = idx + 1

            
            collectDict = {}
            printLine("%s.topicDestinations.%d.identifier = %s" % (prefix,idx,tidentifier))
            excludeProps = ['identifier']
            if (includeUUID != "true"):
                excludeProps.append('uuid')
                excludeProps.append('busUuid')
            topicPrefix = "%s.topicDestinations.%d" % (prefix,idx)
            printSimpleProperties("%s.prop" % topicPrefix, topic, excludeProps,collectDict=collectDict)
            
            includeContextInfo = 1
            if (includeContextInfo):
              # The collectDict has the attribute information that was not already printed
              contextInfoList = wsadminToList(collectDict.get("%s.prop.contextInfo" % topicPrefix,""))
              ciidx = 0
              for contextInfo in contextInfoList:
                if (not isEmpty(contextInfo)):
                    ciidx =  ciidx + 1
                    printSimpleProperties("%s.topicDestinations.%d.contextInfo.%d.prop" % (prefix, idx, ciidx), contextInfo)
              printLine("%s.topicDestinations.%d.contextInfo.count = %d" % (prefix, idx, ciidx))
            
            replyDestination = AdminConfig.showAttribute(topic,"replyDestination")
            if (not isEmpty(replyDestination)):
                printSimpleProperties("%s.topicDestinations.%d.replyDestination.prop" % (prefix,idx), replyDestination)
            
            includeLocalization = 0
            if (includeLocalization):
              localizationPointRefsList = wsadminToList(AdminConfig.showAttribute(topic, "localizationPointRefs"))
              lpidx = 0
              for localizationPoint in localizationPointRefsList:
                lpidx = lpidx + 1
                
                clusterName = AdminConfig.showAttribute(localizationPoint,"cluster")
                nodeName = AdminConfig.showAttribute(localizationPoint,"node")
                serverName = AdminConfig.showAttribute(localizationPoint,"server")
                if (not isEmpty(clusterName)):
                    printLine("%s.topicDestinations.%d.localizationPointRefs.%d.cluster =  %s" % (prefix, idx, lpidx, clusterName))
                
                if (not isEmpty(nodeName)):
                    printLine("%s.topicDestinations.%d.localizationPointRefs.%d.node =  %s" % (prefix, idx, lpidx, nodeName))
                    
                if (not isEmpty(serverName)):
                    printLine("%s.topicDestinations.%d.localizationPointRefs.%d.server =  %s" % (prefix, idx, lpidx, serverName))

                printSimpleProperties("%s.topicDestinations.%d.localizationPointRefs.%d.prop" % (prefix, idx, lpidx), localizationPoint, ['cluster','node','server'])
                
              printLine("%s.topicDestinations.%d.localizationPointRefs.count = %d" % (prefix, idx, lpidx))
            
                        
            destinationMediationRef = collectDict.get("%s.prop.destinationMediationRef" % topicPrefix)
            if (not isEmpty(destinationMediationRef)):
              refProps = {}
              printSimpleProperties("%s.destinationMediationRef.prop" % topicPrefix,destinationMediationRef,
                                    collectDict=refProps,printSimpleChildren=1,printListChildren=1,printChildType=1)
              if (mediationMap != None):
                mediationUuid = refProps.get("%s.destinationMediationRef.prop.mediationUuid" % topicPrefix)
                if (not isEmpty(mediationUuid)):
                  mediationName = mediationMap.get(mediationUuid)
                  if (not isEmpty(mediationName)):
                    printLine("%s.destinationMediationRef.mediationName = %s" % (topicPrefix,mediationName))
                
            printLine(" ")
    
    printLine("%s.topicDestinations.count = %d" % (prefix,idx))           
    
    printLine(" ")

#----------------------------------------------------------------------------------------------
# collectResourceProperties
# 
# Utility method for loading resource properties
#----------------------------------------------------------------------------------------------
def collectResourceProperties(configId,propertyName,prefix):
  
  props = java.util.Properties()
    
  mId = AdminConfig.showAttribute(configId,propertyName)
  if not (isEmpty(mId)):
    rps = AdminConfig.showAttribute(mId,"resourceProperties")
    rpsarray = rps[1:len(rps)-1].split(' ')
    for rp in rpsarray:
        if (isEmpty(rp)):
            continue
        rname = AdminConfig.showAttribute(rp,"name")
        rtype = AdminConfig.showAttribute(rp,"type")
        rval = AdminConfig.showAttribute(rp,"value")
        rdesc = AdminConfig.showAttribute(rp,"description")
        rrequired = AdminConfig.showAttribute(rp,"required")
        if (not isEmpty(rtype) and not isEmpty(rrequired)):
          if isEmpty(rdesc):
            props.put("%s.resourceProperties.prop.%s" % (prefix, rname), "%s|%s|%s" % (rtype,rrequired,rval))
          else:
            props.put("%s.resourceProperties.prop.%s" % (prefix,rname), "%s|%s|%s|%s" % (rtype,rrequired,rval,rdesc))
        else:
          if isEmpty(rdesc):
            props.put("%s.resourceProperties.prop.%s" % (prefix, AdminConfig.showAttribute(rp, 'name')), AdminConfig.showAttribute(rp, 'value'))
          else:
            props.put("%s.resourceProperties.prop.%s" % (prefix, AdminConfig.showAttribute(rp, 'name')), "%s|%s" % (AdminConfig.showAttribute(rp, 'value'),rdesc))
  return props

#------------------------------------------------------------------------------------------------------------------------------------
# dumpResourceProperties - print out the resource properties in a J2EEResourcePropertySet attribute
# Parms:
#  configId - resource that has a J2EEResourcePropertySet attribute
#  propertyName - the propertyName of the J2EEResourcePropertySet attribute
#  prefix - the prefix to use.  
#  
#  This script will print properties in the format "<prefix>.resourceProperties.prop.name = type|required|val|desc"
#------------------------------------------------------------------------------------------------------------------------------------
def dumpResourceProperties(configId,propertyName,prefix):
  if (isEmpty(configId)):
    return  
  mId = AdminConfig.showAttribute(configId,propertyName)
  if not (isEmpty(mId)):
    rps = AdminConfig.showAttribute(mId,"resourceProperties")
    rpsarray = wsadminToList(rps) # rps[1:len(rps)-1].split(' ')
    for rp in rpsarray:
        if (isEmpty(rp)):
            continue
        tempProps = {}
        collectSimpleProperties(tempProps, "temp.prop", rp)
        
        rname = tempProps.get('temp.prop.name','')
        rtype = tempProps.get('temp.prop.type','')
        rval = tempProps.get('temp.prop.value','')
        rdesc = tempProps.get('temp.prop.description','')
        rrequired = tempProps.get('temp.prop.required','')
        
        if (not isEmpty(rtype) and not isEmpty(rrequired)):
          if isEmpty(rdesc):
            printLine("%s.resourceProperties.prop.%s = %s|%s|%s" % (prefix, rname, rtype,rrequired,rval))
          else:
            printLine("%s.resourceProperties.prop.%s = %s|%s|%s|%s" % (prefix, rname, rtype,rrequired,rval,rdesc))
        else:
          if isEmpty(rdesc):
            printLine("%s.resourceProperties.prop.%s = %s" % (prefix, rname, rval))
          else:
            printLine("%s.resourceProperties.prop.%s = %s|%s" % (prefix, rname, rval,rdesc))
            
						
def dumpResourcePropertiesList(prefix, rpList):
    for rp in rpList:
        if (isEmpty(rp)):
            continue
        tempProps = {}  
        collectSimpleProperties(tempProps, "temp.prop", rp)
        
        rname = tempProps.get('temp.prop.name','')
        rtype = tempProps.get('temp.prop.type','')
        rval = tempProps.get('temp.prop.value','')
        rdesc = tempProps.get('temp.prop.description','')
        rrequired = tempProps.get('temp.prop.required','')
        
        if (not isEmpty(rtype) and not isEmpty(rrequired)):
          if isEmpty(rdesc):
            printLine("%s.prop.%s = %s|%s|%s" % (prefix, rname, rtype,rrequired,rval))
          else:
            printLine("%s.prop.%s = %s|%s|%s|%s" % (prefix, rname, rtype,rrequired,rval,rdesc))
        else:
          if isEmpty(rdesc):
            printLine("%s.prop.%s = %s" % (prefix, rname,rval))
          else:
            printLine("%s.prop.%s = %s|%s" % (prefix, rname,rval,rdesc))


def dumpSIBAuthUsersGroups(parentId,prefix):
	if (isEmpty(parentId)):
			return
			
	authgroups = AdminConfig.showAttribute(parentId,"group")
	if (not isEmpty(authgroups)):
			groupidx = 0
			for authgroup in wsadminToList(authgroups):
					groupidx = groupidx + 1
					printSimpleProperties("%s.group.%d.prop" % (prefix, groupidx), authgroup)
					
			printLine("%s.group.count = %d" % (prefix, groupidx))
		
	authusers = AdminConfig.showAttribute(parentId,"user")
	if (not isEmpty(authusers)):
			useridx = 0
			for authuser in wsadminToList(authusers):
					useridx = useridx + 1
					printSimpleProperties("%s.user.%d.prop" % (prefix, useridx), authuser)
					
			printLine("%s.user.count = %d" % (prefix, useridx))

#-----------------------------------------------------------------------------
# listBusesWithClusterAsMembers
#
# Parameters:
#   cluster - Either a single cluster name or list of cluster names
#
# Returns:
#   List of Bus configuraiton IDs
#-----------------------------------------------------------------------------
def listBusesWithClusterAsMembers(cluster):
  retval = []
  clusterList = []
  if (type(cluster) == type("")):
    clusterList.append(cluster)
  elif (type(cluster) == type([])):
    clusterList = cluster

  buses = AdminTask.listSIBuses().splitlines()
  for bus in buses:
      if (isEmpty(bus)):continue
      busMembers = AdminConfig.showAttribute(bus,"busMembers")
      if (not isEmpty(busMembers)):
          for busMember in wsadminToList(busMembers):
              if (not isEmpty(busMember)):
                
                  clusterName = AdminConfig.showAttribute(busMember,"cluster")
                  if (isEmpty(clusterName)):
                    continue
                  if (clusterName in clusterList):
                    if (bus not in retval):
                      retval.append(bus)
  retval.sort()
  
  return retval
        
  


#------------------------------------------------------------------------------
def dumpSIBus(targetBusName=None,includeUUID="false",pattern="",busMemberTarget="",destinationTarget="",wildcard='*',busList=None):

    printLine("\n#------------------------------------------------------------------------------")
    printLine("# SIBus")
    printLine("#------------------------------------------------------------------------------")
    
    if (busList == None):
      tempstr = AdminTask.listSIBuses()
     
      if isEmpty(tempstr):
        busList = []
      else:
        busList = tempstr.split(SEPARATOR)
    #endif buslist not supplied
    
    # See if the supplied name is a pattern
    if (not isEmpty(targetBusName) and targetBusName.find(wildcard) >= 0):
      pattern = wildcardToRegExpString(targetBusName,wildcard)
      targetBusName=None
    
    busMemberTargetPattern = None
    if (not isEmpty(busMemberTarget) and busMemberTarget.find(wildcard) >= 0):
      busMemberTargetPattern = wildcardToRegExpString(busMemberTarget,wildcard)
    
    destinationTargetPattern = None
    if (not isEmpty(destinationTarget) and destinationTarget.find(wildcard) >= 0):
      destinationTargetPattern = wildcardToRegExpString(destinationTarget,wildcard)
    
    idx = 0
    for bus in busList:
      busName = AdminConfig.showAttribute(bus,'name')
      
      if (not isEmpty(targetBusName)):
        if (targetBusName != busName):
            continue
      
      if (not isEmpty(pattern)):
        try:
          
          if (not re.match(pattern,busName)):
            continue
          
        except:
          exc_type,exc_value,exc_traceback = sys.exc_info()
          exceptionString = "%s %s" % (exc_type, exc_value)
          print "Exception: %s" %exceptionString
      
      idx = idx + 1
      prefix = "app.sibus.%d" % idx
      
      printLine("%s.name = %s" % (prefix, busName))
      printLine("%s.prop.description = %s" % (prefix, AdminConfig.showAttribute(bus,'description')))
      excludeProps = ['name', 'description']
      if (includeUUID != "true"):
          excludeProps.append("uuid")
      printSimpleProperties("%s.prop" % prefix,bus, excludeProps)
      
      custprops=AdminConfig.showAttribute(bus,"properties")
      if (not isEmpty(custprops)):
          for cpropsitem in wsadminToList(custprops):
              cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
              cpropname = AdminConfig.showAttribute(cpropsitem,"name")
              cpropval = AdminConfig.showAttribute(cpropsitem,"value")
              if isEmpty(cpropdesc):
                  printLine("%s.customProperties.prop.%s = %s" % (prefix,   cpropname, cpropval))
              else:
                  printLine("%s.customProperties.prop.%s = %s|%s" % (prefix,   cpropname, cpropval, cpropdesc))
                  
      printLine(" ")
      
      # SIBAuthSpace
      authspace = AdminConfig.list("SIBAuthSpace",bus)
      if (not isEmpty(authspace)):
        dumpSIBAuthUsersGroups(authspace,"%s.sibauthspace" % (prefix))
          
        busConnect = AdminConfig.showAttribute(authspace,"busConnect")
        if (not isEmpty(busConnect)):
          dumpSIBAuthUsersGroups(busConnect,"%s.sibauthspace.busConnect" % (prefix))
          
        defaultAuth = AdminConfig.showAttribute(authspace,"default")
        if (not isEmpty(defaultAuth)):
          browserAuth = AdminConfig.showAttribute(defaultAuth,"browser")
          dumpSIBAuthUsersGroups(browserAuth,"%s.sibauthspace.default.browser" % (prefix))
          
          creatorAuth = AdminConfig.showAttribute(defaultAuth,"creator")
          dumpSIBAuthUsersGroups(creatorAuth,"%s.sibauthspace.default.creator" % (prefix))
          
          identityAdopterAuth = AdminConfig.showAttribute(defaultAuth,"identityAdopter")
          dumpSIBAuthUsersGroups(identityAdopterAuth,"%s.sibauthspace.default.identityAdopter" % (prefix))
          
          receiverAuth = AdminConfig.showAttribute(defaultAuth,"receiver")
          dumpSIBAuthUsersGroups(receiverAuth,"%s.sibauthspace.default.receiver" % (prefix))
          
          senderAuth = AdminConfig.showAttribute(defaultAuth, "sender")
          dumpSIBAuthUsersGroups(senderAuth,"%s.sibauthspace.default.sender" % (prefix))
        
        printLine(" ")
        
      
      bmidx = 0
      
      busMembers = AdminConfig.showAttribute(bus,"busMembers")
      if (not isEmpty(busMembers)):
          for busMember in wsadminToList(busMembers):
              if (not isEmpty(busMember)):
                
                  clusterName = AdminConfig.showAttribute(busMember,"cluster")
                  nodeName = AdminConfig.showAttribute(busMember,"node")
                  serverName = AdminConfig.showAttribute(busMember,"server")
                  
                  # If we are matching against patterns or explicit nmae, check them first and skip this
                  # bus member if it doesn't match
                  if (not isEmpty(busMemberTargetPattern) or not isEmpty(busMemberTarget)):
                    compTarget = clusterName
                    if (isEmpty(compTarget)):
                      compTarget = serverName
                    
                    if (busMemberTargetPattern != None):
                      if (not re.match(busMemberTargetPattern,compTarget)):
                        continue
                    elif (busMemberTarget != compTarget):
                      continue
                  #endif
                  
                  bmidx = bmidx + 1
                  
                  if (not isEmpty(clusterName)):
                      printLine("%s.busmembers.%d.cluster = %s" % (prefix, bmidx, clusterName))
                  else:
                      printLine("%s.busmembers.%d.cluster = %s" % (prefix, bmidx, ""))
                  
                  if (not isEmpty(nodeName)):
                      printLine("%s.busmembers.%d.node = %s" % (prefix, bmidx, nodeName))
                  else:
                      printLine("%s.busmembers.%d.node = %s" % (prefix, bmidx, ""))
                  
                  if (not isEmpty(serverName)):
                      printLine("%s.busmembers.%d.server = %s" % (prefix, bmidx, serverName))
                  else:
                      printLine("%s.busmembers.%d.server = %s" % (prefix, bmidx, ""))
                  
                  excludeProps = ['cluster','node','server']
                  if (includeUUID != "true"):
                    excludeProps.append("uuid")
                    excludeProps.append("busUuid")
                  printSimpleProperties("%s.busmembers.%d.prop" % (prefix,bmidx), busMember, excludeProps)
                  
                  memberCluster = clusterName 
                  memberServer = serverName
                  memberNode = nodeName
                  
                  if (not isEmpty(memberCluster)):
                      # Get list from cluster
                      messageEngines = AdminTask.listSIBEngines('[-bus "%s" -cluster "%s"]' % (busName, memberCluster))
                  else:
                      # Get list from server
                      messageEngines = AdminTask.listSIBEngines('[-bus "%s" -server "%s" -node "%s"]' % (busName, memberServer, memberNode))
                  
                  dumpMessageEngines("%s.busmembers.%d" % (prefix,bmidx), wsadminToList(messageEngines),includeUUID)
                  
      printLine("%s.busmembers.count = %d" % (prefix,bmidx))
      printLine(" ")
      
      mediationMap = dumpSIBMediations(busName,prefix,includeUUID)
      dumpSIBQueues(busName, prefix,includeUUID,busMemberTarget,busMemberTargetPattern,destinationTarget,destinationTargetPattern,mediationMap=mediationMap)
      dumpSIBTopics(busName, prefix,includeUUID,destinationTarget,destinationTargetPattern,mediationMap=mediationMap)
      dumpSIBAliases(busName, prefix,includeUUID,destinationTarget=destinationTarget,destinationTargetPattern=destinationTargetPattern)
      dumpSIBForeignDestinations(busName,prefix,includeUUID,destinationTarget=None,destinationTargetPattern=None)
      
      
      
    printLine("app.sibus.count = %d" %idx)

#enddef

#--------------------------------------------------------------------------------
# dumpObjectCacheProviders
#--------------------------------------------------------------------------------
def dumpObjectCacheProviders(targetCluster=None,targetNode=None,targetServer=None,wildcard="*",serverList=None,membersList=None):

    prtheader = 1
    providerList = wsadminToList(AdminConfig.list("CacheProvider"))
    providerIdx = 0
    for provider in providerList:
        if (isEmpty(provider)):
            continue
        
        c,n,s,dc,app,appdep = getScope(provider)

        if (not isEmpty(targetCluster)):
          memberMatch = 0
          if (membersList != None):
            if (not isEmpty(n) and not isEmpty(s)):
              member = (n,s)
              if (member not in membersList):
                continue
              else:
                memberMatch = 1
                
          if (not memberMatch and not checkPossibleWildcardMatch(c, targetCluster, wildcard)):
            continue        

        if (not isEmpty(targetNode)):
          if ((targetNode != n)):
            continue
          
          if (not isEmpty(targetServer)):
            if (targetServer != s):
              continue
          elif (not isEmpty(s)):
            continue           

        if (isEmpty(targetServer) and serverList != None and [n,s] not in serverList):
          continue
        
        cacheList = wsadminToList(AdminConfig.list("ObjectCacheInstance", provider))
        if ( len(cacheList) == 1 and isEmpty(cacheList[0])):
            cacheList = []

        servletCacheList = wsadminToList(AdminConfig.list("ServletCacheInstance", provider))
        if ( len(servletCacheList) == 1 and isEmpty(servletCacheList[0])):
            servletCacheList = []

        
        if (len(cacheList) > 0 or len(servletCacheList) > 0):
          
            # We'll print out this provider
            if (prtheader):
              prtheader = 0
              printLine("")
              printLine("#---------------------------------------------------------------")
              printLine("# Object Cache")
              printLine("#---------------------------------------------------------------")
              printLine("")
            
            
            providerIdx = providerIdx + 1
            
            
            prefix = "app.cacheprovider.%d" % providerIdx
            
            printLine("%s.cluster = %s" % (prefix, c))
            printLine("%s.node = %s" % (prefix, n))
            printLine("%s.server = %s" % (prefix, s))

            if (not isEmpty(dc)):
              printLine("%s.dynamicCluster = %s" % (prefix,dc))
    
            if (not isEmpty(app)):
              printLine("%s.application = %s" % (prefix,app))
  
            if (not isEmpty(appdep)):
              printLine("%s.deployment = %s" % (prefix,appdep))         
            
                        
            
            
            printLine("%s.name = %s" % (prefix, AdminConfig.showAttribute(provider,"name")))
            printSimpleProperties("%s.prop" % prefix, provider, ["name"])
            dumpResourceProperties(provider,"propertySet",prefix)
            referenceableList = AdminConfig.list("Referenceable",provider)
            refidx = 0
            for referenceableId in referenceableList:
                if (isEmpty(referenceableId)):
                    continue
                refidx = refidx + 1
                printSimpleProperties("%s.referenceables.%d.prop" % (prefix,refidx), referenceableId,[])
                
            printLine(" ")
            if (len(cacheList) > 0):
              dumpObjectCacheList(prefix, cacheList)
              
            if (len(servletCacheList) > 0):
              printLine(" ")
              dumpServletCacheList(prefix, servletCacheList)
    
    printLine("app.cacheprovider.count = %d" % providerIdx)
            
						

#------------------------------------------------------------------------------
# dumpObjectCache
#------------------------------------------------------------------------------
def dumpObjectCacheList(providerPrefix, cacheList): 

  
  cacheidx = 0
  for objectCacheId in cacheList:
    if (isEmpty(objectCacheId)):
          continue
    cacheidx = cacheidx+1
    prefix = "%s.objectcache.%d" % (providerPrefix,cacheidx)
    
    printLine("%s.name = %s" % (prefix, AdminConfig.showAttribute(objectCacheId,"name")))
    
    printSimpleProperties("%s.prop" % prefix, objectCacheId, ["name","memoryCacheSizeInMB"])
    
    # cacheReplication DRSSettings
    cacheReplicationId = AdminConfig.showAttribute(objectCacheId,"cacheReplication")
    if (not isEmpty(cacheReplicationId)):
        printSimpleProperties("%s.cacheReplication.prop" % prefix, cacheReplicationId, [])
    
    # diskCacheCustomPerformanceSettings DiskCacheCustomPerformanceSettings
    diskCacheCustomPerformanceSettingsId = AdminConfig.showAttribute(objectCacheId, "diskCacheCustomPerformanceSettings")
    if (not isEmpty(diskCacheCustomPerformanceSettingsId)):
        printSimpleProperties("%s.diskCacheCustomPerformanceSettings.prop" % prefix, diskCacheCustomPerformanceSettingsId, [])
    
    # diskCacheEvictionPolicy DiskCacheEvictionPolicy
    diskCacheEvictionPolicyId = AdminConfig.showAttribute(objectCacheId, "diskCacheEvictionPolicy")
    if (not isEmpty(diskCacheEvictionPolicyId)):
        printSimpleProperties("%s.diskCacheEvictionPolicy.prop" % prefix, diskCacheEvictionPolicyId, [])
    
    # memoryCacheEvictionPolicy MemoryCacheEvictionPolicy   # New to v7
    # memoryCacheSizeInMB int                               # New to v7
    try:
      if (isValidAttribute("ObjectCacheInstance","memoryCacheSizeInMB")):
        printLine("%s.prop.memoryCacheSizeInMB = %s" % (prefix, AdminConfig.showAttribute(objectCacheId,"memoryCacheSizeInMB")))
      
      if (isValidAttribute("ObjectCacheInstance","memoryCacheEvictionPolicy")):
        memoryCacheEvictionPolicyId = AdminConfig.showAttribute(objectCacheId,"memoryCacheEvictionPolicy")
        if (not isEmpty(memoryCacheEvictionPolicyId)):
          printSimpleProperties("%s.memoryCacheEvictionPolicy.prop" % prefix, memoryCacheEvictionPolicyId,[])
    except:
      pass
    
    dumpResourceProperties(objectCacheId,"propertySet",prefix)
    printLine("")
  
  
  printLine("%s.objectcache.count = %d" % (providerPrefix,cacheidx))
  printLine(" ")


#------------------------------------------------------------------------------
# dumpServletCacheList
#------------------------------------------------------------------------------
def dumpServletCacheList(providerPrefix, cacheList):  

  
  cacheidx = 0
  for cacheId in cacheList:
    if (isEmpty(cacheId)):
          continue
    cacheidx = cacheidx+1
    prefix = "%s.servletcache.%d" % (providerPrefix,cacheidx)
    
    printLine("%s.name = %s" % (prefix, AdminConfig.showAttribute(cacheId,"name")))
    printSimpleProperties("%s.prop" % prefix, cacheId, ["name"],printSimpleChildren=1,printPropertyAttributes=1)
    
    printLine("")
  
  
  printLine("%s.servletcache.count = %d" % (providerPrefix,cacheidx))
  printLine(" ")

#-------------------------------------------------------------------------------
# dumpJ2CResourceAdapters
#-------------------------------------------------------------------------------
def dumpJ2CResourceAdapters(pattern=None,targetCluster=None,targetNode=None,targetServer=None,targetCell=None,wildcard="*",serverList=None,**options):
  try:
    if (options == None):
      options = {}
    
    showBuiltIns = options.get("-builtins","false")
      
    resourceAdapters = listResourceCandidatesAtScope("J2CResourceAdapter",targetCluster,targetNode,targetServer,targetCell,wildcard="*",serverList=None)
    
    idx = 0
    for ra in resourceAdapters:
      if (isEmpty(ra)):
        continue
        
      c,n,s,dc,app,appdep = getScope(ra)
      j2cName = AdminConfig.showAttribute(ra,"name")
      if (showBuiltIns == "false"):
        if (j2cName in ['SIB JMS Resource Adapter','WebSphere Relational Resource Adapter','WebSphere MQ Resource Adapter']):
          continue
          
      idx += 1
      printScopeLines("app.j2c.%d" % idx,c,n,s,dc,app,appdep)
      
      dumpJ2CResourceAdapter("app.j2c.%d" % idx,ra,j2cName)
      printLine("")
      
      
  except:
    _app_message("Problem in dumpJ2CResourceAdapters","exception")
     


#------------------------------------------------------------------------
# Utility method for finding MessageListener corresponding to activationSpec
#------------------------------------------------------------------------
def findMessageListenerForActivationSpec(resourceAdapter,activationSpec):
  retval = None
  mls = AdminConfig.list("MessageListener",resourceAdapter).splitlines()
  for ml in mls:
    if (isEmpty(ml)):
      continue
    actspecs = AdminConfig.list("ActivationSpec",ml).splitlines()
    for as in actspecs:
      if (as == activationSpec):
        retval = ml
        break
    
    if (not isEmpty(retval)):
      break
  
  return retval

#------------------------------------------------------------------------
# Utility method for finding Message Listener type corresponding to activationSpec
#------------------------------------------------------------------------
def getMessageListenerTypeForActivationSpec(resourceAdapter,activationSpec):
  retval = None
  ml = findMessageListenerForActivationSpec(resourceAdapter,activationSpec)
  if (not isEmpty(ml)):
    retval = AdminConfig.showAttribute(ml,"messageListenerType")
  return retval
  
  
#-------------------------------------------------------------------------------
# dumpJ2CResourceAdapter
#-------------------------------------------------------------------------------
def dumpJ2CResourceAdapter(prefix, resourceAdapter,raName=None):
  
  if (raName == None):
    raName = AdminConfig.showAttribute(resourceAdapter,"name")
  printLine("%s.name = %s" % (prefix,raName))
  printSimpleProperties("%s.prop" % prefix, resourceAdapter, ["name"])
  
  dumpResourceProperties(resourceAdapter,"propertySet","%s.propertySet" % prefix)
  
  deploymentDescriptor = AdminConfig.showAttribute(resourceAdapter,"deploymentDescriptor")
  if (not isEmpty(deploymentDescriptor)):
      printLine(" ")
      printLine("#Deployment descriptor settings included for info only. Not used for applying settings")
      printSimpleProperties("%s.deploymentDescriptor.prop" % prefix, deploymentDescriptor, [])
      ddresourceAdapter = AdminConfig.showAttribute(deploymentDescriptor,"resourceAdapter")
      if (not isEmpty(ddresourceAdapter)):
          printSimpleProperties("%s.deploymentDescriptor.resourceAdapter.prop" % (prefix) ,ddresourceAdapter)
          ddaolist = AdminConfig.showAttribute(ddresourceAdapter,"adminObjects")
          if (not isEmpty(ddaolist)):
              ddaoidx = 0
              for ddao in wsadminToList(ddaolist):
                  ddaoidx = ddaoidx + 1
                  printSimpleProperties("%s.deploymentDescriptor.resourceAdapter.adminObjects.%d.prop" % (prefix, ddaoidx), ddao)
              printLine("%s.deploymentDescriptor.resourceAdapter.adminObjects.count = %d" % (prefix, ddaoidx))
                  

  j2cAdminObjects = AdminConfig.showAttribute(resourceAdapter, "j2cAdminObjects")
  if (not isEmpty(j2cAdminObjects)):
      printLine(" ")
      j2cAdminObjects = wsadminToList(j2cAdminObjects)
      aoidx = 0
      for j2cAdminObject in j2cAdminObjects:
          if (isEmpty(j2cAdminObject)):
              continue
          aoidx = aoidx + 1
          printLine("%s.j2cAdminObjects.%d.name = %s" % (prefix, aoidx, AdminConfig.showAttribute(j2cAdminObject,"name")))
          printSimpleProperties("%s.j2cAdminObjects.%d.prop" % (prefix, aoidx), j2cAdminObject, ["name"])
          resourcePropList = wsadminToList(AdminConfig.showAttribute(j2cAdminObject,"properties"))
          dumpResourcePropertiesList("%s.j2cAdminObjects.%d.properties" % (prefix, aoidx), resourcePropList)
          # Need to dump information on the AdminObject this J2CAdminObject refers to
          adminObjectId = AdminConfig.showAttribute(j2cAdminObject,"adminObject")
          if (not isEmpty(adminObjectId)):
            printSimpleProperties("%s.j2cAdminObjects.%d.adminObject.prop" % (prefix, aoidx), adminObjectId)
          printLine(" ")
      printLine("%s.j2cAdminObjects.count = %d" % (prefix,aoidx))
      
  j2cActivationSpecs = AdminConfig.showAttribute(resourceAdapter,"j2cActivationSpec")
  
  if (not isEmpty(j2cActivationSpecs)):
      j2cActivationSpecs = wsadminToList(j2cActivationSpecs)
      actspecidx = 0
      for j2cActivationSpec in j2cActivationSpecs:
          if (isEmpty(j2cActivationSpec)):
              continue
          actspecidx = actspecidx + 1
          printLine("%s.j2cActivationSpec.%d.name = %s" % (prefix, actspecidx, AdminConfig.showAttribute(j2cActivationSpec,"name")))
          printSimpleProperties("%s.j2cActivationSpec.%d.prop" % (prefix, actspecidx), j2cActivationSpec, ["name"])
          
          activationSpec = AdminConfig.showAttribute(j2cActivationSpec,"activationSpec")
          if (not isEmpty(activationSpec)):
              printLine("# Information used to find ActivationSpec for this J2CActivationSpec")
              mltype = getMessageListenerTypeForActivationSpec(resourceAdapter,activationSpec)
              printLine("%s.j2cActivationSpec.%d.activationSpec.messageListener.messageListenerType = %s" % (prefix, actspecidx, mltype))
              printSimpleProperties("%s.j2cActivationSpec.%d.activationSpec.prop" % (prefix, actspecidx), activationSpec)
          
          resourcePropList = wsadminToList(AdminConfig.showAttribute(j2cActivationSpec,"resourceProperties"))
          dumpResourcePropertiesList("%s.j2cActivationSpec.%d.properties" % (prefix, actspecidx), resourcePropList)
          printLine(" ")
      printLine("%s.j2cActivationSpec.count = %d" % (prefix, actspecidx))
          
          
  cfList = AdminConfig.list("J2CConnectionFactory", resourceAdapter).split(SEPARATOR)
  cfidx = 0
  for cf in cfList:
    if (isEmpty(cf)):
        continue
    cfidx = cfidx + 1
    printLine(" ")
    printLine("%s.cf.%d.name = %s"  % (prefix,cfidx, AdminConfig.showAttribute(cf,"name")))
    printSimpleProperties("%s.cf.%d.prop" % (prefix, cfidx), cf, ["name"])
    
    # Output connectionDefinition for reference
    connectionDefinition =  AdminConfig.showAttribute(cf,"connectionDefinition")
    if (not isEmpty(connectionDefinition)):
        printLine("# settings used to locate ConnectionDefinition reference")
        printSimpleProperties("%s.cf.%d.connectionDefinition.prop" % (prefix,cfidx), connectionDefinition, [])
    
    connPool = AdminConfig.showAttribute(cf,"connectionPool")
    if (not isEmpty(connPool)):
        printSimpleProperties("%s.cf.%d.connectionPool.prop" % (prefix, cfidx), connPool, [])
        
        custprops=AdminConfig.showAttribute(connPool,"properties")
        if (not isEmpty(custprops)):
          for cpropsitem in wsadminToList(custprops):
            cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
            cpropname = AdminConfig.showAttribute(cpropsitem,"name")
            cpropval = AdminConfig.showAttribute(cpropsitem,"value")
            if isEmpty(cpropdesc):
              printLine("%s.cf.%d.connectionPool.properties.prop.%s = %s" % (prefix, cfidx,  cpropname, cpropval))
            else:
              printLine("%s.cf.%d.connectionPool.properties.prop.%s = %s|%s" % (prefix, cfidx,  cpropname, cpropval, cpropdesc))
            
        
        
    preTestConfig = AdminConfig.showAttribute(cf,"preTestConfig")
    if (not isEmpty(preTestConfig)):
        printSimpleProperties("%s.cf.%d.preTestConfig.prop" % (prefix, cfidx), preTestConfig, [])
    
    mapping = AdminConfig.showAttribute(cf,"mapping")
    if (not isEmpty(mapping)):
        printSimpleProperties("%s.cf.%d.mapping.prop" % (prefix,cfidx), mapping, [])
        
    # V7 introduced a "properties" attribute
    cfproperties = None
    try:
      cfproperties = AdminConfig.showAttribute(cf,"properties")
    except:
      cfproperties = ""
    
    if (not isEmpty(cfproperties)):
          for cpropsitem in wsadminToList(cfproperties):
            if (not isEmpty(cpropsitem)):
              cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
              cpropname = AdminConfig.showAttribute(cpropsitem,"name")
              cpropval = AdminConfig.showAttribute(cpropsitem,"value")
              if isEmpty(cpropdesc):
                printLine("%s.cf.%d.properties.prop.%s = %s" % (prefix, cfidx,  cpropname, cpropval))
              else:
                printLine("%s.cf.%d.properties.prop.%s = %s|%s" % (prefix, cfidx,  cpropname, cpropval, cpropdesc))   
    
        
    dumpResourceProperties(cf,"propertySet","%s.cf.%d.propertySet" % (prefix,cfidx))
    
  printLine("%s.cf.count = %d" % (prefix,cfidx))
		

#-------------------------------------------------------------------------------
# dumpModuleConfig
#-------------------------------------------------------------------------------
def dumpModuleConfig(module, prefix,parmMap=None):
    #wsadminTrace("dumpModuleConfig(%s,%s)" % (module,prefix))
    
    configs = wsadminToList(AdminConfig.showAttribute(module,"configs"))
    
    filterSettings = getFilterSettings(parmMap)
    
    #print configs
    confidx = 0
    for config in configs:
        if (isEmpty(config)):
            continue
        
        try:
          if (not filterSettings.get("DeployedObjectConfig",1)):
            continue
          
          if (len(filterSettings) > 0):
            configType = callGetObjectType(config)
            if (not filterSettings.get(configType,1)):
              continue
        except:
          pass    
            
        confidx = confidx + 1
        #print AdminConfig.show(config)
        
        appconfig = 0

        try:
          sessionManagerId = AdminConfig.showAttribute(config,"sessionManagement")
          enableSFSBFailover = AdminConfig.showAttribute(config,"enableSFSBFailover")
        
          appconfig = 1 
          printLine("%s.configs.%d.type = ApplicationConfig" % (prefix, confidx))
          printSimpleProperties("%s.configs.%d.prop" % (prefix, confidx), config, [])
          
          if (not isEmpty(sessionManagerId)):
              if (filterSettings.get("SessionManager",1)):
                dumpSessionManager("%s.configs.%d.sessionManagement" % (prefix,confidx), sessionManagerId)
                
          if (filterSettings.get("DRSSettings",1)):
            drsSettings  = AdminConfig.showAttribute(config,"drsSettings")
            if (not isEmpty(drsSettings)):
              printSimpleProperties("%s.configs.%d.drsSettings.prop" % (prefix, confidx), drsSettings,[])
            
        except:
          pass        
        
        if (appconfig == 0):
          try:
            sessionManagerId = AdminConfig.showAttribute(config,"sessionManagement")
            printLine("%s.configs.%d.type = WebModuleConfig" % (prefix, confidx))
            printSimpleProperties("%s.configs.%d.prop" % (prefix, confidx), config, [])
            if (not isEmpty(sessionManagerId)):
              if (filterSettings.get("SessionManager",1)):
                dumpSessionManager("%s.configs.%d.sessionManagement" % (prefix,confidx), sessionManagerId)
            
          except:
            pass
        
        if (appconfig == 0):
          try:
            enableSFSBFailover = AdminConfig.showAttribute(config,"enableSFSBFailover")
            printLine("%s.configs.%d.type = EJBModuleConfiguration" % (prefix, confidx))
            printSimpleProperties("%s.configs.%d.prop" % (prefix, confidx), config,[])
            
            if (filterSettings.get("DRSSettings",1)):
              drsSettings  = AdminConfig.showAttribute(config,"drsSettings")
              if (not isEmpty(drsSettings)):
                printSimpleProperties("%s.configs.%d.drsSettings.prop" % (prefix, confidx), drsSettings,[])
            
            if (filterSettings.get("EnterpriseBeanConfig",1)):
              enterpriseBeanConfigs = AdminConfig.showAttribute(config,"enterpriseBeanConfigs")
              if (not isEmpty(enterpriseBeanConfigs)):
                  enterpriseBeanConfigsList = wsadminToList(enterpriseBeanConfigs)
                  beanIdx = 0
                  for enterpriseBeanConfig in enterpriseBeanConfigsList:
                    if (isEmpty(enterpriseBeanConfig)):
                      continue
                    beanIdx = beanIdx + 1
                    try:
                      timeout = AdminConfig.showAttribute(enterpriseBeanConfig,"timeout")
                      printLine("%s.configs.%d.enterpriseBeanConfigs.%d.type = StatefulSessionBeanConfig" % (prefix, confidx, beanIdx))
                    except:
                      printLine("%s.configs.%d.enterpriseBeanConfigs.%d.type = SessionBeanConfig" % (prefix, confidx, beanIdx))
                      pass
                    printSimpleProperties("%s.configs.%d.enterpriseBeanConfigs.%d.prop" % (prefix, confidx, beanIdx), enterpriseBeanConfig,[])
                    
                    instancePool = AdminConfig.showAttribute(enterpriseBeanConfig,"instancePool")
                    if (not isEmpty(instancePool)):
                        printSimpleProperties("%s.configs.%d.enterpriseBeanConfigs.%d.instancePool.prop" % (prefix, confidx, beanIdx), instancePool,[])
                  printLine("%s.configs.%d.enterpriseBeanConfigs.count = %d" % (prefix, confidx, beanIdx))
          except:
            pass
        
        
        #printSimpleProperties("%s.configs.%d.prop" % (prefix, confidx), config, [])
    printLine("%s.configs.count = %d" % (prefix,confidx))
		
#-------------------------------------------------------------------------------
# dumpTargetMappings
#-------------------------------------------------------------------------------
def dumpTargetMappings(module,prefix):
  

    targetMappingList = wsadminToList(AdminConfig.showAttribute(module,"targetMappings"))
    #AdminConfig.list("DeploymentTargetMapping",module).split(SEPARATOR)
    tmidx = 0
    for targetMapping in targetMappingList:
      if (isEmpty(targetMapping)):
          continue
      
      deploymentTarget = AdminConfig.showAttribute(targetMapping, "target")
      if (isEmpty(deploymentTarget)):
          continue
      
      tmidx = tmidx + 1
      printLine("%s.targetMappings.%d.enable = %s" % (prefix,tmidx,AdminConfig.showAttribute(targetMapping,"enable")))
      printSimpleProperties("%s.targetMappings.%d.target.prop" % (prefix,tmidx), deploymentTarget)
      #printLine("%s.targetMappings.%d.target.name = %s" % (prefix, tmidx,AdminConfig.showAttribute(deploymentTarget,"name")))
      
      
      DeployedObject = AdminConfig.showAttribute(targetMapping,"DeployedObject")
      if (not isEmpty(DeployedObject)):
          #print "DeployedObject: %s" % (DeployedObject)
          #print "DeployedObject: %s %s" % (AdminConfig.getObjectType(DeployedObject), DeployedObject)
          #printLine("%s.targetMappings.%d.DeployedObject = %s" % (prefix, tmidx, DeployedObject))
          
          if (checkConfigType(DeployedObject,"ApplicationDeployment")):
            printLine("%s.targetMappings.%d.DeployedObject.type = APPLICATION" % (prefix, tmidx))
          else:
            try:
              printLine("%s.targetMappings.%d.DeployedObject.prop.uri = %s" % (prefix, tmidx,AdminConfig.showAttribute(DeployedObject,"uri")))
              printLine("%s.targetMappings.%d.DeployedObject.type = MODULE" % (prefix, tmidx))
            except:
              printLine("%s.targetMappings.%d.DeployedObject.type = APPLICATION" % (prefix, tmidx))
          
          
    
      
      config = AdminConfig.showAttribute(targetMapping, "config")
      if (not isEmpty(config)):
          printLine("# %s.targetMappings.%d.config = %s" % (prefix,tmidx,config))
          printSimpleProperties("%s.targetMappings.%d.config.prop" % (prefix, tmidx), config, [])
    
    printLine("%s.targetMappings.count = %d" % (prefix, tmidx))

#-------------------------------------------------------------------------------
#	dumpApplicationModule
#-------------------------------------------------------------------------------
def dumpApplicationModule(module, prefix,parmMap=None):

    moduleTypes = [ "WebModuleDeployment", "ApplicationDeployment", "EJBModuleDeployment", "ConnectorModuleDeployment","ModuleDeployment" ]
    modType = None
    printLine(" ")
    
    filterSettings = getFilterSettings(parmMap)
    
    for moduleType in moduleTypes:
      if (module.find(moduleType) >= 0):
        modType = moduleType
        
        printLine("%s.type = %s" % (prefix, moduleType))
        break
    
    
    printLine("%s.uri = %s" % (prefix, AdminConfig.showAttribute(module,"uri")))
    printSimpleProperties("%s.prop" % prefix, module, ["uri"],printPropertyAttributes=1)
    
    try:
      if (modtype == None or (modtype != None and isValidAttribute(modType,"classloader"))):
        classloaderid = AdminConfig.showAttribute(module,"classloader")
        if (not isEmpty(classloaderid)):
          dumpClassloader("%s.classloader" % prefix,classloaderid)
    
    except:
      pass
      
    try:
      # As far as I know, the ejbDeployments isn't really worthwile info, if it even exists
      ejbDeployments = None
      if (modType ==None or (modType != None and isValidAttribute(modType,"ejbDeployments"))):
        ejbDeployments = AdminConfig.showAttribute(module,"ejbDeployments")
      
      #print "ejbDeployments %s" % ejbDeployments
      if (not isEmpty(ejbDeployments)):
          ejbList = wsadminToList(ejbDeployments)
          ejbidx = 0
          for ejbDeployment in ejbList:
              ejbidx = ejbidx + 1
              printSimpleProperties("%s.EJBModuleDeployment.ejbDeployments.%d.prop" % (prefix,ejbidx), ejbDeployment,[])
          
          printLine("%s.EJBModuleDeployment.ejbDeployments.count = %d" % (prefix,ejbidx))
              
    except:
      pass
      
    try:
      if (modType == None or (modType != None and isValidAttribute(modType,"resourceAdapter"))):
        resourceAdapter = AdminConfig.showAttribute(module,"resourceAdapter")
            
        # No exception, so should be ConnectorModuleDeployment
        if (not isEmpty(resourceAdapter)):
            dumpJ2CResourceAdapter("%s.resourceAdapter" % (prefix), resourceAdapter)
            
    except:
      pass
    
    dumpModuleConfig(module, prefix,parmMap=parmMap)
    
    if (filterSettings.get("DeploymentTargetMapping",1)):
      dumpTargetMappings(module,prefix)
		


#-------------------------------------------------------------------------------
def dumpApplicationDeployment(applist=None,pattern=None,parmMap=None):
  
  #wsadminTrace("dumpApplicationDeployment(%s)" % applist)

  if (applist == None):
    applist = AdminApp.list().split(SEPARATOR)
    
  appidx = 0
  
  filterSettings = getFilterSettings(parmMap)
  
  if (not filterSettings.get("Deployment",1)):
    return
  
  printLine("\n#----------------------------------------------------------------------")
  printLine("# Application Deployment ")
  printLine("#----------------------------------------------------------------------")
  for appName in applist:
      if (isEmpty(appName)):
          continue
          
      if (not isEmpty(pattern)):
        if (pattern.find("*") < 0):
          # Test for equality
          if (appName != pattern):
            continue
        elif (not re.match(pattern,appName)):
          continue
          
      
      deployments = AdminConfig.getid("/Deployment:%s" % appName)
      if (isEmpty(deployments)):
          continue
      deployedObject = AdminConfig.showAttribute(deployments,"deployedObject")
      if (isEmpty(deployedObject)):
          continue
          
      appidx = appidx+1
      prefix = "app.appdeployment.%d" % appidx
      printLine("%s.name = %s" % (prefix, appName))
      
      
      dtidx = 0
      if (filterSettings.get("DeploymentTarget",1)):
        deploymentTargets = AdminConfig.showAttribute(deployments,"deploymentTargets")
        if (not isEmpty(deploymentTargets)):
            for deploymentTarget in wsadminToList(deploymentTargets):
                if (isEmpty(deploymentTarget)):
                    continue
                dtidx = dtidx + 1
                printSimpleProperties("%s.deploymentTarget.%d" % (prefix, dtidx), deploymentTarget)
            
            printLine("%s.deploymentTarget.count = %d" % (prefix,dtidx))
                
      
      prefix = "%s.deploymentObject" % prefix
      
      printBasicProperties = 1
      if (len(filterSettings) > 0):
        if (not filterSettings.get("DeployedObject",1)):
          printBasicProperties = 0
        else:
          deploymentType = callGetObjectType(deployedObject)
          if (not filterSettings.get(deploymentType,1)):
            printBasicProperties = 0

      if (printBasicProperties):          
        printSimpleProperties("%s.prop" % prefix, deployedObject,[],printPropertyAttributes=1)
      
      try:
        classloaderid = AdminConfig.showAttribute(deployedObject,"classloader")
        if (not isEmpty(classloaderid)):
            dumpClassloader("%s.classloader" % prefix,classloaderid)
      except:
        pass
      
      # Dump the application config
      dumpModuleConfig(deployedObject, prefix,parmMap=parmMap)
      
      # Now do the modules
      modules = wsadminToList(AdminConfig.showAttribute(deployedObject,"modules"))
      modidx = 0
      for module in modules:
          if (isEmpty(module)):
              continue
          
          if (len(filterSettings) > 0):
            otype = callGetObjectType(module)
            if (not filterSettings.get(otype,1)):
              # Skip this module
              continue    
              
          modidx = modidx + 1
          modprefix = "%s.modules.%d" % (prefix, modidx)
          dumpApplicationModule(module, modprefix,parmMap)
      printLine("%s.modules.count = %d" % (prefix, modidx))
      
      if (filterSettings.get("DeploymentTargetMapping",1)):
        dumpTargetMappings(deployedObject,prefix)
          
      printLine(" ")
  
  printLine("app.appdeployment.count = %d" % appidx)


# callViewAsset
#
# This is a workaround issues for viewAsset implementation
# http://www-01.ibm.com/support/docview.wss?uid=swg1PM22463
def callViewAsset(asset):

  oldOut = java.lang.System.out
  assetString = ""
  try:
    baos = java.io.ByteArrayOutputStream()
    ps = java.io.PrintStream(baos)
    java.lang.System.setOut(ps)
    
    AdminTask.viewAsset('[ -assetID %s ]' % asset)
    assetString = str(baos.toString())
  except:
    java.lang.System.setOut(oldOut)
    _app_message("Error calling viewAsset")
    assetString = ""
    
  java.lang.System.setOut(oldOut)
  
  return assetString


#--------------------------------------------------------------------
# dumpAssets
#
# Dump Asset definitions used by BLA
#--------------------------------------------------------------------
def dumpAssets(**options):
  
  if (options != None and options.get("-skipassets") != None):
    return
      
  if not isValidTaskMethod("listAssets"):
    return
    
  checkForOSGi = 0
  if (options != None and options.get("-osgi") != None):
    checkForOSGi = 1
  
  assets = AdminTask.listAssets().splitlines()
  assets.sort()
  assetIdx = 0
  
  if (len(assets) > 0 and not isEmpty(assets[0])):
    if (checkForOSGi):
      printLine("\n#----------\n# Assets (OSGi)\n#----------")
    else:
      printLine("\n#----------\n# Assets (BLA and OSGi)\n#----------")
  
  for asset in assets:
    if (isEmpty(asset)):
      return
    
    assetString = callViewAsset(asset)
    
    if (checkForOSGi):
      if (assetString.find("WebSphere:spec=EBA") < 0):
        continue
    
    assetIdx +=1 
    printLine("app.assets.%d.assetID = %s" % (assetIdx,asset))
    
    #print "\nCaptured asset information:\n%s" % assetString  
    assetProps = parseAssetToDictionary(assetString)
    if (len(assetProps) > 0): 
      # Use the captured output
      primaryattributes = ["name","description"]
      for key in primaryattributes:
        val = assetProps.get(key,"")
        printLine("app.assets.%d.prop.%s=%s" % (assetIdx,key,val))
      attrList = []
      for key in assetProps.keys():
        if (key not in primaryattributes):
          attrList.append(key)
      for key in attrList:
        val = assetProps.get(key)
        printLine("app.assets.%d.prop.%s=%s" % (assetIdx,key,val))
    else:
      
      # Grab the asset file
      dirName = asset
      startIdx = dirName.find("assetname=")
      if (startIdx >= 0):
        dirName = dirName[startIdx+10:]
        path="/cells/%s/assets/%s/aver/BASE/asset.xml" % (getCellName(),dirName)
        tempFileName = downloadTempFile(path)
        #print "Downloaded %s as %s" % (path,tempFileName)
        
        myXMLHandler = XMLHandler("app.assets.%d" % assetIdx,"asset",["typeAspects.typeAspect","deplUnits.deplUnit","defaultBindings.defaultBinding","relationships.relationship"])
        
        parseXML(tempFileName,myXMLHandler)
    #end if file parsing  
  
  if (assetIdx > 0):
    printLine("\napp.assets.count = %d" % assetIdx)
    
    
  
#enddef dumpAssets


def callViewCompUnit(blaID, compUnitID):
  # See if we can use viewCompUnit
  oldOut = java.lang.System.out
  compUnitString = ""
  try:
    baos = java.io.ByteArrayOutputStream()
    ps = java.io.PrintStream(baos)
    java.lang.System.setOut(ps)
    
    AdminTask.viewCompUnit("[ -blaID '%s'  -cuID '%s' ]" % (blaID,compUnitID))
    compUnitString = str(baos.toString())
    java.lang.System.setOut(oldOut)
  except:
    java.lang.System.setOut(oldOut)
    _app_message("Error calling viewCompUnit","exception")
    compUnitString = ""  
  
  return compUnitString        
      

#Changed Items	Status
#cells / OSGICell / assets / log4j-1.2.8.jar / aver / BASE / asset-ref.xml	Updated
#cells / OSGICell / blas / SecureBLA / bver / BASE / bla.xml	Updated
#cells / OSGICell / cus / log4j-1.2.8_0003.jar / cver / BASE / cu-ref.xml	Added
#cells / OSGICell / cus / log4j-1.2.8_0003.jar / cver / BASE / targets / WAS / OSGINode1+BlogServer.xml	Added
#cells / OSGICell / cus / log4j-1.2.8_0003.jar / cver / BASE / controlOpDefs.xml	Added
#cells / OSGICell / cus / log4j-1.2.8_0003.jar / cver / BASE / cu.xml	Added
#cells / OSGICell / cus / log4j-1.2.8_0003.jar / cver / BASE / meta / META-INF / MANIFEST.MF	Added
def dumpBLAs(**options):

  if (options != None and options.get("-skipblas") != None):
    
    return
   
  if not isValidTaskMethod("listBLAs"):
    print "No BLA task"
    return
  
  checkForOSGi = 0
  if (options != None and options.get("-osgi",None) != None):
    checkForOSGi = 1

  
  blas = AdminTask.listBLAs("[-includeDescription true]").splitlines()
  
  blaList = []
  blaIdx = 0
  if (len(blas) >= 1):
    if (checkForOSGi):
      printLine("\n#\n# OSGi Business Level Applications\n#\n")
    else:
      printLine("\n#\n# Business Level Applications\n#\n")
      
    idx = 0
    while idx < len(blas):
      
      blaID = blas[idx]
      
      blaDescription = ""
      if (idx+1 < len(blas)):
        blaDescription = blas[idx+1]
      
      idx+=2
      
      compUnits = None
      
      if (checkForOSGi):
        isOSGi = 0
        
        compUnits = AdminTask.listCompUnits("[ -blaID '%s' -includeType false -includeDescription false ]"%blaID).splitlines()
        for compUnitID in compUnits:
          if (isEmpty(compUnitID)):
            continue
          compUnitString = callViewCompUnit(blaID, compUnitID)
          if (compUnitString.find("ebaDeploymentUnit") > 0):
            isOSGi = 1
            break
        
        if (not isOSGi):
          continue
          

        
      
      blaIdx += 1
      printLine("app.bla.%d.blaID = %s" % (blaIdx,blaID))
      printLine("app.bla.%d.prop.description = %s" % (blaIdx,blaDescription))
      
      
      compUnits = AdminTask.listCompUnits("[ -blaID '%s' -includeType true -includeDescription true ]"%blaID).splitlines()
      
      if (len(compUnits) > 1):
        culistidx = 0
        compUnitIdx = 0
        while culistidx < len(compUnits):
          compUnitIdx +=1
          compUnitID = compUnits[culistidx]
          compUnitType = compUnits[culistidx+1]
          
          compUnitDescription = ""
          if (culistidx+2 < len(compUnits)):
            compUnitDescription = compUnits[culistidx+2]
          
          culistidx += 3
          
          # See if we can use viewCompUnit
          compUnitString = callViewCompUnit(blaID, compUnitID)
          
          cuKeys,cuDict = parseCompUnitToDictionary(compUnitString)
          
          #printLine("\n# %s" % compUnitString)
          printLine("app.bla.%d.compUnits.%d.compUnitID = %s" % (blaIdx, compUnitIdx, compUnitID))
          printLine("app.bla.%d.compUnits.%d.prop.type = %s" % (blaIdx, compUnitIdx, compUnitType))
          printLine("app.bla.%d.compUnits.%d.prop.description = %s" % (blaIdx, compUnitIdx, compUnitDescription))

          
          if (len(cuDict) > 0):
            for key in cuKeys:
               if cuDict.has_key(key):
                 val = cuDict[key]
                 printLine("app.bla.%d.compUnits.%d.%s = %s" % (blaIdx,compUnitIdx,key,val))
             
            
            deplUnit = cuDict.get("MapTargets.prop.deplUnit",None)
            if (deplUnit == None):
              deplUnit = cuDict.get("MapTargets.1.prop.deplUnit",None)
               
            if (deplUnit == "ebaDeploymentUnit"):
              try:
                cuName = compUnitID
                if (cuName.startswith("WebSphere:cuname=")):
                  cuName = cuName[17:]
                extensions = AdminTask.listOSGiExtensions("[-cuName %s ]" % cuName).splitlines()
                extIdx = 0
                for ext in extensions:
                  if (not isEmpty(ext)):
                    extIdx += 1
                    nameVer = ext.split(";")
                    extName = nameVer[0]
                    
                    extVer = ""
                    if (len(nameVer) > 1):
                      extVer = nameVer[1]
                    printLine("app.bla.%d.compUnits.%d.osgiExtensions.%d.symbolicName = %s" % (blaIdx,compUnitIdx,extIdx,extName))
                    printLine("app.bla.%d.compUnits.%d.osgiExtensions.%d.version = %s" % (blaIdx,compUnitIdx,extIdx,extVer))
              except:
                _app_message("Error listing OSGi extensions","exception")
          else:
            # Pull down cu.xml for basic parsing  
            dirName = compUnitID
            if (dirName.startswith("WebSphere:cuname=")):
              dirName = dirName[17:]
            
            path="/cells/%s/cus/%s/cver/BASE/cu.xml" % (getCellName(),dirName)
            
            tempFileName = downloadTempFile(path)
        
        
            myXMLHandler = XMLHandler("app.bla.%d.compUnits.%d" % (blaIdx,compUnitIdx),"compUnit",["deplUnits.deplUnit","targets.target","relationships.relationship","activationplans.activationplan","props.prop"])
        
            parseXML(tempFileName,myXMLHandler)
          #endif parse comp unit xml directly
      #end compunits
      printLine(" ")  
    
    printLine("app.bla.count = %d" % blaIdx)

#enddef dumpBLAs    

#-----------------------------------------------------------------------
def dumpOSGIBundles(**options):
  
  #Confirm this feature is supported
  if not isValidTaskMethod("listLocalRepositoryBundles"):
    return
    
  try:
    bundleList = AdminTask.listLocalRepositoryBundles().splitlines()
    bundleList.sort()
    bidx = 0
    for bundle in bundleList:
      if (not isEmpty(bundle)):
        bidx += 1
        
        if (bidx == 1):
           printLine("\n#-------------------------------------\n# Local OSGI Repository Bundles\n#-------------------------------------\n")
        
        binfo = bundle.split(";")
        bver = ""
        bname = binfo[0]
        if (len(binfo) > 1):
          bver = binfo[1]
        
        printLine("app.osgi.localRepositoryBundle.%d.name = %s" % (bidx,bname))
        printLine("app.osgi.localRepositoryBundle.%d.version = %s" % (bidx,bver))
        
        # Now get information about the bundle
        binfo = wsadminToDictionary(AdminTask.showLocalRepositoryBundle("[ -version '%s' -symbolicName '%s' ]" % (bver,bname)))
        keyList = []
        for key in binfo.keys():
          keyList.append(key)
        keyList.sort()
        for key in keyList:
          printLine("app.osgi.localRepositoryBundle.%d.prop.%s = %s" % (bidx, key, binfo[key]))
        
        printLine("")
    if (bidx > 0):
      printLine("app.osgi.localRepositoryBundle.count = %d" % (bidx))    
      
  except:
    _app_message("Problem in dumpOSGIBundles","exception")

#------------------------------------------------
# dumpExternalBundleRepositories
#------------------------------------------------
def dumpExternalBundleRepositories(**options):
  
  if not isValidTaskMethod("listExternalBundleRepositories"):
    return
    
  try:
    externalRepos = AdminTask.listExternalBundleRepositories().splitlines()
    ridx = 0
    for repo in externalRepos:
      if (isEmpty(repo)):
        continue
      ridx += 1
      
      if (ridx == 1):
        printLine("\n#-------------------------------------\n#External OSGI Bundle Repositories\n#-------------------------------------\n")
        
      repoName = repo
      repoProperties = wsadminToDictionary(AdminTask.showExternalBundleRepository("[-name %s ]" % repoName ))
      
      printLine("app.osgi.externalBundleRepositories.%d.name = %s" % (ridx,repoName))
      attrs = []
      for key in repoProperties.keys():
        if (key != "name"):
          attrs.append(key)
      
      attrs.sort()
      for key in attrs:
        printLine("app.osgi.externalBundleRepositories.%d.prop.%s= %s" % (ridx,key,repoProperties[key]))
      
    if (ridx > 0):
      printLine("app.osgi.externalBundleRepositories.count = %d" % (ridx))
  except:
    _app_message("Unexpected error in dumpRemoteBundleRepositories")

#------------------------------------------------------------------------------
# dumpCoreGroup
#------------------------------------------------------------------------------
def dumpCoreGroup(targetCoreGroup=None):

  printLine("#------------------------------------------------------------------")
  printLine("# CoreGroup section")
  printLine("#------------------------------------------------------------------")
  
  cgNames = AdminTask.getAllCoreGroupNames().split(SEPARATOR)
  
  cgidx = 0
  for cgName in cgNames:
      if (not isEmpty(targetCoreGroup) and targetCoreGroup != cgName):
          continue
      
      if (isEmpty(cgName)):
          continue
      
      cgidx = cgidx + 1
      
      cgId = AdminConfig.getid("/CoreGroup:%s/" % cgName)
      
      printLine("app.coregroups.%d.name = %s" % (cgidx, cgName))
      printSimpleProperties("app.coregroups.%d.prop" % cgidx, cgId, ["name"])

      printCustomProperties("app.coregroups.%d.customProperties" % (cgidx), cgId, "customProperties")
        
      # liveness (discovery) settings introduced in V7
      liveness = None
      try:
        if (isValidAttribute("CoreGroup","liveness")):
          liveness = AdminConfig.showAttribute(cgId,"liveness")
      except:
        liveness = ""
      
      if (not isEmpty(liveness)):
          printSimpleProperties("app.coregroups.%d.liveness.prop" % cgidx, liveness)
          printCustomProperties("app.coregroups.%d.liveness.customProperties" % cgidx, liveness, "customProperties")
      
      
      
      coreGroupServers = wsadminToList(AdminConfig.showAttribute(cgId,"coreGroupServers"))
      serverIdx = 0
      for coreGroupServer in coreGroupServers:
          if (isEmpty(coreGroupServer)):
              continue
          
          serverIdx = serverIdx + 1
          
          serverName = AdminConfig.showAttribute(coreGroupServer,"serverName")
          nodeName = AdminConfig.showAttribute(coreGroupServer,"nodeName")
          printLine("app.coregroups.%d.coreGroupServers.%d.serverName = %s"% (cgidx,serverIdx,serverName))
          printLine("app.coregroups.%d.coreGroupServers.%d.nodeName = %s"% (cgidx,serverIdx,nodeName))
          printSimpleProperties("app.coregroups.%d.coreGroupServers.%d.prop"% (cgidx,serverIdx), coreGroupServer,["serverName","nodeName"])
          
          printCustomProperties("app.coregroups.%d.coreGroupServers.%d.customProperties" % (cgidx,serverIdx), coreGroupServer, "customProperties")
          
                
      printLine("app.coregroups.%d.coreGroupServers.count = %d" % (cgidx, serverIdx))
          
      preferredCoordinatorServers = wsadminToList(AdminConfig.showAttribute(cgId,"preferredCoordinatorServers"))
      serverIdx = 0
      for preferredCoordinatorServer in preferredCoordinatorServers:
          if (isEmpty(preferredCoordinatorServer)):
              continue
          
          serverIdx = serverIdx + 1
          serverName = AdminConfig.showAttribute(preferredCoordinatorServer,"serverName")
          nodeName = AdminConfig.showAttribute(preferredCoordinatorServer,"nodeName")
          printLine("app.coregroups.%d.preferredCoordinatorServers.%d.serverName = %s"% (cgidx,serverIdx,serverName))
          printLine("app.coregroups.%d.preferredCoordinatorServers.%d.nodeName = %s"% (cgidx,serverIdx,nodeName))
          printSimpleProperties("app.coregroups.%d.preferredCoordinatorServers.%d.prop"% (cgidx,serverIdx), preferredCoordinatorServer,["serverName","nodeName"]) 
      
      printLine("app.coregroups.%d.preferredCoordinatorServers.count = %d" % (cgidx, serverIdx))
      
      policyTypes = ["AllActivePolicy", "NoOpPolicy", "PreferredServerPolicy", "MOfNPolicy", "OneOfNPolicy", "StaticPolicy"]
      matchedPolicyType = None
      policies = AdminConfig.showAttribute(cgId,"policies")
      policyList = wsadminToList(policies)
      if (not isEmpty(policies)):
          pidx = 0
          for policy in policyList:
              pidx = pidx + 1
              for policyType in policyTypes:
                  if (policy.find(policyType) > 0):
                      printLine("app.coregroups.%d.policies.%d.policyType = %s" % (cgidx, pidx, policyType))
                      matchedPolicyType = policyType
                      break
              
              pname = AdminConfig.showAttribute(policy,"name")
              pdesc = AdminConfig.showAttribute(policy,"description")
              printLine("app.coregroups.%d.policies.%d.name = %s" % (cgidx, pidx, pname))
              printLine("app.coregroups.%d.policies.%d.prop.description = %s" % (cgidx, pidx, pdesc))
              printSimpleProperties("app.coregroups.%d.policies.%d.prop" % (cgidx,pidx), policy, ["name","description"])
              
              matchCriteria = AdminConfig.showAttribute(policy,"MatchCriteria")
              if (not isEmpty(matchCriteria)):
                  mcidx = 0
                  for mc in wsadminToList(matchCriteria):
                      if (isEmpty(mc)): continue
                      mcidx = mcidx+1
                      mcname = AdminConfig.showAttribute(mc,"name")
                      mcdesc = AdminConfig.showAttribute(mc,"description")
                      mcvalue = AdminConfig.showAttribute(mc,"value")
                      printLine("app.coregroups.%d.policies.%d.matchCriteria.%d.name = %s" % (cgidx, pidx, mcidx, mcname))
                      printLine("app.coregroups.%d.policies.%d.matchCriteria.%d.description = %s" % (cgidx, pidx, mcidx, mcdesc))
                      printLine("app.coregroups.%d.policies.%d.matchCriteria.%d.value = %s" % (cgidx, pidx, mcidx, mcvalue))
                  
                  printLine("app.coregroups.%d.policies.%d.matchCriteria.count = %d" % (cgidx, pidx, mcidx))
              
              printCustomProperties("app.coregroups.%d.policies.%d.customProperties" % (cgidx,pidx), policy, "customProperties")
              
              # Not all policies have preferred servers
              preferredServers = None
              if (matchedPolicyType != None and isValidAttribute(matchedPolicyType,"preferredServers")):
                preferredServers = AdminConfig.showAttribute(policy,"preferredServers")
              elif (matchedPolicyType == None):
                try:
                  preferredServers = AdminConfig.showAttribute(policy,"preferredServers")
                except:
                  preferredServers = ""
              
              if (not isEmpty(preferredServers)):
                  serverIdx = 0
                  for svr in wsadminToList(preferredServers):
                      if (isEmpty(svr)): continue
                      serverIdx = serverIdx + 1
                      serverName = AdminConfig.showAttribute(svr,"serverName")
                      nodeName = AdminConfig.showAttribute(svr,"nodeName")
                      printLine("app.coregroups.%d.policies.%d.preferredServers.%d.serverName = %s"% (cgidx,pidx,serverIdx,serverName))
                      printLine("app.coregroups.%d.policies.%d.preferredServers.%d.nodeName = %s"% (cgidx,pidx,serverIdx,nodeName))
                      
                  
                  printLine("app.coregroups.%d.policies.%d.preferredServers.count = %d"% (cgidx,pidx,serverIdx))
                      
              
              printLine(" ")
              
          printLine("app.coregroups.%d.policies.count = %d" % (cgidx,pidx))   
                      
    
      printLine(" ")
  
  printLine("app.coregroups.count = %d" % cgidx)
  printLine(" ")

#-------------------------------------------------------------------------------
#
def dumpJAASConfiguration(prefix,configId):
	jaasentries = wsadminToList(AdminConfig.showAttribute(configId,"entries"))
	eidx = 0
	for jaasentry in jaasentries:
		if (isEmpty(jaasentry)): continue
		
		eidx = eidx + 1
		alias = AdminConfig.showAttribute(jaasentry,"alias")
		printLine("%s.entries.%d.alias = %s" % (prefix,eidx,alias))
		
		loginModules = wsadminToList(AdminConfig.showAttribute(jaasentry,"loginModules"))
		lmidx = 0
		for loginModule in loginModules:
			if (isEmpty(loginModule)): continue
			lmidx = lmidx + 1
			printSimpleProperties("%s.entries.%d.loginModules.%d.prop" % (prefix,eidx,lmidx) ,loginModule)
			printCustomProperties("%s.entries.%d.loginModules.%d.options" % (prefix,eidx,lmidx),loginModule,"options")
		printLine("%s.entries.%d.loginModules.count = %d" % (prefix,eidx,lmidx))
	
	printLine("%s.entries.count = %d" % (prefix,eidx))

#--------------------------------------------------------------------------------
# dumpAuthMechanism
#--------------------------------------------------------------------------------
def dumpAuthMechanism(authtype,prefix, configId):
	authtypes = ['SWAMAuthentication', 'LTPA', 'CustomAuthMechanism', 'KRB5', 'RSAToken', 'SPNEGO']
	printLine("%s.type = %s" % (prefix, authtype))
	printSimpleProperties("%s.prop" % prefix, configId)
	
	#digestAuthentication DigestAuthentication
  #properties Property(TypedProperty, DescriptiveProperty)*
  #singleSignon SingleSignon
	#trustAssociation TrustAssociation
	digestAuthId = None
	if (checkConfigType(configId,"LTPA")):
	  if (isValidAttribute("LTPA","digestAuthentication")):
	    digestAuthId = AdminConfig.showAttribute(configId,"digestAuthentication")
	else:
	  try:
		  digestAuthId = AdminConfig.showAttribute(configId,"digestAuthentication")
	  except:
		  digestAuthId = None
		
	if (not isEmpty(digestAuthId)):
		printSimpleProperties("%s.digestAuthentication.prop" % prefix, digestAuthId)
	
	singleSignonId = AdminConfig.showAttribute(configId,"singleSignon")
	if (not isEmpty(singleSignonId)):
		printSimpleProperties("%s.singleSignon.prop" % prefix, singleSignonId)
		
	trustAssociationId = AdminConfig.showAttribute(configId,"trustAssociation")
	if (not isEmpty(trustAssociationId)):
		printSimpleProperties("%s.trustAssociation.prop" % prefix, trustAssociationId)
		tais = wsadminToList(AdminConfig.showAttribute(trustAssociationId,"interceptors"))
		taiidx = 0
		for tai in tais:
			if (isEmpty(tai)):continue
			taiidx = taiidx + 1
			interceptorClassName = AdminConfig.showAttribute(tai,"interceptorClassName")
			printLine("%s.trustAssociation.interceptors.%d.interceptorClassName = %s" % (prefix,taiidx,interceptorClassName))
			printCustomProperties("%s.trustAssociation.interceptors.%d.trustProperties"% (prefix,taiidx) , tai, "trustProperties")
			
		printLine("%s.trustAssociation.interceptors.count = %d" % (prefix,taiidx))
		
	printCustomProperties("%s.properties" % prefix, configId, "properties")
	

def dumpUserRegistry(registryType, prefix, configId):
	printLine("%s.type = %s" % (prefix, registryType))
	printSimpleProperties("%s.prop" % (prefix), configId)
	
	if (registryType == "LDAPUserRegistry"):
		hosts = wsadminToList(AdminConfig.showAttribute(configId,"hosts"))
		hidx = 0
		for host in hosts:
			if isEmpty(host):continue
			hidx = hidx + 1
			printSimpleProperties("%s.hosts.%d.prop" % (prefix,hidx),host)
		printLine("%s.hosts.count = %d" % (prefix,hidx))
		
		searchFilter = AdminConfig.showAttribute(configId,"searchFilter")
		if not isEmpty(searchFilter):
			printSimpleProperties("%s.searchFilter.prop" % (prefix), searchFilter)
		
	
	printCustomProperties("%s.properties" % (prefix),configId,"properties")

#-------------------------------------------------------------------------------
# Dump settings that are common to global and security domains
#-------------------------------------------------------------------------------
def dumpCommonSecurity(configId, prefix):
	
	authtypes = ['SWAMAuthentication', 'LTPA', 'CustomAuthMechanism', 'KRB5', 'RSAToken', 'SPNEGO']
	registrytypes = ['LocalOSUserRegistry', 'LDAPUserRegistry', 'CustomUserRegistry', 'WIMUserRegistry']
	
	printSimpleProperties("%s.prop" % prefix, configId,[])
	printCustomProperties("%s.properties" % prefix, configId, "properties")
	
	activeAuth =  AdminConfig.showAttribute(configId,'activeAuthMechanism')
	if (not isEmpty(activeAuth)):
		for authtype in authtypes:
			if activeAuth.find(authtype) >= 0:
				printLine("%s.activeAuthMechanism = %s" % (prefix, authtype))
				break
	
	authMechanisms = wsadminToList(AdminConfig.showAttribute(configId,"authMechanisms"))
	authidx  = 0
	for authMechanism in authMechanisms:
		if (isEmpty(authMechanism)): continue
		authidx = authidx + 1
		currentauthtype = "Unknown"
		for authtype in authtypes:
			if authMechanism.find(authtype) >= 0:
				currentauthtype = authtype
				break
		dumpAuthMechanism(currentauthtype,"%s.authMechanisms.%d" % (prefix,authidx), authMechanism)
	
	printLine("%s.authMechanisms.count = %d" % (prefix,authidx))
	printLine(" ")
	
	activeUserRegistry = AdminConfig.showAttribute(configId,"activeUserRegistry")
	if not isEmpty(activeUserRegistry):
		for regtype in registrytypes:
			if activeUserRegistry.find(regtype) >= 0:
				printLine("%s.activeUserRegistry = %s" % (prefix,regtype))
				break
	
	userRegistries = wsadminToList(AdminConfig.showAttribute(configId,"userRegistries"))
	regidx = 0
	for userRegistry in userRegistries:
		if isEmpty(userRegistry): continue
		regidx = regidx + 1
		registryType = "Unknown"
		for regtype in registrytypes:
			if userRegistry.find(regtype) >= 0:
				registryType = regtype
				break
		dumpUserRegistry(registryType,"%s.userRegistries.%d" % (prefix,regidx),userRegistry)
	printLine("%s.userRegistries.count = %d" % (prefix,regidx))
	printLine(" ")

	keystores = wsadminToList( AdminConfig.showAttribute(configId,"keyStores"))
	keyidx = 0
	for keystore in keystores:
		if isEmpty(keystore):
			continue
		
		keyidx = keyidx+1
		keyname = AdminConfig.showAttribute(keystore,"name")
		printLine("%s.keyStores.%d.name = %s" % (prefix, keyidx, keyname))
		managementScope =  AdminConfig.showAttribute(keystore,"managementScope")
		if not isEmpty(managementScope):
			printSimpleProperties("%s.keyStores.%d.managementScope.prop" % (prefix,keyidx), managementScope)
		printSimpleProperties("%s.keyStores.%d.prop" % (prefix,keyidx), keystore, ["name"])
		printCustomProperties("%s.keyStores.%d.additionalKeyStoreAttrs" % (prefix,keyidx), keystore, "additionalKeyStoreAttrs")
	
	printLine("%s.keyStores.count = %d" % (prefix,keyidx))
		
	systemLoginConfig = AdminConfig.showAttribute(configId, "systemLoginConfig")
	if not isEmpty(systemLoginConfig):
		dumpJAASConfiguration("%s.systemLoginConfig" % prefix,systemLoginConfig)
		
	applicationLoginConfig = AdminConfig.showAttribute(configId,"applicationLoginConfig")
	if not isEmpty(applicationLoginConfig):
		dumpJAASConfiguration("%s.applicationLoginConfig" % prefix, applicationLoginConfig)
	

#-------------------------------------------------------------------------------
# dumpSecurity - a basic export of high level security settings
#-------------------------------------------------------------------------------
def dumpSecurity(**options):
	
	if (options != None and options.get("-skipsecurity") != None):
	  return
	  
	printLine("# Global Security")
	securityId = AdminConfig.list("Security").split(SEPARATOR)[0]
	
	dumpCommonSecurity(securityId,"app.security.global")
	printLine(" ")
	try:
		secdomains = AdminTask.listSecurityDomains().split(SEPARATOR)
	except:
		# WAS 6.1
		secdomains = []
	
	secidx = 0
	for secdomain in secdomains:
		if (isEmpty(secdomain)):
			continue
		secidx = secidx + 1
		appsecurity =AdminConfig.getid("/SecurityDomain:%s/AppSecurity:/" % secdomain)
		printLine("app.security.domain.%d.name =  %s" % (secidx,secdomain))
		dumpCommonSecurity(appsecurity,"app.security.domain.%d" % secidx)
		printLine(" ")
	printLine("app.security.domain.count = %d" % secidx)


def dumpHealthClass(**options):
  try:
    prtHeader = 0
    
    hclist = AdminConfig.list("HealthClass").splitlines()
    hcidx = 0
    for hc in hclist:
      if (isEmpty(hc)):
        continue
      hcidx +=1
      
      if (not prtHeader):
        printLine("\n#--------------------------\n# Health Policies\n#--------------------------")
        prtHeader = 1
      
      if (hcidx > 1):
        printLine("")
        
      props = {}
      nestedIds = {}
      collectSimpleProperties(props, "prop",hc, optionalSkipList=[],nestedIds=nestedIds)
      
      prefix = "app.im.healthClass.%d" % (hcidx)
      printLine("%s.name = %s" % (prefix,props.get("prop.name","")))
      sortedKeys = []
      for key in props.keys():
        sortedKeys.append(key)
      sortedKeys.sort()
      for key in sortedKeys:
        
        # This includes "prop."
        if (key == "prop.name"):
          continue
        printLine("%s.%s = %s"% (prefix,key,props.get(key)))
        
      for key in nestedIds.keys():
        val = nestedIds[key]
        shortKey = key[5:]
        
        if (isArray(val)):
          idList = wsadminToList(val)
          tidx = 0
          for tempid in idList:
            if (isEmpty(tempid)):
              continue
            tidx +=1
            configType = callGetObjectType(tempid)
            if (not isEmpty(configType)):
              printLine("%s.%s.%d.type = %s" % (prefix,shortKey,tidx,configType))
            printSimpleProperties("%s.%s.%d.prop" % (prefix,shortKey,tidx),tempid)
          
          if (tidx > 0):
            printLine("%s.%s.count = %d" % (prefix,shortKey,tidx))
        else:
          configType = callGetObjectType(val)
          if (configType != None):
            printLine("%s.%s.type = %s" % (prefix,shortKey,configType))
          printSimpleProperties("%s.%s.prop" % (prefix,shortKey),val)
    
    if (hcidx > 0):
      printLine("\napp.im.healthClass.count = %d" % (hcidx))
  except:
    _app_message("Unexpected problem in dumpHealthClass","exception")


  

#-------------------------------------------------------------------------------
def dumpCustomActions(**options):
  try:
    types = getTypeList()
    if "CustomProcessDefs" not in types:
      return
    
    cpds = AdminConfig.list("CustomProcessDefs").splitlines()
    idx = 0
    for cpd in cpds:
      if (isEmpty(cpd)):
        continue
      
      idx += 1
      if (idx == 1):
        printLine("\n#--------------------------------\n# Custom Actions\n#--------------------------------")
      else:
        printLine("")
      
      printLine("app.im.customActions.%d.name = %s" % (idx, AdminConfig.showAttribute(cpd,"name")))
      definitions = wsadminToList(AdminConfig.showAttribute(cpd,"definitions"))
      if (len(definitions) == 1 and not isEmpty(definitions[0])):
        configType = callGetObjectType(definitions[0])
        printLine("app.im.customActions.%d.definitions.type = %s" % (idx,configType))
        printSimpleProperties("app.im.customActions.%d.definitions.prop" % (idx),definitions[0],printSimpleChildren=1,printPropertyAttributes=1,useAttrNameWithProperties=1)
    
    if (idx > 0):
      printLine("\napp.im.customActions.count = %d" % idx)
          
  except:
    _app_message("Problem in dumping custom action settings","exception")


#-------------------------------------------------------------------------------
def dumpCustomElasticityActions(**options):
  try:
    wccmtypes = getTypeList()
    if "ElasticityCustomProcessDefs" not in wccmtypes:
      return
    
    cpds = AdminConfig.list("ElasticityCustomProcessDefs").splitlines()
    idx = 0
    for cpd in cpds:
      if (isEmpty(cpd)):
        continue
      
      idx += 1
      if (idx == 1):
        printLine("\n#--------------------------------\n# Custom Elasticity Actions\n#--------------------------------")
      else:
        printLine("")
      
      printLine("app.im.customElasticityActions.%d.name = %s" % (idx, AdminConfig.showAttribute(cpd,"name")))
      definitions = wsadminToList(AdminConfig.showAttribute(cpd,"definitions"))
      if (len(definitions) == 1 and not isEmpty(definitions[0])):
        configType = callGetObjectType(definitions[0])
        printLine("app.im.customElasticityActions.%d.definitions.type = %s" % (idx,configType))
        printSimpleProperties("app.im.customElasticityActions.%d.definitions.prop" % (idx),definitions[0],printSimpleChildren=1,printPropertyAttributes=1,useAttrNameWithProperties=1)
    
    if (idx > 0):
      printLine("\napp.im.customElasticityActions.count = %d" % idx)
          
  except:
    _app_message("Problem in dumping custom action settings","exception")


#-------------------------------------------------------------------------------
# dumpElasticityClass
#
# Parameters
#
#-------------------------------------------------------------------------------
def dumpElasticityClass(**options):
  
  
  try:
    wccmtypes = getTypeList()
    if "ElasticityClass" not in wccmtypes:
      return
    
    eclasses = AdminConfig.list("ElasticityClass").splitlines()
    idx = 0
    for eclass in eclasses:
      if (isEmpty(eclass)):
        continue
      
      idx += 1
      
      if (idx == 1):
        printLine("\n#--------------------------\n# Elasticity Operations \n#--------------------------")
      
      printLine("")

      props = {}
      nestedIds = {}
      collectSimpleProperties(props, "prop",eclass, optionalSkipList=[],nestedIds=nestedIds)
      
      prefix = "app.im.elasticityClass.%d" % (idx)
      printLine("%s.name = %s" % (prefix,props.get("prop.name","")))
      sortedKeys = []
      for key in props.keys():
        sortedKeys.append(key)
      sortedKeys.sort()
      for key in sortedKeys:        
        # This includes "prop."
        if (key == "prop.name"):
          continue
        printLine("%s.%s = %s"% (prefix,key,props.get(key)))
        
      for key in nestedIds.keys():
        val = nestedIds[key]
        shortKey = key[5:]
        
        if (isArray(val)):
          idList = wsadminToList(val)
          tidx = 0
          for tempid in idList:
            if (isEmpty(tempid)):
              continue
            tidx +=1
            configType = callGetObjectType(tempid)
            if (not isEmpty(configType)):
              printLine("%s.%s.%d.type = %s" % (prefix,shortKey,tidx,configType))
            printSimpleProperties("%s.%s.%d.prop" % (prefix,shortKey,tidx),tempid)
          
          if (tidx > 0):
            printLine("%s.%s.count = %d" % (prefix,shortKey,tidx))
        else:
          configType = callGetObjectType(val)
          if (configType != None):
            printLine("%s.%s.type = %s" % (prefix,shortKey,configType))
          printSimpleProperties("%s.%s.prop" % (prefix,shortKey),val)
          
    if (idx > 0):
      printLine("app.im.elasticityClass.count = %d" % (idx))
    #some stuff
  except:
    _app_message("Unexpected problem in dumpElasticityClass()","exception")
  
  

#---------------------------------------------------------------------
# dumpIMControllers
#---------------------------------------------------------------------    
def dumpIMControllers(**options):
  
  try:
    
    wccmtypes = getTypeList()
    
    if "HealthController" in wccmtypes:
      hcId =  AdminConfig.getid("/Cell:%s/HealthController:/" % getCellName())
      if (not isEmpty(hcId)):
        printLine("\n#-------------------------------------------\n# HealthController\n#\n#")
        printLine("#   The prohibited restart times cannot be updated by wsadmin script")
        printLine("#   http://www-01.ibm.com/support/knowledgecenter/SSUP64_7.0.0/com.ibm.websphere.virtualenterprise.doc/reference/todhmscript.html\n#")
        printLine("#-------------------------------------------\n")
      
        printSimpleProperties("app.im.controllers.health.prop",hcId,printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1,useAttrNameWithProperties=1)
    
    if "AutonomicRequestFlowManager" in wccmtypes:
      arfmId = AdminConfig.getid("/AutonomicRequestFlowManager:/")
      if (not isEmpty(arfmId)):
        printLine("\n#-------------------------------------------\n# AutonomicRequestFlowManager\n#-------------------------------------------")
             
        printSimpleProperties("app.im.controllers.arfm.prop",arfmId,printSimpleChildren=1,printPropertyAttributes=1,useAttrNameWithProperties=1)
        
    if "AppPlacementController" in wccmtypes:
      apcId = AdminConfig.getid("/AppPlacementController:/")
      if (not isEmpty(apcId)):
        printLine("\n#-------------------------------------------\n# Application Placement Controller \n#-------------------------------------------")
        printSimpleProperties("app.im.controllers.apc.prop",apcId,printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1,useAttrNameWithProperties=1)
        
        

        

  except:
    _app_message("Unexpected problem with dumpIMControllers","exception")

#-------------------------------------------------------------------------------
# dumpServiceClass
#
# Produces a list of service policy configuration items

#-------------------------------------------------------------------------------
def dumpServiceClass(**options):
  
  retval = None
  try:
    #some stuff
    scl = AdminConfig.getid("/ServiceClass:/").splitlines()
    idx = 0
    for scId in scl:
      if (isEmpty(scId)):
        continue
      idx +=1 
      
      if (idx == 1):
        printLine("\n#----------------------------\n# Service Policies\n#----------------------------\n")
      else:
        printLine("")
      
      prefix = "app.im.serviceclass.%d" % idx
      printLine("%s.name = %s" % (prefix, splitOffName(scId)))
      printSimpleProperties(prefix,scId, optionalSkipList=["name"],includeBlanks=0,printSimpleChildren=1,childrenSkipList=None,
                          printPropertyAttributes=1,useAttrNameWithProperties=1,includeReferenceChildren=0,printListChildren=1,
                          printChildType=1)
    
    if (idx > 0):
      printLine("\napp.im.serviceclass.count = %d"%idx)
      
  except:
    _app_message("Unexpected problem in dumpServiceClass()","exception")
  
#------------------------------------------------------------
# Note: this doesn't support middleware apps yet
#
# Note:
#  Routing policy for eba:
#     cells / IMScriptingCell / cus / com.ibm.samples.websphere.osgi.blog_0001.eba / workclasses / Default_HTTP_WC / workclass.xml
#
#  Service policy for eba:
#     cells / IMScriptingCell / cus / com.ibm.samples.websphere.osgi.blog_0001.eba / cver / BASE / workclasses / Default_HTTP_WC / workclass.xml
#------------------------------------------------------------
def dumpWorkClass(**options):
  wkPrefix = "app.im.workclass"
  try:
    wkList = AdminConfig.list("WorkClass").splitlines()
    
    # Sort into Work Classes for Routing and Service Policies
    routingWorkClasses = []
    serviceWorkClasses = []
    ebaRoutingWorkClasses = []
    ebaServiceWorkClasses = []
    for wkId in wkList:
      if (wkId.find("/deployments/") >= 0):
        serviceWorkClasses.append(wkId)
      elif (wkId.find(".ear/workclasses/") >= 0):
        routingWorkClasses.append(wkId)
      elif (wkId.find("/cus/") >= 0):
        if (wkId.find("/cver/") >= 0):
          ebaServiceWorkClasses.append(wkId)
        else:
          ebaRoutingWorkClasses.append(wkId)
      else:
        _app_message("Uncategorized WorkClass: %s" % wkId)
    
    routingAppDict = {}
    serviceAppDict = {}
    serviceEditionDict = {}
    if (len(routingWorkClasses) > 0):
      
      for wkId in routingWorkClasses:
        # Parse out the application name
        tokens = wkId.split("/")
        longName = tokens[ tokens.index("workclasses") - 1]
        shortName = longName
        if (longName.endswith(".ear")):
          shortName = longName[:-4]
        
        appList = routingAppDict.get(shortName,None)
        if (appList == None):
          appList = []
        
        appList.append(wkId)
        routingAppDict[shortName] = appList
    
    if (len(serviceWorkClasses) > 0):
      for wkId in serviceWorkClasses:
        tokens = wkId.split("/")
        longName = tokens[ tokens.index("workclasses") - 1]        
        shortName = longName
        if (longName.find("-edition") > 0):
          shortName = longName[0:longName.find("-edition")]
        
        appList = serviceAppDict.get(shortName,None)
        if (appList == None):
          appList = []
        
        appList.append(wkId)
        serviceAppDict[shortName] = appList
        
        # Also store the edition name so we don't have to reparse later
        if (shortName != longName):
          editionNameList = serviceEditionDict.get(shortName,None)
          
          if (editionNameList == None):
            editionNameList = []
            serviceEditionDict[shortName] = editionNameList
          
          if (longName not in editionNameList):
            editionNameList.append(longName)
          
          editionWCList = serviceEditionDict.get(longName,None)
          if (editionWCList == None):
            editionWCList = []
            serviceEditionDict[longName] = editionWCList
          
          editionWCList.append(wkId)          
    
    masterAppList = []
    for x in routingAppDict.keys():
      masterAppList.append(x)
    for y in serviceAppDict.keys():
      if y not in masterAppList:
        masterAppList.append(y)
    
    
    
    appIdx = 0
    masterAppList.sort()
    for appName in masterAppList:
      appIdx += 1 
      if (appIdx == 1):
        # Print header for work classes
        printLine("\n#----------------------------------------------\n# Work Classes (Routing and Service Policies)\n#----------------------------------------------\n")
      
      printLine("\n#--\n# Work Class definitions for application %s\n#--" % appName)
      printLine("%s.application.%d.name = %s" % (wkPrefix,appIdx,appName))
      routingWorkClassList = routingAppDict.get(appName,None)
      if routingWorkClassList != None :
        routingIdx = 0
        for wkId in routingWorkClassList:
          if (isEmpty(wkId)):continue
          routingIdx += 1
          if (routingIdx == 1):
            printLine("# Routing Policy work classes for application %s" % appName)
          else:
            printLine("")
          prefix = "%s.application.%d.routing.%d" % (wkPrefix,appIdx,routingIdx)
          printLine("%s.name = %s" % (prefix,wkId[0:wkId.find('(')]))
          printSimpleProperties("%s.prop" % prefix,wkId,["name"],printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1)
      
      # For service work classes - see if there are editions for this application
      editionNameList = serviceEditionDict.get(appName,None)
      if (editionNameList != None):
        # Print it on per-edition basis
        editionIdx = 0
        for editionName in editionNameList:
          editionIdx = editionIdx+1
          eprefix = "%s.application.%d.edition.%d" % (wkPrefix,appIdx,editionIdx)

          printLine("\n# Service Policy work classes for application edition %s" % editionName)

          printLine("%s.name = %s" % (eprefix,editionName))
          serviceWorkClassList = serviceEditionDict.get(editionName)
          serviceIdx = 0
          for wkId in serviceWorkClassList:
            if (isEmpty(wkId)): continue
            serviceIdx += 1            
            prefix = "%s.service.%d" % (eprefix,serviceIdx)
            printLine("\n%s.name = %s" % (prefix,wkId[0:wkId.find('(')]))
            printSimpleProperties("%s.prop" % prefix,wkId,["name"],printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1)
          
          if (serviceIdx > 0):
            printLine("\n%s.service.count = %d" % (eprefix,serviceIdx))
        
        if (editionIdx > 0):    
          printLine("\n%s.application.%d.edition.count = %d" % (wkPrefix,appIdx,editionIdx))
        
      else:
        # No editions 
        serviceWorkClassList = serviceAppDict.get(appName,None)
        serviceIdx = 0
        for wkId in serviceWorkClassList:
          if (isEmpty(wkId)): continue
          serviceIdx += 1
          if (serviceIdx == 1):
            printLine("\n# Service Policy work classes for application %s" % appName)
          else:
            printLine("")            
          prefix = "%s.application.%d.service.%d" % (wkPrefix,appIdx,serviceIdx)
          printLine("%s.name = %s" % (prefix,wkId[0:wkId.find('(')]))
          printSimpleProperties("%s.prop" % prefix,wkId,["name"],printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1)
        
        if (serviceIdx > 0):
          printLine("\n%s.application.%d.service.count = %d" % (wkPrefix,appIdx,serviceIdx))
    
    if (appIdx > 0):
      printLine("\n%s.application.count = %d" % (wkPrefix,appIdx))
      
    # Now process the BLA related routing 
    if (len(ebaRoutingWorkClasses) > 0 or len(ebaServiceWorkClasses) > 0):
      cuRoutingDict = {}
      cuServiceDict = {}
      cuMasterList = []
      for wkId in ebaRoutingWorkClasses:
        # cells / IMScriptingCell / cus / com.ibm.samples.websphere.osgi.blog_0001.eba / workclasses / Default_HTTP_WC / workclass.xml
        tokens = wkId.split("/")
        cuName  = tokens[ tokens.index("cus") + 1]
        if (cuName not in cuMasterList):
          cuMasterList.append(cuName)
        
        routingList = cuRoutingDict.get(cuName,None)
        if (routingList == None):
          routingList = []
        routingList.append(wkId)
        cuRoutingDict[cuName]=routingList
        
      for wkId in ebaServiceWorkClasses:
        
        tokens = wkId.split("/")
        cuName  = tokens[ tokens.index("cus") + 1]
        if (cuName not in cuMasterList):
          cuMasterList.append(cuDict)
        
        serviceList = cuServiceDict.get(cuName,None)
        if (serviceList == None):
          serviceList = []
        serviceList.append(wkId)
        cuServiceDict[cuName]=serviceList       
      
      # Now let's determine BLAs that the comp-units belong to  
      blaDict = {}
      blaList = AdminTask.listBLAs('').splitlines()
      for blaName in blaList:
        if (isEmpty(blaName)):
          continue
        cuNames = AdminTask.listCompUnits('[-blaID %s ]'%blaName).splitlines()
        for tempCu in cuNames:
          tempName = tempCu
          if (tempCu.startswith("WebSphere:cuname=")):
            tempName = tempCu[17:]
            if (tempName in cuMasterList):
              # Update entry in our blaDict
              tempList = blaDict.get(blaName,None)
              if (tempList == None):
                tempList = []
              tempList.append(tempName)
              
              blaDict[blaName] = tempList
        #end for each cu
      #end for each bla       
      
      # Ok, having organized everything in dictionaries, we can pump it out 
      printLine("\n# WorkClass configurations in BLA (OSGi) applications")
      blaNames = blaDict.keys()
      blaNames.sort()
      blaIdx = 0
      for blaName in blaNames:
        blaIdx += 1
        printLine("\n%s.blas.%d.name = %s" % (wkPrefix,blaIdx,blaName))
        cuList = blaDict[blaName]
        cuList.sort()
        cuIdx = 0
        for cuName in cuList:
          cuIdx += 1
          cuPrefix = "%s.blas.%d.compUnit.%d" % (wkPrefix,blaIdx,cuIdx)
          printLine("%s.name = %s" % (cuPrefix,cuName))
          routingList = cuRoutingDict.get(cuName,None)
          if (routingList != None and len(routingList) > 0):
            printLine("\n# Routing workclasses for %s" % cuName)
            rIdx = 0
            routingList.sort()
            for wkId in routingList:
              rIdx += 1
              routingPrefix = "%s.routing.%d" % (cuPrefix,rIdx)
              printLine("%s.name = %s" % (routingPrefix,wkId[0:wkId.find('(')]))
              printSimpleProperties("%s.prop" % routingPrefix,wkId,["name"],printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1)
            printLine("%s.routing.count = %d" % (cuPrefix,rIdx))
            
          serviceList = cuServiceDict.get(cuName,None)
          if (serviceList != None and len(serviceList) > 0):
            printLine("\n# Service workclasses for %s" % cuName)
            rIdx = 0
            serviceList.sort()
            for wkId in serviceList:
              rIdx += 1
              servicePrefix = "%s.service.%d" % (cuPrefix,rIdx)
              printLine("%s.name = %s" % (servicePrefix,wkId[0:wkId.find('(')]))
              printSimpleProperties("%s.prop" % servicePrefix,wkId,["name"],printSimpleChildren=1,printListChildren=1,printPropertyAttributes=1)
            printLine("%s.service.count = %d" % (cuPrefix,rIdx))
        printLine("\n%s.blas.%d.compUnit.count = %d" % (wkPrefix,blaIdx,cuIdx)  )
      if (blaIdx > 0):
        printLine("\n%s.blas.count = %d" % (wkPrefix,blaIdx))
        

      
  except:
    _app_message("Unexpected error in dumpWorkClass","exception")
  

#-------------------------------------------------------------------------------
# dumpIntelligentManagement
#-------------------------------------------------------------------------------
def dumpIntelligentManagement(**options):	
  try:
    # See if IM features are available
    types = getTypeList()
    if "HealthClass" not in types:
      return
      
    dumpCustomActions(**options)
    
    dumpHealthClass(**options)
    
    dumpCustomElasticityActions(**options)
    
    dumpElasticityClass(**options)
    
    dumpServiceClass(**options)
    
    dumpWorkClass(**options)
    
    dumpIMControllers(**options)
  except:
    _app_message("Problem dumping intelligent management settings","exception")
    
#-----------------------------------------------------------------------------------------
# dumpTemplate 
#-----------------------------------------------------------------------------------------
def dumpTemplate(**options):
  try:
    # For templates, always print configuration ID
    if (options != None):
      options["-printid"] = 1
      
    cfgType = options.get("-template")
    matchPattern = options.get("-templatepattern")
    if (not isEmpty(matchPattern)):
      templateList = AdminConfig.listTemplates(cfgType,matchPattern).splitlines()
    else:
      templateList = AdminConfig.listTemplates(cfgType).splitlines()
    if (len(templateList) == 1 and templateList[0] == ''):
      _app_message("No matching templates found for %s, '%s')" % (cfgType,matchPattern))
    else:
      rePattern = options.get("-pattern",None)
      if (rePattern != None):
        tempList = []
        for templateId in templateList:
          if (re.match(rePattern,templateId)):
            tempList.append(templateId)
        templateList = tempList
        
      _app_message("%d matching templates found for %s, templatepattern='%s', rePattern='%s')" % (len(templateList),cfgType,matchPattern,rePattern))
      if (cfgType == "Server"):
        appServerList = []
        webServerList = []
        for templateId in templateList:
          if (templateId.find("servertypes/APPLICATION_SERVER/") >= 0):
            appServerList.append(templateId)
          elif (templateId.find("servertypes/WEB_SERVER/") >= 0):
            # Get the WebServer configuration
            wsId = AdminConfig.list("WebServer",templateId)
            webServerList.append(wsId)
            
          
        if (len(appServerList) > 0):          
          dumpStandaloneApplicationServers(parmMap=options,inputServerList=appServerList)
        
        if (len(webServerList) > 0):
          dumpWebServers(parmMap=options,inputWebServerList=webServerList)    
      elif (cfgType == "JDBCProvider"):
        dumpJdbc(parmMap=options,inputProviderList=templateList) 
            
           
    
    
    
  except:
    _app_message("Unexpected problem in dumpTemplate","exception")
  


    
#------------------------------------------------------------------------------
def dumpEnv(dirName,sufix,fileName = None,**options):
  global fileId
  
  if (fileName == None):
      fileName = "%s/%s_%s_%s.props" % (dirName, getStoredHostName(),getCellName(), sufix)
  
  fileId = open(fileName,"w")
  
  _app_message("Starting configuration dump to file %s" % fileName)
  
  printLine("###############################################################################")
  printLine("# Generated at : %s" % (java.util.Date()))
  printLine("# HostName     : %s" % getStoredHostName())
  printLine("# CellName     : %s" % getCellName())
  printLine("# app.config Application Config file")
  printLine("###############################################################################")
  printLine(" ")
  
  dumpCell(**options)
  printLine(" ")
  
  dumpManagedNodes()
  printLine(" ")
  
  dumpNodeGroups(**options)
  printLine("")

  
  #printTemplateServer()
  printLine(" ")
  dumpStandaloneApplicationServers(parmMap=options)
  
  printLine(" ")
  dumpClusterSection(parmMap=options)
  printLine(" " )
  dumpReplicationDomain()
  printLine(" " )
  dumpURIGroups(parmMap=options)
  printLine("")
  dumpVirtualHosts()
  printLine(" ")
  dumpUnmanagedNodes()
  printLine(" " )
  dumpWebServers(parmMap=options)
  printLine(" " )
  dumpAuthSection()
  printLine(" " )
  
  printLine(" " )
  
  try:
    dumpVars()
  except:
    eString = _app_message("Error processing vars","exception")
    printLine("# Error processing vars\n#%s" % eString)
    
  printLine(" " )
  dumpNameSpaceBindings()
  printLine(" " )
  dumpLibraries()
  printLine(" ")
  
  printLine(" " )
  dumpJdbc(parmMap=options)
  printLine(" ")
  dumpJ2CResourceAdapters()
  
  # JJM
  try:
    dumpMQJMS()
  except:
    eString = _app_message("Error processing MQJMS","exception")
    printLine("# Error processing mqjms\n#%s" % eString)
    
  printLine(" ")

  dumpObjectCacheProviders()
  printLine(" ")
  #@JJM
  dumpSchedulers() 
  
  printLine(" ")
  dumpWorkManagers()
  
  printLine(" ")
  dumpTimerManagers()
  
  printLine("")
  dumpMail()
  
  printLine("")
  dumpURL()
  
  printLine("")
  dumpResourceEnvironmentProviders()
  
  dumpSIBus()
  printLine(" ")
  dumpSIBJMS()
  printLine(" ")
  
  dumpGenericJMS()
  
  dumpCoreGroup()
  
  printLine(" ")
  dumpApplicationDeployment(parmMap=options)
  
  printLine("")
  dumpAssets(**options)
  
  printLine(" ")
  dumpBLAs(**options)
  
  printLine(" ")
  dumpOSGIBundles(**options)
  
  printLine(" ")
  dumpExternalBundleRepositories(**options)
  
  printLine(" ")
  dumpIntelligentManagement(**options)
  
  printLine(" ")
  dumpSecurity(**options)
  
  printLine("#------------------------------------------------------------------------------")
  printLine("# End of Config file")
  printLine("#------------------------------------------------------------------------------")
  fileId.close()
  
  _app_message("Finished configuration dump to file %s" % fileName)


#-------------------------------------------------------------------------------------------
# dumpDirective
# 
# Called multiple times by dumpPartialEnvironment to process individual directives
#-------------------------------------------------------------------------------------------
def dumpDirective(parmMap,directive, target = None, target2=None, target3= None , target4 = None):
  
   wildcard = parmMap.get("-wildcard","*")
   
   lcdirective = directive.lower()
   
   
   if (lcdirective == "-cell"):
      dumpCell(**parmMap)
   elif (directive == "-sibjms"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
        
      dumpSIBJMS(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard)

   elif (directive == "-genericjms"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
        
      dumpGenericJMS(pattern,targetCluster,targetNode,targetServer,targetCell,parmMap)

      
   elif (directive == "-sibus"):
   
      # See if we have the includeUUID parm
      includeUUID = parmMap.get("-includeUUID","false")
      
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      busMember  = parmMap.get("-busMember","")
      if (isEmpty(busMember)):
        busMember = parmMap.get("-busmember","")
      
      destination = parmMap.get("-destination","")
      
      
      dumpSIBus(target,includeUUID,pattern,busMember,destination,wildcard)
      
   elif (directive == "-mqjms"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
        
      dumpMQJMS(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard)
      
   elif (directive == "-jdbc"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
   
      dumpJdbc(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard,parmMap=parmMap)
   elif (directive == "-j2c"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
   
      dumpJ2CResourceAdapters(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard,**parmMap)

   elif (directive == "-authalias"):
      dumpAuthSection(parmMap=parmMap)
   elif (directive == "-dumpClusterServerAsTemplate"):
        clusterName = target
        serverName = target2
        nodeName = target3
        try:
          dumpClusterServerAsTemplate(clusterName, serverName, nodeName)
        except:
          import traceback
          print "Error occurred dumping cluster template  %s %s %s" % (clusterName, serverName, nodeName)
          traceback.print_exc()
          fileId.close()
          return        
   elif (directive == "-converToDynamic" or directive == "-converttodynamic" or directive=="-convertdynamic"):
    clusterName = target
    convertToDynamicCluster(clusterName, **parmMap)
   elif (directive == "-vars"):
        targetCluster = parmMap.get("-targetcluster","")
        targetNode = parmMap.get("-targetnode","")
        targetServer = parmMap.get("-targetserver","")
        targetCell = parmMap.get("-targetcell")      
        
        dumpVars(targetCluster=targetCluster,targetNode=targetNode,targetServer=targetServer,targetCell=targetCell,wildcard=wildcard)
        
   elif (directive == "-schedulers"):
        targetCluster = parmMap.get("-targetcluster","")
        targetNode = parmMap.get("-targetnode","")
        targetServer = parmMap.get("-targetserver","")
        targetCell = parmMap.get("-targetcell")        
        dumpSchedulers(targetCluster,targetNode,targetServer,wildcard)
   elif (directive == "-libraries"):
        # see if we have a pattern
        pattern = parmMap.get("-pattern","")
      
        if (not isEmpty(target)):
          pattern = wildcardToRegExpString(target,wildcard)
        
        targetNode = parmMap.get("-targetnode","")
        targetCluster = parmMap.get("-targetcluster","")
        targetServer = parmMap.get("-targetserver","")
        targetCell = parmMap.get("-targetcell")
          
        dumpLibraries(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard)
   elif (directive == "-workmanager" or directive == "-workmanagers"):
        targetCluster = parmMap.get("-targetcluster","")
        targetNode = parmMap.get("-targetnode","")
        targetServer = parmMap.get("-targetserver","")
        targetCell = parmMap.get("-targetcell")
        
        dumpWorkManagers(targetCluster,targetNode,targetServer,wildcard)
        
   elif (directive.startswith("-webserver" )):
        dumpWebServers(parmMap=parmMap)
   elif (directive == "-nsbindings"):
        dumpNameSpaceBindings()
   elif (directive == "-repdomain"):
        dumpReplicationDomain()
   elif (lcdirective.startswith("-urigroup")):
      dumpURIGroups(parmMap)
   elif (directive == "-objectcache"):
        targetNode = parmMap.get("-targetnode","")
        targetCluster = parmMap.get("-targetcluster","")
        targetServer = parmMap.get("-targetserver","")
        targetCell = parmMap.get("-targetcell")
    
        dumpObjectCacheProviders(targetCluster,targetNode,targetServer,wildcard)
   elif (directive == "-url" or directive == "-urls"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
        
      dumpURL(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard,parmMap)
   elif (directive == "-timer" or directive == "-timers"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
        
      dumpTimerManagers(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard,parmMap)
   elif (directive == "-mail"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
        
      dumpMail(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard,parmMap)
   elif (directive.lower() == "-resourceenvironment"):
      # see if we have a pattern
      pattern = parmMap.get("-pattern","")
      
      if (not isEmpty(target)):
        pattern = wildcardToRegExpString(target,wildcard)
        
      targetNode = parmMap.get("-targetnode","")
      targetCluster = parmMap.get("-targetcluster","")
      targetServer = parmMap.get("-targetserver","")
      targetCell = parmMap.get("-targetcell")
              
      dumpResourceEnvironmentProviders(pattern,targetCluster,targetNode,targetServer,targetCell,wildcard,parmMap)
   elif (directive == "-appdeployment"):
        
        pattern = parmMap.get("-pattern","")
        if (not isEmpty(target)):
          pattern = wildcardToRegExpString(target,wildcard)
    
        dumpApplicationDeployment(pattern=pattern,parmMap=parmMap)
   elif (directive == "-coregroup"):
        dumpCoreGroup(target)
   elif (directive == "-virtualhosts"):
        dumpVirtualHosts()
   elif (directive == "-unmanagednodes"):
        dumpUnmanagedNodes()
   elif (directive == "-cluster"):
        # see if we have a pattern
        pattern = parmMap.get("-pattern","")
        if (not isEmpty(target)):
          pattern = wildcardToRegExpString(target,wildcard)
        serverPattern = parmMap.get("-server","")
        if (not isEmpty(serverPattern)):
          serverPattern = wildcardToRegExpString(serverPattern,wildcard)
        
        printTemplates = parmMap.get("-printTemplates","true")
        dumpClusterSection(pattern,serverPattern,printTemplates,parmMap=parmMap)
        
        doResources = parmMap.get("-resources","false")
        if (doResources != "false"):
          _app_message("Dumping resources associated with cluster %s" % pattern)
          
          # As we print output, the PrintLineFilter will grab authentication alias
          plf = AuthenticationAliasPrintLineFilter()
          addPrintLineFilter(plf)
          
          clusterDict = getMatchingClusters(clusterPattern=pattern,wildcard=wildcard)
          clusterNames = clusterDict.keys()
          clusterNames.sort()
          
          membersList = None
          if (parmMap.get("-memberresources") != None):
            # create list with all members in all matching clusters
            membersList = []
            for clusterName in clusterNames:
              clusterId = AdminConfig.getid("/ServerCluster:%s/"%clusterName)
              members = wsadminToList(AdminConfig.showAttribute(clusterId,"members"))
              for m in members:
                if (isEmpty(m)):continue
                memberName = AdminConfig.showAttribute(m,"memberName")
                nodeName = AdminConfig.showAttribute(m,"nodeName")
                membersList.append((nodeName,memberName))
                
            membersList.sort()
          
          dumpLibraries(pattern=None,targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          dumpVars(targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          dumpJdbc(pattern=None,targetCluster=pattern,membersList=membersList)
          dumpMQJMS(pattern=None,targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          
          busList = listBusesWithClusterAsMembers(clusterNames)
          
          dumpSIBus(busList=busList)
          dumpSIBJMS(pattern=None,targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          
          dumpGenericJMS(targetCluster=pattern,parmMap=parmMap)
          
          dumpWorkManagers(targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          dumpTimerManagers(targetCluster=pattern,wildcard=wildcard,parmMap=parmMap,membersList=membersList)
          dumpSchedulers(targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          dumpMail(targetCluster=pattern,wildcard=wildcard,parmMap=parmMap,membersList=membersList)
          dumpURL(targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          dumpObjectCacheProviders(targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          dumpJ2CResourceAdapters(targetCluster=pattern,wildcard=wildcard)
          dumpResourceEnvironmentProviders(targetCluster=pattern,wildcard=wildcard,membersList=membersList)
          
          applicationList = getApplicationsInClusters(clusterNames)
          applicationList.sort()
          dumpApplicationDeployment(applicationList,parmMap=parmMap)
          
          # Now we can do JAAS aliases
          removePrintLineFilter(plf)
          
          _app_message("The following JAAS aliases were identified: %s" % plf.getAliasList())
          dumpAuthSection(aliasNameList=plf.getAliasList(),parmMap=parmMap)
          
          
   elif (directive == "-clusters"):
        dumpClusterSection(parmMap=parmMap)  
   elif (directive == "-security"):
        dumpSecurity()
   elif (directive == "-dumpVariableClusterTemplate"):
        dumpVariableClusterTemplate(parmMap)
   elif (directive == "-appservers" or directive == "-appserver"):       
        
        pattern = parmMap.get("-pattern","")
        if (not isEmpty(target)):
          pattern = wildcardToRegExpString(target,wildcard)
        
        targetNode = parmMap.get("-targetnode","")
        targetCluster = parmMap.get("-targetcluster","")
        targetServer = parmMap.get("-targetserver","")
        
        serverList = dumpStandaloneApplicationServers(pattern,0,targetServer,targetNode,targetCluster,parmMap=parmMap)
        
        doResources = parmMap.get("-resources","false")
        if (doResources.lower() != "false"):
          resourcePattern = parmMap.get("resourcepattern",None)
          dumpResourcesForApplicationServer(namePattern=resourcePattern, targetServer=targetServer, targetNode=targetNode, wildcard=wildcard,parmMap=parmMap,serverList=serverList)
          
   elif (directive == "-allappservers"):
        # see if we have a pattern
        pattern = parmMap.get("-pattern","")
        if (not isEmpty(target)):
          pattern = wildcardToRegExpString(target,wildcard)
        
        targetNode = parmMap.get("-targetnode","")
        targetCluster = parmMap.get("-targetcluster","")
        targetServer = parmMap.get("-targetserver","")
        
        dumpStandaloneApplicationServers(pattern,1,targetServer,targetNode,targetCluster,parmMap=parmMap)
        
        doResources = parmMap.get("-resources","false")
        if (doResources.lower() != "false"):
          resourcePattern = parmMap.get("resourcepattern",None)
          dumpResourcesForApplicationServer(namePattern=resourcePattern, targetServer=targetServer, targetNode=targetNode, wildcard=wildcard,parmMap=parmMap)
   elif (lcdirective == "-odr"):
     pattern = parmMap.get("-pattern","")
     if (not isEmpty(target)):
       pattern = wildcardToRegExpString(target,wildcard)
        
     targetNode = parmMap.get("-targetnode","")
     targetCluster = parmMap.get("-targetcluster","")
     targetServer = parmMap.get("-targetserver","")
    
     # Dump Standalone ODR
     
     # 
     serverTypes = getRequestedServerTypes(parmMap)
     if ("ONDEMAND_ROUTER" not in serverTypes):
       serverTypes.append("ONDEMAND_ROUTER")
     
     parmMap["-skipappserver"] = "true"
     dumpStandaloneApplicationServers(namePattern=pattern, includeClusterMembers=0,targetServer=targetServer,targetNode=targetNode,targetCluster=targetCluster,parmMap=parmMap)
      
     # ToDo - clustered ODR
     dynamicClusterList = []
     if (isValidTaskMethod("listDynamicClusters")):
        dynamicClusters = AdminTask.listDynamicClusters()
        if (not isEmpty(dynamicClusters)):
          dynamicClusterList = dynamicClusters.splitlines()
        
     dumpDynamicClusterSection(dynamicClusterList, specificCluster = None,parmMap=parmMap)
      
   elif (lcdirective == "-foreign"):
    dumpForeignServers(**parmMap)
   elif (directive == "-nodes"):
    dumpManagedNodes(parmMap)
    dumpUnmanagedNodes(parmMap)
    dumpNodeGroups(**parmMap)
   elif (directive == "-assets"):
    dumpAssets(**parmMap)
   elif (directive == "-blas" or directive =="-bla"):
    dumpAssets(**parmMap)
    printLine("")
    dumpBLAs(**parmMap)
   elif (directive == "-osgi"):
    # dump information related to OSGI applications
    dumpExternalBundleRepositories(**parmMap)
    printLine(" ")
    dumpOSGIBundles(**parmMap)
    printLine(" ")
    dumpAssets(**parmMap)
    printLine(" ")
    dumpBLAs(**parmMap)
   elif (directive == "-im"):
    dumpIntelligentManagement(**parmMap)
   elif (directive == "-customactions" or directive == "-customActions"):
    dumpCustomActions(**parmMap)
   elif (directive.lower() == "-healthpolicy" or lcdirective == "-healthpolicies" or lcdirective=="healthclass"):
    dumpHealthClass(**parmMap)
   elif (lcdirective == "-servicepolicy" or lcdirective == "-servicepolicies" or lcdirective == "serviceclass"):
    dumpServiceClass(**parmMap)
   elif (lcdirective == "-workclass" or lcdirective == "-workclasses"):
    dumpWorkClass(**parmMap)
   elif (directive == "-imcontroller"):
    dumpIMControllers(**parmMap)
   elif (directive == "-template"):
    dumpTemplate(**parmMap)
   elif (lcdirective == "-createclusterfromtemplate"):
    createClusterDefinitionFromTemplate(parmMap)
    
# end dumpDirective

#------------------------------------------------------------------------------
def dumpPartialEnvironment(dirName,sufix,optionalFileName,directive, target=None, target2=None, target3=None, target4=None, parmMap = None):
	global fileId
	
	import traceback
	
	simpleFileName = 0
	tempwildchar = '*'
	if (parmMap != None):
	  tempwildchar = parmMap.get("-wildcard","*")
	  if (not isEmpty(parmMap.get("-pattern"))):
	    simpleFileName = 1
	
	if (not simpleFileName):
	  #print "Target %s wildcard %s" % (target, tempwildchar)
	  if (target != None and target.find(tempwildchar) >= 0) :
	    simpleFileName = 1 
	  
	#print "SimpleFileName %d " % simpleFileName
	
	if (optionalFileName == None):
			fileName = "%s/%s_%s.props" % (dirName, getStoredHostName(), sufix)
	else:
			fileName = optionalFileName
	
	if (directive == "-dumpClusterServerAsTemplate"):
			if (optionalFileName == None):
					fileName = "%s/%s_%s_template_%s.props" % (dirName, getStoredHostName(), target, sufix)
			# The 4th target parameter of this directive can be an optional output file name
			# If target2 is -any, then target 3 can be file name
			
			if (target4 != None):
					fileName = target4
			elif (target2 == "-any" or target2 == "ANY"):
					if (target3 != None):
							fileName = target3
	elif (optionalFileName == None):
	
		if (simpleFileName):
			fileName = "%s/%s_%s_multiparm_%s.props" % (dirName, getStoredHostName(), directive[1:],sufix)
		elif (directive == "-jdbc"):
			fileName = "%s/%s_JDBC_%s.props" % (dirName, getStoredHostName(), sufix)
		elif (directive == "-vars"):
			fileName = "%s/%s_Variables_%s.props" % (dirName, getStoredHostName(), sufix)
		elif (directive == "-cluster"):
			fileName = "%s/%s_%s_%s.props" % (dirName, getStoredHostName(), target, sufix)
		elif (directive == "-libraries"):
			fileName = "%s/%s_SharedLibraries_%s.props" % (dirName, getStoredHostName(), sufix)
		elif (directive == "-workmanager"):
			fileName = "%s/%s_WorkManagers_%s.props" % (dirName, getStoredHostName(), sufix)
		elif (directive == "-sibjms"):
			fileName = "%s/%s_SIBJMS_%s.props" % (dirName, getStoredHostName(), sufix)
		elif (directive == "-webservers"):
			fileName = "%s/%s_WebServers_%s.props" % (dirName, getStoredHostName(), sufix)
		else:
			fileName = "%s/%s_%s_%s_%s.props" % (dirName, getStoredHostName(), getCellName(),directive[1:], sufix)

	_app_message("Starting partial environment dump to file %s" % fileName)
	
	fileId = open(fileName, "w")
	
	printLine("###############################################################################")
	printLine("# Generated at : %s" % (java.util.Date()))
	printLine("# HostName     : %s" % getStoredHostName())
	printLine("# CellName     : %s" % getCellName())
	printLine("# Other options:  %s %s %s %s " % (directive, target, target2, target3))
	printLine("# app.config Application Config file")
	printLine("###############################################################################")
	printLine(" ")
	
	try:
		dumpDirective(parmMap, directive, target, target2,target3, target4)
		
		
		if parmMap != None:
				for key in parmMap.keys():				
					if (key.lower() == directive.lower()):
						# We've already processed this
						continue
						
					val = parmMap.get(key)
					if (val == key):
						val = None
						
					printLine(" ")
					printLine(" ")
						
					# process the directive
					dumpDirective(parmMap,key,val)
	 

	except:
		_app_message("Error - Unexpected error processing dumpPartialEnvironment request","exception")
		print "Error - Unexpected error processing dumpPartialEnvironment request"
		traceback.print_exc()
		fileId.close()
		return
		
	printLine(" ")
	printLine("#------------------------------------------------------------------------------")
	printLine("# End of Config file")
	printLine("#------------------------------------------------------------------------------")
	fileId.close()
	
	_app_message("Properties have been written to %s" % fileName)


#------------------------------------------------------------------------------
# This method parses the command line inputs and supports a non-posiitional 
# parameter syntax
#------------------------------------------------------------------------------
def processSpecialArguments(parmlist):
  import os
  
  timestamp = ""
  outputDir ="."
  fileName = None
  directive1 = None
  target1 = None
  target2 = None
  target3 = None
  target4 = None
  
  if "-outdir" not in parmlist:
    outputDir = os.environ.get("DUMPCONFIG_OUTPUT")
    if (outputDir == None):
      outputDir = "."
  
  parmDictionary = {}

  
  idx = 0
  while (idx < len(parmlist)):
    parm = parmlist[idx]
    nextparm = None
    nextparm2 = None
    nextparm3 = None
    nextparm4 = None
    if (idx+1) < len(parmlist) :
        nextparm = parmlist[idx+1]
    if (idx+2) < len(parmlist) :
        nextparm2 = parmlist[idx+2]
    if (idx+3) < len(parmlist) :
        nextparm3 = parmlist[idx+3]
    if (idx+4) < len(parmlist) :
        nextparm4 = parmlist[idx+4]
        
    if parm.startswith("-"):
    
      # Store parm/next parm in dictionary
      if (nextparm != None and not nextparm.startswith("-")):
          parmDictionary[parm] = nextparm
          parmDictionary[parm.lower()]  = nextparm
          
          if (parm.lower() == "-pattern"):
            parmDictionary["-pattern"] = wildcardToRegExpString(nextparm,parmDictionary.get("-wildcard","*"))
      else:
          # Just use parm key as value
          parmDictionary[parm] = parm
          parmDictionary[parm.lower()] = parm.lower()
          
      if (parm.lower() == "-outdir"):
          if (nextparm == None or nextparm.startswith("-")):
            print "Missing output directory value for -outdir parameter"
            return
          else:
            outputDir = nextparm
            # Increment index by one so we'll skip past outdir arguments
            idx = idx + 1
      elif (parm.lower() == "-timestamp"):
          if (nextparm == None or nextparm.startswith("-")):
            print "Missing timestamp value for -timestamp parameter"
            return
          else:
            timestamp = nextparm
            # Increment index by one so we'll skip past outdir arguments
            idx = idx + 1         
      elif (parm.lower() == "-filename"):
          if (nextparm == None or nextparm.startswith("-")):
            print "Missing file name value for -fileName parameter"
            return
          else:
            fileName = nextparm
            # Increment index by one so we'll skip past fileName arguments
            idx = idx + 1
      elif (directive1 == None):
            # Treat as special directive
            directive1 = parm
            
            # Special handling for -any - change to ANY
            if (nextparm == "-any"):
                nextparm = "ANY"

            # Special handling for -any - change to ANY
            if (nextparm2 == "-any"):
                nextparm2 = "ANY"
                  
            # Special handling for -any - change to ANY
            if (nextparm3 == "-any"):
                nextparm3 = "ANY"         
            
            # A directive may have up to 3 positional arguments
            if (nextparm != None and not nextparm.startswith("-")):
                target1 = nextparm
                idx = idx + 1
            
                if (nextparm2 != None and not nextparm2.startswith("-")):
                    target2 = nextparm2
                    idx = idx + 1
                    
                    if (nextparm3 != None and not nextparm3.startswith("-")):
                        target3 = nextparm3
                        idx = idx + 1
                        
                        if (nextparm4 != None and not nextparm4.startswith("-")):
                          target4 = nextparm4
                          idx = idx + 1
      
    idx = idx + 1
  #end while more parms
  
  # Now determine who we're going to call
  if (timestamp == None or timestamp == ""):
      # Generate the timestamp
      from java.util import Date
      from java.text import SimpleDateFormat
      now = Date()
      sdf = SimpleDateFormat("yyyyMMdd_HHmmss")
      timestamp = sdf.format(now)
      
  for key in parmDictionary.keys():
    if (key != key.lower()):
      parmDictionary[key.lower()] = parmDictionary[key]
  
  for key in parmDictionary.keys():
    if (key.startswith("-")):
      # Store non dash option as well
      parmDictionary[key[1:]] = parmDictionary[key]
    
        
  
  if (directive1 == None or directive1 == "-all"):
    # Complete system dump
    dumpEnv(outputDir, timestamp, fileName,**parmDictionary)
  else:
    dumpPartialEnvironment(outputDir,timestamp, fileName, directive1, target1, target2, target3, target4, parmDictionary)
		

#------------------------------------------------------------------------------
# main
#------------------------------------------------------------------------------

if (len(sys.argv) == 0 or sys.argv[0].startswith("-")):
	processSpecialArguments(sys.argv)
elif (len(sys.argv) < 2):
	print "Syntax: wsadmin.sh -f dumpConfig.py dirNameForReport TimeStampExt"
elif (len(sys.argv) >= 2):
	parmlist = ["-outdir", sys.argv[0], "-timestamp", sys.argv[1] ]
	idx = 2
	while (idx < len(sys.argv)):
		parmlist.append(sys.argv[idx])
		idx = idx +1 
	processSpecialArguments(parmlist)

else: 

	print "Syntax: wsadmin.sh -f dumpConfig.py dirNameForReport TimeStampExt"
	print "Syntax: wsadmin.sh -f dumpConfig.py dirNameForReport TimeStampExt -cluster cluster-name"
