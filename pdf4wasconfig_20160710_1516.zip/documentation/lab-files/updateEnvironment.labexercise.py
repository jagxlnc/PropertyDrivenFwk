#---------------------------------------------------------------------------------------------------
# updateEnvironment.py
#
# This is the primary (but not only) script for Update Environment function which reads a property file
# to drive updates to a WebSphere cell. This script supports creation of new servers and resources as well
# as updating servers and resources.
#
# To understand the property file syntax, use the dumpConfig.py script to produce a property file
# representation of a current cell.
#
# Dependencies:
#     Loader.py 
#       - Initialization script invoked with the wsadmin -profile option to set up the
#         environment prior to invoking this scripts main entry point
#     updateEnv.properties
#       - Java system properties loaded by wsadmin -p option. (Optional, defaults will be used
#          if property file not loaded or missing properties). The properties that control the
#          the behavior of the script are listed below in the section titled
#          "updateEnvironment script control properties"
#     lib/*.py 
#       - A set of utility scripts for common functions as well as wsadmin scripts for specific
#         configuration actions.  These scripts are loaded by Loader.py
#
# Basic invocation from the directory where the scripts are installed:
#
# ${WAS_DMGR_PROFILE}/bin/wsadmin.sh -lang jython \
#                                     -profile Loader.py \
#                                     -f updateEnvironment.py  cell-properties-file [variable-properties-file]
#
# Where:
#
#   cell-properties-file is the name of the property file containing settings to be applied to the cell.
#   if not specified on the command line, the app.config.location setting from updateEnv.properties will be used.
#
#   variable-properties-file is the name of the optional properties file that contains values
#   to be used if the cell-properties-file is designed to support variable replacement.  The 
#   app.variable.location property in updateEnv.properties can also be used.
#
# Invocation from a different directory:
#
# ${WAS_DMGR_PROFILE}/bin/wsadmin.sh -lang jython \
#                                     -profile Loader.py \
#                                     -f <PDInstall-root>/updateEnvironment.py  cell-properties-file [variable-properties-file] \
#                                     -Dapp.config.scriptsdir=<PDInstall-root>/lib
#
# where PDInstall-root is the path to the location of the updateEnvironment.py script   
#
# Invocation with optional updateEnv.properties file:
#
# ${WAS_DMGR_PROFILE}/bin/wsadmin.sh -lang jython -p updateEnv.properties \
#                                     -profile Loader.py -f updateEnvironment.py  [optionalArguments]
# Optional Arguments: 
#   cell-properties-file [variable-properties-file]
#
#   cell-properties-file is the name of the property file containing settings to be applied to the cell.
#   if not specified on the command line, the app.config.location setting from updateEnv.properties will be used.
#
#   variable-properties-file is the name of the optional properties file that contains values
#   to be used if the cell-properties-file is designed to support variable replacement.  The 
#   app.variable.location property in updateEnv.properties can also be used.
#
# System Property Arguments: 
#   The Loader.py script will treat arguments with -Dprop=value syntax as Java system properties and
#   add them to the JVM's system properties.  You can override the properties in updateEnv.properties
#   using this syntax.
#
#   Example: 
#      -Dapp.config.location=serverEnvs/ConfigurationCell.props -Dapp.trace.log=1 -Dapp.trace.log.file=logs/mytrace.log -Dapp.autosave=true
#
# 
# Support for -conntype NONE
#
#   Some of the functionality is the updateEnvironment.py and processXXX.py scripts has been tested and
#   confirmed to work with the -conntype NONE option of wsadmin.  Running from the local DMGR profile with
#   this option will improve performance, but there may be a need to adjust the wsadmin heap sizes with the
#   -javaoption wsadmin option or editing of the wsadmin.sh script.
#--------------------------------------------------------------------------------------------------------         
#  
###########################################################################
# updateEnvironment script control properties
#
# The follow settings can be specified either in the properties file
# passed in to wsadmin with the -p option or as -D<property>=<value> command
# line arguments.
#
# #Set app.trace to non-zero value to enable tracing
# #Note that the app.trace.log setting also has to be set to 1
# Defaults to 1
#
# app.trace.level = 1
#
# Set app.trace.spaces to format trace output
# Defaults to 2
# app.trace.spaces = 2
#
# Output trace messages to trace file rather than console
# app.trace.log defaults to 1
# app.trace.log.file defaults to "./pdconfig.[timestamp].log"
# app.trace.log = 1
# app.trace.log.file = ./updatetrace.log
#
# Location of helper scripts
# Defaults to ./lib
# app.config.scriptsdir = c:/IC/PDInstall/lib
#
# Location of configuration file
# Can be supplied as first script parameter
# app.config.location =c:/IC/PDInstall/simple.props
#
# Location of variable file
# Can be supplied as second script parameter
# app.variable.location = c:/IC/PDInstall/samplevars.props
#
# Do not commit changes. Force rollback after all properties are processed.
# app.preview = true
#
# Override comparison of existing properties. Default behavior is
# to not compare against settings of newly created cluster members. Set
# this property to true to force the check and avoid unnecessary update
# messages.
# app.forceExistingProps = true
#--------------------------------------------------------------------------------------------------------         
# Cluster Member Property syntax notes:
#
# -----------------------------------------------------------------------
# Applying settings to all cluster members without specifying the members
#
# The clusterTemplate.applyTemplateSettingsToExistingMembers can be used to 
# apply settings to all cluster members, even if those members are not specified
# in the property file.  This is useful when using the property file to update
# an existing cluster where there is no need to add new members.
# 
# The following example will update every server in the MyCluster cluster.
#
# app.cluster.1.name = MyCluster
# app.cluster.1.clusterTemplate.updateTemplate = true
# app.cluster.1.clusterTemplate.applyTemplateSettingsToExistingMembers = true
# app.cluster.1.clusterTemplate.applyTemplateSettingsToNewMembers = false
#
# # Default Thread Pool
# app.cluster.1.clusterTemplate.threadPoolManager.threadPool.1.prop.name = Default
# app.cluster.1.clusterTemplate.threadPoolManager.threadPool.1.prop.maximumSize = 25
# app.cluster.1.clusterTemplate.threadPoolManager.threadPool.1.prop.minimumSize = 25
#
#
# -----------------------------------
# Wildcard matching for cluster names
#
# To apply settings across multiple application server clusters, use the @ITERATE(pattern) parameter for 
# the cluster name. The following example will update the Default thread pool size for all servers
# in clusters that match the "MyCluster*" name pattern.
# 
# app.cluster.1.name = @ITERATE(MyCluster*)
# app.cluster.1.clusterTemplate.updateTemplate = true
# app.cluster.1.clusterTemplate.applyTemplateSettingsToExistingMembers = true
# app.cluster.1.clusterTemplate.applyTemplateSettingsToNewMembers = false
#
# # Default Thread Pool
# app.cluster.1.clusterTemplate.threadPoolManager.threadPool.1.prop.name = Default
# app.cluster.1.clusterTemplate.threadPoolManager.threadPool.1.prop.maximumSize = 25
# app.cluster.1.clusterTemplate.threadPoolManager.threadPool.1.prop.minimumSize = 25
#
# ------------------------------------------------------------
# Alternative syntax for Cluster Member names
# In the case where all cluster members are configured the same, you may want
# to use this alternative syntax for listing the cluster members:
#
# app.cluster.1.name = MyCluster
#
# app.cluster.1.variableMembers = true
# app.cluster.1.variableMembers.servers = Node1/Server_1_1 Node1/Server_1_2 Node2/Server_2_1
#
# [app.cluster.1.clusterTemplate section]
#
# app.cluster.1.clustermember.1.name = PLACEHOLDER
# app.cluster.1.clustermember.1.node = PLACEHOLDER
# app.cluster.1.clustermember.1.weight = 4
#
# ... rest of clustermember settings ..
#
# The variableMembers.servers property is an in-line list of node/server pairs that will be used as the cluster members.
# This node-server pairs can be specified as "node/server-name" or "node:server-name". 
#
# The script will iterate through the cluster members specified and apply 
# the app.cluster.[n].clustermember.1 settings to the cluster members. If you 
# specify additional cluster members, they will not be processed. The features of
# the clusterTemplate sections are also supported with this syntax.
#
# 
# ------------------------------------------------------------
# Support for Cluster Member Name Generation
#
# There is an alternative syntax that can support generated cluster member names.
# By specifying node names and server-per-nodes settings and a member name 
# template that uses the @{DYNAMIC#KEYWORD#...} macro, the process of setting up
# a variable-sized cluster becomes much simpler. 
#
# The script will use the specified input properties to determine the number 
# of servers to create on each node and then will use the clustermember.1.name
# property as a template to build out the server name. When generating the 
# the server name, the script will replace the following KEYWORD tokens with
# the appropriate values.
#          NODE_NAME - the name of the node
#          CURRENT_NODE_HOSTNAME - the hostname of the node
#          NODE_IDX - "01","02","03".... The index of node in the input list.
#          NODE_MEMBER_IDX - "01","02","03"... The index of the generated server on the node
#          CLUSTER_MEMBER_IDX - "001","002","003" - The index of the generated server in the cluster
#
#
# Examples are shown below
#
# Generated Name Example 1: Create a cluster with 3 servers per node
# This will create cluster members: Node1:MEMBER_01_01 Node1:MEMBER_01_02 Node1:MEMBER_01_03
#                                   Node2:MEMBER_02_01 Node2:MEMBER_02_02 Node2:MEMBER_02_03
#                                   Node3:MEMBER_03_01 Node3:MEMBER_03_02 Node3:MEMBER_03_03
#                                   Node4:MEMBER_04_01 Node4:MEMBER_04_02 Node4:MEMBER_04_03
# 
# app.cluster.1.name = MyCluster
#
# app.cluster.1.variableMembers = true
# app.cluster.1.variableMembers.perNode = 3
# app.cluster.1.variableMembers.nodes = Node1 Node2 Node3 Node4
#
#
# [app.cluster.1.clusterTemplate section]
#
# app.cluster.1.clustermember.1.name = MEMBER_@{DYNAMIC#KEYWORD#NODE_IDX}_@{DYNAMIC#KEYWORD#NODE_MEMBER_IDX}
# app.cluster.1.clustermember.1.node = PLACEHOLDER
# app.cluster.1.clustermember.1.weight = 4
#
# ... rest of clustermember settings ..
#
# Generated Name Example 2: Create a cluster with 2 servers across the first
#                           two nodes specified in the #{MY_NODE_LIST} variable.
#                           Node1:MEMBER_001 Node1:MEMBER_002
#
# app.cluster.1.name = MyCluster
#
# app.cluster.1.variableMembers = true
# app.cluster.1.variableMembers.perNode = 1
# app.cluster.1.variableMembers.nodeCount = 2
# app.cluster.1.variableMembers.nodes = #{MY_NODE_LIST}
#
# [app.cluster.1.clusterTemplate section]
#
# app.cluster.1.clustermember.1.name = MEMBER_@{DYNAMIC#KEYWORD#CLUSTER_MEMBER_IDX}
# app.cluster.1.clustermember.1.node = PLACEHOLDER
# app.cluster.1.clustermember.1.weight = 4
#
# Generated Name Example 3: Create a cluster with varying number of servers
#
# This will create cluster members: Node1:MEMBER_01_01 
#                                   Node2:MEMBER_02_01 Node2:MEMBER_02_02 
#                                   Node3:MEMBER_03_01 Node3:MEMBER_03_02 Node3:MEMBER_03_03
#                                   Node4:MEMBER_04_01 
#
# Note: Commas are a valid separator for the node list also
# 
# app.cluster.1.name = MyCluster
#
# app.cluster.1.variableMembers = true
# app.cluster.1.variableMembers.serverCount = 1,2,3,1
# app.cluster.1.variableMembers.nodes = Node1,Node2,Node3,Node4
#
# [app.cluster.1.clusterTemplate section]
#
# app.cluster.1.clustermember.1.name = MEMBER_@{DYNAMIC#KEYWORD#NODE_IDX}_@{DYNAMIC#KEYWORD#NODE_MEMBER_IDX}
# app.cluster.1.clustermember.1.node = PLACEHOLDER
# app.cluster.1.clustermember.1.weight = 4
#
# ... rest of clustermember settings ..
#
# Generated Name Example 4: Create a cluster with dynamic names and remove any cluster members
# that do not match generated names. 
#
# Also in this example, we show how the cluster template settings can be used to define new 
# members without updating existing members.
#
# This will create cluster members: Node1:MEMBER_01_01 
#                                   Node2:MEMBER_02_01 
#                                   Node3:MEMBER_03_01 
#                                   Node4:MEMBER_04_01
#
# Note: Commas are a valid separator for the node list also
# 
# app.cluster.1.name = MyCluster
# 
#
# app.cluster.1.variableMembers = true
# app.cluster.1.variableMembers.nodes = Node1,Node2,Node3,Node4
# app.cluster.1.removeMismatches = true
#
# # [app.cluster.1.clusterTemplate section]
# # New member settings will be pulled from these properties
#
# app.cluster.1.clusterTemplate.updateTemplate = false
# app.cluster.1.clusterTemplate.applyTemplateSettingsToExistingMembers = false
# app.cluster.1.clusterTemplate.applyTemplateSettingsToNewMembers = true
# 
# app.cluster.1.clusterTemplate.memberDefaults.weight  = 5
# app.cluster.1.clusterTemplate.memberDefaults.startingPort  = 20000
#
# [app.cluster.1.clusterTemplate settings will be applied to new servers]
#
# app.cluster.1.clustermember.1.name = MEMBER_@{DYNAMIC#KEYWORD#NODE_IDX}_@{DYNAMIC#KEYWORD#NODE_MEMBER_IDX}
# app.cluster.1.clustermember.1.node = PLACEHOLDER
#
# ------------------------------------
# Wildcard support for application server updates
# To apply settings across multiple application servers (standalone and cluster members), use the
# @ITERATE(pattern) parameter for the server name. (Node names will be ignored in the search). To
# prevent cluster members from matching, set includeClusterMembers to false.
#
# You can also use this feature to update nodeagent and dmgr settings if you set the corresponding
# includeManagementServers property to true (default behavior is to not include the management servers
# in the search)
#
# To match On Demand Router servers, set the includeODR property to true (default behavior is to not match
# ODR servers)
#
# app.appserver.2.name = @ITERATE(*)
# app.appserver.2.includeClusterMembers = false
# app.appserver.2.includeManagementServers = false
# app.appserver.2.includeODR = false
# app.appserver.2.node = 
#
# Attribute names retrieved from JavaVirtualMachine object - AdminConfig.attributes("JavaVirtualMachine")
# app.appserver.2.processdef.jvm.prop.initialHeapSize = 512
# app.appserver.2.processdef.jvm.prop.maximumHeapSize = 1024
# app.appserver.2.processdef.jvm.prop.verboseModeGarbageCollection = true
# app.appserver.2.processdef.jvm.prop.verboseModeClass = false
# app.appserver.2.processdef.jvm.prop.verboseModeJNI = false
#
# ---------------------------------------------------
# Specifying a starting port value (application server or cluster members)
# 
# If you want continuous port assignments with a known starting port number,
# application server and cluster member definitions have a meta-property,
# startingport that can be used to make these port assignments when the server
# is created or optionally on updates to existing servers.
#
# By default, the startingport processing will standardize all of the
# host names of the ports to the host name of the node, preventing a 
# port from being attached to localhost or other hostnames. To prevent this,
# set the meta-property startingport.keepHostNames = true
# ---------------------------------------------
# Starting port example for application server:
#
# app.appserver.2.name = MyTestServer
# app.appserver.2.node = IMScriptingNode1
# 
# # Starting port : Port assignment will start at 20000
# # Port host names will be untouched 
# app.appserver.2.startingport = 20000
# app.appserver.2.startingport.keepHostNames = true
#
# # Port values will be assigned only to new servers unless this setting is set to true
# app.appserver.2.processPortsOnExistingServer = false
#
# # If ports are being set up, you can optionally specify the virtual host to add
# # the HTTP and HTTPS ports as aliases to
# app.appserver.2.mapPortsToVirtualHost = 
# ---------------------------------------------
# Starting port example for cluster member:
#
# app.cluster.3.name = SampleCluster
# app.cluster.3.preferlocal = true
# app.cluster.3.createDomain = false
#  
# # This optional setting controls which virtual host the servers
# # HTTP/HTTPS ports will be added to as host aliases to the Virtual Host specified here
# app.cluster.3.mapPortsToVirtualHost =
# 
# app.cluster.3.clustermember.1.name = SampleCluster_1
# app.cluster.3.clustermember.1.node = IMScriptingNode1
#  
# # Starting port for this server is 20000, all host names will be changed to node host name
# app.cluster.3.clustermember.1.startingport = 20000
# app.cluster.3.clustermember.1.startingport.keepHostNames = false
# 
# ---------------------------------------------------
# Dynamic port assignment for cluster members
#
# This feature is useful when you have a range, but want to 
# work around existing port assignments
#
# app.cluster.3.name = SampleCluster
# app.cluster.3.preferlocal = true
# app.cluster.3.createDomain = false
#
# # This is a cluster-wide starting value
# app.cluster.3.startingport = 20000
#  
# # This optional setting controls which virtual host the servers
# # HTTP/HTTPS ports will be added to as host aliases to the Virtual Host specified here
# app.cluster.3.mapPortsToVirtualHost =
# 
# app.cluster.4.clustermember.1.name = SampleCluster_1
# app.cluster.4.clustermember.1.node = IMScriptingNode1
# 
# # This macro calculates the next available port range 
# # Host names will be untouched 
# app.cluster.4.clustermember.1.startingport =  @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT}
# app.cluster.4.clustermember.1.startingport.keepHostNames = true
# 
# ---------------------------------------------------
# Dynamic port assignment for application servers.
#
# Instead of setting the startingport key to a literal port number, use the
# @{DYNAMIC#CURRENT_NODE#NEXT_STARTING_PORT(port-number)} macro. This is slightly
# different than the syntax for cluster members.
#
# You can also set processPortsOnExistingServer to true to enable updates
# of port numbers for existing servers
#
#  # Starting port : required ONLY FOR CUSTOM PORTS. Leave it blank for WebSphere defaults
#  app.appserver.2.startingport = @{DYNAMIC#CURRENT_NODE#NEXT_STARTING_PORT(12000)}
#  # Port values will be assigned only to new servers unless this setting is set to true
#  app.appserver.2.processPortsOnExistingServer = true
#  # If ports are set up, you can optionally specify the virtual host to add
#  # the ports as aliases to
#  app.appserver.2.mapPortsToVirtualHost = default_host
#
#---------------------------------------------------------------------------
# Explicit port assignment for cluster members and application servers.
#
# Explicit port assignments are supported for the times when the incremental
# calculations based on the startingport meta-property doesn't fit the
# needs of the environment. Explicit port assignments cannot be mixed with
# with the calculated port assignments.
#
# 
# See the examples below for the property syntax for explicit port assignments.
# The <prefix>.serverEntry.nameEndPoints properties can be exported
# from an existing configuration using one of the following options:
#    dumpConfig.py -clusters -includeFilter ServerEntry
#    dumpConfig.py -appservers -includeFilter ServerEntry
#
# The script will update the supplied properties, so if you want to change
# only the port values, you do not need to specify the host name.
#
# You do not have to specify all ports if only a few need to be changed
# from the WebSphere generated values.
#
# 
# This script is careful with port assignments, so besides the properties
# for ports, the meta-property processNamedEndPoints must be set to true
# as well (see below for examples)
#
# ----------------------------------------------------
# Application server port assignment example:
#
# app.appserver.2.name = PortyTestServer
# app.appserver.2.node = IMScriptingNode1
#
# # Starting port : should be blank for explicit assignment
# app.appserver.2.startingport = 
#
# # NamedEndPoint information - set processNamedEndPoints to true
# # for updateEnvironment processing 
# app.appserver.2.serverEntry.processNamedEndPoints = true
# app.appserver.2.serverEntry.namedEndPoints.1.name = BOOTSTRAP_ADDRESS
# app.appserver.2.serverEntry.namedEndPoints.1.endPoint.prop.host = JJMW530
# app.appserver.2.serverEntry.namedEndPoints.1.endPoint.prop.port = 31195
# app.appserver.2.serverEntry.namedEndPoints.2.name = CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS
# app.appserver.2.serverEntry.namedEndPoints.2.endPoint.prop.host = JJMW530
# app.appserver.2.serverEntry.namedEndPoints.2.endPoint.prop.port = 31214
# app.appserver.2.serverEntry.namedEndPoints.3.name = CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS
# app.appserver.2.serverEntry.namedEndPoints.3.endPoint.prop.host = JJMW530
# app.appserver.2.serverEntry.namedEndPoints.3.endPoint.prop.port = 31199
# app.appserver.2.serverEntry.namedEndPoints.4.name = DCS_UNICAST_ADDRESS
# app.appserver.2.serverEntry.namedEndPoints.4.endPoint.prop.host = *
# app.appserver.2.serverEntry.namedEndPoints.4.endPoint.prop.port = 31217
# app.appserver.2.serverEntry.namedEndPoints.5.name = IPC_CONNECTOR_ADDRESS
# app.appserver.2.serverEntry.namedEndPoints.5.endPoint.prop.host = localhost
# app.appserver.2.serverEntry.namedEndPoints.5.endPoint.prop.port = 31224
# app.appserver.2.serverEntry.namedEndPoints.6.name = ORB_LISTENER_ADDRESS
# app.appserver.2.serverEntry.namedEndPoints.6.endPoint.prop.host = JJMW530
# app.appserver.2.serverEntry.namedEndPoints.6.endPoint.prop.port = 31197
# ...
# -----------------------------------------------------
# ClusterMember port assignment example:
#
# app.cluster.6.clustermember.1.name = PortfulMember1
# app.cluster.6.clustermember.1.node = IMScriptingNode1
#  
# #  Starting port : should be blank for explicit ports
# app.cluster.6.clustermember.1.startingport = 
#  
#  
# # NamedEndPoint information - set processNamedEndPoints to true
# # for updateEnvironment processing 
# app.cluster.6.clustermember.1.serverEntry.processNamedEndPoints = true
# app.cluster.6.clustermember.1.serverEntry.namedEndPoints.1.name = BOOTSTRAP_ADDRESS
# app.cluster.6.clustermember.1.serverEntry.namedEndPoints.1.endPoint.prop.host = JJMW530
# app.cluster.6.clustermember.1.serverEntry.namedEndPoints.1.endPoint.prop.port = 23137
# app.cluster.6.clustermember.1.serverEntry.namedEndPoints.2.name = CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS
# app.cluster.6.clustermember.1.serverEntry.namedEndPoints.2.endPoint.prop.host = JJMW530
# ...
# ----------------------------------------------------
# Cluster template port assignment example:
#
# This works if there's only one server per node and you want to be 
# consistent with the port values:
#
# # Meta properties that control cluster template properties processing
# app.cluster.6.clusterTemplate.updateTemplate = false
# app.cluster.6.clusterTemplate.applyTemplateSettingsToExistingMembers = true
# app.cluster.6.clusterTemplate.applyTemplateSettingsToNewMembers = true
# 
# # NamedEndPoint information - set processNamedEndPoints to true
# # for updateEnvironment processing 
# #
# # Note that no explicit host names are specified.
# app.cluster.6.clusterTemplate.serverEntry.processNamedEndPoints = true
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.1.name = BOOTSTRAP_ADDRESS
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.1.endPoint.prop.port = 23137
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.2.name = CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.2.endPoint.prop.port = 23142
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.3.name = CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.3.endPoint.prop.port = 23141
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.4.name = DCS_UNICAST_ADDRESS
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.4.endPoint.prop.host = *
# app.cluster.6.clusterTemplate.serverEntry.namedEndPoints.3.endPoint.prop.port = 23142
#
# ----------------------------------------------------
# Dynamic cluster port assignment example:
# 
# # These meta-properties are required for dynamic cluster port processing
# app.dyncluster.1.processAllClusterMemberPorts = true
# app.dyncluster.1.processAllClusterMemberDefinitions = true
# app.dyncluster.1.processNewClusterMemberDefinitions = false
# 
# app.dyncluster.1.clustermember.1.name = DynamicPorty_IMScriptingNode1
# app.dyncluster.1.clustermember.1.node = IMScriptingNode1
# 
# # This value should be empty if explicit port definitions are used
# app.dyncluster.1.clustermember.1.startingport = 
#
# # NamedEndPoint information - set processNamedEndPoints to true
# # for updateEnvironment processing 
# app.dyncluster.1.clustermember.1.serverEntry.processNamedEndPoints = true
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.1.name = BOOTSTRAP_ADDRESS
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.1.endPoint.prop.host = JJMW530
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.1.endPoint.prop.port = 12312
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.2.name = CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.2.endPoint.prop.host = JJMW530
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.2.endPoint.prop.port = 12317
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.3.name = CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.3.endPoint.prop.host = JJMW530
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.3.endPoint.prop.port = 12316
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.4.name = DCS_UNICAST_ADDRESS
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.4.endPoint.prop.host = *
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.4.endPoint.prop.port = 12320
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.5.name = IPC_CONNECTOR_ADDRESS
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.5.endPoint.prop.host = localhost
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.5.endPoint.prop.port = 12331
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.6.name = ORB_LISTENER_ADDRESS
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.6.endPoint.prop.host = JJMW530
# app.dyncluster.1.clustermember.1.serverEntry.namedEndPoints.6.endPoint.prop.port = 12314
# ....
#---------------------------------------------------------------------------
# PMI Settings
# The default behavior for the enable property is to add what's in the input
# properties to the existing PMI settings.
# 
# For example, the following settings will enable counters 1 and 3, merging them in
# with the existing settings. 
#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.moduleName = orbPerfModule
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.type = orbPerfModule#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.enable = 1,3 
#
#
# To remove some settings or do a complete replacement, there are meta-properties and
# keywords that can be used. 
#
# The removeCounters meta-property can be used to specify the counters to remove from
# the enable attribute. The following example shows how it can be used to remove
# specific counters.
#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.moduleName = orbPerfModule
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.type = orbPerfModule#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.removeCounters = 1,3
#
# A value of ALL can be used to clear all counters:
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.moduleName = orbPerfModule
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.type = orbPerfModule#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.removeCounters = ALL
#
# Using the @CLEAR keyword with the enable property can be used to remove all or some of the
# properties, making it an alternative for the removeCounters property. In the first example,
# counters 2 and 1 are removed from enable. In the second, all are removed.
#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.moduleName = orbPerfModule
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.type = orbPerfModule#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.enable = @CLEAR(2,1)
#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.moduleName = orbPerfModule
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.type = orbPerfModule#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.enable = @CLEAR
#
# The @RESET keyword can be used to do a complete replacement of the enable property 
# instead of a merge. In the example below, the value of enable is changed to just include
# the 2 and 3 counters.
#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.moduleName = orbPerfModule
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.type = orbPerfModule#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.enable = @RESET(2,3)
#
# Using @RESET with no parameters acts like @CLEAR
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.moduleName = orbPerfModule
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.type = orbPerfModule#
# app.cluster.1.clustermember.1.pmiService.pmimodules.10.prop.enable = @RESET()
#---------------------------------------------------------------------------------------------------

from java.lang import System

#---------------------------------------------------------------------------------------------------
# exit()
#---------------------------------------------------------------------------------------------------
def exit(errflg = 1):
  import sys
  
  if (errflg):
      try:
        _app_message("Exiting after failure")
      except:
        print "Exiting after failure"

  # In some situations (such as running with the Dmgr for scheduled
  # scripts, we want to avoid call sys.exit()
  exitDisabled = System.getProperty("app.exitDisabled")
  if (exitDisabled != None and exitDisabled.lower() == "true"):
    if (errflg == 1):
      # Throw some error
      raise SystemError("Fatal Error discovered")
    else:
      return
  else:
    sys.exit()


#----------------------------------------------------------------------------------------------------
# setupApplicationServerBaseApplicationServerSettings
#
# Process the base ApplicationServer component settings for a specific server. This function
# also handles custom properties for the ApplicationServer component.  This function reads
# the <prefix>.applicationServer properties from the global serverConfigInfo dictionary and performs
# the necessary updates to the configuration item.
# 
# Parameters:
#   serverId - the configuration ID of the server (or cluster template) to configure
#   prefix - The part of the property keys to load that uniquely identies a server. 
#            (e.g. "app.cluster.1.clustermember.1")
#   appserverName - The name of the application server (for logging only)
#   existingProps - if not None, a sign that this is an update of an existing application server
#                   and we should compare against existing settings before proceeding
#----------------------------------------------------------------------------------------------------
def setupApplicationServerBaseApplicationServerSettings(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  _app_trace("setupApplicationServerBaseApplicationServerSettings(%s, %s, %s, existingProps)" % (serverId, prefix, appserverName), "entry")
  
  if (checkForPrefix(serverConfigInfo,"%s.applicationServer" % prefix)):
    applicationServerId = AdminConfig.list("ApplicationServer",serverId)
    
    # Load existing properties for the ApplicationServer component if this is an update to an existing server
    # and we are actually changing those properties
    if (existingProps != None):
       getApplicationServerComponentProperties(serverId,existingProps)
  
    subProps = getPropListDifferences(serverConfigInfo, "%s.applicationServer"  % (prefix), existingProps, "appserver.applicationServer" )
    if (len(subProps) > 0) :
      
      applicationServerPropAttrs = []
      for key in subProps.keys():
          applicationServerPropAttrs.append([key, subProps[key]])
          
      if modifyObject(applicationServerId, applicationServerPropAttrs):
          _app_message("Failed to modify base ApplicationServer attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified base ApplicationServer attributes for appserver %s" % (appserverName))
    else:
      _app_message("No need to modify base ApplicationServer attributes for appserver %s" % (appserverName))
  
    # Now check for custom properties
    subProps = getPropListDifferences(serverConfigInfo, "%s.applicationServer.properties"  % (prefix), existingProps, "appserver.applicationServer.properties" )
    if (len(subProps) > 0):
      # Call 
      errMsg = updateCustomProperties(applicationServerId, "properties", "Property", subProps)
      if (not isEmpty(errMsg)):
        _app_message("Error updating custom properties for base ApplicationServer component for appserver %s: %s" % (appserverName,errMsg))
        exit()
      else:
        _app_message("Updated custom properties for base ApplicationServer component for appserver %s" % appserverName)

  else:
    _app_message("No base ApplicationServer settings to process for appserver %s" % appserverName)
  
  _app_trace("setupApplicationServerBaseApplicationServerSettings()", "exit")    
          
#enddef setupApplicationServerBaseApplicationServerSettings


#----------------------------------------------------------------------------------------------------
# setupApplicationServerTransportChannel
#----------------------------------------------------------------------------------------------------
def setupApplicationServerTransportChannel(serverConfigInfo,serverId, chainId, chainName, channelName, prefix, appserverName, existingProps, overrideSettings=0):

  retval = 0
  _app_trace("setupApplicationServerTransportChannel(%s,%s,%s,%s, %s, %s, existingProps, %d)" % (serverId, chainId, chainName, channelName, prefix, appserverName,overrideSettings), "entry")
  try:
  
      channelId = findTransportChannel(channelName,chainId)
      if (isEmpty(channelId)):
          _app_message("TransportChannel %s not found in server %s" % (channelName, appserverName))
          exit()
          
      if (overrideSettings):
          removeAllCustomProperties(channelId, "properties")
      
      existingChannelProps = None
      
      if (existingProps != None):
          # This is an existing server
          existingChannelProps = getTransportChannelProperties(channelId)
      
      subProps = getPropListDifferences(serverConfigInfo, prefix, existingChannelProps, "channel")
      customProps = getPropListDifferences(serverConfigInfo, "%s.customProperties" % prefix, existingChannelProps, "channel.customProperties")
      loggingProps = getPropListDifferences(serverConfigInfo,"%s.httpInboundChannelLogging"%prefix,existingChannelProps,"channel.httpInboundChannelLogging")
      accessLogProps = getPropListDifferences(serverConfigInfo,"%s.httpInboundChannelLogging.accessLog"%prefix,existingChannelProps,"channel.httpInboundChannelLogging.accessLog")
      errorLogProps = getPropListDifferences(serverConfigInfo,"%s.httpInboundChannelLogging.errorLog"%prefix,existingChannelProps,"channel.httpInboundChannelLogging.errorLog")
      
      # Not all channels will have thread pool settings
      inputThreadPoolName = serverConfigInfo.get("%s.threadPool.name" % prefix,None)
      currentThreadPoolName = None
      if (not isEmpty(inputThreadPoolName)): 
        if (existingChannelProps == None):
          currentThreadPoolId = AdminConfig.showAttribute(channelId,"threadPool")
          if (not isEmpty(currentThreadPoolId)):
            currentThreadPoolName = AdminConfig.showAttribute(currentThreadPoolId,"name")
        else:    
          currentThreadPoolName = existingChannelProps.get("channel.threadPool.name",None)
      
      
      if (len(subProps) > 0 or (inputThreadPoolName != currentThreadPoolName)):
        retval = 1
        
        # Use string to support passivation directory with bad slash
        attrs = ""
        if (inputThreadPoolName != currentThreadPoolName):
          # Look up thread pool Id for reference attribute
          nodeName = getNodeNameForServer(serverId)
          threadPoolId = AdminConfig.getid("/Node:%s/Server:%s/ThreadPoolManager:/ThreadPool:%s/"% (nodeName,appserverName,inputThreadPoolName))
          if (isEmpty(threadPoolId)):
            raise StandardError("Unable to locate threadpool %s" % inputThreadPoolName)
          else:
            attrs = " [ threadPool %s ] "% threadPoolId
          
        
        for key in subProps.keys():
            attrs =  "%s [ %s %s ]" %  (attrs, key, subProps.get(key))
            
        attrs = "[ %s ]" % attrs
                  
        if (modifyObject(channelId,attrs)):
            _app_message("Unable to change TransportChannel attributes on server %s" % (appserverName))
            exit()
            
      if (len(customProps) > 0):
          
          retval = 1
          errmsg = updateCustomProperties(channelId, "properties", "Property", customProps)
          if (not isEmpty(errmsg)):
              _app_message("Failed to update custom properties on TransportChannel %s on server %s - %s" % (channelName,appserverName,errmsg))
              exit()
      
      loggingId = None
      if (len(loggingProps) > 0 or len(accessLogProps) > 0 or len(errorLogProps) > 0):
        
        retval = 1
        loggingId = doUpdateCreate("HTTPInboundChannelLogging",channelId,loggingProps,"httpInboundChannelLogging")
        
        if (len(accessLogProps) > 0):
          accessLogId = doUpdateCreate("LogFile",loggingId,accessLogProps,"accessLog")

        if (len(errorLogProps) > 0):
          errorLogId = doUpdateCreate("LogFile",loggingId,errorLogProps,"errorLog")
          

      if (retval == 0):
          _app_message("No need to modify %s TransportChannel %s settings for server %s" % (chainName, channelName,appserverName))
      else:
          _app_message("Modified %s TransportChannel %s settings for server %s" % (chainName, channelName,appserverName))
      
      
  
      
  
  except:
    _app_trace("Exception processing TransportChannel %s properties" % channelName,"exception")
    _app_message("Unexpected error processing TransportChannel settings %s  for server %s" % (channelName, appserverName))
    exit()
        
  _app_trace("setupApplicationServerTransportChannel(%d)" % retval, "exit") 
  return retval

#----------------------------------------------------------------------------------------------------
# setupApplicationServerTransportChains
#----------------------------------------------------------------------------------------------------
def setupApplicationServerTransportChains(serverConfigInfo,serverId, prefix, appserverName, existingProps, overrideSettings=0):

  _app_trace("setupApplicationServerTransportChains(%s, %s, %s, existingProps, %d)" % (serverId, prefix, appserverName,overrideSettings), "entry")
  try:
  
    if (checkForPrefix(serverConfigInfo,"%s.transportChains" % prefix)):
        # We have settings to process
        
        chainCount = int(serverConfigInfo.get("%s.transportChains.count" % prefix,"0"))
        if (chainCount > 0):
            nodeName = getNodeNameForServer(serverId)
            
            for idx in range(1,chainCount+1):
                chainName = serverConfigInfo.get("%s.transportChains.%d.name" % (prefix,idx),"")
                
                if (isEmpty(chainName)):
                    # Partial list?
                    continue
                
                # Find the chain ID
                chainId = findTransportChain(chainName, serverId,appserverName,nodeName)
                if (isEmpty(chainId)):
                    _app_message("Unable to locate TransportChain %s on server %s" % (serverId, prefix))
                    exit()
                    
                updateFlag = 0
                    
                # See if there are base properties to update
                existingChainProps = None
                if (existingProps != None):
                    existingChainProps = getTransportChainProperties(chainId)
                
                subProps = getPropListDifferences(serverConfigInfo, "%s.transportChains.%d" % (prefix,idx), existingChainProps, "chain")
                if (len(subProps) > 0):
                    updateFlag = 1
                    attrs = ""
                    for key in subProps.keys():
                        attrs =  "%s [ %s %s ]" %  (attrs, key, subProps.get(key))
            
                    attrs = "[ %s ]" % attrs
                  
                    if (modifyObject(chainId,attrs)):
                        _app_message("Unable to modify Chain %s attributes on server %s" % (chainName, appserverName))
                        exit()
                    else:
                        _app_message("Modified Chain %s attributes on server %s" % (chainName, appserverName))

                
                # Now we need to process the channels for this chain
                channelCount = int(serverConfigInfo.get("%s.transportChains.%d.channels.count" % (prefix,idx),0))
                if (channelCount > 0):
                    for channelIdx in range(1,channelCount+1):
                        channelPrefix = "%s.transportChains.%d.channels.%d" % (prefix,idx,channelIdx)
                        channelName = serverConfigInfo.get("%s.name" % channelPrefix,"")
                        if (isEmpty (channelName)):
                            # Partial list
                            continue
                        
                        if (setupApplicationServerTransportChannel(serverConfigInfo,serverId, chainId, chainName,channelName, channelPrefix, appserverName, existingProps, overrideSettings)):
                            updateFlag = 1
                
                if (not updateFlag):
                    _app_message("No need to modify TransportChain %s on Server %s" % (chainName, appserverName))
          
    #endif TransportChains settings to processing     
      
  except:
    _app_trace("Exception processing TransportChains properties","exception")
    _app_message("Unexpected error processing TransportChains settings for server %s" % appserverName)
    exit()
        
  _app_trace("setupApplicationServerTransportChains()", "exit")


#----------------------------------------------------------------------------------------------------
# setupApplicationServerEJBContainer
#----------------------------------------------------------------------------------------------------
def setupApplicationServerEJBContainer(serverConfigInfo,serverId, prefix, appserverName, existingProps, overrideSettings=0):

  _app_trace("setupApplicationServerEJBContainer(%s, %s, %s, existingProps, %d)" % (serverId, prefix, appserverName,overrideSettings), "entry")
  try:
  
    if (checkForPrefix(serverConfigInfo,"%s.ejbContainer" % prefix)):
        # We have settings to process
        
        EJBContainerId = AdminConfig.list("EJBContainer",serverId)
        
        if (existingProps != None):
            getEJBContainerProperties(serverId, existingProps)
            
        subProps = getPropListDifferences(serverConfigInfo,"%s.ejbContainer" % prefix, existingProps, "appserver.ejbContainer")
        cacheProps = getPropListDifferences(serverConfigInfo,"%s.ejbContainer.cacheSettings" % prefix, existingProps, "appserver.ejbContainer.cacheSettings")
        timerProps = getPropListDifferences(serverConfigInfo,"%s.ejbContainer.timerSettings" % prefix, existingProps, "appserver.ejbContainer.timerSettings")
        drsProps = getPropListDifferences(serverConfigInfo,"%s.ejbContainer.drsSettings" % prefix, existingProps, "appserver.ejbContainer.drsSettings")
        
        #V8 component
        asyncProps = getPropListDifferences(serverConfigInfo,"%s.ejbContainer.asyncSettings" % prefix, existingProps, "appserver.ejbContainer.asyncSettings")
        
        
        if (len(subProps) > 0):
            # Use string to support passivation directory with bad slash
            attrs = ""
            for key in subProps.keys():
                attrs =  "%s [ %s %s ]" %  (attrs, key, subProps.get(key))
            
            attrs = "[ %s ]" % attrs
                  
            if (modifyObject(EJBContainerId,attrs)):
                _app_message("Unable to change EJBContainer attributes on server %s" % (appserverName))
                exit()
                
        if (len(cacheProps) > 0):
            attrs = []
            for key in cacheProps.keys():
                attrs.append([key, cacheProps.get(key)])
            
            cacheId = AdminConfig.showAttribute(EJBContainerId, "cacheSettings")
            if (isEmpty(cacheId)):
                cacheId = AdminConfig.create("EJBCache", EJBContainerId,[])
            
            if (modifyObject(cacheId,attrs)):
                _app_message("Unable to change EJBContainer EJBCache attributes on server %s" % (appserverName))
                exit()

        if (len(timerProps) > 0):
            attrs = []
            for key in timerProps.keys():
                attrs.append([key, timerProps.get(key)])
            
            timerId = AdminConfig.showAttribute(EJBContainerId, "timerSettings")
            if (isEmpty(timerId)):
                timerId = AdminConfig.create("EJBTimer", EJBContainerId,[])
            
            if (modifyObject(timerId,attrs)):
                _app_message("Unable to change EJBContainer timer attributes on server %s" % (appserverName))
                exit()
        
        if (len(drsProps) > 0):
            attrs = []
            for key in drsProps.keys():
                attrs.append([key, drsProps.get(key)])
            
            drsId = AdminConfig.showAttribute(EJBContainerId, "drsSettings")
            if (isEmpty(drsId)):
                drsId = AdminConfig.create("DRSSettings", EJBContainerId,[])
            
            if (modifyObject(drsId,attrs)):
                _app_message("Unable to change EJBContainer DRSSettings attributes on server %s" % (appserverName))
                exit()

        #V8 component
        if (len(asyncProps) > 0):
            attrs = []
            for key in asyncProps.keys():
                attrs.append([key, asyncProps.get(key)])
            
            asyncId = AdminConfig.showAttribute(EJBContainerId, "asyncSettings")
            if (isEmpty(asyncId)):
                asyncId = AdminConfig.create("EJBAsync", EJBContainerId,[])
            
            if (modifyObject(asyncId,attrs)):
                _app_message("Unable to change EJBContainer EJBAsync attributes on server %s" % (appserverName))
                exit()


        
        if (len(subProps) == 0 and len(cacheProps) == 0 and len(drsProps) == 0 and len(timerProps) == 0 and len(asyncProps) == 0):
            _app_message("No need to modify EJBContainer settings for server %s" % appserverName) 
        else:
            _app_message("Modified EJBContainer settings for server %s" % appserverName)
          
    #endif EJBContainer settings to processing      
      
  except:
    _app_trace("Exception processing EJBContainer properties","exception")
    _app_message("Unexpected error processing EJBContainer settings for server %s" % appserverName)
    exit()
        
  _app_trace("setupApplicationServerEJBContainer()", "exit")

#----------------------------------------------------------------------------------------------------
# setupJavaPersistenceAPIService
#----------------------------------------------------------------------------------------------------
def setupJavaPersistenceAPIService(serverConfigInfo,serverId,prefix,appserverName, existingProps,overrideSettings=0):
  _app_trace("setupJavaPersistenceAPIService(serverConfigInfo,%s,%s,%s,existingProps,%d)" %  (serverId,prefix,appserverName,overrideSettings),"entry")
  try:
    if (overrideSettings):
      # This will force us to delete custom properties
      jpaId = AdminConfig.list("JavaPersistenceAPIService",serverId)
      if (not isEmpty(jpaId)):
        removeAllCustomProperties(jpaId, "properties")
    
    if (checkForPrefix(serverConfigInfo,"%s.javaPersistenceAPIService" % prefix)):
      # We have settings to process
      
      jpaId = AdminConfig.list("JavaPersistenceAPIService",serverId)
      if (isEmpty(jpaId)):
        # Need to create it
        jpaId = AdminConfig.create("JavaPersistenceAPIService",AdminConfig.list("ApplicationServer",serverId),[])
      
      if (existingProps != None):
        getJavaPersistenceAPIServiceProperties(serverId,existingProps)
      
      subProps = getPropListDifferences(serverConfigInfo,"%s.javaPersistenceAPIService" % prefix, existingProps, "appserver.javaPersistenceAPIService")
      customProps = getPropListDifferences(serverConfigInfo,"%s.javaPersistenceAPIService.properties" % prefix, existingProps, "appserver.javaPersistenceAPIService.properties")

      if (len(subProps) > 0):
        attrs = []
        for key in subProps.keys():
            attrs.append([key, subProps.get(key)])
                  
        if (modifyObject(jpaId,attrs)):
            _app_message("Unable to change JavaPersistenceAPIService attributes on server %s" % (appserverName))
            exit()
        
      if (len(customProps) > 0):
        errmsg = updateCustomProperties(jpaId, "properties", "Property", customProps)
        if (not isEmpty(errmsg)):
          _app_message("Failed to update custom properties on JavaPersistenceAPIService on server %s - %s" % (appserverName,errmsg))
          exit()
        
      if (len(subProps) > 0 or len(customProps) > 0):
        _app_message("Modified JavaPersistenceAPIService on server %s" % (appserverName))
      else:
        _app_message("No need to modify JavaPersistenceAPIService on server %s" % (appserverName))

      
  except:
    _app_exception("Unexpected error in setupJavaPersistenceAPIService")
    
  _app_trace("setupJavaPersistenceAPIService()","exit")



# Take a list of of ExternalCacheGroups in property syntax and turn it
# into a list of nested dictionaries and lists for comparisons
#  [  { name: value, type: value,
#            members: [ {adapterBeanName : value, address: value, frcaCacheGroupMember: {key:value}} , ....] },
#      ...
#  ]
def cacheGroupPropertiesToComparableList(inDict,prefix):
  retval = []
  cgDict = toDictionary(filterProperties(inDict,"%s.cacheGroups" % prefix))
  
  
  cgCount = int(cgDict.get("%s.cacheGroups.count"%prefix,0))
  
  if (cgCount > 0):
    for idx in range(1,cgCount+1):
      cgPrefix = "%s.cacheGroups.%d" % (prefix,idx)
      baseProps = toDictionary(getPropList(cgDict,cgPrefix))
      retval.append(baseProps)
      memberList = []
      baseProps["members"] = memberList
      
      memberCount = int(cgDict.get("%s.members.count"%cgPrefix,0))
      if (memberCount > 0):
        for midx in range(1,memberCount + 1):
          memProps = toDictionary(getPropList(cgDict,"%s.members.%d" % (cgPrefix,midx)))
          memberList.append(memProps)
          frcaProps = toDictionary(getPropList(cgDict,"%s.members.%d.frcaCacheGroupMember" % (cgPrefix,midx)))
          if (len(frcaProps) > 0):
            memProps["frcaCacheGroupMember"] = frcaProps
          
          
      
  
  return retval
  

#----------------------------------------------------------------------------------------------------
# setupDynamicCacheService
#----------------------------------------------------------------------------------------------------
def setupDynamicCacheService(serverConfigInfo,serverId,prefix,appserverName, existingProps,overrideSettings=0):
  _app_entry("setupDynamicCacheService(serverConfigInfo,%s,%s,%s,existingProps,%d)",serverId,prefix,appserverName,overrideSettings)
  try:
    if (checkForPrefix(serverConfigInfo,"%s.dynamicCache"%prefix)):
      cacheServiceId = AdminConfig.list("DynamicCache",serverId)
      if (isEmpty(cacheServiceId)):
        attrs = [["defaultPriority","1"], ["cacheSize","2000"]]
        cacheServiceId = AdminConfig.create("DynamicCache",serverId,attrs)
        
      if (overrideSettings):
        removeAllCustomProperties(cacheServiceId)
      
      if (existingProps != None):
        getDynamicCacheServiceProperties(serverId,existingProps)
      
      baseProps = getPropListDifferences(serverConfigInfo,"%s.dynamicCache"%prefix,existingProps,"appserver.dynamicCache")
      customProps = getPropListDifferences(serverConfigInfo,"%s.dynamicCache.properties"%prefix,existingProps,"appserver.dynamicCache.properties")
      replicationProps = getPropListDifferences(serverConfigInfo,"%s.dynamicCache.cacheReplication"%prefix,existingProps,"appserver.dynamicCache.cacheReplication")
      perfProps = getPropListDifferences(serverConfigInfo,"%s.dynamicCache.diskCacheCustomPerformanceSettings" % prefix, existingProps,"appserver.dynamicCache.diskCacheCustomPerformanceSettings")
      diskEvictionProps = getPropListDifferences(serverConfigInfo,"%s.dynamicCache.diskCacheEvictionPolicy"%prefix,existingProps,"appserver.dynamicCache.diskCacheEvictionPolicy")
      memoryEvictionProps = getPropListDifferences(serverConfigInfo,"%s.dynamicCache.memoryCacheEvictionPolicy"%prefix,existingProps,"appserver.dynamicCache.memoryCacheEvictionPolicy")
      
      clearCacheGroupsText = serverConfigInfo.get("%s.dynamicCache.cacheGroups.clearAll"%prefix,"false").lower()
      clearCacheGroups = 0
      if (clearCacheGroupsText in ["true","yes"]):
        clearCacheGroups = 1
      
      inputCacheGroups = cacheGroupPropertiesToComparableList(serverConfigInfo,"%s.dynamicCache" % prefix)
      existingCacheGroups = []
      if (len(inputCacheGroups) != 0):
        if (existingProps == None):
          # Go ahead and load the existing properties for this new server
          # to minimize update effort
          existingProps = {}
          getDynamicCacheServiceProperties(serverId,existingProps)
          
        
        existingCacheGroups = cacheGroupPropertiesToComparableList(existingProps,"appserver.dynamicCache")
      
      updateCacheGroups = 0
      if (existingCacheGroups != inputCacheGroups):
        if (not clearCacheGroups):
          tempList = []
          for cg in inputCacheGroups:
            if (cg not in existingCacheGroups):
              tempList.append(cg)
              
          # Doing a merge of settings
          inputCacheGroup = tempList
          if (len(tempList) > 0):
            updateCacheGroups = 1
        else: 
          # Replacing existing settings     
          updateCacheGroups = 1
      elif (not clearCacheGroups):
        # Prevent unnecessary processing
        inputCacheGroups = []
      
      if (len(baseProps) > 0 or len(customProps) > 0 or len(replicationProps) > 0 or len(perfProps) > 0 
          or len(diskEvictionProps) > 0 or len(memoryEvictionProps) > 0 or updateCacheGroups or clearCacheGroups):
        modifyDynamicCache(dynamicCacheId=cacheServiceId,baseProps=baseProps,customProperties = customProps, replicationProps=replicationProps,
                           diskPerformanceProps=perfProps,diskEvictionProps=diskEvictionProps,memoryEvictionProps=memoryEvictionProps,
                           cacheGroups=inputCacheGroups,resetCacheGroups=clearCacheGroups)
        _app_message("DynamicCache service has been updated in server %s" % appserverName)
      else:
        _app_message("No need to modify DynamicCache service in server %s" % appserverName)
      
  except:
    _app_exception("Unexpected error in setupDynamicCacheService: appserver=%s" % appserverName)
  
  _app_exit("setupDynamicCacheService()")


#-------------------------------------------------------------------------------
# setupApplicationServerObjectPoolService
#
# Parameters
#
#-------------------------------------------------------------------------------
def setupApplicationServerObjectPoolService(serverConfigInfo,serverId, prefix, appserverName, existingProps, overrideSettings=0):
  _app_entry("setupApplicationServerObjectPoolService(serverConfigInfo,%s,%s,%s,existingProps,%d)" , serverId,prefix, appserverName,  overrideSettings)
  retval = None
  try:
    
    if (checkForPrefix(serverConfigInfo,"%s.objectPoolService"%prefix)):
      
      # At some point this will be set in this function or looked up
      # in processStandardizedProperties 
      objectPoolServiceId = None
      
      if (overrideSettings):
          # This will force us to delete custom properties
          objectPoolServiceId = AdminConfig.list("ObjectPoolService",serverId)
          removeAllCustomProperties(objectPoolServiceId, "properties")
      
      if (existingProps != None):
        objectPoolServiceId= getObjectPoolServiceProperties(serverId,existingProps)
      
      attributesUpdated =processStandardizedProperties(serverConfigInfo, "%s.objectPoolService"%prefix, existingProps, "appserver.objectPoolService",
                                  targetId=objectPoolServiceId,
                                  parentId=serverId, parentAttribute=None, updateConfigurationType="ObjectPoolService",
                                  processCustomProperties=1)
      
      if (len(attributesUpdated) > 0):
        _app_message("ObjectPoolService for server %s has been updated" % (appserverName))
      else:
        _app_message("No need to modify ObjectPoolService for server %s" % (appserverName))
                                  
      
      
  except:
    _app_exception("Unexpected problem in setupApplicationServerObjectPoolService()")
  
  _app_exit("setupApplicationServerObjectPoolService(retval=%s)" % retval)
  return retval

#----------------------------------------------------------------------------------------------------
# setupApplicationServerOrbService
#----------------------------------------------------------------------------------------------------
def setupApplicationServerORBService(serverConfigInfo,serverId, prefix, appserverName, existingProps, overrideSettings=0):

  _app_trace("setupApplicationServerORBService(%s, %s, %s, existingProps, %d)" % (serverId, prefix, appserverName,overrideSettings), "entry")
  try:
  
    if (overrideSettings):
        # This will force us to delete custom properties
        ORBServiceId = AdminConfig.list("ObjectRequestBroker",serverId)
        removeAllCustomProperties(ORBServiceId, "properties")
  
    if (checkForPrefix(serverConfigInfo,"%s.orbService" % prefix)):
        # We have settings to process
        
        ORBServiceId = AdminConfig.list("ObjectRequestBroker",serverId)
        
        if (existingProps != None):
            getORBServiceProperties(serverId, existingProps)
            
        subProps = getPropListDifferences(serverConfigInfo,"%s.orbService" % prefix, existingProps, "appserver.orbService")
        threadPoolProps = getPropListDifferences(serverConfigInfo,"%s.orbService.threadPool" % prefix, existingProps, "appserver.orbService.threadPool")
        customProps = getPropListDifferences(serverConfigInfo,"%s.orbService.customProperties" % prefix, existingProps, "appserver.orbService.customProperties")
        
        if (len(subProps) > 0):
            attrs = []
            for key in subProps.keys():
                attrs.append([key, subProps.get(key)])
                  
            if (modifyObject(ORBServiceId,attrs)):
                _app_message("Unable to change ORBService attributes on server %s" % (appserverName))
                exit()
                
        if (len(threadPoolProps) > 0):
            attrs = []
            for key in threadPoolProps.keys():
                attrs.append([key, threadPoolProps.get(key)])
            
            threadPoolId = AdminConfig.showAttribute(ORBServiceId,"threadPool")
            if (isEmpty(threadPoolId)):
                threadPoolId = AdminConfig.create("ThreadPool", ORBServiceId,[])
            
            if (modifyObject(threadPoolId,attrs)):
                _app_message("Unable to change ORBService ThreadPool attributes on server %s" % (appserverName))
                exit()
                
        if (len(customProps) > 0):
            errmsg = updateCustomProperties(ORBServiceId, "properties", "Property", customProps)
            if (not isEmpty(errmsg)):
                _app_message("Failed to update custom properties on ORBService on server %s - %s" % (appserverName,errmsg))
                exit()
        
        if (len(subProps) == 0 and len(customProps) == 0 and len(threadPoolProps) == 0):
            _app_message("No need to modify ORBService settings for server %s" % appserverName) 
        else:
            _app_message("Modified ORBService settings for server %s" % appserverName)
          
    #endif ORBService settings to processing      
      
  except:
    _app_trace("Exception processing ORBService properties","exception")
    _app_message("Unexpected error processing ORBService settings for server %s" % appserverName)
    exit()
        
  _app_trace("setupApplicationServerORBService()", "exit")
  
#----------------------------------------------------------------------------------------------------
# setupApplicationServerWebContainer
#----------------------------------------------------------------------------------------------------
def setupApplicationServerWebContainer(serverConfigInfo,serverId, prefix, appserverName, existingProps, overrideSettings=0):

  _app_trace("setupApplicationServerWebContainer(%s, %s, %s, existingProps, %d)" % (serverId, prefix, appserverName,overrideSettings), "entry")
  try:
  
    if (overrideSettings):
        # This will force us to delete custom properties
        webcontainerId = AdminConfig.list("WebContainer",serverId)
        removeAllCustomProperties(webcontainerId, "properties")
  
    if (checkForPrefix(serverConfigInfo,"%s.webContainer.prop" % prefix) or checkForPrefix(serverConfigInfo,"%s.webContainer.customProperties" % prefix)):
        # We have settings to process
        
        webcontainerId = AdminConfig.list("WebContainer",serverId)
        
        
        # @JJM - Some odd behavior with new ODR/enableServletCaching attribute  8.5.5.8
        # Can work around it by always checking against settings
        if (existingProps == None):
          existingProps = {}
        
        if (existingProps != None):
            getWebContainerProperties(serverId, existingProps)
            
        subProps = getPropListDifferences(serverConfigInfo,"%s.webContainer" % prefix, existingProps, "appserver.webContainer")
        customProps = getPropListDifferences(serverConfigInfo,"%s.webContainer.customProperties" % prefix, existingProps, "appserver.webContainer.customProperties")
        
        if (len(subProps) > 0):
            attrs = []
            for key in subProps.keys():
                attrs.append([key, subProps.get(key)])
                  
            if (modifyObject(webcontainerId,attrs)):
                _app_message("Unable to change WebContainer attributes on server %s" % (appserverName))
                exit()
                
        if (len(customProps) > 0):
            errmsg = updateCustomProperties(webcontainerId, "properties", "Property", customProps)
            if (not isEmpty(errmsg)):
                _app_message("Failed to update custom properties on WebContainer on server %s - %s" % (appserverName,errmsg))
                exit()
        
        if (len(subProps) == 0 and len(customProps) == 0):
            _app_message("No need to modify WebContainer settings for server %s" % appserverName) 
        else:
            _app_message("Modified WebContainer settings for server %s" % appserverName)
          
    #endif webcontainer settings to processing      
      
  except:
    _app_trace("Exception processing webContainer properties","exception")
    _app_message("Unexpected error processing WebContainer settings for server %s" % appserverName)
    exit()
        
  _app_trace("setupApplicationServerWebContainer()", "exit")

#enddef setupApplicationServerWebContainer


#----------------------------------------------------------------------------------------------------
# setupApplicationServerPortletContainer
#
# Process the PortletContainer component settings for a specific server. This function
# also handles custom properties for the PortletContainer component.  This function reads
# the <prefix>.portletContainer properties from the global serverConfigInfo dictionary and performs
# the necessary updates to the configuration item.
# 
# Parameters:
#   serverId - the configuration ID of the server (or cluster template) to configure
#   prefix - The part of the property keys to load that uniquely identies a server. 
#            (e.g. "app.cluster.1.clustermember.1")
#   appserverName - The name of the application server (for logging only)
#   existingProps - if not None, a sign that this is an update of an existing application server
#                   and we should compare against existing settings before proceeding
#----------------------------------------------------------------------------------------------------
def setupApplicationServerPortletContainer(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  _app_trace("setupPortletContainerPortletContainer(%s, %s, %s, existingProps)" % (serverId, prefix, appserverName), "entry")
  
  if (checkForPrefix(serverConfigInfo,"%s.portletContainer" % prefix)):
    portletContainerId = AdminConfig.list("PortletContainer",serverId)
    
    # Load existing properties for the PortletContainer component if this is an update to an existing server
    # and we are actually changing those properties
    if (existingProps != None):
       getPortletContainerProperties(serverId,existingProps)
  
    subProps = getPropListDifferences(serverConfigInfo, "%s.portletContainer"  % (prefix), existingProps, "appserver.portletContainer" )
    if (len(subProps) > 0) :
      
      portletContainerAttrs = []
      for key in subProps.keys():
          portletContainerAttrs.append([key, subProps[key]])
          
      if modifyObject(portletContainerId, portletContainerAttrs):
          _app_message("Failed to modify base PortletContainer attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified base PortletContainer attributes for appserver %s" % (appserverName))
    else:
      _app_message("No need to modify base PortletContainer attributes for appserver %s" % (appserverName))
  
    # Now check for custom properties
    subProps = getPropListDifferences(serverConfigInfo, "%s.portletContainer.properties"  % (prefix), existingProps, "appserver.portletContainer.properties" )
    if (len(subProps) > 0):
      # Call 
      errMsg = updateCustomProperties(portletContainerId, "properties", "Property", subProps)
      if (not isEmpty(errMsg)):
        _app_message("Error updating custom properties of PortletContainer for appserver %s: %s" % (appserverName,errMsg))
        exit()
      else:
        _app_message("Updated custom properties of PortletContainer for appserver %s" % appserverName)

  else:
    _app_message("No PortletContainer settings to process for appserver %s" % appserverName)
  
  _app_trace("setupApplicationServerPortletContainer()", "exit")    
          
#enddef setupApplicationServerPortletContainer

#----------------------------------------------------------------------------------------------------
# setupApplicationServerSIPContainer
#
# Process the SIPContainer component settings for a specific server. This function
# also handles custom properties for the SIPContainer component.  This function reads
# the <prefix>.sipContainer properties from the global serverConfigInfo dictionary and performs
# the necessary updates to the configuration item.
# 
# Parameters:
#   serverId - the configuration ID of the server (or cluster template) to configure
#   prefix - The part of the property keys to load that uniquely identies a server. 
#            (e.g. "app.cluster.1.clustermember.1")
#   appserverName - The name of the application server (for logging only)
#   existingProps - if not None, a sign that this is an update of an existing application server
#                   and we should compare against existing settings before proceeding
#----------------------------------------------------------------------------------------------------
def setupApplicationServerSIPContainer(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  _app_trace("setupSIPContainerSIPContainer(%s, %s, %s, existingProps)" % (serverId, prefix, appserverName), "entry")
  
  if (checkForPrefix(serverConfigInfo,"%s.sipContainer" % prefix)):
    sipContainerId = AdminConfig.list("SIPContainer",serverId)
    
    # Load existing properties for the SIPContainer component if this is an update to an existing server
    # and we are actually changing those properties
    if (existingProps != None):
       getSIPContainerProperties(serverId,existingProps)
  
    subProps = getPropListDifferences(serverConfigInfo, "%s.sipContainer"  % (prefix), existingProps, "appserver.sipContainer" )
    if (len(subProps) > 0) :
      
      sipContainerAttrs = []
      for key in subProps.keys():
          sipContainerAttrs.append([key, subProps[key]])
          
      if modifyObject(sipContainerId, sipContainerAttrs):
          _app_message("Failed to modify base SIPContainer attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified base SIPContainer attributes for appserver %s" % (appserverName))
    else:
      _app_message("No need to modify base SIPContainer attributes for appserver %s" % (appserverName))
  
    # Now check for custom properties
    subProps = getPropListDifferences(serverConfigInfo, "%s.sipContainer.properties"  % (prefix), existingProps, "appserver.sipContainer.properties" )
    if (len(subProps) > 0):
      # Call 
      errMsg = updateCustomProperties(sipContainerId, "properties", "Property", subProps)
      if (not isEmpty(errMsg)):
        _app_message("Error updating custom properties of SIPContainer for appserver %s: %s" % (appserverName,errMsg))
        exit()
      else:
        _app_message("Updated custom properties of SIPContainer for appserver %s" % appserverName)
    else:
      # Print "no need to modify" only if properties were passed in
      if (checkForPrefix(serverConfigInfo,"%s.sipContainer.properties" % prefix)):
        _app_message("No need to modify custom properties for SIPContainer")


    # Now check for Stack properties
    stackSubProps = getPropListDifferences(serverConfigInfo, "%s.sipContainer.stack"  % (prefix), existingProps, "appserver.sipContainer.stack" )
    timersSubProps = getPropListDifferences(serverConfigInfo, "%s.sipContainer.stack.timers"  % (prefix), existingProps, "appserver.sipContainer.stack.timers" )
    if (len(stackSubProps) > 0 or len(timersSubProps) > 0):
      stackId = AdminConfig.showAttribute(sipContainerId, "stack")
      if (isEmpty(stackId)):
        _app_trace("About to call AdminConfig.create(Stack,%s,[])" % sipContainerId)
        stackId = AdminConfig.create("Stack",sipContainerId,[])
      
      # Stack attributes 
      if (len(stackSubProps) > 0):  
        stackAttrs = []
        for key in stackSubProps.keys():
          stackAttrs.append([key, stackSubProps[key]])
          
        if modifyObject(stackId, stackAttrs):
          _app_message("Failed to modify SIPContainer Stack attributes for appserver %s" % (appserverName))
          exit()
        else:
          _app_message("Updated Stack properties of SIPContainer for appserver %s" % appserverName)
      else:
        _app_message("No need to modify Stack properties for SIPContainer for appserver %s" % appserverName)
        
      # Stack Timers attributes
      if (len(timersSubProps) > 0):
        timerId = AdminConfig.showAttribute(stackId,"timers")
        if (isEmpty(timerId)):
          _app_trace('About to call AdminConfig.create("Timers",%s,[])' % stackId)
          timerId = AdminConfig.create("Timers",stackId,[])
        timerAttrs = []
        for key in timersSubProps.keys():
          timerAttrs.append([key, timersSubProps[key]])
          
        if modifyObject(timerId, timerAttrs):
          _app_message("Failed to modify SIPContainer Stack Timers attributes for appserver %s" % (appserverName))
          exit()
        else:
          _app_message("Updated Stack Timers properties of SIPContainer for appserver %s" % appserverName)
      else:
        _app_message("No need to modify Stack Timers properties for SIPContainer for appserver %s" % appserverName)
    else:
      # No Stack or Timers updates needed
      if (checkForPrefix(serverConfigInfo,"%s.sipContainer.stack" % prefix)):
        _app_message("No need to modify SIPContainer Stack for appserver %s" % appserverName)
    

  else:
    _app_message("No SIPContainer settings to process for appserver %s" % appserverName)
  
  _app_trace("setupApplicationServerSIPContainer()", "exit")    
          
#enddef setupApplicationServerSIPContainer

#----------------------------------------------------------------------------------------------------
# setupApplicationServerHAManagerService
#----------------------------------------------------------------------------------------------------
def setupApplicationServerHAManagerService(serverConfigInfo,serverId, prefix, appserverName, existingProps,overrideSettings=0):

  _app_trace("setupApplicationServerHAManagerService(%s, %s, %s, existingProps,%d)" % (serverId, prefix, appserverName,overrideSettings), "entry")
  try:
  
    if (overrideSettings):
        haserviceList = AdminConfig.list("HAManagerService",serverId).split(progInfo["line.separator"])
        if (len(haserviceList) >= 1 and not isEmpty(haserviceList[0])):
            haservice = haserviceList[0]
            removeAllCustomProperties(haservice, "properties")
        
        
  
    if (checkForPrefix(serverConfigInfo,"%s.hamanagerService" % prefix)):
      # We have settings to process
      
      # Load current server settings if necessary
      if (existingProps != None):
        getHAManagerServiceProperties(serverId,existingProps)
          
      # Get base service properties
      subProps = getPropListDifferences(serverConfigInfo,"%s.hamanagerService" % (prefix), existingProps, "appserver.hamanagerService")
      coreGroup = subProps.remove("coreGroupName")
      threadPoolProps = getPropListDifferences(serverConfigInfo,"%s.hamanagerService.threadPool" % (prefix), existingProps, "appserver.hamanagerService.threadPool")
      customProps = getPropListDifferences(serverConfigInfo,"%s.hamanagerService.customProperties" % (prefix), existingProps, "appserver.hamanagerService.customProperties")
      
      if (len(subProps) > 0 or len(threadPoolProps) > 0 or len(customProps) > 0):
          # Get the service and update it
          
          haserviceList = AdminConfig.list("HAManagerService",serverId).split(progInfo["line.separator"])
          if (len(haserviceList) >= 1 and not isEmpty(haserviceList[0])):
              haservice = haserviceList[0]
          else:
              raise StandardError("Unable to find HAManagerService for server %s" % (appserverName))
          
          if (len(subProps) > 0):
              attrs = []
              for key in subProps.keys():
                  attrs.append([key, subProps.get(key)])
                  
              if (modifyObject(haservice,attrs)):
                  _app_message("Unable to change HAManagerService attributes on server %s" % (appserverName))
                  exit()
          
          if (len(threadPoolProps) > 0):
              threadPoolId = AdminConfig.showAttribute(haservice,"threadPool")
              
              attrs = []
              for key in threadPoolProps.keys():
                  attrs.append([key, threadPoolProps.get(key)])
                  
              if (modifyObject(threadPoolId,attrs)):
                  _app_message("Unable to change HAManagerService threadPool attributes on server %s" % (appserverName))
                  exit()
          
          if (len(customProps) > 0):
              errmsg = updateCustomProperties(haservice, "properties", "Property", customProps)
              if (not isEmpty(errmsg)):
                  _app_message("Failed to update custom properties on HAManagerService on server %s - %s" % (appserverName,errmsg))
                  exit()
          
          _app_message("Updated HAManagerService settings for server %s" % (appserverName))
      else:
          _app_message("No need to modify HAManagerService for server %s" % (appserverName))
              
    # end if hamanagerservice settings are in serverConfigInfo          
      
  except:
      _app_trace("Unexpected error processing HAManagerServcice settings for server %s" % (appserverName),"exception")
      _app_message("Unexpected error processing HAManagerServcice settings for server %s" % (appserverName))
      exit()
      
  _app_trace("setupApplicationServerHAManagerService()" , "exit")


#----------------------------------------------------------------------------------------------------
# setupApplicationServerCustomServices
#----------------------------------------------------------------------------------------------------
def setupApplicationServerCustomServices(serverConfigInfo,serverId, prefix, appserverName, existingProps,overrideSettings=0):

  _app_trace("setupApplicationServerCustomServices(%s, %s, %s, existingProps,%d)" % (serverId, prefix, appserverName,overrideSettings), "entry")
  
  # Load current server settings if necessary
  # Moved below to avoid problems with custom service in template
  #if (existingProps != None):
  #   if (checkForPrefix(serverConfigInfo,"%s.customService" % prefix)):
  #       getCustomServiceProperties(serverId,existingProps)
  
  serviceCount = int(serverConfigInfo.get("%s.customService.count" % prefix, "0"))
  if (serviceCount > 0):
    
      # Load current server custom service settings if necessary
      # We'll need them even if this is a new server in case we are getting from template
      if (existingProps == None):
        existingProps = {}
        
      getCustomServiceProperties(serverId,existingProps)
    
      for idx in range(1,serviceCount+1):
          
          existingPrefix = ""
          serviceId = None
          # See if we have an existing custom service with same displayName
          displayName = serverConfigInfo.get("%s.customService.%d.prop.displayName" % (prefix,idx),"")
          if (existingProps != None):
              existingCount = existingProps.get("appserver.customService.count")
              if (existingCount != None and existingCount != "0"):
                  for eidx in range(1,int(existingCount)+1):
                      tempPrefix = "appserver.customService.%d" % eidx
                      existingDisplayName = existingProps.get("%s.prop.displayName" % tempPrefix)
                      if (existingDisplayName == displayName):
                          # match found
                          existingPrefix = tempPrefix
                          serviceId = existingProps.get("%s.CONFIGURATION_ID" % existingPrefix)
                          break
          
          if (existingPrefix != ""):
              subProps = getPropListDifferences(serverConfigInfo,"%s.customService.%d" % (prefix, idx), existingProps, existingPrefix)
              customProps = getPropListDifferences(serverConfigInfo,"%s.customService.%d.customProperties" % (prefix, idx), existingProps, "%s.customProperties" % existingPrefix)
          else:
              subProps = getPropList(serverConfigInfo,"%s.customService.%d" % (prefix, idx))
              customProps = getPropList(serverConfigInfo,"%s.customService.%d.customProperties" % (prefix, idx))
              
          if (len(subProps) > 0):
              attrs = "["
              for key in subProps.keys():
                  val = subProps.get(key)
                  if (key == "displayName" or key == "description"):
                      if not val.startswith('"'):
                          val = '"%s"' % val
                  
                  attrs = "%s [%s %s]" % (attrs, key, val)
              
              attrs = "%s ]" % attrs
                          
              if (not isEmpty(serviceId)):
                  # Doing an update
                  if (modifyObject(serviceId,attrs)):
                      _app_message("Error updating Custom Service %s in server %s" % (displayName, appserverName))
                  else:
                      _app_message("Updated Custom Service %s in server %s" % (displayName, appserverName))
              else:
                  # Creating
                  try:
                      _app_trace("Calling AdminConfig.create(CustomService,%s,%s)" % (serverId, attrs))
                      serviceId = AdminConfig.create("CustomService",serverId,attrs)
                      if (serviceId != None):
                          _app_message("Created custom service %s in server %s" % (displayName, appserverName))
                  except:
                      _app_trace("Error creating custom service %s in server %s" % (displayName, appserverName),"exception")
                      _app_message("Error creating custom service %s in server %s" % (displayName, appserverName))
                      exit()
          
          if (overrideSettings):
              removeAllCustomProperties(serviceId,"properties")
              
          if (len(customProps) > 0 and not isEmpty(serviceId)):
              errmsg = updateCustomProperties(serviceId, "properties", "Property", customProps)
              if (not isEmpty(errmsg)):
                  _app_message("Failed to update custom properties on CustomService %s on server %s - %s" % (displayName, appserverName,errmsg))
                  exit()
              else:
                  _app_message("Updated custom properties on CustomService %s on server %s" % (displayName, appserverName ))
                  
          
          if (len(customProps) == 0 and len(subProps) == 0):
              _app_message("No need to modify CustomService %s on server %s" % (displayName, appserverName))
              
  _app_trace("setupApplicationServerCustomServices()","exit")               
#enddef setupApplicationServerCustomServices            
  

#----------------------------------------------------------------------------------------------------
# setupProcessDefEnvironmentVariables
#----------------------------------------------------------------------------------------------------
def setupProcessDefEnvironmentVariables(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps,overrideSettings=0):

  # @JJM ProcessDef environment properties
  
  if (overrideSettings):
      removeAllCustomProperties(processId, "environment")
  
  # Load current server settings if necessary
  if (existingProps != None):
      if (checkForPrefix(serverConfigInfo,"%s.processdef.environment" % prefix)):
          getProcessEnvironmentProperties(serverId,existingProps)
  
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.environment" % (prefix), existingProps, "appserver.processdef.environment")  
  if (len(subProps) > 0):
  
    errmsg = updateCustomProperties(processId, "environment", "Property", subProps)
    if (not isEmpty(errmsg)):
        _app_message("Failed to set ProcessDef environment properties for appserver %s %s" % (appserverName, errmsg))
        exit()
    else:
        _app_message("Modified ProcessDef environment properties for appserver %s" % (appserverName))
  else:
    _app_message("No need to modify ProcessDef environment properties for appserver %s" % (appserverName))
    
    
#enddef setupProcessDefEnvironmentVariables

#----------------------------------------------------------------------------------------------------
# setupProcessDefWorkingDirectory
#----------------------------------------------------------------------------------------------------
def setupProcessDefWorkingDirectory(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps):

  if (existingProps != None):
    if (checkForPrefix(serverConfigInfo,"%s.processdef.process" % prefix)):
        getWorkingDirectoryProperties(serverId, processId, existingProps)

  # @JJM Working directory support
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.process" % (prefix), existingProps, "appserver.processdef.process")  
  if (len(subProps) > 0):
      workingDirectory = subProps["workingDirectory"]
      if not isEmpty(workingDirectory):
          processattrs = [['workingDirectory', workingDirectory]]
          if (modifyObject(processId,processattrs)):
              _app_message("Failed to modify working directory for %s" % (appserverName))
              exit()
          else:
              _app_message("Modified working directory for %s to %s" %(appserverName, workingDirectory))
      else:
          _app_message("No working directory settings for %s" % (appserverName))
  else:
      _app_message("No need to update processdef working directory settings for %s" % (appserverName))
  

# enddef setupProcessDefWorkingDirectory

#----------------------------------------------------------------------------------------------------
# setupApplicationServerClassLoaders
#----------------------------------------------------------------------------------------------------
def setupApplicationServerClassLoaders(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  # @JJM Classloader support
  if serverConfigInfo.has_key("%s.classloaders.count" % (prefix)) :
    clCount = int(serverConfigInfo["%s.classloaders.count" % prefix])
    if (clCount > 0) :
    
      doneClassloaders = "false"
      clidx = 0
      
      
      # See if we need to do an update at all
      # First, we need to get classloader properties, even if existingProps is None
      # in case we inherit settings from template
      if (existingProps == None):
        existingProps = {}
      
      if (existingProps != None):
          # Loading of classloader information has been deferred
          # Need to load those settings now
          getClassloaderProperties(serverId,existingProps)
      
          # Lets see if we need to update at all
          compPropsNew = getComparableProperties(serverConfigInfo,"%s.classloaders" % prefix,"appserver.classloaders")
          compPropsExist = getComparableProperties(existingProps,"appserver.classloaders",None)
          if (compPropsNew.equals(compPropsExist)):
              _app_message("No new classloader settings for appserver %s" % (appserverName))
              doneClassloaders = "true"
          elif len(compPropsExist) > 0:
              #Delete existing classloaders and redefine
              
              appserverid = AdminConfig.list("ApplicationServer", serverId)
              classloaders = AdminConfig.list("Classloader", appserverid).split(progInfo['line.separator'])
              for classloader in classloaders:
                  if (not isEmpty(classloader)):
                      _app_message("Classloader settings are different - deleting existing classloader for appserver %s" % (appserverName))
                      AdminConfig.remove(classloader)
              
      
      while (doneClassloaders == "false"):
          clidx += 1
          if (clidx > clCount):
              doneClassloaders = "true"
              continue
              
          subProps = getPropList(serverConfigInfo, "%s.classloaders.%d" % (prefix,clidx))
          mode = subProps["mode"]
          
          clattrs = [["mode", mode]]
          appserverid = AdminConfig.list("ApplicationServer", serverId)
          classloader = AdminConfig.create("Classloader", appserverid, clattrs)
          
          _app_message("Created classloader with mode %s for appserver %s " % (mode, appserverName))
          
          if serverConfigInfo.has_key("%s.classloaders.%d.libraries.count" % (prefix, clidx)) :
              libCount = int(serverConfigInfo["%s.classloaders.%d.libraries.count" % (prefix, clidx)])
              
              doneLibraries = "false"
              libidx = 0
              while (doneLibraries == "false") : 
                  libidx += 1
                  subProps = getPropList(serverConfigInfo, "%s.classloaders.%d.libraries.%d" % (prefix,clidx,libidx))
                  if (len(subProps) > 0) :
                      libraryName = subProps.get("libraryName")
                      if (libraryName == None):
                          libraryName = ""
                      libAttrs = []
                      for key in subProps.keys() :
                          libAttrs.append([key, subProps[key]])
                      
                      libraryRef = AdminConfig.create("LibraryRef", classloader, [])
                      if (modifyObject(libraryRef, libAttrs)) :
                          _app_message("Failed to modify classLoader library reference %s for %s" % (libraryName, appserverName))
                          exit()
                      else:
                          _app_message("Added classLoader library reference %s for %s" % (libraryName, appserverName))
                  else:
                      doneLibraries = "true"
                      
      #_app_message("Done with classloader settings for appserver %s " % (appserverName))
  else:
      _app_message("No classloader settings for appserver %s" % (appserverName))
      
#enddef setupApplicationServerClassLoaders

#----------------------------------------------------------------------------------------------------
# setupApplicationServerWebserverPluginSettings
#----------------------------------------------------------------------------------------------------
def setupApplicationServerWebserverPluginSettings(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  # @JJM Plugin Settings properties
  
  if (existingProps != None):
      if (checkForPrefix(serverConfigInfo,"%s.webserverPluginSettings" % prefix)):
          getWebServerPluginProperties(serverId,existingProps)
          
  
  subProps = getPropListDifferences(serverConfigInfo, "%s.webserverPluginSettings" % (prefix), existingProps, "appserver.webserverPluginSettings")  
  
  if (len(subProps) > 0) :
      pluginSettings = AdminConfig.list("WebserverPluginSettings",serverId)
      
      pluginAttrs = []
      for key in subProps.keys() :
          if (key == "properties") :
              continue
          pluginAttrs.append([key, subProps[key]])
      
      if (modifyObject(pluginSettings, pluginAttrs)) :
          _app_message("Failed to modify the plugin settings for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified plugin settings for appserver %s" % (appserverName))
  else:
      _app_message("No need to modify plugin settings for appserver %s" % (appserverName))

#enddef setupApplicationServerWebserverPluginSettings

#----------------------------------------------------------------------------------------------------
# setupApplicationServerThreadPools
#----------------------------------------------------------------------------------------------------
def setupApplicationServerThreadPools(serverConfigInfo,serverId, prefix, appserverName, existingProps):

  # @JJM Full thread pool support
  doneThreadPool="false"
  tpidx=0
  tpm = None
  
  
  if (existingProps != None):
      # Check to see if we are even processing thread pool settings
      if (checkForPrefix(serverConfigInfo,"%s.threadPoolManager.threadPool" % prefix)):
          # Load the threadpool information into the existingProps
          getThreadPoolProperties(serverId,existingProps)
          
  tpCount = int(serverConfigInfo.get("%s.threadPoolManager.threadPool.count" % prefix, "0"))
  nodeName = ""
  if (tpCount > 0):
    tpm = AdminConfig.list("ThreadPoolManager", serverId)
    nodeName = getNodeNameForServer(serverId)
  
  while (tpidx < tpCount):
      tpidx = tpidx + 1
      subProps = getPropList(serverConfigInfo, "%s.threadPoolManager.threadPool.%d" % (prefix,tpidx))
      if (len(subProps) > 0):
          tpname = subProps["name"]
          
          if (existingProps != None):
              # Find info on existing thread pool with this name
              existingSubProps=getPropListWithMatchingName(existingProps, "appserver.threadPoolManager.threadPool", tpname)
              if (len(existingSubProps) > 0):
                  # We'll update only changed properties
                  keepRulesProps = getPropList(serverConfigInfo, "%s.threadPoolManager.threadPool.%d.keepRules" % (prefix,tpidx))
                  if (len(keepRulesProps) == 0):
                      keepRulesProps = None
                  subProps = getModifiedProperties(subProps, existingSubProps,keepRulesProps)
                  if (len(subProps) == 0):
                      _app_message("No need to modify %s ThreadPool attributes for appserver %s" % (tpname, appserverName))
                      continue
                  
          
          # Find thread pool with this name
          
          tp = None
          
          if (serverId.find("Template") >= 0 or serverId.find("dynamicclusters") >= 0):
            # Use alternative method to find tp
            tplist = AdminConfig.list("ThreadPool",tpm).split(progInfo['line.separator'])
          
            for temptp in tplist:
              tempname = AdminConfig.showAttribute(temptp,"name")
              if (tempname == tpname): 
                tp = temptp
                break
          else:
            tp = AdminConfig.getid("/Node:%s/Server:%s/ThreadPoolManager:/ThreadPool:%s" % (nodeName, appserverName,tpname))
          
          if (isEmpty(tp)):
            tpfound = 0
          else:
            tpfound = 1
          #tplist = AdminConfig.list("ThreadPool",tpm).split(progInfo['line.separator'])
          #tpfound=0
          #for tp in tplist:
          #   tempname = AdminConfig.showAttribute(tp,"name")
          #   if (tempname == tpname): 
        
          if (tpfound):
                  #Update this threadpool
                  tpfound=1
                  threadAttrs = []
                  for key in subProps.keys():
                      if (key != "name"):
                        threadAttrs.append([key, subProps[key]])
                  
                  if modifyObject(tp, threadAttrs):
                      _app_message("Failed to modify %s ThreadPool attributes for appserver %s" % (tpname, appserverName))
                      exit()
                  else:
                      _app_message("Modified %s ThreadPool  attributes for appserver %s" % (tpname, appserverName))
                  
                  
          if (not tpfound):
              # New thread pool to create
              threadAttrs = []
              for key in subProps.keys():
                    threadAttrs.append([key, subProps[key]])
              tp = AdminConfig.create("ThreadPool",tpm, threadAttrs)
              _app_message("Created new ThreadPool %s for appserver %s" % (tpname, appserverName))
      else:
        continue
        #break                  

#enddef setupApplicationServerThreadPools

#----------------------------------------------------------------------------------------------------
# setupApplicationServerSessionManagement
#----------------------------------------------------------------------------------------------------
def setupApplicationServerSessionManagement(serverConfigInfo,serverId, prefix, appserverName, existingProps):

  # SessionManagement properties
  if (checkForPrefix(serverConfigInfo,"%s.webContainer.sessionManagement" % prefix)):
    
      webContainerId = AdminConfig.list("WebContainer", serverId)
      sessionMgrId = AdminConfig.list("SessionManager", webContainerId)
      if (sessionMgrId == ""):
          attrs = []
          sessionMgrId = AdminConfig.create("SessionManager", webContainerId,attrs)
  else:
    _app_message("No neeed to update WebContainer SessionManager settings for server %s" % (appserverName))
    return
      
  if (existingProps != None):
    if (checkForPrefix(serverConfigInfo,"%s.webContainer.sessionManagement" % prefix)):
        # load session properties into the existingProps
        getSessionManagementProperties(serverId, existingProps)

  subProps = getPropListDifferences(serverConfigInfo, "%s.webContainer.sessionManagement" % (prefix), existingProps, "appserver.webContainer.sessionManagement")  
  if (len(subProps) > 0):
  
    propAttrs = "["
      
    for key in subProps.keys():
      propAttrs += "[%s %s]" % (key, subProps[key])

    propAttrs += "]"
      
    if modifyObject(sessionMgrId, propAttrs):
      _app_message("Failed to modify webcontainer session management attributes for appserver %s" % (appserverName))
      exit()
    else:
      _app_message("Modified webcontainer session management attributes for appserver %s" % (appserverName))
  else:
      _app_message("No need to modify webcontainer session management attributes to update for appserver %s" % (appserverName))

  customProps = getPropListDifferences(serverConfigInfo, "%s.webContainer.sessionManagement.properties" % (prefix), existingProps, "appserver.webContainer.sessionManagement.properties")
  if (len(customProps) > 0):
    errMsg = updateCustomProperties(sessionMgrId, "properties", "Property", customProps) 
    if (not isEmpty(errMsg)):
      _app_exception("Error updating Session Manager custom properties for server %s, error=%s" % (appserverName,errMsg))
    else:
      _app_message("Updated Session Manager custom properties for server %s" % (appserverName))
      
  # @JJM - session management tuning parameters
  subProps = getPropListDifferences(serverConfigInfo, "%s.webContainer.sessionManagement.tuningParams" % (prefix), existingProps, "appserver.webContainer.sessionManagement.tuningParams")  
  if (len(subProps) > 0):
      tuningParamsId = AdminConfig.list("TuningParams", sessionMgrId)
      if (tuningParamsId == "") :
        attrs = []
        tuningParamsId = AdminConfig.create("TuningParams", sessionMgrId,attrs)
          
      propAttrs = "["
      for key in subProps.keys():
          propAttrs += "[%s %s]" % (key, subProps[key])
        
      propAttrs += "]"
        
      if modifyObject(tuningParamsId, propAttrs) :
        _app_message("Failed to modify webcontainer session management tuning properties attributes for appserver %s" % (appserverName))
        exit()
      else:
        _app_message("Modified webcontainer session management tuning attributes for appserver %s" % (appserverName))
    
      # Now update the invalidation schedule attributes
      subProps = getPropListDifferences(serverConfigInfo, "%s.webContainer.sessionManagement.tuningParams.invalidationSchedule" % (prefix), existingProps, "appserver.webContainer.sessionManagement.tuningParams.invalidationSchedule")  
      if (len(subProps) > 0) :
          invalidationScheduleId = AdminConfig.list("InvalidationSchedule", tuningParamsId)
          if (invalidationScheduleId == "") :
            attrs = []
            invalidationScheduleId = AdminConfig.create("InvalidationSchedule", tuningParamsId, attrs)
          
          propAttrs = "["
          for key in subProps.keys():
            propAttrs += "[%s %s]" % (key, subProps[key])
        
          propAttrs += "]"
          
          if modifyObject(invalidationScheduleId, propAttrs) :
              _app_message("Failed to modify webcontainer session management tuning invalidation schedule attributes for appserver %s" % (appserverName))
              exit()
          else:
              _app_message("Modified webcontainer session management tuning invalidation schedule attributes for appserver %s" % (appserverName))
    
          
  # @JJM - session management cookie parameters
  subProps = getPropListDifferences(serverConfigInfo, "%s.webContainer.sessionManagement.defaultCookieSettings" % (prefix), existingProps, "appserver.webContainer.sessionManagement.defaultCookieSettings")  
  if (len(subProps) > 0) :
      cookieid = AdminConfig.list("Cookie",sessionMgrId)
      if (cookieid == "") :
          attrs = []
          cookieid = AdminConfig.create("Cookie",sessionMgrId,attrs)
          
      propAttrs = "["
      for key in subProps.keys():
          val = subProps[key]
          if (val == ""):
              val = "''"
          propAttrs += "[%s %s]" % (key, val)
        
      propAttrs += "]"
        
      if modifyObject(cookieid, propAttrs) :
          _app_message("Failed to modify webcontainer session management cookie properties attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified webcontainer session management cookie attributes for appserver %s" % (appserverName))
          

  # @JJM - session management database persistence parameters
  subProps = getPropListDifferences(serverConfigInfo, "%s.webContainer.sessionManagement.sessionDatabasePersistence" % (prefix), existingProps, "appserver.webContainer.sessionManagement.sessionDatabasePersistence")  
  if (len(subProps) > 0) :
      sdp_id = AdminConfig.list("SessionDatabasePersistence",sessionMgrId)
      if (sdp_id == "") :
          attrs = []
          sdp_id = AdminConfig.create("SessionDatabasePersistence",sessionMgrId,attrs)
          
      propAttrs = "["
      for key in subProps.keys():
          val = subProps[key]
          if (val == "") :
            val = "''"
          propAttrs += "[%s %s]" % (key, subProps[key])
        
      propAttrs += "]"
        
      if modifyObject(sdp_id, propAttrs) :
          _app_message("Failed to modify webcontainer session management database persistence properties attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified webcontainer session management database persistence attributes for appserver %s" % (appserverName))
      
  # @JJM - session management memory-to-memory persistence parameters
  subProps = getPropListDifferences(serverConfigInfo, "%s.webContainer.sessionManagement.sessionDRSPersistence" % (prefix), existingProps, "appserver.webContainer.sessionManagement.sessionDRSPersistence")  
  if (len(subProps) > 0) :
      sdrs_id = AdminConfig.list("DRSSettings",sessionMgrId)
      if (sdrs_id == "") :
          attrs = []
          sdrs_id = AdminConfig.create("DRSSettings",sessionMgrId,attrs)
          
      propAttrs = "["
      for key in subProps.keys():
          val = subProps[key]
          if (val == "") :
            val = "''"
          propAttrs += "[%s %s]" % (key, subProps[key])
        
      propAttrs += "]"
        
      if modifyObject(sdrs_id, propAttrs) :
          _app_message("Failed to modify webcontainer session management memory-to-memory persistence properties attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified webcontainer session management memory-to-memory persistence attributes for appserver %s" % (appserverName))
          
#enddef setupApplicationServerSessionManagement

#----------------------------------------------------------------------------------------------------
# setupApplicationServerLogs
#
# Process the settings for application server logs
#----------------------------------------------------------------------------------------------------
def setupApplicationServerLogs(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  
  if (checkForPrefix(serverConfigInfo,"%s.processdef.outputLog" % (prefix)) or checkForPrefix(serverConfigInfo,"%s.processdef.errorLog" % (prefix))):
    if (existingProps != None):
      # load output and error log properties into the existingProps
      getStreamRedirectProperties(serverId, existingProps)
  else:
    _app_message("No need to update stdout and stderr settings for appserver %s" % appserverName)
    return
      
        
  # Set Logging properties
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.outputLog" % (prefix), existingProps, "appserver.processdef.outputLog")  
  if (len(subProps) > 0):
    stdoutId = AdminConfig.showAttribute(serverId, "outputStreamRedirect")
    loggingStdoutPropAttrs = "["
      
    for key in subProps.keys():
      loggingStdoutPropAttrs += "[%s %s]" % (key, subProps[key])

    loggingStdoutPropAttrs += "]"
      
    if modifyObject(stdoutId, loggingStdoutPropAttrs):
      _app_message("Failed to modify outputLog attributes for appserver %s" % (appserverName))
      exit()
    else:
      _app_message("Modified outputLog attributes for appserver %s" % (appserverName))
  
  
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.errorLog" % (prefix), existingProps, "appserver.processdef.errorLog")
  if (len(subProps) > 0):
    stderrId = AdminConfig.showAttribute(serverId, "errorStreamRedirect")
    loggingStderrPropAttrs = "["

    for key in subProps.keys():
      loggingStderrPropAttrs += "[%s %s]" % (key, subProps[key])

    loggingStderrPropAttrs += "]"
          
    if modifyObject(stderrId, loggingStderrPropAttrs):
      _app_message("Failed to modify errorLog attributes for appserver %s" % (appserverName))
      exit()
    else:
      _app_message("Modified errorLog attributes for appserver %s" % (appserverName))

#enddef setupApplicationServerLogs

#-------------------------------------------------------------------------------
# setupApplicationServerIoRedirect
#
# Parameters
#
#-------------------------------------------------------------------------------
def setupApplicationServerIoRedirect(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps):
  _app_entry("setupApplicationServerIoRedirect()")
  retval = None
  try:
    if (checkForPrefix(serverConfigInfo,"%s.processdef.ioRedirect" % (prefix))):
      if (existingProps != None):
        # Load current settings into existing props
        getIoRedirectProperties(serverId,processId,existingProps)
    
    baseProps = getPropListDifferences(serverConfigInfo,"%s.processdef.ioRedirect"%prefix,existingProps,"appserver.processdef.ioRedirect")
    if (len(baseProps) > 0):
      doUpdateCreate("OutputRedirect",processId,baseProps,"ioRedirect")
      _app_message("Modified IO Redirect logs for appserver %s" % appserverName)
    else:
      _app_message("No need to update IO Redirect logs for appserver %s" % appserverName)
  except:
    _app_exception("Unexpected problem in setupApplicationServerIoRedirect()")
  
  _app_exit("setupApplicationServerIoRedirect(retval=%s)" % retval)
  return retval

#----------------------------------------------------------------------------------------------------
# setupPMIModules
#
# In the WebSphere and property configurations, the settings for PMI modules is a tree structure
# that can be navigated recursively. This function is called recursively to process the settings
# for a module and its children.
#    Parameters:
#       serverConfigInfo - the dictionary with the input property set
#       modulePrefix - The property prefix, e.g. "app.cluster.1.clustermember.1.pmiService.pmimodules.2.pmimodules.1"
#       appserverName - name of the server being configured
#       pmiDescriptorDict - dictionary with the current PMIModule settings from the saved configuration
#       parentDescriptor - key into pmiDescriptorDict for the parent configuration item in [ (name,type), (name, type),...] syntax
#       pmiServiceID - configuration ID of the PMIService for the server
#----------------------------------------------------------------------------------------------------
def setupPMIModules(serverConfigInfo, modulePrefix,  appserverName, pmiDescriptorDict,parentDescriptor, pmiServiceId):
  _app_trace("setupPMIModules(serverConfigInfo, %s, %s, pmiDescriptorDict,%s,%s)" % (modulePrefix, appserverName,parentDescriptor,pmiServiceId),"entry")
  try:
    modProps = getPropList(serverConfigInfo, modulePrefix)
    
    moduleName = modProps.get("moduleName")
    moduleType = modProps.get("type")

    newRemoveModule = serverConfigInfo.get("%s.deleteModule" % modulePrefix, "false")
    if (newRemoveModule == "true"):
      # Process module
      moduleDescriptor = []
      moduleDescriptor.extend(parentDescriptor)
      moduleDescriptor.append((moduleName,moduleType))
      
      moduleDescriptorKey =  str(moduleDescriptor)
      
      # Lookup current settings
      currentSettings = pmiDescriptorDict.get( moduleDescriptorKey, None)
      if (currentSettings != None):
        moduleId = currentSettings.get("pmiModule.CONFIG_ID")
        AdminConfig.remove(moduleId)
        _app_message("Deleted module %s for appserver %s" % (moduleDescriptorKey,appserverName))
      else:
        _app_message("No need to Delete module %s for appserver %s" % (moduleDescriptorKey,appserverName))
        
    elif (moduleName and moduleType):
      # Process module
      moduleDescriptor = []
      moduleDescriptor.extend(parentDescriptor)
      moduleDescriptor.append((moduleName,moduleType))
      
      moduleDescriptorKey =  str(moduleDescriptor)
      
      # Lookup current settings
      currentSettings = pmiDescriptorDict.get( moduleDescriptorKey, None)
      
      if (currentSettings):
        # Existing - do an update
        newRemove = serverConfigInfo.get("%s.removeCounters" % modulePrefix, "")
        subProps = getPropListDifferences(serverConfigInfo,modulePrefix, currentSettings, "pmiModule")
        if (len(subProps) > 0 or not isEmpty(newRemove)):
          currentEnable = currentSettings.get("pmiModule.prop.enable")
          newEnable = subProps.get("enable")
          if (newEnable == None):
            newEnable = ""
          
          if (newEnable.startswith("@RESET")):
            newRemove = "all"
            idx1 = newEnable.find("(")
            idx2 = newEnable.find(")")
            if (idx1 >= 0 and idx2 >= 0):
              newEnable = newEnable[idx1+1:idx2]
            else:
              newEnable = ""
              
            subProps["enable"] = newEnable

          if (newEnable != None and newEnable.startswith("@CLEAR")):
            
            newRemove = "all"
            idx1 = newEnable.find("(")
            idx2 = newEnable.find(")")
            if (idx1 >= 0 and idx2 >= 0):
              # Remove only specific counters
              newRemove = newEnable[idx1+1:idx2]
                
            newEnable = ""
            
          
          if (newRemove.lower() == "all"):
            # Remove all existing counters
            newRemove = currentEnable
            subProps["enable"] = ""
            if (newRemove == None):
              newRemove = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30"
          
          
         
          
          removeTokens = newRemove.split(",")
              
          # Compare the enable settings so we avoid removing existing settings          
          if (not isEmpty(newRemove) and newEnable == None):
            # handle case where only removeCounters is specified
            newEnable = ""
          
          enableTokens = []
          if (not isEmpty(newEnable)):
            enableTokens = newEnable.split(",")
          
          # Merge existing enabled counters into new enable value
          # Unles they are specified in the remove list
          if (newEnable != None and currentEnable):
            currentEnableTokens = currentEnable.split(",")
            for tempToken in currentEnableTokens:
              
              if (tempToken not in enableTokens and tempToken not in removeTokens):
                enableTokens.append(tempToken)
          
          
          # Build out new enable value
          newEnable = ""
          for tempToken in enableTokens:      
            if (newEnable == ""):
              newEnable = tempToken
            else:
              newEnable = "%s,%s" % (newEnable,tempToken)
                  
          subProps["enable"] = newEnable
          
          moduleId = currentSettings.get("pmiModule.CONFIG_ID")
          pmiAttrs = []
          for key in subProps.keys():
              pmiAttrs.append([key, subProps[key]])
          _app_debug("setupPMIModules before modifyObject newRemove=%s, removeTokens=%s, currentEnable=%s, newEnable=%s, ",newRemove,removeTokens,currentEnable,newEnable)
          if modifyObject(moduleId, pmiAttrs):
            _app_message("Failed to modify PMI module attributes for module %s appserver %s" % (moduleDescriptorKey,appserverName))
            exit()
          else:
            _app_message("Modified PMI module attributes for module %s appserver %s" % (moduleDescriptorKey,appserverName))
        else:
          _app_message("No need to modify PMI module attributes for module %s appserver %s" % (moduleDescriptorKey,appserverName))
      else:
        # Not existing, will have to create
        
        # Retrieve parent ID from dictionary
        if (parentDescriptor):
          parentSettings = pmiDescriptorDict.get( str(parentDescriptor), None)
          if (parentSettings):
            parentId = parentSettings.get("pmiModule.CONFIG_ID")
            
            newId = createPMIModule(parentId, moduleName, moduleType, modProps.get("enable"))
            
            _app_message("Create PMI module %s for appserver %s" % (moduleDescriptorKey,appserverName))
            
            # Add the PMI module to our dictionary
            tempSettings = {}
            for key in modProps.keys():
              tempSettings["pmiModule.prop.%s" % key] =  modProps.get(key)
              tempSettings["pmiModule.CONFIG_ID"] = newId
            
            pmiDescriptorDict[moduleDescriptorKey] = tempSettings
            pmiDescriptorDict[newId] = tempSettings
            
          else:
            _app_message("ERROR: Unable to locate PMI parent descriptor %s" % parentDescriptor)
            exit()
        else:
          # New Top level
          
          topModule = AdminConfig.list("PMIModule",pmiServiceId)
          newId = createPMIModule(topModule, moduleName, moduleType, modProps.get("enable"))
            
          _app_message("Created top-level PMI module %s for appserver %s" % (moduleDescriptorKey,appserverName))
            
          # Add the PMI module to our dictionary
          tempSettings = {}
          for key in modProps.keys():
            tempSettings["pmiModule.prop.%s" % key] =  modProps.get(key)
            tempSettings["pmiModule.CONFIG_ID"] = newId
            
          pmiDescriptorDict[moduleDescriptorKey] = tempSettings
          pmiDescriptorDict[newId] = tempSettings
        
      
      # See if there are child modules
      childCount = int(serverConfigInfo.get("%s.pmimodules.count" % modulePrefix, 0))
      if (childCount > 0):
        for childIdx in range(1,childCount+1):
          setupPMIModules(serverConfigInfo, "%s.pmimodules.%d" % (modulePrefix,childIdx),  appserverName, pmiDescriptorDict,moduleDescriptor, pmiServiceId)
      
    else:
      # Otherwise, incomplete list, no problemo
      pass
    
  except:
    _app_trace("Unexpected error in setupPMIModules","exception")
    exit()
    
  _app_trace("setupPMIModules()","exit")
  
#------------------------------------------------------------
# setupApplicationServerPMIModules
# 
# Set up the custom PMIModule configuration for the specified server.
# See the documentation at the top of the script for more details on PMI module settings.
#------------------------------------------------------------
def setupApplicationServerPMIModules(serverConfigInfo,serverId, pmiServiceId,prefix, appserverName, existingProps):
  _app_trace("setupApplicationServerPMIModules()","entry")
  try:
      # We'll always need to know current PMI tree
      pmiDescriptorDict = getPMIModulePropertiesForService(pmiServiceId)
      
      # Process top level PMI modules
      moduleCount  = int(serverConfigInfo.get("%s.pmiService.pmimodules.count" % prefix, 0))
      
      for modidx in range(1,moduleCount+1) :
        setupPMIModules(serverConfigInfo, "%s.pmiService.pmimodules.%d" % (prefix,modidx), appserverName, pmiDescriptorDict,[],pmiServiceId)
        
      
  except:
    _app_trace("Unexpected error in setupApplicationServerPMIModules","exception")
    exit()
    
  _app_trace("setupApplicationServerPMIModules()","exit")

#----------------------------------------------------------------------------------------------------
# setupApplicationServerPMI
#
# Process the settings for basic application server PMI settings and PMI modules
#
# See the documentation at the top of the script for more details on PMI module settings.
#----------------------------------------------------------------------------------------------------
def setupApplicationServerPMI(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  
  pmiServiceId = None
  
  # Set Logging properties
  if (existingProps != None):
    if (checkForPrefix(serverConfigInfo,"%s.pmiService" % (prefix))):
        getPMISettings(serverId, existingProps)
  
  subProps = getPropListDifferences(serverConfigInfo, "%s.pmiService" % (prefix), existingProps, "appserver.pmiService")
  if (len(subProps) > 0):
    pmiServiceId = AdminConfig.list('PMIService',serverId)
    if (not isEmpty(pmiServiceId)):
    
        pmiAttrs = []
          
        for key in subProps.keys():
            pmiAttrs.append([key, subProps[key]])

      
        if modifyObject(pmiServiceId, pmiAttrs):
          _app_message("Failed to modify PMI attributes for appserver %s" % (appserverName))
          exit()
        else:
          _app_message("Modified PMI attributes for appserver %s" % (appserverName))
        
        
  
  if (checkForPrefix(serverConfigInfo,"%s.pmiService.pmimodules" % (prefix))):
    if (not pmiServiceId):
      pmiServiceId = AdminConfig.list('PMIService',serverId)
    
    if (not isEmpty(pmiServiceId)):
      setupApplicationServerPMIModules(serverConfigInfo,serverId, pmiServiceId,prefix, appserverName, existingProps)
        
    
    
  

#enddef setupApplicationServerPMI


#----------------------------------------------------------------------------------------------------
# setupApplicationServerTraceService
#
# Process the trace service and trace log settings for a specific server
#----------------------------------------------------------------------------------------------------
def setupApplicationServerTraceService(serverConfigInfo,serverId, prefix, appserverName, existingProps):

  if (checkForPrefix(serverConfigInfo,"%s.processdef.traceService" % prefix)):
      traceServiceId = AdminConfig.list("TraceService",serverId)
      if (traceServiceId == "") :
          traceServiceId = AdminConfig.create("TraceService", serverId,[])
  else:
    _app_message("No trace service settings to process for appserver %s" % appserverName)
    return
  
  # Load existing properties for the Trace Service if this is an update to an existing server
  # and we are actually changing those properties
  if (existingProps != None):
      if (checkForPrefix(serverConfigInfo,"%s.processdef.traceService" % prefix)):
          getTraceServiceProperties(serverId,existingProps)
  
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.traceService"  % (prefix), existingProps, "appserver.processdef.traceService" )
  if (len(subProps) > 0) :
      
      traceServicePropAttrs = []
      for key in subProps.keys():
          traceServicePropAttrs.append([key, subProps[key]])
          
      if modifyObject(traceServiceId, traceServicePropAttrs):
          _app_message("Failed to modify trace service attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified trace service attributes for appserver %s" % (appserverName))
      
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.traceService.traceLog"  % (prefix), existingProps, "appserver.processdef.traceService.traceLog" )
  if (len(subProps) > 0):
      
      traceLogId = AdminConfig.showAttribute(traceServiceId,"traceLog")
      if (traceLogId == "") :
          traceLogId = AdminConfig.create("TraceLog",traceServiceId,[])
          
      traceLogPropAttrs = []
      for key in subProps.keys():
          traceLogPropAttrs.append([key, subProps[key]])
          
      if modifyObject(traceLogId, traceLogPropAttrs):
          _app_message("Failed to modify trace service log file attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified trace service log fileattributes for appserver %s" % (appserverName))
          
#enddef setupApplicationServerTraceService

#----------------------------------------------------------------------------------------------------
# setupApplicationServerRASLoggingService
#
# Process the activity log settings for a specific server
#----------------------------------------------------------------------------------------------------
def setupApplicationServerRASLoggingService(serverConfigInfo,serverId, prefix, appserverName, existingProps):

  if (checkForPrefix(serverConfigInfo,"%s.rasLoggingService" % prefix)):
      RASLoggingServiceId = AdminConfig.list("RASLoggingService",serverId)
      if (RASLoggingServiceId == "") :
          RASLoggingServiceId = AdminConfig.create("RASLoggingService", serverId,[])
  else:
    _app_message("No RASLoggingService settings to process for appserver %s" % appserverName)
    return
  
  # Load existing properties for the RASLogging Service if this is an update to an existing server
  # and we are actually changing those properties
  if (existingProps != None):
      if (checkForPrefix(serverConfigInfo,"%s.rasLoggingService" % prefix)):
          getRASLoggingServiceProperties(serverId,existingProps)
  
  subProps = getPropListDifferences(serverConfigInfo, "%s.rasLoggingService"  % (prefix), existingProps, "appserver.rasLoggingService" )
  if (len(subProps) > 0) :
      
      RASLoggingServicePropAttrs = []
      for key in subProps.keys():
          RASLoggingServicePropAttrs.append([key, subProps[key]])
          
      if modifyObject(RASLoggingServiceId, RASLoggingServicePropAttrs):
          _app_message("Failed to modify RASLoggingService attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified RASLoggingService attributes for appserver %s" % (appserverName))
  else:
    _app_message("No need to modify RASLoggingService attributes for appserver %s" % (appserverName))
      
  subProps = getPropListDifferences(serverConfigInfo, "%s.rasLoggingService.serviceLog"  % (prefix), existingProps, "appserver.rasLoggingService.serviceLog" )
  if (len(subProps) > 0):
      
      serviceLogId = AdminConfig.showAttribute(RASLoggingServiceId,"serviceLog")
      if (serviceLogId == "") :
          serviceLogId = AdminConfig.create("ServiceLog",RASLoggingServiceId,[])
          
      serviceLogPropAttrs = []
      for key in subProps.keys():
          serviceLogPropAttrs.append([key, subProps[key]])
          
      if modifyObject(serviceLogId, serviceLogPropAttrs):
          _app_message("Failed to modify RASLoggingService Service Log attributes for appserver %s" % (appserverName))
          exit()
      else:
          _app_message("Modified RASLoggingService Service Log attributes for appserver %s" % (appserverName))
  else:
    _app_message("No need to modify RASLoggingService Service Log attributes for appserver %s" % (appserverName))
    
          
#enddef setupApplicationServerRASLoggingService

#----------------------------------------------------------------------------------------------------
# setupApplicationServerHPELService
#
# Process the HPEL service and related log/trace settings for a specific server
#----------------------------------------------------------------------------------------------------
def setupApplicationServerHPELService(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  try:
    if (checkForPrefix(serverConfigInfo,"%s.hpeLoggingService" % prefix)):
        hpelId = None
        
        if (existingProps != None):
          
          hpelId = getHPELoggingServiceProperties(serverId,existingProps)
  
        # Call the utility method that will process the settings and modify the component and
        # subcomponents
        updatedProps = processStandardizedProperties(serverConfigInfo, "%s.hpeLoggingService" % prefix, existingProps, "appserver.hpeLoggingService",
                                    hpelId,
                                    serverId, None, "HighPerformanceExtensibleLogging",
                                    processSubItems=1,subItemSkipList=None,processCustomProperties=1)
        
        if (len(updatedProps) > 0):
          # We can check the returned keys to determine what was updated
          
          if (checkForPrefix(updatedProps,"%s.hpeLoggingService.prop." % prefix)):
            _app_message("Modified HighPerformanceExtensibleLogging base settings for application server %s" % appserverName)

          if (checkForPrefix(updatedProps,"%s.hpeLoggingService.properties" % prefix)):            
            _app_message("Modified HighPerformanceExtensibleLogging custom settings for application server %s" % appserverName)

          if (checkForPrefix(updatedProps,"%s.hpeLoggingService.hpelLog.prop" % prefix)):
            _app_message("Modified HighPerformanceExtensibleLogging log settings for application server %s" % appserverName)            

          if (checkForPrefix(updatedProps,"%s.hpeLoggingService.hpelTextLog.prop" % prefix)):
            _app_message("Modified HighPerformanceExtensibleLogging text Log settings for application server %s" % appserverName)

          if (checkForPrefix(updatedProps,"%s.hpeLoggingService.hpelTrace.prop" % prefix)):
            _app_message("Modified HighPerformanceExtensibleLogging trace file settings for application server %s" % appserverName)
          
        else:
          _app_message("No need to modify HighPerformanceExtensibleLogging settings for application server %s" % appserverName)
    else:
      _app_message("No HPEL service settings to process for appserver %s" % appserverName)
  except:
    _app_exception("Unexpected error in setupApplicationServerHPELService, serverId=%s prefix=%s" % (serverId,prefix))
    
#enddef setupApplicationServerHPELService

#----------------------------------------------------------------------------------------------------
# setupHTTPAccessLoggingService
#----------------------------------------------------------------------------------------------------
def setupHTTPAccessLoggingService(serverConfigInfo,serverId,prefix,appserverName,existingProps):
  try:
    if (checkForPrefix(serverConfigInfo,"%s.httpAccessLoggingService" % prefix)):
      
      targetId = None
      if (existingProps != None):
        targetId = getHTTPAccessLoggingServiceProperties(serverId,existingProps)
      
      # Call utility method that will process settings for this item and simple children
      updateProps = processStandardizedProperties(serverConfigInfo,"%s.httpAccessLoggingService" % prefix, existingProps, "appserver.httpAccessLoggingService",
                                  targetId, 
                                  serverId, parentAttribute=None, updateConfigurationType="HTTPAccessLoggingService",
                                  processSubItems=1,subItemSkipList=None)
      
      if (len(updateProps) > 0):
        _app_message("Modified HTTP Access Logging Service properties for server %s " % appserverName)
      else:
        _app_message("No need to modify HTTP Access Logging Service properties for server %s " % appserverName)
    
  except:
    _app_exception("Unexpected error in setupHTTPAccessLoggingService")

#----------------------------------------------------------------------------------------------------
# setupApplicationServerMonitoringPolicy
#
# Process the monitoring policy settings for a specific server
#----------------------------------------------------------------------------------------------------
def setupApplicationServerMonitoringPolicy(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps):

  # set monitoringpolicy
  if (existingProps != None):
    if (checkForPrefix(serverConfigInfo,"%s.processdef.monitoringpolicy" % prefix)):
        getMonitoringPolicyProperties(serverId, existingProps)  
  
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.monitoringpolicy"  % (prefix), existingProps, "appserver.processdef.monitoringpolicy" )
  if (len(subProps) > 0):
    monitoringPolicyId = AdminConfig.list("MonitoringPolicy", processId)
    monitoringPolicyAttrs = "["

    for key in subProps.keys():
      monitoringPolicyAttrs += "[%s %s]" % (key, subProps[key])

    monitoringPolicyAttrs += "]"
          
    if modifyObject(monitoringPolicyId, monitoringPolicyAttrs):
      _app_message("Failed to modify monitoring policy for appserver %s" % (appserverName))
      exit()
    else:
      _app_message("Modified monitoring policy for appserver %s" % (appserverName))

#enddef setupApplicationServerMonitoringPolicy
  

#----------------------------------------------------------------------------------------------------
# setupMessageListeningService
#
# Process the message listener service settings for a specific server
#----------------------------------------------------------------------------------------------------
def setupMessageListeningService(serverConfigInfo,serverId, prefix, appserverName, existingProps):
  # @JJM MessageListenerService and Listener Ports

  if (checkForPrefix(serverConfigInfo,"%s.messageListenerService" % prefix)):
    # We always need to check existing settings, in case template has LP settings
    if (existingProps == None):
      existingProps = {}
    
    getMessageListenerServiceProperties(serverId,existingProps)
  else:
    # No listener port settings to process
    _app_message("No listener port settings to process for server %s" % (appserverName))
    return
  
  mlsId = None
  subProps = getPropListDifferences(serverConfigInfo, "%s.messageListenerService"  % (prefix), existingProps, "appserver.messageListenerService" )
  if (len(subProps) > 0):
      mlsAttrs = []
      for key in subProps.keys():
        val = subProps[key]
        if (val != None and val != "None" and val != ""):
          mlsAttrs.append([key,val])
  
      mlsId = getMessageListenerService(serverId)
      if (modifyObject(mlsId, mlsAttrs)):
          _app_message("Failed to update MessageListenerService for appserver  %s" % (appserverName))
          exit()
      else:
          _app_message("Updated MessageListenerService for appserver  %s" % (appserverName))
            
  threadPoolProps = getPropListDifferences(serverConfigInfo, "%s.messageListenerService.threadPool"  % (prefix), existingProps, "appserver.messageListenerService.threadPool" )
  if (len(threadPoolProps) > 0):
          tpattrs = []
          for key in threadPoolProps.keys():
            val = threadPoolProps[key]
            if (val != None and val != "" and val != "None"):
              tpattrs.append([key,val])
              
          if (mlsId == None):
              #skipped above processing, get it now
              mlsId = getMessageListenerService(serverId)
              
          tpid = AdminConfig.list('ThreadPool',mlsId).split(progInfo['line.separator'])
          if ( len(tpid) == 0 or tpid[0] == ''):
              AdminConfig.create('ThreadPool',mlsId,tpattrs)
              _app_message("Created thread pool for MessageListenerService of server %s" % (appserverName))
          else:
              if (modifyObject(tpid[0], tpattrs)):
                  _app_message("Failed to modify thread pool for MessageListenerService of server %s" % (appserverName))
              else:
                  _app_message("Modified thread pool for MessageListenerService of server %s" % (appserverName))
      
  if serverConfigInfo.has_key("%s.messageListenerService.listenerPorts.count" % prefix):
      if (mlsId == None):
              #skipped above processing, get it now
              mlsId = getMessageListenerService(serverId)
      
      
      for lpidx in range(1, int(serverConfigInfo["%s.messageListenerService.listenerPorts.count" % (prefix)]) + 1):
          lpProps = getPropList(serverConfigInfo, "%s.messageListenerService.listenerPorts.%d" % (prefix, lpidx))
          existinglp = None
          if (len(lpProps) > 0 and existingProps != None):
        
              # Compare against existing LP props for the listener port with the same name
              lpname=lpProps.get("name")
              
              existinglp = getListenerPortWithName(serverId, lpname)
              if (not isEmpty(existinglp)):
                  # We'll need to compare settings to see if update is needed
                  existingLPprops = getListenerPortProperties(existinglp)
                  existingSubProps = getPropList(existingLPprops, "listenerPort")
                    
                  lpProps = getModifiedProperties(lpProps, existingSubProps)
                  if (len(lpProps) > 0):
                      # Apply just the modified properties
                      lpAttrs = []
                      for key in lpProps.keys():
                          val = lpProps[key]
                          if (val != None and val != "None" and val != ""):
                              lpAttrs.append([key,val])
                        
                      if (modifyObject(existinglp, lpAttrs)):
                          _app_message("Failed to modify ListenerPort %s for MessageListenerService of server %s" % (lpname,appserverName))
                      else:
                          _app_message("Modified ListenerPort %s for MessageListenerService of server %s" % (lpname,appserverName))
                            
                  # Now need to modify state management settings for listener port
                                      
                  stateProps = getPropList(serverConfigInfo, "%s.messageListenerService.listenerPorts.%d.stateManageable" % (prefix, lpidx))
                  existingStateProps = getPropList(existingLPprops, "listenerPort.stateManageable")
                  stateProps = getModifiedProperties(stateProps, existingStateProps)
                  if (len(stateProps) > 0): 
                      stateAttrs = []
                      for key in stateProps.keys():
                          val = stateProps[key]
                          if (val != None and val != "None" and val != ""):
                              stateAttrs.append([key,val])
                      smid = AdminConfig.list('StateManageable',existinglp).split(progInfo['line.separator'])
                      if (smid != None and len(smid) > 0 and smid[0] != ''):
                          if (modifyObject(smid[0], stateAttrs)):
                                _app_message("Failed to update ListenerPort state for server %s Listener Port %s" %(appserverName, lpname))
                          else:
                                _app_message("Updated StateManageable settings for Listener Port %s in server %s" % (appserverName, lpname))
                      else:
                          smid = AdminConfig.create('StateManageable',existinglp, stateAttrs)
            
                        

          # end if existing listener port
            
          # If we didn't update existing listener port, create one now        
          if (len(lpProps) > 0 and isEmpty(existinglp)):
              lpAttrs = []
              for key in lpProps.keys():
                val = lpProps[key]
                if (val != None and val != "None" and val != ""):
                    lpAttrs.append([key,val])
              
              lpID = AdminConfig.create('ListenerPort', mlsId, lpAttrs)
              
              stateProps = getPropList(serverConfigInfo, "%s.messageListenerService.listenerPorts.%d.stateManageable" % (prefix, lpidx))
              if (len(stateProps) > 0):
                  stateAttrs = []
                  for key in stateProps.keys():
                      val = stateProps[key]
                      if (val != None and val != "None" and val != ""):
                        stateAttrs.append([key,val])
              
                  smid = AdminConfig.list('StateManageable',lpID).split(progInfo['line.separator'])
                  if (smid != None and len(smid) > 0 and smid[0] != ''):
                      if (modifyObject(smid[0], stateAttrs)):
                          _app_message("Failed to update ListenerPort state for server % Listener Port %s" %(appserverName, lpAttrs))
                  else:
                      smid = AdminConfig.create('StateManageable',lpID, stateAttrs)
              
              _app_message("Created listener port for server %s %s" %(appserverName, lpAttrs))
          # end if new listener port    
      
      # end for each listener port        

#enddef setupMessageListeningService

#----------------------------------------------------------------------------------------------------
# stripSurroundingQuotes
#----------------------------------------------------------------------------------------------------
def stripSurroundingQuotes(arg1):

    if (arg1 == None):
        return arg1

    result = arg1
    if (arg1.find('"') == 0):
        result = arg1[1:]
        
        if (result[-1] == '"'):
            result = result[:-1]
    
    
    return result
            
        

#----------------------------------------------------------------------------------------------------
# combineGenericJvmArguments
#
# This method will combine new genericJVMArguments with existing settings. After the initial
# combination, it processes the special genericJvmArguments rules for settings that are 
# replacements for previous values.
#
#----------------------------------------------------------------------------------------------------
def combineGenericJvmArguments(serverConfigInfo,existingGenericJVMSettings,newGenericJVMSettings, prefix):
    
    if (existingGenericJVMSettings == None):
        existingGenericJVMSettings = ""
    else:
        existingGenericJVMSettings = stripSurroundingQuotes(existingGenericJVMSettings)

    
    if (newGenericJVMSettings == None):
        newGenericJVMSettings = ""
    else:
        newGenericJVMSettings = stripSurroundingQuotes(newGenericJVMSettings)
        
    combinedSettings = existingGenericJVMSettings
        
    newList = newGenericJVMSettings.split()
    for arg in newList:
        pos = combinedSettings.find(arg)
        if (pos >= 0):
            continue
        else:
            if (len(combinedSettings) == 0):
                combinedSettings = arg
            else:
                combinedSettings += " " + arg
    
    
    # Now we need to see if individual properties are found
    if (serverConfigInfo.has_key("%s.processdef.jvm.genericJvmArguments.count" % prefix) ):
        idx = 0
        maxargs = int(serverConfigInfo["%s.processdef.jvm.genericJvmArguments.count" % prefix]);
        processingArgs="true"
        while (processingArgs == "true" and idx < maxargs):
            idx += 1
            newArg = ""
            replacesArg = ""
            skipArg = ""
            removeArg = ""
            
            if (serverConfigInfo.has_key("%s.processdef.jvm.genericJvmArguments.%d.removeArg" % (prefix, idx))):
                # If this value is defined, then newArg is blank and replacesArg is set to the value of removeArg
                newArg = ""
                replacesArg = stripSurroundingQuotes(serverConfigInfo["%s.processdef.jvm.genericJvmArguments.%d.removeArg" % (prefix, idx)])
                removeArg = replacesArg
            elif (serverConfigInfo.has_key("%s.processdef.jvm.genericJvmArguments.%d.newArg" % (prefix, idx))):
                newArg = stripSurroundingQuotes(serverConfigInfo["%s.processdef.jvm.genericJvmArguments.%d.newArg" % (prefix, idx)])
                newArg = substituteDynamicValues("newArg",newArg)
            else:
                # There may be a partial list
                continue
            
            if (serverConfigInfo.has_key("%s.processdef.jvm.genericJvmArguments.%d.replacesArg" % (prefix, idx))):
                replacesArg = stripSurroundingQuotes(serverConfigInfo["%s.processdef.jvm.genericJvmArguments.%d.replacesArg" % (prefix, idx)])
            
            if (serverConfigInfo.has_key("%s.processdef.jvm.genericJvmArguments.%d.skipIfArgExists" % (prefix, idx))):
                skipArg = stripSurroundingQuotes(serverConfigInfo["%s.processdef.jvm.genericJvmArguments.%d.skipIfArgExists" % (prefix, idx)])
                
            # See if this argument should be skipped due to an existing setting
            if (not isEmpty(skipArg)):
                pos = combinedSettings.find(skipArg)
                if (pos >= 0):
                    # We won't process this setting
                    continue

            # See if this argument should be skipped due to an existing identical setting to new argument
            # (as long as we aren't doing a remove)
            if (not isEmpty(newArg)):
                pos = combinedSettings.find(newArg)
                if (pos >= 0):
                    # We won't process this setting
                    continue
                    
            
            # See if a current setting needs to be replaced
            updatedSettings = ""
            replacementFound = "false"
            if (not isEmpty(replacesArg)):
                pos = combinedSettings.find(replacesArg)
                if (pos >= 0):
                    
                    combinedSettingsList = combinedSettings.split()
                    for arg in combinedSettingsList:
                        appendArg = arg
                        if (arg.find(replacesArg) == 0):
                            
                            appendArg = newArg
                            replacementFound = "true"
                    
                        if (updatedSettings == ""):
                            updatedSettings = appendArg
                        else:
                            updatedSettings += " " + appendArg
            
            # If no replacement was made, add new setting to end of combined list
            if (replacementFound == "true"):
                combinedSettings = updatedSettings
            else:
                if (combinedSettings == ""):
                    combinedSettings = newArg
                else:
                    combinedSettings += " " + newArg
            
            
        # end while
        
    # end if listed args exist
      
    return combinedSettings.strip()

#enddef combineGenericJvmArguments

#----------------------------------------------------------------------------------------------------
# setupApplicationServerJavaVirtualMachine
#
# Process the JavaVirtualMachine settings for a specific server, including the system properties
#----------------------------------------------------------------------------------------------------
def setupApplicationServerJavaVirtualMachine(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps,overrideSettings=0):  

  JVMId = None
  
  if (overrideSettings):
      JVMId = AdminConfig.list("JavaVirtualMachine", processId)
      removeAllCustomProperties(JVMId, "systemProperties")
      
      if modifyObject(JVMId,[ ["genericJvmArguments", ""]]):
          _app_message("Unable to clear genericJvmArguments for server %s" % appserverName)
          exit()
      
      
      
  # We need to load existing props even for new servers so we can merge with
  # settings from template
  if (checkForPrefix(serverConfigInfo,"%s.processdef.jvm"%prefix)):
    if (existingProps == None):
      existingProps = {}
      
    # load jvm properties into the existingProps
    JVMId = getJavaVirtualMachineProperties(serverId,existingProps,processId)
  else:
    # No settings to process
    _app_message("No need to modify base JVM settings or system settings for appserver %s" % (appserverName)) 
    return
          
  # set processdef jvm properties
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.jvm"  % (prefix), existingProps, "appserver.processdef.jvm" )
  if (subProps.get("genericJvmArguments") != None or serverConfigInfo.has_key("%s.processdef.jvm.genericJvmArguments.count" % prefix)):
    
    newGenericJVMSettings=subProps.get("genericJvmArguments")
    
    if (existingProps != None):
        existingGenericJVMSettings = stripSurroundingQuotes(existingProps.get("appserver.processdef.jvm.prop.genericJvmArguments"))
    else:
        existingGenericJVMSettings = ""
        
    combinedGenericJvmArguments = combineGenericJvmArguments(serverConfigInfo,existingGenericJVMSettings,newGenericJVMSettings, prefix)
    
    if (combinedGenericJvmArguments != existingGenericJVMSettings):
        _app_message("genericJVMarguments are being updated")
      
        
        quotedString = '"'+combinedGenericJvmArguments+'"'
        
        subProps.put("genericJvmArguments",quotedString)
    else:
        #identical - don't process genericJVMSettings
        subProps.remove("genericJvmArguments")
    
    
  if (len(subProps) > 0): 
    # JVMId = AdminConfig.list("JavaVirtualMachine", processId)
    
    # Special handling for classpaths
    if (existingProps != None):
    
      jvmClasspath = subProps.get("classpath");
      if (not isEmpty(jvmClasspath)):
          # Erase existing
          JVMAttrs = [["classpath", ""]]
          if modifyObject(JVMId, JVMAttrs):
            _app_message("Failed to clear jvm classpath properties for appserver %s '%s'" % (appserverName, JVMAttrs))
            exit()
            
      jvmBootClasspath = subProps.get("bootClasspath")
      if (not isEmpty(jvmBootClasspath)):
          # Erase existing
          JVMAttrs = [["bootClasspath", ""]]
          if modifyObject(JVMId, JVMAttrs):
            _app_message("Failed to clear jvm boot classpath properties for appserver %s '%s'" % (appserverName, JVMAttrs))
            exit()
    
    JVMAttrs = "["

    for key in subProps.keys():
      JVMAttrs += "[%s %s]" % (key, subProps[key])

    JVMAttrs += "]"
    
        
    if modifyObject(JVMId, JVMAttrs):
      _app_message("Failed to set jvm properties for appserver %s '%s'" % (appserverName, JVMAttrs))
      exit()
    else:
      _app_message("Modified jvm properties for appserver %s" % (appserverName))
      
  else:
    _app_message("No need to modify base JVM settings for appserver %s" % (appserverName)) 

  # set jvm system properties
  subProps = getPropListDifferences(serverConfigInfo, "%s.processdef.jvm.sys" % (prefix), existingProps, "appserver.processdef.jvm.sys")
  if (len(subProps) > 0):
    #JVMId = AdminConfig.list("JavaVirtualMachine", processId)
    
    errmsg = updateCustomProperties(JVMId, "systemProperties", "Property", subProps)
    if (not isEmpty(errmsg)):
        _app_message("Failed to set jvm systemProperties for appserver %s %s" % (appserverName, errmsg))
        exit()
    else:
        _app_message("Modified jvm systemProperties for appserver %s" % (appserverName))
  else:
    _app_message("No JVM system properties to update for appserver %s" % appserverName)
#enddef setupApplicationServerJavaVirtualMachine

#----------------------------------------------------------------------------------------------------
# setupApplicationServerProcessExecution
#
# Process the ProcessExecution settings for a specific server, including the system properties
#----------------------------------------------------------------------------------------------------
def setupApplicationServerProcessExecution(serverConfigInfo,serverId, prefix, appserverName, existingProps):  
  _app_trace("setupApplicationServerProcessExecution()","entry")
  
  if (checkForPrefix(serverConfigInfo,"%s.processExecution" % prefix)):
    if (existingProps != None):
      _app_trace("found prefix.. call getProcessExcecutionSettings()","debug")
      getProcessExcecutionSettings(serverId, existingProps)
  
    # set processExecution properties
    subProps = getPropListDifferences(serverConfigInfo, "%s.processExecution"  % (prefix), existingProps, "appserver.processExecution" )
    if (len(subProps) > 0):
      execId = AdminConfig.list("ProcessExecution", serverId)
      execAttrs = []
  
      for key in subProps.keys():
        execAttrs.append([key,subProps[key]])
  
      if modifyObject(execId, execAttrs):
        _app_message("Failed to set jvms ProcessExecution properties for appserver %s '%s'" % (appserverName, execAttrs))
        exit()
      else:
        _app_message("Modified jvm ProcessExecution properties for appserver %s" % (appserverName))
    else:
      _app_message("No need to modify ProcessExecution for appserver %s" % (appserverName) )
      
  #endif input properties  
  
  _app_trace("setupApplicationServerProcessExecution()","exit")
      
#enddef setupApplicationServerProcessExecution

#----------------------------------------------------------------------------------------------------
# setupApplicationServerTransactionService
#
# Process the TransactionService settings for a specific server, including the custom properties
#----------------------------------------------------------------------------------------------------
def setupApplicationServerTransactionService(serverConfigInfo,serverId, prefix, appserverName, existingProps, overrideSettings=0):  

  if (overrideSettings):
      txnServiceId = AdminConfig.list("TransactionService",serverId)
      removeAllCustomProperties(txnServiceId, "properties")


  # Get the properties for the existing server if necessary
  if (existingProps != None):
      if (checkForPrefix(serverConfigInfo,"%s.transactionService" % prefix)):
          getTransactionServiceProperties(serverId,existingProps)
      
  # TransactionService Support
  subProps = getPropListDifferences(serverConfigInfo, "%s.transactionService" % prefix, existingProps, "appserver.transactionService")
  if (len(subProps) > 0):
      txnServiceId = AdminConfig.list("TransactionService",serverId)
      txnServiceAttrs = []
      for key in subProps.keys():
          txnServiceAttrs.append([key, subProps[key]])
      
      if modifyObject(txnServiceId, txnServiceAttrs):
          _app_message("Failed to set TransactionService properties for appserver $s '%s'" % (appserverName, txnServiceAttrs))
          exit()
      else:
          _app_message("Modified TransactionService properties for appserver %s " % (appserverName))
  
  # Check for transaction service custom properties
  subProps = getPropListDifferences(serverConfigInfo, "%s.transactionService.customProperties" % prefix, existingProps, "appserver.transactionService.customProperties")
  if (len(subProps) > 0):
      txnServiceId = AdminConfig.list("TransactionService",serverId)
      errMsg = updateCustomProperties(txnServiceId, "properties", "Property", subProps)
      if (not isEmpty(errMsg)):
          _app_message("Failed to updated custom properties on TransactionService for appserver %s : %s" % (appserverName, errMsg))
          exit()
      else:
          _app_message("Modified TransactionService custom properties for appserver %s" % (appserverName))
            
#enddef setupApplicationServerTransactionService

#-------------------------------------------------------------------------------
# setupApplicationServerAdminServices
#-------------------------------------------------------------------------------
def setupApplicationServerAdminServices(serverConfigInfo,serverId, prefix, appserverName, existingProps=None):
  _app_trace("setupApplicationServerAdminServices(%s,%s,%s,existingProps)" % (serverId, prefix, appserverName),"entry")
  try:
    # Get the current properties (no need to check if preexisting or not)
    if (checkForPrefix(serverConfigInfo,"%s.adminService" % prefix)):
      # Do AdminService processing
      
      # Get the current properties (no need to check if preexisting or not)
      if (existingProps == None):
        existingProps = {}
      
      
      collectedIds = {}
      getAdminServicesProperties(serverId,existingProps,1,collectedIds)
      
      adminServiceId = collectedIds.get("appserver.adminService.id")
      connectors = collectedIds.get("appserver.adminService.prop.connectors")
      
      #print "%s\n%s" % (adminServiceId,connectors)
      
      # Now lets see what we need to update
      adminServiceProps = getPropListDifferences(serverConfigInfo, "%s.adminService" % prefix, existingProps, "appserver.adminService")
      adminServiceCustomProps = getPropListDifferences(serverConfigInfo, "%s.adminService.properties" % prefix, existingProps, "appserver.adminService.properties")
      
      soapProps = None
      rmiProps = None
      jsr160Props = None
      ipcProps = None
      
      connectorPropsCollection = {}
      
      connectorCount = int(serverConfigInfo.get("%s.adminService.connectors.count" % prefix,"0"))
      for cidx in range(1,connectorCount+1):
        connectorType = serverConfigInfo.get("%s.adminService.connectors.%d.type" % (prefix,cidx),"")
        if (isEmpty(connectorType)):
          continue
        
        # Determine the existing properties index for this connector
        # And then store the properties that need to be updated in our dictionary
        existingCount = int(existingProps.get("appserver.adminService.connectors.count"))
        for eidx in range(1,existingCount+1):
          existingType = existingProps.get("appserver.adminService.connectors.%d.type"%eidx)
          if (existingType == connectorType):
            modifiedProps = getPropListDifferences(serverConfigInfo, "%s.adminService.connectors.%d.properties" % (prefix,cidx), existingProps, "appserver.adminService.connectors.%d.properties"%eidx)
            connectorPropsCollection[connectorType] = modifiedProps
            break
        
      soapProps = connectorPropsCollection.get("SOAPConnector",{})
      rmiProps = connectorPropsCollection.get("RMIConnector",{})
      jsr160Props = connectorPropsCollection.get("JSR160RMIConnector",{})
      ipcProps = connectorPropsCollection.get("IPCConnector",{})
      
      needUpdate = 0
      if (len(soapProps) > 0 or len(rmiProps) > 0 or len(jsr160Props) > 0 or len(ipcProps) > 0):
        needUpdate = 1
      elif (len(adminServiceProps) > 0 or len(adminServiceCustomProps) > 0):
        needUpdate = 1
      
      if (not needUpdate):
        _app_message("No need to update AdminService propeties for server %s" % appserverName)
      else:
        updateAdminServiceConnectorProperties(serverId, adminServiceProps.get("remoteAdminProtocol"), adminServiceProps.get("localAdminProtocol"),adminServiceId, connectors, adminServiceCustomProps, soapProps,rmiProps,jsr160Props,ipcProps)
        _app_message("Updated AdminService for server %s" % appserverName)
        
          
          
     
  except:
    _app_trace("Unexpected error in setupApplicationServerAdminServices","exception")
    exit()
    
  _app_trace("setupApplicationServerAdminServices(%s,%s,existingProps)","exit")

#enddef setupApplicationServerAdminServices


#--------------------------------------------------------------------------
# setupApplicationServerPorts
#   - Processes the serverEntry.namedEndPoints definitions
# 
#--------------------------------------------------------------------------
def setupApplicationServerPorts(serverConfigInfo,nodeName,serverName,prefix):
  _app_entry("setupApplicationServerPorts(serverConfigInfo,%s,%s,%s)",nodeName,serverName,prefix)
  try:
    namedEntryCount = int(serverConfigInfo.get("%s.serverEntry.namedEndPoints.count"% prefix,0))
    
    if (namedEntryCount > 0):
      # 
      # We are very careful about port assignments, make sure meta property is tru
      processPorts = serverConfigInfo.get("%s.serverEntry.processNamedEndPoints"%prefix,"false").lower()
      
      if (processPorts in ["true","yes"]):
            
        # Call the utility that returns a directory of existing named port values
        # and their configuration IDs
        existingEndPointDict = getNamedEndPoints(nodeName,serverName)
        
        # Parse the input and store it in format that we can compare
        # against the existing one
        for idx in range(1,namedEntryCount+1):
          endPointPrefix = "%s.serverEntry.namedEndPoints.%d" % (prefix,idx)
          
          endPointName = serverConfigInfo.get("%s.name" % (endPointPrefix))
          if (isEmpty(endPointName)):
            # Partial list
            continue
            
          inputPort = serverConfigInfo.get("%s.endPoint.prop.port" % endPointPrefix)
          inputHost = serverConfigInfo.get("%s.endPoint.prop.host" % endPointPrefix)
          
          existingValues = existingEndPointDict.get(endPointName)
          existingEndPointId = existingEndPointDict.get("%s.ENDPOINT_CONFIG_ID" % endPointName)
          
          if (isEmpty(existingEndPointId)):
            _app_message("Endpoint %s is not defined for server %s/%s" % (endPointName,nodeName,serverName))
          else:
            existingHost = existingValues[0]
            existingPort = existingValues[1] 
            
            if (isEmpty(inputPort)):
              inputPort = existingPort
            if (isEmpty(inputHost)):
              inputHost = existingHost
            
            if (inputPort == existingPort and inputHost == existingHost):
              _app_message("No need to update named endpoint %s on server %s/%s" % (endPointName,nodeName,serverName))
            else:
              
              attrs = []
              if (inputPort != existingPort):
                attrs.append(["port",inputPort])
              if (inputHost != existingHost):
                attrs.append(["host",inputHost])
              
              if (modifyObject(existingEndPointId,attrs)):
                raise StandardError("Unable to update %s on server %s/%s" % (endPointName,nodeName,serverName))
              else:
                _app_message("Updated named endpoint %s (%s,%s) on server %s/%s" % (endPointName,inputPort,inputHost,nodeName,serverName))
          
  except:
    _app_exception("Unexpected error in setupApplicationServerPorts")
    
  _app_exit("setupApplicationServerPorts()")
#enddef setupApplicationServerPorts


#-------------------------------------------------------------------------------
# setupApplicationServerCEASettings
#
# Parameters
#
#-------------------------------------------------------------------------------
def setupApplicationServerCEASettings(serverConfigInfo,serverId,prefix,appserverName,existingProps):
  _app_entry("setupApplicationServerCEASettings(serverConfigInfo,%s,%s,%s,existingProps)" , serverId,prefix,appserverName)
  retval = None
  try:
    if (checkForPrefix(serverConfigInfo,"%s.CEASettings"%prefix)):
      ceaSettingsId = None
      if (existingProps != None):
        getCEASettingsProperties(parentId=serverId,appServerProperties=existingProps)
        ceaSettingsId = existingProps.get("CEASettings.CONFIG_ID")
      
      # See if there are settings to process - becomes no-op if existingProps is empty
      baseProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings"%prefix,existingProps,"CEASettings")
      customProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.properties"%prefix,existingProps,"CEASettings.properties")
      commsvcProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.commsvc"%prefix,existingProps,"CEASettings.commsvc")
      commsvcCustomProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.commsvc.properties"%prefix,existingProps,"CEASettings.commsvc.properties")
      ctiGatewayProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.ctiGateway"%prefix,existingProps,"CEASettings.ctiGateway")
      ctiGatewayCustomProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.ctiGateway.properties"%prefix,existingProps,"CEASettings.ctiGateway.properties")
      
      if (len(baseProps) > 0 or len(customProps) > 0 or
          len(commsvcProps) > 0 or len(commsvcCustomProps) > 0 or
          len(ctiGatewayProps) > 0 or len(ctiGatewayCustomProps) > 0):
            
        updateCEASettings(parentId=serverId, ceaSettingsId=ceaSettingsId,
                          ceaProps=baseProps,ceaCustomProps=customProps,
                          commsvcProps=commsvcProps,commsvcCustomProps=commsvcCustomProps,
                          ctiGatewayProps=ctiGatewayProps,ctiGatewayCustomProps=ctiGatewayCustomProps)
        
        _app_message("Updated CEASettings for server %s" % appserverName)
      else:
        _app_message("No need to update CEASettings for server %s" % appserverName)
      
  except:
    _app_exception("Unexpected problem in setupApplicationServerCEASettings()")
  
  _app_exit("setupApplicationServerCEASettings(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# setupApplicationServerWorkAreaService
#-------------------------------------------------------------------------------
def setupApplicationServerWorkAreaService(serverConfigInfo,serverId,prefix,appserverName, existingProps):
  _app_entry("setupApplicationServerWorkAreaService(serverConfigInfo,%s,%s,%s,existingProps)" , serverId,prefix,appserverName)
  retval = None
  try:
    workAreaServiceId = None
    
    if (checkForPrefix(serverConfigInfo,"%s.workAreaService"%prefix)):
      
      workAreaServiceId = None
      
      if (existingProps != None):
        getWorkAreaServiceProperties(serverId,existingProps)
        workAreaServiceId = existingProps.get("workAreaService.CONFIG_ID")
      
      baseProps = getPropListDifferences(serverConfigInfo,"%s.workAreaService"%prefix,existingProps,"workAreaService")
      customProps = getPropListDifferences(serverConfigInfo,"%s.workAreaService.properties"%prefix,existingProps,"workAreaService.properties")
      
      if (len(baseProps) > 0 or len(customProps) > 0):
        # Need to do update
        updateWorkAreaServiceProperties(serverId=serverId,workAreaServiceId=workAreaServiceId,baseProps=baseProps,customProps=customProps)
        _app_message("Updated WorkAreaService for application server %s" % appserverName)
      else:
        _app_message("No updates requrired for WorkAreaService in application server %s" % appserverName)
      
  except:
    _app_exception("Unexpected problem in setupApplicationServerWorkAreaService()")
  
  _app_exit("setupApplicationServerWorkAreaService(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# setupApplicationServerWorkAreaPartitionService
#-------------------------------------------------------------------------------
def setupApplicationServerWorkAreaPartitionService(serverConfigInfo,serverId,prefix,appserverName,existingProps):
  _app_entry("setupApplicationServerWorkAreaPartitionService(serverConfigInfo,%s,%s,%s,existingProps)" , serverId,prefix,appserverName)
  retval = None
  try:
    wapServiceId = None
    existingPartitionPrefixMap = {}
    
    if (checkForPrefix(serverConfigInfo,"%s.workAreaPartitionService" % prefix)):
      if (existingProps != None):
        getWorkAreaPartitionServiceProperties(serverId,existingProps)
        wapServiceId = existingProps.get("workAreaPartitionService.CONFIG_ID")
      
        existingPartitionPrefixMap = buildNameToPrefixMap(existingProps,"workAreaPartitionService.partitions","prop.name")


    baseProps = getPropListDifferences(serverConfigInfo,"%s.workAreaPartitionService" % prefix, existingProps, "workAreaPartitionService")
    
    if (len(baseProps) > 0):
      wapServiceId = updateWorkAreaPartitionService(serverId=serverId,wapServiceId=wapServiceId,baseProps=baseProps)
      _app_message("Updated base properties of WorkAreaPartitionService for application server %s" % appserverName)
    

    partitionCount = int(serverConfigInfo.get("%s.workAreaPartitionService.partitions.count"%prefix,0))
    if (partitionCount > 0):
      for idx in range(1,partitionCount+1):
        partitionName = serverConfigInfo.get("%s.workAreaPartitionService.partitions.%d.name" % (prefix,idx))
        if (isEmpty(partitionName)):
          continue
        
        existingPrefix = existingPartitionPrefixMap.get(partitionName)
        
        if (isEmpty(existingPrefix)):
          baseProps = getPropList(serverConfigInfo,"%s.workAreaPartitionService.partitions.%d"%(prefix,idx))
          customProps = getPropList(serverConfigInfo,"%s.workAreaPartitionService.partitions.%d.properties"%(prefix,idx))
          createWorkAreaPartition(partitionName,baseProps,customProps,serverId=serverId,wapServiceId=wapServiceId)
          _app_message("Created work area partition %s for application server %s" % (partitionName,appserverName))
        else:
          baseProps = getPropListDifferences(serverConfigInfo,"%s.workAreaPartitionService.partitions.%d"%(prefix,idx),existingProps,existingPrefix)
          customProps = getPropListDifferences(serverConfigInfo,"%s.workAreaPartitionService.partitions.%d.properties"%(prefix,idx),existingProps,"%s.properties"%existingPrefix)

          if (len(baseProps)  > 0 or len(customProps) > 0):
            modifyWorkAreaPartition(wapName=partitionName,baseProps=baseProps,customProps=customProps,serverId=serverId)
            _app_message("Updated work area partition %s on server %s" % (partitionName,appserverName))
          else:
            _app_message("No updates required work area partition %s on server %s" % (partitionName,appserverName))
  except:
    _app_exception("Unexpected problem in setupApplicationServerWorkAreaPartitionService()")
  
  _app_exit("setupApplicationServerWorkAreaPartitionService(retval=%s)" % retval)
  return retval
  



#-------------------------------------------------------------------------------
# setupApplicationServerCompensationService
#
# Parameters
#   serverConfigInfo - dictionary with input configuration properties
#   serverId - configuration ID of object to be configured. Could be a server
#              or a template
#   prefix - prefix of properties to be used
#   appserverName - Name of server (used for logging primarily)
#   existingProps - if server already existed when script was launched, 
#                   this is the property representation of the current props. If
#                   server was just created, this will be null
#-------------------------------------------------------------------------------
def setupApplicationServerCompensationService(serverConfigInfo,serverId,prefix,appserverName,existingProps):
  _app_entry("setupApplicationServerCompensationService(serverConfigInfo,%s,%s,existingProps)" , serverId,prefix)
  retval = None
  try:
    compensationServiceId = None
    
    # See if there are any properties in the input dictionary for defining a 
    # CompensationService
    if (checkForPrefix(serverConfigInfo,"%s.compensationService" % prefix)):
      
      # Get the current configuration ID - if it exists
      
      ########
      # LAB INSERTION POINT
      #
      # Call the method in ApplicationServer.py that looks up the 
      # Configuration ID for the CompensationService
      # 
      #  compensationServiceId = ....
      
      
      #
      # END INSERTION POINT
      ###########
      
      
      if (existingProps != None):
                
        # Call the function that will collect the current settings of the service
        # Will be a no-op if compensation service is not defined
        
        ##############
        # LAB INSERTION POINT
        # 
        # Call appropriate funtion in ApplicationServer.py
        #
        # Replace pass with code
        pass
        
        
        # END INSERTION POINT
        ##############
        
      #endif existingProps defined
      
      
      # If existingProps is defined, the calling getPropListDifferences
      # will determine if the base or custom properties have changed from 
      # current configuration
      #
      # If existingProps==None, then these method calls will simply return the
      # input properties
      baseProps = getPropListDifferences(serverConfigInfo,"%s.compensationService"%prefix,
                                         existingProps,"compensationService")
                                         
      customProperties = getPropListDifferences(serverConfigInfo,"%s.compensationService.properties"%prefix,
                                                 existingProps,"compensationService.properties")
      
      # If there settings to be applied, update (or create) the compensation service
      if (len(baseProps) > 0 or len(customProperties) > 0):
        if (isEmpty(compensationServiceId)):
          # Call the function that will create the compensation service
          
          #####################
          # LAB INSERTION POINT
          #
          # Call the method in ApplicationServer.py that creates a CompensationService configuration
          
          
          
          # END INSERTION POINT
          ####################
          
          _app_message("Created CompensationService on server %s" % appserverName)
        else:
          # Call the function that will update existing service
          
          ###############
          # LAB INSERTION POINT
          #
          # Call the update method for the compensation service
          

          # END INSERTION POINT
          ################
  
          _app_message("Modified CompensationService on server %s" % appserverName)
      else:
        _app_message("No updates necessary for CompensationService on server %s" % appserverName)
    
        
  except:
    _app_exception("Unexpected problem in setupApplicationServerCompensationService()")
  
  _app_exit("setupApplicationServerCompensationService(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# setupApplicationServerRecoveryLog
#    If RecoveryLog settings for a specific server/template are in the input
#    dictionary, they will be processed and applied to the system configuration
#
# Parameters
#   serverConfigInfo - dictionary with input configuration properties
#   serverId - configuration ID of object to be configured. Could be a server
#              or a template
#   prefix - prefix of properties to be used
#   appserverName - Name of server (used for logging primarily)
#   existingProps - if server already existed when script was launched, 
#                   this is the property representation of the current props. If
#                   server was just created, this will be null

#-------------------------------------------------------------------------------
def setupApplicationServerRecoveryLog(serverConfigInfo,serverId,prefix,appserverName,existingProps):
  _app_entry("setupApplicationServerRecoveryLog(serverConfigInfo,%s,%s,%s,existingProps)" , serverId,prefix,appserverName)
  retval = None
  try:
    # See if there are any properties in the input dictionary for defining a 
    # RecoveryLog
    if (checkForPrefix(serverConfigInfo,"%s.recoveryLog" % prefix)):
      
      # Determine if we are processing a server or cluster/dynamicCluster template
      # This is needed to determine location of serverindex.xml file that holds
      # the recoverylog settings
      nodeName,clusterName,dynamicClusterName = parseNodeClusterDynamic(serverId)
      
      # Get the configuration ID of the recovery log - may be undefined
      recoveryLogId = None
      
      #####
      #  LAB INSERTION POINT
      #
      #  Call the utility function from ApplicationServer.py and 
      #  recoveryLogId = get......
      #
      
      
      #
      #  End LAB INSERTION POINT
      ########
      
      if (existingProps != None and not isEmpty(recoveryLogId)):
        
        # Load the properties for the RecoveryLog into our collection of
        # existing properties
        
        ######
        #  LAB INSERTION POINT
        #
        
        
        #  END LAB INSERTION POINT
        #############
        
        # Compare input properties against existing and get a dictionary
        # with just the updated properties 
        baseProps = getPropListDifferences(serverConfigInfo,"%s.recoveryLog" % prefix,
                                            existingProps,"recoveryLog")
                                            
        if (len(baseProps) > 0):
          
          # Call the update method for the recovery log
          
          ###########
          # LAB INSERTION POINT
          #
          # Call the method in ApplicationServer.py
          
          
          # END LAB INSERTION POINT
          #######
          
          _app_message("Updated RecoveryLog for appserver %s" % appserverName)
          
          
      else:
        # Need to update/create with full set of input properties
        
        # Get the input properties for the recoveryLog
        baseProps = getPropList(serverConfigInfo,"%s.recoveryLog" % prefix)
        
        if (not isEmpty(recoveryLogId)):
          
          #################
          # LAB INSERTION POINT
          # 
          # Call the method in ApplicationServer.py that updates the RecoveryLog
          #
          
          
          # END INSERTION POINT 
          #####
          
          _app_message("Updated RecoveryLog for appserver %s" % appserverName)
        else:
          
          # Call the method for creating a recoveryLog
          
          #########
          # LAB INSERTION POINT
          #
          # Call the method in ApplicationServer.py for creating a RecoveryLog
          #
                            
          # END INSERTION POINT
          ################
          
          _app_message("Created RecoveryLog for appserver %s" % appserverName)
          
            
        
  except:
    _app_exception("Unexpected problem in setupApplicationServerRecoveryLog()")
  
  _app_exit("setupApplicationServerRecoveryLog(retval=%s)" % retval)
  return retval
      
#----------------------------------------------------------------------------------------------------
# setupApplicationServer
#
# This function is used to apply a set of properties to a server, cluster member, or a template
#
# Parameters:
#   serverId - configuration ID of object to be configured
#   prefix - prefix of properties to be used
#   existingProps - if server already exists, this is the property representation of the current props
#----------------------------------------------------------------------------------------------------
def setupApplicationServer(serverConfigInfo,serverId, prefix, existingProps=None):

  setDynamicId("CURRENT_SERVER", serverId)
  
  #appserverName = serverConfigInfo["%s.name" % (prefix)]
  appserverName = AdminConfig.showAttribute(serverId,"name")

  # Now make modifications e.g. JVM settings, monitoring defs etc
  processId = None
  if (checkForPrefix(serverConfigInfo,"%s.processdef" % prefix)):
    # Go ahead and look up process ID
    processId = AdminConfig.list("ProcessDef", serverId)
  else:
    _app_message("No need to update ProcessDef settings for server %s" % appserverName)
  
  overrideSettings = 0
  overrideSettingsFlag = serverConfigInfo.get("%s.overrideSettings" % prefix,"false")
  if (overrideSettingsFlag == "true"):
      overrideSettings = 1
      

  # Change Ports  
  #subProps = getPropList(serverConfigInfo, "%s.ports" % (prefix))
  #if (len(subProps) > 0):
  # if (modifyPorts(serverId, subProps) == 1):
  #   _app_message("Failed to modify ports for appserver %s" % (appserverName))
  #   exit()
  # else:
  #   _app_message("Modified ports for appserver %s" % (appserverName))

  # ThreadPool properties
  if ( progInfo["dmgrVersion"].startswith("6.0")):
    subProps = getPropList(serverConfigInfo, "%s.webContainer.threadPool" % (prefix))
    if (len(subProps) > 0):
      webContainerId = AdminConfig.list("WebContainer", serverId)
      threadPoolId = AdminConfig.list("ThreadPool", webContainerId)
      if (threadPoolId == ""):
        attrs = []
        threadPoolId = AdminConfig.create("ThreadPool", webContainerId,attrs)
    
 
      propAttrs = "["
      
      for key in subProps.keys():
        propAttrs += "[%s %s]" % (key, subProps[key])

      propAttrs += "]"
      
      if modifyObject(threadPoolId, propAttrs):
        _app_message("Failed to modify webcontainer ThreadPool attributes for appserver %s" % (appserverName))
        exit()
      else:
        _app_message("Modified webcontainer ThreadPool  attributes for appserver %s" % (appserverName))
  else:
    _app_trace("Ignoring webcontainer ThreadPool attributes in %s environment" % (progInfo["dmgrVersion"]))
    
  # Base ApplicationServer properties
  setupApplicationServerBaseApplicationServerSettings(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  # Process environment variables
  if (processId != None):
    setupProcessDefEnvironmentVariables(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps,overrideSettings)
    
  # Working Directory setting     
  if (processId != None):
    setupProcessDefWorkingDirectory(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps)

  # IORedirect
  if (not isEmpty(processId)):
    setupApplicationServerIoRedirect(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps)
  
  # Plug-in settings
  setupApplicationServerWebserverPluginSettings(serverConfigInfo,serverId, prefix, appserverName, existingProps)

  # @JJM Classloader support  
  setupApplicationServerClassLoaders(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  

  # @JJM Full thread pool support
  setupApplicationServerThreadPools(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  
  # SessionManagement properties
  setupApplicationServerSessionManagement(serverConfigInfo,serverId, prefix, appserverName, existingProps)      


  # Set Logging properties
  setupApplicationServerLogs(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
      
  # @JJM trace service
  setupApplicationServerTraceService(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  # @JJM Activity Log
  setupApplicationServerRASLoggingService(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  # @JJM HPEL Log in V8
  setupApplicationServerHPELService(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  setupHTTPAccessLoggingService(serverConfigInfo,serverId,prefix,appserverName,existingProps)
  
  # @JJM PMI service
  setupApplicationServerPMI(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  
  # @JJM MessageListenerService and Listener Ports
  setupMessageListeningService(serverConfigInfo,serverId, prefix, appserverName, existingProps)
    
  # set monitoringpolicy
  if (processId != None):
    setupApplicationServerMonitoringPolicy(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps)
  
  
  # set processdef jvm properties
  if (processId != None):
    setupApplicationServerJavaVirtualMachine(serverConfigInfo,serverId, processId, prefix, appserverName, existingProps,overrideSettings)
  
  # set processExecution properties
  setupApplicationServerProcessExecution(serverConfigInfo,serverId, prefix, appserverName, existingProps)
      
  # @JJM TransactionService Support
  setupApplicationServerTransactionService(serverConfigInfo,serverId, prefix, appserverName, existingProps,overrideSettings)
  
  # Setup Any custom services
  setupApplicationServerCustomServices(serverConfigInfo,serverId, prefix, appserverName, existingProps,overrideSettings)  
  
  # Setup up any HA Manager Service
  setupApplicationServerHAManagerService(serverConfigInfo,serverId, prefix, appserverName, existingProps,overrideSettings)
  
  # Setup WebContainer properties and custom properties
  setupApplicationServerWebContainer(serverConfigInfo,serverId, prefix, appserverName, existingProps,overrideSettings)
  
  #Setup PortletContainer properties and custom properties
  setupApplicationServerPortletContainer(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  # Setup the SIPContainer
  setupApplicationServerSIPContainer(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  # Setup the ORB Service
  setupApplicationServerORBService(serverConfigInfo,serverId, prefix, appserverName, existingProps, overrideSettings)
  
  # Setup the EJB Container
  setupApplicationServerEJBContainer(serverConfigInfo,serverId, prefix, appserverName, existingProps, overrideSettings)
  
  # Setup the JPA service
  setupJavaPersistenceAPIService(serverConfigInfo,serverId,prefix,appserverName, existingProps,overrideSettings)
  
  # Setup the WebContainer Transport Chains and Channels
  setupApplicationServerTransportChains(serverConfigInfo,serverId, "%s.webContainer" % prefix, appserverName, existingProps, overrideSettings)
  
  # Setup the SIPContainer Transport Chains and Channels
  setupApplicationServerTransportChains(serverConfigInfo,serverId, "%s.sipContainer" % prefix, appserverName, existingProps, overrideSettings)

  # Setup the Messaging Transport Chains and Channels
  setupApplicationServerTransportChains(serverConfigInfo,serverId, "%s.messaging" % prefix, appserverName, existingProps, overrideSettings)  
  
  # Setup the Messaging Transport Chains and Channels
  setupApplicationServerTransportChains(serverConfigInfo,serverId, "%s.dcs" % prefix, appserverName, existingProps, overrideSettings)  
  

  if serverConfigInfo.has_key("%s.startupbeansservice.enable" % (prefix)):
    startupBeansEnabled   = serverConfigInfo["%s.startupbeansservice.enable" % (prefix)]
    startupBeansServiceID = AdminConfig.list("StartupBeansService", serverId)
    if (AdminConfig.showAttribute(startupBeansServiceID, "enable") != startupBeansEnabled):
        if modifyObject(startupBeansServiceID, "[[enable %s]]" % (startupBeansEnabled)):
            _app_message("Failed to modify startup beans service for appserver %s" % (appserverName))
            exit()
        else:
            _app_message("Modified startup beans service for appserver %s" % (appserverName))
  
  # AdminService settings
  setupApplicationServerAdminServices(serverConfigInfo,serverId, prefix, appserverName,existingProps)
  
  # DynamicCache service
  setupDynamicCacheService(serverConfigInfo,serverId,prefix,appserverName, existingProps)
  
  # ObjectPoolService
  setupApplicationServerObjectPoolService(serverConfigInfo,serverId, prefix, appserverName, existingProps)
  
  # WorkAreaService
  setupApplicationServerWorkAreaService(serverConfigInfo,serverId,prefix,appserverName, existingProps)
  
  setupApplicationServerWorkAreaPartitionService(serverConfigInfo,serverId,prefix,appserverName,existingProps)
  
  setupApplicationServerCEASettings(serverConfigInfo,serverId,prefix,appserverName,existingProps)
  
  setupApplicationServerCompensationService(serverConfigInfo,serverId,prefix,appserverName,existingProps)
  
  setupApplicationServerRecoveryLog(serverConfigInfo,serverId,prefix,appserverName,existingProps)
  
  if (checkForPrefix(serverConfigInfo,"%s.odr"%prefix)):
    processOnDemandRouter(odrConfig=serverConfigInfo,prefix="%s.odr"%prefix,odrId=serverId,odrName=appserverName,existingProps=existingProps)

#enddef setupApplicationServerRecoveryLog


#---------------------------------------------------------------------------------------------------
# processMatchingApplicationServers
#---------------------------------------------------------------------------------------------------
def processMatchingApplicationServers(serverConfigInfo,prefix, nameProperty):
  try:
    iterateParms = parseFunctionParms(nameProperty)
    if (len(iterateParms) == 0):
      namePattern = wildcardToRegExpString("*")
    else:
      namePattern =  wildcardToRegExpString(iterateParms[0])
    
    includeClusterMembersValue = serverConfigInfo.get("%s.includeClusterMembers" % prefix,"true").lower()  
    includeClusterMembers = 0
    if (includeClusterMembersValue == "true" or includeClusterMembersValue == "yes"):
      includeClusterMembers = 1
    
    
    includeManagementServersValue = serverConfigInfo.get("%s.includeManagementServers" % prefix,"false").lower() 
    includeManagementServers = 0
    if (includeManagementServersValue == "true" or includeManagementServersValue == "yes"):
      includeManagementServers = 1
    
    includeODRValue = serverConfigInfo.get("%s.includeODR" % prefix,"false").lower()  
    includeODR = 0
    if (includeODRValue.lower() == "true" or includeODRValue.lower() == "yes"):
      includeODR = 1
      
   
    
    
    matchingIds = findMatchingApplicationServers(namePattern, includeClusterMembers=includeClusterMembers,includeManagementServers=includeManagementServers, includeODR=includeODR)
    if (len(matchingIds) == 0):
      _app_message("No servers match the name pattern for %s" % nameProperty)
    else:
      _app_message("%d servers matched the name pattern for %s" % (len(matchingIds),nameProperty))
      for serverId in matchingIds:
        serverName = AdminConfig.showAttribute(serverId,"name")
        nodeName = getNodeNameForServer(serverId)
        _app_message("Applying properties to server %s on node %s" % (serverName,nodeName))
        
        # Get node ID for dynamic properties
        nodeId = getNodeForServer(serverId)
        if (not isEmpty(nodeId)):
           setDynamicId("CURRENT_NODE", nodeId)
        
    
        appserverPort = serverConfigInfo.get("%s.startingport" % (prefix),"")
        keepHostNames = 0
        keepHostNamesString = serverConfigInfo.get("%s.startingport.keepHostNames","false").lower()
        if (keepHostNamesString in ["true","yes"]):
          keepHostNames = 1
          
        # See if we want to update ports, which is not default behavior for existing application servers
        if (not isEmpty(appserverPort)):
          appserverPort = substituteDynamicValues("%s.startingport" % (prefix), appserverPort)
          processPorts = serverConfigInfo.get("%s.processPortsOnExistingServer" % prefix,"false")
      
          if (processPorts.lower() == "true" or processPorts.lower() == "yes"):
            amendVHost = 0
            mapPortsToVirtualHost = serverConfigInfo.get("%s.mapPortsToVirtualHost" % prefix,"")
            if (not isEmpty(mapPortsToVirtualHost)):
              amendVHost = 1
                
            if (modifyApplicationServerPorts(serverName, nodeName, appserverPort, amendVHost, mapPortsToVirtualHost,keepHostNames)):
              _app_message("Error modifying ports for application server %s/%s" % (nodeName,serverName))
              exit()
            else:
              _app_message("Modified ports for application server %s/%s" % (nodeName,serverName))
                
        existingProps=getApplicationServerInfo(serverId)
        setupApplicationServer(serverConfigInfo,serverId, prefix,existingProps)
        _app_message(" ")
        
  except:
    _app_trace("Unexpected error in processMatchingApplicationServers","exception")
    exit()

#---------------------------------------------------------------------------------------------------
# processApplicationServers
# 
# This script loops through the app.appserver definitions and creates non-clustered application servers
#
# Formerly known as buildCreateApplicationServers
#----------------------------------------------------------------------------------------------------
def processApplicationServers(serverConfigInfo):
  if not serverConfigInfo.has_key("app.appserver.count"):
    return

  _app_message("Building Application Server...")
  # Create application servers
  for asidx in range(1, int(serverConfigInfo["app.appserver.count"])+1):
    prefix = "app.appserver.%d" % (asidx)
    try:
      appserverName = serverConfigInfo["%s.name" % (prefix)]
    except:
      continue
    
    if (isEmpty(appserverName)):
      _app_message("No application server name supplied for %s, skipping partial list item" % prefix)
      continue
    
    if (appserverName.find("@ITERATE") >= 0):
      # This is a special case for applying patterns to multiple application servers
      processMatchingApplicationServers(serverConfigInfo,prefix, appserverName)
      continue
    
    appserverNode = serverConfigInfo["%s.node" % (prefix)]
    
    keepHostNames = 0
    try:
      appserverPort = serverConfigInfo["%s.startingport" % (prefix)]
      
      keepHostNamesString = serverConfigInfo.get("%s.startingport.keepHostNames" % prefix,"false").lower()
      if (keepHostNamesString in ["true","yes"]):
        keepHostNames = 1
    except:
      appserverPort = ""
    
    amendVHost = 0
    mapPortsToVirtualHost = serverConfigInfo.get("%s.mapPortsToVirtualHost" % prefix,"")
    if (not isEmpty(appserverPort) and not isEmpty(mapPortsToVirtualHost)):
      amendVHost = 1
    
    
    serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (appserverNode, appserverName))
    
    coregroup = serverConfigInfo.get("%s.moveToCoreGroup"%prefix,"")
    
    # Get node ID for dynamic properties
    nodeId = AdminConfig.getid("/Node:%s/" % (appserverNode))
    if (not isEmpty(nodeId)):
      setDynamicId("CURRENT_NODE", nodeId)
  
    # Support the @{DYNAMIC#CURRENT_NODE#NEXT_STARTING_PORT(seedValue)} macro
    if (not isEmpty(appserverPort)):
      appserverPort = substituteDynamicValues("%s.startingport" % (prefix), appserverPort)
      
     
  
    if isEmpty(serverId):
      
      serverType = serverConfigInfo.get("%s.serverType"%prefix,"APPLICATION_SERVER")
      if (serverType == "ONDEMAND_ROUTER"):
        templateName = serverConfigInfo.get("%s.template" % prefix,"odr")
        
        
        _app_message("Creating OnDemand Router %s/%s" % (appserverNode,appserverName))
        serverId = createODR(appserverNode,appserverName,templateName,startingPort=appserverPort)
      else:
        _app_message("Creating application server %s/%s" % (appserverNode,appserverName))
        serverId = createApplicationServer(appserverName, appserverNode, appserverPort, None, "default", amendVHost,mapPortsToVirtualHost,keepHostNames)
      
      
      if isEmpty(serverId):
        _app_message("isEmpty serverID")
        if not isEmpty(appserverPort):
            _app_message("Failed to create appserver %s node %s starting port %d" % (appserverName, appserverNode, appserverPort))
        else:
            _app_message("Failed to create appserver %s node %s" % (appserverName, appserverNode))
        
        raise StandardError("Application server creation failure")
            

      else:
        _app_message("Created %s %s/%s - Settings will now be applied" % (serverType,appserverNode,appserverName))
        if (isEmpty(appserverPort)):
          setupApplicationServerPorts(serverConfigInfo,appserverNode,appserverName,prefix)
          
        setupApplicationServer(serverConfigInfo,serverId, prefix)
        
        if (not isEmpty(coregroup)):
          addServerToCoreGroup(appserverName,appserverNode,coregroup,serverId)
          
        _app_message("Created %s %s/%s" % (serverType,appserverNode,appserverName))
    else:
      _app_message("Server %s already exists on Node %s" %( appserverName, appserverNode ))
      
      # See if we want to update ports, which is not default behavior for existing application servers
      # Two different options for port processing - starting port value or explicit endpoint settings
      if (not isEmpty(appserverPort)):
        processPorts = serverConfigInfo.get("%s.processPortsOnExistingServer" % prefix,"false").lower()
      
        if (processPorts == "true" or processPorts == "yes"):
            
          if (modifyApplicationServerPorts(appserverName, appserverNode, appserverPort, amendVHost, mapPortsToVirtualHost,keepHostNames)):
            _app_message("Error modifying ports for application server %s/%s" % (appserverNode,appserverName))
            exit()
          else:
            _app_message("Modified ports for application server %s/%s" % (appserverNode,appserverName))
      else:
        setupApplicationServerPorts(serverConfigInfo,appserverNode,appserverName,prefix)      
        
        
            
      #@JJM support update on existing
      existingProps=getApplicationServerInfo(serverId)
      setupApplicationServer(serverConfigInfo,serverId, prefix,existingProps)
      
      if (not isEmpty(coregroup)):
        oldCoreGroupName,newCoreGroupName=addServerToCoreGroup(appserverName,appserverNode,coregroup,serverId)
        if (oldCoreGroupName == newCoreGroupName):
          _app_message("Server %s/%s was already a member of core group %s" % (appserverNode,appserverName,newCoreGroupName))
        else:
          _app_message("Server %s/%s was moved from core group %s to core group %s" % (appserverNode,appserverName,oldCoreGroupName,newCoreGroupName))
        
      _app_message("Finished processing settings for appserver %s/%s" % (appserverNode,appserverName))
    
    _app_message(" ")
    
  #endfor         

#enddef processApplicationServers

#-------------------------------------------------------------------------------------------------
# processClusterTemplateSettings()
#
# There are multiple uses for a cluster template definition pulled from the properties file.
# This method checks the control settings to determine what to do with them.
#-------------------------------------------------------------------------------------------------
def processClusterTemplateSettings(serverConfigInfo,prefix, clusterId, clusterName,dynamicClusterId=None):

  if serverConfigInfo.has_key("%s.clusterTemplate.updateTemplate" % prefix) :
      updateTemplateFlag = serverConfigInfo["%s.clusterTemplate.updateTemplate" % prefix ]
      if (updateTemplateFlag == "true" or updateTemplateFlag == "TRUE"):
        
        if (dynamicClusterId != None):
        
          # Template location is different
          templateId = AdminConfig.getid("/DynamicCluster:%s/Server:%s/" % (clusterName,clusterName))
          if (not isEmpty(templateId)):
            existingProps = getApplicationServerInfo(templateId)
            setupApplicationServer(serverConfigInfo,templateId, "%s.clusterTemplate" % prefix, existingProps)
            _app_message("Cluster template has been updated for dynamic cluster %s" % clusterName)
            _app_message(" ")
          else:
            raise StandardError("Problem locating template for DynamicCluster %s" % clusterName)
            
        else:
          # Regular template
          searchName = "templates/clusters/%s/servers" % (clusterName)
          templateIds = AdminConfig.listTemplates("Server",searchName)
          templateList = wsadminToList(templateIds)
          for templateId in templateList:
              existingProps = getApplicationServerInfo(templateId)

              setupApplicationServer(serverConfigInfo,templateId, "%s.clusterTemplate" % prefix, existingProps)
              _app_message("Cluster template has been updated for cluster %s" % clusterName)
              _app_message(" ")
  
  
  if serverConfigInfo.has_key("%s.clusterTemplate.applyTemplateSettingsToExistingMembers" % prefix) :
      updateExistingFlag = serverConfigInfo["%s.clusterTemplate.applyTemplateSettingsToExistingMembers" % prefix]
      if (updateExistingFlag == "true" or updateExistingFlag == "TRUE"):
          clusterMembers = AdminConfig.list("ClusterMember", clusterId)

          if not isEmpty(clusterMembers):
              _app_message("Applying template settings to members of cluster %s" % clusterName)       
              clusterMemberList = clusterMembers.split(progInfo["line.separator"])
              for cmid in clusterMemberList:
                  mName = AdminConfig.showAttribute(cmid, "memberName")
                  mNode = AdminConfig.showAttribute(cmid, "nodeName")
                  
                  # Get node ID for dynamic properties
                  nodeId = AdminConfig.getid("/Node:%s/" % (mNode))
                  if (not isEmpty(nodeId)):
                      setDynamicId("CURRENT_NODE", nodeId)
          
                  serverId = AdminConfig.getid("/Node:%s/Server:%s" % (mNode, mName))
                  if (not isEmpty(serverId)):
                      
                      # This explicit port processing really only works if 1) one server per port
                      # and no hostnames in properties
                      setupApplicationServerPorts(serverConfigInfo,mNode,mName,"%s.clusterTemplate" % prefix)
                    
                      existingProps = getApplicationServerInfo(serverId)
                      _app_message("Applying cluster templates settings to server %s on node %s" % (mName,mNode))
                      setupApplicationServer(serverConfigInfo,serverId, "%s.clusterTemplate" % prefix, existingProps)
                      _app_message("Cluster template settings have been applied to %s on %s" % (mName, mNode))
                      _app_message(" ")
              
              _app_message("Done applying template settings to members of cluster %s" % clusterName)        
          

#enddef

#-------------------------------------------------------------------------------
# processClusterMemberList
#
#-------------------------------------------------------------------------------
def processClusterMemberList(serverConfigInfo, clusterId, memberList, prefix):
  _app_trace("processClusterMemberList(serverConfigInfo,%s,%s,%s)" % (clusterId, memberList, prefix),"entry")
  
  try:
    pass
    
  except:
    _app_trace("Unexpected error in processClusterMemberList","exception")
    exit()
  
  _app_trace("processClusterMemberList()","exit")
  
#enddef processClusterMemberList

#-------------------------------------------------------------------------------
# processMatchingClusters
#
# This function is called with the cluster name is the @ITERATE(wildcard) macro.
# It will find clusters that match the pattern and apply the template settings 
# against them and possibly update the cluster members if the applyTemplateSettingsToExistingMembers
# property is set to true.
#-------------------------------------------------------------------------------
def processMatchingClusters(serverConfigInfo,prefix, nameProperty ):
  try:
    
    iterateParms = parseFunctionParms(nameProperty)
    if (len(iterateParms) == 0):
      clusterPattern = wildcardToRegExpString("*")
    else:
      clusterPattern =  wildcardToRegExpString(iterateParms[0])
      
    matchingIds = findMatchingClusters(clusterPattern)
    
    _app_message("%d clusters match the name pattern for %s" % (len(matchingIds),nameProperty))
    for clusterId in matchingIds:
      clusterName = AdminConfig.showAttribute(clusterId, "name")
      
      # Store cluster ID for dynamic variable support
      setDynamicId("CURRENT_CLUSTER",clusterId)
      
      _app_message("Processing template settings for cluster %s" % clusterName)

      processClusterTemplateSettings(serverConfigInfo,prefix, clusterId, clusterName)
      _app_message(" ")
      
      
  except:
    _app_trace("Unexpected error in processMultipleClusters","exception")
    exit()
    

#-----------------------------------------------------------------
# determineVariableServers
#
# Builds a generated list of node:server names based on other input properties
#-----------------------------------------------------------------
def determineVariableServers(serverConfigInfo,clusterName,prefix):
  
  _app_trace("determineVariableServers(serverConfigInfo,%s,%s)" % (clusterName,prefix))
  
  retval = ""
  
  try:
    # Let's see if the servers are explicitly defined as a single property
    servers = serverConfigInfo.get("%s.variableMembers.servers" %  prefix,"")
    if (not isEmpty(servers)):
      # See if it is the correct format "Node:Server Node:Server ..."
      if (servers.find(":") < 0):
        # Support some alternative formats
        namesep = None
        serversep = " "
        if (servers.find("\\") > 0):
          namesep = "\\"
        elif (servers.find("/") > 0):
          namesep = "/"
        elif (servers.find(",") > 0):
          namesep = " "
          serversep = ","
        
        if (namesep != None):
          slist = servers.split(serversep)
          templist = None
          for nodeserver in slist:
            ns = nodeserver.split(namesep)
            if (len(ns) != 2):
              raise StandardError("Invalid server name format")
            
            if (templist == None):
              templist = "%s:%s" % (ns[0],ns[1])
            else:
              templist = "%s %s:%s" % (templist, ns[0],ns[1])
          
          servers = templist
        else:
          raise StandardError("Invalid server name format")
      
      retval = servers    
    else:
      # Need to look at other options to build server list
      servers = ""
      
      # Get list of nodes
      nodelist = getSortedListFromProperty(serverConfigInfo,"%s.variableMembers.nodes" %  prefix)
      if (len(nodelist) == 0):
        raise StandardError("Unable to build node list for dynamic servers")
        
      # Support the subset of nodes option
      nodeCount = len(nodelist)
      nodeCountStr = serverConfigInfo.get("%s.variableMembers.nodeCount" % prefix,"")
      if (not isEmpty(nodeCountStr)):
        nodeCount = int(nodeCountStr)
        if (nodeCount > len(nodelist)):
          raise StandardError("Invalid nodeCount setting")
      
      # Determine the server counts
      serverCounts = []
      perNode = serverConfigInfo.get("%s.variableMembers.perNode" % prefix,"")
      if (not isEmpty(perNode)):
        for idx in range(1,nodeCount+1):
          serverCounts.append(int(perNode))
      else:
        serverCountStr = serverConfigInfo.get("%s.variableMembers.serverCount" % prefix,"")
        if (isEmpty(serverCountStr)):
          # Go with default of 1 per node
          for idx in range(1,nodeCount+1):
            serverCounts.append(1)
        else:
          # Parse the serverCount input
          if (serverCountStr.find(",") > 0):
            serverCountStrings = serverCountStr.split(",")
          else:
            serverCountStrings = serverCountStr.split(" ")
          
          for serverCountStr in serverCountStrings:
            serverCounts.append(int(serverCountStr))
          
          if (len(serverCounts) != nodeCount):
            raise StandardError("Server count settings do not match node settings for cluster %s" % clusterName)
        
      # Now use the node list and server counts list to build server names
      # We'll make use the @DYNAMIC processing to leave the syntax up to the user
      clusterMemberIdx = 0
      nodeMemberIdx = 0
      
      memberPropertyId = "%s.clustermember.1.name" % prefix
      baseMemberName = serverConfigInfo.get(memberPropertyId, "")
      if (isEmpty(baseMemberName)):
        raise StandardError("No member name template is available")
      
      
      nodeidx = 0
      setDynamicId("CURRENT_CLUSTER_NAME",clusterName)
      
      while (nodeidx < nodeCount):
        nodeName = nodelist[nodeidx]
        # Get node ID for dynamic properties
        nodeId = AdminConfig.getid("/Node:%s/" % (nodeName))
        if (not isEmpty(nodeId)):
           setDynamicId("CURRENT_NODE", nodeId)
           hostName = AdminConfig.showAttribute(nodeId,"hostName")
           setDynamicId("CURRENT_NODE_HOSTNAME",hostName)
           hostNames = hostName.split(".")
           setDynamicId("CURRENT_NODE_SHORTHOSTNAME",hostNames[0])
        else:
          raise StandardError("Unable to find node configuration id: %s" % nodeName)
        
        
        setDynamicId("NODE_NAME", nodeName)
        setDynamicId("CURRENT_NODE_NAME", nodeName)
        
        nodeIdxString = "00%d" % (nodeidx+1)
        nodeIdxString = nodeIdxString[-2:]
        setDynamicId("NODE_IDX",nodeIdxString)
        
        nodeMemberIdx = 0
        serversOnThisNode = serverCounts[nodeidx]
        if (serversOnThisNode > 0):
          for serveridx in range(1,serversOnThisNode+1):
            clusterMemberIdx += 1
            
            clusterMemberIdxString = "000%d" % clusterMemberIdx
            clusterMemberIdxString = clusterMemberIdxString[-3:]
              
            serverNodeIdxString = "00%d" % serveridx
            serverNodeIdxString = serverNodeIdxString[-2:]
              
              
            # Get node ID for dynamic properties
            setDynamicId("CLUSTER_MEMBER_IDX",clusterMemberIdxString)
            setDynamicId("NODE_MEMBER_IDX",serverNodeIdxString)
            
            tempServerName = substituteDynamicValues(memberPropertyId, baseMemberName)
            
            if (servers == ""):
              servers = "%s:%s" % (nodeName,tempServerName)
            else:
              servers = "%s %s:%s" % (servers,nodeName,tempServerName)
          #endfor
        #endif
         
        nodeidx += 1
      #endwhile
      
      retval = servers
      
    #endelse      
  except:
    _app_trace("Unexpected error in determineVariableServers","exception")
    exit()
  
  _app_trace("determineVariableServers(retval = %s)" % retval,"exit")
  return retval
#enddef determineVariableServers

#---------------------------------------------------------------------------------------------------------------------
# processNewClusterMember
#
# This function will process the settings for creating a new cluster member (if it needs to be created).
#---------------------------------------------------------------------------------------------------------------------
def processNewClusterMember(serverConfigInfo,clusterName,clusterId,existingMembers,clusterPrefix,memberPrefix,applyTemplateSettingsToNewMembers,mapPortsToVirtualHost,resourcesScope):

  _app_trace("processNewClusterMember(serverConfigInfo,%s,%s,%s,%s,%s,%d)" % (clusterName,clusterId,existingMembers,clusterPrefix,memberPrefix,applyTemplateSettingsToNewMembers),"entry")
  
  global createdMembers
  
  try:
      
      memberName    = serverConfigInfo.get("%s.name" % (memberPrefix),"")
      if (isEmpty(memberName)):
        _app_message("Skipping CreateClusterMemeber %s" % (memberPrefix))
      else:
        memberNode    = serverConfigInfo["%s.node" % (memberPrefix)]
        
        _app_message("Processing cluster member definition for %s %s" % (memberName, memberNode))
        
        # Get node ID for dynamic properties
        nodeId = AdminConfig.getid("/Node:%s/" % (memberNode))
        if (not isEmpty(nodeId)):
            setDynamicId("CURRENT_NODE", nodeId)
        
        try:
          memberTempl   = serverConfigInfo["%s.defaulttemplate" % (memberPrefix)]
        except:
          memberTempl = ""
          
        try:
          memberTemplNode   = serverConfigInfo["%s.templatenode" % (memberPrefix)]  
        except:
          memberTemplNode = ""
          
        try:
          memberTemplServer = serverConfigInfo["%s.templateserver" % (memberPrefix)]
        except:
          memberTemplServer = ""
        
        

          
          
        memberStartingPort  = serverConfigInfo.get("%s.startingport" % (memberPrefix),"")
        
        keepHostNames = 0
        keepHostNamesString = serverConfigInfo.get("%s.startingport.keepHostNames" % (memberPrefix),"false").lower()
        if (keepHostNamesString in ["true","yes"]):
          keepHostNames = 1
          
        memberWeight = None
        if (serverConfigInfo.has_key("%s.weight" % (memberPrefix))):
            memberWeight = serverConfigInfo["%s.weight" % (memberPrefix)]
        
        
        #memberId = checkForExistingClusterMember(clusterName, memberNode, memberName)
        memberId = existingMembers.get("%s@%s" % (memberName,memberNode),None)
        
        
        if (isEmpty(memberId) and applyTemplateSettingsToNewMembers):
          # See if the member starting port and weight values are defined in the cluster section
          # and use those if the member specific values are not set
          templatePrefix = "%s.clusterTemplate" % (clusterPrefix)
          
          if (isEmpty(memberWeight)):
            memberWeight = serverConfigInfo.get("%s.memberDefaults.weight" % templatePrefix,"")
          
          if (isEmpty(memberStartingPort)):
            memberStartingPort = serverConfigInfo.get("%s.memberDefaults.startingport" % templatePrefix,"")
            keepHostNamesString = serverConfigInfo.get("%s.memberDefaults.startingport.keepHostNames" % (templatePrefix),"false").lower()
            if (keepHostNamesString in ["true","yes"]):
                keepHostNames = 1
        #end if check for default cluster member templates
          
          
         
        
        if (not isEmpty(memberId)):
            _app_message("Cluster %s already has a cluster member %s on node %s" % (clusterName, memberName, memberNode))
            
            # Only cluster member update we'll support is weight
            if (not isEmpty(memberWeight)):
                currentWeight = AdminConfig.showAttribute(memberId,"weight")
                if (memberWeight != currentWeight):
                    if (modifyObject(memberId,[["weight", memberWeight]])):
                        _app_message("Failed to change weight for existing %s clusterMember %s on %s)" % (clusterName, memberName, memberNode))
                    else:
                        _app_message("Modified weight for existing %s clusterMember %s on %s)" % (clusterName, memberName, memberNode))
            
        else:
          # New cluster member needs to be created
          
          # See if this starting port field has dynamic values
          memberStartingPort = substituteDynamicValues("%s.startingport" % (memberPrefix), memberStartingPort)
          
          if (memberStartingPort.startswith("ERROR")):
              _app_message("Unable to determine dynamic port range for server %s %s" % (memberName,  memberNode))
              exit()
          
          memberId = createClusterMember(clusterName, memberNode, memberName, memberStartingPort, memberTempl, memberTemplNode, 
                                         memberTemplServer, memberWeight,mapPortsToVirtualHost,resourcesScope,keepHostNames=keepHostNames)
          
                
          if isEmpty(memberId):
            _app_message("Failed to create cluster member %s on %s" % (memberName, memberNode))
            exit()
          else:
            #_app_message("Created %d of %s cluster members" % (cmidx, serverConfigInfo["%s.clustermember.count" %(prefix)]))
            _app_message("Created cluster member %s on %s" % (memberName, memberNode))
            createdMembers.put("%s.%s" %(memberName, memberNode) , clusterName)
            
            if (isEmpty(memberStartingPort)):
              # Process any explicit port definitions
              setupApplicationServerPorts(serverConfigInfo,memberNode,memberName,memberPrefix)
            
            # See if we need to apply the template settings
            if (applyTemplateSettingsToNewMembers):
                _app_message("Applying template settings to new cluster member %s on %s" %(memberName, memberNode))
            
                # Support dynamic variables
                serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (memberNode, memberName))
                
                    
                # Get and set up the keys used with @DYNAMIC("KEYWORD",keyword)
                keyProps = getPropList(serverConfigInfo,"%s.dynamickeys" % (memberPrefix))
                setDynamicKeys(keyProps)
                
                # This only works if one member per node and settings don't have host name
                setupApplicationServerPorts(serverConfigInfo,memberNode,memberName,"%s.clusterTemplate" % (clusterPrefix))
                
                # Set up the application server, but only using template settings
                setupApplicationServer(serverConfigInfo,serverId, "%s.clusterTemplate" % (clusterPrefix),None)
                
                # Now that we're done, remove the keys
                removeDynamicKeys(keyProps)
                
          _app_message("Done processing cluster member definition for %s %s" % (memberName, memberNode))
          
        # endelse not existing member
        

      #end if not empty memberName
    
    
  except:
    _app_trace("Unexpected error in processNewClusterMember","exception")
    exit()
  
  _app_trace("processNewClusterMember()","exit")
  
#enddef

#-------------------------------------------------------------------------------
# updateClusterTemplateDynamically
#    clusterName
#    modelMemberName
#    modelMemberNode
#-------------------------------------------------------------------------------
def updateClusterTemplateDynamically(clusterName,modelMemberName,modelMemberNode):
  _app_trace("updateClusterTemplateDynamically(%s,%s,%s)" %(clusterName,modelMemberName,modelMemberNode),"entry")
  
  try:
              
              # A new server will be created, but first we must update the template
              _app_message("Cluster %s server template will be updated with values from existing server" % clusterName)
              tempServerId = AdminConfig.getid("/Node:%s/Server:%s/" % (modelMemberNode,modelMemberName))
  
              tempDictionary = toDictionary(getApplicationServerInfo(tempServerId,1))
              _app_message("Property setting dictionary for the template has been built from %s:%s" % (modelMemberNode,modelMemberName))
              
              searchName = "templates/clusters/%s/servers" % (clusterName)
              templateIds = AdminConfig.listTemplates("Server",searchName)
              templateList = wsadminToList(templateIds)
              for templateId in templateList:
                  if (isEmpty(templateId)):continue
                  existingProps = getApplicationServerInfo(templateId)

                  setupApplicationServer(tempDictionary,templateId, "appserver", existingProps)
                  _app_message("Cluster template has been updated for cluster %s" % clusterName)
                  _app_message(" ")
              #endfor
  except:
    _app_trace("Unexpected error in updateClusterTemplateDynamically","exception")
    exit()
    
  _app_trace("updateClusterTemplateDynamically","exit")

#enddef updateClusterTemplateDynamically


#-------------------------------------------------------------------------------
# processServerClusterSettings -  Apply non-member settings to a ServerCluster configuration item
#
# Parameters
#    
#-------------------------------------------------------------------------------
def processServerClusterSettings(serverConfigInfo,clusterPrefix,clusterId,clusterName,existingProps=None,existingPrefix=None):  
  _app_entry("processServerClusterSettings(serverConfigInfo,%s,%s,%s,existingProps,%s)" , clusterPrefix,clusterId,clusterName,existingPrefix)
  retval = None
  try:
    baseProps = getPropListDifferences(serverConfigInfo,clusterPrefix,existingProps,existingPrefix)
    if (baseProps.get("name") != None):
      del baseProps["name"]
    if (baseProps.get("serverType") != None):
      del baseProps["serverType"]
    
    if (len(baseProps) > 0):
      attrs = propsToAttrList(baseProps)
      if (modifyObject(clusterId,attrs)):
        raise StandardError("Unable to update cluster %s base properties" % clusterName)
      else:
        _app_message("Updated base ServerCluster properties for cluster %s" % clusterName)
    
    clusterAddressProperties = getPropListDifferences(serverConfigInfo,"%s.clusterAddressProperties"%clusterPrefix,existingProps,"%s.clusterAddressProperties" % existingPrefix)
    if (len(clusterAddressProperties) > 0):
      # Need to update this
      attrs = propsToAttrList(clusterAddressProperties)
      clusterAddressPropertiesId = None
      if (existingProps != None):
        #for key in existingProps.keys():
        #  print "%s %s" % (key,existingProps[key])
        clusterAddressPropertiesId = existingProps.get("cluster.clusterAddressProperties.CONFIG_ID")
      
      if (isEmpty(clusterAddressPropertiesId)):
        # Do a create
        clusterAddressPropertiesId = AdminConfig.create("ClusterAddressProperties",clusterId,attrs,"clusterAddressProperties")
        _app_message("Created ClusterAddressProperties for cluster %s" % clusterName)
      else:
        if (modifyObject(clusterAddressPropertiesId,attrs)):
          raise StandardError("Problem updating ClusterAddressProperties for cluster %s: %s" % (clusterName,attrs))
        else:
          _app_message("Updated ClusterAddressProperties for cluster %s" % clusterName)
    elif (checkForPrefix(serverConfigInfo,"%s.clusterAddressProperties" % clusterPrefix)):
      _app_message("No updates required for %s ClusterAddressProperties" % clusterName)
          
    clusterAddressEndPointsCount = int(serverConfigInfo.get("%s.clusterAddressEndPoints.count" % clusterPrefix,0))
    if (clusterAddressEndPointsCount > 0):
      for idx in range(1,clusterAddressEndPointsCount+1):
        epPrefix = "%s.clusterAddressEndPoints.%d" % (clusterPrefix,idx)
        epName = serverConfigInfo.get("%s.prop.name" % (epPrefix))
        if (isEmpty(epName)):
          # Partial list
          continue
          
        existingEPPrefix = None
        endPointID = None
        if (existingProps != None):
          existEPCount = int(existingProps.get("cluster.clusterAddressEndPoints.count"))
          if (existEPCount > 0):
            for eidx in range(1,existEPCount+1):
              existName = existingProps.get("cluster.clusterAddressEndPoints.%d.prop.name" % eidx)
              if (existName == epName):
                existingEPPrefix = "cluster.clusterAddressEndPoints.%d" % eidx
                endPointID = existingProps.get("%s.CONFIG_ID" % existingEPPrefix)
                break
        
        
        endPointProps = getPropListDifferences(serverConfigInfo,epPrefix,existingProps,existingEPPrefix)
        if (len(endPointProps) > 0):
          attrs = propsToAttrList(endPointProps)
          if (not isEmpty(endPointID)):
            # Existing - do an update
            
            if (modifyObject(endPointID,attrs)):
              raise StandardError("Error updating ClusterAddressEndPoint %s in Cluster %s" % (epName,clusterName))
            else:
              _app_message("Updated ClusterAddressEndPoint %s in Cluster %s" % (epName,clusterName))
          else:
            # Need to create
            createType = serverConfigInfo.get("%s.type" % epPrefix)
            if (isEmpty(createType)):
              if (endPointProps.get("keyring") != None):
                createType = "SecureClusterAddressEndPoint"
              else:
                createType = "ClusterAddressEndPoint"
                
            _app_trace('About to call AdminConfig.create("%s",%s,%s)'% (createType,clusterId,attrs))
            endPointID = AdminConfig.create(createType,clusterId,attrs)
            _app_message("Created %s %s in Cluster %s" % (createType,epName,clusterName))
        else:
          _app_message("No updates required  ClusterAddressEndPoint %s in Cluster %s" % (epName,clusterName))
    # end clusterAddressEndPoints        
            
        
      
      
    
  except:
    _app_exception("Unexpected problem in processServerClusterSettings()")
  
  _app_exit("processServerClusterSettings(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------------------------
# processClusters()
#
# This method will create a cluster if necessary and create the cluster members.  Application server
# configuration is done later on in the processClusterMemberSettings() method.
#-------------------------------------------------------------------------------------------------

def processClusters(serverConfigInfo):

  global createdMembers
  
  # Create clusters
  if not serverConfigInfo.has_key("app.cluster.count"):
    return
    
  # Create a properties set that we'll use to keep track of new servers that are created
  createdMembers = java.util.Properties()
  

  for cidx in range(1, int(serverConfigInfo["app.cluster.count"]) + 1):
    
    existingMembers = {}
    firstMember = None
    firstMemberName = None
    firstMemberNode = None
    
    prefix = "app.cluster.%d" % (cidx)
    try:
      clusterName   = serverConfigInfo["%s.name" % (prefix)]
    except:
      _app_message("Skipping CreateCluster for %s" % (prefix))
      continue
      
    if (clusterName.find("@ITERATE") >= 0):
      # This is a special case for applying settings to multiple clusters and
      # their members
      processMatchingClusters(serverConfigInfo,prefix, clusterName )
      
      # Go on to the next definition
      continue
      
    
    clusterPrefer = "true"
    createDomain = "false"
    
    try:
      clusterPrefer = serverConfigInfo["%s.preferlocal" % (prefix)].lower()
    except:
      clusterPrefer = "true"

    try:
      createDomain  = serverConfigInfo["%s.createDomain" % (prefix)].lower()
    except:
      createDomain = "false"
      
    try:
      mapPortsToVirtualHost = serverConfigInfo["%s.mapPortsToVirtualHost" % (prefix)]
    except:
      mapPortsToVirtualHost = None
      
    coregroupName = serverConfigInfo.get("%s.moveClusterToCoreGroup" % prefix, "")
    
    resourcesScope = serverConfigInfo.get("%s.resourcesScope" % prefix,"")
      
    clusterId = AdminConfig.getid("/ServerCluster:%s/" % (clusterName))
 
    if not isEmpty(clusterId):
      _app_message("Cluster %s already exists" % (clusterName))
      
      # Store cluster ID for dynamic variable support 
      setDynamicId("CURRENT_CLUSTER",clusterId)
      
      clusterSettings = getServerClusterProperties(clusterId)
      
      processServerClusterSettings(serverConfigInfo,prefix,clusterId,clusterName,existingProps=clusterSettings,existingPrefix="cluster")
      
      # Now do cluster template settings
      processClusterTemplateSettings(serverConfigInfo,prefix, clusterId,clusterName)
      
      # Fill the dictionary of existing cluster members
      tempstr = AdminConfig.list("ClusterMember", clusterId)
      if not isEmpty(tempstr):
        memberList = tempstr.split(progInfo["line.separator"])
        for member in memberList:
          mName = AdminConfig.showAttribute(member, "memberName")
          mNode = AdminConfig.showAttribute(member, "nodeName")
          existingMembers["%s@%s" % (mName,mNode)] = member
          if (firstMember == None):
            firstMember = member
            firstMemberName = mName
            firstMemberNode = mNode

      
    else:
      # Need to create the cluster
      # Prefer local or round-robin?
      if clusterPrefer.lower() == "true":
        clusterPrefer = 1
      elif clusterPrefer.lower() == "false":
        clusterPrefer = 0
      else:
        _app_message("Unexpected value (%s) for %s.preferlocal; expected true or false" \
          % (clusterPrefer, prefix))
        exit()
      
      clusterId = createCluster(clusterName, None, None, clusterPrefer,createDomain)
      if isEmpty(clusterId):
        _app_message("Failed to create cluster %s" % (clusterName))
        exit()
      else:
        _app_message("Created cluster %s" % (clusterName))
    
    # end else need to create cluster
    
    # See if this cluster as CEASettings to process
    if (checkForPrefix(serverConfigInfo,"%s.CEASettings"%prefix)):
      ceaSettingsId = None
      ceaProps = {}

      getCEASettingsProperties(parentId=clusterId,appServerProperties=ceaProps)
      ceaSettingsId = ceaProps.get("CEASettings.CONFIG_ID")
      
      # See if there are settings to process - becomes no-op if existingProps is empty
      baseProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings"%prefix,ceaProps,"CEASettings")
      customProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.properties"%prefix,ceaProps,"CEASettings.properties")
      commsvcProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.commsvc"%prefix,ceaProps,"CEASettings.commsvc")
      commsvcCustomProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.commsvc.properties"%prefix,ceaProps,"CEASettings.commsvc.properties")
      ctiGatewayProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.ctiGateway"%prefix,ceaProps,"CEASettings.ctiGateway")
      ctiGatewayCustomProps = getPropListDifferences(serverConfigInfo,"%s.CEASettings.ctiGateway.properties"%prefix,ceaProps,"CEASettings.ctiGateway.properties")
      
      if (len(baseProps) > 0 or len(customProps) > 0 or
          len(commsvcProps) > 0 or len(commsvcCustomProps) > 0 or
          len(ctiGatewayProps) > 0 or len(ctiGatewayCustomProps) > 0):
            
        updateCEASettings(parentId=clusterId, ceaSettingsId=ceaSettingsId,
                          ceaProps=baseProps,ceaCustomProps=customProps,
                          commsvcProps=commsvcProps,commsvcCustomProps=commsvcCustomProps,
                          ctiGatewayProps=ctiGatewayProps,ctiGatewayCustomProps=ctiGatewayCustomProps)
        
        _app_message("Updated CEASettings for cluster %s" % clusterName)
      else:
        _app_message("No need to update CEASettings for cluster %s" % clusterName)
    #endif CEASettings  

    
    
    # Store cluster ID for dynamic variable support 
    if (not isEmpty(clusterId)):
        setDynamicId("CURRENT_CLUSTER",clusterId)
    
    if serverConfigInfo.has_key("%s.startingport"% (prefix)):
      setDynamicId(clusterName+".STARTING_PORT", serverConfigInfo["%s.startingport" % (prefix)])

    if not serverConfigInfo.has_key("%s.clustermember.count" % prefix):
      continue

    applyTemplateSettingsToNewMembers = 0
    
    if serverConfigInfo.has_key("%s.clusterTemplate.applyTemplateSettingsToNewMembers" % prefix) :
        if (serverConfigInfo["%s.clusterTemplate.applyTemplateSettingsToNewMembers" % prefix] == "true"):
            applyTemplateSettingsToNewMembers = 1

    updateTemplateBeforeNewMembers = serverConfigInfo.get("%s.updateTemplateDynamicallyBeforeNewMembers"%prefix,"false")

    # See if we will dynamically build list of cluster member names
    variableMembers = serverConfigInfo.get("%s.variableMembers" % prefix,"false")
    variableServers = None
    if (variableMembers.lower() == "true"):
      
      
      variableServers = determineVariableServers(serverConfigInfo,clusterName,prefix)
      if (not isEmpty(variableServers)):
        serverConfigInfo["%s.variableMembers.servers" % prefix] = variableServers
        
        # Remove any cluster members that do not meet the generated list
        tempList = getSortedClusterMemberList(clusterName, clusterId)
        originalMemberCount = len(tempList)
        removeList = []
        for tempMember in tempList:
          tempName = tempMember[0]
          tempNode = tempMember[1]
          
          if (variableServers.find("%s:%s" % (tempNode,tempName)) < 0):
            # This node is not in the generated list
            removeList.append(tempMember)
          
        numRemove = len(removeList)
        
        deferredRemoval = []
        if (numRemove > 0):
          
          # See if we allow removal of non-matching members
          allowRemoval = serverConfigInfo.get("%s.variableMembers.removeMismatches" % prefix,"false")
          if (allowRemoval.lower() == "true"):
            if (originalMemberCount == numRemove):
              _app_message("Variable cluster members are being built. All %d existing servers do not match name input and will be removed after the new servers are created" % numRemove)
              deferredRemoval = removeList
            else:
              _app_message("Variable cluster members are being built. %d existing servers do not match name input and will be removed" % numRemove)
              deleteClusterMembers(clusterName, removeList)
              for tempMember in removeList:
                _app_message("Cluster member %s has been removed from %s" % (tempMember,clusterName))
            #endelse
          else:
            _app_message("WARNING: The following existing %s cluster members do not match current variable settings, but will be kept in the configuration" % clusterName)
            for tempMember in removeList:
              _app_message("   %s" % (tempMember))
          #endelse
            
        #endif
        
        
        # Create a copy of the serverConfigInfo to dynamically modify
        tempServerConfigInfo = filterProperties(serverConfigInfo,prefix)
        
        variableServersList = variableServers.split(" ")
        for nodeserver in variableServersList:
          nodeserversplit = nodeserver.split(":")
          if (len(nodeserversplit) != 2):
            raise StandardError("Invalid dynamic members syntax: %s" % variableServers)
          
          nodeName = nodeserversplit[0]
          serverName = nodeserversplit[1]
          
          tempServerConfigInfo["%s.clustermember.1.name" % prefix] = serverName
          tempServerConfigInfo["%s.clustermember.1.node" % prefix] = nodeName
          
          # Before we process the cluster member, see if we are to dynamically update the 
          # cluster template
          if (updateTemplateBeforeNewMembers == "true" and not isEmpty(firstMember)):
            
            # See if this server is new
            if (existingMembers.get("%s@%s" % (serverName,nodeName),None) == None):
              
              updateClusterTemplateDynamically(clusterName,firstMemberName,firstMemberNode)
              
              # Set the value to false so we don't repeat              
              updateTemplateBeforeNewMembers = "false"
              
          #endif

          processNewClusterMember(tempServerConfigInfo,clusterName,clusterId,existingMembers,prefix,"%s.clustermember.1" % prefix,applyTemplateSettingsToNewMembers,mapPortsToVirtualHost,resourcesScope)
          
        #endfor 
        
        if (len(deferredRemoval) > 0):
           _app_message("Dynamic cluster members have been built. %d existing servers did not match name input and will be removed" % numRemove)
           deleteClusterMembers(clusterName, deferredRemoval)
           for tempMember in deferredRemoval:
             _app_message("Cluster member %s has been removed from %s" % (tempMember,clusterName))
        #endif
     
    else:
      # Do processing for statically defined members
      
      # Create cluster members
      for cmidx in range(1, int(serverConfigInfo.get("%s.clustermember.count" %(prefix),"0")) + 1):
    
        _app_message(" ")
      
      
        memberPrefix = "%s.clustermember.%d" % (prefix,cmidx)
        
        # Before we process the cluster member, see if we are to dynamically update the 
        # cluster template
        if (updateTemplateBeforeNewMembers == "true" and not isEmpty(firstMember)):
          
          serverName = serverConfigInfo.get("%s.name" % memberPrefix,"")
          nodeName = serverConfigInfo.get("%s.node" % memberPrefix,"")
            
          # See if this server is new
          if (existingMembers.get("%s@%s" % (serverName,nodeName),None) == None):
              
              updateClusterTemplateDynamically(clusterName,firstMemberName,firstMemberNode)
              
              # Set the value to false so we don't repeat              
              updateTemplateBeforeNewMembers = "false"
              
        #endif
      
        processNewClusterMember(serverConfigInfo,clusterName,clusterId,existingMembers,prefix,memberPrefix,applyTemplateSettingsToNewMembers,mapPortsToVirtualHost,resourcesScope)
      
      # end for each cluster member
    # end else staticly defined members
    
    if (not isEmpty(coregroupName)):
      try:
        _app_message(" ")
        oldCoreGroupName,newCoreGroupName =  addClusterToCoreGroup(clusterName, coregroupName)
        if (oldCoreGroupName == newCoreGroupName):
           _app_message("Cluster %s was already a member of core group %s" % (clusterName,newCoreGroupName))
        else:
          _app_message("Cluster %s was moved from core group %s to core group %s" % (clusterName,oldCoreGroupName,newCoreGroupName))
      except NameError:
        # core group functions not available
        _app_message("Unable to change core group settings because core group module is not available")
    
#enddef processClusters

#----------------------------------------------------------------------------------------------------
# processIndividualClusterMemberSettings
# 
# This function will process the application server settings for a single cluster member.
#----------------------------------------------------------------------------------------------------
def processIndividualClusterMemberSettings(serverConfigInfo, memberNode, memberName, memberPrefix,applyTemplateSettingsToNewMembers):
  
  
  global createdMembers
  
  _app_trace("processIndividualClusterMemberSettings(serverConfigInfo,%s,%s,%s)" % (memberNode,memberName,memberPrefix),"entry")
  
  try:
      serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (memberNode, memberName))
      existingProps = None
      
      # Get node Id for dynamic variable support
      nodeId = AdminConfig.getid("/Node:%s/" % (memberNode))
      if (not isEmpty(nodeId)):
          setDynamicId("CURRENT_NODE", nodeId)
      
      
      if (isEmpty(serverId) or isEmpty(nodeId)):
        _app_message("Failed to Modify cluster member %s on %s. Invalid node/server names." % (memberName, memberNode))
        exit()
      else:
        
        # What we do to the cluster member depends on if it was created by this script
        # or was already existing
        createdClusterValue = createdMembers.get("%s.%s" % (memberName, memberNode))
        if (createdClusterValue == None):
          # This member already existed
          _app_message("Updating existing cluster member %s on %s" % (memberName, memberNode))
          existingProps = getApplicationServerInfo(serverId)
        else:
          # This member was just created
          if (applyTemplateSettingsToNewMembers):
              # The new member has already had settings applied
                           
              _app_message("Already applied template settings to new cluster member %s on %s" % (memberName, memberNode))
              serverId = None
          
          else:   
            _app_message("Applying settings to new cluster member %s on %s" % (memberName, memberNode))
            existingProps = None
            if (progInfo.get("app.forceExistingProps","false").lower() == "true"):
              existingProps = getApplicationServerInfo(serverId)
            
          #endelse
        
        #endelse
          
        # Proceed if settings are to be applied to cluster member
        if (serverId != None):
      
          # Get and set up the keys used with @DYNAMIC("KEYWORD",keyword)
          keyProps = getPropList(serverConfigInfo,"%s.dynamickeys" % (memberPrefix))
          setDynamicKeys(keyProps)
          
          # Process any explicit port definitions if we didn't handle it before
          if (createdClusterValue == None):
            setupApplicationServerPorts(serverConfigInfo,memberNode,memberName,memberPrefix)

          setupApplicationServer(serverConfigInfo,serverId, memberPrefix,existingProps)
          _app_message("Done processing settings for cluster member %s on %s" % (memberName, memberNode))
          
          # Now that we're done with this server, make sure we don't accidentally reuse its special keys
          removeDynamicKeys(keyProps)

        #end if ok to setup member
        
        
  except:
    _app_trace("Unexpected error in processIndividualClusterMemberSettings","exception")
    exit()
  
  
  _app_trace("processIndividualClusterMemberSettings()","exit")
    
#enddef processIndividualClusterMemberSettings

#------------------------------------------------------------------------------------------------------------------
# processClusterMemberSettings
# 
# The configuration input may have settings to be applied to individual cluster members.  Loop through all of 
# the clusters and update member application servers with the specified settings.
# 
# This processing is done after the member has been created
# 
# This memthod was previously named setupClusterMembers
#------------------------------------------------------------------------------------------------------------------
def processClusterMemberSettings(serverConfigInfo):

  global createdMembers
  # Setup cluster members
  if not serverConfigInfo.has_key("app.cluster.count"):
    return

  for cidx in range(1, int(serverConfigInfo["app.cluster.count"]) + 1):
    prefix = "app.cluster.%d" % (cidx)

    try:
      clusterName   = serverConfigInfo["%s.name" % (prefix)]
    except:
      _app_message("Skipping SetupClusterMembers for %s" % (prefix))
      continue

    if not serverConfigInfo.has_key("%s.clustermember.count" % prefix):
      continue

    if (clusterName.find("@ITERATE") >= 0):
      # This is a special case for applying settings to multiple clusters and
      # their members. This processing is only handled in processClusters()
      # Go on to the next definition
      continue
    
    # Get cluster ID for dynamic variable support 
    clusterId = AdminConfig.getid("/ServerCluster:%s/"%clusterName)
    if (not isEmpty(clusterId)):
        setDynamicId("CURRENT_CLUSTER",clusterId)
        
    if serverConfigInfo.has_key("%s.startingPort"% (prefix)):
      setDynamicId(clusterName+".STARTING_PORT", serverConfigInfo["%s.startingPort" % (prefix)])
    
    # Determine if we're going to skip new members in this processing   
    applyTemplateSettingsToNewMembers = 0
    
    if serverConfigInfo.has_key("%s.clusterTemplate.applyTemplateSettingsToNewMembers" % prefix) :
        if (serverConfigInfo["%s.clusterTemplate.applyTemplateSettingsToNewMembers" % prefix] == "true"):
            applyTemplateSettingsToNewMembers = 1
    
    _app_message(" ")
    _app_message("Processing server specific settings for cluster %s" % clusterName)
    _app_message(" ")
    
    
    # Setup cluster members
    variableMembers = serverConfigInfo.get("%s.variableMembers" % prefix,"false")
    variableServers = None
    if (variableMembers.lower() == "true"):
      variableServers = serverConfigInfo.get("%s.variableMembers.servers" % prefix,"")
        
      # Create a copy of the serverConfigInfo to dynamically modify
      tempServerConfigInfo = filterProperties(serverConfigInfo,prefix)
        
      variableServersList = variableServers.split(" ")
      for nodeserver in variableServersList:
        nodeserversplit = nodeserver.split(":")
        if (len(nodeserversplit) != 2):
          raise StandardError("Invalid dynamic members syntax: %s" % variableServers)
          
        memberNode = nodeserversplit[0]
        memberName = nodeserversplit[1]
          
        tempServerConfigInfo["%s.clustermember.1.name" % prefix] = memberName
        tempServerConfigInfo["%s.clustermember.1.node" % prefix] = memberNode
          
        
        processIndividualClusterMemberSettings(tempServerConfigInfo, memberNode, memberName, "%s.clustermember.1" % (prefix),applyTemplateSettingsToNewMembers)         
    else:
      # Statically defined member names
      for cmidx in range(1, int(serverConfigInfo.get("%s.clustermember.count" %(prefix),"0")) + 1):
        try:
          memberName    = serverConfigInfo["%s.clustermember.%d.name" % (prefix, cmidx)]
        except:
          _app_message("Skipping SetupClusterMember %s.clustermember.%d" % (prefix, cmidx))
          continue
  
        memberNode    = serverConfigInfo["%s.clustermember.%d.node" % (prefix, cmidx)]
        
        processIndividualClusterMemberSettings(serverConfigInfo, memberNode, memberName, "%s.clustermember.%d" % (prefix, cmidx),applyTemplateSettingsToNewMembers)
              
        _app_message(" ")
        
      #endfor each cluster member in definition
  
    #endelse
    

#enddef

#-------------------------------------------------------------------------------
# processMatchingDynamicClusters
#
# This function is called with the dynamic cluster name is the @ITERATE(wildcard) macro.
# It will find clusters that match the pattern and apply the dynamic cluster and template settings 
# against them.
#-------------------------------------------------------------------------------
def processMatchingDynamicClusters(serverConfigInfo,prefix, nameProperty ):
  try:
    
    iterateParms = parseFunctionParms(nameProperty)
    if (len(iterateParms) == 0):
      clusterPattern = wildcardToRegExpString("*")
    else:
      clusterPattern =  wildcardToRegExpString(iterateParms[0])
      
    matchingIds = findMatchingDynamicClusters(clusterPattern)
    
    _app_message("%d clusters match the name pattern for %s" % (len(matchingIds),nameProperty))
    for clusterTuple in matchingIds:
      clusterName,dynamicClusterId,clusterId = clusterTuple
      
      # Store cluster ID for dynamic variable support
      setDynamicId("CURRENT_CLUSTER",clusterId)
      
      if serverConfigInfo.has_key("%s.startingport"% (prefix)):
        setDynamicId(clusterName+".STARTING_PORT", serverConfigInfo["%s.startingport" % (prefix)])

      
      # See if we want to modify the DynamicCluster settings
      existingProps = getDynamicClusterProperties(dynamicClusterId)
      dynamicClusterProperties = getPropListDifferences(serverConfigInfo,"%s.dc" % prefix, existingProps, "dc")
      dynamicClusterCustomProperties = getPropListDifferences(serverConfigInfo,"%s.dc.properties" % prefix, existingProps, "dc.properties")
      
      if (len(dynamicClusterProperties) > 0 or len(dynamicClusterCustomProperties) > 0):
        _app_message("Applying modified DynamicCluster properties to %s" % clusterName)
        updateDynamicCluster(dynamicClusterId,clusterName,dynamicClusterProperties,dynamicClusterCustomProperties)
        _app_message("Updated DynamicCluster properties for existing DynamicCluster %s" % clusterName)
      
      
      # Now do cluster template settings
      processClusterTemplateSettings(serverConfigInfo,prefix, clusterId,clusterName,dynamicClusterId)  
      
      processAllClusterMemberDefinitions = serverConfigInfo.get("%s.processAllClusterMemberDefinitions" % prefix,"false")
      if (processAllClusterMemberDefinitions.lower() == "true"):
        # We want to process cluster members - assume that we'll only support iterate
        processAllClusterMemberPorts = serverConfigInfo.get("%s.processAllClusterMemberPorts" % prefix,"false")
        
        mapPortsToVirtualHost = serverConfigInfo.get("%s.mapPortsToVirtualHost" % prefix,"false")
        
        memberPrefix = "%s.clustermember.1" % (prefix)
        
        memberName = serverConfigInfo.get("%s.name" % memberPrefix, None)
        memberNode = serverConfigInfo.get("%s.node" % memberPrefix, None)
        
        if (not isEmpty(memberName) and memberName.startswith("@ITERATE")):          
          # Special case - apply all of the settings to all members
          # Fill the dictionary of existing cluster members
          tempstr = AdminConfig.list("ClusterMember", clusterId)
          if not isEmpty(tempstr):
            memberList = tempstr.splitlines()
            for member in memberList:
              mName = AdminConfig.showAttribute(member, "memberName")
              mNode = AdminConfig.showAttribute(member, "nodeName")
              _app_message(" ")
              _app_message("Processing member settings for cluster %s %s/%s" % (clusterName, mNode,mName))
              processDynamicClusterMember(serverConfigInfo,clusterName,clusterId,{},prefix,memberPrefix,
                                          mName, mNode,
                                          processAllClusterMemberDefinitions,processAllClusterMemberPorts,mapPortsToVirtualHost)

        else:
          _app_message("@ITERATE was not specified as the cluster member name, no cluster member settings will be processed")
          
      
  except:
    _app_trace("Unexpected error in processMatchingDynamicClusters","exception")
    exit()
    

#-------------------------------------------------------------------------------
# processDynamicClusterMember
#-------------------------------------------------------------------------------
def processDynamicClusterMember(serverConfigInfo,clusterName,clusterId,existingMembers,prefix,memberPrefix,
                                memberName, memberNode,
                                processAllClusterMemberDefinitions,
                                processAllClusterMemberPorts,mapPortsToVirtualHost):
  try:
      
      serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (memberNode, memberName))
      
      # Get node Id for dynamic variable support
      nodeId = AdminConfig.getid("/Node:%s/" % (memberNode))
      if (not isEmpty(nodeId)):
          setDynamicId("CURRENT_NODE", nodeId)
      
      # See if this member was created by the script
      memberId = existingMembers.get("%s@%s" % (memberName, memberNode))
      
      
      
      if (isEmpty(serverId) or isEmpty(nodeId)):
        _app_message("processDynamicClusterMember: Failed to modify cluster member %s on %s. Invalid node/server names." % (memberName, memberNode))
        exit()

      processSettings = 0
      processPort = 0
      existingMember = 0
      
      # See if this member was created by the script
      memberId = existingMembers.get("%s@%s" % (memberName, memberNode),None)
      
      if (memberId):
        existingMember = 1
        
        # See if we support processing of existing members
        if (processAllClusterMemberDefinitions.lower() == "true"):
          processSettings = 1
          if (processAllClusterMemberPorts.lower() == "true"):
            processPort = 1
          
      else:
        memberId = getClusterMemberId(clusterName, memberName, memberNode)
        if (isEmpty(memberId)):
          raise StandardError("Unable to find ClusterMember configuration for %s %s %s" % (clusterName, memberName, memberNode))
          
        processSettings = 1
        processPort = 1
      
      # Need code for port
      if (processPort):
        
        dynamicPort = 0
        memberStartingPort = serverConfigInfo.get("%s.startingport" % (memberPrefix), None)
        keepHostNames = 0
        keepHostNamesString = serverConfigInfo.get("%s.startingport.keepHostNames" % (memberPrefix),"false").lower()
        if (keepHostNamesString in ["true","yes"]):
          keepHostNames = 1
        
        if (not isEmpty(memberStartingPort)):
          
          if (memberStartingPort.find("DYNAMIC") > 0):
            dynamicPort = 1
            memberStartingPort = substituteDynamicValues("%s.startingport" % (memberPrefix), memberStartingPort)
          
            if (memberStartingPort.startswith("ERROR")):
              _app_message("Unable to determine dynamic port range for server %s %s" % (memberName,  memberNode))
              exit()
          
          if (existingMember):
            # If port is macro, see if ports are in range before we change them
            if (dynamicPort):
              pass
        
          if (processPort):
            amendVHost = 0
            if (not isEmpty(mapPortsToVirtualHost)):
              amendVHost = 1
              
            if (modifyApplicationServerPorts(memberName, memberNode, memberStartingPort, amendVHost, mapPortsToVirtualHost,keepHostNames)):
              _app_message("Error modifying ports for cluster %s member %s/%s" % (clusterName, memberNode, memberName))
              exit()
            else:
              _app_message("Modified ports for cluster %s member %s/%s" % (clusterName, memberNode, memberName))
        else:
          #Process settings for individual ports
          setupApplicationServerPorts(serverConfigInfo,memberNode,memberName,memberPrefix)
      
      # Need code for weight
      memberWeight = serverConfigInfo.get("%s.weight"%memberPrefix,None)
      if (memberWeight != None):
        # See if it needs to be updated
        currentWeight = AdminConfig.showAttribute(memberId,"weight")
        if (currentWeight != memberWeight):
          if (modifyObject(memberId,[ ["weight",memberWeight] ])):
            raise StandardError("Unable to update weight for cluster %s member %s/%s" % (clusterName, memberNode, memberName))
          else:
            _app_message("Updated weight (from %s to %s) for cluster %s member %s/%s" % (currentWeight,memberWeight, clusterName, memberNode, memberName))
            
      
      if (processSettings):
        # Process the server settings
        _app_message("Non-template settings will be applied to member in cluster %s: %s/%s" % (clusterName, memberNode, memberName))
        
        existingProps = getApplicationServerInfo(serverId)
        setupApplicationServer(serverConfigInfo,serverId, memberPrefix,existingProps)
      else:
        _app_message("Non-template settings will not be applied to existing member in cluster %s: %s/%s" % (clusterName, memberNode, memberName))
          
  except:
    _app_trace("Unexpected error in processDynamicClusterMember","exception")
    exit()

#enddef
  

#-------------------------------------------------------------------------------
# processDynamicClusters
#-------------------------------------------------------------------------------
def processDynamicClusters(serverConfigInfo):

  global createdMembers
  
  # Create clusters
  if not serverConfigInfo.has_key("app.dyncluster.count"):
    return
    
  # Create a properties set that we'll use to keep track of new servers that are created
  try:
    if (createdMembers == None):
      createdMembers = java.util.Properties()
  except NameError:
    createdMembers = java.util.Properties()
    
  

  for cidx in range(1, int(serverConfigInfo["app.dyncluster.count"]) + 1):
    
    existingMembers = {}
    firstMember = None
    firstMemberName = None
    firstMemberNode = None
    
    prefix = "app.dyncluster.%d" % (cidx)
    
    clusterName = serverConfigInfo.get("%s.name" % prefix, None)
    if isEmpty(clusterName):
      continue
      
    if (clusterName.find("@ITERATE") >= 0):
      # This is a special case for applying settings to multiple clusters and
      # their members
      processMatchingDynamicClusters(serverConfigInfo,prefix, clusterName )
      
      # Go on to the next definition
      continue
      
    
    clusterPrefer = "true"
    createDomain = "false"
    
    try:
      clusterPrefer = serverConfigInfo["%s.preferlocal" % (prefix)].lower()
    except:
      clusterPrefer = "true"

    try:
      createDomain  = serverConfigInfo["%s.createDomain" % (prefix)].lower()
    except:
      createDomain = "false"
      
    templateServer = serverConfigInfo.get("%s.templateServer"%prefix,"")
    
    if (isEmpty(templateServer)):
      templateServer = serverConfigInfo.get("%s.template"%prefix,"")
    if (isEmpty(templateServer)):
      templateServer = serverConfigInfo.get("%s.templateName"%prefix,"")
    
      
    try:
      mapPortsToVirtualHost = serverConfigInfo["%s.mapPortsToVirtualHost" % (prefix)]
    except:
      mapPortsToVirtualHost = None
      
    coregroupName = serverConfigInfo.get("%s.moveClusterToCoreGroup" % prefix, "")
      
    clusterId = AdminConfig.getid("/ServerCluster:%s/" % (clusterName))
    dynamicClusterId = AdminConfig.getid("/DynamicCluster:%s/" % (clusterName))
    
    if (isEmpty(dynamicClusterId) and not isEmpty(clusterId)):
      # This is an error condition, we should not reach this point
      _app_message("Cluster %s exists as normal cluster, not dynamic" % clusterName)
      raise StandardError("Cluster %s exists as normal cluster, not dynamic" % clusterName)
 
    if not isEmpty(dynamicClusterId):
      _app_message("Cluster %s already exists" % (clusterName))
      
      # Store cluster ID for dynamic variable support 
      setDynamicId("CURRENT_CLUSTER",clusterId)
      
      # Fill the dictionary of existing cluster members
      tempstr = AdminConfig.list("ClusterMember", clusterId)
      if not isEmpty(tempstr):
        memberList = tempstr.split(progInfo["line.separator"])
        for member in memberList:
          mName = AdminConfig.showAttribute(member, "memberName")
          mNode = AdminConfig.showAttribute(member, "nodeName")
          existingMembers["%s@%s" % (mName,mNode)] = member
          if (firstMember == None):
            firstMember = member
            firstMemberName = mName
            firstMemberNode = mNode

      
      # See if we want to modify the DynamicCluster settings
      existingProps = getDynamicClusterProperties(dynamicClusterId)
      dynamicClusterProperties = getPropListDifferences(serverConfigInfo,"%s.dc" % prefix, existingProps, "dc")
      dynamicClusterCustomProperties = getPropListDifferences(serverConfigInfo,"%s.dc.properties" % prefix, existingProps, "dc.properties")
      
      if (len(dynamicClusterProperties) > 0 or len(dynamicClusterCustomProperties) > 0):
        _app_message("Applying modified DynamicCluster properties to %s" % clusterName)
        updateDynamicCluster(dynamicClusterId,clusterName,dynamicClusterProperties,dynamicClusterCustomProperties)
        _app_message("Updated DynamicCluster properties for existing DynamicCluster %s" % clusterName)
      
      
      # Now do cluster template settings
      processClusterTemplateSettings(serverConfigInfo,prefix, clusterId,clusterName,dynamicClusterId)
      

      
    else:
      
      if (isEmpty(coregroupName)):
        # Since this is a create, check for top level property
        coregroupName = serverConfigInfo.get("%s.coreGroup" % prefix,"")
      
      clusterArgs = {}
      clusterArgs["preferLocal"] = clusterPrefer
      clusterArgs["createDomain"] = createDomain
      
      if (not isEmpty(templateServer)):
        clusterArgs["templateName"] = templateServer
      

        
      
      if (not isEmpty(coregroupName)):
        clusterArgs["coreGroup"] = coregroupName
        
      dynamicClusterArgs = getPropList(serverConfigInfo,"%s.dc" % prefix)
      
      customPropertyArgs = getPropList(serverConfigInfo,"%s.dc.properties" % prefix)
      
      if (isEmpty(templateServer)):
        serverType = dynamicClusterArgs.get("serverType")
        if (serverType == "APPLICATION_SERVER"):
          clusterArgs["templateName"] = "default"
        elif (serverType == "ONDEMAND_ROUTER"):
          clusterArgs["templateName"] = "odr"
          
      
      _app_message("Creating dynamic cluster %s ..." % (clusterName))
      dynamicClusterId,clusterId = createDynamicCluster(clusterName, dynamicClusterArgs, clusterArgs, customPropertyArgs)
      if isEmpty(clusterId):
        _app_message("Failed to create cluster %s" % (clusterName))
        exit()
      else:
        _app_message("Created dynamic cluster %s" % (clusterName))
      
      # Store cluster ID for dynamic variable support 
      setDynamicId("CURRENT_CLUSTER",clusterId)

        
      # Now do cluster template settings - will always do this for a new cluster
      processClusterTemplateSettings(serverConfigInfo,prefix, clusterId,clusterName,dynamicClusterId)
          
    # end else need to create cluster
    
    # Store cluster ID for dynamic variable support 
    if (not isEmpty(clusterId)):
        setDynamicId("CURRENT_CLUSTER",clusterId)
    
    if serverConfigInfo.has_key("%s.startingport"% (prefix)):
      setDynamicId(clusterName+".STARTING_PORT", serverConfigInfo["%s.startingport" % (prefix)])

    if serverConfigInfo.has_key("%s.endingport"% (prefix)):
      setDynamicId(clusterName+".ENDING_PORT", serverConfigInfo["%s.endingport" % (prefix)])


    if not serverConfigInfo.has_key("%s.clustermember.count" % prefix):
      continue
      
    applyTemplateToNew = serverConfigInfo.get("%s.clusterTemplate.applyTemplateSettingsToNewMembers" % prefix,"false")
    if (applyTemplateToNew.lower() == "true"):
      tempstr = AdminConfig.list("ClusterMember", clusterId)
      if not isEmpty(tempstr):
        memberList = tempstr.splitlines()
        for member in memberList:
          mName = AdminConfig.showAttribute(member, "memberName")
          mNode = AdminConfig.showAttribute(member, "nodeName")
          memberId = existingMembers.get("%s@%s" % (mName,mNode),None)
          if (memberId == None):
            _app_message(" ")
            _app_message("Applying template settings to new cluster member in cluster %s %s/%s" % (clusterName, mNode,mName))
            processDynamicClusterMember(serverConfigInfo,clusterName,clusterId,existingMembers,prefix,
                                        "%s.clusterTemplate" % prefix, mName, mNode,
                                        "true","false","")
    
    
    #endif applyTemplateToNew

    
    # Now this is where things get a bit tricky. Normally a dynamic cluster member setting
    # is controlled by the template. One only need to update the template to update all 
    # cluster members.  However, there may be cases where members need to be individually 
    # cusomized.  We'll try to do that only when necessary with special property switches
    
    processAllClusterMemberDefinitions = serverConfigInfo.get("%s.processAllClusterMemberDefinitions"%prefix,"false")
    processNewClusterMemberDefinitions = serverConfigInfo.get("%s.processNewClusterMemberDefinitions"%prefix,"false")
    processAllClusterMemberPorts = serverConfigInfo.get("%s.processAllClusterMemberPorts"%prefix,"false")
    
    if (processAllClusterMemberDefinitions.lower() == "true" or processNewClusterMemberDefinitions.lower() == "true"):
      
      clusterMemberCount = int(serverConfigInfo.get("%s.clustermember.count" % prefix,"0"))
      
      if (clusterMemberCount > 0):
        # Do processing for statically defined members
        
        # Create cluster members
        for cmidx in range(1, int(serverConfigInfo["%s.clustermember.count" %(prefix)]) + 1):
      
          _app_message(" ")
        
        
          memberPrefix = "%s.clustermember.%d" % (prefix,cmidx)
          
          memberName = serverConfigInfo.get("%s.name" % memberPrefix, None)
          memberNode = serverConfigInfo.get("%s.node" % memberPrefix, None)
          
          if (isEmpty(memberName)):
            continue
          
          if (memberName.startswith("@ITERATE")):
            # Special case - apply all of the settings to all members
            # Fill the dictionary of existing cluster members
            tempstr = AdminConfig.list("ClusterMember", clusterId)
            if not isEmpty(tempstr):
              memberList = tempstr.splitlines()
              for member in memberList:
                mName = AdminConfig.showAttribute(member, "memberName")
                mNode = AdminConfig.showAttribute(member, "nodeName")
                _app_message(" ")
                _app_message("Processing member settings for cluster %s %s/%s" % (clusterName, mNode,mName))
                processDynamicClusterMember(serverConfigInfo,clusterName,clusterId,existingMembers,prefix,memberPrefix,
                                            mName, mNode,
                                            processAllClusterMemberDefinitions,processAllClusterMemberPorts,mapPortsToVirtualHost)

            
          else:
            processDynamicClusterMember(serverConfigInfo,clusterName,clusterId,existingMembers,prefix,memberPrefix,
                                        memberName, memberNode,
                                        processAllClusterMemberDefinitions,processAllClusterMemberPorts,mapPortsToVirtualHost)
        
        # end for each cluster member
      # end else staticly defined members
      
    # endif we want to process cluster member definitions
    
        
    if (not isEmpty(coregroupName)):
      try:
        _app_message(" ")
        oldCoreGroupName,newCoreGroupName =  addClusterToCoreGroup(clusterName, coregroupName)
        if (oldCoreGroupName == newCoreGroupName):
           _app_message("Cluster %s was already a member of core group %s" % (clusterName,newCoreGroupName))
        else:
          _app_message("Cluster %s was moved from core group %s to core group %s" % (clusterName,oldCoreGroupName,newCoreGroupName))
      except NameError:
        # core group functions not available
        _app_message("Unable to change core group settings because core group module is not available")
    
#enddef processDynamicClusters




  
#---------------------------------------------------------------------------------------------------
# updateEnvironment():
# This is the primary method for the configuration script.  It will process the input property file 
# which has been loaded into the serverConfigInfo object.
#---------------------------------------------------------------------------------------------------
def updateEnvironment():

  if progInfo["app.initialization.error"] == "true":
    _app_message("Exiting due to initialization error")
    exit()
    
  if (len(configInfo) == 0):
    _app_message("Configuration information is empty")
    _app_message("==================================================")
    _app_message("No configuration updates need to be saved")
    _app_message("Exiting updateEnvironment")
    return

  
  setDynamicId("CURRENT_CELL",getCellId())
  
  dmgrId = AdminConfig.getid("/Server:dmgr/")
  dmgrNodeId = getNodeForServer(dmgrId)
  
  setDynamicId("CURRENT_DMGR_SERVER",dmgrId)
  setDynamicId("CURRENT_DMGR_NODE",dmgrNodeId)
  
  # Process cell custom properties 
  try:
    processCell(configInfo)
  except NameError:
    _app_message("Skipping Cell custom properties. Module is not loaded")
  
  # Create any new core groups
  try:
    processCoreGroupCreation()
  except NameError:
    _app_message("Skipping new core group processing. Module is not loaded")
  
  try:
    processNodeGroups(configInfo)
    
    # Added the following to work around issue with dynamic cluster creation
    # with a new node group
    previewRun = progInfo.get("app.preview","false")
    # print "Preview: %s" % previewRun
    if (previewRun.lower() != "true"):
      forceSave = configInfo.get("app.nodegroups.forceSave","false")
      if (forceSave == "true"):
        _app_message("Saving configuration changes after node group processing...")
        _app_message("Changed artifacts...")
        _app_message(AdminConfig.queryChanges())
    
        _app_message("Saving...")
        AdminConfig.save()
        _app_message("Save complete")
  
        
  except NameError:
    _app_message("Skipping NodeGroup settings. Module is not loaded")

  try:
    processURIGroup(configInfo)
  except NameError:
    _app_message("Skipping URIGroup settings. Module is not loaded")
    

  
  # Process non-clustered application servers
  processApplicationServers(configInfo)         
  
  # Process Cluster definitions 
  processClusters(configInfo)
  
  # Process Cluster definitions 
  processClusterMemberSettings(configInfo)
  
  #Process the definitions for Dynamic Clusters
  processDynamicClusters(configInfo)
  
  # Process unmanaged nodes
  try:
    processUnmanaged()
  except NameError:
    _app_message("Skipping Unmanaged Nodes. Module is not loaded")
  
  # Process Web Server definitions
  try:
    processWebServers(configInfo)
  except NameError:
    _app_message("Skipping Web Servers. Module is not loaded")
  
  # Process J2C Authentication Aliases
  try:
    processJAASAliases()
  except NameError:
    _app_message("Skipping J2C Authentication Aliases. Module is not loaded")
  
  # Process environment variables
  try:
    processWASEnvironmentVariables()
  except NameError:
    _app_message("Skipping WebSphere Variables. Module is not loaded.")
  
  # Process Virtual Hosts
  try:
    processVirtualHosts()
  except NameError:
    _app_message("Skipping Virtual Hosts. Module is not loaded.")
  
  # Process JDBC providers and data sources
  try:
    processJDBC()
  except NameError:
    _app_message("Skipping JDBC resources. Module is not loaded.")
  
  # Process SIBus definitions
  try:
    processSIB()
  except NameError:
    _app_message("Skipping SIBus definitions. Module is not loaded.")
  
  # Process SIBus JMS resources
  try:
    processSIBJMS()
  except NameError:
    _app_message("Skipping SIBus JMS resources. Module is not loaded.")
  
  # Process MQ JMS resources
  try:
    processMQJMS()
  except NameError:
    _app_message("Skipping MQ JMS resources. Module is not loaded.")

  # Process Generic JMS resources
  try:
    processGenericJMS(configInfo)
  except NameError:
    _app_message("Skipping Generic JMS resources. Module is not loaded")

  try:
    processJ2CResourceAdapter(configInfo)
  except NameError:
    _app_message("Skipping J2CResourceAdapter resources. Module is not loaded")
    
      
  # Process Work Managers
  try:
    processWorkManagers()
  except NameError:
    _app_message("Skipping Work Managers. Module is not loaded.")
    
  try:
    processTimerManagerSettings(configInfo)
  except NameError:
    _app_message("Skipping Timer Managers. Module is not loaded")

  # Process Schedulers
  try:
    processSchedulers(configInfo)
  except NameError:
    _app_message("Skipping Schedulers. Module is not loaded.")

  # Process URL Providers and URL resources
  try:
    processURL(configInfo)
  except NameError:
    _app_message("Skipping URL Providers. Module is not loaded")
    
  # Process shared library definitiona
  try:
    processSharedLibraries()
  except NameError:
    _app_message("Skipping Shared Libraries. Module is not loaded.")
  
  # Name space bindings
  try:
    processNameSpaceBindings()
  except NameError:
    _app_message("Skipping NameSpaceBindings. Module is not loaded.")
    
    
  # Data Replication Domains
  try:
    processReplicationDomain()
  except NameError:
    _app_message("Skipping Data Replication Domain. Module is not loaded.")

  try:
    processObjectCache()
  except NameError:
    _app_message("Skipping Object Cache. Module is not loaded.")
    
  try:
    processMail(configInfo)
  except NameError:
    _app_message("Skipping Mail resources. Module is not loaded")

  try:
    processResourceEnvironment(configInfo)
  except NameError:
    _app_message("Skipping Resource Environment Provider and Entries. Module is not loaded")
    
  try:
    processAppDeployment()
  except NameError:
    _app_message("Skipping Application Deployment. Module is not loaded.")

  try:
    processHealthManagementCustomActions(configInfo)  
  except NameError:
    _app_message("Skipping Custom Actions. Module is not loaded")
  
  try:
    processHealthClasses(configInfo)
  except NameError:
    _app_message("Skipping Health Policies. Module is not loaded")
  
  try:
    processElasticityCustomActions(configInfo)
  except NameError:
    _app_message("Skipping Elasticity Custom Actions. Module is not loaded")
  
  try:
    processElasticityClasses(configInfo)  
  except NameError:
    _app_message("Skipping Elasticity Operations. Module is not loaded")
    
  try:
    processServiceClasses(configInfo)
  except NameError:
    _app_message("Skipping Service Policies. Module is not loaded")

  try:
    processWorkClass(configInfo)
  except NameError:
    _app_message("Skipping WorkClass definitions. Module is not loaded")
      
  try:
    processIMControllers(configInfo)
  except NameError:
    _app_message("Skipping Intelligent Management Controllers. Module is not loaded")

  try:
    processCoreGroupSettings()
  except NameError:
    _app_message("Skipping core group settings. Module is not loaded")    

  try:
    processSecurity()
  except NameError:
    _app_message("Skipping security settings. Module is not loaded")    

  # Other components will have their own methods....


  # Phew!  And save
  if AdminConfig.hasChanges():
    _app_message("==================================================")
    _app_message("Changed artifacts...")
    _app_message(AdminConfig.queryChanges())
    
    previewRun = progInfo.get("app.preview","false")
    if (previewRun.lower() != "true"):
      _app_message("Saving...")
      AdminConfig.save()
      _app_message("Save complete")
    else:
      _app_message("Preview run complete. Discarding changes")
      AdminConfig.reset()
  else:
    _app_message("==================================================")
    _app_message("No configuration updates need to be saved")
  
  _app_message("Exiting updateEnvironment")


# end updateEnvironment


#---------------------------------------------------------------------------------------------------
# Main section
#---------------------------------------------------------------------------------------------------

if (len(sys.argv) > 0) :
    # Support command line arguments instead of relying on properties passed in
    propfile = sys.argv[0]
    System.setProperty("app.config.location",propfile)

loadermsg = System.getProperty("app.config.errors")
if (loadermsg != None and loadermsg != ""):
  print ""
  print "ERROR!!!"
  print "Unable to start due to the following errors: %s" % loadermsg
  exit(1)

initialise()
global progInfo
global configInfo
global createdMembers

updateEnvironment()

exit(0)
