##########################################################################
# File Name:    Loader.py
# Description:  This file loads all Jython scripts from scripts directory
#               and executes the initialise() function
#
##########################################################################

import sys
from java.io import FilenameFilter, File

#-------------------------------------------------------------------
# getUserInstallRoot - looks up the value of USER_INSTALL_ROOT for 
# the specified node
#------------------------------------------------------------------
def getUserInstallRoot(nodeName):
   import java
   retval = None
   

   try:
     varmap = AdminConfig.getid("/Node:%s/VariableMap:/" % nodeName)
     if (varmap != '' and varmap != None):
       entries = AdminConfig.list("VariableSubstitutionEntry",varmap).split(java.lang.System.getProperty("line.separator"))
       for entry in entries:
         if (entry == ''): continue
         symName = AdminConfig.showAttribute(entry,"symbolicName")
         if (symName == "USER_INSTALL_ROOT"):
           retval = AdminConfig.showAttribute(entry,"value")
           break
   except:
     exc_type,exc_value,exc_traceback = sys.exc_info()
     exceptionString = "%s %s" % (exc_type, exc_value)
     print "Error locating USER_INSTALL_ROOT: %s" % exceptionString
     
     import traceback
     stacklist = traceback.extract_stack()
     for stackdata in stacklist: 
       stackfile,stackln,stackfn,stacktext = stackdata
       print "%s %s %s %s" % (stackfile,stackln,stackfn,stacktext)
     
     
   return retval 

def massageArgs(inputArgs):
  retval = []
  nodeName = ""
  try:
    nodeName = AdminControl.getNode()
  except:
    return inputArgs
    
  profileRoot = getUserInstallRoot(nodeName)
  if (inputArgs != None and len(inputArgs) > 0):
    for temparg in inputArgs:
      if (temparg.find("PROFILE_ROOT") >= 0):
        temparg = temparg.replace("PROFILE_ROOT",profileRoot)
      if (temparg.find("DOWNLOAD_CONTENT") >= 0):
        temparg = temparg.replace("DOWNLOAD_CONTENT","%s/downloadedContent" % profileRoot)
      
      retval.append(temparg)
  return retval
  



#  Add files to be not automatically loaded to ignoreList in LOWER CASE
ignoreList = [ "loader.py", "buildenvironment.py" ]

class ff(FilenameFilter):
  def accept(self, dir, name):
    name = name.lower()
    if name[-3:] == ".py" and ignoreList.count(name) != 1:
      return 1

try:      
  loaderErrors = []
  
  myArgs = massageArgs(sys.argv)
      
    
  print "Args: %s" % myArgs  
  
  if (len(myArgs) > 0) :
    # Support command line arguments instead of relying on properties passed in
    propfile = myArgs[0]
    if (not propfile.startswith("-D")):
        java.lang.System.setProperty("app.config.location",propfile)
    
    if (len(myArgs) > 1):
        varfile = myArgs[1]
        if (not varfile.startswith("-D")):
          java.lang.System.setProperty("app.variable.location",varfile)
          
  # Support passing in -Dprop=val settings on the command line
  idx = 0
  while (idx < len(myArgs)):
      parm = myArgs[idx]
      idx += 1
      
      if (parm.startswith("-D")):
          parm = parm[2:]
          keyVal = parm.split("=")
          if (len(keyVal) == 2):
              propkey = keyVal[0]
              propval = keyVal[1]
              java.lang.System.setProperty(propkey,propval)
              
  SCRIPTS_DIR = java.lang.System.getProperty("app.config.scriptsdir")
  if (SCRIPTS_DIR == None):
      SCRIPTS_DIR = "./lib"
  
  scriptsFile = File(SCRIPTS_DIR)
  if (scriptsFile.exists()):
    fileList = File(SCRIPTS_DIR).list(ff())
  else:
    fileList = None
  
  if (fileList == None):
      print ""
      print "Unable to load library scripts - check to see if app.config.scriptsdir setting (%s) is correct" % SCRIPTS_DIR
      print ""
  else:
    # Finish initialization
    for file in fileList:
      fullFile = "%s/%s" % (SCRIPTS_DIR, file)
      # print "Loading " + fullFile + " from %s" % SCRIPTS_DIR
      try:
        execfile(fullFile)
      except SyntaxError:
        loadermsg = "Syntax error loading %s: %s" % (fullFile,sys.exc_info()[1])
        print loadermsg
        loaderErrors.append(loadermsg)
        
    if (len(loaderErrors) > 0):
      loadermsg = ""
      for errmsg in loaderErrors:
        loadermsg ="%s\n  %s" % (loadermsg,errmsg)
      
      java.lang.System.setProperty("app.config.errors",loadermsg)
      
    else:      
      #print "Calling initialize"  
      initialise()
except:
  for exc in sys.exc_info():
    print exc

#-------------------------------------------------------------------------
