# #!/bin/ksh

#---------------------------------------------------------------------------------------------------
# updateEnv.sh
#
# This script is used to invoke the wsadmin updateEnvironment.py script for the Update Environment function 
# which reads a property file to drive updates to a WebSphere cell. This script supports creation of 
# new servers and resources as well as updating servers and resources.
#
# To understand the property file syntax, use the dumpConfig.py script to produce a property file
# representation of a current cell.
#
# Dependencies:
#     updateEnvironment.py 
#       - the script to be launched by wsadmin
#     Loader.py 
#				- Initialization script invoked with the wsadmin -profile option to set up the
#         environment prior to invoking this scripts main entry point
#     updateEnv.properties
#       - Java system properties loaded by wsadmin -p option.  These properties 
#     lib/*.py 
#       - A set of utility scripts for common functions as well as wsadmin scripts for specific
#         configuration actions.  These scripts are loaded by Loader.py
#     logs 
#       - A log directory where stdout is redirected to a log file.
#     updatetrace.log 
#       - A trace file in the current working directory created by updateEnvironment.py This script 
#         erases the trace file before launching the wsadmin script
#
#
#
# Typical invocation:
#  	updateEnv.sh [optionalArguments]
# Optional Arguments: 
#		cell-properties-file [variable-properties-file]
#
#   cell-properties-file is the name of the property file containing settings to be applied to the cell.
#   if not specified on the command line, the app.config.location setting from updateEnv.properties will be used.
#
#   variable-properties-file is the name of the optional properties file that contains values
#   to be used if the cell-properties-file is designed to support variable replacement.  The 
#   app.variable.location property in updateEnv.properties can also be used.
#          
#     
# 
#---------------------------------------------------------------------------------------------------


[[ -e updatetrace.log ]] && rm updatetrace.log

LOG_FILE=logs/updateenv.`date +%Y%m%d_%H%M%S`.log
C:/WebSphere/NetworkDeployment8/profiles/ScriptingDmgr/bin/wsadmin.bat  -p updateEnv.properties -profile Loader.py -tracefile wsadmin.traceout -f updateEnvironment.py $* | tee $LOG_FILE

