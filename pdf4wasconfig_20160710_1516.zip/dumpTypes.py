

typelist = AdminConfig.types().splitlines()

typelist.sort()

for typeName in typelist:
  print typeName
  

print ""
print ""

for typeName in typelist:
  print ""
  print typeName
  attrs = AdminConfig.attributes(typeName).splitlines()
  for attr in attrs:
    print "  %s" % attr
    
  