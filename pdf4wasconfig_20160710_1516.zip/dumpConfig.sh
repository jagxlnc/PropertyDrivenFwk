# #!/bin/ksh

TS=`date +%Y%m%d_%H%M%S`

C:/WebSphere/NetworkDeployment8/profiles/ScriptingDmgr/bin/wsadmin.bat -f dumpConfig.py serverEnvs v7$TS $*
