# #!/bin/ksh

TS=`date +%Y%m%d_%H%M%S`

c:/WebSphere/NetworkDeployment61/profiles/SiemensConfigurationScriptingDmgr/bin/wsadmin.bat -f dumpConfig.py serverEnvs v7$TS $*
