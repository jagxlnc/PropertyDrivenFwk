

def processGenericJMSProviderDestinations(jmsConfigInfo,prefix,providerId,newProvider,destinationType,providerName,clusterName,nodeName,serverName):
  _app_trace("processGenericJMSProviderDestinations(jmsConfigInfo,%s,%s,%s,%s,%s,%s,%s,%s)" % (prefix,providerId,newProvider,destinationType,providerName,clusterName,nodeName,serverName),"entry")
  try:
    destinationCount = int(jmsConfigInfo.get("%s.count"%prefix,"0"))
    if (destinationCount):
      for didx in range(1,destinationCount+1):
        destinationName = jmsConfigInfo.get("%s.%d.name" % (prefix,didx),"")
        if (not destinationName):
          # partial list
          continue
        
        if (not newProvider):
          # See if the destination exists
          destinationId = findGenericJMSProviderDestination(providerName,destinationName,clusterName,nodeName,serverName)
        else:
          destinationId = None
        
        if (destinationId):
          # Update
          existingProps = getGenericJMSProviderDestinationProperties(destinationId)
          baseProps = getPropListDifferences(jmsConfigInfo, "%s.%d" % (prefix,didx), existingProps, "jmsdestination")
          resourceProps = getPropListDifferences(jmsConfigInfo, "%s.%d.propertySet.resourceProperties" % (prefix,didx), existingProps, "jmsdestination.propertySet.resourceProperties")          
          
          if ( len(baseProps) > 0 or len(resourceProps) > 0):
            # Need to do modify
            modifyGenericJMSProviderDestination(destinationId,destinationName,baseProps,resourceProps)
            _app_message("Updated JMS %s destination %s for provider %s" % (destinationType, destinationName, providerName))
          else:
            _app_message("No need to update JMS %s destination %s" % (destinationType, destinationName))
          
          
          #
        else:
          # Create
          baseProps = getPropList(jmsConfigInfo, "%s.%d" % (prefix,didx))
          resourceProps = getPropList(jmsConfigInfo, "%s.%d.propertySet.resourceProperties" % (prefix,didx))
                    
          destinationId = createGenericJMSProviderDestination(providerId,destinationName,baseProps,resourceProps)
          
          if (destinationId):
            _app_message("Created JMS %s destination %s for provider %s" % (destinationType, destinationName, providerName))
        
        
        
  except:
    _app_trace("Unexpected error in processGenericJMSProviderDestinations","exception")
    exit()
  _app_trace("processGenericJMSProviderDestinations()","exit")
  
  
# 
def processGenericJMSProviderFactories(jmsConfigInfo,prefix,providerId,newProvider,factoryType,providerName,clusterName,nodeName,serverName):
  _app_trace("processGenericJMSProviderFactories(jmsConfigInfo,%s,%s,%d,%s, %s,%s,%s,%s" % (prefix,providerId,newProvider,factoryType,providerName,clusterName,nodeName,serverName),"entry")
  try:
    
    factoryCount = int(jmsConfigInfo.get("%s.count"%prefix,"0"))
    if (factoryCount):
      for fidx in range(1,factoryCount+1):
        
        factoryName = jmsConfigInfo.get("%s.%d.name" % (prefix,fidx),"")
        if (not factoryName):
          # Partial list
          continue
          
        if (not newProvider):
          # See if the factory exists
          factoryId = findGenericJMSProviderConnectionFactory(providerName,factoryName,clusterName,nodeName,serverName)
        else:
          factoryId = None
            
        if (factoryId):
          existingProps = getGenericJMSProviderConnectionFactoryProperties(factoryId)
          
          baseProps = getPropListDifferences(jmsConfigInfo, "%s.%d" % (prefix,fidx), existingProps, "jmsfactory")
          customProps = getPropListDifferences(jmsConfigInfo,"%s.%d.customProperties" % (prefix,fidx), existingProps, "jmsfactory.customProperties")
          resourceProps = getPropListDifferences(jmsConfigInfo, "%s.%d.propertySet.resourceProperties" % (prefix,fidx), existingProps, "jmsfactory.propertySet.resourceProperties")
          connectionPoolProps = getPropListDifferences(jmsConfigInfo, "%s.%d.connectionPool" % (prefix,fidx), existingProps, "jmsfactory.connectionPool")
          connectionPoolCustomProps  = getPropListDifferences(jmsConfigInfo, "%s.%d.connectionPool.customProperties" % (prefix,fidx), existingProps, "jmsfactory.connectionPool.customProperties")
          sessionPoolProps = getPropListDifferences(jmsConfigInfo, "%s.%d.sessionPool" % (prefix,fidx), existingProps, "jmsfactory.sessionPool")
          sessionPoolCustomProps = getPropListDifferences(jmsConfigInfo, "%s.%d.sessionPool.customProperties" % (prefix,fidx), existingProps, "jmsfactory.sessionPool.customProperties")
          mappingProps = getPropListDifferences(jmsConfigInfo, "%s.%d.mapping" % (prefix,fidx), existingProps, "jmsfactory.mapping")
          
          if (len(baseProps) > 0 or len(resourceProps) > 0 or 
              len(connectionPoolProps) > 0  or len(connectionPoolCustomProps) > 0 or
              len(sessionPoolProps) > 0 or len(sessionPoolCustomProps) > 0 or len(mappingProps) > 0):
                
                updateGenericJMSProviderFactory(factoryName,factoryId,baseProps,customProps,resourceProps,connectionPoolProps,connectionPoolCustomProps,
                                                      sessionPoolProps, sessionPoolCustomProps, mappingProps)
                
                _app_message("Updated JMS %s connection factory %s for JMS provider %s" % (factoryType, factoryName, providerName))
          
          else:
            _app_message("No update required for %s connection factory %s" % (factoryType, factoryName))
                    
        else:
          _app_message("Need to create factory %s" % factoryName )
          baseProps = getPropList(jmsConfigInfo, "%s.%d" % (prefix,fidx))
          customProps = getPropList(jmsConfigInfo,"%s.%d.customProperties" % (prefix,fidx))
          resourceProps = getPropList(jmsConfigInfo, "%s.%d.propertySet.resourceProperties" % (prefix,fidx))
          connectionPoolProps = getPropList(jmsConfigInfo, "%s.%d.connectionPool" % (prefix,fidx))
          connectionPoolCustomProps  = getPropList(jmsConfigInfo, "%s.%d.connectionPool.customProperties" % (prefix,fidx))
          sessionPoolProps = getPropList(jmsConfigInfo, "%s.%d.sessionPool" % (prefix,fidx))
          sessionPoolCustomProps = getPropList(jmsConfigInfo, "%s.%d.sessionPool.customProperties" % (prefix,fidx))
          mappingProps = getPropList(jmsConfigInfo, "%s.%d.mapping" % (prefix,fidx))
          
          factoryId = createGenericJMSProviderFactory(factoryName,providerId,baseProps,customProps,resourceProps,connectionPoolProps,connectionPoolCustomProps,
                                                      sessionPoolProps, sessionPoolCustomProps, mappingProps)
                                                      
          _app_message("Created %s connection factory %s for JMS provider %s" % (factoryType, factoryName, providerName))
            
  except:
    _app_trace("Unexpected error in processGenericJMSProviderFactories","exception")
    exit()
  _app_trace("processGenericJMSProviderFactories","exit")
  
  

def processGenericJMSProvider(jmsConfigInfo,prefix,providerName,clusterName,nodeName,serverName):
  _app_trace("processGenericJMSProvider(jmsConfigInfo,%s,%s,%s,%s,%s)" % (prefix,providerName,clusterName,nodeName,serverName),"entry")
  try:
    newProvider = 0
    
    providerId = findGenericJMSProvider(providerName,clusterName,nodeName,serverName)
    if (providerId):
      # Update
      _app_message("Provider %s exists" % providerName)
      
      # Get the current properties
      existingProps = getGenericJMSProviderProperties(providerId)
      

      baseProps = getPropListDifferences(jmsConfigInfo, prefix, existingProps, "jmsprovider")
      resourceProps = getPropListDifferences(jmsConfigInfo, "%s.propertySet.resourceProperties" % prefix, existingProps, "jmsprovider.propertySet.resourceProperties")
         
      
      if (len(baseProps) > 0 or len(resourceProps) > 0):
        
        updateGenericJMSProvider(providerId, baseProps, resourceProps)
        _app_message("Updated %d base properties and %d resource properties for JMSProvider %s" % (len(baseProps),len(resourceProps),providerName))
      else:
        _app_message("No base or resource properties updates needed for JMSProvider %s" % (providerName))
      
    else:
      # Create
      baseProps = getPropList(jmsConfigInfo, prefix)
      resourceProps = getPropList(jmsConfigInfo, "%s.propertySet.resourceProperties" % prefix)
      
      providerId = createGenericJMSProvider(providerName, clusterName, nodeName, serverName, baseProps, resourceProps)
      if (providerId):
        _app_message("Created new JMS Provider %s at scope %s %s %s" % (providerName, clusterName,nodeName,serverName))
      
      newProvider = 1
    
    # Process the providers
    processGenericJMSProviderFactories(jmsConfigInfo,"%s.genericConnectionFactories" %prefix,providerId,newProvider,"UNIFIED",providerName,clusterName,nodeName,serverName)
    processGenericJMSProviderFactories(jmsConfigInfo,"%s.queueConnectionFactories" %prefix,providerId,newProvider,"QUEUE",providerName,clusterName,nodeName,serverName)
    processGenericJMSProviderFactories(jmsConfigInfo,"%s.topicConnectionFactories" %prefix,providerId,newProvider,"TOPIC",providerName,clusterName,nodeName,serverName)
    
    # Process the destinations
    processGenericJMSProviderDestinations(jmsConfigInfo,"%s.queues" %prefix,providerId,newProvider,"QUEUE",providerName,clusterName,nodeName,serverName)
    processGenericJMSProviderDestinations(jmsConfigInfo,"%s.topics" %prefix,providerId,newProvider,"TOPIC",providerName,clusterName,nodeName,serverName)
      
  except:
    _app_trace("Unexpected error in processGenericJMSProvider","exception")
    exit()
    
  _app_trace("processGenericJMSProvider()","exit")
  
def processGenericJMS(jmsConfigInfo):
  _app_trace("processGenericJMS","entry")
  try:
    
    providerCount = int(jmsConfigInfo.get("app.genericjms.provider.count","0"))
    if (providerCount):
      for idx in range(1,providerCount+1):
        prefix = "app.genericjms.provider.%d" % idx
        
        providerName = jmsConfigInfo.get("%s.name"%prefix ,"")
        clusterName = jmsConfigInfo.get("%s.cluster"%prefix ,"")
        nodeName = jmsConfigInfo.get("%s.node"%prefix ,"")
        serverName = jmsConfigInfo.get("%s.server"%prefix ,"")
        
        if (providerName):
          processGenericJMSProvider(jmsConfigInfo,prefix,providerName,clusterName,nodeName,serverName)
          
       
    
  except:
    _app_trace("Unexpected error in processGenericJMS","exception")
    exit()
  _app_trace("processGenericJMS","exit")