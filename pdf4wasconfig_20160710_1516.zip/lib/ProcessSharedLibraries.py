#########################################################################################
# ProcessSharedLibraries.py
#
# This module contains the functions that process the Shared Library properties in the
# global configInfo dictionary.
#
# Primary function:
# 	processSharedLibraries()
#	 
# Related modules:
#		SharedLibraries.py - Utilitiles for find/create/modify Shared Library configuration
#   Utils.py - Utility functions
#
# Properties Syntax overview
# 
# # Each library has scope fields, blank in all means cell scoped
# app.library.<index>.cluster = 
# app.library.<index>.node    = 
# app.library.<index>.server  = 
# # Properties of library, isolatedClassLoader introduced in V7
# app.library.<index>.prop.name  = CellScopedLibrary
# app.library.<index>.prop.description  = This is a cell scoped library
# app.library.<index>.prop.classPath  = c:\jardir\one.jar;c:\jardir\two.jar;c:\jardir\three.jar
# app.library.<index>.prop.nativePath  = c:\lib;c:\lib\bin
# app.library.<index>.prop.isolatedClassLoader  = false
# ...
# app.library.count = <count>
# 
 


#----------------------------------------------------------------------------------------	
# processNewSharedLibrary
#----------------------------------------------------------------------------------------	
def processNewSharedLibrary(scopeId, scopeLabel, libraryName, prefix):

	global configInfo
	retval = None
	
	try:
		libProps = getPropList(configInfo, prefix)

		retval = createSharedLibrary(scopeId, libraryName, libProps)

	except:
		_app_trace("Unexpected error processing new shared library","exception")
		_app_message("Unexpected error processing new shared library %s" % libraryName)
		exit()

	return retval

#----------------------------------------------------------------------------------------	
# processExistingSharedLibrary
#----------------------------------------------------------------------------------------	
def processExistingSharedLibrary(libraryId, libraryName, prefix):

	global configInfo
	try:
		existingProps = getLibraryProperties(libraryId)
		if (existingProps == None):
				_app_message("Error getting existing properties for library %s" % (libraryName))
				exit()
		
		subProps = getPropListDifferences(configInfo, prefix, existingProps, "app.library")
		if (subProps.size() > 0):
				# Need to do update
				retval = updateSharedLibrary(libraryId, subProps)
				if (retval == None):
						_app_message("Error occurred updating shared library %s" % (libraryName))
						exit()
				else:
						_app_message("Updated shared library %s" % (libraryName))
		else:
				_app_message("No updates required for shared library %s" % (libraryName))
				
		
		
	except:
		_app_trace("Unexpected error updating existing library %s" % (libraryName),"exception")
		_app_message("Unexpected error updating existing library %s" % (libraryName))
		exit()
	
#-----------------------------------------------------------------------------------------
# processSharedLibraries
#-----------------------------------------------------------------------------------------
def processSharedLibraries():

	global configInfo
	
	try:
		
		if not configInfo.has_key("app.library.count"):
			_app_message("Skipping Shared Libraries...")
			return
    
		#	Create Library
		for jpidx in range(1, int(configInfo["app.library.count"]) + 1):
			prefix = "app.library.%d" % (jpidx)
			
			pName = configInfo.get("%s.prop.name" % (prefix),"")
			
			if (isEmpty(pName)):
					# We support partial lists, skip this if name is not there
					continue
			
			pCluster = configInfo.get("%s.cluster" % (prefix),"")
			pNode   = configInfo.get("%s.node" % (prefix),"")
			pServer = configInfo.get("%s.server" % (prefix),"")
			
			# Check for an existing shared library
			libraryId =  checkForExistingLibrary(pCluster, pNode, pServer, pName)
			if (libraryId == "ERROR"):
					_app_message("Error checking for existing library %s %s %s %s" % (pCluster, pNode, pServer, pName))
					exit()
			
			if (not isEmpty(libraryId)):
					processExistingSharedLibrary(libraryId, pName, prefix)
					continue
    
			retval = None
			pScope = ""
			if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
				pScope = "cell"
				cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
				for cell in cells:
					retval = processNewSharedLibrary(cell, pScope, pName, prefix)
					if isEmpty(retval):
						_app_message("Failed to create Library %s at %s scope" % (pName, pScope))
						exit()
				
			else:
				if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer): 
					pScope = "cluster"
					cluster = AdminConfig.getid("/ServerCluster:%s" % pCluster)
					retval = processNewSharedLibrary(cluster, pScope, pName, prefix)
					if isEmpty(retval):
						_app_message("Failed to create Library %s at %s scope" % (pName, pScope))
						exit()
				else:
					if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
						pScope = "node"
						node = AdminConfig.getid("/Node:%s" % pNode)
						retval = processNewSharedLibrary(node, pScope, pName, prefix)
						if isEmpty(retval):
							_app_message("Failed to create Library %s at %s scope" % (pName, pScope))
							exit()
					else:
						if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
							pScope = "server"
							server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
							retval = processNewSharedLibrary(server, pScope, pName, prefix)
							if isEmpty(retval):
								_app_message("Failed to create Library %s at %s scope" % (pName, pScope))
								exit()
    
			if (not isEmpty(retval)):
					_app_message("Created Library %s at scope %s %s%s %s" % (pName,pScope,pCluster,pNode,pServer))
    
	except:
		_app_message("Unexpected error processing shared library definitions","exception")
 		_app_message("Unexpected error processing shared library definitions")
 		exit()  

# enddef processSharedLibraries