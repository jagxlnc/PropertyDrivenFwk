################################################################################
# ProcessHealthClass.py
#  
# Handles the property instruction processing for HealthClass (health policy) 
# configurations.
#  
# Required modules: HealthClass.py
#                   Utils.py
#                   common.py
#
# Entry function:
#   processHealthClasses()
#
#      
#--------------------------
# Health Policies Propery Syntax examples
#
# Use the dumpConfig.py to produce samples based on existing configurations.
#--------------------------
# app.im.healthClass.1.name = CustomHealthPolicyOmega
# app.im.healthClass.1.prop.description = This is an example custom health policy
# app.im.healthClass.1.prop.reactionMode = 3
# app.im.healthClass.1.healthActions.1.type = HealthAction
# app.im.healthClass.1.healthActions.1.prop.actionType = THREADDUMP
# app.im.healthClass.1.healthActions.1.prop.stepNum = 1
# app.im.healthClass.1.healthActions.2.type = HealthAction
# app.im.healthClass.1.healthActions.2.prop.actionType = RESTART
# app.im.healthClass.1.healthActions.2.prop.stepNum = 2
# app.im.healthClass.1.healthActions.count = 2
# app.im.healthClass.1.HealthCondition.type = HealthCondition
# app.im.healthClass.1.HealthCondition.prop.conditionExpr = PMIMetric_FromLastInterval$threadPoolModule$activeThreads >= 30L
# app.im.healthClass.1.targetMemberships.1.type = TargetMembership
# app.im.healthClass.1.targetMemberships.1.prop.memberString = IMScriptingCell
# app.im.healthClass.1.targetMemberships.1.prop.type = 4
# app.im.healthClass.1.targetMemberships.count = 1

# app.im.healthClass.2.name = DailyRestartOmega
# app.im.healthClass.2.prop.reactionMode = 3
# app.im.healthClass.2.healthActions.1.type = HealthAction
# app.im.healthClass.2.healthActions.1.prop.actionType = RESTART
# app.im.healthClass.2.healthActions.1.prop.stepNum = 1
# app.im.healthClass.2.healthActions.count = 1
# app.im.healthClass.2.HealthCondition.type = AgeCondition
# app.im.healthClass.2.HealthCondition.prop.ageUnits = 4
# app.im.healthClass.2.HealthCondition.prop.maxAge = 7
# app.im.healthClass.2.targetMemberships.1.type = TargetMembership
# app.im.healthClass.2.targetMemberships.1.prop.memberString = DynamicAlpha
# app.im.healthClass.2.targetMemberships.1.prop.type = 3
# app.im.healthClass.2.targetMemberships.count = 1

# app.im.healthClass.3.name = GCPolicyOmega
# app.im.healthClass.3.prop.description = This is a GC Policy for multiple clusters
# app.im.healthClass.3.prop.reactionMode = 2
# app.im.healthClass.3.healthActions.1.type = HealthAction
# app.im.healthClass.3.healthActions.1.prop.actionType = HEAPDUMP
# app.im.healthClass.3.healthActions.1.prop.stepNum = 1
# app.im.healthClass.3.healthActions.2.type = CustomHealthAction
# app.im.healthClass.3.healthActions.2.prop.actionName = GrabDumps
# app.im.healthClass.3.healthActions.2.prop.actionType = CUSTOM
# app.im.healthClass.3.healthActions.2.prop.stepNum = 2
# app.im.healthClass.3.healthActions.2.prop.targetServer = Node agent of the sick server
# app.im.healthClass.3.healthActions.3.type = HealthAction
# app.im.healthClass.3.healthActions.3.prop.actionType = THREADDUMP
# app.im.healthClass.3.healthActions.3.prop.stepNum = 3
# app.im.healthClass.3.healthActions.4.type = HealthAction
# app.im.healthClass.3.healthActions.4.prop.actionType = RESTART
# app.im.healthClass.3.healthActions.4.prop.stepNum = 4
# app.im.healthClass.3.healthActions.count = 4
# app.im.healthClass.3.HealthCondition.type = GCPercentageCondition
# app.im.healthClass.3.HealthCondition.prop.garbageCollectionPercent = 30
# app.im.healthClass.3.HealthCondition.prop.samplingPeriod = 7
# app.im.healthClass.3.HealthCondition.prop.samplingUnits = 3
# app.im.healthClass.3.targetMemberships.1.type = TargetMembership
# app.im.healthClass.3.targetMemberships.1.prop.memberString = DynamicBeta
# app.im.healthClass.3.targetMemberships.1.prop.type = 3
# app.im.healthClass.3.targetMemberships.2.type = TargetMembership
# app.im.healthClass.3.targetMemberships.2.prop.memberString = DynamicAlpha
# app.im.healthClass.3.targetMemberships.2.prop.type = 3
# app.im.healthClass.3.targetMemberships.count = 2
# app.im.healthClass.count = 3
#
# -- Deletion syntax --
# del.im.healthClass.1.name = GCPolicyOmega
# del.im.healthClass.2.name = GCPolicyDelta
# del.im.healthClass.count = 2
################################################################################ 

#---------------------------------------------------------------------
# processHealthClassDeletions
#---------------------------------------------------------------------
def processHealthClassDeletions(healthClassConfig):
  _app_entry('processHealthClassDeletions(healthClassConfig)')
  
  try:
    prefix = "del.im.healthClass"
    hcCount = int(healthClassConfig.get("%s.count" % prefix,0))
    if (hcCount > 0):
      for idx in range(1,hcCount+1):
        hcName = healthClassConfig.get("%s.%d.name" % (prefix,idx),None)
        if (isEmpty(hcName)):
          # Partial list
          continue
          
        cfgId = deleteHealthClass(hcName)
        if (not isEmpty(cfgId)):
          _app_message("HealthClass %s has been deleted" % hcName)
        else:
          _app_message("HealthClass %s was not defined - no deletion necessary" % hcName)
  except:
    _app_exception("Unexpected problem with processHealthClassDeletions")
  
  _app_exit('processHealthClassDeletions()')
  


#---------------------------------------------------------------------
# getHealthActionsList
#---------------------------------------------------------------------
def getHealthActionsList(healthClassConfig,prefix):
  healthActions = []
  haCount = int(healthClassConfig.get("%s.healthActions.count" % prefix,0))
  for idx in range(1,haCount+1):
    haType = healthClassConfig.get("%s.healthActions.%d.type" % (prefix,idx))
    haProps = getPropList(healthClassConfig,"%s.healthActions.%d" % (prefix,idx))
    healthActions.append((haType,toDictionary(haProps)))
  
  return healthActions

#---------------------------------------------------------------------
# getTargetMembershipList
#---------------------------------------------------------------------
def getTargetMembershipList(healthClassConfig,prefix):
  targetMemberships = []
  tmCount = int(healthClassConfig.get("%s.targetMemberships.count" % prefix ,0))
  for idx in range(1,tmCount+1):
    tmProps = getPropList(healthClassConfig,"%s.targetMemberships.%d" % (prefix,idx))
    targetMemberships.append(toDictionary(tmProps))
  
  return targetMemberships
    


#---------------------------------------------------------------------
# processIndividualHealthClass
#---------------------------------------------------------------------
def processIndividualHealthClass(healthClassConfig,hcName,prefix):
  _app_entry('processIndividualHealthClass(healthClassConfig,%s,%s)' % (hcName,prefix))
 
  try:
    hcId = None
    hcId = findHealthClass(hcName)
    if (not isEmpty(hcId)):
      #_app_message("HealthClass %s has been found" % hcName)
      hcProps = getHealthClassProperties(hcId)
      #for key in hcProps.keys():
      #  print "   %s = %s" % (key,hcProps[key])
    
      # Get the base properties
      hcBaseProps = getPropListDifferences(healthClassConfig,prefix,hcProps,"healthClass")
      
      # Now see if condition has changed
      conditionType = healthClassConfig.get("%s.HealthCondition.type" % prefix)
      existingConditionType = hcProps.get("healthClass.HealthCondition.type")
      conditionProps = None
      
      if (conditionType != existingConditionType):
        # Changing it is not supported by the script
        raise StandardError("HealthCondition update not supported, HealthClass=%s, current condition=%s, new condition=%s" % (hcName,existingConditionType,conditionType))
      
      conditionProps = getPropListDifferences(healthClassConfig,"%s.HealthCondition"%prefix, hcProps,"healthClass.HealthCondition")
      
      # Now see if actions are changed
      healthActions = getHealthActionsList(healthClassConfig,prefix)
      existingHealthActions = getHealthActionsList(hcProps,"healthClass")
      if (len(healthActions) == len(existingHealthActions)):
        # Need to see if they are duplicates
        # Lists of tuples can be compared for value equality
        if (healthActions == existingHealthActions):
          # Set to None so we won't update it
          healthActions = None
      
      # Now see if target memberships are changed
      targetMemberships = getTargetMembershipList(healthClassConfig,prefix)
      existingTargetMemberships = getTargetMembershipList(hcProps,"healthClass")
      if (len(targetMemberships) == len(existingTargetMemberships)):
        # Lists of dictionaries can be compared
        if (targetMemberships == existingTargetMemberships):
          # Set to None so we won't update it
          targetMemberships = None
      
      if (len(hcBaseProps) > 0 or len(conditionProps) > 0 or healthActions != None or targetMemberships != None):
        modifyHealthClass(hcId, hcBaseProps, conditionProps, healthActions, targetMemberships)
        _app_message("HealthClass %s has been updated" % hcName)
        #print "\nbp=%s\ncp=%s\nha=%s\ntm=%s\n" %( hcBaseProps,conditionProps,healthActions,targetMemberships)
      else:
        _app_message("HealthClass %s does not need to be updated" % hcName)
      
    else:
      hcProps = getPropList(healthClassConfig,prefix)
      conditionType = healthClassConfig.get("%s.HealthCondition.type" % prefix)
      conditionProps = getPropList(healthClassConfig,"%s.HealthCondition"%prefix)
      healthActions = getHealthActionsList(healthClassConfig,prefix)
      targetMemberships = getTargetMembershipList(healthClassConfig,prefix)
              
      hcId = createHealthClass(hcName, hcProps, conditionType, conditionProps, healthActions, targetMemberships)
      _app_message("HealthClass %s has been created" % hcName)
  except:
    _app_exception("Unexpected problem with processIndividualHealthClass")
  
  _app_exit('processIndividualHealthClass()')

#---------------------------------------------------------------------
# processHealthClasses
#---------------------------------------------------------------------
def processHealthClasses(healthClassConfig):
  _app_entry('processHealthClasses(healthClassConfig)')
  
  try:
    
    # Process deletions firsts
    processHealthClassDeletions(healthClassConfig)
    
    prefix = "app.im.healthClass"
    hcCount = int(healthClassConfig.get("%s.count" % prefix,0))
    if (hcCount > 0):
      for idx in range(1,hcCount+1):
        hcName = healthClassConfig.get("%s.%d.name" % (prefix,idx),None)
        if (isEmpty(hcName)):
          # Partial list
          continue
          
        processIndividualHealthClass(healthClassConfig,hcName,"%s.%d" % (prefix,idx))
  except:
    _app_exception("Unexpected problem with processHealthClasses")
  
  _app_exit('processHealthClasses()')
  