##########################################################################
# File Name:    SIBEngine.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere SIB Messaging Engines as well as settings
#               to manipulate the localization points for the Messagine Engine
#
#               createSIBEngine
#               deleteSIBEngine
#               listSIBEngines
#               getSIBEnginesForBusMember
#               trimSIBEngines
#               getSIBLocalizationPointProperties
#               updateLocalizationPoint
#
#wsadmin>AdminTask.help("createSIBEngine")
#'WASX8006I: Detailed help for command: createSIBEngine\n\nDescription: Create a messaging engine.\n\nTarget object:   None\n\nArguments:\n  *bus - The name of the bus to which the messaging engine is to belong.
#  node - To create a messaging engine on a server, supply node and server name, but not cluster name.
#  server - To create a messaging engine on a server, supply node and server name, but not cluster name.
#  cluster - To create a messaging engine on a cluster, supply cluster name, but not node and server name.
#  description - Description of the messaging engine.
#  initialState - Whether the messaging engine is started or stopped when the associated application server is first started. Until started, the messaging engine is unavailable. (Stopped | Started).
#  highMessageThreshold - The maximum total number of messages that the messaging engine can place on its message points.
#  fileStore - Indicates that a file store is to be created. No value is needed.
#  dataStore - Indicates that a data store is to be created. No value is needed.
#  logSize - The size, in megabytes, of the log file.
#  minPermanentStoreSize - The minumum size in megabytes of the permanent store file.
#  maxPermanentStoreSize - The maximum size, in megabytes, of the permanent store file.
#  unlimitedPermanentStoreSize - True if the permanent file store size has no limit, false otherwise.
#  permanentStoreDirectory - The name of the permanent store files directory.
#  minTemporaryStoreSize - The minumum size in megabytes of the temporary store file.
#  maxTemporaryStoreSize - The maximum size, in megabytes, of the temporary store file.
#  unlimitedTemporaryStoreSize - True if the temporary file store size has no limit, false otherwise.
#  temporaryStoreDirectory - The name of the temporary store files directory.
#  logDirectory - The name of the log files directory.
#  createDefaultDatasource - When adding a server to a bus, set this to true if a default datasource is required. When adding a cluster to a bus, this parameter must not be supplied.
#  datasourceJndiName - The JNDI name of the datasource to be referenced from the datastore created when the member is added to the bus.
#  authAlias - The name of the authentication alias used to authenticate the messaging engine to the data source.
#  createTables - Select this option if the messaging engine creates the database tables for the data store. Otherwise, the database administrator must create the database tables.
#  schemaName - The name of the database schema used to contain the tables for the data store.
#
# V8.5: 
#  restrictLongDBLock - Select this option to restrict the messaging engine from holding long enduring database locks.
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createSIBEngine: Create a SIB Engine
#
# SYNTAX:
#    createSIBEngine name, (cluster|node, server), bus, type
#
# PARAMETERS:
#    cluster	-	Cluster to assign Engine to
#    node	-	Node to assign Engine to
#    server	-	Server to assign Engine to
#    bus	-	Name of bus for this Engine
#    attrs	-	Attributes in the form of -name1 value1 -name2 value2 ...
#
# USAGE NOTES:
#    Creates a SIB Engine on the bus at the desired scope.  
#
# RETURNS:
#    ObjID	Object ID of new messaging engine
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addSIBEngine(cluster, node, server, bus, engineProps, dbProps, fileProps,customProps):
	return createSIBEngine(cluster, node, server, bus, engineProps, dbProps, fileProps,customProps)

def createSIBEngine(cluster, node, server, bus, engineProps, dbProps, fileProps, customProps):

	global progInfo

	retval = None
	
	dbParmMap = { 'dataSourceName': '-datasourceJndiName', 'authAlias':'-authAlias', 'createTables':'-createTables', 'schemaName':'-schemaName', 'restrictLongDBLock':'-restrictLongDBLock'}
	fileParmMap = { 'logSize':'-logSize' , 'minPermanentStoreSize':'-minPermanentStoreSize', 'maxPermanentStoreSize':'-maxPermanentStoreSize' ,  'unlimitedPermanentStoreSize':'-unlimitedPermanentStoreSize' , 'permanentStoreDirectory':'-permanentStoreDirectory' , 'minTemporaryStoreSize':'-minTemporaryStoreSize', 'maxTemporaryStoreSize':'-maxTemporaryStoreSize', 'unlimitedTemporaryStoreSize':'-unlimitedTemporaryStoreSize', 'temporaryStoreDirectory':'-temporaryStoreDirectory', 'logDirectory':'-logDirectory' }
	engineParmMap = { 'description': '-description', 'initialState':'-initialState', 'highMessageThreshold':'-highMessageThreshold', 'customGroup':'-targetGroups' }
	

	try:
		traceStr = "createSIBEngine(%s, %s, %s, %s, %s, %s, %s)" % (cluster, node, server, bus, engineProps, dbProps, fileProps)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		configID = getContainmentPath(cluster, node, server, 1)
		
		if isEmpty(configID):
			raise StandardError("Could not get containment path")
		
		if isEmpty(AdminConfig.getid(configID)):
			raise StandardError("No such target as %s to create SIB Engines for" % (configID))
			
		if isEmpty(bus):
			raise StandardError("SIBus Name not specified")
			
		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))
			
		attributes  = ' -bus "%s"' % (bus)
		
		if (dbProps == None):
				dbProps = java.util.Properties()
		
		if (fileProps == None):
				fileProps = java.util.Properties()
				
		if (dbProps.size() == 0 and fileProps.size() == 0):
				raise StandardError("No message store properties were supplied")
		
		if (dbProps.size() > 0):
			attributes += " -dataStore -createDefaultDatasource false "
				
			for key in dbProps.keys():
				if dbParmMap.has_key(key):
					val = dbProps.get(key)
					if (not isEmpty(val)):
							attributes = "%s %s %s" % (attributes, dbParmMap[key], val)
		else:
			attributes += " -fileStore"
				
			for key in fileProps.keys():
				if fileParmMap.has_key(key):
					val = fileProps.get(key)
					if (not isEmpty(val)):
							attributes = "%s %s %s" % (attributes, fileParmMap[key], val)
					
		if (engineProps != None and engineProps.size() > 0):
				for key in engineProps.keys():
						if engineParmMap.has_key(key):
								val = engineProps.get(key)
								if (isEmpty(val)):
										continue
										
								if (key == "description"):
										if (not val.startswith('"')):
												val ='"%s"' % val
							  
								if (key == "customGroup" and val.find("[") < 0):
								  # Need to convert to list format 
								  tempval = ""
								  tokens = val.split(";")
								  for token in tokens:
								    tempval = "%s [%s]" % (tempval, token)
								  val = "[ %s ]" % tempval
							    
								attributes = "%s %s %s" % (attributes, engineParmMap[key], val)
						

		if isEmpty(cluster):
			attributes += " -node %s -server %s" % (node, server)
		else:
			attributes += " -cluster %s" % (cluster)

		#	AdminTask.createSIBEngine() does not like the 'name' attribute even
		#	though AdminConfig.attributes('SIBMessagingEngine') shows it!!!

		#	Therefore we cannot check for the existence of an engine :(

		_app_trace("Running command: AdminTask.createSIBEngine('[%s]')" % (attributes))
		retval = AdminTask.createSIBEngine("[%s]" % (attributes))
		
		# Now need to update properties
		if (customProps != None and customProps.size() > 0):
			print retval
			updateCustomProperties(retval, "properties", "Property", customProps)

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()

	except:
		_app_trace("An error was encountered creating the SIB Engine", "exception")
		retval = None

	_app_trace("createSIBEngine(%s)" %(retval), "exit")
	return retval

##########################################################################
# findEngine
##########################################################################
def findEngine(engineName, bus, cluster, server, node):

	_app_trace("findEngine(%s, %s, %s, %s, %s)" % (engineName, bus, cluster, server, node), "entry")

	foundEngine = None
	try:
		
		# Find the engine
		if (not isEmpty(cluster)):
				# Get list from cluster
				messageEngines = AdminTask.listSIBEngines('[-bus "%s" -cluster %s]' % (bus, cluster))
		else:
				# Get list from server
				messageEngines = AdminTask.listSIBEngines('[-bus "%s" -server %s -node %s]' % (bus, server, node))
				
		foundEngine = None
		
		for me in wsadminToList(messageEngines):
				if (not isEmpty(me)):
						tempName = AdminConfig.showAttribute(me, "name")
						if (tempName == engineName):
								foundEngine = me
								break
	except:
		_app_trace("An error occurred searching for the SIB Engine","exception")
		foundEngine = None
		
	_app_trace("findEngine(result = %s)" % foundEngine, "exit")
	return foundEngine
	
##########################################################################
# findEngine
##########################################################################
def findFirstEngine(bus, cluster, server, node):

	foundEngine = None
	try:
	
		_app_trace("findEngine( %s, %s, %s, %s)" % ( bus, cluster, server, node), "entry")
		
		# Find the engine
		if (not isEmpty(cluster)):
				# Get list from cluster
				messageEngines = AdminTask.listSIBEngines('[-bus "%s" -cluster %s]' % (bus, cluster))
		else:
				# Get list from server
				messageEngines = AdminTask.listSIBEngines('[-bus "%s" -server %s -node %s]' % (bus, server, node))
				
		foundEngine = None
		
		for me in wsadminToList(messageEngines):
				if (not isEmpty(me)):
						foundEngine = me
						break
	except:
		_app_trace("An error occurred searching for the SIB Engine","exception")
		foundEngine = None
		
	_app_trace("findEngine(result = %s)" % foundEngine, "exit")
	return foundEngine

##########################################################################
# updateSIBEngine
#
# FUNCTION:
# 		Update an existing message engine
##########################################################################
def updateSIBEngine(engineName, cluster, node, server, bus, engineProps, dbProps, fileProps, customProps):

	global progInfo

	retval = None
	
	skipAttrs = ["busUuid", "uuid"]
	
	try:
		traceStr = "updateSIBEngine(%s %s, %s, %s, %s, %s, %s, %s)" % (engineName, cluster, node, server, bus, engineProps, dbProps, fileProps)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		configID = getContainmentPath(cluster, node, server, 1)
		
		if isEmpty(configID):
			raise StandardError("Could not get containment path")
		
		if isEmpty(AdminConfig.getid(configID)):
			raise StandardError("No such target as %s to create SIB Engines for" % (configID))
			
		if isEmpty(bus):
			raise StandardError("SIBus Name not specified")
			
		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))
			
		# Get the bus member
		memberId = findSIBusMember(bus, None, cluster, node, server)
		if (memberId == None):
				raise StandardError("No bus member was found for bus %s member = %s %s %s" % (bus, cluster, node, server))

		# Find the engine
		if (not isEmpty(cluster)):
				# Get list from cluster
				messageEngines = AdminTask.listSIBEngines('[-bus "%s" -cluster %s]' % (bus, cluster))
		else:
				# Get list from server
				messageEngines = AdminTask.listSIBEngines('[-bus "%s" -server %s -node %s]' % (bus, server, node))
				
		foundEngine = None
		
		for me in wsadminToList(messageEngines):
				if (not isEmpty(me)):
						tempName = AdminConfig.showAttribute(me, "name")
						if (tempName == engineName):
								foundEngine = me
								break
		
		if (foundEngine == None):
				raise StandardError("No message engine with name %s was found in bus %s" % (engineName, bus))
		
		
		
		if (engineProps != None and engineProps.size() > 0):
				if (engineProps.get("customGroup") != None):
				  modifyObject(foundEngine,[ ["customGroup",""]])
		  
				# Update attributes of engine
				engineAttrs = []
				for key in engineProps.keys():
						if not key in skipAttrs:
								engineAttrs.append([key, engineProps.get(key)])
				
				if (len(engineAttrs) > 0):
						if (modifyObject(foundEngine, engineAttrs)):
								raise StandardError("Error updating attriubtes of message engine %s in bus %s" % (engineName, bus))
								
		# Determine the message store type
		messageStoreType = AdminConfig.showAttribute(foundEngine, "messageStoreType")
		
		if (messageStoreType == "FILESTORE" and fileProps != None and fileProps.size() > 0):
				# Ok to update file store
				filestore = AdminConfig.showAttribute(foundEngine,"fileStore")
				fsattrs = ""
				for key in fileProps.keys():
						if not key in skipAttrs:
								fsattrs = "%s [%s %s]" % (fsattrs, key, fileProps.get(key))
				if (fsattrs != ""):
						fsattrs = "[ %s ]" % fsattrs
						if (modifyObject(filestore, fsattrs)):
								raise StandardError("Error updating filestore attributes for message engine %s in bus %s" % (engineName, bus))
								
		elif (messageStoreType == "DATASTORE" and dbProps != None and dbProps.size() > 0):
				# Ok to update database store
				datastore = AdminConfig.showAttribute(foundEngine,"dataStore")
				dsattrs = []
				for key in dbProps.keys():
						if not key in skipAttrs:
								dsattrs.append([key, dbProps.get(key)])
				if (len(dsattrs) > 0):
						if (modifyObject(datastore, dsattrs)):
								raise StandardError("Error updating datastore attributes for message engine %s in bus %s" % (engineName, bus))
								
		# Now need to update properties
		if (customProps != None and customProps.size() > 0):
			updateCustomProperties(foundEngine, "properties", "Property", customProps)
								
		# Return the message engine ID 
		retval = foundEngine
						
						
	
	except:
		_app_trace("Exception caught modifying message engine","exception")
		retval = None
		
	_app_trace("updateSIBEngine(%s)" %(retval), "exit")
	return retval



		

	
##########################################################################
#
# FUNCTION:
#    deleteSIBEngine: delete a SIB Engine
#
# SYNTAX:
#    deleteSIBEngine name, (cluster|node, server), bus, type
#
# PARAMETERS:
#    name	- 	SIB Engine name (Cluster only)
#    cluster	-	Cluster to delete Engine from
#    node	-	Node to delete Engine from
#    server	-	Server delete Engine from
#    bus	-	Name of bus for this Engine
#
# USAGE NOTES:
#    Deletes a SIB Engine from the bus at the desired scope.  
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBEngine(name, cluster, node, server, bus):
	deleteSIBEngine(name, cluster, node, server, bus)

def deleteSIBEngine(name, cluster, node, server, bus):

	global progInfo

	retval = 1

	try:
		traceStr = "deleteSIBEngine(%s, %s, %s, %s, %s)" % (name, cluster, node, server, bus)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		configID = getContainmentPath(cluster, node, server, 1)
		
		if isEmpty(configID):
			raise StandardError("Could not get containment path")
			
		if isEmpty(AdminConfig.getid(configID)):
			raise StandardError("No such target as %s to delete SIB Engines from" % (configID))
			
		if isEmpty(bus):
			raise StandardError("SIBus Name not specified")
			
		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))
			
		if not existsSIBEngine(name, bus, cluster, node, server):
			raise StandardError("Engine does not exist on bus %s" % (bus))
			
		attributes  = ' -bus "%s"' % (bus)

		if isEmpty(cluster):
			attributes += " -node %s -server %s" % (node, server)
		else:
			attributes += " -cluster %s" % (cluster)

			if not isEmpty(name):
				attributes += ' -engine "%s"' % (name)

		_app_trace("Running command: AdminTask.deleteSIBEngine(%s)" % (attributes))
		AdminTask.deleteSIBEngine(attributes)

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
			
		retval = 0
		
	except:
		_app_trace("An error was encountered deleting the SIB Engine", "exception")
		retval = 1

	_app_trace("deleteSIBEngine(%d)" %(retval), "exit")
	return retval
	

##########################################################################
#
# FUNCTION:
#    listSIBEngines: List SIB Engines on bus
#
# SYNTAX:
#    listEngines bus, displayFlag
#
# PARAMETERS:
#    bus	-	Name of bus for this Engine
#    displayFlag-	Boolean indicating whether to print list 
#			(default = 1)
# USAGE NOTES:
#    Lists SIB Engines on the bus.  
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showSIBEngines(bus, displayFlag = 1):
	listSIBEngines(bus, displayFlag)
	
def listSIBEngines(bus, displayFlag = 1):

	global progInfo
	
	retval = None
	
	try:
		traceStr = "listSIBJMSConnectionEngines(%s, %d)" % (bus, displayFlag)
		_app_trace(traceStr, "entry")	

		if isEmpty(bus):
			raise StandardError("SIBus Name not specified")
			
		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))
			
		attributes  = ' -bus "%s"' % (bus)

		_app_trace("Running command: AdminTask.listSIBEngines(%s)" % (attributes))
		str = AdminTask.listSIBEngines(attributes)

		if isEmpty(str):
			retval = []
		else:
			retval = str.split(progInfo["line.separator"])


		if displayFlag:
			print "\nSI Bus Engines\n-------------------"

			for r in retval:
				print AdminConfig.showAttribute(r, "name")

			print "-------------------"

	except:
		_app_trace("An error was encountered listing the SIB Engines", "exception")
		retval = None

	_app_trace("listSIBEngines(%s)" %(retval), "exit")
	return retval


#---------------------------------------------------------------------------------
# getSIBEnginesForBusMember
#
# Returns the list of Messaging Engine configuration IDs for the specified bus member.
#---------------------------------------------------------------------------------
def getSIBEnginesForBusMember(busName, memberCluster,memberNode=None,memberServer=None):
  _app_trace("getSIBEnginesForBusMember(%s,%s,%s,%s)" % (busName, memberCluster,memberNode,memberServer),"entry")
  retval = []
  
  try:
    if (not isEmpty(memberCluster)):
       # Get list from cluster
       messageEngines = AdminTask.listSIBEngines('[-bus "%s" -cluster %s]' % (busName, memberCluster))
    else:
       # Get list from server
       messageEngines = AdminTask.listSIBEngines('[-bus "%s" -server %s -node %s]' % (busName, memberServer, memberNode))
       
    retval = wsadminToList(messageEngines)
  except:
    _app_trace("Unexpected error in getSIBEnginesForBusMember","exception")
    raise StandardError("Unexpected error in getSIBEnginesForBusMember")
  
  _app_trace("getSIBEnginesForBusMember(%s)" % retval,"exit")
  return retval
  
#---------------------------------------------------------------------------------
# getSIBEngineNamesForBusMember
#
# Returns the list of Messaging Engine names for the specified bus member.
#---------------------------------------------------------------------------------
def getSIBEngineNamesForBusMember(busName, memberCluster,memberNode=None,memberServer=None):
  _app_trace("getSIBEngineNamesForBusMember(%s,%s,%s,%s)" % (busName, memberCluster,memberNode,memberServer),"entry")
  retval = []
  
  try:
    if (not isEmpty(memberCluster)):
       # Get list from cluster
       messageEngines = AdminTask.listSIBEngines('[-bus "%s" -cluster %s]' % (busName, memberCluster))
    else:
       # Get list from server
       messageEngines = AdminTask.listSIBEngines('[-bus "%s" -server %s -node %s]' % (busName, memberServer, memberNode))
       
    enginelist = wsadminToList(messageEngines)
    for engine in enginelist:
      if (not isEmpty(engine)):
        engineName = AdminConfig.showAttribute(engine,"name")
        retval.append(engineName)
  except:
    _app_trace("Unexpected error in getSIBEngineNamesForBusMember","exception")
    raise StandardError("Unexpected error in getSIBEngineNamesForBusMember")
  
  _app_trace("getSIBEngineNamesForBusMember(%s)" % retval,"exit")
  return retval

#----------------------------------------------------------------------------------
# trimSIBEngines
# 
# This function will remove messaging engines from a cluster bus member.
#
# Parameters:
#     busName - Name of the bus
#     memberCluster - Name of the bus member
#     targetEngineCount - Number of messaging engines the cluster should have
#     engineList - Optional - list of engine IDs. Can be supplied if already known.
#----------------------------------------------------------------------------------
def trimSIBEngines(busName, memberCluster, targetEngineCount,engineList=None):
  
  _app_trace("trimSIBEngines(%s,%s,%d)" % (busName, memberCluster, targetEngineCount),"entry")
  retval = []
  try:
    if (engineList == None):
      # Build it
      engineList = getSIBEnginesForBusMember(busName, memberCluster)
    
    engineNames = []
    engineMap = {}
    
    for engine in engineList:
      engineName = AdminConfig.showAttribute(engine,"name")
      engineNames.append(engineName)
      engineMap[engineName] = engine
    
    if (len(engineNames) > targetEngineCount):
      engineNames.sort()
      
      for idx in range(targetEngineCount,len(engineNames)):
        removeName = engineNames[idx]
        
        _app_trace('About to call AdminTask.deleteSIBEngine("[-bus %s -cluster %s -engine %s ]")' % (busName, memberCluster, removeName))
        AdminTask.deleteSIBEngine('[-bus "%s" -cluster %s -engine "%s" ]' % (busName, memberCluster, removeName))
        
        retval.append(removeName)
        
    
  except:
    _app_trace("Unexpected error in trimSIBEngines","exception")
    raise StandardError("Unexpected error in trimSIBEngines")
  
  _app_trace("trimSIBEngines(retval=%s)" % retval,"exit")
  return retval

#-------------------------------------------------------------------------------
# getSIBLocalizationPointProperties
#
# This function will get the localization point settings for a message engine as
# a property set with the following key syntax:
#
#  localizationPoints.1.identifier = queue@messageengine
#  localizationPoints.1.CONFIG_ID = configuration ID
#  localizationPoints.1.prop.key = val
#-------------------------------------------------------------------------------
def getSIBLocalizationPointProperties(messageEngine):
  
  _app_trace("getSIBLocalizationPointProperties(%s)" % messageEngine,"entry")
  
  retval = java.util.Properties()
  try:
           
        localizationPoints = AdminConfig.showAttribute(messageEngine,"localizationPoints")
        lidx = 0
        if (not isEmpty(localizationPoints)):
          for lpoint in wsadminToList(localizationPoints):
            if (not isEmpty(lpoint)):
              lidx += 1
              lpType = callGetObjectType(lpoint)
              collectSimpleProperties(retval,"localizationPoints.%d.prop" % (lidx),lpoint, ["targetUuid","uuid"],
                                      getSimpleChildren=1)
              lidentifier = retval.remove("localizationPoints.%d.prop.identifier" % (lidx))
              retval.put("localizationPoints.%d.identifier" % lidx,lidentifier)
              retval.put("localizationPoints.%d.type" % lidx,lpType)
              retval.put("localizationPoints.%d.CONFIG_ID" % lidx,lpoint)
        
        retval.put("localizationPoints.count","%d" % lidx)    
  except:
    _app_trace("Unexpected error in getSIBLocalizationPointProperties","exception")
    raise StandardError("Unexpected error in getSIBLocalizationPointProperties","exception")
  
  _app_trace("getSIBLocalizationPointProperties()","exit")
  return retval

#enddef getSIBLocalizationPointProperties

#-------------------------------------------------------------------------------
# updateLocalizationPoint
# 
# This function will update a localization point with the specified properties
#
# Parameters:
#   lpId - Configuration ID for localization point
#   props - dictionary/Map with key/value pairs to update
#-------------------------------------------------------------------------------
def updateLocalizationPoint(lpId,props,mediationProps = None):
  _app_trace("updateLocalizationPoint(%s,%s,%s)" % (lpId,props,mediationProps),"entry")
  try:
    if (props != None and len(props) > 0):
      attrlist = []
      for key in props.keys():
        if (key.lower().find("uuid") >= 0):
          continue
        val = props.get(key)
        attrlist.append([key,val])
      
      if (len(attrlist) > 0):
        if (modifyObject(lpId,attrlist)):
          raise StandardError("Error updating localization point %s" % lpId)
    
    if (mediationProps != None and len(mediationProps) > 0):
      medAttrs = []
      for key in mediationProps.keys():
        if (key.lower().find("uuid") >= 0):
          continue
        val = mediationProps.get(key)
        medAttrs.append([key,val])
      
      if (len(medAttrs) > 0):
        mediationInstance = AdminConfig.showAttribute(lpId,"mediationInstance")
        # Only support updates - this item must be configured before we come in here
        if (not isEmpty(mediationInstance)):
          if (modifyObject(mediationInstance,medAttrs)):
            raise StandardError("Error updating SIBMediationInstance for localization point %s" % lpId)
          
          
      
   
  except:
    _app_exception("Unexpected error in updateLocalizationPoint")
    
    
  _app_trace("updateLocalizationPoint()","exit")
  