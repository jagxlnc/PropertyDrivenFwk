##########################################################################
# File Name:    SIBJMSQueue.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere SIB JMS Queues
#
#               createSIBJMSQueue
#               deleteSIBJMSQueue
#               listSIBJMSQueues
#               listSIBJMSQueueMessages
#               deleteSIBJMSQueueMessages
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createSIBJMSQueue: Create a SIB JMS Queue
#
# SYNTAX:
#    createSIBJMSQueue name, (cluster|node, server), queueName, attrs
#
# PARAMETERS:
#    name  -  Name for SIB JMS Queue entry
#    cluster  -  Cluster to assign JMS Queue to
#    node  -  Node to assign JMS Queue to
#    server  -  Server to assign JMS Queue to
#    queueName  -  Name of underlying SIB queue
#    attrs  -  Hash map of attributes
#
# USAGE NOTES:
#    Creates a SIB JMS Queue at the desired scope.  
#
# RETURNS:
#    ObjID  Object ID of new appserver
#    None  Failure
#
# THROWS:
#    N/A
#
#wsadmin>print AdminTask.help("createSIBJMSQueue")
# WASX8006I: Detailed help for command: createSIBJMSQueue
#
# Description: Create a SIB JMS queue at the scope identified by the target object.
#
# *Target object: Scope at which to create the SIB JMS queue.
#
#Arguments:
#  *name - The SIB JMS queue's name.
#  *jndiName - The SIB JMS queue's JNDI name.
#  description - A description of the SIB JMS queue.
#  *queueName - The name of the underlying SIB queue to which the queue points.
#  deliveryMode - The delivery mode for messages. Legal values are "Application", "NonPersistent" and "Persistent".
#  timeToLive - The time in milliseconds to be used for message expiration.
#  priority - The priority for messages. Whole number in the range 0 to 9.
#  readAhead - Read-ahead value. Legal values are "AsConnection", "AlwaysOn" and "AlwaysOff".
#  busName - The name of the bus on which the queue resides.
#  scopeToLocalQP - Indicates if the underlying SIB queue destination should be scoped to a local queue point when addressed using this JMS queue
#  producerBind - Indicates how JMS producers should bind to queue points of the clustered queue. TRUE indicates that a queue point should be chosen when the session is opened and should never change, FALSE indicates that a queue point should be chosen every time a message is sent.
#  producerPreferLocal - Indicates whether queue points local to the producer should be used
#  gatherMessages - Indicates whether JMS consumers and browsers should be given messages from any queue points, rather than the single queue point that they are attached to.
# 
# Note: no new parms in V8 and V8.5
##########################################################################
def createSIBJMSQueue(name, cluster, node, server, queueName, attrs):

  global progInfo

  retval = None
  
  dashParmsV7 = [  'jndiName', 'description',  'deliveryMode', 'timeToLive', 'priority', 'readAhead', 'busName', 'scopeToLocalQP', 'producerBind', 'producerPreferLocal', 'gatherMessages']
  dashParmsV6 = [  'jndiName', 'description',  'deliveryMode', 'timeToLive', 'priority', 'readAhead', 'busName' ]

  try:
    traceStr = "createSIBJMSQueue(%s, %s, %s, %s, %s, %s)" % (name, cluster, node, server, queueName, attrs)
    _app_trace(traceStr, "entry")  
    
    dashParms = dashParmsV7
    
    if ( progInfo["dmgrVersion"].startswith("6")):
        dashParms = dashParmsV6
    

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    #if isEmpty(AdminConfig.getid(configID)):
    #  raise StandardError("No such target as %s to create SIB JMS Queue on" % (configID))
      
    if isEmpty(name) or isEmpty(queueName):
      raise StandardError("SIB JMS Queue name, SIBus or SIB Queue name not specified")
      
      
    #if existsSIBJMSQueue(name, cluster, node, server):
    #  raise StandardError("SIB JMS Queue %s already exists at scope %s" % (name, configID))
      
    parentID  = AdminConfig.getid(configID)

    if isEmpty(parentID):
      raise StandardError("Cannot find ID; check cluster or node/server and SIB values are correct")

    _app_trace("Got parent ID = " + parentID)

    attributes = ""
    if (name.find(" ") > 0 and not name.startswith("'") and not name.startswith('"')):
      attributes = "-name '%s'" % (name)
    else:
      attributes  = " -name %s" % (name)
    
    if (not queueName.startswith("'") and not queueName.startswith('"')):
      attributes += " -queueName '%s'" % (queueName) 
    else:
      attributes += " -queueName %s" % (queueName) 
    
    for key in attrs.keys():
        if key in dashParms:
            val = attrs.get(key)
            if (isEmpty(val)):
                continue
            if (key == "description"):
                if (not val.startswith('"')):
                    val = '"%s"' % val
                    
            if (val.find(' ') >= 0):
              if (not val.startswith('"') and not val.startswith("'") ) :
                val = '"%s"' % val
        
            attributes = "%s -%s %s" % (attributes, key, val)

    #  Get the templates for SIBJMSQueue
    _app_trace("Running command: AdminTask.createSIBJMSQueue(%s, %s)" % (parentID, attributes))

    retval = AdminTask.createSIBJMSQueue(parentID, attributes)
    
    _app_trace("AdminTask.createSIBJMSQueue() retval = %s" % retval)

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered creating the SIB JMS Queue", "exception")
    retval = None

  _app_trace("createSIBJMSQueue(%s)" %(retval), "exit")
  return retval

############################################################################################################
#wsadmin>print AdminTask.help("modifySIBJMSQueue")
#WASX8006I: Detailed help for command: modifySIBJMSQueue
#
#Description: Modify the attributes of the supplied SIB JMS queue using the supplied attribute values.
#
#*Target object: The SIB JMS queue to be modified.
#
#Arguments:
#  name - The SIB JMS queue's name.
#  jndiName - The SIB JMS queue's JNDI name.
#  description - A description of the SIB JMS queue.
#  queueName - The name of the underlying SIB queue to which the queue points.
#  deliveryMode - The delivery mode for messages. Legal values are "Application", "NonPersistent" and "Persistent".
#  timeToLive - The time in milliseconds to be used for message expiration.
#  priority - The priority for messages. Whole number in the range 0 to 9.
#  readAhead - Read-ahead value. Legal values are "AsConnection", "AlwaysOn" and "AlwaysOff".
#  busName - The name of the bus on which the queue resides.
#  scopeToLocalQP - Indicates if the underlying SIB queue destination should be scoped to a local queue point when addressed using this JMS queue
#  producerBind - Indicates how JMS producers should bind to queue points of the clustered queue. TRUE indicates that a queue point should be chosen when the session is opened and should never change, FALSE indicates that a queue point should be chosen every time a message is sent.
#  producerPreferLocal - Indicates whether queue points local to the producer should be used
#  gatherMessages - Indicates whether JMS consumers and browsers should be given messages from any queue points, rather than the single queue point that they are attached to.
#
# Steps:
#  None
############################################################################################################
def modifySIBJMSQueue(name, cluster, node, server,attrs):

  global progInfo

  retval = None
  
  dashParmsV7 = [  'jndiName', 'queueName', 'description',  'deliveryMode', 'timeToLive', 'priority', 'readAhead', 'busName', 'scopeToLocalQP', 'producerBind', 'producerPreferLocal', 'gatherMessages']
  dashParmsV6 = [  'jndiName', 'queueName', 'description',  'deliveryMode', 'timeToLive', 'priority', 'readAhead', 'busName' ]

  try:
    traceStr = "modifySIBJMSQueue(%s, %s, %s, %s, %s)" % (name, cluster, node, server, attrs)
    _app_trace(traceStr, "entry")  
    
    dashParms = dashParmsV7
    if ( progInfo["dmgrVersion"].startswith("6")):
        dashParms = dashParmsV6
    

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to modify SIB JMS Queue on" % (configID))


    queueid = getSIBJMSQueueId(cluster,node,server,name)
    
    if (isEmpty(queueid)):
        raise StandardError("Unable to find SIBJMSQueue %s at scope %s %s %s" % (name,cluster,node,server))

    attributes = ""
    
    for key in attrs.keys():
        if key in dashParms:
            val = attrs.get(key)
            if (isEmpty(val)):
                continue
            if (key == "description"):
                if (not val.startswith('"')):
                    val = '"%s"' % val
                    
            if (val.find(' ') >= 0):
              if (not val.startswith('"') and not val.startswith("'") ) :
                val = '"%s"' % val

        
            attributes = "%s -%s %s" % (attributes, key, val)

    #  Get the templates for SIBJMSQueue
    _app_trace("Running command: AdminTask.modifySIBJMSQueue(%s, %s)" % (queueid, attributes))

    AdminTask.modifySIBJMSQueue(queueid, attributes)
    
    retval = queueid

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered modifying the SIB JMS Queue", "exception")
    retval = None

  _app_trace("modifySIBJMSQueue(%s)" %(retval), "exit")
  return retval


##########################################################################
#
# FUNCTION:
#    deleteSIBJMSQueue: Delete a SIB JMS Queue
#
# SYNTAX:
#    deleteSIBJMSQueue name, cluster|(node, server)
#
# PARAMETERS:
#    name  -  Name for SIB JMS Queue entry
#    cluster  -  Name of cluster for cluster scoped queue
#    node  -  Name of node for server scoped queue
#    server  -  Name of server for server scoped queue
#    jmsQueueId - Configuration ID of the queue if it is known
#
#
# USAGE NOTES:
#    Deletes a SIB JMS Queue from the desired scope.  
#    
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBJMSQueue(name, cluster, node, server,jmsQueueId=None):
  deleteSIBJMSQueue(name, cluster, node, server,jmsQueueId)
  
def deleteSIBJMSQueue(name, cluster, node, server,jmsQueueId=None):

  global progInfo

  retval = 1

  try:
    traceStr = "deleteSIBJMSQueue(%s, %s, %s, %s, %s)" % (name, cluster, node, server,jmsQueueId)
    _app_trace(traceStr, "entry")
    
    if (not isEmpty(jmsQueueId)):
        _app_trace("Running command: AdminTask.deleteSIBJMSQueue(%s)" % (jmsQueueId))
        AdminTask.deleteSIBJMSQueue(jmsQueueId)
        retval = 0
    else:
        
      #  Check function parameters
      configID = getContainmentPath(cluster, node, server, 1)
      
      if isEmpty(configID):
        raise StandardError("Could not get containment path")
        
      if isEmpty(AdminConfig.getid(configID)):
        raise StandardError("No such target as %s to delete SIB JMS Queue from" % (configID))
        
      if isEmpty(name):
        raise StandardError("SIB JMS Queue name not specified")
        
      if not existsSIBJMSQueue(name, cluster, node, server):
        raise StandardError("SIB JMS Queue %s does not exist at scope %s" % (name, configID))
        
      parentID = AdminConfig.getid(configID)
      idList  = AdminTask.listSIBJMSQueues(parentID)
  
      if isEmpty(idList):
        raise StandardError("Cannot find ID; check SIB queue name, cluster and node/server values are correct")
        
      qList = idList.split(progInfo["line.separator"])
  
      _app_trace("Got SIB JMS Queues = %s" % (qList))
  
      #  Delete ALL SIB JMS Queues with the same name (hmmmm!) at this scope
      for q in qList:
        nameAttr = AdminConfig.showAttribute(q, 'name')
  
        if nameAttr == name:
          _app_trace("Running command: AdminTask.deleteSIBJMSQueue(%s)" % (q))
          AdminTask.deleteSIBJMSQueue(q)
    
    #endelse
    
    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()
      
    retval = 0
  except:
    _app_trace("An error was encountered deleting the SIB JMS Queue", "exception")
    retval = 1

  _app_trace("deleteSIBJMSQueue(%d)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    listSIBJMSQueues: List SIB JMS Queues at scope
#
# SYNTAX:
#    listSIBJMSQueues cluster| (node, server), displayFlag
#
# PARAMETERS:
#    cluster  -  Name of cluster for cluster scoped queue
#    node  -  Name of node for server scoped queue
#    server  -  Name of server for server scoped queue
#    displayFlag-  Boolean indicating whether to print list 
#      (default = 1)
#
# USAGE NOTES:
#    Lists SIB JMS Queues at the desired scope.  
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showSIBJMSQueues(cluster, node, server, displayFlag = 1):
  listSIBJMSQueues(cluster, node, server, displayFlag)
  
def listSIBJMSQueues(cluster, node, server, displayFlag = 1):

  global progInfo
  
  retval = None
  
  try:
    traceStr = "listSIBJMSQueues(%s, %s, %s, %d)" % (cluster, node, server, displayFlag)
    _app_trace(traceStr, "entry")  

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)

    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to list SIB JMS Queues at" % (configID))
      
    #  Get the parentID
    parentID = AdminConfig.getid(configID)

    _app_trace("Running command: AdminTask.listSIBJMSQueues(%s)" % (parentID))
    str = AdminTask.listSIBJMSQueues(parentID)

    if isEmpty(str):
      retval = []
    else:
      retval = str.split(progInfo["line.separator"])

    if displayFlag:
      print "\nSI Bus JMS Queues\n-------------------"

      for r in retval:
        print AdminConfig.showAttribute(r, "name")

      print "-------------------"
  except:
    _app_trace("An error was encountered listing the SIB JMS Queues", "exception")
    retval = None

  _app_trace("listSIBJMSQueues(%s)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    listSIBJMSQueueMessages: List SIB JMS Queue Messages
#
# SYNTAX:
#    listSIBJMSQueueMessages engine, queue
#
# PARAMETERS:
#    engine  -  Messaging engine name
#    queue  -  Optional queue name, if None then all queues 
#    -  will be displayed
#
# USAGE NOTES:
#    Lists SIB JMS Queue Messages
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def showSIBJMSQueueMessages(engine, queue = None):
  listSIBJMSQueueMessages(engine, queue)
  
def listSIBJMSQueueMessages(engine, queue = None):

  global progInfo

  retval = 1

  try:
    traceStr = "listSIBJMSQueueMessages(%s, %s)" % (engine, queue)
    _app_trace(traceStr, "entry")
    
    #  Check args
    if isEmpty(engine):
      raise StandardError("SIB Messaging Engine name not specified")
      
    if not objectExists("SIBMessagingEngine", None, engine):
      raise StandardError("Messaging engine %s does not exist" % (engine))

    #  Build AdminControl object name
    configID = AdminConfig.getid("/SIBMessagingEngine:%s/" % (engine))
    localizationPointsStr = AdminConfig.showAttribute(configID, "localizationPoints")

    if isEmpty(localizationPointsStr):
      raise StandardError("No queues found on messaging engine %s" % (engine))

    _app_trace("ConfigID = %s | localQueues = %s" % (configID, localizationPointsStr))

    length = len(localizationPointsStr) - 1
    localizationPointsList = localizationPointsStr[1:length].split(" ")

    print "\n\n%-60.60s\t%-6.6s" % ("Queue Name", "Depth")
    print "------------------------------------------------------------\t------"

    for localizationPoint in localizationPointsList:

      name = AdminConfig.showAttribute(localizationPoint, "identifier")

      #  Queue name  = name[0:first occ of @]
      idx = name.find("@")

      if idx == -1:
        _app_trace("Queue name format looks wrong (%s), expected name@engine" % (name))
        continue

      qname = name[0:idx]

      if queue is not None and qname != queue:
        continue

      MBeanName = "WebSphere:name=%s,type=SIBQueuePoint,SIBMessagingEngine=%s,*" % (qname, engine)
      MBeanObj  = AdminControl.completeObjectName(MBeanName)

      if isEmpty(MBeanObj):
        raise StandardError("Cannot get MBean information - is the Messaging Engine running?")

      print "\n%-60.60s\t%6d" % (qname, int(AdminControl.getAttribute(MBeanObj, "depth")))
      
    retval = 0

  except:
    _app_trace("An error was encountered listing the SIB JMS Queue Messages", "exception")
    retval = 1

  _app_trace("listSIBJMSQueueMessages(%d)" % (retval), "exit")
  return retval


##########################################################################
#
# FUNCTION:
#    deleteSIBJMSQueueMessages: Delete SIB JMS Queue Messages
#
# SYNTAX:
#    deleteSIBJMSQueueMessages engine, queue
#
# PARAMETERS:
#    engine  -  Messaging engine name
#    username  -  Username (required to access MBean)
#    password  -  Password (required to access MBean)
#    queue  -  Optional queue name, if None then all messages
#    -  on all queues will be deleted.  USE WITH CAUTION
#
# USAGE NOTES:
#    Deletes all SIB JMS Messages on either a given queue, or all queues
#    if no queue specified
#
# RETURNS:
#    0  -  Success
#    1  -  Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBJMSQueueMessages(engine, username, password, queue = None):
  deleteSIBJMSQueueMessages(engine, username, password, queue)
  
def deleteSIBJMSQueueMessages(engine, username, password, queue = None):

  from jarray import array, zeros
  import java
  import javax
  import com

  global progInfo

  retval = 1

  try:
    traceStr = "deleteSIBJMSQueueMessages(%s, %s, %s, %s)" % (engine, username, "*****", queue)
    _app_trace(traceStr, "entry")
    
    #  Check args
    if isEmpty(engine):
      raise StandardError("SIB Messaging Engine name not specified")

    if isEmpty(username) or isEmpty(password):
      raise StandardError("Username / password not specified ")
      
    if not objectExists("SIBMessagingEngine", None, engine):
      raise StandardError("Messaging engine %s does not exist" % (engine))
      
    #  Build AdminControl object name
    configID = AdminConfig.getid("/SIBMessagingEngine:%s/" % (engine))
    localizationPointsStr = AdminConfig.showAttribute(configID, "localizationPoints")

    if isEmpty(localizationPointsStr):
      raise StandardError("No queues found on messaging engine %s" % (engine))

    _app_trace("ConfigID = %s | localQueues = %s" % (configID, localizationPointsStr))

    length = len(localizationPointsStr) - 1
    localizationPointsList = localizationPointsStr[1:length].split(" ")

    for localizationPoint in localizationPointsList:

      name = AdminConfig.showAttribute(localizationPoint, "identifier")

      #  Queue name  = name[0:first occ of @]
      idx = name.find("@")

      if idx == -1:
        _app_trace("Queue name format looks wrong (%s), expected name@engine" \
          % (name))
        continue

      qname = name[0:idx]

      _app_trace("Found queue name = %s" % (qname))

      if not isEmpty(queue) and qname != queue:
        continue

      #  AdminControl.invoke() will always return a String.  This is useless
      #  if the return is not a String  e.g. getQueuedMessages() which returns
      #  an array of com.ibm.ws.sib.admin.impl.SIBQueuedMessageImpl
      #  which we need to traverse to get the message ID to then be 
      #  able to delete it!
      #  
      #  Use the Java API instead
      MBeanName = "WebSphere:name=%s,type=SIBQueuePoint,SIBMessagingEngine=%s,*" \
        % (qname, engine)
      MBeanObj  = AdminControl.completeObjectName(MBeanName)
      objectName = javax.management.ObjectName(MBeanObj)

      _app_trace("MBeanName = %s | MBeanObj = %s | objectName = %s" \
        % (MBeanName, MBeanObj, objectName))

      #  Set AdminClient properties - not sure why as we are already connected?
      props = java.util.Properties()
      props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_HOST, \
        AdminControl.getHost())
      props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_PORT, \
        AdminControl.getPort())
      props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_TYPE, \
        com.ibm.websphere.management.AdminClient.CONNECTOR_TYPE_SOAP)
      props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_SECURITY_ENABLED, "true")
      props.setProperty(com.ibm.websphere.management.AdminClient.USERNAME, username) 
      props.setProperty(com.ibm.websphere.management.AdminClient.PASSWORD, password) 

      #  Get an AdminClient to connect to server JMX
      service = com.ibm.websphere.management.AdminClientFactory.createAdminClient(props)

      if isEmpty(service):
        raise StandardError("Unable to get an AdminClient object")

      #  Get queued messages
      queuedMessages = service.invoke(objectName, 'getQueuedMessages', None, None)

      #  Set flag to not move messages to exception queue instead of discard
      bool = java.lang.Boolean("false")

      #  Loop through each one
      for m in queuedMessages:
        id = m.getId()
        param = array((id, bool), java.lang.Object)
        sign  = array(("java.lang.String", "java.lang.Boolean"), \
          java.lang.String)

        _app_trace("Deleting message %s" % (id))
        service.invoke(objectName, "deleteQueuedMessage", param, sign)
        
    retval = 0
  except:
    _app_trace("An error was encountered listing the SIB JMS Queue Messages", "exception")
    retval = 1

  _app_trace("deleteSIBJMSQueueMessages(%d)" % (retval), "exit")
  return retval
  
#--------------------------------------------------------------------------------------------
# getSIBJMSQueueId
#
# Search for the queue with the specified scope and name. If it exists, return the id
#--------------------------------------------------------------------------------------------
def getSIBJMSQueueId(cluster,node,server,jmsQueueName):

  result = ""
  
  try:
  
    _app_trace("getSIBJMSQueueId(%s,%s,%s,%s)" % (cluster,node,server,jmsQueueName), "entry")

    # See if the queue exists
    shortName = jmsQueueName
    if (jmsQueueName.startswith("'") or jmsQueueName.startswith('"')):
      shortName = jmsQueueName[1:-1]
    qlist = []
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        qlist = AdminTask.listSIBJMSQueues(scopeId).split(progInfo["line.separator"])
        
        for queue in qlist:
            if (not isEmpty(queue)):
                if (queue.find(shortName) < 0):
                  continue
                name = AdminConfig.showAttribute(queue,"name")
                if (name == jmsQueueName or name == shortName):
                    result = queue
                    break
  except:
    _app_trace("Unexpected error getting SIBJMSQueue ID","exception")
    result = None

  _app_trace("getSIBJMSQueueId(%s)" % (result),"exit")
  return result

#--------------------------------------------------------------------------------------------
# findMatchingSIBJMSQueues
#
# Search for the queues with the specified scope and name pattern. Returns matching queues in
# a dictionary where jmsqueuename = id
# 
#--------------------------------------------------------------------------------------------
def findMatchingSIBJMSQueues(cluster,node,server,namePattern):

  retval = {}
  
  import re
  
  try:
    _app_trace("findMatchingSIBJMSQueues(%s,%s,%s,%s)" % (cluster,node,server,namePattern), "entry")

    # See if the queue exists
    qlist = []
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        qlist = AdminTask.listSIBJMSQueues(scopeId).split(progInfo["line.separator"])
        
        for queue in qlist:
            if (not isEmpty(queue)):
                tempName = AdminConfig.showAttribute(queue,"name")
                if (namePattern.find("*") >= 0):
                  # Regular express
                  if (re.match(namePattern,tempName)):
                      # Add ID to result list
                      retval[tempName] = queue
                else:
                  if (namePattern == tempName):
                      retval[tempName] = queue

  except:
    _app_trace("Unexpected error in findMatchingSIBJMSQueues","exception")
    raise StandardError("Unexpected error in findMatchingSIBJMSQueues")

  _app_trace("findMatchingSIBJMSQueues(%s)" % (retval),"exit")
  return retval



#--------------------------------------------------------------------------------------------
# getSIBJMSQueueProperties
#
# Search for the queue with the specified scope and name. If it exists, gather properties and
# store in property set with "queue.prop.key = val" naming format.
#
# Return empty Properties set if no match found.
# Return None if error occurs
#--------------------------------------------------------------------------------------------
def getSIBJMSQueueProperties(cluster,node,server,jmsQueueName,jmsQueueId=None,checkSettingsOverride=0):

  result = java.util.Properties()
  
  try:
  
    _app_trace("getSIBJMSQueueProperties(%s,%s,%s,%s,%s,%d)" % (cluster,node,server,jmsQueueName,jmsQueueId,checkSettingsOverride), "entry")

    # See if the queue exists
    qlist = []
    shortName = jmsQueueName
    if (jmsQueueName.startswith('"') or jmsQueueName.startswith("'")):
      shortName = jmsQueueName[1:-1]
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        if (not isEmpty(jmsQueueId)):
          # JMS Queue was previously found
          qlist = [jmsQueueId]
        else:
          qlist = AdminTask.listSIBJMSQueues(scopeId).split(progInfo["line.separator"])
        
        for queue in qlist:
            if (not isEmpty(queue)):
                # ID should contain name, check this before calling showAttribute
                
                if (queue.find(shortName) < 0):
                    continue
                  
                name = AdminConfig.showAttribute(queue,"name")
                
                if ( shortName == name or name == jmsQueueName):
                    result.put("queue.name", name)
                    
                    if (checkSettingsOverride or isCheckSettingsEnabled("sibjms")):
                      
                      # Note: turns oout that showSIBJMSQueue is very very slow
                      # and it is much quicker to pull attributes and custom properties directly 
                      # from the J2CAdminObject
                      #
                      # The only drawback from this approach is that the attribute names may 
                      # have an uppercase starting character, which doesn't map to AdminTask.updateSIBJMSQueue
                      # After collecting the properties, we'll need to transform the keys
                      
                      collectSimpleProperties(result, "queue.prop",queue)
                      collectCustomProperties(result,"queue", queue, "properties")
                      
                      # Some of the property values need to be remapped from On/Off to true/false
                      booleanProps = [ "queue.prop.gatherMessages", "queue.prop.producerBind", "queue.prop.scopeToLocalQP", "queue.prop.producerPreferLocal" ]
                      
                      tempKeys = [] 
                      for key in result.keys():
                        tempKeys.append(key)
                        
                      for key in tempKeys:
                        propName = key.split(".")[-1]
                        replaceName = "%s%s" % (propName[0].lower(), propName[1:])
                        replaceKey = "queue.prop.%s" % replaceName
                        val = result.get(key)
                        result.put(replaceKey,val)
                        
                      # Now check to see if its a special boolean prop that needs to have value changed
                      for key in booleanProps:
                        val = result.get(key)
                        if (not isEmpty(val)):
                          if (val == "On"):
                            result.put(key,"true")
                          elif (val == "Off"):
                            result.put(key,"false")
                      
                      
                      #_app_trace("About to call AdminTask.showSIBJMSQueue(%s)" % queue)
                      #queuetext =   AdminTask.showSIBJMSQueue(queue)
                      
                      #_app_trace("Back from AdminTask.showSIBJMSQueue(queue)")

                      #queuedict = wsadminToDictionary(queuetext)
                      
                      # Return dictionary as a property set
                      #for key in queuedict.keys():
                      #  val = queuedict.get(key)
                      #  if (isEmpty(val)):
                      #      continue
                      #  if (key != name):
                      #      result.put("queue.prop.%s" %key, val)
                            
                    #Break out of queue list loop
                    break
  except:
    _app_trace("Unexpected error getting SIBJMSQueue properties","exception")
    result = None

  _app_trace("getSIBJMSQueueProperties(%s)" % (result),"exit")
  return result
    