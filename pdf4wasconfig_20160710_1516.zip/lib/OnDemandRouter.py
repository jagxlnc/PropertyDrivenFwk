#######################################################################################
#  OnDemandRouter.py
#
#  Utility methods for manipulating On Demand Router configuration items
#
#  Dependencies: Utils.py, common.py
#
#######################################################################################



#-------------------------------------------------------------------------------
# createODR
#
# Parameters
#
#-------------------------------------------------------------------------------
def createODR(nodeName,odrName,templateName="odr",startingPort="0"):
  _app_entry("createODR(%s,%s,%s,%s)" , nodeName,odrName,templateName,str(startingPort))
  retval = None
  try:
    parms = "-name %s -templateName %s" % (odrName,templateName)
    if (isEmpty(startingPort) or startingPort == "0"):
      parms = "%s -genUniquePorts true" % (parms)
    
    parms = "[ %s ]" % parms
    _app_trace('About to call AdminTask.createOnDemandRouter(%s,%s)' % (nodeName,parms))
    retval = AdminTask.createOnDemandRouter(nodeName,parms)
    
    if (not isEmpty(startingPort and str(startingPort) != "0")):
      if (modifyApplicationServerPorts(odrName, nodeName, port=startingPort, amendVHost = 0, keepHostNames=1)):
        raise StandardError("Unable to configure ports for server %s/%s startingPort=%s" % (nodeName,odrName,str(startingPort)))
  except:
    _app_exception("Unexpected problem in createODR()")
  
  _app_exit("createODR(retval=%s)" % retval)
  return retval
  


#-------------------------------------------------------------------------------
# updateODRProxyServerSettings
#
# Parameters
#   odrId - Configuration ID of ODR server - optional is proxyServerId is supplied
#   baseProps - properties for ProxyServer configuration item
#   httpProxyServerSettingsProps - properties for httpProxyServerSettings attribute
#   stateManagementProps - properties for stateManagement attribute
#   customProps - custom properties for id
#   proxyServerId - optional if odrId is supplied
#
# Returns:
#    proxyServerId
#-------------------------------------------------------------------------------
def updateODRProxyServerSettings(odrId=None,baseProps=None,httpProxyServerSettingsProps=None,stateManagementProps=None,customProps=None,proxyServerId=None):
  _app_entry("updateODRProxyServerSettings(%s,%s,%s,%s,%s,%s)" ,odrId,baseProps,httpProxyServerSettingsProps,stateManagementProps,customProps,proxyServerId)
  retval = None
  try:
    if (isEmpty(proxyServerId)):
      proxyServerId = AdminConfig.list("ProxyServer",odrId)
      if (isEmpty(proxyServerId)):
        attrs = propsToAttrList(baseProps)
        proxyServerId = AdminConfig.create("ProxyServer",odrId,attrs)
    
    retval = proxyServerId
    
    if (baseProps != None and len(baseProps) > 0):
      attrs = propsToAttrList(baseProps)
      if (modifyObject(proxyServerId,attrs)):
        raise StandardError("Unable to update base properties of ProxyServer %s" % proxyServerId)
    
    if (httpProxyServerSettingsProps != None and len(httpProxyServerSettingsProps) > 0):
      doUpdateCreate("HTTPProxyServerSettings",proxyServerId,httpProxyServerSettingsProps,parentAttributeName="httpProxyServerSettings")
    
    if (stateManagementProps != None and len(stateManagementProps) > 0):
      doUpdateCreate("StateManageable",proxyServerId,stateManagementProps,parentAttributeName="stateManagement")
    
    if (customProps != None and len(customProps) > 0):
      doUpdateCreate("Property",proxyServerId,customProps,parentAttributeName="properties")
        
  except:
    _app_exception("Unexpected problem in updateODRProxyServerSettings()")
  
  _app_exit("updateODRProxyServerSettings(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# updateODRProxySettings
#
# Parameters
#    odrId - Server configuration ID of the ODR
#    baseProps - dictionary with base properties of ProxySettings configuration item
#    errorPagePolicyProps - dictionary with properties of CustomErrorPagePolicy
#    localErrorPagePolicyProps - dictionary with base settings of LocalErrorPagePolicy
#    localErrorMappings - list of dictionaries that define the errorMapping settings for LocalErrorPagePolicy
#    pluginConfigPolicyProps - properties of PluginConfigPolicy configuration item
#    rewritingRules - list of dictionaries that define RewritingRule items in the RewritingPolicy
#    staticCachePolicy - A list of dictionaries of StaticCacheRule attributes, include optional "properties" attribute point to nested dictionary
#-------------------------------------------------------------------------------
def updateODRProxySettings(odrId,baseProps,customProps,errorPagePolicyProps,localErrorPagePolicyProps,localErrorMappings,pluginConfigPolicyProps,rewritingRules,staticCachePolicy):
  _app_entry("updateODRProxySettings(%s,%s,%s,%s,%s,%s,%s,%s,%s)" , odrId,baseProps,customProps,errorPagePolicyProps,localErrorPagePolicyProps,localErrorMappings,pluginConfigPolicyProps,rewritingRules,staticCachePolicy)
  retval = None
  try:
    proxySettingsId = doUpdateCreate("ProxySettings",odrId,baseProps)
    
    retval = proxySettingsId
    
    doUpdateCreate("Property",proxySettingsId,customProps,"properties")
    
    doUpdateCreate("CustomErrorPagePolicy",proxySettingsId,errorPagePolicyProps,"errorPagePolicy")
    
    localErrorPagePolicyId = doUpdateCreate("LocalErrorPagePolicy",proxySettingsId,localErrorPagePolicyProps,"localErrorPagePolicy")
    
    if (localErrorMappings != None and len(localErrorMappings) > 0):
      if (isEmpty(localErrorPagePolicyId)):
        localErrorPagePolicyId = AdminConfig.showAttribute(proxySettingsId,"localErrorPagePolicy")
        
      currentMappings = wsadminToList(AdminConfig.showAttribute(localErrorPagePolicyId,"errorMappings"))
      for tempId in currentMappings:
        if (not isEmpty(tempId)):
          AdminConfig.remove(tempId)
      
      for lem in localErrorMappings:
        doUpdateCreate("ErrorMapping",localErrorPagePolicyId,lem,forceCreate=1)
    
    doUpdateCreate("PluginConfigPolicy",proxySettingsId,pluginConfigPolicyProps,"pluginConfigPolicy")
    
    if (rewritingRules != None and len(rewritingRules) > 0):
      rewritingPolicyId = AdminConfig.showAttribute(proxySettingsId,"rewritingPolicy")
      if (isEmpty(rewritingPolicyId)):
        rewritingPolicyId = AdminConfig.create("RewritingPolicy",proxySettingsId,[])
      
        
      currentRules = wsadminToList(AdminConfig.showAttribute(rewritingPolicyId,"rewritingRules"))
      for tempId in currentRules:
        if (not isEmpty(tempId)):
          AdminConfig.remove(tempId)
      
      for rw in rewritingRules:
        doUpdateCreate("RewritingRule",rewritingPolicyId,rw,forceCreate=1)    
    
    # Note - there appears to be a wsadmin problem with float attributes
    if (staticCachePolicy != None and len(staticCachePolicy) > 0):
      staticCachePolicyId = AdminConfig.showAttribute(proxySettingsId,"staticCachePolicy")
      if (isEmpty(staticCachePolicyId)):
        _app_trace('About to call AdminConfig.create("StaticCachePolicy",%s,[])' % proxySettingsId)
        staticCachePolicyId = AdminConfig.create("StaticCachePolicy",proxySettingsId,[])
      
      currentRules = wsadminToList(AdminConfig.showAttribute(staticCachePolicyId,"staticCacheRules"))
      for tempId in currentRules:
        if (not isEmpty(tempId)):
          AdminConfig.remove(tempId)
      
      for scr in staticCachePolicy:
        doUpdateCreate("StaticCacheRule",staticCachePolicyId,scr,forceCreate=1)


    
    
    
  except:
    _app_exception("Unexpected problem in updateODRProxySettings()")
  
  _app_exit("updateODRProxySettings(retval=%s)" % retval)
  return retval
        


#-------------------------------------------------------------------------------
# getProxyServerProperties
#
# Parameters
#    odrId - configuration ID of ODR Server
#
#    odrProperties - optional property to store attributes in
#    checkSettingsOverride - overrides global settings that might disable getXXXProperties function
#  
#  Returns: dictionary containing properties for ProxySettings and child items
#           Keys start with proxySettings.prop or proxySettings.attributeName
 
#  
#-------------------------------------------------------------------------------
def getProxyServerProperties(odrId,odrProperties=None,checkSettingsOverride=0):
  _app_entry("getProxyServerProperties(%s,odrProperties,%d)" , odrId,checkSettingsOverride)
  retval = None
  if (odrProperties == None):
    odrProperties = {}
  
  retval = odrProperties
  
  try:
    if (checkSettingsOverride or isCheckSettingsEnabled()):
      proxyServerId = AdminConfig.list("ProxyServer",odrId)
      if (not isEmpty(proxyServerId)):
        collectSimpleProperties(retval,"proxyServer.prop",proxyServerId,getSimpleChildren=1,collectListChildren=1,collectPropertyAttributes=1,useAttrNameWithProperties=1)
    
  except:
    _app_exception("Unexpected problem in getProxyServerProperties()")
  
  _app_exit("getProxyServerProperties(retval=%d)" % len(retval))
  return retval

#-------------------------------------------------------------------------------
# getProxySettingsProperties
#
# Parameters
#    odrId - configuration ID of ODR Server
#    odrProperties - optional property to store attributes in
#    checkSettingsOverride - overrides global settings that might disable getXXXProperties function
#  
#  Returns: dictionary containing properties for ProxySettings and child items
#           Keys start with proxySettings.prop or proxySettings.attributeName
#-------------------------------------------------------------------------------
def getProxySettingsProperties(odrId,odrProperties=None,checkSettingsOverride=0):
  _app_entry("getProxySettingsProperties(%s,odrProperties,%d)" , odrId,checkSettingsOverride)
  retval = None
  if (odrProperties == None):
    odrProperties = {}
  
  retval = odrProperties  
  try:
    if (checkSettingsOverride or isCheckSettingsEnabled()):
      proxySettingsId = AdminConfig.list("ProxySettings",odrId)
      if (not isEmpty(proxySettingsId)):
        collectSimpleProperties(retval,"proxySettings.prop",proxySettingsId,getSimpleChildren=1,collectListChildren=1,collectPropertyAttributes=1,useAttrNameWithProperties=1)
  except:
    _app_exception("Unexpected problem in getProxySettingsProperties()")
  
  _app_exit("getProxySettingsProperties(retval=%d)" % len(retval))
  return retval
  


#-------------------------------------------------------------------------------
# getOnDemandRouterRules
#
# Parameters
#    odrId - Configuration ID of ODR Server    
# Returns:
#    A dictionary containing properties that define a list of Rules items
#    Properties for each rule start with odr.rules.[idx], odr.rules.count has count value
#-------------------------------------------------------------------------------
def getOnDemandRouterRules(odrId,odrProperties=None,checkSettingsOverride=0):
  _app_entry("getOnDemandRouterRules(%s,odrProperties,%d)" , odrId,checkSettingsOverride)
  retval = None
  try:
    if (checkSettingsOverride or isCheckSettingsEnabled()):
      if (odrProperties == None):
        odrProperties = {}
        
      rules = AdminConfig.list("Rules",odrId)
      if (not isEmpty(rules)):
        ridx = 0
        rulelist = rules.splitlines()
        for ruleId in rulelist:
          if (isEmpty(ruleId)):
            continue
          ruleName = splitOffName(ruleId)
          ridx += 1
          rPrefix = "odr.rules.%d" % (ridx)
          odrProperties["%s.name" % rPrefix] = ruleName
          collectSimpleProperties(odrProperties,"%s.prop" % rPrefix,ruleId,["name"],getSimpleChildren=1,collectListChildren=1,collectPropertyAttributes=1)
        
        if (ridx > 0):
          odrProperties["odr.rules.count"] = ridx
      
      
  except:
    _app_exception("Unexpected problem in getOnDemandRouterRules()")
  
  _app_exit("getOnDemandRouterRules(retval=%d)" % len(retval))
  return retval

#-------------------------------------------------------------------------------
# createOnDemandRouterRules
#
# Parameters
#
#-------------------------------------------------------------------------------
def createOnDemandRouterRules(odrId,rulesName,baseRules=None):
  _app_entry("createOnDemandRouterRules(%s,%s,%s)" , odrId,rulesName,baseRules)
  retval = None
  try:
    if (baseRules == None):
      baseRules = {}
      
    baseRules["name"] = rulesName
    
    retval = doUpdateCreate("Rules",odrId,baseRules,forceCreate=1)
  except:
    _app_exception("Unexpected problem in createOnDemandRouterRules()")
  
  _app_exit("createOnDemandRouterRules(retval=%s)" % retval)
  return retval
  

#-------------------------------------------------------------------------------
# updateOnDemandRouterRules
#
# Parameters
#    rulesId - configuration ID of a Rules configuration item under the ODR
#    baseRules - base properties to be applied to Rules item
#    matchRules - a list of dictionaries that define the MatchRules items to be
#                created
#    appendMatchRules - if 1, new rules will be appended to existing list of rules,
#                       0 (default) means existing will be replaced
#-------------------------------------------------------------------------------
def updateOnDemandRouterRules(rulesId,baseRules,matchRules,appendMatchRules = 0):
  _app_entry("updateOnDemandRouterRules(%s,%s,%s,%d)" , rulesId,baseRules,matchRules,appendMatchRules)
  retval = None
  try:
    if (baseRules != None and len(baseRules) > 0):
      attrs = propsToAttrList(baseRules)
      if (modifyObject(rulesId,attrs)):
        raise StandardError("Unable to update %s" % rulesId)
      
      if (matchRules != None):
        if (not appendMatchRules):
          tempIds = wsadminToList(AdminConfig.showAttribute(rulesId,"matchRules"))
          for tempId in tempIds:
            if (not isEmpty(tempId)):
              AdminConfig.remove(tempId)
        
        for matchRuleDict in matchRules:
          doUpdateCreate("MatchRule",rulesId,matchRuleDict,"matchRules",forceCreate=1)
      
  except:
    _app_exception("Unexpected problem in updateOnDemandRouterRules()")
  
  _app_exit("updateOnDemandRouterRules(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# getOnDemandRouterRulesId
#
# Parameters
#   odrNode - Node name for ODR server - if empty will try DynamicCluster template
#   odrName - name of ODR server
#   rulesName - rules to lookup
#-------------------------------------------------------------------------------
def getOnDemandRouterRulesId(odrNode,odrName,rulesName):
  _app_entry("getOnDemandRouterRulesId(%s,%s,%s)" , odrNode,odrName,rulesName)
  retval = None
  try:
    _app_trace('About to call AdminConfig.getid("/Node:%s/Server:%s/Rules:%s/")' % (odrNode,odrName,rulesName))
    
    if (not isEmpty(odrNode)):
      retval = AdminConfig.getid("/Node:%s/Server:%s/Rules:%s/" % (odrNode,odrName,rulesName))
    else:
      # See if it a dynamic cluster template
      retval = AdminConfig.getid("/DynamicCluster:%s/Server:%s/Rules:%s/" %(odrName,odrName,rulesName))
  except:
    _app_exception("Unexpected problem in getOnDemandRouterRulesId()")
  
  _app_exit("getOnDemandRouterRulesId(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# getODRRulesProperties
#
# Parameters
#   rulesId - Configuration ID of Rules item
#   rulesProps - optional dictionary to store results in, otherwise new
#                dictionary will be created
#
# Returns:
#   A dictionary with Rules in the following key/value syntax
#      odr.rules.name = routing_HTTP_serverRequest
#      odr.rules.prop.matchAction = permit:WLOR:module=*/*/*/*
#      odr.rules.matchRules.1.prop.matchAction = permitstickyMM:WLOR:cluster=IMScriptingCell/DynamicGamma
#      odr.rules.matchRules.1.prop.matchExpression = clientipv4 LIKE '192.%.%.%'
#      odr.rules.matchRules.1.prop.priority = 0
#      odr.rules.matchRules.2.prop.matchAction = permit:WLOR:module=*/IntelligentManagementApp/2.0/*
#      odr.rules.matchRules.2.prop.matchExpression = cookie$EVALUSER IS NOT NULL
#      odr.rules.matchRules.2.prop.priority = 1
#      odr.rules.matchRules.3.prop.matchAction = permitstickyMM:WLOR:cluster=IMScriptingCell/DynamicAlpha
#      odr.rules.matchRules.3.prop.matchExpression = clientipv4 LIKE '209.103.%.%'
#      odr.rules.matchRules.3.prop.priority = 3
#      odr.rules.matchRules.count = 3       
#-------------------------------------------------------------------------------
def getODRRulesProperties(rulesId,rulesProps=None):
  _app_entry("getODRRulesProperties(%s)" , rulesId)
  retval = None
  try:
    if (rulesProps == None):
      rulesProps = {}
    retval = rulesProps
    retval["odr.rules.name"] = splitOffName(rulesId)
    collectSimpleProperties(rulesProps,"odr.rules.prop",rulesId,["name"],getSimpleChildren=1,collectListChildren=1,collectPropertyAttributes=1)
    
  except:
    _app_exception("Unexpected problem in getODRRulesProperties()")
  
  _app_exit("getODRRulesProperties(retval=%d)" % len(retval))
  return retval
  
    