################################################################################
# ProcessServiceClass.py
#
#   This module contains the functions that process a dictionary with multiple
#   Service Policy settings and applies them to the configuration.
#
#   Requires: ServiceClass.py, Utils.py, common.py
#
#   Primary Entry Point: 
#     processServiceClasses(scConfigInfo)
#
# -- Property Syntax Example: Use dumpConfig.py to export from existing system -- 
#
# app.im.serviceclass.1.name = Default_SP
# app.im.serviceclass.1.ServiceClassGoal.type = DiscretionaryGoal
# app.im.serviceclass.1.ServiceClassGoal.prop.importance = 1
# app.im.serviceclass.1.TransactionClasses.1.type = TransactionClass
# app.im.serviceclass.1.TransactionClasses.1.prop.name = Default_TC
# app.im.serviceclass.1.TransactionClasses.count = 1

# app.im.serviceclass.2.name = MyNewServicePolicy
# app.im.serviceclass.2.prop.description = My updated service policy
# app.im.serviceclass.2.ServiceClassGoal.type = PercentileResponseTimeGoal
# app.im.serviceclass.2.ServiceClassGoal.prop.goalDeltaPercent = 15
# app.im.serviceclass.2.ServiceClassGoal.prop.goalDeltaValue = 0
# app.im.serviceclass.2.ServiceClassGoal.prop.goalDeltaValueUnits = 0
# app.im.serviceclass.2.ServiceClassGoal.prop.goalPercent = 90
# app.im.serviceclass.2.ServiceClassGoal.prop.goalValue = 500
# app.im.serviceclass.2.ServiceClassGoal.prop.goalValueUnits = 0
# app.im.serviceclass.2.ServiceClassGoal.prop.importance = 60
# app.im.serviceclass.2.ServiceClassGoal.prop.timePeriodValue = 3
# app.im.serviceclass.2.ServiceClassGoal.prop.timePeriodValueUnits = 2
# app.im.serviceclass.2.ServiceClassGoal.prop.violationEnabled = true
# app.im.serviceclass.2.TransactionClasses.1.type = TransactionClass
# app.im.serviceclass.2.TransactionClasses.1.prop.name = Default_TC_MyNewServicePolicy
# app.im.serviceclass.2.TransactionClasses.2.type = TransactionClass
# app.im.serviceclass.2.TransactionClasses.2.prop.description = Example of a custom transaction class
# app.im.serviceclass.2.TransactionClasses.2.prop.name = CustomTCMyNewServicePolicy
# app.im.serviceclass.2.TransactionClasses.count = 2
#
# app.im.serviceclass.count = 2
#
# --- Service Policy Deletion Example ---
# The following syntax can be used to specify Service Policies to be deleted
# 
# del.im.serviceclass.1.name = ServicePolicyAlpha
# del.im.serviceclass.2.name = MyNewServicePolicy
# del.im.count = 2

################################################################################


#-------------------------------------------------------------------------------
# processServiceClassDeletions
#
# Parameters
#
#-------------------------------------------------------------------------------
def processServiceClassDeletions(scConfigInfo):
  _app_entry("processServiceClassDeletions(scConfigInfo)")
  
  try:
    delCount = int(scConfigInfo.get("del.im.serviceclass.count",0))
    if (delCount > 0):
      for idx in range(1,delCount+1):
        delName = scConfigInfo.get("del.im.serviceclass.%d.name" % idx)
        if (not isEmpty(delName)):
          delId = removeServiceClass(delName)
          if (isEmpty(delId)):
            _app_message("Service Policy %s was not defined - no deletion necessary" % delName)
          else:
            _app_message("Service policy %s was deleted" % delName)
  except:
    _app_exception("Unexpected problem in processServiceClassDeletions()")
  
  _app_exit("processServiceClassDeletions()")
  


#-------------------------------------------------------------------------------
# getTransactionClassList
#   Utility method that will turn properties into a list of dictionaries
#   that represent transaction class input
#
# Parameters
#    tcDict - dictionary to pull transaction class properties from
#    prefix - prefix to use with property keys
#
#-------------------------------------------------------------------------------
def getTransactionClassList(tcDict,prefix):
  _app_entry("getTransactionClassList(tcDict,%s)" , prefix)
  retval = []
  try:
    tcCount = int(tcDict.get("%s.TransactionClasses.count"%prefix,0))
    if (tcCount > 0):
      for idx in range(1,tcCount+1):
        tempDict = toDictionary(getPropList(tcDict,"%s.TransactionClasses.%d" % (prefix,idx)))
        retval.append(tempDict)
  except:
    _app_exception("Unexpected problem in getTransactionClassList()")
  
  _app_exit("getTransactionClassList(retval=%s)" % retval)
  return retval
 

#-------------------------------------------------------------------------------
# processIndividualServiceClass
#
# Parameters
#    scConfigInfo - dictionary with the settings to apply
#    prefix - Property key prefix to use with dictionary
#    scName - name of Service Policy to be processed
#
#-------------------------------------------------------------------------------
def processIndividualServiceClass(scConfigInfo,prefix,scName):
  _app_entry("processIndividualServiceClass(scConfigInfo,%s,%s)" , prefix,scName)
  
  try:
    #some stuff
    scId = getServiceClassId(scName)
    if (isEmpty(scId)):
      _app_message("Service Policy %s is not defined" % scName)
      tcList = getTransactionClassList(scConfigInfo,prefix)
      baseProps = getPropList(scConfigInfo,prefix)
      goalProps = getPropList(scConfigInfo,"%s.ServiceClassGoal"%prefix)
      goalType = scConfigInfo.get("%s.ServiceClassGoal.type" % prefix)
      
      scId = createServiceClass(scName,baseProps,goalType,goalProps,tcList)
      _app_message("Service Policy %s has been created" % (scName))
    else:
      _app_message("Service Policy %s is defined" % scName)
      existingProps = getServiceClassProperties(scId)
      
      inputTcList = getTransactionClassList(scConfigInfo,prefix)
      existingTcList = getTransactionClassList(existingProps,"serviceclass")
      
      # List/dictionary comparison goes deep 
      if (inputTcList == existingTcList):
        # Use None to indicate that no updates are required
        inputTcList = None
      
      baseProps = getPropListDifferences(scConfigInfo,prefix,existingProps,"serviceclass")
      inputGoalType = scConfigInfo.get("%s.ServiceClassGoal.type" % prefix)
      goalProps = None
      if (not isEmpty(inputGoalType)):
        existingGoalType = existingProps.get("serviceclass.ServiceClassGoal.type")
        goalProps = None
        if (inputGoalType == existingGoalType):
          goalProps = getPropListDifferences(scConfigInfo,"%s.ServiceClassGoal"%prefix,existingProps,"serviceclass.ServiceClassGoal")
        else:
          goalProps = getPropList(scConfigInfo,"%s.ServiceClassGoal"%prefix)
      
      if (inputTcList != None or len(baseProps) > 0 or len(goalProps) > 0):
        modifyServiceClass(scName,scId,baseProps,inputGoalType,goalProps,inputTcList)
        _app_message("Service Policy %s has been updated" % scName)
      else:
        _app_message("No updates are required for Service Policy %s" % scName)
        
      
  except:
    _app_exception("Unexpected problem in processIndividualServiceClass()")
  
  _app_exit("processIndividualServiceClass()")
  

#-------------------------------------------------------------------------------
# processServiceClass
#   Primary entry point for this module
#
# Parameters:
#    scConfigInfo - dictionary with the settings to apply
#
#-------------------------------------------------------------------------------
def processServiceClasses(scConfigInfo):
  _app_entry("processServiceClass(scConfigInfo)")
  
  try:
    # Process deletions first
    processServiceClassDeletions(scConfigInfo)
    
    scCount = int(scConfigInfo.get("app.im.serviceclass.count",0))
    if (scCount > 0):
      for idx in range(1,scCount+1):
        prefix = "app.im.serviceclass.%d" % idx
        scName = scConfigInfo.get("%s.name" % prefix)
        if (isEmpty(scName)):
          #partial list
          continue
          
        processIndividualServiceClass(scConfigInfo,prefix,scName)
    
  except:
    _app_exception("Unexpected problem in processServiceClass()")
  
  _app_exit("processServiceClass()")
  