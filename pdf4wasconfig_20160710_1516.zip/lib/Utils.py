#########################################################################
# File Name:    Utils.py
# Description:  This file contains common function definitions for the
#               scripting framework
#
#               _app_message
#               _app_trace
#               _app_entry
#               _app_exit
#               _app_debug
#               configSave
#               determineConditionalValues
#								evaluateKeepRule
#               existsCoreGroupPolicy
#               existsSIBDestination
#               existsSIBEngine
#               existsSIBJMSActivationSpec
#               existsSIBJMSQueue
#               existsSIBusMember
#               existsWebSphereVariable
#               filterProperties
#               funcArgs
#								getComparableProperties
#               getContainmentPath
#               getModifiedProperties
#								getNodeForServer
#               getOptionalProperty
#               getPortForServer
#								getPropListDifferences
#               getResourceAdapterId
#               getWebSphereVariableMapID
#								getPropList
#								getPropListWithMatchingName
#               initialise
#               isEmpty
#               mergeMissingProperties
#               modifyObject
#               objectExists
#               parseIterateMacroParms
#               parsePropertyXML
#								removeDynamicKeys
#               removeAllCustomProperties
#               scopeInfoString
#               searchReplaceFile
#								setDynamicId
#								setDynamicKeys
#								storePropertiesInSet
#								substituteDynamicValues
#               transformPropertyKeys
#               tron
#               troff
#               trlogon
#               trlogoff
#               trlogclear
#               updateCustomProperties
#
##########################################################################


#-----------------------------------------------------------------------------
# Utility method that will only call AdminConfig.showAttribute() for the name
# if it has to because the name has a left parenthesis in it
#-----------------------------------------------------------------------------
def splitOffName(configId):
  retval = ""
  try:
    parentokens = configId.split("(")
    if (len(parentokens) == 2):
      retval = parentokens[0]
      if (retval.startswith('"')):
        retval = retval[1:]
    
    if (isEmpty(retval)):
      # Name must have had ( in it or was not part of ID
      retval = AdminConfig.showAttribute(configId,"name")
  except:
    pass
  
  return retval


#------------------------------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------------------------------
storedCellName = None
storedCellId = None


def getCellName():
  global storedCellName
  
  if (isEmpty(storedCellName)):
    try:
      storedCellName = AdminControl.getCell()
    except:
      cells = AdminConfig.getid("/Cell:/").splitlines()
      for cell in cells:
        if (not isEmpty(cell)):
          storedCellName = splitOffName(cell)
          break
        
  
  return storedCellName
  
#------------------------------------------------------------------------------------------------------
# getCellId
#------------------------------------------------------------------------------------------------------
def getCellId():
  global storedCellId
  if (storedCellId == None):
    storedCellId = AdminConfig.getid("/Cell:%s/" % getCellName())
  
  return storedCellId

#----------------------------------------------------
# formatExceptionData
#
# Formats exception data for _app_message or _app_trace
#
# Parameters:
#   tnow - timestamp string to use
#
# Returns formatted string
#----------------------------------------------------
def formatExceptionData(tnow):
    import traceback
    
    resultString = ""
    exceptionString = tnow
    exc_type,exc_value,exc_traceback = sys.exc_info()
    exceptionString = "%s %s %s" % (tnow, exc_type, exc_value)
    
    resultString = exceptionString
    
    resultString = resultString + "\n" + "%s Frame stack:"% tnow
    try:
      stacklist = traceback.extract_stack()
      for stackdata in stacklist:
        stackfile,stackln,stackfn,stacktext = stackdata
        
        # Remove calls to _app_trace from stack
        if (stackfn != None and stackfn.find("_app_trace") >=0):
              break
        if (stacktext != None and stacktext.find("_app_trace") >= 0):
              break
        if (stackfn != None and stackfn.find("_app_exception") >=0):
              break
        if (stacktext != None and stacktext.find("_app_exception") >= 0):
              break              
        
        resultString = resultString + "\n" + '%s   File "%s", line %s, in %s' % (tnow, stackfile, stackln, stackfn)

    except:
      resultString = resultString + "\n" + "error gettng stack"
      pass    

    resultString = resultString + "\n" + "%s Exception stack:" % tnow
    try:
      tb = sys.exc_info()[2]
      tblist = traceback.extract_tb(tb,10)
      for tbdata in tblist:
        stackfile,stackln,stackfn,stacktext = tbdata          
        resultString = resultString + "\n" + '%s   File "%s", line %s, in %s' % (tnow, stackfile, stackln, stackfn)
        if (stacktext != None and stacktext != ""):
            resultString = resultString + "\n" + "%s    %s" % (tnow,stacktext)
      resultString="%s\n" % resultString
    except:
      resultString = resultString + "\n" + "error getting exception stack"
      pass
      
    return resultString

global _app_message
global _app_trace
global _app_entry
global _app_enter
global _app_exit

##########################################################################
#
# FUNCTIONS:
#    _app_message 
#    _app_trace: 
#
#    Print out trace information
#
# SYNTAX:
#    _app_message (args)
#    _app_trace   (type, args, force)
## PARAMETERS:
#    
#    type	- [entry|exit|debug] referring to type of trace message
#		  default = debug
#    args       - a string to be printed as a helpful trace message
#    force	- force display even if trace is off (1 = force; 0 = no force)
#
# USAGE NOTES:
#    1. Call _app_trace at the beginning and end of every procedure.
#    2. Call _app_trace at processing points that you think are significant.
#    3. Turn the facility on at runtime by setting the property
#       progInfo["trace"] = 1 in a properties file and including the -p
#       option on starting wsadmin.
#    4. Use _app_message to force output to the console regardless of trace settings
#
# RETURNS:
#    N/A
#
# IMPLEMENTATION:
#    1. Display the parameter string.
#
##########################################################################
def _app_message(args):
	_app_trace(args, "none", 1)

def _app_enter(fmtstr,*vals):
  _app_entry(fmtstr,*vals)

def _app_entry(fmtstr,*vals):
  global progInfo
  if (progInfo["app.trace.level"] != 0):
    if (vals != None and len(vals) > 0):
      _app_trace(fmtstr%vals,"enter")
    else:
      _app_trace(fmtstr,"enter")

def _app_exit(fmtstr,*vals):
  global progInfo
  if (progInfo["app.trace.level"] != 0):
    if (vals != None and len(vals) > 0):
      _app_trace(fmtstr%vals,"exit")
    else:
      _app_trace(fmtstr,"exit")
  

def _app_debug(fmtstr,*vals):
  global progInfo
  if (progInfo["app.trace.level"] != 0):
    if (vals != None and len(vals) > 0):
      _app_trace(fmtstr%vals,"debug")
    else:
      _app_trace(fmtstr,"debug")  

def _app_exception(args,raiseError=1,forceExit=0):
  _app_trace(args,"exception",1)
  if (forceExit):
    exit()
  if (raiseError):
    raise StandardError(args)
  
def _app_trace(args, ttype="debug", force = 0):
	import sys
	
	
	global progInfo
	ltype = ttype.lower()
	
	# You know what, let's always add exception data to stdout
	if ltype == "exception" and force == 0:
		# Hey hey, let's have some standard handling of exception data to stdout
		from java.util import Date
		from java.text import SimpleDateFormat
		
		import traceback
		
		now = Date()
		sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS z")
		tnow = "[%s]" % (sdf.format(now))
		
		print "%s %s" % (tnow,args)		
		print formatExceptionData(tnow)
		


		
		
			

	#	If tracing is enabled then print out args
	if force == 1 or progInfo["app.trace.level"] != 0:
		
		
		if ltype not in ("entry", "enter","exit", "debug", "exception", "none"):
			print "Bad 1st argument to _app_trace(); expected entry|exit|debug|exception|none"
			return

		from java.util import Date
		from java.text import SimpleDateFormat
		
		now = Date()
		sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS z")
		tnow = "[%s]" % (sdf.format(now))
			
		tabs = int(progInfo.get("app.trace.spaces","2"))
				
		if ltype == "entry" or ltype == "enter":
			printStr = "%*s%s > %s" % (progInfo["app.trace.current"], " ", tnow, args)
			progInfo["app.trace.current"] = progInfo["app.trace.current"] + tabs
		elif ltype == "exit":
			if progInfo["app.trace.current"] >= tabs:
				progInfo["app.trace.current"] = progInfo["app.trace.current"] - tabs
			printStr = "%*s%s < %s" % (progInfo["app.trace.current"], " ", tnow, args)
		elif ltype == "debug":
			printStr = "%*s%s (d) %s" % (progInfo["app.trace.current"], " ", tnow, args)
		elif ltype == "none":
			printStr = "%s %s" % (tnow, args)
		elif ltype == "exception":
			
			#AdminConfig.reset()
			printStr =  "%*s%s (E) %s" % (progInfo["app.trace.current"], " ", tnow, args)
			
			printStr = printStr +"\n" + formatExceptionData("%*s%s (E)" % (progInfo["app.trace.current"], " ", tnow))
			#i = 1;
			
			#for exc in sys.exc_info():
			#	printStr += "\n(%d): %s" % (i, exc)
			#	i = i + 1
			
			
			
				
		if force != 1 and progInfo["app.trace.log"] == 1:
			writeStr = "%s%s" % (printStr, progInfo["line.separator"])
			
			progInfo["app.trace.tracelogfp"].write(writeStr)
			progInfo["app.trace.tracelogfp"].flush()
		elif force == 1 or progInfo["app.trace.log"] == 0:
			print printStr


##########################################################################
#
# FUNCTION:
#    configSave: Save configuration changes
#
# SYNTAX:
#    configSave()
#
# RETURNS:
#    	N/A
#
##########################################################################
def configSave():
	global progInfo
	
	if progInfo["app.autosave"] == "true":
		_app_trace("Saving configuration...")
		AdminConfig.save()

##########################################################################
# isCheckSettingsEnabled
#
# Returns 1 to indicate that code should check existing settings before doing
# an update.  Driven by the app.minimizeChecks = [true|false] program property.
##########################################################################
def isCheckSettingsEnabled(componentID = None):
	global progInfo
	retval = 1
	
	if (componentID != None):
	  if (progInfo.get("app.minimizeChecks.%s" % componentID,"false") == "true"):
	    retval = 0
	
	# Global setting overrides all    
	if (progInfo.get("app.minimizeChecks","false") == "true"):
		retval = 0
	
	return retval


#-----------------------------------------------------------------------------------------------------
# wildcardToRegExpString - converts a string that treats asterisk as wild card to regular expression 
# string,  "Hello*" -> "Hello.*?"
#-----------------------------------------------------------------------------------------------------  
def wildcardToRegExpString(inStr,wildcard='*'):
 
  retval = ""
  if (isEmpty(inStr)):
    retval = ".*"
  elif (inStr.find(wildcard) <0):
    # Not a supported syntax
    retval = inStr
  elif (inStr == "*"):
    retval = ".*"
  else:
    prefix = "";
    if (inStr.startswith(wildcard)):
      prefix = ".*?"
    suffix = ""
    if (inStr.endswith(wildcard)):
      suffix = ".*?";
    else:
      suffix = "$"
    
    tokens = inStr.split(wildcard)
    retval = ""
    for token in tokens:
     
      if (retval == ""):
        retval = token
      elif (token != ""):
        retval = "%s.*?%s" % (retval,token)
    
    retval = "%s%s%s" % (prefix,retval,suffix)
    
 
  return retval

def passwordSafeDictString(inDict):
  tempDict = {}
  
  for key in inDict.keys():
    tempDict[key] = inDict[key]
    if (key.lower().find("password") >= 0):
      tempDict[key] = "placeholder"
  
  return str(tempDict)
      
  
  


#---------------------------------------------------------------------------------------------------------
# filterList - apply a pattern to a list of IDs by getting the name attribute of each configuration item
# and checking to see if it matches the pattern
#---------------------------------------------------------------------------------------------------------
def filterList(inList, namePattern,clusterPattern=None,nodePattern=None,serverPattern=None):
  import re
  retval = []
  if (isEmpty(namePattern) and isEmpty(clusterPattern) and isEmpty(nodePattern) and isEmpty(serverPattern)):
    return inList
  
  for configId in inList:
    if (isEmpty(configId)):
      continue
    
    try:
      nameValue = AdminConfig.showAttribute(configId,"name")
      #print "Matching %s against %s" % (pattern,nameValue)
      if (not re.match(namePattern,nameValue)):
            #print "No match"
            continue
      else:
        
        c,n,s,dc,app,appdep = getScope(configId)
        
        if (isEmpty(clusterPattern) and not isEmpty(c)):
          continue
        
        if (isEmpty(nodePattern) and not isEmpty(n)):
          continue
        
        if (isEmpty(serverPattern) and not isEmpty(s)):
          continue
          
        if (isEmpty(s) and not isEmpty(serverPattern) and not isEmpty(nodePattern) and isEmpty(clusterPattern)):
          # Handle the case when we want just server scoped and not nodes,cells,or clusters
          continue
          
        if (isEmpty(c) and not isEmpty(clusterPattern) and isEmpty(nodePattern) and isEmpty(serverPattern)):
          # Handle the case we're were iterating across clusters and not all scopes
          continue

        if (isEmpty(n) and not isEmpty(nodePattern) and isEmpty(clusterPattern) and isEmpty(serverPattern)):
          # Handle the case we're were iterating across nodes and not all scopes
          continue
          
          
        if (not isEmpty(clusterPattern)):
          if (clusterPattern.find("*") >= 0):
            if (not re.match(clusterPattern,c)):
              continue
          elif (clusterPattern != c):
            continue
        
        if (not isEmpty(nodePattern)):
          if (nodePattern.find("*") >= 0):
            if (not re.match(nodePattern,n)):
              continue
          elif (nodePattern != n):
            continue
        
        if (not isEmpty(serverPattern)):
          if (serverPattern.find("*") >= 0):
            if (not re.match(serverPattern,s)):
              continue
          elif (serverPattern != s):
            continue
        
        #print "Matched"
        retval.append(configId)
          
    except:
      _app_trace("Pattern matching exception","exception")
      raise StandardError("Pattern matching exception")
  
  return retval

#-------------------------------------------------------------------------
# Parses xml string of the following format and returns name/value tuple
# <Property name="webserverName" value="ScriptingCell_ScriptingNode1_IHS1"/>
#
#
def parsePropertyXML(xmlstring):
  retval = None
  
  if (xmlstring != None and xmlstring.startswith("<Property")):
    nameidx = xmlstring.find('name="')
    valueidx = xmlstring.find('value="')
    if (nameidx > 0 and valueidx > 0):
      nameend = xmlstring.find('"',nameidx+6)
      valueend = xmlstring.find('"',valueidx+7)
      nameval = xmlstring[nameidx+6:nameend]
      valueval = xmlstring[valueidx+7:valueend]
      retval = (nameval,valueval)
     
  return retval    
      
      


##########################################################################
# Parses a string and returns comma seperated strings between () as an array of strings
##########################################################################
def parseFunctionParms(inputStr):
  retval = []
  
  idx1 = inputStr.find("(")
  idx2 = inputStr.find(")")
  if (idx1 >= 0 and idx2 >= 0):
    templist = inputStr[idx1+1:idx2].split(",")
    for tempstr in templist:
      tempstr = tempstr.strip()
      retval.append(tempstr)
  
  return retval

#-------------------------------------------------------------------------------
# parseIterateMacroParms
#
# Utility method that performs common routine of determining the patterns 
# passed in to a special @ITERATE macro. 
#
# The macro argument comes in two formats
#    @ITERATE - iterates over all logical matches
#    @ITERATE(*wildcard*pattern") - specifies pattern with asterisk wildcard support
# 
# Parameters:
#    currentDoIterationValue - value to initialize the doIteration result with. 
#    inputString - The string with a possible @ITERATE argument
#
# Returns doIteration,pattern,wildcardPattern
#    where doIteration =  true if @ITERATE was specified, otherwise value of currentDoIterationValue
#          pattern - the pattern argument of doIterate - caller will use for logging
#          wildcardPattern - the pattern converted into a valid regular expression
#-------------------------------------------------------------------------------
def parseIterateMacroParms(inputString,currentDoIterationValue=0):
  doIteration = currentDoIterationValue
  tempPattern = inputString
  tempWildcard = inputString
  if (inputString.find("@ITERATE") >= 0):
     doIteration = 1
     tempArgs = parseFunctionParms(inputString)
     if (len(tempArgs) > 0):
        tempPattern = tempArgs[0]
     else:
        tempPattern = "*"
     #endelse  
     tempWildcard = wildcardToRegExpString(tempPattern)
  #endif
    
  return doIteration,tempPattern,tempWildcard
#enddef

#---------------------------------------------------
# parseIterateToRegularExpression
#
# inputString - literal, @ITERATE or @ITERATE(wildcard-pattern)
#
# Returns literanl, .* or regular expression of wildcard-pattern
#---------------------------------------------------
def parseIterateToRegularExpression(inputString):
  namePattern = inputString
  if (inputString.startswith("@ITERATE")):
    tempArgs = parseFunctionParms(inputString)
    tempName = None
    if (len(tempArgs) > 0):
      tempName = tempArgs[0]
    else:
      tempName = "*"
            
    namePattern = wildcardToRegExpString(tempName)
    
  return namePattern
          
 
  
#########################################################################
# scopeInfoString
#
# Create a string for printing out formatted scope information in a log statement
#
# Parameters:
#    cluster - possible cluster name
#    node - possible node name
#    server - possible server 
#
# Returns one of the following:
#     Cell
#     Cluster:cluster
#     Node:node
#     Server:node/server
#########################################################################
def scopeInfoString(cluster,node,server,dynamicCluster=None,appDeployment=None):
  retval = "Cell"
  
  if (not isEmpty(cluster)):
    retval = "Cluster:%s" % cluster
  elif (not isEmpty(dynamicCluster)):
    if (not isEmpty(server)):
      retval = "DynamicCluster:%s/Server:%s" % (dynamicCluster,server)
    else:
      retval = "DynamicCluster:%s" % (dynamicCluster)
  elif (not isEmpty(server)):
    retval = "Server:%s/%s" % (node,server)
  elif (not isEmpty(node)):
    retval = "Node:%s" % node
  elif (not isEmpty(appDeployment)):
    retval = "Deployment:%s" % appDeployment
  
  return retval		
  
		
##########################################################################
#
# FUNCTION:
#    existsCoreGroupPolicy: Checks if policy already exists in core group
#
# SYNTAX:
#    existsCoreGroupPolicy(policyName, coreGroupName)
#
# PARAMETERS:
#    
#    policyName		- Policy name
#    coreGroupName	- Core group to search within
#
# RETURNS:
#    	1:	Core group policy exists
#	0:	Core group policy does not exist
#
##########################################################################
def existsCoreGroupPolicy(policyName, coreGroupName):

 	retval = {}
 
 	try:
 		traceStr = "existsCoreGroupPolicy(%s, %s)" % (policyName, coreGroupName)
 		_app_trace(traceStr, "entry")	
 	
		if isEmpty(policyName) or isEmpty(coreGroupName):
			raise StandardError("Policy name or core group name missing")

		if not objectExists("CoreGroup", None, coreGroupName):
			raise StandardError("Core Group %s does not exist" % (coreGroupName))

		configID = "/CoreGroup:%s/" % (coreGroupName)
		scopeID = AdminConfig.getid(configID)

		if isEmpty(scopeID):
			raise StandardError("Could not get containment path")
		
		policyStr = AdminConfig.showAttribute(scopeID, "policies")
		_app_trace("Found policies: %s" % (policyStr))

		if isEmpty(policyStr):
			retval = 0
		else:

			#	We cannot turn policyStr into a list.  showAttribute()
			#	returns a string and not a list (as in JACL) and
			#	one of the policies may have a space in it 

			#	Side effect is that it will find partial matches

			startIdx = policyStr.find(policyName)
			length = len(policyStr)
			endIdx = policyStr[startIdx:length].find(")") + startIdx + 1 

			policyId = policyStr[startIdx:endIdx]
			_app_trace("Looking for %s in core group %s" % (policyId, policyStr))

			if policyId.find(policyName) == -1:
				retval = 0
			else:
				retval = 1
 	except:
 		_app_trace("An error was encountered checking existence of Core Group Policy", "exception")
 		retval = 0
 
 	_app_trace("existsCoreGroupPolicy(%d)" % (retval), "exit")
 	return retval

##########################################################################
#
# FUNCTION:
#    existsSIBDestination: Checks if SIB Destination already exists on bus
#
# SYNTAX:
#    existsSIBDestination(name, bus)
#
# PARAMETERS:
#    
#    name	- SIB Destination name
#    bus 	- Name of SIBus to search
#
# RETURNS:
#    	1:	SIBus Member exists
#	0:	SIBus Member does not exist
#
##########################################################################
def existsSIBDestination(name, bus):
 
 	retval = {}
 
 	try:
 		traceStr = "existsSIBDestination(%s, %s)" % (name, bus)
 		_app_trace(traceStr, "entry")	
 	
		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))

		#	Call showSIDestination, it will throw an exception if 
		#	SIB destination does not exist
		try:
			attributes  = ' -bus "%s"'  % (bus)
			attributes += ' -name "%s"' % (name)

			_app_trace("Running command: AdminTask.showSIBDestination(%s)" % (attributes))
			if isEmpty(AdminTask.showSIBDestination("%s" % (attributes))):
				retval = 0
			else:
				retval = 1
		except:
			retval = 0
 	except:
 		_app_trace("An error was encountered checking existence of the SIB Destination", "exception")
 		retval = 0
 
 	_app_trace("existsSIBDestination(%d)" % (retval), "exit")
 	return retval
 
##########################################################################
#
# FUNCTION:
#    existsSIBEngine: Checks if SIB Engine already exists on bus
#
# SYNTAX:
#    existsSIBEngine(name, bus, cluster, node, server)
#
# PARAMETERS:
#    
#    name	- SIB Engine name (Cluster only)
#    bus 	- Name of SIBus to search
#    cluster	- Cluster name to match
#    node	- Node name to match
#    server	- Server name to match
#
# RETURNS:
#    	1:	SIBus Member exists
#	0:	SIBus Member does not exist
#
##########################################################################
def existsSIBEngine(name, bus, cluster, node, server):
 
 	retval = {}
 
 	try:
 		traceStr = "existsSIBusEngine(%s, %s, %s, %s, %s)" % (name, bus, cluster, node, server)
 		_app_trace(traceStr, "entry")	
 	
 		configID = getContainmentPath(cluster, node, server, 1)
 		
 		if isEmpty(configID):
 			raise StandardError("Could not get containment path")
 		
 		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))

		#	Call showSIBusEngine, it will throw an exception if engine
		#	does not exist
		try:
			if isEmpty(cluster):
				attributes = '-bus "%s" -node %s -server %s' % (bus, node, server)
			else:
				attributes = '-bus "%s" -cluster %s' % (bus, cluster)

				if not isEmpty(name):
					attributes += ' -engine "%s"' % (name)

			_app_trace("Running command: AdminTask.showSIBEngine(%s)" % (attributes))
			id = AdminTask.showSIBEngine("%s" % (attributes))

			if isEmpty(id):
				retval = 0
			else:
				retval = 1
		except:
			retval = 0
 	except:
 		_app_trace("An error was encountered checking existence of the SIB Bus Member", "exception")
 		retval = 0
 
 	_app_trace("existsSIBusEngine(%d)" % (retval), "exit")
 	return retval

##########################################################################
#
# FUNCTION:
#    existsSIBJMSActivationSpec: Checks if SIB JMS Activation Spec already exists on bus
#
# SYNTAX:
#    existsSIBJMSActivationSpec(name, bus, cluster, node, server)
#
# PARAMETERS:
#    
#    name	- SIB Engine name (Cluster only)
#    cluster	- Cluster name to match
#    node	- Node name to match
#    server	- Server name to match
#
# RETURNS:
#    	1:	SIBus JMS Activation Spec exists
#	0:	SIBus JMS Activation Spec does not exist
#
##########################################################################
def existsSIBJMSActivationSpec(name, cluster, node, server):
 
 	retval = {}
 
 	try:
 		traceStr = "existsSIBJMSActivationSpec(%s, %s, %s, %s)" % (name, cluster, node, server)
 		_app_trace(traceStr, "entry")	
 	
 		configID = getContainmentPath(cluster, node, server, 1)
 		
 		if isEmpty(configID):
 			raise StandardError("Could not get containment path")
 			
		parentID = AdminConfig.getid(configID)
		_app_trace("ParentID = %s" % (parentID))

		idList  = AdminTask.listSIBJMSActivationSpecs(parentID)
		_app_trace("idList = %s" % (idList))

		if isEmpty(idList):
			retval = 0
		else:
			qList = idList.split(progInfo["line.separator"])
			_app_trace("qList = %s" % (qList))

			retval = 0

			for q in qList:
				nameAttr = AdminConfig.showAttribute(q, "name")

				_app_trace("Matching SIB JMS Activation Spec %s with %s" % (nameAttr, name))

				if name == nameAttr:
					retval = 1
					break
 	except:
 		_app_trace("An error was encountered checking existence of the SIB JMS Activation Spec", "exception")
 		retval = 0
	
 	_app_trace("existsSIBJMSActivationSpec(%d)" % (retval), "exit")
 	return retval

##########################################################################
#
# FUNCTION:
#    existsSIBJMSQueue: Checks if SIB JMS Queue already exists on bus
#
# SYNTAX:
#    existsSIBJMSQueue(name, bus, cluster, node, server)
#
# PARAMETERS:
#    
#    name	- SIB Engine name (Cluster only)
#    cluster	- Cluster name to match
#    node	- Node name to match
#    server	- Server name to match
#
# RETURNS:
#    	1:	SIBus JMS Queue exists
#	0:	SIBus JMS Queue not exist
#
##########################################################################
def existsSIBJMSQueue(name, cluster, node, server):
 
 	retval = {}
 
 	try:
 		traceStr = "existsSIBJMSQueue(%s, %s, %s, %s)" % (name, cluster, node, server)
 		_app_trace(traceStr, "entry")	
 	
 		configID = getContainmentPath(cluster, node, server, 1)
 		
 		if isEmpty(configID):
 			raise StandardError("Could not get containment path")

		parentID = AdminConfig.getid(configID)
		_app_trace("ParentID = %s" % (parentID))

		idList  = AdminTask.listSIBJMSQueues(parentID)
		_app_trace("idList = %s" % (idList))

		if isEmpty(idList):
			retval = 0
		else:
			qList = idList.split(progInfo["line.separator"])
			_app_trace("qList = %s" % (qList))

			retval = 0

			for q in qList:
				nameAttr = AdminConfig.showAttribute(q, "name")

				_app_trace("Matching SIB JMS Queue %s with %s" % (nameAttr, name))

				if name == nameAttr:
					retval = 1
					break
 	except:
 		_app_trace("An error was encountered checking existence of the SIB JMS Queue", "exception")
 		retval = 0
	
 	_app_trace("existsSIBJMSQueue(%d)" % (retval), "exit")
 	return retval
 	
##########################################################################
#
# FUNCTION:
#    existsSIBJMSTopic: Checks if SIB JMS Topic already exists on bus
#
# SYNTAX:
#    existsSIBJMSTopic(name, bus, cluster, node, server)
#
# PARAMETERS:
#    
#    name	- Topic name
#    cluster	- Cluster name to match
#    node	- Node name to match
#    server	- Server name to match
#
# RETURNS:
#    	1:	SIBus JMS Topic exists
#	    0:	SIBus JMS Topic not exist
#
##########################################################################
def existsSIBJMSTopic(name, cluster, node, server):
 
 	retval = {}
 
 	try:
 		traceStr = "existsSIBJMSTopic(%s, %s, %s, %s)" % (name, cluster, node, server)
 		_app_trace(traceStr, "entry")	
 	
 		configID = getContainmentPath(cluster, node, server, 1)
 		
 		if isEmpty(configID):
 			raise StandardError("Could not get containment path")

		parentID = AdminConfig.getid(configID)
		_app_trace("ParentID = %s" % (parentID))

		idList  = AdminTask.listSIBJMSTopics(parentID)
		_app_trace("idList = %s" % (idList))

		if isEmpty(idList):
			retval = 0
		else:
			qList = idList.split(progInfo["line.separator"])
			_app_trace("qList = %s" % (qList))

			retval = 0

			for q in qList:
				nameAttr = AdminConfig.showAttribute(q, "name")

				_app_trace("Matching SIB JMS Topic %s with %s" % (nameAttr, name))

				if name == nameAttr:
					retval = 1
					break
 	except:
 		_app_trace("An error was encountered checking existence of the SIB JMS Topic", "exception")
 		retval = 0
	
 	_app_trace("existsSIBJMSTopic(%d)" % (retval), "exit")
 	return retval



##########################################################################
#
# FUNCTION:
#    existsSIBusMember: Checks if SIBus Member already exists
#
# SYNTAX:
#    existsSIBusMember(bus, cluster, node, server)
#
# PARAMETERS:
#    
#    bus 	- Name of SIBus to search
#    cluster	- Cluster name to match
#    node	- Node name to match
#    server	- Server name to match
#
# RETURNS:
#    	1:	SIBus Member exists
#	0:	SIBus Member does not exist
#
##########################################################################
def existsSIBusMember(bus, cluster, node, server):
 
 	retval = {}
 
 	try:
 		traceStr = "existsSIBusMember(%s, %s, %s, %s)" % (bus, cluster, node, server)
 		_app_trace(traceStr, "entry")	
 	
 		configID = getContainmentPath(cluster, node, server, 1)
 		
 		if isEmpty(configID):
 			raise StandardError("Could not get containment path")
 			
 		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))
			
		#	Call showSIBusMember, it will throw an exception if member 
		#	does not exist
		try:
			if isEmpty(cluster):
				attributes = '-bus "%s" -node %s -server %s' % (bus, node, server)
			else:
				attributes = '-bus "%s" -cluster %s' % (bus, cluster)

			_app_trace("Running command: AdminTask.showSIBusMember(%s)" % (attributes))
			id = AdminTask.showSIBusMember("%s" % (attributes))

			if isEmpty(id):
				retval = 0
			else:
				retval = 1
		except:
			retval = 0
 	except:
 		_app_trace("An error was encountered checking existence of the SIB Bus Member", "exception")
 		retval = 0
 
 	_app_trace("existsSIBusMember(%d)" % (retval), "exit")
 	return retval
 
##########################################################################
#
# FUNCTION:
#    existsWebSphereVariable: Checks existence of WebSphere Environment Variable
#
# SYNTAX:
#    existsWebSphereVariable name, configID, isCluster), 
#
# PARAMETERS:
#
#    name:	Name of variable to locate
#    configID:	Usually from prior call to AdminConfig.getid()
#    isCluster:	Guess!
#
# USAGE NOTES:
#    Checks for existence of a WebSphere environment variable named 'name' at the desired scope

#
# RETURNS:
#	0	Variable does not exist
#    	1	Variable exists
#	-1:	Error encountered
#
# THROWS:
#    N/A
##########################################################################
def existsWebSphereVariable(name, configID, isCluster = 0):

	retval = 0

	try:
		global progInfo

		traceStr = "existsWebSphereVariable(%s, %s, %d)" % (name, configID, isCluster)
		_app_trace(traceStr, "entry")	

		if isEmpty(configID):
			retval = -1
		else:
			mapID = getWebSphereVariableMapID(configID, isCluster)
			if isEmpty(mapID):
				#retval = -1
				pass
			else:
				#	Add the entry, let the exception handlder handle duplicates
				entries = AdminConfig.showAttribute(mapID, "entries")
			        if isEmpty(entries):
					pass
				else:	
					entriesLen = len(entries) - 1
					entriesList = entries[1:entriesLen].split(" ")

					for entry in entriesList:
						symName = AdminConfig.showAttribute(entry, "symbolicName")
				
						if(symName == name):
							retval = 1
							break
		
	except:
		_app_trace("An error was encountered locating the WebSphere Variable", "exception")
		retval = 1

	_app_trace("existsWebSphereVariable(%d)" % (retval), "exit")
	return retval

##########################################################################
#
# FUNCTION:
#    funcArgs:  Displays function arguments for given function
#
# SYNTAX:
#    funcArgs(name)
#
# PARAMETERS:
#    
#    name               -   Function name
#
# RETURNS:
#    	List of function arguments
#
##########################################################################
def funcArgs(name):

	try:
		args  = "%s.func_code.co_varnames" % (name)
		argsc = "%s.func_code.co_argcount" % (name)

		argv = eval(args)
		argc = eval(argsc)

		argList = []

		for i in range(argc):
			argList.append(argv[i])

		return argList
	except:
		_app_trace("Error getting arg list for " + name)

##########################################################################
#
# FUNCTION:
#    getContainmentPath: Checks that either a cluster or node/server is
#			passed and returns containment path suitable
#			for AdminConfig.getid()
#  Combinations
#  ============
#  C   N   S   Valid?
#  -----------------
#  N   N   N   No
#  N   N   Y   No
#  N   Y   N   Yes*
#  N   Y   Y   Yes
#  Y   N   N   Yes
#  Y   N   Y   No
#  Y   Y   N   No
#  Y   Y   Y   No
#
#  * unless nodeAndServer flag is set
#
# SYNTAX:
#    getContainmentPath(cluster, node, server, nodeAndServer)
#
# PARAMETERS:
#    cluster 		- Name of cluster or None if using server/node
#    node		- Name of node or None if using cluster
#    server		- Name of server or None if using cluster
#    nodeAndServer	- Requires both node and server (defaults = 0)
#
# USAGE:
#
#    Use where a function needs to determine whether a cluster or
#    node/server argument is required.  Also can be used to determine
#    whether a node or node and server are required based on the 
#    nodeAndServer flag.  Outputs error messages as necessary, and as
#    a by-product returns the containment path for use in 
#    AdminConfig.getid(containment path) or objectExists() in this module
#
# RETURNS:
#	containment path string or None on error
#
##########################################################################
def getContainmentPath(cluster, node, server, nodeAndServer = 0):

	retval = None
	
	_app_trace("getContainmentPath(%s, %s, %s)" % (cluster, node, server), "entry")
	
	if isEmpty(cluster) and isEmpty(node) and isEmpty(server):
		#_app_trace("Cluster OR node/server required, not none")
		retval = "/Cell:/"
	elif (not isEmpty(cluster)) and (not isEmpty(node) or not isEmpty(server)):
		_app_trace("Cluster OR node/server required, not both")
	elif isEmpty(node) and not isEmpty(server):
		_app_trace("Node AND server required, not just server")
	elif nodeAndServer and (not isEmpty(node) and isEmpty(server)):
		_app_trace("Node AND server required, not just node")
	else:
		if not isEmpty(cluster):
			retval = "/ServerCluster:%s/" % (cluster)
		elif isEmpty(server):
			retval = "/Node:%s/" % (node)
		else:
			retval = "/Node:%s/Server:%s/" % (node, server)
		
	_app_trace("getContainmentPath(%s)" % (retval), "exit")
	return retval

#------------------------------------------------------------------------------------------------------
# getScopeId
# 
# Get the ID of the object defined by the scoping parameters
#------------------------------------------------------------------------------------------------------
def getScopeId(cluster, node, server,dynCluster=None):

  _app_trace("getScopeId(%s,%s,%s,%s)" % (cluster,node,server,dynCluster),"entry")
  result  = ''
  
  result = ''
  
  try:
    if (not isEmpty(cluster)):
        result = AdminConfig.getid("/ServerCluster:%s/"% cluster)
    elif (not isEmpty(node) and not isEmpty(server)):
        result = AdminConfig.getid("/Node:%s/Server:%s/" % (node,server))
    elif (not isEmpty(node)):
        result = AdminConfig.getid("/Node:%s/" % node)
    elif (not isEmpty(dynCluster) and not isEmpty(server)):
      result = AdminConfig.getid("/DynamicCluster:%s/Server:%s/" % (dynCluster,server))
    elif (not isEmpty(dynCluster)):
      result = AdminConfig.getid("/DynamicCluster:%s/" % (dynCluster))
    else:
        # Cell scope
        cells = AdminConfig.list("Cell").split(progInfo["line.separator"])
        for cell in cells:
            result = cell
            break
  
  except:
    _app_exception("Error determining scope Id")
      
      
  _app_trace("getScopeId(result = %s)" % (result),"exit")
  return result


##########################################################################
#
# FUNCTION:
#    getWebSphereVariableMapID: Returns VariableMap id
#
# SCOPE:
#    Private
#
# SYNTAX:
#    getWebSphereVariableMapID (configID, isCluster), 
#
# PARAMETERS:
#
#    configID:	Usually from prior call to AdminConfig.getid()
#    isCluster:	Guess!
#
# USAGE NOTES:
#    Returns VariableMap ID for WebSphere Variables at given scope
#
# RETURNS:
#	VariableMap ID or None on error
#
# THROWS:
#    N/A
##########################################################################
def getWebSphereVariableMapID(configID, isCluster = 0):

	retval = None

	try:
		global progInfo

		traceStr = "getWebSphereVariableMapID(%s, %d)" % (configID, isCluster)
		_app_trace(traceStr, "entry")	

		if not isEmpty(configID):
			#	There appears to be a bug for AdminConfig.getid('/ServerCluster:clustername/VariableMap:/')
			#	Therefore we have to use AdminConfig.list and use the first entry only
			#	(Applies to clusters only)
			#
			#	See PK08937
			if isCluster:
				clusterID = AdminConfig.getid(configID)
				mapID = AdminConfig.list("VariableMap", clusterID)
				if isEmpty(mapID):
					mapID = AdminConfig.create("VariableMap", clusterID, [])
			else:
				mapID = AdminConfig.getid(configID + "VariableMap:/")
			
#			if mapID == "" or mapID is None or len(mapID.split(progInfo["line.separator"])) != 1:
			if isEmpty(mapID) or len(mapID.split(progInfo["line.separator"])) != 1:
					# Its possible that we may need to create the variable map
					
					# Get the full configuration
					configId = AdminConfig.getid(configID)
					_app_trace("Creating VariableMap at scope %s" % configId)
					mapID = AdminConfig.create("VariableMap", configId, [])
					_app_trace("Created VariableMap %s" % mapID)
					
					# Now check it out
					if isEmpty(mapID) or len(mapID.split(progInfo["line.separator"])) != 1:
						raise StandardError("Cannot find or create variable map for %s" % (configID))

			retval = mapID
	
	except:
		_app_trace("An error was encountered locating the WebSphere VariableMap ID", "exception")
		retval = None

	_app_trace("getWebSphereVariableMapID(%s)" % (retval), "exit")
	return retval

##########################################################################
# getResourceAdapterId
##########################################################################
def getResourceAdapterId(pCluster,pNode,pServer,raName):
  _app_trace("getResourceAdapterId(%s,%s,%s,%s)" % (pCluster,pNode,pServer,raName),"entry")
  ra = None

  if (isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer)):
    ra = AdminConfig.getid("/Cell:%s/J2CResourceAdapter:%s/" % (AdminConfig.showAttribute(AdminConfig.getid("/Cell:/"),"name"),raName))
  elif (not isEmpty(pCluster)):
    ra = AdminConfig.getid("/ServerCluster:%s/J2CResourceAdapter:%s/" % (pCluster,raName))
  elif (not isEmpty(pServer) and not isEmpty(pNode)):
    ra = AdminConfig.getid("/Node:%s/Server:%s/J2CResourceAdapter:%s/" % (pNode,pServer,raName))
  elif (not isEmpty(pNode) and isEmpty(pServer)):
    ra = AdminConfig.getid("/Node:%s/J2CResourceAdapter:%s/" % (pNode,raName))
  else:
    ra = None

  _app_trace("getResourceAdapterId(retval = %s)" % ra, "exit")
  return ra
  
##########################################################################################
# matchItemsAtScope
# 
# Return a list of items that match the search criteria which can include wildcard
##########################################################################################
def matchItemsAtScope(namePattern, itemType="J2CResourceAdapter", clusterPattern=None, nodePattern=None, serverPattern=None,skipString=None):

   global progInfo
   retval = []

   try:
    traceStr = "matchItemsAtScope(%s,%s,%s,%s,%s)" % (namePattern, itemType, clusterPattern, nodePattern, serverPattern)
    _app_trace(traceStr, "entry")
    
    c = clusterPattern
    n = nodePattern
    s = serverPattern
    
    foundItems = ""
    
    # If name is not a pattern we can tighten the getid call
    if (namePattern.find("*") == -1):
      if (isEmpty(c) and isEmpty(n) and isEmpty(s)):
        foundItems = AdminConfig.getid("/Cell:%s/%s:%s/" % (AdminConfig.showAttribute(AdminConfig.getid("/Cell:/"),"name"),itemType,namePattern))
      elif (not isEmpty(c) and c.find("*") == -1):
        # Not a wildcard cluster pattern
        foundItems = AdminConfig.getid("/ServerCluster:%s/%s:%s/" % (c,itemType,namePattern) )
      elif (not isEmpty(s) and not isEmpty(n) and s.find("*") == -1 and n.find("*") == -1 ):
        foundItems = AdminConfig.getid("/Node:%s/Server:%s/%s:%s/" % (n,s,itemType,namePattern))
      elif (not isEmpty(n) and isEmpty(s) and n.find("*") == -1):
        foundItems = AdminConfig.getid("/Node:%s/%s:%s/" % (n,itemType,namePattern))
      else:
        foundItems = AdminConfig.getid("/%s:%s/"% (itemType,namePattern))
    else:
      if (isEmpty(c) and isEmpty(n) and isEmpty(s)):
        foundItems = AdminConfig.getid("/Cell:%s/%s:/" % (AdminConfig.showAttribute(AdminConfig.getid("/Cell:/"),"name"),itemType))
      elif (not isEmpty(c) and c.find("*") == -1):
        # Not a wildcard cluster pattern
        foundItems = AdminConfig.getid("/ServerCluster:%s/%s:/" % (c,itemType) )
      elif (not isEmpty(s) and not isEmpty(n) and s.find("*") == -1 and n.find("*") == -1 ):
        foundItems = AdminConfig.getid("/Node:%s/Server:%s/%s:/" % (n,s,itemType))
      elif (not isEmpty(n) and isEmpty(s) and n.find("*") == -1):
        foundItems = AdminConfig.getid("/Node:%s/%s:/" % (n,itemType))
      else:
        foundItems = AdminConfig.getid("/%s:/"%itemType)

    
    provider=None

    
    if (foundItems != ""):
        itemList=foundItems.split(progInfo["line.separator"])
        
        if (not isEmpty(skipString)):
          tempList = []
          for itemId in itemList:
            if (itemId.find(skipString) < 0):
              tempList.append(itemId)
          itemList = tempList
              
        
        retval = filterList(itemList, namePattern,clusterPattern,nodePattern,serverPattern)

   except:
      _app_trace("An error was encountered searching for the items (%s,%s,%s,%s,%s)" % (namePattern, itemType, clusterPattern, nodePattern, serverPattern), "exception")
      raise StandardError("An error was encountered searching for the item (%s,%s,%s,%s,%s)" % (namePattern, itemType,clusterPattern, nodePattern, serverPattern))

   _app_trace("matchItemsAtScope(%s)" %(retval), "exit")
   return retval

#-------------------------------------------------------------------------------
# findItemsAtScope
#    Can be used to find a list of objects that match the specified scope
#    and suffix string. The suffix string can specify a WCCM to return a list
#    or a type/name combination to return a list of one object that matches.
#
#    Similar in functionality to matchItemsAtScope, but doesn't support pattern
#    matching and can also be used to look for nested items by specifiy nested suffix.
#
# Parameters:
#    suffixString - in syntax for getid, e.g. "URLProvider:/" or "J2CResourceAdapter:WebSphere MQ Resource Adapter/"                                         
#    cluster (optional) - cluster to search under
#    node (optional) - node to search under
#    server (optional) - server to search under. Can also be used to specify template of dynamic cluster
#    dyncluster (optional) - dynamic cluster to search under
#    appName (optional) - application to search under
#    appDeployment (optional) - application deployment to search under
#
# Returns a list of configuration IDs, will be empty if no match found
#-------------------------------------------------------------------------------
def findItemsAtScope(suffixString,cluster=None, node=None, server=None, dyncluster=None, appName=None, appDeployment=None):
  _app_trace("findItemsAtScope(%s,%s,%s,%s,%s,%s,%s)" % (suffixString,cluster, node, server, dyncluster, appName, appDeployment),"entry")
  result = []
  try:
    if not suffixString.endswith("/"):
      suffixString = "%s/" % suffixString
    
    
    if (not isEmpty(dyncluster)):
      if (not isEmpty(server)):
        result = AdminConfig.getid("/DynamicCluster:%s/Server:%s/%s" % (dyncluster,server,suffixString)).splitlines()
      else:
        result = AdminConfig.getid("/DynamicCluster:%s/Server:%s/%s" % (dyncluster,dyncluster,suffixString)).splitlines()
    elif (not isEmpty(appName) or not isEmpty(appDeployment)):
      if (not isEmpty(appDeployment)):
        result = AdminConfig.getid("/Deployment:%s/%s" % (appDeployment,suffixString)).splitlines()
      else:
        result = []
    elif (not isEmpty(cluster)):
        result = AdminConfig.getid("/ServerCluster:%s/%s"% (cluster,suffixString)).splitlines()
    elif (not isEmpty(node) and not isEmpty(server)):
        result = AdminConfig.getid("/Node:%s/Server:%s/%s" % (node,server,suffixString)).splitlines()
    elif (not isEmpty(node)):
        result = AdminConfig.getid("/Node:%s/%s" % (node,suffixString)).splitlines()
    else:
        # Cell scope
        result = AdminConfig.getid("/Cell:%s/%s" % (getCellName(),suffixString)).splitlines()
            
    if (len(result) == 1 and isEmpty(result[0])):
      result = []
  except:
    _app_exception("Unexpected problem in findItemsAtScope")
    
  _app_trace("findItemsAtScope(retval=%s)" % result,"exit")
  return result

	
##########################################################################
# @JJM
def getOptionalProperty(props, key, defaultValue = ""):
	result = defaultValue
	try:
		result = props[key]
	except:
		result = defaultValue
	
	return result

#---------------------------------------------------------------------------
# toDictionary
#
# Will convert a java map to jython dictionary
#
# Parameters:
#   inputMap - a java.util.Map or a jython dictionary.
#
# Returns: a jython dictionary with values of Java map. If a dictionary was
#          passed in, the original dictionary will be returned.
#---------------------------------------------------------------------------
def toDictionary(inputMap):
  if (inputMap == None):
    return {}
    
  if (type(inputMap) != type({})):
      tempdict = {}
      for key in inputMap.keys():
        tempdict[key] = inputMap.get(key)
      inputMap = tempdict   
  
  return inputMap

##########################################################################
#
# FUNCTION:
#    getPropList: Returns Properties list based on prefix
#
# SCOPE:
#    Public
#
# SYNTAX:
#    subProps = getPropList (props, prefix), 
#
# PARAMETERS:
#
#    props:	Master props
#    prefix:	Prefix of properties to filter on
#    checkDynamicVariables : 1 - enable dynamic variable support, 0 - disable
#
# USAGE NOTES:
#    Returns properties sub list from master list
#
# RETURNS:
#	Properties
#
# THROWS:
#    N/A
##########################################################################
def getPropList(props, prefix, checkDynamicVariables = 0):

	traceStr = "getPropList(props, %s)" % (prefix)
 	_app_trace(traceStr, "entry")	
 	
	result=java.util.Properties()
	prefix = prefix + ".prop."
	for key in props.keys():
		if (key.startswith(prefix)):
			newKey = key[len(prefix):]
			newValue = props[key]
			if (checkDynamicVariables):
					newValue = substituteDynamicValues(newKey, newValue)
			result.put(newKey,newValue)
			
	traceStr = "getPropList(%d properties found)" % (result.size())
 	_app_trace(traceStr, "exit")	
	return result

#############################################################################
# Returns true if at least one property with the prefix is in the map
#############################################################################
def checkForPrefix(props, prefix):

	traceStr = "checkForPrefix(props, %s)" % (prefix)
 	_app_trace(traceStr, "entry")	
 	
	result=0
	for key in props.keys():
		if (key.startswith(prefix)):
			result = 1
			break
			
	traceStr = "checkForPrefix(result = %d)" % (result)
 	_app_trace(traceStr, "exit")	
	return result
	
	
def getPropName(props, prefix):
	prefix = prefix + "."
	for key in props.keys():
		if (key.startswith(prefix)):
			return key[len(prefix):]
	return None

##########################################################################
# getPropListWithMatchingName
#
# Some properties are organized as lists of sublists with the format
# prefix.ordinal.prop.key
# This function will find the proper subpool to return given a prefix
# and the value of the "name" key
##########################################################################
def getPropListWithMatchingName(props, prefix, nameval, checkDynamicVariables = 0):
	traceStr = "getPropListWithMatchingName(props, %s, %s)" % (prefix,nameval)
 	_app_trace(traceStr, "entry")
 	
 	result = None
 	idx=0
 	doneloop=0
 	while (not doneloop):
 			idx = idx + 1
 			val=props.get("%s.%d.prop.name" % (prefix, idx))
 			if (val == None):
 					doneloop = 1
 					break
 			
 			if (val == nameval):
 					result = getPropList(props,"%s.%d" % (prefix, idx), checkDynamicVariables)
 	
 	if (result == None):
 			result = java.util.Properties()
 	traceStr = "getPropListWithMatchingName(%d properties found)" % (result.size())
 	_app_trace(traceStr,"exit")
 	
 	return result
 					
 			
#-------------------------------------------------------------------------------
# getDictionaryList
#   Determines prefix.count value and then builds a list of dictionaries
#   for each set of properties for prefix.1 ... prefix.count
# Parameters
#   inputDictionary
#   prefix
#
# Returns:
#   list of dictionaries with the base properties of each list element
#-------------------------------------------------------------------------------
def getDictionaryList(inputDictionary,prefix,includeCustomProperties=0):
  _app_entry("getDictionaryList(inputDictionary,%s)" , prefix)
  retval = []
  try:
    if (inputDictionary != None):
      itemCount = int(inputDictionary.get("%s.count" % prefix, 0))
      if (itemCount > 0):
        for idx in range(1,itemCount+1):
          itemDictionary = toDictionary(getPropList(inputDictionary,"%s.%d" % (prefix,idx)))
          retval.append(itemDictionary)
          
          # See if there are custom properties with this configuration item
          if (includeCustomProperties):
            customProps = toDictionary(getPropList(inputDictionary,"%s.%d.properties" % (prefix,idx)))
            if (len(customProps) > 0):
              itemDictionary["properties"] = customProps
          
  except:
    _app_exception("Unexpected problem in getDictionaryList()")
  
  _app_exit("getDictionaryList(retval=%d items in list)" % len(retval))
  return retval

#--------------------------------------------------------------------------------
# Compares two lists of dictionaries to determine if one list is a subset of the
# other.  
#
# inputList - list that may be a subset
# existingList - master list to be compared against
# identifierKey - Property in the dictionaries that is unique identifier
# secondKey - optional secondary identifer key
#
# Returns 1 if input list is a subset of existing, 0 otherwise
#--------------------------------------------------------------------------------
def isSubSetDictionaryLists(inputList,existingList,identifierKey,secondKey=None):
  retval = 1
  
  existingMap = {}
  for d in existingList:
    #print "\nExisting: %s" % d
    if (isEmpty(secondKey)):
      existingMap[d.get(identifierKey)] = d
    else:
      existingMap[(d.get(identifierKey),d.get(secondKey))] = d
  
  #print "Existing Map = %s" % existingMap
  
  for d in inputList:
    if d not in existingList:
      ed = None
      #print "Checking %s" % d
      if (isEmpty(secondKey) and existingMap.has_key(d[identifierKey]) ):
        ed = existingMap[d[identifierKey]]
      elif (not isEmpty(secondKey) and existingMap.has_key((d.get(identifierKey),d.get(secondKey)))):
        ed = existingMap[(d.get(identifierKey),d.get(secondKey))]
    
      if (ed != None):
        #print "Checking against %s" % ed
        for tkey in d.keys():
          if ed.has_key(tkey) and ed[tkey] == d[tkey]:
            continue
          else:
            #print "Mismatch %s\n%s\%s" % (tkey, ed.get(tkey), d.get(tkey))
            retval = 0
            break
      else:
        #print "Nothing to check against"
        retval = 0
        break
        
    if (retval == 0):
      break
      
  return retval 
   


#--------------------------------------------------------------------------------------------------------
# Combine two lists of dictionaries, where each dictionary has an identifier key and an optional second key.
# The values in the inputList will be used over the values in the existing lists.  If the mergeMissingAttributes
# option is 1, then any keys that existing in the existing dictionary but not in the input dictionary will be
# merged into the results.
#
#--------------------------------------------------------------------------------------------------------
def combineDictionaryLists(inputList,existingList,identifierKey,secondKey=None,mergeMissingAttributes=1):
  retval = []
  
  existingMap = {}
  for d in existingList:
    if (isEmpty(secondKey)):
      existingMap[d.get(identifierKey)] = d
    else:
      existingMap[(d.get(identifierKey),d.get(secondKey))] = d
  
  for d in inputList:
    if d not in existingList:
      retval.append(d)
      if (isEmpty(secondKey) and existingMap.has_key(d[identifierKey]) ):
        if (mergeMissingAttributes):
          ed = existingMap[d[identifierKey]]
          doDictionaryMerge(d,ed)

        del existingMap[d[identifierKey]]
      elif (not isEmpty(secondKey) and existingMap.has_key((d.get(identifierKey),d.get(secondKey)))):
        if (mergeMissingAttributes):
          ed = existingMap[(d.get(identifierKey),d.get(secondKey))]
          doDictionaryMerge(d,ed)
          
              
        del existingMap[(d.get(identifierKey),d.get(secondKey))]
   
  for key in existingMap.keys():
    retval.append(existingMap[key])
  
  return retval 

#---------------------------------------------
# Special merge logic function for combineDictionaryLists
#--------------------------------------------
def doDictionaryMerge(d,ed):
    for key in ed.keys():
      if not d.has_key(key):
        d[key] = ed[key]

    # Special handling for nested properties dictionary
    pd = d.get("properties")
    epd = ed.get("properties")

    if (pd != None and epd !=None and pd != epd):
      for key in epd.keys():
        if not pd.has_key(key):
          pd[key] = epd[key]
              



#-------------------------------------------------------------------------------
# buildNameToPrefixMap
#   Loop through a list of configuration items in the dictionary and build a
#   map {item-name : prefix-of-properties}
#
# Parameters
#    inDictionary - inputDictionary
#    prefixRoot - prefix to use when looking at property keys
#    identifierAttribute - prefix suffix to use to pull identifier value
#-------------------------------------------------------------------------------
def buildNameToPrefixMap(inDictionary,prefixRoot,identifierAttribute="prop.name"):
  _app_entry("buildNameToPrefixMap(inDictionary,%s,%s)" , prefixRoot,identifierAttribute)
  retval = {}
  try:
    if (inDictionary != None):
      itemCount = int(inDictionary.get("%s.count" % prefixRoot,0))

      if (itemCount > 0):
        for idx in range(1,itemCount+1):
          identifierValue = inDictionary.get("%s.%d.%s" % (prefixRoot,idx,identifierAttribute))
          if (not isEmpty(identifierValue)):
            retval[identifierValue] = "%s.%d" % (prefixRoot,idx)
  except:
    _app_exception("Unexpected problem in buildPrefixMap()")
  
  _app_exit("buildNameToPrefixMap(retval=%s)" % retval)
  return retval
      

##########################################################################
# @JJM
# Produce a new property set with all of the properties that start with the
# specified suffix.  The new property set will rename the keys to start with 
# the specified new prefix (if not Null)
##########################################################################
def getComparableProperties(props,prefix,newprefix):
  traceStr = "getComparableProperties(props, %s, %s)" % (prefix,newprefix)
  _app_trace(traceStr, "entry") 
  
  result=java.util.Properties()
  for key in props.keys():
    if (key.startswith(prefix)):
      if (newprefix != None):
        newKey = "%s%s" % (newprefix, key[len(prefix):])
      else:
        newKey = key
      result.put(newKey,props[key])
      #print "%s %s" %(newKey,props[key])
      
  traceStr = "getComparableProperties(%d properties found)" % (result.size())
  _app_trace(traceStr, "exit")  
  return result

#####################################################################################
# getPropListDifferences
# Returns property list from input property list based on prefix.  After the initial
# list is  built, those properties are compared against another property set list pulled
# from the existing property settings.  The difference is returned to the caller.
#
# PARAMETERS:
#		inputProps - the input properties (usually config info master set)
#		inputPrefix - the prefix to filter on when reading the input properties
#   existingProps - the property set representing current configuration
#   existingPrefix - the prefix to filter on when processing existing props
#####################################################################################
def getPropListDifferences(inputProps, inputPrefix, existingProps, existingPrefix, prefixKeepRules=None):

  traceStr = "getPropListDifferences(inputProps, %s, existingProps, %s, %s)" % (inputPrefix,existingPrefix,prefixKeepRules)
  _app_trace(traceStr, "entry") 
  
  if (existingProps == None):
    existingProps = {}
    
  subProps = getPropList(inputProps,inputPrefix, 1)
  if (subProps.size() > 0):
    if (existingProps != None and existingPrefix != None):
        existingSubProps = getPropList(existingProps, existingPrefix)
        if (existingSubProps.size() > 0):
            # We'll update only changed properties
            
            if (prefixKeepRules == None):
                prefixKeepRules = inputPrefix+".keepRules";
            keepRulesProps = getPropList(inputProps, prefixKeepRules,1)
            if (keepRulesProps.size() == 0):
                keepRulesProps = None
            subProps = getModifiedProperties(subProps, existingSubProps,keepRulesProps)
            
  traceStr = "getPropListDifferences(inputProps, %s, existingProps, %s, %s) result = %d" % (inputPrefix,existingPrefix,prefixKeepRules,subProps.size())
  _app_trace(traceStr, "exit")  
  return subProps
  
#enddef getPropListDifferences
	


##########################################################################
# @JJM
#
# FUNCTION:
#	getModifiedProperties - compare two property sets, return items from first
#                         that are different/new from the second
#
# SYNTAX:
#	getModifiedProperties(newProps, existingProps)
#
# PARAMETERS:
#
# newProps 				- The property set that contains possibly new settngs
#	existingProps 	- The property set that contains existing settings
# keepRulesProps 	- The property set that contains the set of "keep rules" for this
#                 	setting from the property file. This is optional.
#
# USAGE NOTES:
#	
# RETURNS:
#    	New Property Set containing key/value pairs from newProps that are
#     either new keys or have different values in existingProps
#     If a keep rule is defined and the current value matches the rule, then
#     the new property value will not be returned.
#	
def getModifiedProperties(newProps, existingProps, keepRulesProps = None):

  # TODO - Need finer grain trace support or else get rid of property parms here
  traceStr = "getModifiedProperties(newProps,existingProps,keepRulesProps)"
  _app_trace(traceStr, "entry") 
  
  if (existingProps == None):
    existingProps = {}
  result=java.util.Properties()
  
  # Create a new property set with key/value pairs that are different in 
  # the new set
  for key in newProps.keys():
      newvalue = newProps[key]
      oldvalue = existingProps.get(key)
      
      if (keepRulesProps != None):
          rule = keepRulesProps.get(key)
          if (not isEmpty(rule)):
            if (evaluateKeepRule(keepRulesProps[key], oldvalue)):
                continue
      
      if isEmpty(newvalue) and oldvalue == "None":
          #Special handling for case when "None" was written to property file
          continue
      elif newvalue == "None" and isEmpty(oldvalue):
          continue
      elif isEmpty(newvalue) and isEmpty(oldvalue):
          continue
      elif isEmpty(newvalue) and not isEmpty(oldvalue) :
          result.put(key,"")
          _app_trace("Modified property %s" % key)
      elif not isEmpty(newvalue) and isEmpty(oldvalue) :
          result.put(key,newvalue)
      elif (newvalue.rstrip() != oldvalue.rstrip()) :
          _app_trace("Modified property %s" % key)
          _app_trace("Old value %s" % oldvalue)
          _app_trace("New value %s" % newvalue)
          result.put(key,newvalue)
  
  _app_trace("getModifiedProperties(%s)" % result, "exit")
  
  return result

#----------------------------------------------------------------------------------------------------------------------------
# Keep rules are special properties used in comparing input property sets against live settings.  If the keep rule evaluates
# to true, the current property will be kept in favor of the input value.  
#
# This is currently a prototype feature of the framework with a limited implementation.
#
# Supported rules:
#			RANGE beginningInt endInt   (beginningInt <= value <= endInt)
# @JJM-
#
def evaluateKeepRule(keepRule, oldvalue):

		_app_trace("evaluateKeepRule(%s %s)" % (keepRule, oldvalue), "entry")
		
		result = 0
		
		if (isEmpty(keepRule) or isEmpty(oldvalue)):
				return result
		
		try:
			if (keepRule.startswith("RANGE ")):
					#RANGE beginningInt endInt
					parms = keepRule.split(" ")
					if (len(parms) == 3):
							beginningInt = int(parms[1])
							endInt = int(parms[2])
							valInt = int(oldvalue)
							
							if (valInt >= beginningInt and valInt <= endInt):
									result = 1
		except:
			# Bad rule
			_app_trace("An error was encountered checking keep rule %s %s" % (keepRule,oldvalue), "exception")
			result = 0
							
		_app_trace("evaluateKeepRule(%s %s) returns %d" % (keepRule, oldvalue,result), "exit")
		
		return result

#------------------------------------------------------------------------------------------
# propsToAttrList
#------------------------------------------------------------------------------------------
def propsToAttrList(inputProps,skipList = None):
  retval = []
  if (inputProps != None):
    for key in inputProps.keys():
      if (skipList != None and key in skipList):
        continue
        
      val = inputProps[key]
      
      if (type(val) == type({})):
        if (key == "properties"):
          tempList = []
          for tempKey in val.keys():
            plist = None
            tempVal = val[tempKey]
            if (tempVal.find("|") >= 0):
              valDesc = tempVal.split("|")
              if (len(valDesc) == 1):
                plist = [ ["name",tempKey],["value",valDesc[0]]]
              else:
                plist = [ ["name",tempKey],["value",valDesc[0]], ["description",valDesc[1]]]
            else:
              plist = [ ["name",tempKey],["value",tempVal]]
            tempList.append(plist)
          retval.append([key,tempList])  
        else:  
          templist = propsToAttrList(val)
          retval.append([key,templist])
        continue
      
      if (type(val) == type([])):
        tempList = []
        for tval in val:
          tempList.append(propsToAttrList(tval))
        retval.append([key,tempList])
        continue
        
      
      # Special cases
      if (val == "None"):
        val = ""
      
      lkey = key.lower()
      if (lkey.find("password") >= 0 and val.find("*****") >= 0):
        # Skip stubbed out password to avoid rewrite
        continue
      
      retval.append([key,val])
  
  return retval

# Cached settings
attributeCache = {}
typeList = []
configMethods = None

#---------------------------------------------------------------------------------
# getTypeList()
#
# Loads the list of WCCM types. The list is cached so only one AdminConfig call is 
# made inthe wsadmin session
#---------------------------------------------------------------------------------
def getTypeList():
  global typeList
  if (len(typeList) == 0):
    typeList.extend(AdminConfig.types().splitlines())
  
  return typeList

#---------------------------------------------------------------------------------
# Confirm that this is a valid type
#---------------------------------------------------------------------------------
def isValidType(wccmType):
  retval = 0
  tl = getTypeList()
  if wccmType in tl:
    retval = 1
  
  return retval

#-------------------------------------------------------
# checkGetObjectType
#
# Utility method that confirms that AdminConfig.getObjectType()
# is available in this environment
#-------------------------------------------------------
def checkGetObjectType():
  
  global configMethods
  retval = 0
  
  if (configMethods == None):
    configMethods = AdminConfig.help()
  
  if (configMethods.find("getObjectType") >= 0):
    retval = 1
  
  return retval


#-------------------------------------------------------------------------------
# callGetObjectType
#
# Utility method that wraps AdminConfig.getObjectType() for those backlevel
# releases that do not have that utility method
#-------------------------------------------------------------------------------
def callGetObjectType(configId):
  configType = None
  
  if (checkGetObjectType()):
    configType = AdminConfig.getObjectType(configId)
  else:
    #Parse it out if possible
    splits = configId.split("#")
    
    lastToken = splits[-1]
    configType = lastToken.split("_")[0]
    
    if (configType not in getTypeList()):
      # Not a valid type
      configType = None    
  
  return configType



#---------------------------------------------------------------------------------
# getAttributeInfo
# 
# Parameters:
#
#   configurationType - The name of a WCCM type (e.g. "DataSource")
#
# Returns a list that represents the lines of AdminConfig.attributes(configurationType)
#---------------------------------------------------------------------------------
def getAttributeInfo(configurationType):
  global attributeCache
  
  attributeInfo = attributeCache.get(configurationType)
  if (attributeInfo == None):
    attributeInfo = AdminConfig.attributes(configurationType).splitlines()
    attributeCache[configurationType] = attributeInfo
  
  return attributeInfo

def getAttributeNames(configurationType):
  attributeInfo = getAttributeInfo(configurationType)
  retval = []
  for attribute in attributeInfo:
    retval.append(attribute.split(" ")[0])
  return retval

#---------------------------------------------------------------------------------
# getSimpleSubComponentAttributes
#
# Parameters:
#   configurationType - The name of a WCCM type (e.g. "DataSource")
#
# Returns: A list of [attributeName,attributeType] pairs for each attribute
# of the specified configuration type that is also a WCCM type.  Lists and references
# are ignored.
#    Example result:  [ ["connectionPool","ConnectionPool"], ["preTestConfig","ConnectionTest"],["mapping","MappingModule"] ]
#---------------------------------------------------------------------------------
def getSimpleSubComponentAttributes(configurationType,allowSubClasses = 0):
  retval = []
  baseTypes = ["String","int","boolean"]
  attributeInfo = getAttributeInfo(configurationType)
  for attributeLine in attributeInfo:
    firstSpace = attributeLine.find(" ")
    if (firstSpace <= 0):
      continue
    attributeName = attributeLine[:firstSpace]
    attributeType = attributeLine[firstSpace+1:].strip()
    
    if (attributeType.endswith("*")):
      # List type - skip
      continue
    
    if (attributeType.find("(") >= 0):
      if (not allowSubClasses or attributeType.find("ENUM(") >= 0):
        # ENUM or various subtypes - skip
        continue
      
    if (attributeType in baseTypes):
      # skip
      continue
      
    if (attributeType == "J2EEResourcePropertySet"):
      continue
    
    if (attributeType.find("@") >= 0):
      # reference - skip
      continue
    
    # Finally, if its in the master list, good to go
    if (attributeType in getTypeList()):
      retval.append([attributeName,attributeType])
    else:
      if (allowSubClasses and attributeType.find("(") >= 0):
        # Need to handle this
        retval.append([attributeName,attributeType])      
      
  
  return retval
  
#-------------------------------------------------------------------------------
# getPropertyAttributes
#-------------------------------------------------------------------------------
def getPropertyAttributes(configurationType):
  retval = []
  attributeInfo = getAttributeInfo(configurationType)
  for attributeLine in attributeInfo:
    firstSpace = attributeLine.find(" ")
    if (firstSpace <= 0):
      continue
    attributeName = attributeLine[:firstSpace]
    attributeType = attributeLine[firstSpace+1:].strip()
    
    if (attributeType == "J2EEResourcePropertySet" or
        (attributeType.startswith("Property(") and attributeType.endswith("*")) or
        (attributeType == "Property*")):
          retval.append( [attributeName,attributeType])
  
  retval.sort()
  
  return retval
    


#---------------------------------------------------------------------------------
# getListAttributes
#
# Parameters:
#   configurationType - The name of a WCCM type (e.g. "DataSource")

# Returns a list of attribute names that are list-type as determined
# by their AdminConfig.attributes() definition
#---------------------------------------------------------------------------------
def getListAttributes(configurationType):
  retval = []
  attributeInfo = getAttributeInfo(configurationType)
  for attributeLine in attributeInfo:
    firstSpace = attributeLine.find(" ")
    if (firstSpace <= 0):
      continue
    attributeName = attributeLine[:firstSpace]
    attributeType = attributeLine[firstSpace+1:].strip()
    
    if (attributeType.endswith("*")):
      retval.append(attributeName)
  
  return retval
      

#-------------------------------------------------------------------
# modifyObjectProperties
#
# This function will update a configuration item using the dictionary.
# It does some analysis of the properties and configuration type to 
# avoid some common pitfalls including:
#   will clear out list attributes when setting new values
#
# Raises StandardError if update failed
# 
# Parameters: 
#   configurationId - The configuration ID of the object to update
#   props - dictionary with base properties to apply
#   configurationType - optional - the type being updated
#-------------------------------------------------------------------
def modifyObjectProperties(configurationId,props,configurationType=None):    
  try:
    if (props == None):
      props = {}
      
    if (isEmpty(configurationType)):
      try:
        configurationType=AdminConfig.getObjectType()
      except:
        pass
    
    if (not isEmpty(configurationType)):
      listAttrs = getListAttributes(configurationType)
      clearAttrs = []
      for key in props.keys():
        if (key in listAttrs):
          clearAttrs.append([key,""])
        
      if (len(clearAttrs) > 0):
        if (modifyObject(configurationId,clearAttrs)):
          raise StandardError("Unable to clear list attributes %s in %s" % (clearAttrs,configurationId))
    
    attrList = propsToAttrList(props)
    if (len(attrList) > 0):
      if (modifyObject(configurationId,attrList)):
        
        raise StandardError("Unabled to update %s" % configurationId)
        
  except:
    _app_trace("modifyObjectProperties: Failed to update properties: %s,%s,%s" % (configurationId,props,configurationType))
    _app_exception("Failed to modify object properties: %s" % configurationType)
      
    
#---------------------------------------------------------------------------------
# processStandardizedProperties
#
# This function can be used to simplify the processing of configuration items that
# have either a single set of simple properties or contains nested items that are
# made of simple properties. 
#
# This method will handle lists of strings properly, but not lists of configuration types
#
# Parameters:
#   inputProps - contains set of properties that are meant to be applied to the system
#   inputPrefix - property key prefix that will be used to pull properties from inputProps. This
#                 is the root prefix for the component (e.g. does not include ".prop" at end.
#   existingProps - constains set of properties that represent the current settings of the
#                   configuration item in question. Can be None or empty.
#   existingPrefix - property key prefix that will be used to pull properties from existingProps
#   targetId       - Optional, will be used if supplied, otherwise will be determined from parent 
#                    object 
#   parentId       - Id of parent configuration item if the target configuration item needs to be
#                    found or created.
#   parentAttribute - name of attribute in parent configuration type. If None or empty, then
#                     AdminConfig.list() will be used to find item.
#   updateConfigurationType - the WCCM configuration type to be processed.
#   processSubItems - If set to 1 (true), then simple configuration items that are child attributes
#                     of WCCM will be processed.  When child items are processed, it is assuming
#                     that their properties can be found off the root prefix where the key for the
#                     subitem is <inputPrefix>.attributeName.  If set, subItems will be recursively
#                     processed.
#   subItemSkipList - optional list of sub items to be ignored. This is a list of attribute names
#   processCustomProperties - if true, custom properties and J2EEResourcePropertySet fields will be processed.
#                             For Properties, the input configuration keys will use the following syntax:
#                                 <inputPrefix>.attributeName.prop.key1=val1 where attribute name is usually
#                                    "properties"
#                             For J2EEResource set properties, the properties are either in:
#                                 <inputPrefix>.attributeName.resourceProperties.prop.key1=val1 
#                                        where attribute name is usually "propertySet"
#                                 or the short form:
#                                 <inputPrefix>.resourceProperties.prop.key1=val1 
#                      
#                             
#---------------------------------------------------------------------------------
def processStandardizedProperties(inputProps, inputPrefix, existingProps, existingPrefix,
                                  targetId=None,
                                  parentId=None, parentAttribute=None, updateConfigurationType=None,
                                  processSubItems=0,subItemSkipList=None,processCustomProperties=0):
  _app_trace("processStandardizedProperties(inputProps,%s,existingProps,%s,%s,%s,%s)" % (inputPrefix,existingPrefix,parentId,parentAttribute,updateConfigurationType),"entry")
  retval = None
  try:                           
    retval = {}
    
    
    if (not isEmpty(targetId) and isEmpty(updateConfigurationType)):
      updateConfigurationType = AdminConfig.getObjectType(targetId)
    
    
    didCreate = 0
    subProps = getPropListDifferences(inputProps,inputPrefix,existingProps,existingPrefix)
    if (len(subProps) > 0):
      attrList = propsToAttrList(subProps)
      
      if (isEmpty(targetId)):
        if (not isEmpty(parentAttribute)):
          targetId = AdminConfig.showAttribute(parentId,parentAttribute)
          if (isEmpty(targetId)):
            _app_trace("About to call AdminConfig.create(%s,%s,attrList,%s)" % (updateConfigurationType,parentId, parentAttribute))
            targetId = AdminConfig.create(updateConfigurationType,parentId,attrList,parentAttribute)
            didCreate = 1
        else:
          targetId = AdminConfig.list(updateConfigurationType,parentId)
          
          if (isEmpty(targetId)):
            _app_trace("About to call AdminConfig.create(%s,%s,attrList)" % (updateConfigurationType,parentId))
            targetId = AdminConfig.create(updateConfigurationType,parentId,attrList)
            didCreate = 1
        
        if (isEmpty(targetId)):
          _app_trace("Unable to locate/create %s under %s, attribute= %s" % (updateConfigurationType,parentId,parentAttribute))
          raise StandardError("Unable to locate/create %s under %s, attribute= %s" % (updateConfigurationType,parentId,parentAttribute))
        
      if (not didCreate):
        # Need to do update
        
        # First, special handling for list attributes
        # which must be cleared before updated
        listAttrs = getListAttributes(updateConfigurationType)
        clearAttrs = []
        for key in subProps.keys():
          if (key in listAttrs):
            clearAttrs.append([key,""])
        
        if (len(clearAttrs) > 0):
          if (modifyObject(targetId,clearAttrs)):
            raise StandardError("Unable to clear list attributes %s in %s" % (clearAttrs,targetId))
        
        # Now free to do update 
        if (modifyObject(targetId,attrList)):
          raise StandardError("Unable to update %s %s with values %s" % (updateConfigurationType,targetId,attrList))
        
      # Return the keys/values of items updated
      for key in subProps.keys():
        retval["%s.prop.%s" % (inputPrefix,key)] = subProps.get(key)
        
    if (processCustomProperties):
      # determine which fields are custom properties or resource properties
      pattrs = getPropertyAttributes(updateConfigurationType)
      for pa in pattrs:
        paName = pa[0]
        paType = pa[1]
        
        if (paType == "J2EEResourcePropertySet"):
          if (checkForPrefix(inputProps,"%s.resourceProperties" % inputPrefix)):
            subProps = getPropListDifferences(inputProps,"%s.resourceProperties" % (inputPrefix),existingProps,"%s.resourceProperties" % (existingPrefix))
          else:
            subProps = getPropListDifferences(inputProps,"%s.%s.resourceProperties" % (inputPrefix,paName),existingProps,"%s.%s.resourceProperties" % (existingPrefix,paName))
          
        else:
          subProps = getPropListDifferences(inputProps,"%s.%s" % (inputPrefix,paName),existingProps,"%s.%s" % (existingPrefix,paName))
        
        if (len(subProps) > 0):
          if (isEmpty(targetId)):
            # We never did find it to update it
            if (not isEmpty(parentAttribute)):
              targetId = AdminConfig.showAttribute(parentId,parentAttribute)
              if (isEmpty(targetId)):
                _app_trace("About to call AdminConfig.create(%s,%s,[],%s)" % (updateConfigurationType,parentId, parentAttribute))                
                targetId = AdminConfig.create(updateConfigurationType,parentId,[],parentAttribute)
            else:
              targetId = AdminConfig.list(updateConfigurationType,parentId)
              if (isEmpty(targetId)):
                _app_trace("About to call AdminConfig.create(%s,%s,[])" % (updateConfigurationType,parentId))
                targetId = AdminConfig.create(updateConfigurationType,parentId,[])
            
          if (paType == "J2EEResourcePropertySet"):
            updateJ2EEResourcePropertySet(targetId, subProps, attributeName=paName)
          else:
            errmsg = updateCustomProperties(targetId, paName, "Property", subProps)
            if (not isEmpty(errmsg)):
              raise StandardError("Unable to update custom properties on %s, attribute name = %s, error: %s" % (targetId, paName, errmsg))
          
          # Return the keys/values of items updated
          for key in subProps.keys():
            retval["%s.%s.prop.%s" % (inputPrefix,paName,key)] = subProps.get(key)
            
        
          
    if (processSubItems):
      subItemList = getSimpleSubComponentAttributes(updateConfigurationType)
      for subItem in subItemList:
        subAttribute = subItem[0]
        subType = subItem[1]
        
        if (subItemSkipList != None and subAttribute in subItemSkipList):
          continue
        
        if (checkForPrefix(inputProps,"%s.%s" % (inputPrefix,subAttribute))):
          if (isEmpty(targetId)):
            # We never did find it to update it
            if (not isEmpty(parentAttribute)):
              targetId = AdminConfig.showAttribute(parentId,parentAttribute)
              if (isEmpty(targetId)):
                _app_trace("About to call AdminConfig.create(%s,%s,[],%s)" % (updateConfigurationType,parentId, parentAttribute))                
                targetId = AdminConfig.create(updateConfigurationType,parentId,[],parentAttribute)
            else:
              targetId = AdminConfig.list(updateConfigurationType,parentId)
              if (isEmpty(targetId)):
                _app_trace("About to call AdminConfig.create(%s,%s,[])" % (updateConfigurationType,parentId))
                targetId = AdminConfig.create(updateConfigurationType,parentId,[])
            
          
          tempResults = processStandardizedProperties(inputProps, "%s.%s" % (inputPrefix,subAttribute), existingProps, "%s.%s" % (existingPrefix,subAttribute),
                                    None,
                                    targetId, subAttribute, subType,processSubItems=1,subItemSkipList=subItemSkipList)
        
          # Merge temp results
          if (len(tempResults) > 0):
            for key in tempResults.keys():
              retval[key] = tempResults[key]
    
  except:
    _app_exception("Unexpected error in processStandardizedProperties")
  
  _app_trace("processStandardizedProperties(retval=%d items)" % len(retval),"exit")
  
  return retval

#------------------------------------------------------------------------------
# Utility method that will create multiple children of the same type from a list
# of dictionaries
#----------------------------------------------------------------------------- 
def createMultipleChildren(childList,childType,parentId,attributeName = None):
  try:
    if (childList != None and len(childList) > 0):
      for childDict in childList:
        attrs = propsToAttrList(childDict)
        if (isEmpty(attributeName)):
          _app_trace('About to call AdminConfig.create(%s,%s,%s)' % (childType,parentId,attrs))
          childId = AdminConfig.create(childType,parentId,attrs)
        else:
          _app_trace('About to call AdminConfig.create(%s,%s,%s,%s)' % (childType,parentId,attrs,attributeName))
          moduleId = AdminConfig.create(childType,parentId,attrs,attributeName)
  except:
    _app_exception("Unexpected error in createMultipleChildren")
    
    
#-------------------------------------------------------------------------------
# doUpdateCreate
#
# Parameters
#   wccmType - type of object to create
#   parentId - Parent configuration item
#   newAttributes - list or dictionary with attributes
#   parentAttributeName - attribute name in parent of item being created (can be empty)
#-------------------------------------------------------------------------------
def doUpdateCreate(wccmType,parentId,newAttributes,parentAttributeName=None,forceCreate=0,updateId=None,customProperties=None,customPropertiesType="Property",customPropertiesAttribute="properties"):
  _app_entry("doUpdateCreate(%s,%s,%s,%s,%d,%s,%s,%s,%s)",wccmType,parentId,newAttributes,parentAttributeName,forceCreate,updateId,customProperties,customPropertiesType,customPropertiesAttribute)
  retval = None
  try:
    if (newAttributes != None and len(newAttributes) > 0):
    
      # Special handling for properties
      if (wccmType == "Property" and type(newAttributes) != type([])):
        if (parentAttributeName == None):
          parentAttributeName = "properties"
          
        errmsg = updateCustomProperties(parentId, parentAttributeName, wccmType, inputPropertySet=newAttributes)
        if (not isEmpty(errmsg)):
          raise StandardError("Unable to update custom properties in %s: %s" % (parentId,errmsg))
      else:
        
        
        if (type(newAttributes) != type([])):
          newAttributes = propsToAttrList(newAttributes)
        
        if (not forceCreate):
          if (not isEmpty(updateId)):
            retval = updateId  
          elif (not isEmpty(parentAttributeName)):      
            retval = AdminConfig.showAttribute(parentId, parentAttributeName)
          else:
            retval = AdminConfig.list(wccmType,parentId)
          
        if (isEmpty(retval)):
          if (not isEmpty(parentAttributeName)):
            _app_trace('About to call AdminConfig.create(%s,%s,%s,%s)' % (wccmType,parentId,newAttributes,parentAttributeName))
            retval = AdminConfig.create(wccmType,parentId,newAttributes,parentAttributeName)
          else:
            _app_trace('About to call AdminConfig.create(%s,%s,%s)' % (wccmType,parentId,newAttributes))
            retval = AdminConfig.create(wccmType,parentId,newAttributes)
        elif (len(newAttributes) > 0):
            if (modifyObject(retval,newAttributes)):
              raise StandardError("Unable to update %s in %s" % (wccmType,parentId))
    else:
      # Always return the looked up value for callers expecting it
      if (not isEmpty(updateId)):
        retval = updateId
      elif (not isEmpty(parentAttributeName)):      
        retval = AdminConfig.showAttribute(parentId, parentAttributeName)
      else:
        retval = AdminConfig.list(wccmType,parentId)
    
    # Optional support for custom properties
    if (customProperties != None and len(customProperties) > 0):
      # Do custom properties as well
      errmsg = updateCustomProperties(retval, customPropertiesAttribute, customPropertiesType, inputPropertySet=customProperties)
      if (not isEmpty(errmsg)):
        raise StandardError("Unable to update custom properties in %s: %s" % (retval,errmsg))      
    
          
  except:
    _app_exception("Unexpected problem in doUpdateCreate()")
  
  _app_exit("doUpdateCreate(retval=%s)" % retval)
  return retval
  
  
    
#----------------------------------------------------------------------------------------------------------------------------
# storePropertiesInSet
#
# Use result of show() to parse items properties and store them in a property set
def storePropertiesInSet(prefix,objId,pset):
        if (objId == ""): return
        skipTags = ["managedObject", "server"]
        attrs = AdminConfig.show(objId).split(progInfo["line.separator"])
        for attr in attrs:
                key,val= toKeyValue(attr)
                
                if (key in skipTags): continue
                if (isEmpty(val)): continue

                if (val.startswith('"') and val.endswith('"')):
                        val = val[1:-1]

                if (isArray(val)):
                        arrayList = wsadminToList(val)
                        idCount = 0
                        for arr in arrayList:
                                moduleExt =""
                                idCount = idCount + 1
                                if (isId(arr) == 1):
                                        storePropertiesInSet("%s.%s.%s%d.prop" % (prefix, key, moduleExt, idCount),arr,pset)
                                else:
                                       	pset["%s.%s.%s%d.prop" % (prefix, key, moduleExt, idCount)] = arr
                        pset["%s.%s.count" % (prefix, key)] = idCount
                        continue

                if (isId(val) == 1):
                        storePropertiesInSet("%s.%s" % (prefix, key),val,pset)
                else:
                        pset["%s.%s" % (prefix, key)] = val

###############################################################################
# Iterate through a dictionary and dynamically determine the count properties
# for fields.
###############################################################################
def calculateCounts(props):

		#_app_message("Calculating counts")

		countProps = {}
		
		for key in props.keys():
				prefix = ""
				tokens = key.split(".")
				for token in tokens:
		
						if token.isdigit():
								countPropKey = "%s.count" % prefix
								
								currentCount = countProps.get(countPropKey)
								if (currentCount == None):
										countProps[countPropKey] = token
								else:
										tokenVal = int(token)
										currentVal = int(currentCount)
										
										if (tokenVal > currentVal):
												countProps[countPropKey] = token
												
						# Advance the prefix
						if (prefix == ""):
								prefix = token						
						else:
								prefix = "%s.%s" % (prefix,token)
						
						if prefix.endswith(".prop"):
								# We're done with this key
								break
				
		for countKey in countProps.keys():
				#print "Calculated: %s = %s" % (countKey, countProps.get(countKey))
				loadedCount = props.get(countKey)
				if (loadedCount == None):
						_app_message("Missing count property identified. Will insert calculated value:")
						_app_message("New Value: %s = %s" % (countKey,countProps.get(countKey)))
						props[countKey] = countProps.get(countKey)
				elif loadedCount != "0":
						if (countProps.get(countKey) != loadedCount):
								_app_message("Count property is different from calculated values. Will update:")
								_app_message("Original : %s = %s" % (countKey,loadedCount))
								_app_message("New Value: %s = %s" % (countKey,countProps.get(countKey)))
								props[countKey] = countProps.get(countKey)
						#else:
							#print "Loaded is same : %s = %s" % (countKey, loadedCount)
						
		#_app_message("Done calculating counts")
		

#--------------------------------------------------------------------------------------
# removedSkippedSections
#
# Do a prepass of the loaded properties to see if ther is any use of the x.y.z.includePropertySection
# property, which is a special control flag that if set to "no" or "false" can be used to dynamically remove 
# a subsection of properties before processing begins.
#
# The includePropertySection value can have one of the following formats, where boolean-value can be
# true,false,yes,no
#
#     my.section.includePropertySection = boolean-value
#     my.section.includePropertySection = boolean-value and boolean-value2 [and boolean-value3 ...]
#     my.section.includePropertySection = boolean-value or boolean-value2 [or boolean-value2 ...]
#
# The support for and/or clauses is simplistic: either all-and or all-or expressions are valid
#--------------------------------------------------------------------------------------
def removedSkippedSections(props):
    skipPrefixList = [] 
    
    # Build a list of skipped property prefixes
    propKey = "includePropertySection"
    for key in props.keys():
        if key.endswith(propKey):
            val = props.get(key)
            if (val == None):
              val = "true"
            else:
              val = substituteDynamicValues(key, val)
              
              
            val = val.lower()
            
            if (val.find(" and ") >= 0 ):
              # Any false/no means we'll skip this property section
              vals = val.split(" ")
              skipit = 0
              for val in vals:
                if (val == "false" or val == "no"):
                  skipit = 1
                  break
              if (skipit):
                skipPrefix = key[:-len(propKey)]
                skipPrefixList.append(skipPrefix)
                
            elif (val.find(" or ") >= 0):
              # Any true/yes means we'll keep this property section
              vals = val.split(" ")
              skipit = 1
              for val in vals:
                if (val == "true" or val == "yes"):
                  skipit = 0
                  break
              if (skipit):
                skipPrefix = key[:-len(propKey)]
                skipPrefixList.append(skipPrefix)
            elif (val.lower() == "no" or val.lower() == "false"):
                skipPrefix = key[:-len(propKey)]
                skipPrefixList.append(skipPrefix)
                
        #endif includePropertySection
    #endfor each key
    
    # Iterate through the list of skipped prefixes and remove them from the
    # input map/dictionary
    for skipPrefix in skipPrefixList:
        _app_message("Removing properties that start with %s" % skipPrefix)
        
        for key in props.keys():
            if key.startswith(skipPrefix):
                try:
                  del props[key]
                except:
                  props.remove(key)
        #endfor each key
        
    #endfor each skipped prefix
    
#enddef removedSkippedSections

#-------------------------------------------------------------------------
# stripMetaValues
# 
# Depending on the tooling that produces the input property file, some of
# the properties may include meta values that do not get processed by the
# wsadmin scripts.  This function strips these comments out.  It assumes
# that any content after @META needs to be removed.
def stripMetaValues(inputProps):
  updatedVals = {}
  for key in inputProps.keys():
    val = inputProps[key]
    metaIdx = val.find("@META")
    if (metaIdx >= 0):
      newval = val[0:metaIdx]
      updatedVals[key] = newval
      _app_message("Stripped meta comment [%s,%s,%s]"% (key,val,newval))
    #endif
  #endfor
  
  if (len(updatedVals) > 0):
    for key in updatedVals.keys():
      newval = updatedVals[key]
      inputProps[key] = newval
    #endfor
  #endif

#enddef stripMetaValues
#-------------------------------------------------------------------------
# filterProperties
#
# Utility method that will copy all keys with a certain prefix to a new
# dictionary
#
# Parameters:
#     inputDictionary - the original dictionary/Map to search through
#     prefix - the prefix string to check keys against
#
# Returns: new Jython dictionary that only contains keys that starts with
#          the prefix
#-------------------------------------------------------------------------
def filterProperties(inputDictionary,prefix):
  retval = {}
  
  for key in inputDictionary.keys():
    if key.startswith(prefix):
      retval[key] = inputDictionary[key]
  
  return retval

#enddef

#-------------------------------------------------------------------------
# transformPropertyKeys
# 
# This script will filter and rename the keys of a property set to 
# produce a new dictionary with modified keys.
#
# Parameters:
#   inputDicitonary - original dictionary or Java Map
#   originalPrefix - the string prefix we'll search for in property keys
#   newPrefix - the replacement prefix properties will be created with in result dictionary
#
# Returns - dictionary which is a subset of original with keys modified to replace
#           originalPrefix with newPrefix
#-------------------------------------------------------------------------
def transformPropertyKeys(inputDictionary,originalPrefix, newPrefix):
  prefixLen = len(originalPrefix)
  retval = {}
  
  for key in inputDictionary.keys():
    if key.startswith(originalPrefix):
      newkey = newPrefix+key[prefixLen:]
      retval[newkey] = inputDictionary[key]
  
  return retval

#enddef

#-------------------------------------------------------------------------
# mergeMissingProperties
#
# Merge properties from dictionary1 into dictionary2. If the property is
# already in dictionary2 it will not be overwritten.  
#-------------------------------------------------------------------------
def mergeMissingProperties(dictionary1, dictionary2):
  for key in dictionary1.keys():
    if (dictionary2.get(key) == None):
      dictionary2[key] = dictionary1[key]
      
#enddef

#-------------------------------------------------------------------------
# getSortedListFromProperty
#
# Utility method that will take a comma or space separated property and 
# turn it into a list
#
# Parameters:
#    inputDictionary - dictionary to pull from
#    propkey - key to proces
#-------------------------------------------------------------------------
def getSortedListFromProperty(inputDictionary,propkey):
    retval = []
    
    propval = inputDictionary.get(propkey ,"")
    
    if (isEmpty(propval)):
      retval = []
    elif (propval.find(",") > 0):
      retval = propval.split(",")
      
      # We'll have to strip blanks
      templist = []
      for val in retval:
        templist.append(val.strip())
      retval = templist
      
    else:
      retval = propval.split(" ")

    retval.sort()  
    
    return retval

##########################################################################
#
# FUNCTION:
#    initialise: Performs start-up initialisation.
#
# SYNTAX:
#    initialise ()
#
# PARAMETERS:
#    N/A
#
# USAGE NOTES:
#    Call this at the start of the program.  Place all initialisation
#    of global items here (essentially that means progInfo).
#
# RETURNS:
#    N/A
#
# IMPLEMENTATION:
#    1. Set up globals.
#
##########################################################################
def initialise():
  import sys
  import os
  from java.lang import System
  from java.net import InetAddress
  from java.util import Properties
  from java.io import FileInputStream
  
  
  try:
    global progInfo
    
    if progInfo is None:
      progInfo = {}
  except NameError:
      progInfo = {}

  if len(progInfo) == 0:
    try:
      progInfo["app.initialization.error"] = "false"
    
      # Get java system properties - cannot determine trace level until this time
      props = System.getProperties()
      names = props.propertyNames()

      for name in names:
        progInfo[name] = System.getProperty(name)
        
      # Some program properties can also be set by ENVIRONMENT 
      # variables
      if (not progInfo.has_key("app.trace.log.dir")):
        tempValue = outputDir = os.environ.get("WSADMIN_SCRIPT_LOG_DIR")
        if (tempValue != None):
          progInfo["app.trace.log.dir"]=tempValue
        
      # Set default value for app.autosave if necesary
      autosaveFlag = progInfo.get("app.autosave","")
      if (autosaveFlag == ""):
          progInfo["app.autosave"] = "false"
        
      # Check for trace file name, if not there, use default
      logFileName = progInfo.get("app.trace.log.file","")
      if (logFileName == ""):
          import time
          t0 = time.time()
          tm = time.localtime(t0)
          logFileDir = progInfo.get("app.trace.log.dir",".")
          logFileName = "%s/pdconfig.%s.log" % (logFileDir,(time.strftime("%Y%m%d_%H%M%S",tm)))
          progInfo["app.trace.log.file"] = logFileName

      # Read trace settings from app.properties
      progInfo["app.trace.log"] = int(progInfo.get("app.trace.log","1"))
      
      
      trace = progInfo.get("app.trace.level","1")
      tabs  = progInfo.get("app.trace.spaces","2")
      log   = progInfo["app.trace.log"]
      isEmptyTrace = progInfo.get("app.trace.isempty","0")
      
      
      
      if trace is not None:
        progInfo["app.trace.level"] = int(trace)
        progInfo["app.trace.spaces"] = int(tabs)
        progInfo["app.trace.current"] = 0
        progInfo["app.trace.isempty"] = int(isEmptyTrace)
      else:
        progInfo["app.trace.level"] = 0
        progInfo["app.trace.spaces"] = 0
        progInfo["app.trace.current"] = 0
        progInfo["app.trace.isempty"] = 0

      # If logging trace, open file
      if log == 1:
        trlogon()

      _app_trace("initialise()", "entry")

      # Get program arguments and count
      progInfo["argv"] = sys.argv
      progInfo["argc"] = len(sys.argv)

      # Get Dmgr Version
      dmgrId = AdminConfig.getid("/Server:dmgr/")
      if (dmgrId != ""):
        
        dmgrNode = getNodeNameForServer(dmgrId)
        dmgrVersion = AdminTask.getNodeBaseProductVersion("-nodeName %s" % dmgrNode)
        progInfo["dmgrVersion"] = dmgrVersion
      else:
        serverId = AdminConfig.getid("/Server:/").splitlines()[0]
        serverNode = getNodeNameForServer(serverId)
        dmgrVersion = AdminTask.getNodeBaseProductVersion("-nodeName %s" % serverNode)
        progInfo["dmgrVersion"] = dmgrVersion
        
        
      
      #ids = AdminControl.completeObjectName('WebSphere:type=Server,processType=DeploymentManager,*').split(',')
      #vProps = java.util.Properties()
      #for id in ids:
      #       vProps.put(id[:id.find("=")], id[id.find("=")+1:])
      #progInfo["dmgrVersion"] = vProps["version"]
      
      # Initialize the dynamic keys
      global dynamicIds
      dynamicIds = {}


      # Read the configuration file
      global configInfo
      configInfo = {}

      
      fileprop = None
      
      varLocation = System.getProperty("app.variable.location")
      
      # There are 3 supported options for loading the property file which are attempted in
      # the following order:
      #   1) Using the Java implementation of the PropertyFileLoader and BracketedVariableHandler classes
      #      which requires a jar path be in the wsadmin_classpath setting
      #   2) A jython implementation of the PropertyFileLoader and BracketedVariableHandler classes
      #   3) Using java.util.Properties() to load the properties file. This option differs significantly
      #      from the others as its not backslash friendly and does not support variable substitution
      try:
        try:
          # First attempt, use java library
          from com.ibm.issw.pdinstall.scripting.fileloading import PropertyFileLoader as JavaPropertyFileLoader
          from com.ibm.issw.pdinstall.scripting.var import BracketedVariableHandler as JavaBracketedVariableHandler
          
          if ( not isEmpty(varLocation)):
            _app_message("Variable map is read from %s" % varLocation )
            varHandler = JavaBracketedVariableHandler("#{","}",varLocation)
            fileLoader = JavaPropertyFileLoader(varHandler)
          else:
            fileLoader = JavaPropertyFileLoader(None)
        except:
          # 2nd attempt, use Jython implementation
          _app_message("Using jython implementation to load property files")
          if ( not isEmpty(varLocation)):
            _app_message("Variable map is read from %s" % varLocation )
            varHandler = BracketedVariableHandler("#{","}",varLocation)
            fileLoader = PropertyFileLoader(varHandler)
          else:
            fileLoader = PropertyFileLoader(None)
 
        if progInfo.get("app.config.location") == None:
          _app_message("ERROR: Input property configuration file was not specified.")
          _app_message("Specify the file on command line or in the app.config.location system property")
          return
          
        _app_message("Loading properties from %s" % progInfo["app.config.location"])
        
        try:
          fileprop = fileLoader.loadProperties(progInfo["app.config.location"])
        except:
          progInfo["app.initialization.error"] = "true"
          _app_trace("Error loading property file","exception")
          _app_message("Error loading property file")
          return
      
      except:
        # 3rd option using java.util.Properties()
        
        _app_message("Using java.util.Properties to load properties file")

        # Use Java to load it, it is a properties file
        # Note that \ will be treated as an escape character
        fileprop = Properties()
        print "Loading properties from "+ progInfo["app.config.location"]
        fileStream = FileInputStream(progInfo["app.config.location"])
        fileprop.load(fileStream)


      if (fileprop == None or fileprop.size() == 0):
          # No properties were loaded
          _app_message("No properties were loaded from %s - check to see if file is empty" % progInfo["app.config.location"])
          #progInfo["app.initialization.error"] = "true"
          return
          
      configNames = fileprop.propertyNames()

      for configName in configNames:
        configInfo[configName] = fileprop.getProperty(configName)
      
      stripMetaValues(configInfo)
        
      removedSkippedSections(configInfo)
      
      calculateCounts(configInfo)

      progInfo["hostip"] = InetAddress.getByName(progInfo["com.ibm.ws.scripting.host"])

      _app_trace("host IP     = %s" % (progInfo["hostip"]))
      _app_trace("username    = %s" % (progInfo["user.name"]))
      _app_trace("config file = %s" % (progInfo["app.config.location"]))

      _app_trace("initialise()", "exit")
    except:
      # Do not call _app_trace, all variables it requires may not be initialised
      progInfo["app.initialization.error"] = "true"
      print "Unknown error during initialise()"

      i = 1;
      
      for exc in sys.exc_info():
        print "(%d): %s" % (i, exc)
        i = i + 1
      
##########################################################################
#
# FUNCTION:
#    isEmpty: Checks if variable is empty or None
#
# SYNTAX:
#    isEmpty(variable)
#
# PARAMETERS:
#    
#	variable - Name of variable to validate
#
# RETURNS:
#    	1:	variable = "" or None
#	0:	variable != "" and != None
#
##########################################################################
def isEmpty(var,quietMode=0):
  if (quietMode==0):
    # Check the global setting
    if (progInfo["app.trace.isempty"] == 0):
      quietMode = 1
  
  if (quietMode == 0):
    _app_trace("isEmpty(%s)" % (var), "entry")
    
  retval = (var == "" or var == None or var == "[]" or str(var) == "['']")
  
  if (quietMode==0):
    _app_trace("isEmpty(%d)" % (retval), "exit")
  
  return retval

#---------------------------------------------------------------------------
# noEmptyDictionaries
#
# Loop through one or more dictionaries passed in as parms
# and return 1 if any are non-empty
#---------------------------------------------------------------------------
def noEmptyDictionaries(*dictionaries):
  retval = 0
  if (dictionaries != None and len(dictionaries) > 0):
    for d in dictionaries:
      if (d != None and len(d) > 0):
        #print d
        retval = 1
        break
  
  return retval


##########################################################################
#
# FUNCTION:
#    modifyObject: Modify the attributes of a given object using AdminConfig
#
# SYNTAX:
#    modifyObject(objid, attributes)
#
# PARAMETERS:
#    
#    objid	- Object ID (usu. retrieved via AdminConfig.getid)
#    attributes	- List of attributes in format recognised by AdminConfig.modify
#
# RETURNS:
#    	0:	Success
#	1:	Failure
#
##########################################################################
def modifyObject(objid, attributes, minimumTrace=0):
	
	retval = 1
	
	try:
		if (minimumTrace):
			_app_trace("modifyObject(%s, attributes)" % (objid), "entry")
		else:
			_app_trace("modifyObject(%s, %s)" % (objid, attributes), "entry")
		
		if (minimumTrace):
			_app_trace("Running command: AdminConfig.modify(%s, attributes)" % (objid))
		else:
			_app_trace("Running command: AdminConfig.modify(%s, %s)" % (objid, attributes))
			
		AdminConfig.modify(objid, attributes)
		
		retval = 0
		
	except:
		_app_trace("An error was encountered modifying object attributes", "exception")
		retval = 1
		
	_app_trace("modifyObject(%d)" % (retval), "exit")
	return retval

##########################################################################
#
# FUNCTION:
#    objectExists: Determines existence of object
#
# SYNTAX:
#    objectExists (type, parent, name)
#
# PARAMETERS:
#    
#	type	- Config object type, e.g. JDBCProvider
#		  See AdminConfig.types()	
#	parent	- Object's parent as containment path
#		  e.g. /Cluster:_CLUSTER/
#	name	- Name of object 
#
# USAGE NOTES:
#    1. Call this to ensure an object doesn't exist before creating it
#	or an object does exist before querying, modifying or deleting it
#
# RETURNS:
#    	1:	object exists
#	0:	object does not exist
#
##########################################################################
def objectExists (type, parent, name):

	retval = 1
	
	try:
		_app_trace("objectExists(%s, %s, %s)" % (type, parent, name), "entry")

		if isEmpty(type) or isEmpty(name):
			_app_trace("type and name MUST contain non-empty values")
			retval = 0
		else:
			#	Get the ID for this object
			if isEmpty(parent):
				cpath = "/%s:%s/" % (type, name)
			else:
				cpath = "%s%s:%s/" % (parent, type, name)

			_app_trace("getid for " + cpath)

			objid = AdminConfig.getid(cpath)

			if isEmpty(objid):
				_app_trace("Cannot get Object ID for %s" % (cpath))
				retval = 0
				
	except:
		_app_trace("An error was encountered checking object exists", "exception")
		retval = 0
		
	_app_trace("objectExists(%d)" % (retval), "exit")
	return retval

##########################################################################
#
# FUNCTION:
#	searchReplaceFile:	Search/replace within file
#
# SYNTAX:
#	searchReplaceFile (file, s_token, d_token)
#
# PARAMETERS:
#
#	file		-	Name of file to perform search/replace in
#	s_token	-	String to search for
#	d_token	-	Replacement string
#
#
# USAGE NOTES:
#     1.	This function will overwrite the orginal file with the 
#		replacement string, it will not create a backup
#	
# RETURNS:
#    	N/A
#	
##########################################################################
def searchReplaceFile(file, s_token, d_token):

	fp = open(file, "r")
	buff = fp.read()
	fp.close()

	buff2 = buff.replace(s_token, d_token)

	fp = open(file, "w")
	fp.write(buff2)
	fp.close()

##########################################################################
#
# FUNCTIONS:
#    tron, troff, trlogon, trlogoff, trlogclear:	Trace functions
#
# SYNTAX:
#    tron()		:	Turn tracing on (outputs to console by default)
#    troff()			Turn tracing off
#    trlogon()			Turn tracing to file on
#    trlogoff()			Turn tracing to file off
#    trlogclearon()		Clear (truncate) trace file
#
# PARAMETERS:
#
#    NONE
#
# RETURNS:
#    	N/A
#	
##########################################################################
	
def tron():
	
	global progInfo
	progInfo["app.trace.level"] = 1
	
	_app_message("Trace on")

def troff():
	
	global progInfo
	progInfo["app.trace.level"] = 0
	
	_app_message("Trace off")
	
def trlogon():
	global progInfo

	try:
		_app_message("Tracelog open")

		progInfo["app.trace.tracelogfp"] = open(progInfo["app.trace.log.file"], "a")
		progInfo["app.trace.log"] = 1
		tron()
	except:
		_app_message("Error opening tracefile %s" % (progInfo["app.trace.log.file"]))

def trlogoff():
	global progInfo

	try:
		if progInfo["app.trace.log"] == 1:
			_app_message("Tracelog closed")	

			troff()
			progInfo["app.trace.tracelogfp"].close()
			progInfo["app.trace.log"] = 0

	except:
		_app_message("Error closing tracefile %s" % (progInfo["app.trace.log.file"]))

def trlogclear():
	global progInfo
	
	try:
		if progInfo["app.trace.log"] == 1:

			#	fp.truncate() not supported?
			progInfo["app.trace.tracelogfp"].close()
			progInfo["app.trace.tracelogfp"] = open(progInfo["app.trace.log.file"], "w")
			_app_message("Tracelog cleared")	
		
	except:
		_app_message("Error clearing tracefile %s" % (progInfo["app.trace.log.file"]))


##########################################################################
#
# FUNCTION:
#    modifyPorts: Modify Server Ports
#
# SYNTAX:
#    modifyPorts (serverId, ports)
#
# PARAMETERS:
#    
#	serverId- Server Id
#	ports	- java.util.Properties object with following 
#		  hostalias = host|port 
# 
#
# USAGE NOTES:
#
# RETURNS:
#    	1:	failed
#	0:	successful
#
##########################################################################
def modifyPorts (serverId, ports):

	retval = 1
	
	try:
		_app_trace("modifyPorts(%s, %s)" % (serverId, ports), "entry")

		if isEmpty(serverId) or isEmpty(ports):
			_app_trace("serverId and ports must be supplied")
			retval = 0
		else:
			retval = 0
        		for key in ports.keys():
                        	propAttrs = []
                        	vals = ports[key].split("|")
                        	propAttrs.append([key,[["host", vals[0]],["port",vals[1]]]])

                        	if (key == "BOOTSTRAP_ADDRESS"):
                                	endpointsId = AdminConfig.list("NameServer",serverId)

                        	if (key == "SOAP_CONNECTOR_ADDRESS"):
                                	endpointsId = AdminConfig.list("SOAPConnector",serverId)

                        	if (key == "DRS_CLIENT_ADDRESS"):
                                	endpointsId = AdminConfig.list("SystemMessageServer",serverId)

                        	if (key == "JMSSERVER_QUEUED_ADDRESS"):
                                	endpointsId = AdminConfig.list("JMSServer",serverId)

                        	if (key == "JMSSERVER_DIRECT_ADDRESS"):
                                	endpointsId = AdminConfig.list("JMSServer",serverId)

                        	kini= AdminConfig.modify(endpointsId, propAttrs) 
				#print "RetVal = %s" % kini
				retval = 1
				#break
				
	except:
		_app_trace("An error was encountered while changing the ports", "exception")
		retval = 1
		
	_app_trace("modifyPorts(%d)" % (retval), "exit")
	return retval




#-------------------------------------------------------------------------
def loadProperties(fileName):
        fullName = "%s/%s" % (progInfo['app.data.location'],fileName)
        props = java.util.Properties()
        props.load(java.io.FileInputStream(fullName))
        return props
#-------------------------------------------------------------------------
def existsDestination(cluster, node, server):
 
 	retval = 0
 
 	try:
 		traceStr = "existsDestination(%s, %s, %s)" % (cluster, node, server)
 		_app_trace(traceStr, "entry")	
 	
		if (isEmpty(cluster)):
			return existsWebServer(server, node)
		else:
 			configID = "/ServerCluster:%s/" % cluster
 		
		id = AdminConfig.getid(configID)

		if isEmpty(id):
			retval = 0
		else:
			retval = 1
 	except:
 		_app_trace("An error was encountered checking existence of the Destination", "exception")
 		retval = 0
	
 	_app_trace("existsDestination(%d)" % (retval), "exit")
 	return retval

#-------------------------------------------------------------------------
def existsJAASAlias(alias):
    #@JM did a split on '\n' instead of "line.separator"
		j2c_aliases = AdminConfig.list("JAASAuthData").split(progInfo["line.separator"])
		for entry in j2c_aliases:
			if (isEmpty(entry)): 
				continue
				
			if (AdminConfig.showAttribute(entry, "alias") == alias):
				return 1
				
		return 0
#-------------------------------------------------------------------------
def getJAASAlias(alias):
        j2c_aliases = AdminConfig.list("JAASAuthData").split(progInfo["line.separator"])
        for entry in j2c_aliases:
		if (isEmpty(entry)): continue
                if (AdminConfig.showAttribute(entry, "alias") == alias):
			return entry
	return None
#-------------------------------------------------------------------------
def existsReplicationDomain(rdName):
	rdIds = AdminConfig.list("DataReplicationDomain").split(progInfo["line.separator"])
	for rd in rdIds:
		if (isEmpty(rd)): continue
		if ( rdName == AdminConfig.showAttribute(rd,"name")):
			return 1
	return 0
#------------------------------------------------------------------------------------------------------
def existsSysProperties(propName, jvmId):
	sysId = wsadminToList(AdminConfig.showAttribute(jvmId,"systemProperties"))
	for s in sysId:
		if (isEmpty(s)): continue
		if ( propName == AdminConfig.showAttribute(s,"name")):
			return 1
	return 0
	
#------------------------------------------------------------------------------------------------------
# @JJM
#
# Get the ID of an existing ProcessDef Environment property with the specified name
def checkForExistingEnvProperties(propName, processId):
		retval=None
		envId = wsadminToList(AdminConfig.showAttribute(processId,"environment"))
		for envprop in envId:
				if (isEmpty(envprop)): continue
				if ( propName == AdminConfig.showAttribute(envprop,"name")):
						retval = envprop
						break
		return retval
		
#------------------------------------------------------------------------------------------------------
# @JJM
#
# Get the ID of an existing property with the specified name and property attribute name
#------------------------------------------------------------------------------------------------------
def checkForExistingProperties(propName, parentId, propertyAttributeName="properties"):
		retval=None
		propertyIdList = wsadminToList(AdminConfig.showAttribute(parentId,propertyAttributeName))
		for propertyId in propertyIdList:
				if (isEmpty(propertyId)): continue
				if ( propName == AdminConfig.showAttribute(propertyId,"name")):
						retval = propertyId
						break
		return retval
#------------------------------------------------------------------------------------------------------
# @JJM
def existsEnvProperties(propName, processId):
	envId = wsadminToList(AdminConfig.showAttribute(processId,"environment"))
	for envprop in envId:
		if (isEmpty(envprop)): continue
		if ( propName == AdminConfig.showAttribute(envprop,"name")):
			return 1
	return 0
#------------------------------------------------------------------------------------------------------
def existsWebServer(name, nodeName):
	node=AdminConfig.getid("/Node:%s/" % nodeName)
	if (isEmpty(node)):
	  return 0
	ses = wsadminToList(AdminConfig.list("ServerEntry", node))
	for se in ses:
		if (isEmpty(se)): continue
        	if (name == AdminConfig.showAttribute(se, "serverName")):
                	return 1
	return 0


#------------------------------------------------------------------------------------------------------
def existsDataSource(jndiName):
	dss=AdminConfig.list("DataSource").split(progInfo["line.separator"])
	for ds in dss:
		if (isEmpty(ds)): continue
        	if (jndiName == AdminConfig.showAttribute(ds, "jndiName")):
                	return 1
	return 0


#------------------------------------------------------------------------------------------------------
def deleteSysProperties(propName, jvmId):
	sysId = wsadminToList(AdminConfig.showAttribute(jvmId,"systemProperties"))
	for s in sysId:
		if (isEmpty(s)): continue
		if ( propName == AdminConfig.showAttribute(s,"name")):
			AdminConfig.remove(s)	
			return 
#------------------------------------------------------------------------------------------------------
# @JJM
def deleteEnvProperties(propName, processId):
	envId = wsadminToList(AdminConfig.showAttribute(processId,"environment"))
	for envprop in envId:
		if (isEmpty(envprop)): continue
		if ( propName == AdminConfig.showAttribute(envprop,"name")):
			AdminConfig.remove(envprop)	
			return 
#------------------------------------------------------------------------------------------------------
def getVirtualHost(virtualHostName):
	vhl = AdminConfig.list("VirtualHost").split(progInfo["line.separator"])
	for v in vhl:
		if (isEmpty(v)): continue
		if ( virtualHostName == AdminConfig.showAttribute(v,"name")):
			return v
	return None
#------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------
# collectResourceProperties - add properties to a Properties object for the resource properties in a J2EEResourcePropertySet attribute
# Parms:
#  props - The property set that new properties will be added to
#  configId - resource that has a J2EEResourcePropertySet attribute
#  propertyName - the propertyName of the J2EEResourcePropertySet attribute
#  prefix - the prefix to use.  
#  
#  This function will produce properties in the format "<prefix>.resourceProperties.prop.name = type|required|val|desc"
#------------------------------------------------------------------------------------------------------------------------------------
def collectResourceProperties(props,configId,propertyName,prefix):
  mId = AdminConfig.showAttribute(configId,propertyName)
  if not (isEmpty(mId)):
    rps = AdminConfig.showAttribute(mId,"resourceProperties")
    rpsarray = wsadminToList(rps)   #rps[1:len(rps)-1].split(' ')
    for rp in rpsarray:
        if (isEmpty(rp)):
            continue
        tempProps = {}
        collectSimpleProperties(tempProps, "temp.prop", rp)
        
        rname = tempProps.get('temp.prop.name','')
        rtype = tempProps.get('temp.prop.type','')
        rval = tempProps.get('temp.prop.value','')
        rdesc = tempProps.get('temp.prop.description','')
        rrequired = tempProps.get('temp.prop.required','')
        
        if (not isEmpty(rtype) and not isEmpty(rrequired)):
          if isEmpty(rdesc):
            
            props["%s.resourceProperties.prop.%s" % (prefix, rname)] = "%s|%s|%s" % (rtype,rrequired,rval)
          else:
            props["%s.resourceProperties.prop.%s" % (prefix,rname)] =  "%s|%s|%s|%s" % (rtype,rrequired,rval,rdesc)
        else:
          if isEmpty(rdesc):
            props["%s.resourceProperties.prop.%s" % (prefix, rname)] =  rval
          else:
            props["%s.resourceProperties.prop.%s" % (prefix, rname)] = "%s|%s" % (rval,rdesc)

#--------------------------------------------------------------------------------------------
# colledtResourcePropertiesList
#
# Format properties for a list of J2EEResourceProperty IDs and add the result to the 
# supplied property set
#--------------------------------------------------------------------------------------------
def collectResourcePropertiesList(props,prefix, rpList):
    for rp in rpList:
        if (isEmpty(rp)):
            continue
        tempProps = {}
        collectSimpleProperties(tempProps, "temp.prop", rp)
        
        rname = tempProps.get('temp.prop.name','')
        rtype = tempProps.get('temp.prop.type','')
        rval = tempProps.get('temp.prop.value','')
        rdesc = tempProps.get('temp.prop.description','')
        rrequired = tempProps.get('temp.prop.required','')
        if (not isEmpty(rtype) and not isEmpty(rrequired)):
          if isEmpty(rdesc):
            props["%s.prop.%s" % (prefix, rname)] = "%s|%s|%s" % (rtype,rrequired,rval)
          else:
            props["%s.prop.%s" % (prefix,rname)] = "%s|%s|%s|%s" % (rtype,rrequired,rval,rdesc)
        else:
          if isEmpty(rdesc):
            props["%s.prop.%s" % (prefix, rname)] = rval
          else:
            props["%s.prop.%s" % (prefix,rname)] = "%s|%s" % (rval,rdesc)


#--------------------------------------------------------------------------------------------
# collectSimpleProperties
#
# Put key/value pairs from configuration item into property set. Optionally, this function will 
# store configuration IDs of subitems in the idProps proeprty set if it is supplied.
#
# Parameters:
#     props - Property set to add items to, if None one will be created
#     prefix - prefix to use for property names. Attribute names will be appended to the prefix.
#     objId - The configuration item to collect attribute properties from
#     optionalSkipList - A list of attributes to ignore
#     idProps - An optional properties object to store IDs of attributes that refer to other
#               configuration items
#
#     getSimpleChildren - if 1, then the function will recurse and return properties of 
#             child items in the format <prefix-without-.prop>.<attributeNameInParentItem>.prop.<childAttribute> = childAttributeValue
#             The child item must be of a configuration type and not a list or reference or complex type
#    
#
#  Returns:
#     props - The property set passed in or a newly created one if none was supplied
#--------------------------------------------------------------------------------------------
def collectSimpleProperties(props, prefix,objId, optionalSkipList=[],idProps=None,getSimpleChildren=0,childrenSkipList=None,
                           collectPropertyAttributes=0,useAttrNameWithProperties=0,collectListChildren=0,getChildType=1,sortListChildren=0):
  #_app_trace("collectSimpleProperties(props, %s,%s, %s,%s,%d,%s)" % (prefix, objId, optionalSkipList,idProps,getSimpleChildren,childrenSkipList) , "entry")
  try:
    
    if (props == None):
      props = java.util.Properties()
      
    if (objId == ""): return
    skipTags = ["managedObject", "server"]
    listDict = {}
    
    attrs = AdminConfig.show(objId).split(progInfo["line.separator"])
    for attr in attrs:
        key,val= toKeyValue(attr)
        
        if (key in skipTags): continue
        if (key in optionalSkipList): continue
        if (isEmpty(val)): continue
        
        if (val.startswith('"') and val.endswith('"')):
            val = val[1:-1]
        
        if (isArray(val)):
          if (idProps != None):
            idProps["%s.%s" % (prefix, key)] = val
          listDict[key] = val
          continue
          
        if (isId(val) == 1):
            if (idProps != None):
              #print "%s %s" % (key,val)
              idProps["%s.%s" % (prefix, key)] = val
            continue
        else:
            props["%s.%s" % (prefix, key)] = val
    configType = None
    childPrefixRoot = prefix

    if (getSimpleChildren or collectPropertyAttributes):
      if (childPrefixRoot.endswith(".prop")):
        childPrefixRoot = childPrefixRoot[:-5]

      configType = None
      try:
        configType = AdminConfig.getObjectType(objId)
      except:
        configType = None
    
    if (collectPropertyAttributes):
      if (not isEmpty(configType)):
        propertyAttrList = getPropertyAttributes(configType)
        rpcount = 0
        pcount = 0
        for pattr in propertyAttrList:
          attrName = pattr[0]
          attrType = pattr[1]
          
          if (attrType == "J2EEResourcePropertySet"):
            rpcount += 1
          else:
            pcount +1
        
        for pattr in propertyAttrList:
          attrName = pattr[0]
          attrType = pattr[1]
          
          pprefix = childPrefixRoot
          
          if (attrType == "J2EEResourcePropertySet"):
            if (useAttrNameWithProperties or (rpcount > 1)):
              pprefix = "%s.%s" % (childPrefixRoot,attrName)
              
            collectResourceProperties(props,objId,attrName,pprefix)
          else:
            pprefix = "%s.%s" % (childPrefixRoot,attrName)
            collectCustomProperties(props,pprefix, objId, attributeName=attrName)
            #print "Collected props %s = %s" % (pprefix,filterProperties(props,pprefix))

    
    # Now process child attributes if so desired        
    if (getSimpleChildren):
      
      if (not isEmpty(configType)):
        subItemList = getSimpleSubComponentAttributes(configType,allowSubClasses = getChildType)
        
        for subItem in subItemList:
          subAttribute = subItem[0]
          subType = subItem[1]
        
          if (childrenSkipList != None and subAttribute in childrenSkipList):
            continue
        
          childPrefix = "%s.%s.prop" % (childPrefixRoot,subAttribute)
          
          try:
            childId = AdminConfig.showAttribute(objId,subAttribute)
          except:
            childId = None
          
          if (not isEmpty(childId)):
            if (getChildType):
              props["%s.%s.type" % (childPrefixRoot,subAttribute)] = callGetObjectType(childId)
              
            collectSimpleProperties(props, childPrefix,childId, optionalSkipList=[],idProps=idProps,getSimpleChildren=1,
                                    childrenSkipList=childrenSkipList,collectListChildren=collectListChildren,
                                    getChildType=getChildType,collectPropertyAttributes=collectPropertyAttributes,useAttrNameWithProperties=useAttrNameWithProperties,
                                    sortListChildren=sortListChildren)
    
    if (collectListChildren):
      for lkey in listDict.keys():
        cfgList = wsadminToList(listDict[lkey])
        
        if (sortListChildren):
          cfgList.sort()
        
        lidx = 0
        for cfg in cfgList:
          if (isEmpty(cfg)):
            continue
          if (childrenSkipList != None and lkey in childrenSkipList):
            continue
            
          lidx += 1
          
          if (getChildType):
            props["%s.%s.%d.type" % (childPrefixRoot,lkey,lidx)] = callGetObjectType(cfg)
          lprefix = "%s.%s.%d.prop" % (childPrefixRoot,lkey,lidx)
          
          if (idProps != None):
            idProps["%s.%s.%d" % (childPrefixRoot,lkey,lidx)] = cfg
          
          collectSimpleProperties(props,lprefix,cfg,optionalSkipList=[],idProps=idProps,getSimpleChildren=1,childrenSkipList=childrenSkipList,collectListChildren=1,getChildType=getChildType,
                                  collectPropertyAttributes=collectPropertyAttributes,useAttrNameWithProperties=useAttrNameWithProperties,sortListChildren=sortListChildren)
        
        if (lidx > 0):
          props["%s.%s.count" % (childPrefixRoot,lkey)] = str(lidx)
          if (idProps != None):
            idProps["%s.%s.count" % (childPrefixRoot,lkey)] = str(lidx)
                 
            
         
  except:
    _app_trace("Error collecting properties","exception")
    raise StandardError("Error collecting properties")
    
  #_app_trace("collectSimpleProperties()","exit")
  return props
	
#-----------------------------------------------------------------------------------------------------
# collectCustomPropertiesOriginal
#
# This implemenation relies on collectSimpleProperties to get attributes of each property
#-----------------------------------------------------------------------------------------------------
def collectCustomPropertiesOrginal(props,prefix, objId, attributeName="customProperties"):
		
		customProperties =AdminConfig.showAttribute(objId,attributeName)
		cpProperties = java.util.Properties()
		if (not isEmpty(customProperties)):
			for cpropsitem in wsadminToList(customProperties):
				if (isEmpty(cpropsitem)):
					continue
				cpProperties.clear()
				
				collectSimpleProperties(cpProperties, "prop",cpropsitem, [])
				
				cpropdesc = cpProperties.get("prop.description")
				cpropname = cpProperties.get("prop.name")
				cpropval = cpProperties.get("prop.value")
				
				if (cpropval == None):
					cpropval = ""
				
				if isEmpty(cpropdesc):
					props.put("%s.prop.%s" % (prefix, cpropname), cpropval)
				else:
					props.put("%s.prop.%s" % (prefix,cpropname), "%s|%s" % ( cpropval, cpropdesc))
				
				
#-----------------------------------------------------------------------------------------------------
# collectCustomProperties
#
# This method will check a configuration item for a custom properties attribute and return the
# the key/values/descriptions of those custom properties as properties.
#
# The properties will be returned in the format <prefix>.prop.key = value[|descr]
#
# Parameters:
#   props - the property set to add the values to
#   prefix - the property prefix to use
#   objId - The configuration item
#   attributeName - the custom property attribute name, defaults to "customProperties"
#
# This implemenation relies on parsing of the results from AdminConfig.showall(objId,attributeName)
# where objId is the configuration item with custom properties and attributeName is the attribute
# that returns the list of custom property IDs.
#-----------------------------------------------------------------------------------------------------
def collectCustomProperties(props,prefix, objId, attributeName="customProperties"):
	try:
		propertyText = AdminConfig.showall(objId, attributeName)
		if (not isEmpty(propertyText)):
			
			# Trim the string down to remove the opening "[propertyName ["  and last "]]"
			firstPos = propertyText.find("[[")
			if (firstPos > 0):
				propertyText = propertyText[firstPos+1:-2]
				#print "Modded text"
				#print propertyText
				
				# Convert newlines into spaces so we have a uniform representation
				# to parse.  
				propertyTextLines = propertyText.split(progInfo["line.separator"])
		
				reformedText = ""
				for line in propertyTextLines:
					if reformedText == "":
						reformedText = line
					else:
						reformedText = "%s %s" % (reformedText,line)
		
				# Ok, now we want to split on " [["
				# This will give us one line per property
				propertyList = reformedText.split(" [[")
				for prop in propertyList:
					# Restore the opening brackets
					# First line will have them, others wont
					if ( not prop.startswith("[[")):
						prop = "[[%s" % prop
					
					# Remove first pair of brackes
					prop = prop[1:-1]
					#print prop
					
					# Now we need to split the attributes
					attribs = prop.split("] ")
					cpProperties = java.util.Properties()
					for attrib in attribs:
						if (attrib.endswith("[]")):
							# Blank
							attrib = "%s]" % attrib
						elif (not attrib.endswith("]")):
							attrib = "%s]" % attrib
						
						#print attrib
						key,val = toKeyValue(attrib)
						if val.startswith('"') and val.endswith('"'):
							val = val[1:-1]
						if val == "[]":
							val = ""
						
						cpProperties.put(key,val)
				
					#print "%s" % cpProperties
					cpropdesc = cpProperties.get("description")
					cpropname = cpProperties.get("name")
					cpropval = cpProperties.get("value")
				
					if (cpropval == None):
						cpropval = ""
				  

					if isEmpty(cpropdesc):
						  props["%s.prop.%s" % (prefix, cpropname)] =  cpropval
					else:
						  props["%s.prop.%s" % (prefix,cpropname)] = "%s|%s" % ( cpropval, cpropdesc)
						
	except:
		_app_trace("Unexpected error in collectCustomProperties()","exception")
		raise StandardError("Unexpected error in collectCustomProperties()")
		
#---------------------------------------------------------------------------------------------------------
# @JJM
# Update the ID that will be used for dynamic property lookup
#---------------------------------------------------------------------------------------------------------
def setDynamicId(key, idvalue):
		global dynamicIds
		dynamicIds[key] = idvalue
		_app_trace("Set dynamic key %s %s" % (key,dynamicIds[key]))
		
#---------------------------------------------------------------------------------------------------------
# @JJM
# Update the set of dynamic values with values from a property set
#---------------------------------------------------------------------------------------------------------
def setDynamicKeys(propSet):
		global dynamicIds
		for key in propSet.keys() :
				dynamicIds[key] =  propSet.get(key)

#enddef

#---------------------------------------------------------------------------------------------------------
# @JJM
# Remove the keys in the property set from the dynamic IDs dictionary
#---------------------------------------------------------------------------------------------------------
def removeDynamicKeys(propSet):
		global dynamicIds
		for key in propSet.keys() :
				if (dynamicIds.has_key(key)):
						del dynamicIds[key]

#enddef	

#------------------------------------------------------------------------------------------------------
# @JJM
# Remove all custom properties from the parent ID
#------------------------------------------------------------------------------------------------------
def removeAllCustomProperties(parentId, attributeName):
		_app_trace("removeAllCustomProperties(%s,%s)" %(parentId,attributeName), "entry")
			
		custprops=AdminConfig.showAttribute(parentId,attributeName)
		if (not isEmpty(custprops)):
					for cpropsitem in wsadminToList(custprops):
							if (not isEmpty(cpropsitem)):
									cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
									cpropname = AdminConfig.showAttribute(cpropsitem,"name")
									cpropval = AdminConfig.showAttribute(cpropsitem,"value")
									_app_trace("Removing property %s=%s from %s" % (cpropname,cpropval,parentId))
									AdminConfig.remove(cpropsitem)
		
		_app_trace("removeAllCustomProperties()","exit")
	
#--------------------------------------------------------------------------------------------
# @JJM
#
# Updates a set of custom properties for a configuration ID. Designed to work with various
# types of configuration items.  If a property already exists, it will be updated.
# 
# Parameters:
#			parentId - ID of parent configuration item
#     attributeName - the parents attribute name that refers to a list of properties
#     propertyType - the type of properties, e.g., Property or J2EEResourceProperty
#     inputPropertySet - Properties object or Dictionary with key/value pairs in the key = val|desc syntax
#                        or in the key = type|required|value|desc syntax for J2EEResourceProperty
#
# Returns - Error message, "" if no problems
#--------------------------------------------------------------------------------------------
def updateCustomProperties(parentId, attributeName, propertyType, inputPropertySet):
    _app_trace("updateCustomProperties(%s,%s, %s,inputPropertySet)" %(parentId,attributeName,propertyType), "entry")
    # modify connection pool custom properties
    if ( inputPropertySet != None and  len(inputPropertySet) > 0):
    
      #We'll be removing properties, so get a clean set
      propertySet = {}
      propertySet.update(toDictionary(inputPropertySet))
      
      custprops=AdminConfig.showAttribute(parentId,attributeName)
      if (not isEmpty(custprops)):
          # Remove from the custom properties set all properties that exist
          # with the same value
          propSettings = java.util.Properties()
          for cpropsitem in wsadminToList(custprops):
              propSettings.clear()
              
              
              
              # Before we do any processing we want to see if this item
              # is going to be updated by confirming that the property name
              # is in the input property set.  To do that, we check to see
              # if the propery ID contains the name of a key in the input
              # property set. We do this logic to avoid
              # unnecessary calls to the dmgr.  It looks goofy, but should
              # actually improve performance.
              needToUpdate = 0
              for tempkey in propertySet.keys():
                if (cpropsitem.find(tempkey) >= 0):
                  needToUpdate = 1
                  break
              
              if (not needToUpdate):
                #print "Skipping updates to %s" % cpropsitem
                continue 
              
              collectSimpleProperties(propSettings,"prop",cpropsitem,[])
              
              #cpropname = AdminConfig.showAttribute(cpropsitem,"name")
              cpropname = propSettings.get("prop.name")
              
              # See if this is a property we are updating
              newvalDesc = propertySet.get(cpropname)
              if (newvalDesc == None):
                continue
              
              cpropdesc = propSettings.get("prop.description")
              if (cpropdesc == None):
                cpropdesc = ""
              cpropval = propSettings.get("prop.value")
              if (cpropval == None):
                cpropval = ""
              
              #cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
              #cpropval = AdminConfig.showAttribute(cpropsitem,"value")
              
              cproptype = None
              cproprequired = None
              
              if (propertyType == "J2EEResourceProperty"):
                  try:
                    cproptype = propSettings.get("prop.type")
                    cproprequired = propSettings.get("prop.required")
                    
                    #cproptype = AdminConfig.showAttribute(cpropsitem,"type")
                    #cproprequired = AdminConfig.showAttribute(cpropsitem,"required")
                  
                  except:
                    pass
              
              newtype = None
              newrequired = None
              
              #newvalDesc = propertySet.get(cpropname)
              if (newvalDesc != None):
                  newvalDescList = newvalDesc.split("|")
                  if (len(newvalDescList) > 2):
                      # This is 3 or 4 parm format for J2C Resource Properties
                      # java.lang.String|false|valueAble|This is a resource property
                      newtype = newvalDescList[0].strip()
                      newrequired = newvalDescList[1].strip()
                      newval = newvalDescList[2].strip()
                      if (len(newvalDescList) > 3):
                          newdesc = newvalDescList[3].strip()
                      else:
                          newdesc = cpropdesc
                  else:
                      # 1 or 2 value format for val|desc
                      newval = newvalDescList[0].strip()
                      if (len(newvalDescList) > 1):
                          newdesc = newvalDescList[1].strip()
                      else:
                          newdesc = cpropdesc
                          
                  if (newval == cpropval):
                      # Remove it so we don't process it
                      del propertySet[cpropname]
                  else:
                      # Change this value
                      if (newdesc == None):
                          newdesc = ""
                          
                      if (newval.startswith('"') and newval.endswith('"')):
                        newval = newval[1:-1]
                      
                      if (newdesc.startswith('"') and newdesc.endswith('"')):
                        newdesc = newdesc[1:-1]
                      
                      #cpProps = [ ["value",newval] , ["description", newdesc]]
                      if (propertyType == "J2EEResourceProperty"):
                          cpProps = '[value "%s"]  [description "%s"]' % (newval, newdesc)
                          
                          if (not isEmpty(newtype) and newtype != cproptype):
                              cpProps = "%s [type '%s']" % (cpProps, newtype)
                          
                          if (not isEmpty(newrequired) and newrequired != cproprequired):
                              cpProps = "%s [required '%s']" % (cpProps, newrequired)
                          
                          cpProps = "[ %s ]" % cpProps
                        
                      else:
                        cpProps = '[ [value "%s"]  [description "%s"]]' % (newval, newdesc)
                      
                      if (modifyObject(cpropsitem, cpProps)):
                          errmsg = "Error updating property %s = %s|%s for %s" % (cpropname,newval,newdesc,parentId)
                          _app_trace(errmsg)
                          _app_trace("updateCustomProperties()", "exit")
                          return errmsg
                      
                      
                      del propertySet[cpropname]
      
      #Now process remaining properties
      for cpKey in propertySet.keys():
          cpProps = []
          valDes = propertySet[cpKey].split("|")
          if (len(valDes) == 4):
              # This is 4 parm format for J2C Resource Properties
              # java.lang.String|false|valueAble|This is a resource property
              newtype = valDes[0]
              newrequired = valDes[1]
              newval = valDes[2]
              newdesc = valDes[3]
              if (newval.startswith('"') and newval.endswith('"')):
                  newval = newval[1:-1]
                      
              if (newdesc.startswith('"') and newdesc.endswith('"')):
                  newdesc = newdesc[1:-1]
                    
              cpProps = '[ [name "%s"] [value "%s"] [type "%s"] [required "%s"] [description "%s"] ]' % (cpKey, newval,newtype,newrequired, newdesc)
          elif (len(valDes) == 3):
              # This is 3 parm format for J2C Resource Properties
              # java.lang.String|false|valueAble
              newtype = valDes[0]
              newrequired = valDes[1]
              newval = valDes[2]
              if (newval.startswith('"') and newval.endswith('"')):
                  newval = newval[1:-1]       
              cpProps = '[ [name "%s"] [value "%s"] [type "%s"] [required "%s"]  ]' % (cpKey, newval,newtype,newrequired)

          elif (len(valDes) == 1):
              # Just a value
              #cpProps = [["name", cpKey], ["value", valDes[0]]]
              newval = valDes[0]
              if (newval.startswith('"') and newval.endswith('"')):
                  newval = newval[1:-1]
              if (newval.startswith("'") and newval.endswith("'")):
                  newval = newval[1:-1]             
              cpProps = '[ [name "%s"] [value "%s"] ]' % (cpKey, newval)
          else:
              value = valDes[0].strip()
              description = valDes[1].strip()
              if (value.startswith('"') and value.endswith('"')):
                  value = value[1:-1]
              if (description.startswith('"') and description.endswith('"')):
                  description = description[1:-1]
              #cpProps = [["name", cpKey], ["value", value] , ["description", description ]]
              cpProps = '[ [name "%s"] [value "%s"] [description "%s"] ]' % (cpKey, value, description)
              
          try:
            _app_trace("Running command: AdminConfig.create(%s, %s, %s)" % (propertyType,parentId, cpProps))
            AdminConfig.create(propertyType, parentId, cpProps)
          except:
            errMsg = "Error creating properties: %s" % (cpProps)
            _app_trace(errMsg,"exception")
            _app_trace("updateCustomProperties()", "exit")
            return errMsg
      #endfor each property
      
    _app_trace("updateCustomProperties()", "exit")
    return "" 
#enddef


#-------------------------------------------------------------------------------
# updateJ2EEResourcePropertySet
#
# Updates a J2EEResourcePropertySet attribute for the configuration item
# specified with the parentId parameter.
#-------------------------------------------------------------------------------
def updateJ2EEResourcePropertySet(parentId, rpDict, attributeName="propertySet"):
  _app_trace("updateJ2EEResourcePropertySet(%s,%s,%s)" % (parentId, rpDict, attributeName),"entry")
  
  try:
    # modify J2EEResourcePropertySet props
    propertySetId = AdminConfig.showAttribute(parentId, attributeName)
    if (isEmpty(propertySetId)):
     		propertySetId=AdminConfig.create("J2EEResourcePropertySet", parentId, [],attributeName)
          
    errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", rpDict)
    if (not isEmpty(errmsg)):
    	raise StandardError("Error updating resource properties for %s: %s" % (parentId, errmsg))
  except:
    _app_exception("Unexpected error in updateJ2EEResourcePropertySet")
  
  _app_trace("updateJ2EEResourcePropertySet()","exit")
    


#---------------------------------------------------------------------------------------------------------
# @JJM
#
# This function will parse the input string and process the settings for the following macros:
#     @{DYNAMIC#...#....}
#     @{CONDITIONAL# eval-clause # true-value [# false-value] }
#
# The DYNAMIC macro is processed first and then the CONDITIONAL macro strings are processed. See 
# the determineConditionalValues() function for full details on that macro.
#
# The basic syntax for a dynamic variable is
# @{DYNAMIC#<configuration-item-id>#<get-attribute>}
#
# where 
# <configuration-item-id> is a special identifier or macro used to find an existing configuration item 
# <get-attribute> is the name of the attribute of the configuration to be returned as a result of evaluating this variable.  
#                 It can also be the special keywords HTTP_PORT or HTTPS_PORT if configuration-item-id refers to a server or
#                 NEXT_STARTING_PORT if configuration ID is CURRENT_CLUSTER
#
# configuration-item-id can be one of these keywords:
#
# CURRENT_SERVER - Id of current Server configuration object being updated by script
# CURRENT_NODE - Id of Node of the CURRENT_SERVER
# CURRENT_CLUSTER - Id of the ServerCluster
# CURRENT_CELL - Id of the Cell
# CURRENT_DMGR_SERVER - ID of the Deployment Manager server
# CURRENT_DMGR_NODE - Id of the deployment manager node
#
# configuration-item-id can also be one of these macros:
# 
# KEYWORD - get-attribute should be a propertyName as specified in the servers 
#           <server-prefix>.dynamickeys.prop.<propertyName> = <propertyValue> settings.
# ID(get-id-string)   where get-id-string is passed in to AdminConfig.getid()
# FIND(parent-id |  find-type | matchAttribute | matchValue)  where we use AdminConfig.find(find-type) or 
#     AdminConfig.find(find-type, parent-id) to find an object of type find-type which has attribute matchAttribute of value matchValue.  
#      Parent-id can be "*" for no parent,  one of the above keywords, or an AdminConfig.getid() string.   
#      If the match parms are "*", we'll always match the first item returned in the list.
#      Parent-id can also be the special keywords APPSERVER_NODE - which resolves to a random appserver node or
#                                                 DMGR_NODE - which resolves to the node of the dmgr                                           
# DECRYPT - get-attribute is the string that will be decrypted using the DecryptHelper class.
#
# Here are some example uses:
#
#
# @{DYNAMIC#KEYWORD#MY_SPECIAL_PROPERTY}
#    returns the value of <server-prefix>.dynamickeys.prop.MY_SPECIAL_PROPERTY
# @{DYNAMIC#CURRENT_NODE#hostName}
#    Returns the hostname attribute of the current node. 
# @{DYNAMIC#CURRENT_SERVER#HTTPS_PORT}
#    Returns the HTTPS port (WC_default_secure) of the current server.
# @{DYNAMIC#CURRENT_NODE#name}
#    Returns the name setting of the current node
# @{DYNAMIC#ID(/ServerCluster:SampleCluster/)#shortName}
#    Returns the shortName attribute of the ServerCluster found by AdminConfig.get(�(/ServerCluster:SampleCluster/�).
# @{DYNAMIC#FIND(*|Cell|*|*)#name}
#    Returns the name attribute of the first Cell found (AdminConfig.list(�Cell�))
# @{DYNAMIC#FIND(CURRENT_SERVER|ThreadPool|name|Default)#maximumSize}
#    In the current server, find the ThreadPool where attribute �name� has a value of �Default� and return the value of the �maximumSize� attribute.
#  @{DYNAMIC#FIND(/ServerCluster:SampleCluster/|ClusterMember|memberName|MemberTwo)#nodeName}
#    Find the ServerCluster with AdminConfig.getid(�/ServerCluster:SampleCluster/�), then find a ClusterMember in that ServerCluster 
#   with a �memberName� attribute that has a value of �MemberTwo� and return the nodeName attribute of that ClusterMember.
# @{DYNAMIC#CURRENT_CLUSTER#NEXT_STARTING_PORT} 
#		Find the next starting port for a cluster member based on settings previously registered with the system (app.cluster.n.startingport)
#---------------------------------------------------------------------------------------------------------
def substituteDynamicValues(key, originalValue):
    global dynamicIds 
    
    DYNAMIC_START="@{DYNAMIC"
    
    
    
    result = originalValue
    currentValue = originalValue
    currentPos = 0
    idxDynamic = currentValue.find(DYNAMIC_START,currentPos)
    idxEndBracket = currentPos
    
    # To avoid trace cluster, we'll only do trace entry/exit if dynamic variable is used
    doTrace = 0
    if (idxDynamic >= 0):
        doTrace = 1
        _app_trace("substituteDynamicValues(%s, %s)" % (key, originalValue), "entry")      
    
    while (idxDynamic >= 0) :
        replacementValue = ""
        
        # Determine closing index
        idxEndBracket = currentValue.find("}",idxDynamic)
        
        if (idxEndBracket == -1):
            # Bad structure
            break
            
        # In a few special cases, the end bracket character might be in the parameters to the dynamic syntax
        # We'll handle that case here
        if (currentValue.find("DECRYPT",idxDynamic) >= 0):
            # Let's determine the position of the last end bracket
            idxEndBracket = currentValue.rfind("}",idxDynamic)
            
        
        varsyntax = currentValue[idxDynamic: idxEndBracket]
        
        dynamicParms = varsyntax.split("#")
        if (len(dynamicParms) > 3):
            # The 3rd parm may have contained a # - let's rejoin it
            tempVal = dynamicParms[2]
            for idx in range(3,len(dynamicParms)):
                tempVal = "%s#%s" % (tempVal, dynamicParms[idx])
            dynamicParms[2] = tempVal
        elif (len(dynamicParms) != 3):
            # Bad Structure - leave alone and skip past it
            _app_message("Skipping dynamic variable due to bad syntax: %s" % (varsyntax))
            idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
            continue
        
        # dynamicParms = 
        dynamicKey = dynamicParms[1]
        attributeKeyword = dynamicParms[2]
        _app_trace("Dynamic arguments: %s [%s]" % (dynamicKey, attributeKeyword))
        
        
        
        if (isEmpty(dynamicKey) or isEmpty(attributeKeyword)):
            # Bad format, skip past it
            _app_message("Skipping dynamic variable due to bad syntax: %s" % (varsyntax))
            idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
            continue
            
        
        # See if we have an ID in the 
        if (dynamicKey == "KEYWORD"):
            # This is is the @(DYNAMIC#KEYWORD#keyword) syntax
            
            if (not isEmpty(attributeKeyword)):
                if (dynamicIds.has_key(attributeKeyword)):
                  _app_trace("Looking for keyword %s value" % attributeKeyword)
                  replacementValue = dynamicIds[attributeKeyword]
                else:
                  sysprop = java.lang.System.getProperty(attributeKeyword)
                  if (not isEmpty(sysprop)):
                    replacementValue = sysprop
                  else:
                    # Treat as error
                    _app_trace("Keyword %s not found in dynamicIds" % attributeKeyword)
                    _app_message("Skipping dynamic variable due to missing keyword value, syntax: %s" % (varsyntax))
                    idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
                    continue
        elif (dynamicKey.startswith("ID(")):
            # Special handling for getId lookup
            idPath = dynamicKey[3:-1]
            
            defaultValue = None
            if (attributeKeyword.find(",") > 0):
              attributeList = attributeKeyword.split(",")
              attributeKeyword = attributeList[0]
              defaultValue = attributeList[1]
              
            try:
                configId = AdminConfig.getid(idPath)
            except:
                _app_trace("Error looking up id %s" % idPath, "exception")
                configId = ""
                
            if (isEmpty (configId)):
                if (defaultValue == None):
                  # Can't find object, skip past
                  _app_message("Skipping dynamic variable due to getid failure: %s" % (varsyntax))
                  idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
                  continue
                else:
                  replacementValue = defaultValue
            
            if (attributeKeyword == "HTTP_PORT"):
                replacementValue = getPortForServer(configId,"WC_defaulthost")
            elif (attributeKeyword == "HTTPS_PORT"):
                replacementValue = getPortForServer(configId,"WC_defaulthost_secure")
            else:
                replacementValue = AdminConfig.showAttribute(configId, attributeKeyword)    
                
        elif (dynamicKey.startswith("FIND(")):
            # Special handling for FIND(parent|type|searchAttrib|searchValue)#resultAttrib)
            findParms = dynamicKey[5:-1]
            findParmsList = findParms.split("|")      
            if (len(findParmsList) != 4):
                # Don't have enough values
                idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
                continue
            try:
                findParent = findParmsList[0]
                findType = findParmsList[1]
                findSearchAttrib = findParmsList[2]
                findSearchMatchValue = findParmsList[3]
                
                
                parentId = ""
                # See if parent is one of our keywords
                if (dynamicIds.has_key(findParent)):
                    parentId = dynamicIds[findParent]
                elif (findParent == "APPSERVER_NODE"):
                    # Get the ID of a non-dmgr, non-webserver node
                    managedNodeList = AdminTask.listManagedNodes().split(progInfo['line.separator'])
                    if (len(managedNodeList) > 0 and not isEmpty(managedNodeList[0])):
                        managedNodeName = managedNodeList[0]
                        managedNodeId = AdminConfig.getid("/Node:%s/" % managedNodeName)
                        dynamicIds["APPSERVER_NODE"] = managedNodeId
                        
                        parentId = managedNodeId
                    
                elif (findParent == "DMGR_NODE"):
                    # Get the ID of the deployment manager node
                    dmgrId = AdminConfig.getid("/Server:dmgr/")
                    dmgrNodeId = getNodeForServer(dmgrId)
                    dynamicIds["DMGR_NODE"] = dmgrNodeId
                    parentId = dmgrNodeId
                elif (findParent != "*"):
                    # Treat as getid parm
                    parentId = AdminConfig.getid(findParent)
                    
                
                listResults = None
                
                if (findParent == "*"):
                    listResults = AdminConfig.list(findType).split(progInfo['line.separator'])
                elif (not isEmpty(parentId)):
                    listResults = AdminConfig.list(findType, parentId).split(progInfo['line.separator'])
                
                if (listResults != None and len(listResults) > 0):
                    
                    # Special handling for case where we always want first item
                    foundId = None
                    if (findSearchAttrib == "*" or findSearchMatchValue == "*"):
                        foundId = listResults[0]
                    else:
                        for resultItem in listResults:
                            currentMatchValue = AdminConfig.showAttribute(resultItem, findSearchAttrib)
                            if (currentMatchValue == findSearchMatchValue):
                                foundId = resultItem
                                break
                    
                    defaultValue = None
                    
                    if (attributeKeyword != None and attributeKeyword.find(",") >= 0):
                      attributeKeywordList = attributeKeyword.split(",")
                      attributeKeyword = attributeKeywordList[0]
                      defaultValue = attributeKeywordList[1]
                    
                    
                    if (not isEmpty(foundId)):
                        if (attributeKeyword == "HTTP_PORT"):
                            replacementValue = getPortForServer(foundId,"WC_defaulthost")
                        elif (attributeKeyword == "HTTPS_PORT"):
                            replacementValue = getPortForServer(foundId,"WC_defaulthost_secure")
                        else:
                            replacementValue = AdminConfig.showAttribute(foundId,attributeKeyword)
                            
                    elif (defaultValue != None):
                      replacementValue = defaultValue
                    else:
                        # No match was found, do not do any replacement
                        idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
                        continue
                
            except:
                # Error during find processing
                # Don't have enough values
                _app_trace("Exception in find processing %s" % varsyntax, "exception")
                _app_message("Skipping dynamic variable %s" % varsyntax)
                idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
                continue
        elif (dynamicKey == "DECRYPT"):
            # Use helper method to decrypt password or other encrypted string
            encryptedPassword = attributeKeyword
            decryptedValue = None
            try:
              decryptHelper = DecryptHelper()
              decryptedValue = decryptHelper.decrypt(encryptedPassword)
            except:
              _app_trace("Error calling DecryptHelper()","exception")
              
            # Do the return here - don't want to trace results
            _app_trace("substituteDynamicValues()","exit")
            return decryptedValue
  
        else:
            # The dynamicKey is a special key word that corresponds to 
            # an object in dynamicIds map
            if (dynamicIds.has_key(dynamicKey)):
                configId = dynamicIds[dynamicKey]
                
                # See if the attributeKeyword is a keyword or attribute name
                if (attributeKeyword[0:1].islower()):
                    # treat as attribute
                    replacementValue = AdminConfig.showAttribute(configId, attributeKeyword)
                else:
                    # Special keywords
                    if (dynamicKey ==  "CURRENT_SERVER" and attributeKeyword == "HTTP_PORT"):
                        replacementValue = getPortForServer(configId,"WC_defaulthost")
                    elif (dynamicKey ==  "CURRENT_SERVER" and attributeKeyword == "HTTPS_PORT"):
                        replacementValue = getPortForServer(configId,"WC_defaulthost_secure")
                    elif (dynamicKey == "CURRENT_CLUSTER" and attributeKeyword == "NEXT_STARTING_PORT"):
                        # There are two implementations - one that always goes to config repository
                        # and the other that caches - might want to add switch to control both
                        #startingPort = findDynamicStartingPort()
                        startingPort = findDynamicStartingPortUsingPortLists()
                        if (startingPort != 0):
                          replacementValue  = "%d" % startingPort
                        else:
                          replacementValue = "ERROR: Unable to find open port range"
                    elif (dynamicKey == "CURRENT_NODE" and attributeKeyword.startswith("NEXT_STARTING_PORT")):
                        seedValue = 5000
                        
                        if (attributeKeyword.find("(") >= 0):
                          seedValue = int(attributeKeyword.split("(")[1].split(")")[0])  
                          
                        
                        # There are two implementations - one that always goes to config repository
                        # and the other that caches - might want to add switch to control both
                        #startingPort = findDynamicStartingPort()
                        startingPort = findDynamicStartingPortUsingPortLists(clusterName="_UNCLUSTERED",startingPort=seedValue)
                        if (startingPort != 0):
                          replacementValue  = "%d" % startingPort
                        else:
                          replacementValue = "ERROR: Unable to find open port range"
                          
                    else:
                        # Unknown keyword
                        # Skip past this variable
                        _app_message("Skipping dynamic variable %s" % varsyntax)
                        idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
                        continue
          
            else:
                _app_message("Skipping dynamic variable %s, key %s not found" % (varsyntax, dynamicKey))
                # Skip past this variable
                idxDynamic = currentValue.find(DYNAMIC_START,idxEndBracket)
                continue
          
        if (replacementValue == None):
            replacementValue = ""
        
        
        currentValue = currentValue[0:idxDynamic] + replacementValue + currentValue[idxEndBracket+1:]
        result = currentValue
        idxDynamic = currentValue.find(DYNAMIC_START,idxDynamic)
                    
    # end while
    
    # Now evaluate @{CONDITIONAL...} macros
    result = determineConditionalValues(key, result)


    if (doTrace):
        _app_trace("substituteDynamicValues(result = %s)" % (result), "exit")      
    
    
    return result

#enddef substituteDynamicValues

#-------------------------------------------------------------------------------
# determineConditionalValues
#
# This function will evaulate a string and process the @{CONDITIONAL macro, 
# replacing the macor string with one of two values depending on the evaluation of the
# boolean eval-clause
#
# @{CONDITIONAL# eval-clause # true-value [# false-value] }
#
# where eval-clause can be:
#    boolean value (true|false or yes|no - case insensitive)
#    boolean1 or boolean2 [or boolean3 [or boolean4 ...]]
#    boolean1 and boolean2 [and boolean3 [and boolean4 ...]]
#
# mixed and/or clauses are not currently supported
#
# If the eval-clause evaluates to true, the true value is used as the result 
#
# Parameters:
#   key - property being processed (for logging info only)
#   original value - the string being processed.
#
# Returns:
#   Updated string with @{CONDITIONAL...} macros replaced.
#-------------------------------------------------------------------------------
def determineConditionalValues(key, originalValue):

    CONDITIONAL_START="@{CONDITIONAL"

    result = originalValue
    currentValue = originalValue
    currentPos = 0
    idxConditional = currentValue.find(CONDITIONAL_START,currentPos)
    idxEndBracket = currentPos
    
    # To avoid trace cluster, we'll only do trace entry/exit if dynamic variable is used
    doTrace = 0
    if (idxConditional >= 0):
        doTrace = 1
        _app_trace("substituteDynamicValues(%s, %s)" % (key, originalValue), "entry")      
    
    while (idxConditional >= 0) :
        replacementValue = ""
        
        # Determine closing index
        idxEndBracket = currentValue.find("}",idxConditional)
        
        if (idxEndBracket == -1):
            # Bad structure
            break
        
        conditionalArgs = currentValue[idxConditional:idxEndBracket].split("#")
          
        if (len(conditionalArgs) < 3):
          # bad syntax
          break
        
        evalClause = conditionalArgs[1].strip().lower()
        trueVal = conditionalArgs[2].strip()
        
        if (len(conditionalArgs) > 3):
          falseVal = conditionalArgs[3].strip()
        else:
          falseVal = ""
        
        # Let's evaluate the clause
        evalResult = 0
        if (evalClause == "true" or evalClause == "yes"):
          evalResult = 1
        elif (evalClause == "false" or evalClause == "no" or evalClause == "none"):
          evalResult = 0
        elif (evalClause.find(" or ") >= 0):
          # Evaluate or syntax
          vals = evalClause.split(" ")
          for val in vals:
            if (val == "true" or val == "yes"):
              evalResult = 1
              break
        elif (evalClause.find(" and ") >= 0):
          # Any false/no means false result
          print evalClause
          vals = evalClause.split(" ")
          evalResult = 1
          for val in vals:
            print val
            if (val == "false" or val == "no"):
              evalResult = 0
              print "evalResult=%d" % evalResult
              break
          #endfor
        else:
          #invalid syntax
          break
                
        if (evalResult):
          replacementValue = trueVal
        else:
          replacementValue = falseVal
                  
        currentValue = currentValue[0:idxConditional] + replacementValue + currentValue[idxEndBracket+1:]
        result = currentValue
        idxConditional = currentValue.find(CONDITIONAL_START,idxConditional)
       
    #endwhile
    
    return result
#enddef
    
   

#-----------------------------------------------------------------------------------------
# @JJM
# 
# Return the port value of a named endpoint
#-----------------------------------------------------------------------------------------
def getPortForServer(serverId, endPointName):
    result = ""
    
    serverName = AdminConfig.showAttribute(serverId,"name")
    nodeName = getNodeNameForServer(serverId)
    
    serverEntryId = AdminConfig.getid("/Node:%s/ServerIndex:/ServerEntry:%s/" % (nodeName,serverName))
    if (not isEmpty(serverEntryId)):
      serverEntryList = [ serverEntryId ]
    else:
      nodeId = AdminConfig.getid("/Node:%s/"%nodeName)
      serverEntryList = AdminConfig.list("ServerEntry", nodeId).splitlines()

    for serverEntry in serverEntryList:
        if (isEmpty(serverEntry)):
            continue
        
        if (serverName == AdminConfig.showAttribute(serverEntry, "serverName")):
            specialEndpoints = AdminConfig.showAttribute(serverEntry, "specialEndpoints")
            specialEndpoints = specialEndpoints[1:len(specialEndpoints) - 1].split(" ")
    
            for specialEndpoint in specialEndpoints:

              specialEndpointName = AdminConfig.showAttribute(specialEndpoint, "endPointName")
              if (specialEndpointName == endPointName):
                  objID = AdminConfig.showAttribute(specialEndpoint, "endPoint")
                  if (not isEmpty(objID)):
                      result = AdminConfig.showAttribute(objID, "port")
                      break
            
            break
    
    return result
		
#-------------------------------------------------------------------------------------------
# @JJM
# getNodeForServer
#  
# Given a serverId, return a node ID by parsing the server ID for the nodes name and
# then call AdminConfig.getid
#-------------------------------------------------------------------------------------------
def getNodeForServer(serverId):
		result = ""
		
		components = serverId.split("/")
		idx = 0
		nodeName  = ""
		while (idx < len(components)):
				if (components[idx] == "nodes"):
						nodeName = components[idx+1]
						break;
				
				idx += 1
		
		
		result = AdminConfig.getid("/Node:%s/" % (nodeName))
		
		return result

#-------------------------------------------------------------------------------------------
# @JJM
# getNodeNameForServer
#  
# Given a serverId, return a name by parsing the server ID for the nodes name
#-------------------------------------------------------------------------------------------
def getNodeNameForServer(serverId):
    result = ""
    
    components = serverId.split("/")
    idx = 0
    nodeName  = ""
    while (idx < len(components)):
        if (components[idx] == "nodes"):
            nodeName = components[idx+1]
            break;
        
        idx += 1
    
    
    result = nodeName
    
    return result

#enddef getNodeNameForServer

#-------------------------------------------------------------------------------------------
# @JJM-
# getClusterNameFromTemplateId
#  
# Given a template ID, return the cluster name that the template is for.
#    Returns empty if not a template
#-------------------------------------------------------------------------------------------
def getClusterNameFromTemplateId(serverId):
    result = ""
    
    components = serverId.split("/")
    idx = 0
    clusterName  = ""
    while (idx < len(components)):
        if (components[idx] == "clusters"):
            clusterName = components[idx+1]
            break;
        
        idx += 1
   
    result = clusterName
    
    return result

#-------------------------------------------------------------------------------
# parseNodeClusterDynamic
#
# Parameters
#   serverId - Either a Server ID, cluster template Id, or dynamic cluster template ID
#
# Returns tuple:Node-Name,Cluster-Name,Dyanmic-Cluster-Name  one of which should not be None
#-------------------------------------------------------------------------------
def parseNodeClusterDynamic(serverId):
  _app_entry("parseNodeClusterDynamic(%s)" , serverId)
  
  nodeName = None
  clusterName = None
  dynamicClusterName = None
  
  try:
    components = serverId.split("/")
    idx = 0

    while (idx < len(components)):
        if (components[idx] == "clusters"):
            clusterName = components[idx+1]
            break
        elif (components[idx] == "dynamicclusters"):
            dynamicClusterName = components[idx+1]
            break
        elif (components[idx] == "nodes"):
            nodeName = components[idx+1]
            break
        
        idx += 1
    
  except:
    _app_exception("Unexpected problem in parseNodeClusterDynamic()")
  
  retval = (nodeName,clusterName,dynamicClusterName)
  _app_exit("parseNodeClusterDynamic(retval=%s)" % str(retval))
  return retval

    
#-------------------------------------------------------------------------------------------
# @JJM-
# getClusterNameFromDynamicClusterTemplateId
#  
# Given a template ID, return the cluster name that the template is for.
#    Returns empty if not a template
#-------------------------------------------------------------------------------------------
def getClusterNameFromDynamicClusterTemplateId(serverId):
    result = ""
    
    components = serverId.split("/")
    idx = 0
    clusterName  = ""
    while (idx < len(components)):
        if (components[idx] == "dynamicclusters"):
            clusterName = components[idx+1]
            break;
        
        idx += 1
   
    result = clusterName
    
    return result


#-------------------------------------------------------------------------------------------
# @JJM
# This script uses the CURRENT_NODE and CURRENT_CLUSTER settings to determine
# a place to start looking for a valid starting port. This implementation does not use
# cached data.
#-------------------------------------------------------------------------------------------
def findDynamicStartingPort():

		global dynamicIds
		
		_app_trace("findDynamicStartingPort()", "entry")

		RANGE_BOUNDARY=100000
		try:
				RANGE_BOUNDARY = int(progInfo.get("app.dynamicports.boundarydelta","100000"))
		except:
				RANGE_BOUNDARY = 100000		
		
		result = 0
		if (not dynamicIds.has_key("CURRENT_NODE")):
				_app_message("Unabled to determine dynamic starting port due to missing node")
				_app_trace("findDynamicStartingPort(resutl = 0)", "exit")
				return 0
		
		
		if (not dynamicIds.has_key("CURRENT_CLUSTER")):
				_app_message("Unable to determine dynamic starting port due to missing cluster")
				_app_trace("findDynamicStartingPort(resutl = 0)", "exit")
				return 0
		
		nodeId = dynamicIds["CURRENT_NODE"]
		nodeName = AdminConfig.showAttribute(nodeId, "name")
		
		clusterId = dynamicIds["CURRENT_CLUSTER"]
		clusterName = AdminConfig.showAttribute(clusterId,"name")
		
		if (not dynamicIds.has_key(clusterName+".STARTING_PORT")):
				_app_message("Unable to determine dynamic starting port due to missing seed value")
				_app_trace("findDynamicStartingPort(resutl = 0)", "exit")
				return 0
		
		clusterStartingPort = int(dynamicIds[clusterName+".STARTING_PORT"])
		
		
		nodeKey = clusterName+"."+nodeName+".STARTING_PORT"
		if (not dynamicIds.has_key(nodeKey)):
				# This node hasn't been touched yet, create this setting
				dynamicIds[nodeKey] = "%d" % clusterStartingPort
				nodeStartingPort = clusterStartingPort
		else:
				nodeStartingPort = int(dynamicIds[nodeKey])
				
		_app_message("Looking for dynamic port starting at %d" %(nodeStartingPort))
		
		while (result == 0) and (nodeStartingPort < (clusterStartingPort + RANGE_BOUNDARY)) :
				try:
					if (IsRangeAvailable(nodeId, nodeName, nodeStartingPort, nodeStartingPort+20)) :
							result = nodeStartingPort
							dynamicIds[nodeKey] = "%d" % (nodeStartingPort + 20)
				
					else:
							nodeStartingPort = nodeStartingPort + 20
							_app_message("Looking for dynamic port at %d" %(nodeStartingPort))
				except:
						_app_trace("Error searching for open port", "exception")
						result = 0
						break

		_app_message("Returning dynamic port value of %d" % (result))
		
		_app_trace("findDynamicStartingPort(result = %d)" % result, "exit")
		return result
		

#enddef	

#-------------------------------------------------------------------------------------------
# @JJM
# This script uses the CURRENT_NODE and CURRENT_CLUSTER settings to determine
# a place to start looking for a valid starting port.
#-------------------------------------------------------------------------------------------
def findDynamicStartingPortUsingPortLists(clusterName=None,nodeName=None,startingPort=None):

    global dynamicIds
    nodeId = None
    
    if (not isEmpty(nodeName) and isEmpty(clusterName)):
      clusterName = "_UNCLUSTERED"
    
    _app_trace("findDynamicStartingPortUsingPortLists()", "entry")
    
    RANGE_BOUNDARY=100000
    try:
        RANGE_BOUNDARY = int(progInfo.get("app.dynamicports.boundarydelta","100000"))
    except:
        RANGE_BOUNDARY = 100000
        

    result = 0
    if (isEmpty(nodeName)):
      if (not dynamicIds.has_key("CURRENT_NODE")):
        _app_message("Unabled to determine dynamic starting port due to missing node")
        _app_trace("findDynamicStartingPortUsingPortLists(result = 0)", "exit")
        return 0
    
    if (isEmpty(clusterName)):   
      if (not dynamicIds.has_key("CURRENT_CLUSTER")):
        _app_message("Unable to determine dynamic starting port due to missing cluster")
        _app_trace("findDynamicStartingPortUsingPortLists(result = 0)", "exit")
        return 0
          
    if (isEmpty(nodeName)):
      # Pull from dyanmic Ids dictionary
      nodeId = dynamicIds["CURRENT_NODE"]
      nodeName = AdminConfig.showAttribute(nodeId, "name")
    else:
      nodeId = AdminConfig.getid("/Node:%s/" %nodeName)
    
    if (isEmpty(clusterName)):   
      # Pull from dynamic IDs dictionary
      clusterId = dynamicIds["CURRENT_CLUSTER"]
      clusterName = AdminConfig.showAttribute(clusterId,"name")
    
    clusterStartingPort = 0
    if (isEmpty(startingPort)):
      if (not dynamicIds.has_key(clusterName+".STARTING_PORT")):
        _app_message("Unable to determine dynamic starting port due to missing seed value")
        _app_trace("findDynamicStartingPortUsingPortLists(result = 0)", "exit")
        return 0
    
      clusterStartingPort = int(dynamicIds[clusterName+".STARTING_PORT"])
    else:
      clusterStartingPort = int(startingPort)
    
    nodeKey = clusterName+"."+nodeName+".STARTING_PORT"
    if (not dynamicIds.has_key(nodeKey)):
        # This node hasn't been touched yet, create this setting
        dynamicIds[nodeKey] = "%d" % clusterStartingPort
        nodeStartingPort = clusterStartingPort
    else:
        nodeStartingPort = int(dynamicIds[nodeKey])
        
    _app_message("Looking for dynamic port starting at %d" %(nodeStartingPort))
    
    while (result == 0) and (nodeStartingPort < (clusterStartingPort + RANGE_BOUNDARY)) :
        try:
          
          if (checkForRangeInPortList(nodeId, nodeName, nodeStartingPort, nodeStartingPort+20)) :
              # Make sure dmgr doesn't overlap
              if (checkForRangeInDmgrPortList(nodeId, nodeName, nodeStartingPort, nodeStartingPort+20)) :
                  result = nodeStartingPort
                  dynamicIds[nodeKey] = "%d" % (nodeStartingPort + 20)
  
          if (result == 0):
              nodeStartingPort = nodeStartingPort + 20
              _app_message("Looking for dynamic port at %d" %(nodeStartingPort))
        except:
            _app_trace("Error searching for open port", "exception")
            result = 0
            break

    _app_message("Returning dynamic port value of %d" % (result))
    
    _app_trace("findDynamicStartingPortUsingPortLists(result = %d)" % result, "exit")
    return result
    

#enddef	


#--------------------------------------------------------------------------------------------------------
# @JJM
#
# IsRangeAvailable 
#    Check to see if a port range is in use by a websphere process on the specified node.  This 
#    method always checks the underlying configuration and does not cache results
# 
#	Parameters:
#		nodeId - the configuration ID of the node
#   beginningPort - the start of the range
#   endPort - the value after the last port in the range
#--------------------------------------------------------------------------------------------------------
def IsRangeAvailable(nodeId, nodeName, beginningPort, endPort):
		_app_trace("IsRangeAvailable(%s, %d, %d)"%(nodeId, beginningPort,endPort),"entry")
		
		result = 1
		serverEntries = AdminConfig.list('ServerEntry', nodeId).split(progInfo["line.separator"])
		for serverEntry in serverEntries:
				sName = AdminConfig.showAttribute(serverEntry, "serverName")
				
				#print "Checking end points instead of cache"
						
				endPtStr = AdminConfig.showAttribute(serverEntry, "specialEndpoints")
				specialEndPoints = wsadminToList(endPtStr)
				for specialEndPoint in specialEndPoints:
						if (not isEmpty(specialEndPoint)):
								ePoint =  AdminConfig.showAttribute(specialEndPoint, "endPoint")
								port = int(AdminConfig.showAttribute(ePoint, "port"))
								
								if (port >= beginningPort) and (port < endPort):
										_app_trace("Port %d is in use by server %s and falls in range %d <= port < %d" % (port, sName, beginningPort, endPort))
										_app_trace("IsRangeAvailable(result = 0)","exit")
										return 0
								#endif
						#endif
				#endfor
				
				
				
		#endfor
		
		_app_trace("IsRangeAvailable(result = %d)"% result,"exit")
		return result
		
#enddef


#--------------------------------------------------------------------------------------------------------
# @JJM
#
# checkForRangeInPortList 
#    Check to see if a port range is in use by a websphere process on the specified node.  This 
#    method uses cached port lists to improve performance.
# 
#	Parameters:
#		nodeId - the configuration ID of the node
#		nodeName - the name of the port
#   beginningPort - the start of the range
#   endPort - the value after the last port in the range
#--------------------------------------------------------------------------------------------------------
def checkForRangeInPortList(nodeId, nodeName, beginningPort, endPort):
		_app_trace("checkForRangeInPortList(%s, %s, %d, %d)"%(nodeId, nodeName, beginningPort,endPort),"entry")
		
		result = 1
		portRangeList = getPortListForNode(nodeId, nodeName)
		
		for portRange in portRangeList:
				vals = portRange.split(",")
				if (len(vals) != 3):
						_app_message("Invalid portRange: %s - possible data corruption" % portRange)
						result = 0
						continue
						
				serverName = vals[0]
				serverMin = int(vals[1])
				serverMax = int(vals[2])
				if (serverMin <= beginningPort) and (serverMax >= beginningPort):
							# Beginning port falls in this cached range, go ahead and skip
							_app_trace("Port %d is probably in use by server %s and falls in range %d <= port < %d" % (beginningPort, serverName, serverMin, serverMax))
							result = 0
							break
							
				if (serverMin < endPort) and (serverMax > endPort):
						# end port falls in this cached range, go ahead and skip
						_app_trace("Port %d is probably in use by server %s and falls in range %d <= port < %d" % (endPort, serverName, serverMin, serverMax))
						result = 0
						break				
				
		#endfor
		
		_app_trace("checkForRangeInPortList(result = %d)"% result,"exit")
		return result
		
#enddef

#--------------------------------------------------------------------------------------------
# checkForRangeInDmgrPortList
# 
# Check to see if the node is on same host as dmgr and if so, check to see if port range is
# in use by dmgr
#
# Returns 1 if range is available
#--------------------------------------------------------------------------------------------
def checkForRangeInDmgrPortList(otherNodeId, nodeName, beginningPort, endPort):

		_app_trace("checkForRangeInDmgrPortList(%s,%s,%s,%s)" % (otherNodeId, nodeName, beginningPort, endPort),"entry")

		result = 1
		
		dmgrId = AdminConfig.getid("/Server:dmgr/")
		dmgrNodeId  = getNodeForServer(dmgrId)
		
		dmgrHost = AdminConfig.showAttribute(dmgrNodeId,"hostName")
		otherHost = AdminConfig.showAttribute(otherNodeId,"hostName")
		
		if (dmgrHost == otherHost):
				# Dmgr is also on this box, check for port conflicts
				dmgrNodeName = AdminConfig.showAttribute(dmgrNodeId,"name")
				result = checkForRangeInPortList(dmgrNodeId, dmgrNodeName, beginningPort, endPort)
		
		_app_trace("checkForRangeInDmgrPortList(result = %d)"% result,"exit")
		return result

#--------------------------------------------------------------------------------------------------------
# addServerToPortList
# 
#--------------------------------------------------------------------------------------------------------
def addServerToPortList(nodeName, nodeId, serverName, serverMin, serverMax):
		_app_trace("addServerToPortList(%s, %s, %d, %d )"%(nodeName, serverName, serverMin, serverMax),"entry")
		nodeKey = "PORTLIST.%s" % (nodeName)
		if (dynamicIds.has_key(nodeKey)):
				portList = dynamicIds[nodeKey]
		else:
				# For some reason, this is being called without initialize the node
				# it could be that dynamic ports are not being used
				portList = []
				
		portvalue = "%s,%d,%d" % (serverName, serverMin,serverMax)
		portList.append(portvalue)
		
		dynamicIds[nodeKey] = portList
		
		_app_trace("addServerToPortList()","exit")

#enddef


#--------------------------------------------------------------------------------------------------------
# @JJM
#
# getPortListForNode 
#    Check to see if a port range is in use by a websphere process on the specified node.
# 
#	Parameters:
#		nodeId - the configuration ID of the node
#   nodeName - the name of the node
#--------------------------------------------------------------------------------------------------------
def getPortListForNode(nodeId, nodeName):
		_app_trace("getPortListForNode(%s, %s)"%(nodeId, nodeName),"entry")
		
		result = []
		nodeKey = "PORTLIST.%s" % (nodeName)
		if (dynamicIds.has_key(nodeKey)):
				result = dynamicIds[nodeKey]
		else:
				serverEntries = AdminConfig.list('ServerEntry', nodeId).split(progInfo["line.separator"])
				for serverEntry in serverEntries:
						sName = AdminConfig.showAttribute(serverEntry, "serverName")
				
						
						serverMin = 900000
						serverMax = 0
						endPtStr = AdminConfig.showAttribute(serverEntry, "specialEndpoints")
						specialEndPoints = wsadminToList(endPtStr)
						for specialEndPoint in specialEndPoints:
								if (not isEmpty(specialEndPoint)):
										ePoint =  AdminConfig.showAttribute(specialEndPoint, "endPoint")
										port = int(AdminConfig.showAttribute(ePoint, "port"))
										if (port > serverMax):
												serverMax = port
										if (port != 0) and (port < serverMin):
												serverMin = port
								
										
								#endif
						#endfor
						
						portvalue = "%s,%d,%d" % (sName, serverMin,serverMax)
						result.append(portvalue)
				#endfor
				
				dynamicIds[nodeKey] = result
		#endelse
		
		_app_trace("getPortListForNode(result = %d entries)"% len(result),"exit")
		return result
		
#enddef

