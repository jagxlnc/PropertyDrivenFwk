##########################################################################
# File Name:    SIBusMember.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere SIB Members
#
#               createSIBusMember
#               deleteSIBusMember
#               listSIBusMembers
#               findSIBusMember
#               findMatchingSIBusMembers
#
#wsadmin>AdminTask.help("addSIBusMember")
#'WASX8006I: Detailed help for command: addSIBusMember
#
#Description: Add a member to a bus.
#
#Target object:   None
#
#Arguments:
#  *bus - Name of bus to add member to.
#  node - To specify a server bus member, supply node and server name, but not cluster name or WebSphere MQ server name.
#  server - To specify a server bus member, supply node and server name, but not cluster name or WebSphere MQ server name.
#  cluster - To specify a cluster bus member, supply cluster name, but not node name, server name or WebSphere MQ server name.
#  wmqServer - To specify a WebSphere MQ server bus member, supply a WebSphere MQ server name, but not node name, server name or cluster name.
#  host - This is the override host name of the host to which a connection will be established in orderto communicate with a WebSphere MQ queue manager or a WebSphere MQ queue sharing group, supply with a WebSphere MQ server name, but not node name, server name or cluster name.
#  port - This is the override port number monitored by a WebSphere MQ queue manager or WebSphere MQ queue sharing group listener, which is listening for connections, supply with a WebSphere MQ server name, but not node name, server name or cluster name.
#  channel - This is the override name of the WebSphere MQ server connection channel that will be used top establish a connection to the WebSphere MQ queue manager or WebSphere MQ queue sharing group, supply with a WebSphere MQ server name, but not node name, server name or cluster name.
#  securityAuthAlias - The authentication alias that will be supplied when connecting to the WebSphere MQ server, supply with a WebSphere MQ server name, but not node name, server name or cluster name.
#  transportChain - Overridden value for the WebSphere MQ server bus member "transportChain" attribute.  Refer to the createSIBWMQServer command for a description of this parameter.
#  trustUserIds - Overridden value for the WebSphere MQ server bus member "trustUserIds" attribute.  Refer to the createSIBWMQServer command for a description of this parameter
#  fileStore - Indicates that a file store is to be created. No value is needed.
#  dataStore - Indicates that a data store is to be created. No value is needed.
#  logSize - The size, in megabytes, of the log file.
#  minPermanentStoreSize - The minumum size, in megabytes, of the permanent store file.
#  maxPermanentStoreSize - The maximum size, in megabytes, of the permanent store file.
#  unlimitedPermanentStoreSize - True if the permanent file store size has no limit, false otherwise.
#  permanentStoreDirectory - The name of the store files directory for permanent data.
#  minTemporaryStoreSize - The minumum size, in megabytes, of the temporary store file.
#  maxTemporaryStoreSize - The maximum size, in megabytes, of the temporary store file.
#  unlimited TemporaryStoreSize - True if the temporary file store size has no limit, false otherwise.
#  temporaryStoreDirectory - The name of the store files directory for temporary data.
#  logDirectory - The name of the log files directory.
#  createDefaultDatasource - When adding a server to a bus, set this to true if a default datasource is required. When adding a cluster to a bus, this parameter must not be supplied.
#  datasourceJndiName - The JNDI name of the datasource to be referenced from the datastore created when the member is added to the bus.
#  authAlias - The name of the authentication alias used to authenticate the messaging engine to the data source.
#  createTables - Select this option if the messaging engine creates the database tables for the data store. Otherwise, the database administrator must create the database tables.
#  schemaName - The name of the database schema used to contain the tables for the data store.
#  
#  V7: 
#     enableAssistance - Select this option to enable messaging engine policy assistance. A policy name must also be supplied.
#     policyName - The name of the policy that the messaging engine policy assistance should apply. Messaging engine policy assistance must be enabled.
#     failover - Indicates that the messaging engine created can failover to other servers. This option can be used when messaging engine policy assistance is enabled and the "CUSTOM" policy is selected. 
#     failback - Indicates that the messaging engine created can fail back to a preferred server. This option can be used when messaging engine policy assistance is enabled and the "CUSTOM" policy is selected. 
#     initialHeapSize - The initial JVM heap size in MB of the server, or of each server in the cluster, will be set to this value.
#     maxHeapSize - The maximum JVM heap size in MB of the server, or of each server in the cluster, will be set to this value.
#     preferredServersOnly - Indicates that the messaging engine created can failover to other servers. This option can be used when messaging engine policy assistance is enabled and the "CUSTOM" policy is selected.
#     virtualQueueManagerName - The virtual queue manager name of the SIBus that the WebSphere MQ queue manager sees.
#     preferredServerList - The list of preferred servers for the messaging engine created.  This option can be used when messaging engine policy assistance is enabled and the "CUSTOM" policy is selected.
#
# V8.5:
#      restrictLongDBLock - Select this option to restrict the messaging engine from holding long enduring database locks.
##########################################################################

##########################################################################
#
# FUNCTION:
#    addSIBusMember: Add a member to a Bus
#
# SYNTAX:
#    addSIBusMember bus, (cluster|node, server), dsJNDI
#
# PARAMETERS:
#    bus	-	Name of bus to add member to
#    cluster	-	Specify cluster bus member
#    node	-	Specify server bus member
#    server	-	Specify server bus member
#    memberProps - properties applied to member 
#    dbProps - properties for database message stroe
#    fileProps - properties for file system message store
#
# USAGE NOTES:
#    Adds a member to the bus
#
# RETURNS:
#    String with bus member name if created 
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def createSIBusMember(bus, cluster, node, server, memberProps, dbProps, fileProps, engineCustomProps=None,engineProps = None):
	return addSIBusMember(bus, cluster, node, server, memberProps, dbProps, fileProps, engineCustomProps,engineProps)

def addSIBusMember(bus, cluster, node, server, memberProps, dbProps, fileProps, engineCustomProps = None,engineProps = None):

	global progInfo

	retval = None
	
	memberParmMap = { 'assistanceEnabled': '-enableAssistance', 'policyName': '-policyName', 'failover':'-failover', 'failback':'-failback', 'initialHeapSize':'-initialHeapSize','maxHeapSize':'-maxHeapSize', 'preferredServersOnly':'-preferredServersOnly','preferredServerList':'-preferredServerList'} 
	
	dbParmMap = { 'dataSourceName': '-datasourceJndiName', 'authAlias':'-authAlias', 'createTables':'-createTables', 'schemaName':'-schemaName', 'restrictLongDBLock':'-restrictLongDBLock'}
	fileParmMap = { 'logSize':'-logSize' , 'minPermanentStoreSize':'-minPermanentStoreSize', 'maxPermanentStoreSize':'-maxPermanentStoreSize' ,  'unlimitedPermanentStoreSize':'-unlimitedPermanentStoreSize' , 'permanentStoreDirectory':'-permanentStoreDirectory' , 'minTemporaryStoreSize':'-minTemporaryStoreSize', 'maxTemporaryStoreSize':'-maxTemporaryStoreSize', 'unlimitedTemporaryStoreSize':'-unlimitedTemporaryStoreSize', 'temporaryStoreDirectory':'-temporaryStoreDirectory', 'logDirectory':'-logDirectory' }
	

	try:
		traceStr = "addSIBusMember(%s, %s, %s, %s, %s, %s, %s)" % (bus, cluster, node, server, memberProps, dbProps, fileProps)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		configID = getContainmentPath(cluster, node, server, 1)
		
		if isEmpty(configID):
			raise StandardError("Could not get containment path")
			
		if isEmpty(bus):
			raise StandardError("SIBus not specified")
			
		if (memberProps == None):
				memberProps = java.util.Properties()
		
		if (dbProps == None):
				dbProps = java.util.Properties()
		
		if (fileProps == None):
				fileProps = java.util.Properties()
				
		if (dbProps.size() == 0 and fileProps.size() == 0):
				raise StandardError("No message store properties were supplied")
			
		if isEmpty(AdminConfig.getid(configID)):
			StandardError("No such target as %s to add as a SIBus member to bus %s" % (configID, bus))
			
		#	Make sure bus exists!		
		if not objectExists("SIBus", None, bus):
			StandardError("SIBus %s does not exist" % (bus))
			
		if existsSIBusMember(bus, cluster, node, server):
			StandardError("Bus member %s already exists on SIBus %s" % (configID, bus))
			
		attributes  = ' -bus "%s"' % (bus)
		
		if (memberProps.size() > 0):
		  if (memberProps.get("policyName") == "CUSTOM"):
		    # We need to check for missing preferred servers settings and 
		    # if so, set failover to "false"
		    preferredServersOnly = memberProps.get("preferredServersOnly")
		    preferredServerList = memberProps.get("preferredServerList")
		    failover = memberProps.get("failover")
		    if (isEmpty(preferredServerList) and isEmpty(preferredServersOnly) and isEmpty(failover)):
		      memberProps.put("failover","true")
		    
		  for key in memberProps.keys():
					if (memberParmMap.has_key(key)):
							val = memberProps.get(key)
							attributes = "%s %s %s" % (attributes, memberParmMap[key], val)
		
		if (dbProps.size() > 0):
				attributes += " -dataStore -createDefaultDatasource false "
				
				for key in dbProps.keys():
					if dbParmMap.has_key(key):
						val = dbProps.get(key)
						attributes = "%s %s %s" % (attributes, dbParmMap[key], val)
		else:
				attributes += " -fileStore"
				
				for key in fileProps.keys():
					if fileParmMap.has_key(key):
						val = fileProps.get(key)
						attributes = "%s %s %s" % (attributes, fileParmMap[key], val)

		if isEmpty(cluster):
			attributes += " -node %s -server %s" % (node, server)
		else:
			attributes += " -cluster %s" % (cluster)

		_app_trace("Running command: AdminTask.addSIBusMember('%s')" % (attributes))
		retval = AdminTask.addSIBusMember(attributes)
		_app_trace("addSIBusMember result = [%s]" % (retval))
		if isEmpty(cluster):
				qattributes = '-bus "%s" -node %s -server %s' % (bus, node, server)
		else:
				qattributes = '-bus "%s" -cluster %s' % (bus, cluster)
	

		# See if there are engine properties that need to be set
		engineId = None
		if (engineProps != None and len(engineProps) > 0):
		  engineattrs = []
		  for key in engineProps.keys():
		    if (key == "busName" or key == "messageStoreType"):
		      continue
		    val = engineProps.get(key)
		    engineattrs.append([key, val])
		  
		  if (len(engineattrs) > 0):
		    engineId = findFirstEngine(bus, cluster, server, node)
		    if (modifyObject(engineId,engineattrs)):
		      raise StandardError("Unable to update engine properties: %s" % engineattrs)
		    
	  
		# If there are custom properties for the engine, we need to add those now		
		if (engineCustomProps != None and engineCustomProps.size() > 0):
				engineId = findFirstEngine(bus, cluster, server, node)
				if (engineId != None):
						updateCustomProperties(engineId, "properties", "Property", engineCustomProps)

		_app_trace("Running command: AdminTask.showSIBusMember(%s)" % (qattributes))
		retval = AdminTask.showSIBusMember("%s" % (qattributes))
		_app_trace("showSIBusMember result = [%s]" % (retval))

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()

	except:
		_app_trace("An error was encountered adding the SIB Bus Member", "exception")
		retval = None

	_app_trace("addSIBusMember(%s)" %(retval), "exit")
	return retval
	
##########################################################################
#
# FUNCTION:
#    removeSIBusMember: Delete a SIB Bus Member
#
# SYNTAX:
#    removeSIBusMember bus, cluster|(node, server)
#
# PARAMETERS:
#    bus	-	Name of bus to delete member from
#    cluster	-	Specify cluster bus member
#    node	-	Specify server bus member
#    server	-	Specify server bus member
#
# USAGE NOTES:
#    Deletes a SIB Bus Member from the desired scope.  

# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def deleteSIBusMember(bus, cluster, node, server):
	removeSIBusMember(bus, cluster, node, server)
	
def removeSIBusMember(bus, cluster, node, server):

	global progInfo

	retval = 1

	try:
		traceStr = "removeSIBusMember(%s, %s, %s, %s)" % (bus, cluster, node, server)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		configID = getContainmentPath(cluster, node, server, 1)
		
		#	GetContainmentPath allows Node or Node/Server; however, a member added to a bus
		#	must either be a cluster or a node/server, not node on its own
		if isEmpty(configID):
			raise StandardError("Could not get containment path")
			
		if isEmpty(bus):
			raise StandardError("SIBus name not specified")
			
		if isEmpty(AdminConfig.getid(configID)):
			raise StandardError("No such target as %s to delete SIBus member from bus %s" % (configID, bus))
			
		#	Make sure bus exists!		
		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))
			
		if not existsSIBusMember(bus, cluster, node, server):
			raise StandardError("Bus member %s does not exist on SIBus %s" % (configID, bus))
			
		attributes  = ' -bus "%s"' % (bus)

		if isEmpty(cluster):
			attributes += " -node %s -server %s" % (node, server)
		else:
			attributes += " -cluster %s" % (cluster)

		_app_trace("Running command: AdminTask.removeSIBusMember(%s)" % (attributes))

		AdminTask.removeSIBusMember(attributes)

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()

		retval = 0
	except:
		_app_trace("An error was encountered creating the SIB Bus Member", "exception")
		retval = 1

	_app_trace("removeSIBusMember(%d)" %(retval), "exit")
	return retval

##########################################################################
#
# FUNCTION:
#    listSIBusMembers: List SIB Bus Members
#
# SYNTAX:
#    listSIBusMembers bus displayFlag
#
# PARAMETERS:
#    bus	-	Name of bus to list members from
#    displayFlag- Boolean indicating whether to print list 
#		  (default = 1)
#
# USAGE NOTES:
#    Lists SIB Bus Members
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showSIBusMembers(bus, displayFlag = 1):
	listSIBusMembers(bus, displayFlag)
	
def listSIBusMembers(bus, displayFlag = 1):

	global progInfo
	
	retval = None
	width = 20
	
	try:
		traceStr = "listSIBusMembers(%s, %d)" % (bus, displayFlag)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		if isEmpty(bus):
			raise StandardError("SIBus not specified")
			
		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))
			
		_app_trace("Running command: AdminTask.listSIBusMembers(-bus %s)" % (bus))
		memStr = AdminTask.listSIBusMembers('-bus "%s"' % (bus))

		if isEmpty(memStr):
			retval = []
		else:
			retval = memStr.split(progInfo["line.separator"])

		if displayFlag:
			print "\nSI Bus Members"

			dashes = "-"

			for i in range(width):
				dashes += "-"

			print "%-*s\t%-*s\t%-*s" % (width, "Cluster", width, "Node", width, "Server")
			print "%s\t%s\t%s" % (dashes, dashes, dashes)


			for mem in retval:
				cluster = AdminConfig.showAttribute(mem, "cluster")
				node    = AdminConfig.showAttribute(mem, "node")
				server  = AdminConfig.showAttribute(mem, "server")

				if cluster is None:
					cluster = "***"
				else:
					node = "***"
					server = "***"

				print "%-*s\t%-*s\t%-*s" % (width, cluster, width, node, width, server)

		print "\n\n"

	except:
		_app_trace("An error was encountered listing the SIB Bus Members", "exception")
		retval = None

	_app_trace("listSIBusMembers(%s)" %(retval), "exit")
	return retval


##########################################################################
# findSIBusMember
#
# FUNCTION:
#    Returns the configuration ID of the bus member matching the search criteria
##########################################################################
def findSIBusMember(busName, busId, searchCluster, searchNode, searchServer):

	_app_trace("findSIBusMember(%s %s %s %s %s)" % (busName, busId, searchCluster, searchNode, searchServer))
	retval = None
	
	try:

			if (busId == None):
					busId = AdminConfig.getid("/SIBus:%s/" % busName)
					
			busMembers = AdminConfig.showAttribute(busId,"busMembers")
			if (not isEmpty(busMembers)):
					for busMember in wsadminToList(busMembers):
							if (not isEmpty(busMember)):
									clusterName = AdminConfig.showAttribute(busMember,"cluster")
									nodeName = AdminConfig.showAttribute(busMember,"node")
									serverName = AdminConfig.showAttribute(busMember,"server")
									
									if (not isEmpty(searchCluster)):
											if ((not isEmpty(clusterName)) and clusterName == searchCluster):
													# found a match
													retval = busMember
													break
									else:
											# Compare nodeServer
											if ((not isEmpty(nodeName)) and nodeName == searchNode):
													if ((not isEmpty(serverName)) and serverName == searchServer):
															retval = busMember
															break
											
	except:
			_app_trace("An error was encountered searching for the bus Member","exception")
			raise StandardError("An error was encountered searching for the bus Member")
			

	_app_trace("findSIBusMember(retval = %s" % retval)
	return retval
	

#-------------------------------------------------------------------------------
# findMatchingSIBusMembers 
#
#   Returns a list of bus members that match the supplied patterns for member names.
#   Patterns can be regular expressions or explicit name strings.
#
#   If searching for server members, both node and server parameters must be supplied.
#
# Parameters:
#    busName - Name of the bus to search under
#    busId - optional
#    clusterPattern - a regular expression pattern used to search for cluster names 
#    nodePattern - a regular expression pattern used to search for node/server members
#    serverPattern - a regular expression pattern used to search for node/server members
#
# Returns:
#    A list of [ cluster,node,server,memberId] tuples. Empty strings are supplied
#    for cluster,node, and server attributes that don't apply
#-------------------------------------------------------------------------------
def findMatchingSIBusMembers(busName, busId, clusterPattern, nodePattern, serverPattern):

  _app_trace("findSIBusMember(%s %s %s %s %s)" % (busName, busId, clusterPattern, nodePattern, serverPattern))
  retval = []
  
  import re
  
  try:

      if (busId == None):
          busId = AdminConfig.getid("/SIBus:%s/" % busName)
          
      busMembers = AdminConfig.showAttribute(busId,"busMembers")
      if (not isEmpty(busMembers)):
          for busMember in wsadminToList(busMembers):
              if (not isEmpty(busMember)):
                  clusterName = AdminConfig.showAttribute(busMember,"cluster")
                  if (isEmpty(clusterName)):
                    nodeName = AdminConfig.showAttribute(busMember,"node")
                    serverName = AdminConfig.showAttribute(busMember,"server")
                  else:
                    nodeName = ""
                    serverName = ""
                  
                  if (not isEmpty(clusterPattern) and (not isEmpty(clusterName))):
                    if (clusterPattern.find("*") >= 0):
                      # Regular expression pattern match
                      if (re.match(clusterPattern,clusterName)):
                        # this is a match
                        retval.append([clusterName,"","",busMember])
                    elif (clusterPattern == clusterName):
                      # This is a match 
                      retval.append([clusterName,"","",busMember])
                      
                  else:
                      # Compare nodeServer
                      if ((not isEmpty(nodePattern)) and (not isEmpty(nodeName))):
                        nodeMatch = 0
                        if (nodePattern.find("*") >= 0):
                          # Regualar expression
                          if (re.match(nodePattern,nodeName)):
                            nodeMatch = 1
                        elif (nodePattern == nodeName):
                          nodeMatch = 1
                        
                        if (nodeMatch and (not isEmpty(serverPattern)) and (not isEmpty(serverName))):
                          if (serverPattern.find("*") >= 0):
                            if (re.match(serverPattern,serverName)):
                              retval.append(["",nodeName,serverName,busMember])
                          elif (serverPattern == serverName):
                            retval.append(["",nodeName,serverName,busMember])
                  #endelse
          #endfor
      #endif
  except:
      _app_trace("An error was encountered searching for the bus members","exception")
      raise StandardError("An error was encountered searching for the bus members")

  _app_trace("findMatchingSIBusMembers(retval = %s" % retval)
  return retval

#enddef findMatchingSIBusMembers