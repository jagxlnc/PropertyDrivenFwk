##########################################################################################
# ProcessWASEnvironmentVariables.py
#
# This module contains the functions that process the input properties for WebSphere 
# variable definitions.  The properties should have already been loaded into the global
# configInfo dictionary prior to calling the processWASEnvironmentVariables() function.
#
# Primary function: 
#    processWASEnvironmentVariables()
#
# Related modules:
#		 WebSphereVariable.py - Contains functions used to create/modify variables
#    Utils.py - Utility methods
#
# Property syntax:
#    app.wasenv.<index>.cluster = <Cluster name if at cluster scope, also supports @ITERATE keyword >
#    app.wasenv.<index>.node = <Node name if at node scope or server scope, also supports @ITERATE keyword>
#    app.wasenv.<index>.server = <Server name if at server scope, also supports @ITERATE keyword>
#    # |<variable-definition> is optional:
#    app.wasenv.<index>.<VARIABLE-NAME> = <variable-value>|<variable-definition>
#    ...
#    ...
#    app.wasenv.count = <count>
#
# Deletion Property Syntax:
#
#    del.wasenv.<index>.cluster = <Cluster name if at cluster scope, also supports @ITERATE keyword >
#    del.wasenv.<index>.node = <Node name if at node scope or server scope, also supports @ITERATE keyword>
#    del.wasenv.<index>.server = <Server name if at server scope, also supports @ITERATE keyword>
#    del.wasenv.<index>.<VARIABLE-NAME> = placeholder
# 
#     OR
#    del.wasenv.<index>.cluster = <Cluster name if at cluster scope, also supports @ITERATE keyword >
#    del.wasenv.<index>.node = <Node name if at node scope or server scope, also supports @ITERATE keyword>
#    del.wasenv.<index>.server = <Server name if at server scope, also supports @ITERATE keyword>
#    del.wasenv.<index>.name = <VARIABLE-NAME>
#    ...
#    ...
#    del.wasenv.count = <count>
#
# Property examples:
#
# # Example of variable at cluster scope 
# app.wasenv.1.cluster = SampleCluster
# app.wasenv.1.node    = 
# app.wasenv.1.server  = 
# app.wasenv.1.env.prop.MYVARIABLE = Value|Description
#
# # Example of a variable at cluster scope
# app.wasenv.2.cluster = 
# app.wasenv.2.node    = ConfigurationScriptingNode2
# app.wasenv.2.server  = MemberFive
# app.wasenv.2.env.prop.SERVER_VAR_1 = My Name is ConfigurationScriptingNode2 MemberFive
#
# # Example usage of @ITERATE flag to define variable for all cluster members
# app.wasenv.3.cluster = SampleCluster
# app.wasenv.3.node    = 
# app.wasenv.3.server  = @ITERATE
# app.wasenv.3.env.prop.DYNAMIC_CLUSTER_SERVER_VAR1 = My Name is @{DYNAMIC#CURRENT_CLUSTER#name}  @{DYNAMIC#CURRENT_NODE#name} @{DYNAMIC#CURRENT_SERVER#name} | A dynamic value for server @{DYNAMIC#CURRENT_SERVER#name}
#
# # Exampe usage of @ITERATE to define variable at Node scope for all nodes with cluster members
# app.wasenv.4.cluster = SampleCluster
# app.wasenv.4.node    = @ITERATE
# app.wasenv.4.server  = 
# app.wasenv.4.env.prop.DYNAMIC_CLUSTER_NODE_VAR1 = My Name is @{DYNAMIC#CURRENT_CLUSTER#name}  @{DYNAMIC#CURRENT_NODE#name} | A dynamic value for server @{DYNAMIC#CURRENT_NODE#name}
#
# # Example usage of @ITERATE to define variable at all nodes
# app.wasenv.5.cluster = 
# app.wasenv.5.node    = @ITERATE
# app.wasenv.5.server  = 
# app.wasenv.5.env.prop.DYNAMIC_NODE_VAR1 = My Name is  @{DYNAMIC#CURRENT_NODE#name} | A dynamic value for node @{DYNAMIC#CURRENT_NODE#name}
#
# # Count field is required
# app.wasenv.count = 5
#
# # Deleting a variable at a specified scope
# del.wasenv.2.cluster = 
# del.wasenv.2.node    =  ConfigurationNode1
# del.wasenv.2.server  = 
# del.wasenv.2.env.prop.MY_INSTALL_DRIVE = some-val
#
# del.wasenv.3.cluster = 
# del.wasenv.3.node    =  ConfigurationNode2
# del.wasenv.3.server  = 
# del.wasenv.3.name = MY_INSTALL_DRIVE
#
# # Deleting variables at multiple scopes
# del.wasenv.4.cluster = 
# del.wasenv.4.node    =  @ITERATE
# del.wasenv.4.server  = 
# del.wasenv.4.env.prop.SF_INSTALL_DRIVE = {placeholder}
#
##########################################################################################


#---------------------------------------------------------------------------------------------------------
# VariableScopeValues
#
# This class is used to represent scope attributes of a variable definition. See the buildScopeList 
# function for details on how this is used.
#---------------------------------------------------------------------------------------------------------
class VariableScopeValues:

		cluster = ""
		node = ""
		server = ""
		
		clusterId = ""
		nodeId = ""
		serverId = ""
		
		def __init__(self, c,n,s):
				self.cluster = c
				self.node = n
				self.server = s
		
		def setIds(self, cid, nid, sid):
				self.clusterId = cid
				self.nodeId = nid
				self.serverId = sid

				

#------------------------------------------------------------------------------------------------------
# buildScopeList
# Evaluate the cluster, ndoe, and server settings to see if they are special @ITERATE flag that indicates
# that this variable needs to be defined at multiple scopes.
#
# After evaluating the settings (and processing any @ITERATE logic), this function will return the
# list of VariableScopeValues object that the variable should be declared at.
#------------------------------------------------------------------------------------------------------
def buildScopeList(clusterSetting, nodeSetting, serverSetting):

	global progInfo

	result = []
	_app_trace("buildScopeList(%s,%s,%s)" % (clusterSetting, nodeSetting, serverSetting),"entry")
	try:
		
		if (clusterSetting == None): clusterSetting = ""
		if (nodeSetting == None): nodeSetting = ""
		if (serverSetting == None): serverSetting = ""
		
		iterateNodes = 0
		iterateServers = 0
		iterateClusters = 0
		
		if (nodeSetting.find("@ITERATE") >= 0):
				iterateNodes = 1
				nodeSetting = ""
		
		if (serverSetting.find("@ITERATE") >= 0):
				iterateServers = 1
				serverSetting = ""
		
		if (clusterSetting.find("@ITERATE") >= 0):
				iterateClusters = 1
				clusterSetting = ""
				
		if (iterateClusters):
				# Create cluster level variable for all clusters
				clusterList = AdminConfig.list("ServerCluster").split(progInfo["line.separator"])
				for clusterId in clusterList:
						if not isEmpty(clusterId):
								clusterName = AdminConfig.showAttribute(clusterId,"name")
								
								varscope = VariableScopeValues(clusterName,"","")
								varscope.setIds(clusterId, "","")
								result.append(varscope)
								
		elif (not iterateNodes and not iterateServers):
				# Simple case, create one scope object
				varscope = VariableScopeValues(clusterSetting, nodeSetting, serverSetting)
				
				clusterId = nodeId = serverId = ""
				
				if (not isEmpty(clusterSetting)):
						clusterId = AdminConfig.getid("/ServerCluster:%s/"% clusterSetting)
						if (isEmpty(clusterId)):
								raise StandardError("Unable to get ID for ServerCluster %s" % clusterSetting)
				
				if (not isEmpty(nodeSetting)):
						nodeId = AdminConfig.getid("/Node:%s/"%(nodeSetting))
						if (isEmpty(nodeId)):
								raise StandardError("Unable to get ID for Node %s" % nodeSetting)
				
						if (not isEmpty(serverSetting)):
								serverId = AdminConfig.getid("/Node:%s/Server:%s/"% (nodeSetting,serverSetting))
								if (isEmpty(serverId)):
										raise StandardError("Unable to get ID for Server %s %s" % (nodeSetting,serverSetting))
				
				varscope.setIds(clusterId, nodeId, serverId)
				
				result.append(varscope)
		elif (iterateServers and not isEmpty(clusterSetting)):
				# The variable should be created at server scope on all cluster members
				clusterId = AdminConfig.getid("/ServerCluster:%s/"% clusterSetting)
				
				clusterMembers = AdminConfig.list("ClusterMember", clusterId).split(progInfo["line.separator"])
				for clusterMember in clusterMembers:
						if (isEmpty(clusterMember)):
								continue
						
						mName = AdminConfig.showAttribute(clusterMember, "memberName")
						mNode = AdminConfig.showAttribute(clusterMember, "nodeName")
						
						nodeId = AdminConfig.getid("/Node:%s/" % mNode)
						if (isEmpty(nodeId)):
								raise StandardError("Unable to get ID for Node %s" % mNode)
						
						serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (mNode,mName))
						if (isEmpty(serverId)):
										raise StandardError("Unable to get ID for Server %s %s" % (mNode,mName))
						
						varscope = VariableScopeValues("",mNode,mName)
						varscope.setIds(clusterId, nodeId, serverId)
						result.append(varscope)
		elif (iterateNodes and not isEmpty(clusterSetting)):
				# The variable should be created at Node scope for each node in the cluster
				clusterId = AdminConfig.getid("/ServerCluster:%s/"% clusterSetting)
				nodeList = []
				clusterMembers = AdminConfig.list("ClusterMember", clusterId).split(progInfo["line.separator"])
				for clusterMember in clusterMembers:
						if (isEmpty(clusterMember)):
								continue
						
						
						mNode = AdminConfig.showAttribute(clusterMember, "nodeName")
						
						if not mNode in nodeList:
								nodeList.append(mNode)
						
								nodeId = AdminConfig.getid("/Node:%s/" % mNode)
								serverId = ""
						
								varscope = VariableScopeValues("",mNode,"")
								varscope.setIds(clusterId, nodeId, serverId)
								result.append(varscope)
		elif (iterateServers):
				serverList = AdminConfig.list("Server").split(progInfo["line.separator"])
				for serverId in serverList:
						if not isEmpty(serverId):
								serverName = AdminConfig.showAttribute(serverId, "name")
							
								# determine the node
								nodeId = getNodeForServer(serverId)
								nodeName = AdminConfig.showAttribute(nodeId,"name")
								
								varscope = VariableScopeValues("",nodeName, serverName)
								varscope.setIds("", nodeId, serverId)
								result.append(varscope)
								
		elif (iterateNodes):
				nodeList = AdminConfig.list("Node").split(progInfo["line.separator"])
				for nodeId in nodeList:
						if not isEmpty(nodeId):
								nodeName = AdminConfig.showAttribute(nodeId,"name")
								varscope = VariableScopeValues("",nodeName,"")
								varscope.setIds("",nodeId,"")
								result.append(varscope)
				
	except:
			_app_trace("Error processing variable scope settings: %s %s %s" % (clusterSetting, nodeSetting, serverSetting),"exception")
			_app_message("Error processing variable scope settings: %s %s %s" % (clusterSetting, nodeSetting, serverSetting))
			exit()
		
	_app_trace("buildScopeList(%d items)" % len(result),"exit")
	return result
	
	
#--------------------------------------------------------------------------------------------------------------------
# processWASEnvironmentVariableDeletions
#
# Loops through the configuration properties that have been previously loaded into variableDictionary global dictionary and
# processes the configuration data to create or update WebSphere Variables.
#-------------------------------------------------------------------------------------------------------------------
def processWASEnvironmentVariableDeletions(variableDictionary):

  try:
      if variableDictionary.has_key("del.wasenv.count"):
    
        # WAS_LIB_DIR and WAS_LIBS_DIR removed so they can't be deleted
        skipVars = ["WAS_CELL_NAME", "USER_INSTALL_ROOT", "WAS_INSTALL_ROOT", "WAS_SERVER_NAME", "JAVA_HOME", "CONNECTOR_INSTALL_ROOT", "WAS_TEMP_DIR", "WAS_PROPS_DIR", "WAS_ETC_DIR", "WAS_INSTALL_LIBRARY"]
      
        
        # Create WAS Environment variables for each node and/or server
        delCount = int(variableDictionary["del.wasenv.count"])
        
        if (delCount > 0):
          _app_message("Processing WebSphere Variable Deletions....")
                  
          for eidx in range(1, delCount + 1):
          
            cluster = variableDictionary.get("del.wasenv.%d.cluster" % (eidx),"")
            node  = variableDictionary.get("del.wasenv.%d.node" % (eidx),"")
            server  = variableDictionary.get("del.wasenv.%d.server" % (eidx),"")
            
            # Support alternative syntax
            delName = variableDictionary.get("del.wasenv.%d.name" % (eidx),"")
        
            # get Env variable details
            subProps = getPropList(variableDictionary, "del.wasenv.%d.env" % (eidx))
            
            # If alternative syntax is used, add it to the collection of props to replace
            if (not isEmpty(delName)):
              subProps[delName] = delName
              
            if (len(subProps) > 0):
              for key in subProps.keys():
                  envname = key
              
          
                  # Let's skip modification of key environment variables
                  if (envname in skipVars) :
                      _app_message("Ignore list variable: of WebSphere Variable %s at scope %s %s" % (envname, node, server))
                      continue
                      
                  scopeList = buildScopeList(cluster, node, server)
                  for scope in scopeList:
                      # Build a nice formatted string for reporting scope
                      scopeString = "Cell"
                      if (not isEmpty(scope.cluster)):
                        scopeString = "Cluster %s" % scope.cluster
                      elif (not isEmpty(scope.server)):
                        scopeString = "Server %s %s" % (scope.node,scope.server)
                      elif (not isEmpty(scope.node)):
                        scopeString = "Node %s" % scope.node
                        
                      variableExisted = deleteWebSphereVariable(envname,scope.cluster,scope.node,scope.server)
                      if (variableExisted):
                        _app_message("Variable %s has been deleted at scope %s" % (envname,scopeString))
                      else:
                        _app_message("Variable %s did not exist at scope %s - no deletion was necessary" % (envname,scopeString))
                        
                      
                  # end for each scope item
                  
              # end for each key
              
          # end for each index

  except:
    _app_trace("Unexpected error in processWASEnvironmentVariableDeletions","exception")
    exit()
    
  
# enddef processWASEnvironmentVariableDeletions

#--------------------------------------------------------------------------------------------------------------------
# processVariableSettings
#
# Process the settings for a specific variable at a specific scope
#
# PARAMETERS:
#		cluster - Name of cluster (scope setting)
#   node - Name of node (scope setting)
#   server - Name of server (scope setting)
#   envname - Name of environment variable
#   envval - Value of environment variable
#   envdesc - Descriptoin of environemtn variable
#--------------------------------------------------------------------------------------------------------------------		
def processVariableSettings(cluster,node,server,envname,envval,envdesc,allowUpdate=1,warnOnCreate=0):

    _app_trace("processVariableSettings(%s,%s,%s,%s,%s,%s)" % (cluster,node,server,envname,envval,envdesc),"entry")
    
    try:
          # Build a nice formatted string for reporting scope
          scopeString = "Cell"
          if (not isEmpty(cluster)):
            scopeString = "Cluster %s" % cluster
          elif (not isEmpty(server)):
            scopeString = "Server %s %s" % (node,server)
          elif (not isEmpty(node)):
            scopeString = "Node %s" % node
            
          # See if the variable exists
          existingId = checkForExistingWebSphereVariable(envname, cluster, node, server)
          if (not isEmpty(existingId)):
              # See if we need to do upate
              currentValue = AdminConfig.showAttribute(existingId,"value")
              if (currentValue != envval):
                  
                  if (not allowUpdate and not isEmpty(currentValue)):
                    # This variable is defined with the setting that prevents overwriting of non-empty values
                    _app_message("Variable %s at scope %s will keep it's existing value of %s" % (envname, scopeString, currentValue))
                  else:
                    # Do the update processing
                    currentDescription = AdminConfig.showAttribute(existingId,"description")
                    if (currentDescription == None):
                        currentDescription = ""
                
                    # attrs = '[value [%s]]' % envval
                    if (envval.startswith("'") or envval.startswith('"')):
                      envvaljs = java.lang.String(envval)
                    else:
                      envvaljs = java.lang.String("'%s'" % envval)
                      
                    if (currentDescription != envdesc):
                        attrs = [ ["value" , envvaljs], ["description", envdesc]]
                    else:                   
                      attrs = [ ["value" , envvaljs] ]
                      
                    if (modifyObject(existingId, attrs)):
                        _app_message("Error modifying existing Variable %s at scope %s" % (envname, scopeString))
                        exit()
                    else:
                        _app_message("Updated existing Variable %s at scope %s" % (envname, scopeString))
                        
                  #end else do update
                  
              else:
                  _app_message("Value did not change for Variable %s at scope %s" % (envname, scopeString))
          
          else:
              if isEmpty(createWebSphereVariable(envname, envval, envdesc, cluster, node, server)):
                _app_message("Failed to create WebSphere Variable %s at scope %s" % (envname, scopeString))
                exit()
              else:
                if (warnOnCreate):
                  _app_message("WARNING: A default value has been created for environment variable %s at scope %s Value = %s" % (envname,scopeString, envval))
                else:
                  _app_message("Created WebSphere Variable %s at scope %s" % (envname, scopeString))

    except:
        _app_trace("Error processing variable settings","exception")
        _app_message("Error processing variable settings")
        exit()
    
    _app_trace("processVariableSettings()","exit")
    return
#--------------------------------------------------------------------------------------------------------------------
# processWASEnvironmentVariables
#
# Loops through the configuration properties that have been previously loaded into configInfo global dictionary and
# processes the configuration data to create or update WebSphere Variables.
#-------------------------------------------------------------------------------------------------------------------
def processWASEnvironmentVariables():

  global configInfo
  
  # Process deletions first
  processWASEnvironmentVariableDeletions(configInfo)
  
  
  if not configInfo.has_key("app.wasenv.count"):
    _app_message("Skipping Building WAS Environment Variables...")
    return

  # WAS_LIB_DIR and WAS_LIBS_DIR removed so they can be updated 
  skipVars = ["WAS_CELL_NAME", "USER_INSTALL_ROOT", "WAS_INSTALL_ROOT", "WAS_SERVER_NAME", "JAVA_HOME", "CONNECTOR_INSTALL_ROOT", "WAS_TEMP_DIR", "WAS_PROPS_DIR", "WAS_ETC_DIR", "WAS_INSTALL_LIBRARY"]

  _app_message("Building WAS Environment Variables...")
  # Create WAS Environment variables for each node and/or server
  for eidx in range(1, int(configInfo["app.wasenv.count"]) + 1):
  
    cluster = configInfo.get("app.wasenv.%d.cluster" % (eidx),"")
    node  = configInfo.get("app.wasenv.%d.node" % (eidx),"")
    server  = configInfo.get("app.wasenv.%d.server" % (eidx),"")
    allowUpdateSetting = configInfo.get("app.wasenv.%d.allowUpdate" % (eidx),"true")
    defaultSetting = configInfo.get("app.wasenv.%d.default" % (eidx), "false")
    
    # Support the alternative syntax
    altName = configInfo.get("app.wasenv.%d.name" % (eidx),"")
    altValue = configInfo.get("app.wasenv.%d.value" % (eidx),"")
    altDescription = configInfo.get("app.wasenv.%d.description" % (eidx),"")

    warnOnCreate = 0
    allowUpdate = 1
    if (allowUpdateSetting.lower() == "false" or allowUpdateSetting.lower() == "no"):
      allowUpdate = 0
      
    if (defaultSetting.lower() == "true" or defaultSetting.lower() == "yes"):
      allowUpdate = 0
      warnOnCreate = 1

    # get Env variable details
    subProps = getPropList(configInfo, "app.wasenv.%d.env" % (eidx))
    
    # Support the alternative name/value/description property syntax
    if (not isEmpty(altName)):
      subProps[altName] = "%s|%s" % (altValue, altDescription)
    
    if (subProps.size() > 0):
      for key in subProps.keys():
          envname = key
      
  
          # Let's skip modification of key environment variables
          if (envname in skipVars) :
              _app_message("Ignore list variable: of WebSphere Variable %s at scope %s %s" % (envname, node, server))
              continue
              
          scopeList = buildScopeList(cluster, node, server)
          for scope in scopeList:
              
              if (not isEmpty(scope.clusterId)):
                  setDynamicId("CURRENT_CLUSTER",scope.clusterId)
              else:
                  setDynamicId("CURRENT_CLUSTER", "")
              
              if (not isEmpty(scope.nodeId)):
                  setDynamicId("CURRENT_NODE",scope.nodeId)
              else:
                  setDynamicId("CURRENT_NODE","")
              
              if (not isEmpty(scope.serverId)):
                  setDynamicId("CURRENT_SERVER", scope.serverId)
              else:
                  setDynamicId("CURRENT_SERVER","")
                  
              if (isEmpty(scope.clusterId) and isEmpty(scope.nodeId) and isEmpty(scope.serverId)):
                  # Set server to dmgr and node to be dmgr node
                  serverId = AdminConfig.getid("/Server:dmgr/")
                  nodeId = getNodeForServer(serverId)
                  setDynamicId("CURRENT_NODE", nodeId)
                  setDynamicId("CURRENT_SERVER", serverId)
              
              propertyValue = subProps[key]
              propertyValue = substituteDynamicValues("env", propertyValue)
              
              valDes = propertyValue.split("|")
              envval = ""
              envdesc = ""
              if (len(valDes) == 1):
                  envval = propertyValue
              elif (len(valDes) == 2):
                  envval = valDes[0]
                  envdesc = valDes[1].strip()
                  
              
              envval = envval.strip()
              
              processVariableSettings(scope.cluster,scope.node,scope.server,envname,envval,envdesc,allowUpdate,warnOnCreate)
              
          # end for each scope item
          
      # end for each key
      
  # end for each index
  
# enddef processWASEnvironmentVariables
