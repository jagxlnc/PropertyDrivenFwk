#--------------------------------------------------------------------------------
# ProcessOnDemandRouter.py
#
# This module contains the functions that parse properties that define the
# distinct components of an On Demand Router server. The input properties may
# be part of a standalone server, a cluster member or a cluster template. 
#
# Requires: OnDemandRouter.py, WorkClass.py, Utils.py, common.py, updateEnvironment.py, 
#           ProcessWorkClass.py
# 
#
# Use the dumpConfig.py script with the -odr option to produce examples of 
# the configuration properties.
#
# Primary entry point: processOnDemandRouter
#--------------------------------------------------------------------------------


#-------------------------------------------------------------------------------
# Utility method that will parse properties specifying localErrorPagePolicy.errorMappings list
#
# Returns tupple containing list of errorMappins dictionaries, and dictionary with statusCode=errorMappingSettingsDict
#-------------------------------------------------------------------------------
def parseErrorMappingsList(odrConfig,prefix):
  listResult = []
  mapResult = {}
  try:
    if (odrConfig != None):
      emCount = int(odrConfig.get("%s.errorMappings.count" % prefix,0))
      if (emCount > 0):
        for idx in range(1,emCount+1):
          mappingsDict = toDictionary(getPropList(odrConfig, "%s.errorMappings.%d" % (prefix,idx)))
          statusCode = mappingsDict.get("statusCode")
          if (not isEmpty(statusCode)):
            listResult.append(mappingsDict)
            mapResult[statusCode] = mappingsDict
               
  except:
    _app_exception("Unknown exception in parseErrorMappingsList")
  
  return (listResult,mapResult)

#-------------------------------------------------------------------------------
# processOnDemandRouterProxySettings
#   Processes the ProxyServer and ProxySettings configuration input for the
#   specified On Demand Router.  Note that ODRs support a subset of the
#   ProxySettings
#   
# Parameters
#    odrConfig - dictionary with ODR properties
#    prefix - key prefix (e.g. app.appserver.3.odr )
#    odrId - Configuration id of ODR (usually Server configuration item)
#    odrName - name of the ODR server
#    existingProps - a dictionary containing partial settings of server - will be None
#                    if server is being created by the scripts. Settings will be
#                    loaded into this dictionary as required
#-------------------------------------------------------------------------------
def processOnDemandRouterProxySettings(odrConfig,prefix,odrId,odrName,existingProps=None):
  _app_entry("processOnDemandRouterProxySettings(odrConfig,%s,%s,%s,existingProps)" , prefix,odrId,odrName)
  retval = None
  try:
    if (checkForPrefix(odrConfig,"%s.proxyServer"%prefix)):
      if (existingProps != None):
        getProxyServerProperties(odrId,odrProperties=existingProps)
        
      
      baseProps = getPropListDifferences(odrConfig,"%s.proxyServer"%prefix,existingProps,"proxyServer")
      httpProxyServerSettingsProps = getPropListDifferences(odrConfig,"%s.proxyServer.httpProxyServerSettings" %prefix,
                                                            existingProps,"proxyServer.httpProxyServerSettings")
      stateManagementProps = getPropListDifferences(odrConfig,"%s.proxyServer.stateManagement" %prefix,
                                                    existingProps,"proxyServer.stateManagement")
      
      customProps = getPropListDifferences(odrConfig,"%s.proxyServer.properties"%prefix,
                                           existingProps,"proxyServer.properties")
      
      if (len(baseProps)>0 or len(httpProxyServerSettingsProps) > 0 or 
          len(stateManagementProps) > 0 or len(customProps) > 0):
        
        updateODRProxyServerSettings(odrId,baseProps,httpProxyServerSettingsProps,stateManagementProps,customProps)
        #print "Base: %s\nHttpProxy: %s\nStateManagement: %s\ncustom:%s" % (baseProps,httpProxyServerSettingsProps,stateManagementProps,customProps)
        _app_message("Updated ProxyServer settings for server %s" % odrName)
      else:
        _app_message("No need to update ProxyServer settings for server %s" % odrName)
      
    
    if (checkForPrefix(odrConfig,"%s.proxySettings"%prefix)):
      if (existingProps != None):
        getProxySettingsProperties(odrId,odrProperties=existingProps)
        
      baseProps = getPropListDifferences(odrConfig,"%s.proxySettings"%prefix,existingProps,"proxySettings")
      customProps = getPropListDifferences(odrConfig,"%s.proxySettings.properties"%prefix,
                                         existingProps,"proxySettings.properties")
      errorPagePolicyProps = getPropListDifferences(odrConfig,"%s.proxySettings.errorPagePolicy" % prefix,
                                               existingProps, "proxySettings.errorPagePolicy")
      localErrorPagePolicyProps = getPropListDifferences(odrConfig,"%s.proxySettings.localErrorPagePolicy" % prefix,
                                                    existingProps,"proxySettings.localErrorPagePolicy")
      pluginConfigPolicyProps = getPropListDifferences(odrConfig,"%s.proxySettings.pluginConfigPolicy" % prefix,
                                                  existingProps,"proxySettings.pluginConfigPolicy")
                                                             
      inputRewritingRules = getDictionaryList(odrConfig,"%s.proxySettings.rewritingPolicy.rewritingRules"%prefix)
      existingRewritingRules = getDictionaryList(existingProps,"proxySettings.rewritingPolicy.rewritingRules")
      if (inputRewritingRules != existingRewritingRules and not isSubSetDictionaryLists(inputRewritingRules,existingRewritingRules,"fromURLPattern")):
        
        inputRewritingRules = combineDictionaryLists(inputRewritingRules,existingRewritingRules,"fromURLPattern")
      else:
        inputRewritingRules = []
      
      
      inputLocalErrorMappings,inputLocalErrorMappingsDict = parseErrorMappingsList(odrConfig,"%s.proxySettings.localErrorPagePolicy" % prefix)
      existingLocalErrorMappings,existingLocalErrorMappingsDict = parseErrorMappingsList(existingProps,"proxySettings.localErrorPagePolicy")
      if (inputLocalErrorMappings == existingLocalErrorMappings or isSubSetDictionaryLists(inputLocalErrorMappings,existingLocalErrorMappings,"statusCode")) :
        # No updates necessary
        inputLocalErrorMappings = []
      elif (len(inputLocalErrorMappings) > 0):
        inputLocalErrorMessages = combineDictionaryLists(inputLocalErrorMappings,existingLocalErrorMappings,"statusCode")
        
      # Commented out due to issues with float attribute
      #inputStaticCachePolicy = getDictionaryList(odrConfig,"%s.proxySettings.staticCachePolicy.staticCacheRules"%prefix,includeCustomProperties=1)
      #existingStaticCachePolicy = getDictionaryList(existingProps,"proxySettings.staticCachePolicy.staticCacheRules",includeCustomProperties=1)
      #
      #if (inputStaticCachePolicy == existingStaticCachePolicy or isSubSetDictionaryLists(inputStaticCachePolicy,existingStaticCachePolicy,"uriGroup","virtualHostName")):
      #  # No updates necessary
      #  inputStaticCachePolicy = []
      #else:
      #  inputStaticCachePolicy=combineDictionaryLists(inputStaticCachePolicy,existingStaticCachePolicy,"uriGroup","virtualHostName")
      inputStaticCachePolicy = []
        
      
      if (noEmptyDictionaries(baseProps,customProps,errorPagePolicyProps,localErrorPagePolicyProps,inputLocalErrorMappings,pluginConfigPolicyProps,
                        inputRewritingRules,inputStaticCachePolicy)):
         _app_message("ProxySettings for server %s need to be updated" % odrName)
         updateODRProxySettings(odrId, baseProps,customProps,errorPagePolicyProps,localErrorPagePolicyProps,inputLocalErrorMappings,pluginConfigPolicyProps,
                        inputRewritingRules,inputStaticCachePolicy)
      else:
        _app_message("No need to update ProxySettings for server %s" % odrName)
      
  except:
    _app_exception("Unexpected problem in processOnDemandRouterProxySettings()")
  
  _app_exit("processOnDemandRouterProxySettings(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# processOnDemandRouterTransportChains
#
# Parameters
#    odrConfig - dictionary with ODR properties
#    prefix - key prefix (e.g. app.appserver.3.odr )
#    odrId - Configuration id of ODR (usually Server configuration item)
#    odrName - name of the ODR server
#    existingProps - a dictionary containing partial settings of server - will be None
#                    if server is being created by the scripts. Settings will be
#                    loaded into this dictionary as required

#-------------------------------------------------------------------------------
def processOnDemandRouterTransportChains(odrConfig,prefix,odrId,odrName,existingProps=None): 
  _app_entry("processOnDemandRouterTransportChains(odrConfig,%s,%s,%s,existingProps)" , prefix,odrId,odrName)
  retval = None
  try:
    setupApplicationServerTransportChains(odrConfig,odrId, prefix, odrName, existingProps)
  except:
    _app_exception("Unexpected problem in processOnDemandRouterTransportChains()")
  
  _app_exit("processOnDemandRouterTransportChains(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# processOnDemandRouterRules
#
# Parameters
#    odrConfig - dictionary with ODR properties
#    prefix - key prefix (e.g. app.appserver.3.odr )
#    odrId - Configuration id of ODR (usually Server configuration item)
#    odrName - name of the ODR server
#    existingProps - a dictionary containing partial settings of server - will be None
#                    if server is being created by the scripts. Settings will be
#                    loaded into this dictionary as required
#-------------------------------------------------------------------------------
def processOnDemandRouterRules(odrConfig,prefix,odrId,odrName,existingProps=None):
  _app_entry("processOnDemandRouterRules(odrConfig,%s,%s,%s,existingProps)" , prefix,odrId,odrName)
  retval = None
  try:
    rulesCount = int(odrConfig.get("%s.rules.count"% prefix,0))
    if (rulesCount > 0):
      odrNode = getNodeNameForServer(odrId)
      for idx in range(1,rulesCount+1):
        rulesName = odrConfig.get("%s.rules.%d.name" % (prefix,idx))
        if (not isEmpty(rulesName)):
          rulesId = getOnDemandRouterRulesId(odrNode,odrName,rulesName)
          if (isEmpty(rulesId)):
            # Need to create Rules
            # In theory, this shouldn't be the case
            rulesId = createOnDemandRouterRules(odrId,rulesName)
            _app_message("Rules %s has been created for ODR  %s" % (rulesName,odrName))
            
          #else:
          #  _app_message("Rules %s is defined for ODR  %s" % (rulesName,odrName))
            
          rulesProps = getODRRulesProperties(rulesId)
          
          baseProps = getPropListDifferences(odrConfig,"%s.rules.%d" % (prefix,idx), rulesProps, "odr.rules")
          
          existingMatchRules = getDictionaryList(rulesProps,"odr.rules.matchRules")
          inputMatchRules = getDictionaryList(odrConfig,"%s.rules.%d.matchRules" % (prefix,idx))
          appendMatchRules = odrConfig.get("%s.rules.%d.appendMatchRules" % (prefix,idx),"false").lower()  in ["yes","true"]
          
          
          if (inputMatchRules == existingMatchRules): 
            # No updates necessary
            inputMatchRules = None
          elif (appendMatchRules and isSubSetDictionaryLists(inputMatchRules,existingMatchRules,"priority")):
            # No updates necessary
            inputMatchRules = None
          
          if (noEmptyDictionaries(baseProps,inputMatchRules)):
            updateOnDemandRouterRules(rulesId,baseProps,inputMatchRules,appendMatchRules)
            _app_message("Updated Rules %s for ODR  %s" % (rulesName,odrName))
          else:
            _app_message("No udpates required for Rules %s in ODR  %s" % (rulesName,odrName))
          
  except:
    _app_exception("Unexpected problem in processOnDemandRouterRules()")
  
  _app_exit("processOnDemandRouterRules(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# processOnDemandRouterWorkClasses
#    This method processes the input properties that define the Generic Routing
#    and Generic Service work classes used by the On Demand Router
#
# Parameters
#    odrConfig - dictionary with ODR properties
#    prefix - key prefix (e.g. app.appserver.3.odr )
#    odrId - Configuration id of ODR (usually Server configuration item)
#    odrName - name of the ODR server
#    existingProps - a dictionary containing partial settings of server - will be None
#                    if server is being created by the scripts. Settings will be
#                    loaded into this dictionary as required
#-------------------------------------------------------------------------------
def processOnDemandRouterWorkClasses(odrConfig,prefix,odrId,odrName,existingProps=None):
  _app_entry("processOnDemandRouterWorkClasses(odrConfig,%s,%s,%s,existingProps)" , prefix,odrId,odrName)
  retval = None
  try:
    nodeName = getNodeNameForServer(odrId)
    grCount = int(odrConfig.get("%s.genericRouting.count"%prefix,0))
    if (grCount > 0):
      for idx in range(1,grCount+1):
        workClassName = odrConfig.get("%s.genericRouting.%d.name" % (prefix,idx))
        if (isEmpty(workClassName)):
          continue 
        workClassId = findODRRoutingWorkClass(nodeName,odrName,workClassName)
        if (isEmpty(workClassId)):
          _app_message("Routing work class %s not defined for ODR %s/%s" % (workClassName,nodeName,odrName))
          wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules =  getRoutingUpdateProps(odrConfig,"%s.genericRouting.%d" % (prefix,idx),workClassId)
          # Get optional parameters
          actionType = odrConfig.get("%s.genericRouting.%d.actionType" % (prefix,idx),None)
          action = odrConfig.get("%s.genericRouting.%d.action" % (prefix,idx),None)
          vhost = odrConfig.get("%s.genericRouting.%d.vhost" % (prefix,idx),None)
          workClassId = createODRRoutingWorkClass(wcName=workClassName,odrName=odrName,odrNode=nodeName,wcType="HTTPWORKCLASS",
                                    actionType=actionType,action=action,vhost=vhost,wcProps=wcProps,matchRuleList=inputMatchRuleList,moduleList=inputModuleList)
          _app_message("Created Generic Routing work class %s for ODR %s/%s" % (workClassName,nodeName,odrName))
        else:
          #_app_message("Routing work class %s is defined for ODR %s/%s" % (workClassName,nodeName,odrName))
          
          # See what needs updating
          wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules =  getRoutingUpdateProps(odrConfig,"%s.genericRouting.%d" % (prefix,idx),workClassId)
          if (noEmptyDictionaries(wcProps,inputModuleList,inputMatchRuleList)):
            #_app_message("Routing work class %s needs to be updated for ODR %s/%s" % (workClassName,nodeName,odrName))
            modifyApplicationRoutingWorkClass(wcId=workClassId,wcProps=wcProps,matchRuleList=inputMatchRuleList,moduleList=inputModuleList,
                                          appendModules=appendWorkClassModules,appendRules=appendMatchRules)
            _app_message("Routing work class %s has been updated for ODR %s/%s" % (workClassName,nodeName,odrName))
          else:
            _app_message("Routing work class %s does not need to be updated for ODR %s/%s" % (workClassName,nodeName,odrName))
            
    gsCount = int(odrConfig.get("%s.genericService.count"%prefix,0))
    if (gsCount > 0):
      for idx in range(1,gsCount+1):
        workClassName = odrConfig.get("%s.genericService.%d.name" % (prefix,idx))
        if (isEmpty(workClassName)):
          continue 
        workClassId = findODRServiceWorkClass(nodeName,odrName,workClassName)
        if (isEmpty(workClassId)):
          
          wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules = getServiceUpdateProps(odrConfig,"%s.genericService.%d" % (prefix,idx))
          transactionClass = odrConfig.get("%s.genericService.%d.transactionClass" % (prefix,idx))
          wcType = odrConfig.get("%s.genericService.%d.workclassType" % (prefix,idx),"HTTP")
          vhost = odrConfig.get("%s.genericService.%d.vhost" % (prefix,idx))
          members = odrConfig.get("%s.genericService.%d.members" % (prefix,idx))
          createODRServiceWorkClass(wcName=workClassName,odrName=odrName,odrNode=nodeName,transactionClass=transactionClass,wcType=wcType,
                                    vhost=vhost,members=members,wcProps=wcProps,moduleList=inputModuleList,matchRuleList=inputMatchRuleList)
          _app_message("Service work class %s has been created for ODR %s/%s" % (workClassName,nodeName,odrName))
        else:
          _app_message("Service work class %s is defined for ODR %s/%s" % (workClassName,nodeName,odrName))
          wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules = getServiceUpdateProps(odrConfig,"%s.genericService.%d" % (prefix,idx),workClassId)
          if (noEmptyDictionaries(wcProps,inputModuleList,inputMatchRuleList)):
             modifyApplicationServiceWorkClass(wcId=workClassId,wcProps=wcProps,moduleList=inputModuleList,matchRuleList=inputMatchRuleList,
                                          appendModules=appendWorkClassModules,appendRules=appendMatchRules)
             _app_message("Service work class %s has been updated for ODR %s/%s" % (workClassName,nodeName,odrName))
          else:
             _app_message("No updates required for Service work class %s in ODR %s/%s" % (workClassName,nodeName,odrName))
            
      
  except:
    _app_exception("Unexpected problem in processOnDemandRouterWorkClasses()")
  
  _app_exit("processOnDemandRouterWorkClasses(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# processOnDemandRouter
#
# Parameters
#    odrConfig - dictionary with ODR properties
#    prefix - key prefix (e.g. app.appserver.3.odr )
#    odrId - Configuration id of ODR (usually Server configuration item)
#    odrName - name of the ODR server
#    existingProps - a dictionary containing partial settings of server - will be None
#                    if server is being created by the scripts. Settings will be
#                    loaded into this dictionary as required
#-------------------------------------------------------------------------------
def processOnDemandRouter(odrConfig,prefix,odrId,odrName,existingProps=None):
  _app_entry("processOnDemandRouter(odrConfig,%s,%s,%s,existingProps)" , prefix,odrId,odrName)
  retval = None
  try:
    
    processOnDemandRouterProxySettings(odrConfig,prefix,odrId,odrName,existingProps)
    
    processOnDemandRouterTransportChains(odrConfig,prefix,odrId,odrName,existingProps)
    
    processOnDemandRouterRules(odrConfig,prefix,odrId,odrName,existingProps)
    
    processOnDemandRouterWorkClasses(odrConfig,prefix,odrId,odrName,existingProps)
    
  except:
    _app_exception("Unexpected problem in processOnDemandRouter()")
  
  _app_exit("processOnDemandRouter(retval=%s)" % retval)
  return retval
