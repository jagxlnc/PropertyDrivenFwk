######################################################################
# Mail.py
#
# Provides functions for finding, creating, and updating MailProvider
# and MailSession configuration items
######################################################################


#--------------------------------------------------------------------
# findMailProviderAtScope
#
# Returns the configuration ID of the specified mail provider if it exists
#
# Parameters:
#   providerName - Name of provider
#   pCluster - Cluster to search under
#   pNode - Node to search under
#   pServer - Server to search under
#--------------------------------------------------------------------
def findMailProviderAtScope(providerName,pCluster,pNode,pServer):
  retval = None
  try:
  
    _app_trace("findMailProviderAtScope(%s,%s,%s,%s)" % (providerName,pCluster, pNode, pServer),"entry")
  
    global progInfo
    global configInfo
    
    pScope = ""

    if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
        pScope = "cell"
        cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
        for cell in cells:
            mailProviderId=AdminConfig.getid("/Cell:%s/MailProvider:%s/" % (AdminConfig.showAttribute(cell,"name"),providerName))
            retval = mailProviderId
            break
    else:
      if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer):
          pScope = "cluster"
   
          mailProviderId=AdminConfig.getid("/ServerCluster:%s/MailProvider:%s/" % (pCluster,providerName))
          retval = mailProviderId
          
      else:
        if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
            pScope = "node"
            
            mailProviderId=AdminConfig.getid("/Node:%s/MailProvider:%s/" % (pNode,providerName))
            retval = mailProviderId
                
        else:
            if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
                pScope = "server"
                
            
                mailProviderId=AdminConfig.getid("/Node:%s/Server:%s/MailProvider:%s/" % (pNode,pServer,providerName))
                retval = mailProviderId

  except:
      _app_exception("Error searching for mail provider %s at scope %s%s:%s"%(providerName,pCluster, pNode, pServer))
      
  _app_trace("findMailProviderAtScope(retval=%s)" % (retval),"exit")
  return retval

#--------------------------------------------------------------------------
# createMailProvider
#
# Create a new mail provider
#
# Parameters:
#   providerName - Name of mail provider to create
#   pCluster,pNode,pServer - parameters used to determine scope
#   providerProperties - dictionary with base attributes of MailProvider
#   resourceProperties - dictionary with name=type|required|value|descr
#   protocolPropList - A list of dictionaries for the ProtocolProvider items
#
# Returns
#   Configuration ID of new MailProvider
#--------------------------------------------------------------------------
def createMailProvider(providerName,pCluster,pNode,pServer,providerProperties,resourceProperties,*protocolPropList):
  _app_trace("createMailProvider(%s,%s,%s,%s,%s,%s,%s)" % (providerName,pCluster,pNode,pServer,providerProperties,resourceProperties,protocolPropList),"entry")
  retval = None
  try:
    attrs = propsToAttrList(providerProperties)
    attrs.append(["name",providerName])
    
    scopeId = getScopeId(pCluster,pNode,pServer)
    if isEmpty(scopeId):
      raise StandardError("Invalid scope for Mail Provider")
    
    _app_trace('About to call AdminConfig.create("MailProvider",%s,%s)' % (scopeId,attrs))
    retval = AdminConfig.create("MailProvider",scopeId,attrs)
    
    if (resourceProperties != None):
      updateJ2EEResourcePropertySet(retval, resourceProperties,"propertySet")
      
    if protocolPropList != None:
      for protocolProps in protocolPropList:
        attrs = propsToAttrList(protocolProps)
        AdminConfig.create("ProtocolProvider",retval,attrs)
     
  except:
    _app_exception("Unexpected error trying to create MailProvider %s" % providerName)
    
  _app_trace("createMailProvider(retval = %s)" % retval)
  return retval

#--------------------------------------------------------------------------
# updateMailProvider
#
# Update an existingnew mail provider
#
# Parameters:
#   providerName - Name of mail provider to create
#   providerProperties - dictionary with base attributes of MailProvider
#   resourceProperties - dictionary with name=type|required|value|descr
#   protocolPropList - A list of dictionaries for the ProtocolProvider items
#
# Returns
#   Configuration ID of MailProvider

#--------------------------------------------------------------------------
def updateMailProvider(providerId,providerProperties,resourceProperties,*protocolPropList):
  _app_trace("updateMailProvider(%s,%s,%s,%s)" % (providerId,providerProperties,resourceProperties,protocolPropList),"entry")
  retval = providerId
  try:
    
    if (providerProperties != None and len(providerProperties) > 0):
      # Call utility method that properly handles list attributes 
      modifyObjectProperties(providerId,providerProperties,"MailProvider")
    
    if (resourceProperties != None and len(resourceProperties) > 0):
      updateJ2EEResourcePropertySet(providerId, resourceProperties,"propertySet")
      
    
      
    if protocolPropList != None and len(protocolPropList) > 0:
      protocolDict = {}
      for protocolProps in protocolPropList:
        protocolDict[protocolProps.get("protocol")] = protocolProps
      
      ppIdList = AdminConfig.list("ProtocolProvider",providerId).splitlines()
      for ppId in ppIdList:
        if isEmpty(ppId):
          continue
        
        protocol = AdminConfig.showAttribute(ppId,"protocol")
        newSettings = protocolDict.get(protocol)
        if (newSettings != None):
          modifyObjectProperties(ppId,newSettings,"ProtocolProvider")
          del protocolDict[protocol]
      
      #Now see if there were any protocolproviders that need to be defined
      for protocol in protocolDict.keys():
        protocolProps = protocolDict[protocol]
        attrs = propsToAttrList(protocolProps)
        _app_trace('About to call AdminConfig.create("ProtocolProvider",%s,%s)' % (providerId,attrs))
        AdminConfig.create("ProtocolProvider",providerId,attrs)

  except:
    _app_exception("Unexpected error trying to update MailProvider %s" % providerName)
    
  _app_trace("updateMailProvider(retval = %s)" % retval)
  return retval


#-------------------------------------------------------------------
# createMailSession
#
# Creates a new MailSession
#
# Parameters:
#   providerId - The MailProvider that is the parent of the new MailSession
#   sessionName - name of the new MailSession
#   sessionProperties - dictionary with base properties of session
#   storeProtocol - name of the STORE protocol to use. Must match protocol
#                   attribute of one of the MailProviders defined ProtocolProviders
#   transportProtocol - name of the STORE protocol to use. Must match protocol
#                   attribute of one of the MailProviders defined ProtocolProviders
#   resourceProperties - dictionary with name=type|required|value|descr
# 
# Returns    
#   Configuration ID of new MailSession
#-------------------------------------------------------------------
def createMailSession(providerId,sessionName,sessionProperties,storeProtocol,transportProtocol,resourceProperties = None):
  _app_trace("createMailSession(%s,%s,%s,%s,%s)" % (providerId,sessionName, passwordSafeDictString(sessionProperties),storeProtocol,transportProtocol),"entry")
  retval = None
  try:
     attrs = propsToAttrList(sessionProperties)
     attrs.append(["name",sessionName])
     
     # Look up the IDs for Protocol Providers so we can set reference attributes
     protocolProviders = findProtocolProviders(providerId,storeProtocol,transportProtocol)
     attrs.append(["mailStoreProtocol",protocolProviders[0] ] )
     attrs.append(["mailTransportProtocol",protocolProviders[1] ])
     
     _app_trace('About to call AdminConfig.create("MailSession",%s,attrs)' % providerId)
     retval = AdminConfig.create("MailSession",providerId,attrs)
     
     if (resourceProperties != None):
      updateJ2EEResourcePropertySet(retval, resourceProperties,"propertySet")
     
  except: 
    _app_exception("Unexpected error in createMailSession")
  
  _app_trace("createMailSession(retval=%s)"% retval,"exit")
  return retval

#-------------------------------------------------------------------
# updateMailSession
#
# Updates an existing MailSession
#
# Parameters:
#   providerId - The MailProvider that is the parent of the MailSession
#   mailSessionId - configuration ID of the existing MailSession
#   sessionProperties - dictionary with base properties of session
#   storeProtocol - (optional) name of the STORE protocol to use. Must match protocol
#                   attribute of one of the MailProviders defined ProtocolProviders
#   transportProtocol - (optional) name of the STORE protocol to use. Must match protocol
#                   attribute of one of the MailProviders defined ProtocolProviders
#   resourceProperties - (optional) dictionary with name=type|required|value|descr
# 
# Returns    
#   Configuration ID of MailSession
#-------------------------------------------------------------------
def updateMailSession(providerId,mailSessionId,sessionProperties,storeProtocol=None,transportProtocol=None,resourceProperties=None):
  _app_trace("updateMailSession(%s,%s,%s,%s,%s,%s)" % (providerId,mailSessionId, passwordSafeDictString(sessionProperties),storeProtocol,transportProtocol,resourceProperties),"entry")
  
  try:
    attrs = propsToAttrList(sessionProperties)
    
     
    # Look up the IDs for Protocol Providers so we can set reference attributes
    if (storeProtocol != None or transportProtocol != None):
      if (isEmpty(providerId)):
        providerId = AdminConfig.showAttribute(mailSessionId,provider)
        
      protocolProviders = findProtocolProviders(providerId,storeProtocol,transportProtocol)
      if not isEmpty(storeProtocol):
        attrs.append(["mailStoreProtocol",protocolProviders[0] ] )
      if not isEmpty(transportProtocol):
        attrs.append(["mailTransportProtocol",protocolProviders[1] ])
     
    _app_trace('About to call AdminConfig.modify(%s,attrs)' % mailSessionId)
    AdminConfig.modify(mailSessionId,attrs)
    
    if (resourceProperties != None):
      updateJ2EEResourcePropertySet(mailSessionId, resourceProperties,"propertySet")
     
  except: 
    _app_exception("Unexpected error in updateMailSession")
  
  _app_trace("createMailSession(retval=%s)"% mailSessionId,"exit")
  return mailSessionId


#-----------------------------------------------
# findProtocolProviders
#
#    Finds configuration ID of Store and Transport ProtocolProvider
# 
# Returns tuple: (storeProtocolProviderId,transportProtocolProviderId)
#-----------------------------------------------
def findProtocolProviders(mailProviderId,storeProtocol,transportProtocol):
  _app_trace("findProtocolProviders(%s,%s,%s)" % (mailProviderId,storeProtocol,transportProtocol),"entry")
  retval = None
  storeProtocolProviderId = ''
  transportProtocolProviderId = ''
  try:
    providers = AdminConfig.list("ProtocolProvider",mailProviderId).splitlines()
    for providerId in providers:
      if (isEmpty(providerId)):
        continue
      
      protocol = AdminConfig.showAttribute(providerId,"protocol")
      
      if protocol == storeProtocol:
        storeProtocolProviderId = providerId
      elif protocol == transportProtocol:
        transportProtocolProviderId = providerId
      
      if (storeProtocolProviderId != '' and transportProtocolProviderId != ''):
        break
    
    retval = (storeProtocolProviderId,transportProtocolProviderId)
  except:
    _app_exception("Unexpected error in findProtocolProviders")
  
  _app_trace("findProtocolProviders(retval = %s)" % (str(retval)),"exit")
  
  return retval
  
  

#----------------------------------------------------------------------
# findMailSession
#   Return the configuration ID for the Mail session with the specified
#   name or jndiName
#
#----------------------------------------------------------------------
def findMailSession(providerId,sessionName=None,jndiName=None):
  _app_trace("findMailSession(%s,%s,%s)" % (providerId,sessionName,jndiName),"entry")
  retval = None
  try:
    sessions = AdminConfig.list("MailSession",providerId).splitlines()
    for sessionId in sessions:
      if (isEmpty(sessionId)):
        continue
      if not isEmpty(sessionName):
        tempName = AdminConfig.showAttribute(sessionId,"name")
        if (tempName == sessionName):
          retval = sessionId
          break
      elif not isEmpty(jndiName):
        tempName = AdminConfig.showAttribute(sessionId,"jndiName")
        if (tempName == jndiName):
          retval = sessionId
          break
  except:
    _app_exception("Error in findMailSession(%s,%s,%s)" % (providerId,sessionName,jndiName))
  
  _app_trace("findMailSession(retval=%s)" % (retval),"exit")
  return retval

#--------------------------------------------------------------------  
# getMailProviderProperties
#
# Returns a dictionary with the following properties
#   mailprovider.prop.XXXX = value
#   mailprovider.resourceProperties.XXXX = value
#   protocolProvider.[protocol] = {dictionary with protocolProvider.prop.XXX = value}
#--------------------------------------------------------------------  
def getMailProviderProperties(mailProviderId):
  _app_trace("getMailProviderProperties(%s)" % mailProviderId,"entry")
  retval = {}
  try:
    collectSimpleProperties(retval, "mailprovider.prop",mailProviderId, optionalSkipList=["name"])
    collectResourceProperties(retval,mailProviderId,"propertySet","mailprovider")
    
    pplist = AdminConfig.list("ProtocolProvider",mailProviderId).splitlines()
    ppidx = 0
    for ppId in pplist:
      if (isEmpty(ppId)):
        continue
      ppidx += 1
      tempProps = {}
      collectSimpleProperties(tempProps,"protocolProvider.prop", ppId)
      retval["protocolProvider.%s" % (tempProps.get("protocolProvider.prop.protocol"))] = tempProps
    
  except:
    _app_exception("Unexpected error in getMailProviderProperties")
    
  _app_trace("getMailProviderProperties()","exit") 
  return retval

#---------------------------------------------------------------------
# getMailSessionProperties
#
#    Returns a dictionary with the properties of the mailsession
#         mailsession.prop.XXXX - base properties
#         mailsession.prop.mailTransportProtocol.prop
#         mailsession.prop.mailStoreProtocol.prop
#         mailsession.resourceProperties.prop.XXXX - resource properties
#
#---------------------------------------------------------------------
def getMailSessionProperties(mailSessionId):
  _app_trace("getMailSessionProperties(%s)" % mailSessionId,"entry")
  retval = {}
  idProps = {}
  
  try:
    collectSimpleProperties(retval, "mailsession.prop",mailSessionId, optionalSkipList=[],idProps=idProps)
    
    mailTransportProtocol = idProps.get("mailsession.prop.mailTransportProtocol",None)
    mailStoreProtocol = idProps.get("mailsession.prop.mailStoreProtocol",None)
    
    if (not isEmpty(mailTransportProtocol)):
      collectSimpleProperties(retval,"mailsession.mailTransportProtocol.prop",mailTransportProtocol)
    
    if (not isEmpty(mailStoreProtocol)):
      collectSimpleProperties(retval,"mailsession.mailStoreProtocol.prop",mailStoreProtocol)
    
    collectResourceProperties(retval,mailSessionId,"propertySet","mailsession")
  except:
    _app_exception("Unexpected error in getMailSessionProperties")
  
  _app_trace("getMailSessionProperties()","exit")
  return retval
  