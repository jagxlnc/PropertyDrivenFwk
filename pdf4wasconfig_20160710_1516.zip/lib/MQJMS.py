#--------------------------------------------------------------------------
#
#  This library script contains methods for MQ JMS Provider resoturces
#   createMQJMSProvider
#
# Note that the AdminTask commands were added in v7. Earlier configuration
# relied on WCCM type manipulation. 
#
# Functions implemented in this module are:
# findMQJMSProvider
# findMQResourceAdapter
# getMQResourceAdapterProperties
# updateMQResourceAdapter
# findMQConnectionFactory
# updateMQConnectionFactory
# findMQConnectionFactory
# getMQConnectionFactoryProperties
# findMQResource
# getMQQueueProperties
# createMQQueue
# updateMQQueue
# getMQTopicProperties
# createMQTopic
# updateMQTopic
# findMQActivationSpec
# getMQJMSActivateSpecProperties
# createMQActivationSpec
# modifyMQActivationSpec
#
# WASX8007I: Detailed help for command group: WMQAdminCommands
# Description: A group of commands that help configure WebSphere MQ messaging resources.
# Commands:
# createWMQActivationSpec - Creates a WMQ Activation Specification at the scope provided to the command.
# createWMQConnectionFactory - Creates a WMQ Connection Factory at the scope provided to the command.
# createWMQQueue - Creates a WMQ Queue at the scope provided to the command.
# createWMQTopic - Creates a WMQ Topic at the scope provided to the command.
# deleteWMQActivationSpec - Deletes the WMQ Activation Specification object provided to the command.
# deleteWMQConnectionFactory - Deletes the WMQ Connection Factory object provided to the command.
# deleteWMQQueue - Deletes the WMQ Queue object provided to the command.
# deleteWMQTopic - Deletes the WMQ Topic object provided to the command.
# listWMQActivationSpecs - Lists the WMQ Activation Specification defined at the scope provided to the command.
# listWMQConnectionFactories - Lists the WMQ Connection Factories defined at the scope provided to the command.
# listWMQQueues - Lists the WMQ Queues defined at the scope provided to the command.
# listWMQTopics - Lists the WMQ Topics defined at the scope provided to the command.
# manageWMQ - Provides the ability to manage the settings associated with the WMQ resource adapter installed at a particular scope.
# migrateWMQMLP - Migrates a WebSphere MQ message listener port definition to an activation specification definition.
# modifyWMQActivationSpec - Modifies the properties of the WMQ Activation Specification provided to the command.
# modifyWMQConnectionFactory - Modifies the properties of the WMQ Connection Factory provided to the command.
# modifyWMQQueue - Modifies the properties of the WMQ Queue provided to the command.
# modifyWMQTopic - Modifies the properties of the WMQ Topic provided to the command.
# showWMQActivationSpec - Shows the attributes of the WMQ Activation Specification provided to the command.
# showWMQConnectionFactory - Shows the attributes of the WMQ Connection Factory provided to the command.
# showWMQQueue - Shows the attributes of the WMQ Queue provided to the command.
# showWMQTopic - Shows the attributes of the WMQ Topic provided to the command.
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# findMQResourceAdapter
#
# Finds the configuration ID of the J2CResourceAdapter related to MQ JMS provider
# at the specified scope object. (V7 onwards)
#
# Parameters:
#    scope - the scope object (Node,Cell,Server, or Cluster)
#    raName (optional) - The name of the RA to look for
#
# Returns:
#    The configuration ID of the resource adapter
#--------------------------------------------------------------------------
def findMQResourceAdapter(scope,raName="WebSphere MQ Resource Adapter"):
  _app_trace("findMQResourceAdapter(%s,%s)" % (scope,raName),"entry")
  retval = None
  try:
    pCluster,pNode,pServer,dc,app,appdep = getScope(scope)
    retval = getResourceAdapterId(pCluster,pNode,pServer,raName)
  except:
    _app_trace("Unexpected error in findMQResourceAdapter","exception")
    raise StandardError("Unexpected error in findMQResourceAdapter")
    
  _app_trace("findMQResourceAdapter(%s,%s)" % (scope,raName),"exit")
  return retval

#-------------------------------------------------------------------------------
# getMQResourceAdapterProperties
#
# Returns the J2EE Resource Properties of the resource adapter using the 
# mqjms.provider.resourceAdapter.propertySet.resourceProperties.prop key prefix
# 
# Parameters:
#   resourceAdapterId - The ID to gather properties from
#
# Returns: A Properties collection with the key/value pairs
#-------------------------------------------------------------------------------
def getMQResourceAdapterProperties(resourceAdapterId):
  _app_trace("getMQResourceAdapterProperties(%s)" % resourceAdapterId,"entry")
  retval = None
  try:
    retval = java.util.Properties()
    collectResourceProperties(retval,resourceAdapterId,"propertySet", "mqjms.provider.resourceAdapter.propertySet")
    
  except:
    _app_trace("Unexpected error in getMQResourceAdapterProperties","exception")
    
  _app_trace("getMQResourceAdapterProperties()","exit")
  return retval

#---------------------------------------------------------------------------------
# updateMQResourceAdapter
# 
# Updates the J2EE Resource Properties of the adapter
#
# Parameters:
#    resourceAdapterId - the id of the J2CResourceAdapter to update
#    resourceProps - a properties collection in the form key = type|required|val|descr
#---------------------------------------------------------------------------------
def updateMQResourceAdapter(resourceAdapterId,resourceProps):
  _app_trace("updateMQResourceAdapter(%s,%s)" %(resourceAdapterId,resourceProps),"entry")
  retval = None
  try:
    if (resourceProps != None and len(resourceProps) > 0):
      propertySetId = AdminConfig.showAttribute(resourceAdapterId,"propertySet")
      if (isEmpty(propertySetId)):
        _app_trace('About to call AdminConfig.create("J2EEResourcePropertySet",%s,[],"propertySet")' % resourceAdapterId)
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",resourceAdapterId,[],"propertySet")
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Error updating J2EE Resource Properties for MQ JMS ResourceAdapter: %s" % errmsg)\

    retval = resourceAdapterId
  except:
    _app_trace("Unexpected error in updateMQResourceAdapter","exception")
    raise StandardError("Unexpected error in updateMQResourceAdapter")
  
  _app_trace("updateMQResourceAdapter(retval = %s)" % retval, "exit")
  return retval

#-------------------------------------------------------------------------------
# findMQJMSProvider
#
# Finds the provider under the specified scope object. Will create one if necessary (shouldn't be)
#
# Parameters:
#   scope - A scope object (Node,Server,Cluster, or Cell)
#   providerName (optional)
#
#-------------------------------------------------------------------------------
def findMQJMSProvider(scope, providerName="WebSphere MQ JMS Provider", providerAttrs=[]):

  global progInfo
  retval = None
  
  try:
    traceStr = "createMQJMSProvider(%s, %s, %s)" % (scope, providerName, providerAttrs)
    _app_trace(traceStr, "entry")
    
    c,n,s,dc,app,appdep = getScope(scope)
    _app_trace( "c=%s n=%s s=%s" % (c,n,s))
    
    if (isEmpty(c) and isEmpty(n) and isEmpty(s)):
      providerEntries = AdminConfig.getid("/Cell:%s/JMSProvider:/" % AdminConfig.showAttribute(scope,"name"))
    elif (not isEmpty(c)):
      providerEntries = AdminConfig.getid("/ServerCluster:%s/JMSProvider:/" % c )
    elif (not isEmpty(s) and not isEmpty(n)):
      providerEntries = AdminConfig.getid("/Node:%s/Server:%s/JMSProvider:/" % (n,s))
    elif (not isEmpty(n) and isEmpty(s)):
      providerEntries = AdminConfig.getid("/Node:%s/JMSProvider:/" % (n))
    else:
      providerEntries = ""
    
    
    provider="None"
    _app_trace("Finding provider %s" % providerName)
    if (providerEntries != ""):
      providerEntryList=providerEntries.split(progInfo["line.separator"])
      
      for providerEntry in providerEntryList:
        if (isEmpty(providerEntry)): continue
        c1,n1,s1,dc1,app1,appdep1 = getScope(providerEntry)
        if (c1 != c or n1 != n or s1 != s):  
          continue
        if (providerName == AdminConfig.showAttribute(providerEntry,"name")):
          provider=providerEntry
          break

    #------------------------------------------------------
    # If the JMS provider does not exist, create a new one
    #------------------------------------------------------
    if (provider == "None"):
      _app_trace("Provider %s Not found so creating new one" % providerName)
      _app_trace("Running command:AdminConfig.create('JMSProvider', %s, %s)" % (scope,providerAttrs))
      
      provider=AdminConfig.create("JMSProvider", scope, providerAttrs)
    else:
      _app_trace("Provider %s already exists" % providerName)
    
    retval=provider

  except:
      _app_trace("An error was encountered creating the JMSProvider %s" % providerName, "exception")

  _app_trace("createJMSProvider(%s)" %(retval), "exit")
  return retval

#-----------------------------------------------------------------------
# updateMQProvider
#
# Updates the base and resource properties of a JMSProvider
#
# Parameters:
#   provider - the ID of the JMSProvider
#   baseProps - the base properties to update
#   resourceProps - a properties collection in the form key = type|required|val|descr
#
# Returns:
#   The configuration ID of the provider, raises error otherwise
#-----------------------------------------------------------------------
def updateMQProvider(provider, baseProps, resourceProps):
  _app_trace("updateMQProvider(%s,%s,%s)" % (provider, baseProps, resourceProps),"entry")
  retval = None
  try:
    
    if (baseProps != None and len(baseProps) > 0):
      providerattrs = []
      for key in baseProps.keys() :
        val = baseProps[key]
        if (val != None and val != '' and val != "None") :
          providerattrs.append([key, val])
      if (len (providerattrs) > 0):
        if modifyObject(provider, providerattrs):
          _app_trace("Failed to modify base attributes for MQ JMSProvider %s" % provider)
          raise StandardError("Failed to modify base attributes for MQ JMSProvider %s" % provider)

    if (resourceProps != None and len(resourceProps) > 0):
      propertySetId = AdminConfig.showAttribute(provider,"propertySet")
      if (isEmpty(propertySetId)):
        _app_trace('About to call AdminConfig.create("J2EEResourcePropertySet",%s,[],"propertySet")' % provider)
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",provider,[],"propertySet")
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Error updating J2EE Resource Properties for MQ JMSProvider: %s" % errmsg)\
    
    retval = provider
    
  except:
    _app_trace("Unexpected exception in updateMQProvider","exception")
    raise StandardError("Unexpected exception in updateMQProvider")
  
  _app_trace("updateMQProvider(retval = %s)" % (retval),"exit")
  return retval

#----------------------------------------------------------------------------------------
# getMQProviderProperties
#
# Returns the base and resource properties in a Properties collection with the 
#    mqjms.provider.prop
#    mqjms.provider.propertySet.resourceProperties.prop 
# key prefixes.
#
# Parameters:
#     provider - the provider to inspect
# 
# Returns:
#     A Properties object with the keys
#----------------------------------------------------------------------------------------
def getMQProviderProperties(provider):
  _app_trace("getMQProviderProperties(%s)" %provider, "entry")
  retval = java.util.Properties()
  try:
    collectSimpleProperties(retval,"mqjms.provider.prop", provider, ["name"])
    collectResourceProperties(retval,provider,"propertySet", "mqjms.provider.propertySet")
  except:
    _app_trace("Unexpected error in getMQProviderProperties","exception")
    raise StandardError("Unexpected error in getMQProviderProperties")

  _app_trace("getMQProviderProperties()" , "exit")
  return retval


#----------------------------------------------------------------------------------------------------
# createMQConnectionFactory
#
# Parameters:
#   provider - Configuration ID of provider
#   cfname - The name of the factory to create
#   cftype - The type of factory to create (MQConnectionFactory,MQQueueConnectionFactory,MQTopicConnectionFactory)
#   subProps - base connection factory props 
#   connPoolProps - connection pool props
#   connPoolCustomProps - connection pool custom properties
#   mappingModuleProps - properties for MappingModule
#   sessionPoolProps  - properties for SessionPool
#   resourceProps - J2EE resource props for factory
#
# Returns Configuration id of created factory, throws error otherwise
#
#----------------------------------------------------------------------------------------------------
def createMQConnectionFactory(provider, cfname, cftype, subProps, connPoolProps, connPoolCustomProps, mappingModuleProps, sessionPoolProps, resourceProps):
  retval = None
  
  try:
    traceStr = "createMQConnectionFactory(%s, %s, %s, %s, %s, %s, %s, %s, %s)" % (provider, cfname, cftype, subProps, connPoolProps, connPoolCustomProps, mappingModuleProps, sessionPoolProps, resourceProps)
    _app_trace(traceStr, "entry")

    cfattrs = [["name",cfname]]
    for key in subProps.keys() :
      val = subProps[key]
      if (val != None and val != '' and val != "None") :
        cfattrs.append([key, val])
        
    cfid = AdminConfig.create(cftype,provider,cfattrs)
    
    if modifyObject(cfid, cfattrs):
      _app_trace("Failed to modify %s attributes for %s" % (cftype, cfname))
      raise StandardError("Failed to modify %s attributes for %s" % (cftype, cfname))
    
    if (len(connPoolProps) > 0 or len(connPoolCustomProps) > 0):
      poolattrs = []
      for key in connPoolProps.keys() :
        val = connPoolProps[key]
        if (val != None and val != '' and val != "None") :
          poolattrs.append([key, val])
            
      connectionPoolId = AdminConfig.showAttribute(cfid,"connectionPool")
      if (connectionPoolId == None or connectionPoolId == ""):
        connectionPoolId = AdminConfig.create('ConnectionPool', cfid, poolattrs, 'connectionPool') 
      else:
        if (len(poolattrs) > 0):
          if (modifyObject(connectionPoolId, poolattrs)):
            raise StandardError("Failed to modify connection pool for %s %s"  % (cftype, cfname))
      
      if (len(connPoolCustomProps) > 0):
        errMsg = updateCustomProperties(connectionPoolId, "properties", "Property", connPoolCustomProps)
        if (not isEmpty(errMsg)):
          raise StandardError("Unable to update connection pool custom properties for %s %s: %s" % (cftype, cfname, errMsg))

    if (sessionPoolProps != None and len(sessionPoolProps) > 0):
      poolattrs = []
      for key in sessionPoolProps.keys() :
        val = sessionPoolProps[key]
        if (val != None and val != '' and val != "None") :
          poolattrs.append([key, val])
            
      sessionPoolId = AdminConfig.showAttribute(cfid,"sessionPool")
      if (sessionPoolId == None or sessionPoolId == ""):
        sessionPoolId = AdminConfig.create('ConnectionPool', cfid, poolattrs, 'sessionPool') 
      else:
        if (modifyObject(sessionPoolId, poolattrs)):
          raise StandardError("Failed to modify session pool for %s %s"  % (cftype, cfname))
          
    if (mappingModuleProps != None and len(mappingModuleProps) > 0):      
      mappingattrs = []
      for key in mappingModuleProps.keys() :
        val = mappingModuleProps[key]
        if (val != None and val != '' and val != "None") :
          mappingattrs.append([key,val])
    
      mappingModuleId = AdminConfig.showAttribute(cfid, "mapping")
      if (mappingModuleId == None or mappingModuleId == ""):
        mappingModuleId = AdminConfig.create('MappingModule',cfid, mappingattrs, 'mapping')
      else:
        if (modifyObject(mappingModuleId,mappingattrs)):
          raise StandardError("Failed to modify mapping module for %s %s" % (cftype))

    if (resourceProps != None and len(resourceProps) > 0):
      propertySetId = AdminConfig.showAttribute(cfid,"propertySet")
      if (isEmpty(propertySetId)):
        _app_trace('About to call AdminConfig.create("J2EEResourcePropertySet",%s,[],"propertySet")' % cfid)
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",cfid,[],"propertySet")
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Error updating J2EE Resource Properties for connection factory: %s" % errmsg)

        

    retval = cfid
  except:
    _app_trace("An error was encountered creating the %s %s" % (cftype,cfname), "exception")
    raise StandardError("An error was encountered creating the %s %s" % (cftype,cfname))
      
  _app_trace("createMQQueueConnectionFactory(%s)" %(retval), "exit")
  return retval

#----------------------------------------------------------------------------------------------------
# updateMQConnectionFactory
#
# Parameters:
#   cfid - Configuration ID of connection factory
#   cfname - The name of the factory to modify (for logging)
#   cftype - The type of factory to modify (MQConnectionFactory,MQQueueConnectionFactory,MQTopicConnectionFactory) (for logging)
#   subProps - base connection factory props 
#   connPoolProps - connection pool props
#   connPoolCustomProps - connection pool custom properties
#   mappingModuleProps - properties for MappingModule
#   sessionPoolProps  - properties for SessionPool
#   resourceProps - J2EE resource props for factory
#
# Returns Configuration id of updated factory, throws error otherwise
#
#----------------------------------------------------------------------------------------------------
def updateMQConnectionFactory(cfid, cfname, cftype, subProps, connPoolProps, connPoolCustomProps, mappingModuleProps, sessionPoolProps, resourceProps):
  retval = None
  
  try:
    traceStr = "updateMQConnectionFactory(%s, %s, %s, %s, %s, %s, %s, %s, %s)" % (cfid, cfname, cftype, subProps, connPoolProps, connPoolCustomProps, mappingModuleProps, sessionPoolProps, resourceProps)
    _app_trace(traceStr, "entry")

    if (subProps != None and len(subProps) > 0):
      cfattrs = []
      for key in subProps.keys() :
        val = subProps[key]
        if (val != None and val != '' and val != "None") :
           cfattrs.append([key, val])
    
      if modifyObject(cfid, cfattrs):
        _app_trace("Failed to modify %s attributes for %s" % (cftype, cfname))
        raise StandardError("Failed to modify %s attributes for %s" % (cftype, cfname))
    
    if ((connPoolProps != None and len(connPoolProps) > 0) or (connPoolCustomProps != None and len(connPoolCustomProps) > 0)):  
      poolattrs = []
      for key in connPoolProps.keys() :
        val = connPoolProps[key]
        if (val != None and val != '' and val != "None") :
          poolattrs.append([key, val])
            
      connectionPoolId = AdminConfig.showAttribute(cfid,"connectionPool")
      if (connectionPoolId == None or connectionPoolId == ""):
        connectionPoolId = AdminConfig.create('ConnectionPool', cfid, poolattrs, 'connectionPool') 
      else:
        if (len(poolattrs) > 0):
          if (modifyObject(connectionPoolId, poolattrs)):
            raise StandardError("Failed to modify connection pool for %s %s"  % (cftype, cfname))
      
      if (len(connPoolCustomProps) > 0):
        errMsg = updateCustomProperties(connectionPoolId, "properties", "Property", connPoolCustomProps)
        if (not isEmpty(errMsg)):
          raise StandardError("Unable to update connection pool custom properties for %s %s: %s" % (cftype, cfname, errMsg))

    if (sessionPoolProps != None and len(sessionPoolProps) > 0):
      poolattrs = []
      for key in sessionPoolProps.keys() :
        val = sessionPoolProps[key]
        if (val != None and val != '' and val != "None") :
          poolattrs.append([key, val])
            
      sessionPoolId = AdminConfig.showAttribute(cfid,"sessionPool")
      if (sessionPoolId == None or sessionPoolId == ""):
        sessionPoolId = AdminConfig.create('ConnectionPool', cfid, poolattrs, 'sessionPool') 
      else:
        if (modifyObject(sessionPoolId, poolattrs)):
          raise StandardError("Failed to modify session pool for %s %s"  % (cftype, cfname))
          
    if (mappingModuleProps != None and len(mappingModuleProps) > 0):      
      mappingattrs = []
      for key in mappingModuleProps.keys() :
        val = mappingModuleProps[key]
        if (val != None and val != '' and val != "None") :
          mappingattrs.append([key,val])
    
      mappingModuleId = AdminConfig.showAttribute(cfid, "mapping")
      if (mappingModuleId == None or mappingModuleId == ""):
        mappingModuleId = AdminConfig.create('MappingModule',cfid, mappingattrs, 'mapping')
      else:
        if (modifyObject(mappingModuleId,mappingattrs)):
          raise StandardError("Failed to modify mapping module for %s %s" % (cftype))
    
    if (resourceProps != None and len(resourceProps) > 0):
      propertySetId = AdminConfig.showAttribute(cfid,"propertySet")
      if (isEmpty(propertySetId)):
        _app_trace('About to call AdminConfig.create("J2EEResourcePropertySet",%s,[],"propertySet")' % cfid)
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",cfid,[],"propertySet")
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Error updating J2EE Resource Properties for connectionFactory: %s" %errmsg)

      

    retval = cfid
  except:
    _app_trace("An error was encountered modifying the %s %s" % (cftype,cfname), "exception")
    raise StandardError("An error was encountered modifying the %s %s" % (cftype,cfname))
      
  _app_trace("updateMQQueueConnectionFactory(%s)" %(retval), "exit")
  return retval



#--------------------------------------------------------------------------------
# findMQConnectionFactory
#
# Finds a connection factory under the provider of the specific type and name
#
# Parameters:
#    provider - the provider to search under
#    cftype - MQConnectionFactory, MQQueueConnectionFactory, MQTopicConnectionFactory
#    name - the name of the provider
#
# Returns:
#    Configuration ID if found, None if not, and raises error on unexpected error
#--------------------------------------------------------------------------------
def findMQConnectionFactory(provider, cftype, name):
  _app_trace("findMQConnectionFactory(%s,%s,%s)" % (provider, cftype, name),"entry")
  retval = None
  try:
    cflist = AdminConfig.list(cftype,provider).split(progInfo["line.separator"])
    for cf in cflist:
      if (isEmpty(cf)): continue
      cfname = AdminConfig.showAttribute(cf,"name")
      if (cfname == name):
        retval = cf
        break
  except:
    _app_trace("Unexpected error in findMQConnectionFactory","exception")
    raise StandardError("Unexpected error in findMQConnectionFactory")
  
  _app_trace("findMQConnectionFactory(retval = %s)" % retval,"exit")
  return retval

#-------------------------------------------------------------------------------
# getMQConnectionFactoryProperties
#
# Retrieves propertes for the MQ Connection Factories
# 
# Parameters: 
#     cf - connection factory id
#     cftype - MQConnectionFactory, MQQueueConnectionFactory, MQTopicConnectionFactory
#-------------------------------------------------------------------------------
def getMQConnectionFactoryProperties(cf,cftype,needConnPool=1,needSessionPool=1,needMapping=1,needResource=1):
  retval = java.util.Properties()
  try:
    prefix = "mqjms.connectionFactory"
    
    cfname = AdminConfig.showAttribute(cf,'name')
    retval.put("%s.name" % prefix, cfname)
    
    collectSimpleProperties(retval,"%s.prop" % prefix, cf,["name"])
    
    if (needConnPool):
      cfConnectionPool = AdminConfig.showAttribute(cf,'connectionPool')
      if (not isEmpty(cfConnectionPool)):
        collectSimpleProperties(retval, "%s.connectionPool.prop" % (prefix), cfConnectionPool)
        collectCustomProperties(retval, "%s.connectionPool.customProperties" % prefix, cfConnectionPool, "properties")
    
    if (needMapping):
      cfMappingModules = AdminConfig.list('MappingModule',cf).split(progInfo["line.separator"])
      if (len(cfMappingModules) > 0 and cfMappingModules[0] != ''):
        collectSimpleProperties(retval,"%s.mappingModule.prop" % (prefix), cfMappingModules[0])
    
    if (needSessionPool):
      cfSessionPool = AdminConfig.showAttribute(cf,'sessionPool')
      if (cfSessionPool != ''):
        collectSimpleProperties(retval,"%s.sessionPool.prop" % (prefix), cfSessionPool)
    
    if (needResource):
      collectCustomProperties(retval,"%s.customProperties" % prefix, cf, "properties")
    
    collectResourceProperties(retval,cf,"propertySet","%s.propertySet" % prefix)

  
  except:
    _app_trace("Unexpected error in getMQConnectionFactoryProperties","exception")
    raise StandardError("Unexpected error in getMQConnectionFactoryProperties")
    
  return retval

#-------------------------------------------------------------------------------
# findMQResource - Finds an MQQueue or MQTopic
# 
# Parameters:
#    provider - MQ JMS Provider to search under
#    resourceType - MQQueue or MQTopic
#    resourceName - Name of resource to search for
#
# Returns:
#    Configuration ID if found, None if not, and raises error on unexpected error
#-------------------------------------------------------------------------------
def findMQResource(provider,resourceType, resourceName):
  _app_trace("findMQResource(%s,%s, %s)" % (provider,resourceType,resourceName),"entry")
  retval = None
  
  rlist = AdminConfig.list(resourceType,provider).split(progInfo["line.separator"])
  for resourceId in rlist:
    if (isEmpty(resourceId)): continue
    tempName = AdminConfig.showAttribute(resourceId,"name")
    if (tempName == resourceName):
      retval = resourceId
      break
  
  _app_trace("findMQResource(retval = %s)" % (retval),"exit")
  return retval

#---------------------------------------------------------------------------------
# getMQQueueProperties
#
# Retrieves the settings of the MQQueue in Properties object with these key prefixes:
#    mqjms.queue.prop
#    mqjms.queue.propertySet.resourceProperties.prop
#
# Parameters:
#    queueid - The configuration ID of the queue
#
# Returns:
#    The property set with the keys
#---------------------------------------------------------------------------------
def getMQQueueProperties(queueId):
  _app_trace("getMQQueueProperties(%s)" % queueId,"entry")
  retval = java.util.Properties()
  
  qname = AdminConfig.showAttribute(queueId,'name')
  retval.put("mqjms.queue.name", qname)
  collectSimpleProperties(retval,"mqjms.queue.prop", queueId, ["name"]) 
  collectResourceProperties(retval,queueId,"propertySet","mqjms.queue.propertySet")
  
  _app_trace("getMQQueueProperties(%d properties)" % len(retval),"exit")
  return retval

#-------------------------------------------------------------------------------
# createMQQueue
#
# Creates a MQQueue configuation item under the specified provider
# Parameters:
#     provider - The ID of the JMSProvider MQQueue will be created under
#     queueName - Name of JMSQueue to create
#     subProps - The properties of the MQTopic to create
#     resourceProps - J2EE Resource Properties to create
# 
# Returns:
#    Configuration ID of created item, None or raises error otherwise
#-------------------------------------------------------------------------------
def createMQQueue(provider, queueName, subProps, resourceProps=None):
  retval = None
  
  try:
    traceStr = "createMQQueue( %s, %s, %s,%s)" % (provider, queueName, subProps, resourceProps)
    _app_trace(traceStr, "entry")
    
    queueattrs = [["name",queueName]]
    for key in subProps.keys() :
      val = subProps[key]
      if (val != None and val != '' and val != "None") :
        queueattrs.append([key, val])
    
    _app_trace("About to call AdminConfig.create('MQQueue',%s,%s)" % (provider,queueattrs))
    queueid = AdminConfig.create('MQQueue',provider,queueattrs)
    _app_trace("Created MQQueue for %s" % queueName)
    
    if modifyObject(queueid, queueattrs):
      raise StandardError("Failed to modify MQQueueu attributes for %s" % (queueName))
      
    if (resourceProps != None and len(resourceProps) > 0):
      propertySetId = AdminConfig.showAttribute(queueid,"propertySet")
      if (isEmpty(propertySetId)):
        _app_trace('About to call AdminConfig.create("J2EEResourcePropertySet",%s,[],"propertySet")' % queueid)
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",queueid,[],"propertySet")
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Error updating J2EE Resource Properties for queue: %s" % errmsg)

    retval = queueid
  except:
      _app_trace("An error was encountered creating the MQQueue %s" % queueName, "exception")
      raise StandardError("An error was encountered creating the MQQueue %s" % (queueName))
      
      
  _app_trace("createMQQueue(%s)" %(retval), "exit")
  return retval
  
#-------------------------------------------------------------------------------
# updateMQQueue
#
# Parameters:
#     queueid - The configuration ID of the MQQueue to update
#     subProps - The properties of the MQQueue
#     resourceProps - J2EE Resource Properties
# 
# Returns:
#    Configuration ID of created item, None or raises error otherwise
#-------------------------------------------------------------------------------
def updateMQQueue(queueid, subProps, resourceProps=None):
  retval = None
  
  try:
    traceStr = "updateMQQueue(%s, %s,%s)" % (queueid, subProps, resourceProps)
    _app_trace(traceStr, "entry")
    
    if (subProps != None and len(subProps) > 0):
      queueattrs = []
      for key in subProps.keys() :
        val = subProps[key]
        if (val != None and val != '' and val != "None") :
          queueattrs.append([key, val])
    
      if modifyObject(queueid, queueattrs):
        raise StandardError("Failed to modify MQQueue attributes for %s" % queueid)
      
    if (resourceProps != None and len(resourceProps) > 0):
      propertySetId = AdminConfig.showAttribute(queueid,"propertySet")
      if (isEmpty(propertySetId)):
        _app_trace('About to call AdminConfig.create("J2EEResourcePropertySet",%s,[],"propertySet")' % queueid)
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",queueid,[],"propertySet")
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Error updating J2EE Resource Properties for queue %s %s" % (queueid,errmsg))

    retval = queueid
  except:
    _app_trace("An error was encountered updating the MQQueue %s" % queueid, "exception")
    raise StandardError("An error was encountered updating the MQQueue %s" % queueid)
      
  _app_trace("updateMQQueue(%s)" %(retval), "exit")
  return retval


#---------------------------------------------------------------------------------
# getMQTopicProperties
#
# Retrieves the settings of the MQTopic in Properties object with these key prefixes:
#    mqjms.topic.prop
#    mqjms.topic.propertySet.resourceProperties.prop
#
# Parameters:
#    topicid - The configuration ID of the topic
#
# Returns:
#    The property set with the keys
#---------------------------------------------------------------------------------
def getMQTopicProperties(topicId):
  _app_trace("getMQTopicProperties(%s)" % topicId,"entry")
  retval = java.util.Properties()
  
  qname = AdminConfig.showAttribute(topicId,'name')
  retval.put("mqjms.topic.name", qname)
  collectSimpleProperties(retval,"mqjms.topic.prop", topicId, ["name"]) 
  collectResourceProperties(retval,topicId,"propertySet","mqjms.topic.propertySet")
  
  _app_trace("getMQTopicProperties(%d properties)" % len(retval),"exit")
  return retval

#-------------------------------------------------------------------------------
# createMQTopic
# 
# Parameters:
#     provider - The ID of the JMSProvider MQTopic will be created under
#     topicName - Name of JMSTopic to create
#     subProps - The properties of the MQTopic to create
#     resourceProps - J2EE Resource Properties to create
# 
# Returns:
#    Configuration ID of created item, None or raises error otherwise
#-------------------------------------------------------------------------------
def createMQTopic(provider, topicName, subProps, resourceProps=None):
  retval = None
  
  try:
    traceStr = "createMQTopic( %s, %s, %s,%s)" % (provider, topicName, subProps, resourceProps)
    _app_trace(traceStr, "entry")
    
    topicattrs = [["name",topicName]]
    for key in subProps.keys() :
      val = subProps[key]
      if (val != None and val != '' and val != "None") :
        topicattrs.append([key, val])
    
    _app_trace("About to call AdminConfig.create('MQTopic',%s,%s)" % (provider,topicattrs))
    topicid = AdminConfig.create('MQTopic',provider,topicattrs)
    _app_trace("Created MQTopic for %s" % topicName)
    
    if modifyObject(topicid, topicattrs):
      raise StandardError("Failed to modify MQTopicu attributes for %s" % (topicName))
      
    if (resourceProps != None and len(resourceProps) > 0):
      propertySetId = AdminConfig.showAttribute(topicid,"propertySet")
      if (isEmpty(propertySetId)):
        _app_trace('About to call AdminConfig.create("J2EEResourcePropertySet",%s,[],"propertySet")' % topicid)
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",topicid,[],"propertySet")
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Error updating J2EE Resource Properties for topic: %s" % errmsg)

    retval = topicid
  except:
      _app_trace("An error was encountered creating the MQTopic %s" % topicName, "exception")
      raise StandardError("An error was encountered creating the MQTopic %s" % (topicName))
      
      
  _app_trace("createMQTopic(%s)" %(retval), "exit")
  return retval
  
#-------------------------------------------------------------------------------
# updateMQTopic
#
# Updates a MQTopic definition.
#
# Parameters:
#     topicid - The configuration ID of the MQTopic to update
#     subProps - The properties of the MQTopic to update
#     resourceProps - J2EE Resource Properties to update
# 
# Returns:
#    Configuration ID of updated item, None or raises error otherwise
#-------------------------------------------------------------------------------
def updateMQTopic(topicid, subProps, resourceProps=None):
  retval = None
  
  try:
    traceStr = "updateMQTopic(%s, %s,%s)" % (topicid, subProps, resourceProps)
    _app_trace(traceStr, "entry")
    
    if (subProps != None and len(subProps) > 0):
      topicattrs = []
      for key in subProps.keys() :
        val = subProps[key]
        if (val != None and val != '' and val != "None") :
          topicattrs.append([key, val])
    
      if modifyObject(topicid, topicattrs):
        raise StandardError("Failed to modify MQTopic attributes for %s" % topicid)
      
    if (resourceProps != None and len(resourceProps) > 0):
      propertySetId = AdminConfig.showAttribute(topicid,"propertySet")
      if (isEmpty(propertySetId)):
        _app_trace('About to call AdminConfig.create("J2EEResourcePropertySet",%s,[],"propertySet")' % topicid)
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",topicid,[],"propertySet")
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Error updating J2EE Resource Properties for topic %s %s" % (topicid,errmsg))

    retval = topicid
  except:
    _app_trace("An error was encountered updating the MQTopic %s" % topicid, "exception")
    raise StandardError("An error was encountered updating the MQTopic %s" % topicid)
      
  _app_trace("updateMQTopic(%s)" %(retval), "exit")
  return retval

#-------------------------------------------------------------------------------
# findMQActivationSpec
# 
# Finds the MQ Activation Spec resource with the name for the specified provider.
#
# Parameters:
#    provider - MQ JMS Provider to search under
#    resourceName - Name of resource to search for
#
# Returns:
#    Configuration ID if found, None if not, and raises error on unexpected error
#-------------------------------------------------------------------------------
def findMQActivationSpec(provider, actspecName):
  
  _app_trace("findMQActivationSpec(%s,%s)" %(provider, actspecName),"entry")
  retval = None
  
  try:
    c,n,s,dc,app,appdep = getScope(provider)
    scopeid = getScopeId(c,n,s)

    actSpecs = AdminTask.listWMQActivationSpecs(scopeid).split(progInfo["line.separator"])
    for actSpec in actSpecs:
      if (isEmpty(actSpec)):continue
      tempName = AdminConfig.showAttribute(actSpec,"name")
      if (tempName == actspecName):
        retval = actSpec
        break
  except:
    _app_trace("Unexpected error in findMQActivationSpec","exception")
    raise StandardError("Unexpected error in findMQActivationSpec")
  
  _app_trace("findMQActivationSpec(retval = %s)" %(retval),"exit")
  return retval
  
#-----------------------------------------------------------------------------------------------------
# getMQJMSActivateSpecProperties
#
# Returns the settings of the activation spec in a properties object with the
# mqjms.actspec.prop key prefix.
#
# Parameters:
#    actspec - The configuration ID of the activation spec to inspect
#
# Returns:
#    Properties object with key/val pairs
#-----------------------------------------------------------------------------------------------------
def getMQJMSActivateSpecProperties(actspec):

  _app_trace("getMQJMSActivateSpecProperties(%s)" % actspec,"entry")
  try:
    retval = java.util.Properties()
    actspecnamemap = { 'wAS_EndpointInitialState': 'WAS_EndpointInitialState' }
    if (not isEmpty(actspec)):
       actspecdict = wsadminToDictionary(AdminTask.showWMQActivationSpec(actspec))
            
       name = actspecdict.get("name","")
       retval.put("mqjms.actspec.name", name)
            
       for key in actspecdict.keys():
           if (key == "name"): continue
           val = actspecdict[key]
           
           if (val == "null"):
             val = ""
            
           if (actspecnamemap.has_key(key)):
               #Use alternative key
               key = actspecnamemap.get(key)
           retval.put("mqjms.actspec.prop.%s" % key,val)
           
  except:
    _app_trace("Unexpected error in getMQJMSActivateSpecProperties","exception")
    raise StandardError("Unexpected error in getMQJMSActivateSpecProperties")
    
  _app_trace("getMQJMSActivateSpecProperties(%d properties)" % len(retval),"exit")
  return retval

#wsadmin>print AdminTask.help("createWMQActivationSpec")
#WASX8006I: Detailed help for command: createWMQActivationSpec
#
#Description: Creates a WMQ Activation Specification at the scope provided to the command.
#
#*Target object: The scope at which to create the WMQ Activation Specification.
#
#Arguments:
#  *name - The administrative name assigned to the activation specification.
#  *jndiName - The name and location used to bind this object into WAS JNDI.
#  *destinationJndiName - The JNDI name of a WMQ JMS RA queue or topic type destination. When an MDB is deployed with this activation specification, it is this destination that messages for the MDB will be consumed from.
#  *destinationType - The type of the destination specified using the destinationJndiName parameter.
#  description - An administrative description assigned to the activation specification.
#  ccdtUrl - A URL to a client channel definition table to use, for this activation specification, when contacting WMQ. Activation specifications created using this parameter are of "ccdtURL" variety.
#  ccdtQmgrName - A queue manager name, used to select one or more entries from a client channel definition table.
#  qmgrName - The name of the queue manager to use, for this activation specification, when contacting WMQ. Activation specifications created using this parameter are of "user defined" variety.
#  wmqTransportType - Determines the manner in which, for this activation specification, a connection will be established to WMQ. Activation specifications created using this parameter are of "user defined" variety. Valid values are "BINDINGS", "BINDINGS_THEN_CLIENT" and "CLIENT".
#  qmgrHostname - The hostname which will be used, for this activation specification, when attempting a client mode connection to WMQ.
#  qmgrPortNumber - The port number to use, for this activation specification, when attempting a client mode connection to WMQ.
#  authAlias - The authentication alias used to obtain the credentials specified when this activation specification needs to establish a connection to WebSphere MQ.
#  clientId - The client identifier used for connections started using this activation specification.
#  providerVersion - Determines the minimum version, and capabilities of the queue manager.
#  sslCrl - Specifies a list of LDAP servers which may be used to provide certificate revocation information if this activation specification establishes a SSL based connection to WMQ.
#  sslResetCount - Used when the activation specification establishes an SSL connection to the queue manager. This parameter determines how many bytes to transfer before resetting the symmetric encryption key used for the SSL session.
#  sslPeerName - Used when the activation specification establishes an SSL connection to the queue manager. This value is used to match against the distinguished name present in the peers certificate.
#  sslType - Determines the configuration, if any, to use when applying SSL encryption to the network connection to the queue manager.
#  sslConfiguration - Names a specific SSL configuration to use when using SSL to secure network connections to the queue manager.
#  rcvExit - A comma separated list of receive exit class names.
#  rcvExitInitData - Initialization data to pass to the receive exit.
#  sendExit - A comma separate list of send exit class names.
#  sendExitInitData - Initialization data to pass to the send exit.
#  secExit - A security exit class name.
#  secExitInitData - Initialization data to pass to the security exit.
#  compressHeaders - Determines if message headers are compressed or not.
#  compressPayload - Determines if message payloads are compressed or not.
#  msgRetention - Determines whether or not the connection consumer keeps unwanted messages on the input queue. A value of true means that it does. A value of false means that the messages are disposed of as per their disposition options.
#  rescanInterval - When a message consumer in the point-to-point domain uses a message selector to select which messages it wants to receive, the WebSphere MQ JMS client searches the WebSphere MQ queue for suitable messages in the sequence 
#                  determined by the MsgDeliverySequence attribute of the queue. When the client finds a suitable message and delivers it to the consumer, the client resumes the search for the next suitable message from its current position 
#                  in the queue. The client continues to search the queue in this way until it reaches the end of the queue, or until the interval of time in milliseconds, as determined by the value of this property, has expired. In each case, the client returns to the beginning of the queue to continue its search, and a new time interval commences.
#  ccsid - The coded-character-set-ID to be used on connections.
#  failIfQuiescing - Determines the behavior of certain calls to the queue manager when the queue manager is put into quiescing state.
#  brokerCtrlQueue - The broker control queue to use if this activation specification is to subscribe to a topic.
#  brokerSubQueue - The queue to use for obtaining subscription messages if this activation specification is to subscribe to a topic.
#  brokerCCSubQueue - The name of the queue from which non-durable subscription messages are retrieved for a ConnectionConsumer.
#  brokerVersion - Determines the level of functionality required for publish/subscribe operations.
#  msgSelection - Determines where message selection occurs.
#  subStore - Where WebSphere MQ JMS should store persistent data relating to active subscriptions.
#  stateRefreshInt - The interval, in milliseconds, between refreshes of the long running transaction that detects when a subscriber loses its connection to the queue manager. This property is relevant only if subStore parameter has the value QUEUE.
#  cleanupLevel - Cleanup Level for BROKER or MIGRATE Subscription Stores.
#  cleanupInterval - The interval between background executions of the publish/subscribe cleanup utility.
#  wildcardFormat - Determines which sets of characters are interpreted as topic wildcards.
#  sparseSubs - Controls the message retrieval policy of a TopicSubscriber object.
#  brokerQmgr - The name of the queue manager on which the broker is running.
#  clonedSubs - Whether two or more instances of the same durable topic subscriber can run simultaneously.
#  qmgrSvrconnChannel - The SVRCONN channel to use when connecting to WebSphere MQ. Specifying this property signifies that the activation specification is of the "user defined" variety.
#  brokerCCDurSubQueue - The name of the queue from which a connection consumer receives durable subscription messages.
#  maxPoolSize - The maximum number of server sessions in the server session pool used by the connection consumer.
#  messageSelector - A message selector expression specifying which messages are to be delivered.
#  poolTimeout - The period of time, in milliseconds, that an unused server session is held open in the server session pool before being closed due to inactivity.
#  startTimeout - The period of time, in milliseconds, within which delivery of a message to an MDB must start after the work to deliver the message has been scheduled. If this period of time elapses, the message is rolled back onto the queue.
#  subscriptionDurability - Whether a durable or nondurable subscription is used to deliver messages to an MDB subscribing to the topic.
#  subscriptionName - The name of the durable subscription.
#  stopEndpointIfDeliveryFails - Indicates whether the endpoint should be stopped if message delivery fails the number of times specified by the failureDeliveryCount property.
#  failureDeliveryCount - The number of sequential delivery failures that are allowed before the endpoint is suspended.
#  localAddress - This property specifies either or both of the following: a) The local network interface to be used b) The local port, or range of local ports,to be used.
#
#Steps:
#   customProperties - Used to set custom properties.
#-------------------------------------------------------------------------------
# createMQActivationSpec - Create a new MQ JMS Activation spec at the 
# scope of the specified provider.
#
# Parameters:
#    providerId - The ID of the related provider
#    actSpecName - The name of the activation spec to create
#    specProperties - key/value pairs using the keys from showWMQActivationSpec
#
# Returns:
#    The configuration ID of the created provider, returns null or raises Error otherwise
#-------------------------------------------------------------------------------
def createMQActivationSpec(providerId, actSpecName, specProperties):
  
  _app_trace("createMQActivationSpec(%s,%s,%s)" %(providerId, actSpecName, specProperties),"entry")
  
  # Unfortunately, there's not a 1-1 mapping between the show and create attributes
  # So we'll have to do some mappings and also handle input that have no parms
  parmMap = {"authenticationAlias": "authAlias","messageRetention":"msgRetention"}
  customPropNames = ["acknowledgeMode","useJNDI","WAS_EndpointInitialState"]
  
  retval = None
  
  try:
    c,n,s,dc,app,appdep = getScope(providerId)
    scopeid = getScopeId(c,n,s)
    
    attributes  = " -name %s" % (actSpecName)        
    
    for key in specProperties.keys():
      if key in customPropNames: continue
      altkey = parmMap.get(key,key)
      val = specProperties.get(key)
      if (not isEmpty(val)):
         if (altkey == "description" and not val.startswith('"')):
             val = '"%s"' % val
         elif (altkey == "messageSelector" and not (val.startswith('"') or val.startswith("'"))):
             val = '"%s"' % val
             
         attributes = "%s -%s %s" % (attributes, altkey, val)
  

  
    _app_trace("Running command: AdminTask.createWMQActivationSpec(%s, %s)" % (scopeid, attributes))

    retval = AdminTask.createWMQActivationSpec(scopeid, attributes)
    
    if (not isEmpty(retval)):
      actSpecId = retval
      specialProps = java.util.Properties()
      # See if there any input parms that need to be handled
      for key in specProperties.keys():
        if key in customPropNames:
            val = specProperties.get(key)
            if (not isEmpty(val)):
              specialProps.put(key, "java.lang.String|false|%s" % (val))
      
      if (len(specialProps) > 0):
        errmsg = updateCustomProperties(actSpecId, "resourceProperties", "J2EEResourceProperty", specialProps)
        if (not isEmpty(errmsg)):
          raise StandardError("Unable to update special properties for activation spec %s: %s" % (actSpecName,errmsg))
            
  except:
    _app_trace("Unexpected error in createMQActivationSpec","exception")
    raise StandardError("Unexpected error in createMQActivationSpec")
  
  _app_trace("createMQActivationSpec(retval = %s)" %(retval),"exit")
  return retval
      
#-------------------------------------------------------------------------------
# modifyMQActivationSpec
#
# Updates an existing MQ Activation Sepc
# Parameters:
#    actSpecId - The ID of the activation spec to create
#    specProperties - key/value pairs using the keys from showWMQActivationSpec
#
# Returns:
#    The configuration ID of the modified activation spec, returns null or raises Error otherwise
#-------------------------------------------------------------------------------
def modifyMQActivationSpec(actSpecId, specProperties):
  
  _app_trace("modifyMQActivationSpec(%s,%s)" %(actSpecId, specProperties),"entry")
  
  retval = None
  
  # Unfortunately, there's not a 1-1 mapping between the show and create attributes
  # So we'll have to do some mappings and also handle input that have no parms
  parmMap = {"authenticationAlias": "authAlias", "messageRetention":"msgRetention"}
  customPropNames = ["acknowledgeMode","useJNDI","WAS_EndpointInitialState"]
  
  try:
    
    attributes  = ""
    
    for key in specProperties.keys():
      if key in customPropNames: continue
      altkey = parmMap.get(key,key)
      val = specProperties.get(key)
      if (not isEmpty(val)):
         if (altkey == "description" and not val.startswith('"')):
             val = '"%s"' % val
         elif (altkey == "messageSelector" and not (val.startswith('"') or val.startswith("'"))):
             val = '"%s"' % val             
         attributes = "%s -%s %s" % (attributes, altkey, val)
  

  
    _app_trace("Running command: AdminTask.modifyWMQActivationSpec(%s, %s)" % (actSpecId, attributes))

    AdminTask.modifyWMQActivationSpec(actSpecId, attributes)
    
    if (not isEmpty(actSpecId)):
      specialProps = java.util.Properties()
      # See if there any input parms that need to be handled
      for key in specProperties.keys():
        if key in customPropNames:
            val = specProperties.get(key)
            if (not isEmpty(val)):
              specialProps.put(key, "java.lang.String|false|%s" % (val))
      
      if (len(specialProps) > 0):
        errmsg = updateCustomProperties(actSpecId, "resourceProperties", "J2EEResourceProperty", specialProps)
        if (not isEmpty(errmsg)):
          raise StandardError("Unable to update special properties for activation spec %s: %s" % (actSpecId,errmsg))
          
    retval = actSpecId          
  except:
    _app_trace("Unexpected error in modifyMQActivationSpec","exception")
    raise StandardError("Unexpected error in modifyMQActivationSpec")
  
  _app_trace("modifyMQActivationSpec(retval = %s)" %(retval),"exit")
  return retval
      










































































































