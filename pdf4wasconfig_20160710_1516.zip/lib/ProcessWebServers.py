##########################################################################################
# ProcessWebServers.py
# 
# This module contains the functions that process the web server settings 
# webConfigInfo dictionary passed to processWebServers()
#
# Primary function:
#     processWebServers()
#
# Related modules:
#     WebServers.py
#     Utils.py
# 
# Properties Syntax overview:
#
# For a full example, use the dumpConfig.py script to produce the properties of an
# existing web server. 
#
# Note that the top-level properties of the WebServer can be specified as either
# app.webServer.[].prop.XXXX or app.webServer.[].XXXX.
# Older versions of the script library did not use the .prop. for the top level
# configuration items. The properties name,nodeName,webPort,and adminPort must
# be specified without the ".prop."
#
# # Base web server properties
# app.webServer.<index>.name = WebServerAlpha
# app.webServer.<index>.nodeName = UnmanagedNode1
# app.webServer.<index>.webPort = 80
# app.webServer.<index>.adminPort = 
# app.webServer.<index>.prop.webserverAdminProtocol = HTTP
# app.webServer.<index>.prop.webserverProtocol = HTTP
# app.webServer.<index>.prop.webserverType = IIS
# app.webServer.<index>.stateManagement.prop.initialState = START
# app.webServer.<index>.processDef.prop.executableName = apache.exe
# app.webServer.<index>.processDef.prop.executableTargetKind = JAVA_CLASS
# app.webServer.<index>.processDef.prop.startCommand = ${WEB_INSTALL_ROOT}/bin/apachectl.exe
# app.webServer.<index>.processDef.prop.startCommandArgs = -k;start;-n;IBMHTTPServerV8.5;-f;${WEB_INSTALL_ROOT}/conf/httpd.conf;
# app.webServer.<index>.processDef.prop.stopCommand = ${WEB_INSTALL_ROOT}/bin/apachectl.exe
# app.webServer.<index>.processDef.prop.stopCommandArgs = -k;stop;-n;IBMHTTPServerV8.5;-f;${WEB_INSTALL_ROOT}/conf/httpd.conf
# app.webServer.<index>.processDef.prop.workingDirectory = ${WEB_INSTALL_ROOT}
# app.webServer.<index>.processDef.execution.prop.processPriority = 20
# app.webServer.<index>.processDef.execution.prop.runInProcessGroup = 0
# app.webServer.<index>.processDef.execution.prop.umask = 027
# # WebServer custom properties
# app.webServer.<index>.properties.prop.CustomProperty1 = Value1|Description1
# app.webServer.1.properties.prop.CustomProperty2 = value2
#
# # Webservers Plugin properties, cluster specific properties and custom properties for plugin settings
# app.webServer.<index>.pluginProperties.prop.ASDisableNagle = false
# app.webServer.<index>.pluginProperties.prop.AcceptAllContent = false
# app.webServer.<index>.pluginProperties.prop.AppServerPortPreference = HOSTHEADER
# ...
# app.webServer.<index>.pluginProperties.pluginServerClusterProperties.prop.CloneSeparatorChange = false
# app.webServer.<index>.pluginProperties.pluginServerClusterProperties.prop.LoadBalance = ROUND_ROBIN
# ...
# app.webServer.<index>.pluginProperties.properties.prop.PluginCustomProp1 = Pluginval1|Description1
# app.webServer.<index>.pluginProperties.properties.prop.PluginCustomProp2 = pcvaltwo
# ...
# ...
# app.webServer.count = <count of web servers>
#
#-------------------------------------------------------------------------------
# IntelligentManagement features of the plugin
#
# With 8.5.5 onwards, the plug-in can route to servers with the IM system. These settings
# that define this feature are shown below
#
# app.webServer.1.intelligentManagement.prop.enabled = true
# app.webServer.1.intelligentManagement.prop.maxRetries = 5
# app.webServer.1.intelligentManagement.prop.retryInterval = 65
#
# # Remote Cell settings
# app.webServer.1.intelligentManagement.remoteCells.1.prop.cellIdentifier = RemoteCell1
# app.webServer.1.intelligentManagement.remoteCells.1.prop.host = JJMW530
# app.webServer.1.intelligentManagement.remoteCells.1.prop.port = 12698
# app.webServer.1.intelligentManagement.remoteCells.1.prop.enabled = false
# #-- Additional arguments for addRemoteCellToIntelligentManagement
# #-- Note userids/passwords can be left out if trusted realm settings are in place
# app.webServer.1.intelligentManagement.remoteCells.1.importCertificates = true
# app.webServer.1.intelligentManagement.remoteCells.1.userid = wsadmin
# app.webServer.1.intelligentManagement.remoteCells.1.password = <Password>
# app.webServer.1.intelligentManagement.remoteCells.count = 1
#
# # Custom properties for the IM plugin 
# app.webServer.1.intelligentManagement.pluginProperties.prop.MaxElapsedTimePerRequestInSeconds = 15
# app.webServer.1.intelligentManagement.pluginProperties.prop.MaxSecondsToWaitDuringAtomicRollout = 25
#
# # the pluginProperties.remove properties can be used to indicated plugin properties
# # that should be fully removed
# app.webServer.1.intelligentManagement.pluginProperties.remove.prop.MaxElapsedTimePerRequestInSeconds = true
# app.webServer.1.intelligentManagement.pluginProperties.remove.prop.MaxSecondsToWaitDuringAtomicRollout = true

# # trace settings
# app.webServer.1.intelligentManagement.traceSpecs.default.prop.name = default
# app.webServer.1.intelligentManagement.traceSpecs.default.prop.spec = control:INFO,control.health:DEBUG,http.request:INFO
#
# # Set traceSpecs.default.clear to true to force this setting to be removed
# app.webServer.1.intelligentManagement.traceSpecs.default.clear = false
#
# app.webServer.1.intelligentManagement.traceSpecs.conditional.prop.name = 1
# app.webServer.1.intelligentManagement.traceSpecs.conditional.prop.spec = http.request:DEBUG
# app.webServer.1.intelligentManagement.traceSpecs.conditional.prop.condition = uri LIKE 'mynewprimaryapp'
#
# # Set traceSpecs.conditional.clear to true to force this setting to be removed
# app.webServer.1.intelligentManagement.traceSpecs.conditional.clear = false
#
#
# -----------------------------------------------------------------
# Iteration Support
#
# The following configuration properties show how the @ITERATE keyword
# can be used to apply settings to multiple web servers. You can use the @ITERATE
# keyword for the webserver name and/or node name. 
#
# @ITERATE or @ITERATE(*MyPattern*)
# If no arguments are specified, the wildcard pattern "*" is used to match all
# items, otherwise the specified wildcard pattern is used.
 
# app.webServer.1.name = @ITERATE
# app.webServer.1.nodeName = @ITERATE
# ..
# app.webServer.1.pluginProperties.prop.ASDisableNagle = false
# ..
# 
#-------------------------------------------------------------------
# Server List support
# 
# To simplify the task of creating multiple identical web servers on different
# nodes, the variableServers option can be used as shown in the example below.
#
# app.webServer.1.variableServers = WebNode1/webserver1 WebNode2/webserver2
#
# When variableServers is specified, the dynamic keywords WEB_SERVER_NAME and NODE_NAME can be used to customize
# properties:
#
# app.webServer.1.pluginProperties.prop.LogFilename = /opt/IBM/Plugins855/logs/@{DYNAMIC#KEYWORD#WEB_SERVER_NAME}/http_plugin.log
# ..
# app.webServer.1.pluginProperties.prop.RemoteConfigFilename = /opt/IBM/Plugins855/config/@{DYNAMIC#KEYWORD#WEB_SERVER_NAME}/plugin-cfg.xml
# app.webServer.1.pluginProperties.prop.RemoteKeyRingFilename = /opt/IBM/Plugins855/config/@{DYNAMIC#KEYWORD#WEB_SERVER_NAME}/plugin-key.kdb
# ..
# app.webServer.1.intelligentManagement.pluginProperties.prop.webserverName = MQMessagingCell_@{DYNAMIC#KEYWORD#NODE_NAME}_@{DYNAMIC#KEYWORD#WEB_SERVER_NAME}
#
##########################################################################################


#-------------------------------------------------------------------------------
# processWebServerIntelligentManagementTraceProperties
#
# Handles the trace settings for the IM component
#-------------------------------------------------------------------------------
def processWebServerIntelligentManagementTraceProperties(webConfigInfo,prefix,webserverId,existingProps,webserverName,nodeName):
  _app_trace("processWebServerIntelligentManagementTraceProperties(webConfigInfo,%s,%s,%s,%s,%s)" % (prefix,webserverId,existingProps,webserverName,nodeName),"entry")
  try:
    newDefaultSpec = None
    newConditionalSpec = None
    newCondition = None
    inputSpecified = 0

    # Check the default spec
    defaultprefix = "%s.traceSpecs.default" % prefix
    
    defaultName = webConfigInfo.get("%s.prop.name"%defaultprefix,"")
    defaultSpec = webConfigInfo.get("%s.prop.spec"%defaultprefix,"")
    
  
    if (not isEmpty(defaultName)):
      inputSpecified = 1
      # Settings were passed in
      currentSpec = ""
      if (existingProps):
        currentSpec = existingProps.get("webServer.intelligentManagement.traceSpecs.default.prop.spec","")
        if (currentSpec != defaultSpec):
          # needs to be changed
          newDefaultSpec = defaultSpec
      else:
        newDefaultSpec = defaultSpec
    
    if (webConfigInfo.get("%s.clear" % defaultprefix,"").lower() == "true"):
      newDefaultSpec = ""
    
    # Check the conditional trace
    conditionprefix = "%s.traceSpecs.conditional" % prefix
    
    condition = webConfigInfo.get("%s.prop.condition" % conditionprefix,None)
    conditionalSpec = webConfigInfo.get("%s.prop.spec" % conditionprefix,"")
    
    if (condition != None):
      # Some settings were specified
      inputSpecified = 1
      if (existingProps):
        currentCondition = existingProps.get("webServer.intelligentManagement.traceSpecs.conditional.prop.condition","")
        currentConditionSpec = existingProps.get("webServer.intelligentManagement.traceSpecs.conditional.prop.spec","")
        
        if (currentCondition != condition or currentConditionSpec != conditionalSpec):
          newCondition = condition
          newConditionalSpec = conditionalSpec
      else:      
        newCondition = condition
        newConditionalSpec = conditionalSpec

    if (webConfigInfo.get("%s.clear" % conditionprefix,"").lower() == "true"):
      newCondition = ""
      newConditionalSpec = ""

    if (newDefaultSpec != None or newConditionalSpec != None or  newCondition != None):
      # trace settings need to be changed
      modifyWebServerIntelligentManagementTraceSpecs(nodeName,webserverName,newDefaultSpec,newConditionalSpec,newCondition)
      _app_message("WebServer Intelligent Management trace settings were changed for server %s/%s" % (nodeName,webserverName))
    elif (inputSpecified):
      _app_message("WebServer Intelligent Management trace settings were not changed for server %s/%s" % (nodeName,webserverName))
    
      
  except:
    _app_exception("Unexpected problem in processWebServerIntelligentManagementTraceProperties")
  _app_trace("processWebServerIntelligentManagementTraceProperties()","exit")

#-------------------------------------------------------------
# processWebServerIntelligentManagementRemoteServerProperties
#
# Handles the processing of properties that define the remote
# cells the plug-in can dispatch to.
#-------------------------------------------------------------
def processWebServerIntelligentManagementRemoteServerProperties(webConfigInfo,prefix,webserverId,existingProps,webserverName,nodeName):
  _app_trace("processWebServerIntelligentManagementRemoteServerProperties(webConfigInfo,%s,%s,%s,%s,%s)" % (prefix,webserverId,existingProps,webserverName,nodeName),"entry")
  try:
    prefix = "%s.remoteCells" % prefix
    remoteCount = int(webConfigInfo.get("%s.count" % prefix, "0"))
    if (remoteCount > 0):
      for idx in range(1,remoteCount+1):
        rcprefix = "%s.%d" % (prefix,idx)
        host = webConfigInfo.get("%s.prop.host" % rcprefix)
        port = webConfigInfo.get("%s.prop.port" % rcprefix)
        cellIdentifier = webConfigInfo.get("%s.prop.cellIdentifier" % rcprefix)
        
        if (isEmpty(host)):
          # partial list - just continue
          continue
        
        existingRemote = None
        existingRemoteIM = None
        if (existingProps != None):
          existingRemote = existingProps.get("webServer.intelligentManagement.remoteCells.%s_%s" % (host,port))
          existingRemoteIM = existingProps.get("webServer.intelligentManagement.remoteCells.imSettings.%s_%s" % (host,port))
          
        if (existingRemote != None and len(existingRemote) > 0):
          # This is an update to existing remote cell
          _app_message("Remote cell at %s:%s is already configured in intelligent management" % (host,port))
          remoteProps = getPropList(webConfigInfo,rcprefix,1)
          
          # Compare existing and input settings
          remoteProps = toDictionary(getModifiedProperties(remoteProps, existingRemote))
          
          
          # Note - support for the remote IM Props is questionable, ignoring for now
          #remoteIMProps = getPropList(webConfigInfo,"%s.imSettings"%rcprefix)
          #remoteIMProps = getModifiedProperties(remoteProps, existingRemoteIM)
          
          if (len(remoteProps) > 0):
            modifyWebServerIntelligentManagementRemoteCell(nodeName,webserverName,host,port,**remoteProps)
            _app_message("Settings for Remote cell at %s:%s has been updated in IM configurations for %s/%s" % (host,port,nodeName,webserverName))    
          else:
            _app_message("No changes in settings for existing remote cell at %s:%s in IM configurations for %s/%s" % (host,port,nodeName,webserverName)) 
          
        else:
          _app_message("Remote cell at %s:%s is not configured in intelligent management" % (host,port))
          userid = webConfigInfo.get("%s.userid" % rcprefix,None)
          password = webConfigInfo.get("%s.password" % rcprefix,None)
          importCertificates = webConfigInfo.get("%s.importCertificates" % rcprefix,"false")
          remoteOptions = getPropList(webConfigInfo,rcprefix,1)
          remoteOptions.remove("host")
          remoteOptions.remove("port")
          remoteOptions["importCertificates"] = importCertificates
          addWebServerIntelligentManagementRemoteCell(nodeName,webserverName,host,port,userid,password,**remoteOptions)
          _app_message("Remote cell at %s:%s has been added to IM configurations for %s/%s" % (host,port,nodeName,webserverName))
          
  except:
    _app_exception("Unexpected error in processWebServerIntelligentManagementRemoteServerProperties")
  _app_trace("processWebServerIntelligentManagementRemoteServerProperties()","exit")
  
#-------------------------------------------------------------------------------
# processWebServerIntelligentManagementTraceProperties
#
# Handles the properties for the IM component of an individual web server
#-------------------------------------------------------------------------------
def updateWebServerIntelligentManagementProperties(webConfigInfo,prefix, webserverId, existingProps, webserverName, nodeName):
  _app_trace("updateWebServerIntelligentManagementProperties(webConfigInfo,%s,%s,existingProps,%s,%s)" % (prefix,webserverId, webserverName, nodeName),"entry")
  try:
    prefix = "%s.intelligentManagement" % prefix
    
    if (checkForPrefix(webConfigInfo,prefix)):
      # Intelligent Management settings are passed in
      
      enabledSetting = webConfigInfo.get("%s.prop.enabled"%prefix,"false")
      
      if (existingProps != None):
        # See if currently enabled
        currentEnabled = existingProps.get("webServer.intelligentManagement.prop.enabled")
        #print "currentEnabled = %s" % currentEnabled
        if (currentEnabled == enabledSetting and enabledSetting == "false"):
          _app_message("Intelligent Management already disabled for server %s/%s" % (nodeName,webserverName))
        elif (currentEnabled != enabledSetting and enabledSetting == "true"):
          # Get base settings for IM, removed enabled as its not an attribute
          imProps = toDictionary(getPropList(webConfigInfo,prefix,1))
          del imProps["enabled"]
          
          imId = enableWebServerIntelligentManagement(nodeName,webserverName,**imProps)
          
          _app_message("Intelligent Management enabled for existing web server %s/%s" % (nodeName,webserverName))
        elif (currentEnabled == "true" and enabledSetting == "false"):
          disableWebServerIntelligentManagement(nodeName,webserverName)
          _app_message("Intelligent Management disabled for existing web server %s/%s" % (nodeName,webserverName))
        elif (currentEnabled == "true" and enabledSetting == "true"):
          # May just need to modify
          imProps = toDictionary(getPropListDifferences(webConfigInfo, prefix, existingProps, "webServer.intelligentManagement"))
          if (len(imProps) > 0):
            modifyWebServerIntelligentManagement(nodeName,webserverName,**imProps)
            _app_message("Updated base IntelligentManagement settings for %s/%s" % (nodeName,webserverName))
          else:
            _app_message("No change in base IntelligentManagement settings for %s/%s" % (nodeName,webserverName))
        else:
          _app_message("Unexpected state [%s] [%s]..." % (currentEnabled,enabledSetting))
          
        
        # Handle the plugin properties
        pluginProps = toDictionary(getPropListDifferences(webConfigInfo,"%s.pluginProperties"%prefix,existingProps,"webServer.intelligentManagement.pluginProperties"))
        if (len(pluginProps) > 0):
          setWebServerIntelligentManagmentPluginProperties(nodeName,webserverName,**pluginProps)
          _app_message("Plugin properties have been set up for %s/%s : %s" % (nodeName,webserverName,pluginProps))
          
        # Handle deletions of existing properties if specified
        delProps = getPropList(webConfigInfo,"%s.pluginProperties.remove" % prefix,1)
        if (len(delProps) > 0):
          remList = []
          dontExistList = []
          for key in delProps.keys():
            if (existingProps.get("webServer.intelligentManagement.pluginProperties.prop.%s" % key) != None):
              # Property is currently Set
              if (delProps[key].lower() == "true"):
                remList.append(key)
            else:
              dontExistList.append(key)
          
          if (len(remList) > 0):
            removeWebServerIntelligentManagementPluginProperties(nodeName, webserverName, *remList)
            _app_message("The following IM plugin properties have been removed from %s/%s: %s" % (nodeName,webserverName,remList))
          
          if (len(dontExistList) > 0):
            _app_message("The following IM plugin properties did not exist and have not been removed from %s/%s: %s" % (nodeName,webserverName,remList))
        
        # Handle the remote server properties
        processWebServerIntelligentManagementRemoteServerProperties(webConfigInfo,prefix,webserverId,existingProps,webserverName,nodeName)
        
        # Handle the trace settings
        processWebServerIntelligentManagementTraceProperties(webConfigInfo,prefix,webserverId,existingProps,webserverName,nodeName)
         
      else:
        if (enabledSetting.lower() == "false"):
          # No need to do anything
          _app_message("New web server %s/%s : intelligent management disabled by default" % (nodeName,webserverName))
        else:
          # Will need to enable intelligent management
          
          # Get base settings for IM, removed enabled as its not an attribute
          imProps = toDictionary(getPropList(webConfigInfo,prefix,1))
          del imProps["enabled"]
          
          imId = enableWebServerIntelligentManagement(nodeName,webserverName,**imProps)
          
          _app_message("Intelligent Management enabled for new web server %s/%s" % (nodeName,webserverName))
          
          # Handle the plugin properties
          pluginProps = toDictionary(getPropList(webConfigInfo,"%s.pluginProperties"%prefix,1))
          if (len(pluginProps) > 0):
            setWebServerIntelligentManagmentPluginProperties(nodeName,webserverName,**pluginProps)
            _app_message("Plugin properties have been set up for %s/%s : %s" % (nodeName,webserverName,pluginProps))
        
          # Handle the remote server properties
          processWebServerIntelligentManagementRemoteServerProperties(webConfigInfo,prefix,webserverId,existingProps,webserverName,nodeName)
        
          # Handle the trace settings
          processWebServerIntelligentManagementTraceProperties(webConfigInfo,prefix,webserverId,existingProps,webserverName,nodeName)

          
          
          
        
  except:
    _app_exception("Unexpected problem in updateWebServerIntelligentManagementProperties()")
  
  _app_trace("updateWebServerIntelligentManagementProperties","exit")

#---------------------------------------------------------------------------------------------------------
# updateWebServerPluginProperties
#
# Update the plugin settings for a WebServer configuration item
#---------------------------------------------------------------------------------------------------------
def updateWebServerPluginProperties(webConfigInfo,prefix, serverId, existingProps, serverName, serverNode):

  pluginPropertiesId = AdminConfig.list("PluginProperties",serverId)

  subProps = getPropListDifferences(webConfigInfo, "%s.pluginProperties"  % (prefix), existingProps, "webServer.pluginProperties" )
  if (subProps.size() > 0):
      webServerPluginAttrs = []
      serverClusterProps = java.util.Properties()
      customProps = java.util.Properties()
      for key in subProps.keys():
          val = subProps.get(key)
          webServerPluginAttrs.append([key,val])
      
      if (modifyObject(pluginPropertiesId, webServerPluginAttrs)):
          _app_message("Failed to update PluginProperties for Web Server %s on %s" % (serverName, serverNode))
          exit()
      else:
          _app_message("Updated PluginProperties for Web Server %s on %s" % (serverName, serverNode))
    
    
  serverClusterProps = getPropListDifferences(webConfigInfo, "%s.pluginProperties.pluginServerClusterProperties"  % (prefix), existingProps, "webServer.pluginProperties.pluginServerClusterProperties" )
          
  if (serverClusterProps.size() > 0):
      pluginServerClusterAttrs =[]
      for key in serverClusterProps.keys():
          val = serverClusterProps.get(key)
          pluginServerClusterAttrs.append([key,val])
              
      pluginServerClusterId = AdminConfig.list("PluginServerClusterProperties",pluginPropertiesId)
      if (modifyObject(pluginServerClusterId, pluginServerClusterAttrs)):
          _app_message("Failed to update PluginServerClusterProperties for WebServer %s on %s" % (serverName, serverNode))
          exit()
      else:
          _app_message("Updated PluginServerClusterProperties for WebServer %s on %s" % (serverName, serverNode))
          
  # Handle plugin custom properties - Support old and new format
  newFormatProperties = None
  if (webConfigInfo.has_key("%s.pluginProperties.properties.count" % prefix)):
    # Old format - convert to new and then call standard function
    newFormatProperties = {}
    idx = 1
    countCustomProps = int(webConfigInfo["%s.pluginProperties.properties.count" % (prefix)])
    while (idx <= countCustomProps):
          
          subProps = getPropList(webConfigInfo, "%s.pluginProperties.properties.%d" % (prefix,idx),1)
          idx += 1
          if (subProps.size() == 0 or subProps.get("name") == None):
              continue
          
          propertyName = subProps.get("name")
          propertyValue = subProps.get("value")
          propertyDescription = subProps.get("description")
          
          if (isEmpty(propertyDescription)):
            newFormatProperties["temp.properties.prop.%s" % propertyName] = propertyValue
          else:
            newFormatProperties["temp.properties.prop.%s" % propertyName] = "%s|%s" % (propertyValue,propertyDescription)
    
    if (len(newFormatProperties)  > 0):
      if (existingProps != None):
        newFormatProperties = getPropListDifferences(newFormatProperties,"temp.properties" ,existingProps,"webServer.pluginProperties.properties")
      else:
        newFormatProperties = getPropList(newFormatProperties,"temp.properties",1)
  else:
    # Pull properties in standard format
    if (existingProps != None):
      newFormatProperties = getPropListDifferences(webConfigInfo,"%s.pluginProperties.properties" % prefix,existingProps,"webServer.pluginProperties.properties")
    else:
      newFormatProperties = getPropList(webConfigInfo,"%s.pluginProperties.properties" % prefix,1)
    
  if (len(newFormatProperties) > 0):
    errmsg = updateCustomProperties(pluginPropertiesId, "properties", "Property", newFormatProperties)
    if (isEmpty(errmsg)):
      _app_message("The following plugin custom properties have been updated on server %s/%s : %s" % (serverNode,serverName, newFormatProperties))
    else:
      _app_message("Error updating plugin custom properties have been updated on server %s/%s : %s" % (serverNode,serverName, errmsg))
      exit()
    

# enddef updateWebServerPluginProperties

#---------------------------------------------------------------------------------------------------------
# updateWebServerSettings
#
# Update the settings for a WebServer
#---------------------------------------------------------------------------------------------------------
def updateWebServerSettings(webConfigInfo,prefix, serverId,webserverId, existingProps, serverName, serverNode):
  
  try:
    modifiedWebServer = 0
    
    # Support top level WebServer properties
    # Also support old format by mapping keys missing .prop. to format that will work with
    # getPropList
    webserverAttributes = getAttributeNames("WebServer")
    for aName in webserverAttributes:
      if (aName == "name"): continue
      if (webConfigInfo.has_key("%s.%s" % (prefix,aName)) and not webConfigInfo.has_key("%s.prop.%s" % (prefix,aName))):
        webConfigInfo["%s.prop.%s" % (prefix,aName)] = webConfigInfo["%s.%s" % (prefix,aName)]
        
    subProps = getPropListDifferences(webConfigInfo,prefix,existingProps,"webServer")
    if (len(subProps) > 0):
      attrs = propsToAttrList(subProps)
      if (modifyObject(webserverId,attrs)):
        raise StandardError("Unable to update base properties of WebServer %s/%s" % (serverNode,serverName))
      else:
        _app_message("Updated base WebServer properties for WebServer %s/%s" % (serverNode,serverName))
        modifiedWebServer = 1
      
    # See if authentication information has been supplied - we can't compare passwords so any
    # authentication supplied will mean that we need to do an update
    subProps = getPropListDifferences(webConfigInfo, "%s.adminServerAuthentication" % prefix,existingProps,"webServer.adminServerAuthentication")
    temppw = subProps.get("password")
    if (temppw == "*****"):
      # Avoid clearing out valid password
      subProps.remove("password")
      
    if (len(subProps) > 0):
        attrs = []
        for key in subProps.keys():
            val = subProps.get(key)
            attrs.append([key,val])
        
        adminServerAuthenticationId = AdminConfig.showAttribute(webserverId,"adminServerAuthentication")
        if (isEmpty(adminServerAuthenticationId)):
            # Do create
            adminServerAuthenticationId = AdminConfig.create("AdminServerAuthentication",webserverId,attrs)
            _app_message("Created adminServerAuthentication for WebServer %s on %s" % ( serverName, serverNode))
        else:
            if (modifyObject(adminServerAuthenticationId, attrs)):
                _app_message("Error updating adminServerAuthentication for WebServer %s on %s" % ( serverName, serverNode))
                exit()
            else:
                _app_message("Updated adminServerAuthentication for WebServer %s on %s" % ( serverName, serverNode))
        
        modifiedWebServer = 1
                
    
    # stateManagement
    subProps = getPropListDifferences(webConfigInfo, "%s.stateManagement"  % (prefix), existingProps, "webServer.stateManagement" )
    if (subProps.size() > 0):
        modifiedWebServer = 1
        attrs = []
        for key in subProps.keys():
            val = subProps.get(key)
            attrs.append([key,val])
        
        stateManagementId = AdminConfig.showAttribute(webserverId,"stateManagement")
        if (isEmpty(stateManagementId)):
            # do create
            stateManagementId = AdminConfig.create("StateManageable",webserverId,attrs)
            _app_message("Created stateManagement for WebServer %s on %s" % ( serverName, serverNode))
        else:
            if (modifyObject(stateManagementId,attrs)):
                _app_message("Error updating stateManagement for WebServer %s on %s" % ( serverName, serverNode))
                raise StandardError("Error updating stateManagement for WebServer %s on %s" % ( serverName, serverNode))
            else:
                _app_message("Updated stateManagement for WebServer %s on %s" % ( serverName, serverNode))
    
    # ProcessDefinition
    subProps = getPropListDifferences(webConfigInfo,"%s.processDef" % (prefix),existingProps,"webServer.processDef")
    envProps = getPropListDifferences(webConfigInfo,"%s.processDef.environment" % prefix,existingProps,"webServer.processDef.environment")
    #print "ENV_PROPS: %s" % envProps
    execProps = getPropListDifferences(webConfigInfo,"%s.processDef.execution" % prefix,existingProps,"webServer.processDef.execution")
    pd = None
    if (len(subProps) > 0 or len(envProps) > 0 or len(execProps) > 0):
      pd = AdminConfig.list("JavaProcessDef",serverId)
      if (isEmpty(pd)):
        pd = AdminConfig.create("JavaProcessDef",serverId,[["workingDirectory","${WEB_INSTALL_ROOT}"]])
    
      
    
    if (len(subProps) > 0):
      modifiedWebServer = 1
      attrs = propsToAttrList(subProps)
      
      # Special handling for list elements
      clearArgs = []
      if (subProps.get("startCommandArgs") != None):
        clearArgs.append(["startCommandArgs",""])
      if (subProps.get("stopCommandArgs") != None):
        clearArgs.append(["stopCommandArgs",""])
      if (len(clearArgs) > 0):
        if (modifyObject(pd,clearArgs)):
          _app_message("Error clearing startCommandArgs or stopCommandArgs for web server %s/%s" % (serverNode,serverName))
          raise StandardError("Error clearing startCommandArgs or stopCommandArgs for web server %s/%s" % (serverNode,serverName))
        
      if (modifyObject(pd,attrs)):
        _app_message("Error updating process defintion for web server %s/%s" % (serverNode,serverName))
        raise StandardError("Error updating process defintion for web server %s/%s" % (serverNode,serverName))
      else:
        _app_message("Updated process defintion for web server %s/%s" % (serverNode,serverName))
    
    if (len(execProps) > 0):
      modifiedWebServer = 1
      doUpdateCreate("ProcessExecution",pd,execProps,"execution")
      _app_message("Updated ProcessExecution settings for web server %s/%s" % (serverNode,serverName))
    
    if (len(envProps) > 0):
      modifiedWebServer = 1
      errmsg = updateCustomProperties(pd, "environment", "Property", envProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Unable to update WebServer environment properties for WebServer %s/%s" % (serverNode,serverName))
      _app_message("Updated WebServer environment properties for WebServer %s/%s" % (serverNode,serverName))


    # Handle plugin custom properties - Support old and new format
    newFormatProperties = None
    if (webConfigInfo.has_key("%s.properties.count" % prefix)):
      # Old format - convert to new and then call standard function
      newFormatProperties = {}
      idx = 1
      countCustomProps = int(webConfigInfo["%s.properties.count" % (prefix)])
      while (idx <= countCustomProps):
            
            subProps = getPropList(webConfigInfo, "%s.properties.%d" % (prefix,idx),1)
            idx += 1
            if (subProps.size() == 0 or subProps.get("name") == None):
                continue
            
            propertyName = subProps.get("name")
            propertyValue = subProps.get("value")
            propertyDescription = subProps.get("description")
            
            if (isEmpty(propertyDescription)):
              newFormatProperties["temp.properties.prop.%s" % propertyName] = propertyValue
            else:
              newFormatProperties["temp.properties.prop.%s" % propertyName] = "%s|%s" % (propertyValue,propertyDescription)
      
      if (len(newFormatProperties)  > 0):
        if (existingProps != None):
          newFormatProperties = getPropListDifferences(newFormatProperties,"temp.properties" ,existingProps,"webServer.properties")
        else:
          newFormatProperties = getPropList(newFormatProperties,"temp.properties",1)
    else:
      # Pull properties in standard format
      if (existingProps != None):
        newFormatProperties = getPropListDifferences(webConfigInfo,"%s.properties" % prefix,existingProps,"webServer.properties")
      else:
        newFormatProperties = getPropList(webConfigInfo,"%s.properties" % prefix,1)
      
    if (len(newFormatProperties) > 0):
      modifiedWebServer = 1
      errmsg = updateCustomProperties(webserverId, "properties", "Property", newFormatProperties)
      if (isEmpty(errmsg)):
        _app_message("The following custom properties have been updated on server %s/%s : %s" % (serverNode,serverName, newFormatProperties))
      else:
        _app_message("Error updating custom properties have been updated on server %s/%s : %s" % (serverNode,serverName, errmsg))
        exit()
    
    if (not modifiedWebServer):
      _app_message("No updates necessary for WebServer %s/%s" % (serverNode,serverName))
  except:
    _app_exception("Unexpected error in updateWebServerSettings()")

#enddef updateWebServerSettings


#-------------------------------------------------------------------------------
# processIndividualWebServer
#
# Parameters
#
#-------------------------------------------------------------------------------
def processIndividualWebServer(webConfigInfo,prefix,nodeName,webserverName):
  _app_entry("processIndividualWebServer(webConfigInfo,%s,%s,%s)",prefix,nodeName,webserverName)
  retval = None
  try:
      #Check for existing
      serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (nodeName, webserverName))
    
      if not isEmpty(serverId):
        # Do an update
        _app_message("Server %s already exists on Node %s" %( webserverName, nodeName ))
        webserverId = AdminConfig.list("WebServer",serverId)
        existingProps = getWebServerProperties( webserverId)
        updateWebServerPluginProperties(webConfigInfo,prefix, webserverId, existingProps, webserverName, nodeName)
        updateWebServerSettings(webConfigInfo,prefix, serverId,webserverId, existingProps, webserverName, nodeName)
        updateWebServerIntelligentManagementProperties(webConfigInfo,prefix, webserverId, existingProps, webserverName, nodeName)
      else:
        # Otherwise we are creating a new web server
        templateName = getOptionalProperty(webConfigInfo ,"%s.webserverType" % (prefix),"\"\"")
    
        serverConfigAttrs = []
        remoteServerConfigAttrs = []
        
        # Original code supported configuration file in the format
        # app.webserver.1.webserverInstallRoot instead of 
        # app.webserver.1.prop.webserverInstallRoot 
        #
        # We will now support both formats going forward
        #
        # Note that webPort and adminPort are not attributes of WebServer
        # and will not be treated as such
    
        serverConfigAttrs.append(webConfigInfo["%s.webPort" % (prefix)])
        
        if webConfigInfo.has_key("%s.webserverInstallRoot" % (prefix)):
            webServerInstallRoot = webConfigInfo["%s.webserverInstallRoot" % (prefix)]
        else:
            webServerInstallRoot = webConfigInfo.get("%s.prop.webserverInstallRoot"% prefix,'""')
            
        serverConfigAttrs.append(webServerInstallRoot)
        
        serverConfigAttrs.append(webConfigInfo["%s.pluginProperties.prop.PluginInstallRoot" % (prefix)])
        
        if (webConfigInfo.has_key("%s.configurationFilename" % (prefix))):
          configurationFilename = webConfigInfo.get("%s.configurationFilename" % (prefix))
        else:
          configurationFilename = webConfigInfo.get("%s.prop.configurationFilename" % (prefix),'""')
           
        serverConfigAttrs.append(configurationFilename)
        
        serverConfigAttrs.append("\"\"")
        
        logFilenameError = None
        if webConfigInfo.has_key("%s.logFilenameError" % (prefix)):
          logFilenameError = webConfigInfo["%s.logFilenameError" % (prefix)]
        else:
          logFilenameError = webConfigInfo.get("%s.prop.logFilenameError" % (prefix),'""')
          
        serverConfigAttrs.append(logFilenameError)
        
        logFilenameAccess = None
        if webConfigInfo.has_key("%s.logFilenameAccess" % (prefix)):
          logFilenameAccess = webConfigInfo["%s.logFilenameAccess" % (prefix)]
        else:
          logFilenameAccess = webConfigInfo.get("%s.prop.logFilenameAccess" % (prefix),'""')
          
        serverConfigAttrs.append(logFilenameAccess)
        
        webserverProtocol = None
        if webConfigInfo.has_key("%s.webserverProtocol"%prefix):
          webserverProtocol = webConfigInfo.get("%s.webserverProtocol"%prefix)
        else:
          webserverProtocol = webConfigInfo.get("%s.prop.webserverProtocol"%prefix)
        serverConfigAttrs.append(webserverProtocol)
        
        remoteServerConfigAttrs.append(webConfigInfo["%s.adminPort" % (prefix)])
        remoteServerConfigAttrs.append("\"\"")
        remoteServerConfigAttrs.append("\"\"")
        webserverAdminProtocol = None
        if webConfigInfo.has_key("%s.webserverAdminProtocol"%prefix):
          webserverAdminProtocol = webConfigInfo.get("%s.webserverAdminProtocol"%prefix)
        else:
          webserverAdminProtocol = webConfigInfo.get("%s.prop.webserverAdminProtocol"%prefix)
          
        
        
        remoteServerConfigAttrs.append(webserverAdminProtocol)
    
        serverId = createWebServer(webserverName, nodeName, templateName, serverConfigAttrs, remoteServerConfigAttrs)
        if isEmpty(serverId):
          _app_message("Failed to create webserver %s on node %s" % (webserverName, nodeName))
          exit()
        else:
          _app_message("Created webServer %s %s" % (webserverName,serverId))
          
          webserverId = AdminConfig.list("WebServer",serverId)
          
          updateWebServerPluginProperties(webConfigInfo,prefix, webserverId, None, webserverName, nodeName)
            
          updateWebServerSettings(webConfigInfo,prefix, serverId,webserverId, None, webserverName, nodeName)
          
          updateWebServerIntelligentManagementProperties(webConfigInfo,prefix, webserverId, None, webserverName, nodeName)

        
      #endelse create new web server
      
  except:
    _app_exception("Unexpected problem in processIndividualWebServer()")
  
  _app_exit("processIndividualWebServer(retval=%s)" % retval)
  return retval

#-----------------------------------------------------------------
# determineVariableServers
#
# Builds a generated list of node:server names based on other input properties
#-----------------------------------------------------------------
def determineVariableWebServers(serverConfigInfo,prefix):
  
  _app_trace("determineVariableWebServers(serverConfigInfo,%s)" % (prefix))
  
  retval = ""
  
  try:
    # Let's see if the servers are explicitly defined as a single property
    servers = serverConfigInfo.get("%s.variableServers" %  prefix,"")
    if (not isEmpty(servers)):
      # See if it is the correct format "Node:Server Node:Server ..."
      if (servers.find(":") < 0):
        # Support some alternative formats
        namesep = None
        serversep = " "
        if (servers.find("\\") > 0):
          namesep = "\\"
        elif (servers.find("/") > 0):
          namesep = "/"
        elif (servers.find(",") > 0):
          namesep = " "
          serversep = ","
        
        if (namesep != None):
          slist = servers.split(serversep)
          templist = None
          for nodeserver in slist:
            ns = nodeserver.split(namesep)
            if (len(ns) != 2):
              raise StandardError("Invalid server name format")
            
            if (templist == None):
              templist = "%s:%s" % (ns[0],ns[1])
            else:
              templist = "%s %s:%s" % (templist, ns[0],ns[1])
          
          servers = templist
        else:
          raise StandardError("Invalid server name format")
      
      retval = servers   
  except:
    _app_exception("Unexpected problem in determineVariableWebServers")
    
  return retval
#-------------------------------------------------------------------------------------
# processWebServers
#
# Formerly buildCreateWebServers
#---------------------------------------------------------------------------------------------------------
def processWebServers(webConfigInfo):

  
  
  try:
    if not webConfigInfo.has_key("app.webServer.count"):
      _app_message("Skipping Build Web Servers...")
      return
  
    _app_message("Building Web Servers...")
    # Create web servers
    for asidx in range(1, int(webConfigInfo["app.webServer.count"])+1):
      prefix = "app.webServer.%d" % (asidx)
      
      # See if this is a list of similar servers
      webServerNames = determineVariableWebServers(webConfigInfo,prefix)
      if (not isEmpty(webServerNames)):
        
        webServerNamesList = webServerNames.split(" ")
        for nodeServerStr in webServerNamesList:
          nodeServer = nodeServerStr.split(":")
          if (len(nodeServer) != 2):
            _app_message("Skipping invalid web server name: %s" % nodeServerStr)
            continue
          else:
            nodeName = nodeServer[0]
            webserverName = nodeServer[1]
            tempConfigInfo = filterProperties(webConfigInfo,prefix)
            
            tempConfigInfo["%s.nodeName"%prefix] = nodeName
            tempConfigInfo["%s.name"%prefix] = webserverName
            setDynamicId("WEB_SERVER_NAME",webserverName)
            setDynamicId("NODE_NAME",nodeName)
            
            processIndividualWebServer(tempConfigInfo,prefix,nodeName,webserverName)
            
        # Continue on to next item
        continue
      #endif
      
      try:
        webserverName = webConfigInfo["%s.name" % (prefix)]
      except:
        continue
  
      nodeName = webConfigInfo.get("%s.nodeName" % (prefix),"@ITERATE(*)")
      
      if (nodeName.startswith("@ITERATE") or webserverName.startswith("@ITERATE")):
        # This set of properties needs to be applied to multiple web servers
            
        serverNamePattern = parseIterateToRegularExpression(webserverName)
        nodePattern = parseIterateToRegularExpression(nodeName)
        matchingServers = findMatchingWebServers(nodePattern, serverNamePattern)
        if (len(matchingServers) > 0):
          _app_message("%d web servers match the pattern node=%s, server=%s" % (len(matchingServers),nodePattern,serverNamePattern))
          
          for serverInfo in matchingServers:
            tempConfigInfo = filterProperties(webConfigInfo,prefix)
            nodeName,webserverName,serverId,webserverId = serverInfo
            
            tempConfigInfo["nodeName"] = nodeName
            tempConfigInfo["name"] = webserverName
            
            setDynamicId("WEB_SERVER_NAME",webserverName)
            setDynamicId("NODE_NAME",nodeName)

            
            existingProps = getWebServerProperties( webserverId)
            updateWebServerPluginProperties(tempConfigInfo,prefix, webserverId, existingProps, webserverName, nodeName)
            updateWebServerSettings(tempConfigInfo,prefix, serverId,webserverId, existingProps, webserverName, nodeName)
            updateWebServerIntelligentManagementProperties(tempConfigInfo,prefix, webserverId, existingProps, webserverName, nodeName)
        
        #iterate to the next set of configuration properties
        continue
            
      # Not an iteration so....
      processIndividualWebServer(webConfigInfo,prefix,nodeName,webserverName)
      
          
				
  except:
    _app_exception("Unexpected error in processWebServers()")
