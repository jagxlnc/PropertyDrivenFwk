#################################################################################
# ResourceEnvironment.py
# 
# Utility methods for manipulating ResourceEnvironmentProvider and 
# ResourceEnvEntry configuration items.
#
# Requires:
#    Utils.py common.py
#
# Used by:
#    ProcessResourceEnvironment.py
#################################################################################

#-------------------------------------------------------------------------------
# findResourceEnvironmentProviderAtScope
#    Find the configuration ID for a ResourceEnvironmentProvider at the specified
#    scope.
#
# Parameters
#    providerName - Name of ResourceEnvironmentProvider to locate
#    pCluster - Name of Cluster to look under (empty/None if not a cluster resource)
#    pNode - Name of Node to look under (empty/None if not node or server)
#    pServer - Name of server to look under (empty/None if not server)
#
# Returns:
#    Configuration ID if found , None/"" if not
#-------------------------------------------------------------------------------
def findResourceEnvironmentProviderAtScope(providerName,pCluster,pNode,pServer):
  _app_entry("findResourceEnvironmentProviderAtScope(%s,%s,%s,%s)" , providerName,pCluster,pNode,pServer)
  retval = None
  try:
    itemlist = findItemsAtScope("ResourceEnvironmentProvider:%s/" %providerName,cluster=pCluster, node=pNode, server=pServer)
    if (len(itemlist) ==  1):
      retval = itemlist[0]
    elif (len(itemlist) > 1):
      raise StandardError("Unexpected matches for ResourceEnvironmentProvider %s: %s" % (providerName,itemlist))
    
  except:
    _app_exception("Unexpected problem in findResourceEnvironmentProviderAtScope()")
  
  _app_exit("findResourceEnvironmentProviderAtScope(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# createResourceEnvironmentProvider - create a new ResourceEnvironmentProvider
# 
# Parameters
#    parentId - scope configuration item where resource will be defined at
#    pName - name of the new ResourceEnvironmentProvider
#    baseProps - base properties to be updated
#    resourceProps - resource properties to be updated
#    referenceables - a list of (classname,factoryClassname) tuples or
#                     a list of {classname:XYZ,factoryClassname:XYZFactory} dictionaries
#
# Returns:
#   configuration ID of created provider
#-------------------------------------------------------------------------------
def createResourceEnvironmentProvider(parentId,pName,baseProps,resourceProps,referenceables=None):
  _app_entry("createResourceEnvironmentProvider(%s,%s,%s,%s,%s)" , parentId,pName,baseProps,resourceProps,referenceables)
  retval = None
  try:
    baseAttrs = propsToAttrList(baseProps)
    baseAttrs.append(  ["name",pName])
    
    _app_trace('About to call AdminConfig.create("ResourceEnvironmentProvider",%s,%s)' % (parentId,baseAttrs))
    retval = AdminConfig.create("ResourceEnvironmentProvider",parentId,baseAttrs)
    
    if (resourceProps != None and len(resourceProps) > 0):
       updateJ2EEResourcePropertySet(retval, resourceProps, attributeName="propertySet")
    
    if (referenceables != None):
      for refdata in referenceables:
        classname = ""
        factoryClassname = ""
        
        if (type(refdata) == type (())):
          classname = refdata[0]
          factoryClassname = refdata[1]
        else:
          # Assume dictionary
          classname = refdata["classname"]
          factoryClassname = refdata["factoryClassname"]
        
        refattrs = [['classname',classname], ['factoryClassname',factoryClassname]]
        _app_trace('About to call AdminConfig.create("Referenceable",%s,%s)'%(retval,refattrs))
        AdminConfig.create("Referenceable",retval,refattrs)
      #endfor
    #endif    
  except:
    _app_exception("Unexpected problem in createResourceEnvironmentProvider()")
  
  _app_exit("createResourceEnvironmentProvider(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# updateResourceEnvironmentProvider - update an existing ResourceEnvironmentProvider
#
# Parameters
#    providerId - configuration item to be updated
#    baseProps - base properties to be updated
#    resourceProps - resource properties to be updated
#    referenceables - a list of (classname,factoryClassname) tuples or
#                     a list of {classname:XYZ,factoryClassname:XYZFactory} dictionaries
#
#
#-------------------------------------------------------------------------------
def updateResourceEnvironmentProvider(providerId,baseProps,resourceProps,referenceables=None):
  _app_entry("updateResourceEnvironmentProvider(%s,%s,%s,%s)" , providerId,baseProps,resourceProps,referenceables)
  retval = providerId
  try:
    if (baseProps != None and len(baseProps) > 0):
      tempAttrs = []
      if (baseProps.get("classpath") != None):
        tempAttrs.append(["classpath",""])
      if (baseProps.get("nativepath") != None):
        tempAttrs.append(["nativepath",""])
      
      if (len(tempAttrs) > 0):
        if (modifyObject(providerId,tempAttrs)):
          raise StandardError("Unable to clear path attributes in ResourceEnvironmentProvider %s" % providerId)
      
      baseAttrs = propsToAttrList(baseProps)
      if (modifyObject(providerId,baseAttrs)):
        raise StandardError("Unable to update ResourceEnvironmentProvider %s" % providerId)
       
    if (resourceProps != None and len(resourceProps) > 0):
       updateJ2EEResourcePropertySet(retval, resourceProps, attributeName="propertySet")
    
    if (referenceables != None):
      for refdata in referenceables:
        classname = ""
        factoryClassname = ""
        
        if (type(refdata) == type (())):
          classname = refdata[0]
          factoryClassname = refdata[1]
        else:
          # Assume dictionary
          classname = refdata["classname"]
          factoryClassname = refdata["factoryClassname"]
        
        refattrs = [['classname',classname], ['factoryClassname',factoryClassname]]
        _app_trace('About to call AdminConfig.create("Referenceable",%s,%s)'%(retval,refattrs))
        AdminConfig.create("Referenceable",retval,refattrs)
      #endfor
    #endif    
  except:
    _app_exception("Unexpected problem in updateResourceEnvironmentProvider()")
  
  _app_exit("updateResourceEnvironmentProvider(retval=%s)" % retval)
  return retval





  
#-------------------------------------------------------------------------------
# getResourceEnvironmentProviderProperties - Returns a dictionary with key=value
#  pairs that represent the ResourceEnvironmentProvider settings
#
# Parameters:
#   providerId - configuration ID for ResourceEnvironmentProvider
#
# Returns: Dictionary with keys:
#                resourceEnvProvider.prop.XXX = YYY
#                resourceEnvProvider.referenceables.[idx].prop.XXX = YYYY
#                resourceEnvProvider.referenceables.count = [count]
#                resourceEnvProvider.propertySet.resourceProperties.prop.XXX = YYY|YYY|YYY|YYY
# And the special ID values:
#                resourceEnvProvider.referenceables.[idx].CONFIG_ID = configuration ID  
#-------------------------------------------------------------------------------
def getResourceEnvironmentProviderProperties(providerId):
  _app_entry("getResourceEnvironmentProviderProperties(%s)" , providerId)
  retval = {}
  try:
    idDict={}
    collectSimpleProperties(retval, "resourceEnvProvider.prop",providerId, optionalSkipList=[],idProps=idDict,getSimpleChildren=1,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=1,getChildType=0)
    
    for key in idDict.keys():
      if (key.startswith("resourceEnvProvider.referenceables.")):
        retval["%s.CONFIG_ID" %key] = idDict[key]
    
  except:
    _app_exception("Unexpected problem in getResourceEnvironmentProviderProperties()")
  
  _app_exit("getResourceEnvironmentProviderProperties(retval=%d items)" % len(retval))
  return retval



#-------------------------------------------------------------------------------
# findReferenceableInResourceEnvironmentProvider
#    Utility method that will scan the Referenceable configuration items under
#    a ResourceEnvironmentProvider and determine if one is already defined with
#    the specified classname and factoryClassName
#
# Parameters
#   providerId - provider to look under
#   classname - value to search for in Referenceable
#   factoryClassname - value to search for in Referenceable
#
# Returns:
#    Configuration ID of matching Referenceable or None if no match
#-------------------------------------------------------------------------------
def findReferenceableInResourceEnvironmentProvider(providerId,classname,factoryClassname):
  _app_entry("findReferenceableInResourceEnvironmentProvider(%s,%s,%s)" , providerId,classname,factoryClassname)
  retval = None
  try:
    refIds = wsadminToList(AdminConfig.showAttribute(providerId,"referenceables"))
    for refId in refIds:
      if (isEmpty(refId)):
        continue
      props = {}
      collectSimpleProperties(props,"referenceable.prop",refId)
      tempClassname = props.get("referenceable.prop.classname")
      tempFactoryClassname = props.get("referenceable.prop.factoryClassname")
      
      if (tempClassname == classname and tempFactoryClassname == factoryClassname):
        retval = refId
        break
  except:
    _app_exception("Unexpected problem in findReferenceableInResourceEnvironmentProvider()")
  
  _app_exit("findReferenceableInResourceEnvironmentProvider(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# createReferenceableInResourceEnvironmentProvider
#   - Utility method that will create a Referenceable with the specified 
#   attributes under a ResourceEnvironmentProvider
#    
# Parameters
#   providerId - Parent ResourceEnvironmentProvider configuration ID
#   classname - value of clasname attribute for Referenceable
#   factoryClassname - value of factoryClassname attribute for Referenceable
#
# Returns:
#   Configuration ID of created Referenceable
#-------------------------------------------------------------------------------
def createReferenceableInResourceEnvironmentProvider(providerId,classname,factoryClassname):
  _app_entry("createReferenceableInResourceEnvironmentProvider(%s,%s,%s)" , providerId,classname,factoryClassname)
  retval = None
  try:
    refattrs = [['classname',classname], ['factoryClassname',factoryClassname]]
    _app_trace('About to call AdminConfig.create("Referenceable",%s,%s)'%(retval,refattrs))
    retval = AdminConfig.create("Referenceable",providerId,refattrs)
  except:
    _app_exception("Unexpected problem in createReferenceableInResourceEnvironmentProvider()")
  
  _app_exit("createReferenceableInResourceEnvironmentProvider(retval=%s)" % retval)
  return retval
  


#-------------------------------------------------------------------------------
# findResourceEnvEntryAtScope
#
# Parameters
#
#    providerName - Name of parent ResourceEnvironmentProvider to locate under
#    entryName - Name of ResourceEnvEntry
#    pCluster - Name of Cluster to look under (empty/None if not a cluster resource)
#    pNode - Name of Node to look under (empty/None if not node or server)
#    pServer - Name of server to look under (empty/None if not server)
#
# Returns:
#    Configuration ID of the located ResourceEnvEntry, (None or "" if not found)
#-------------------------------------------------------------------------------
def findResourceEnvEntryAtScope(providerName,entryName,pCluster,pNode,pServer):
  _app_entry("findResourceEnvEntryAtScope(%s,%s,%s,%s)" , providerName,pCluster,pNode,pServer)
  retval = None
  try:
    itemlist = findItemsAtScope("ResourceEnvironmentProvider:%s/ResourceEnvEntry:%s/" %(providerName,entryName),cluster=pCluster, node=pNode, server=pServer)
    if (len(itemlist) ==  1):
      retval = itemlist[0]
    elif (len(itemlist) > 1):
      raise StandardError("Unexpected matches for ResourceEnvEntry %s: %s" % (providerName,itemlist))
    
  except:
    _app_exception("Unexpected problem in findResourceEnvEntryAtScope()")
  
  _app_exit("findResourceEnvEntryAtScope(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# createResourceEnvEntry
#   - create a new ResourceEnvEntry configuration item.  This method will also
#     create a corresponding Referenceable configuration item if necessary
#
# Parameters
#   providerId - parent configuration item (ResourceEnvironmentProvider)
#   entryName - name of the new ResourceEnvEntry
#   baseProps - dictionary base properties of ResourceEnvEntry (e.g. jndiName)
#   resourceProps - dictionary with J2C Resource Properties (key=type|required|value[|description])
#   classname - classname attribute of Referenceable to associate with this ResourceEnvEntry
#   factoryClassname - factoryClassname attribute of Referenceable to associate with this ResourceEnvEntry
#
# Returns:
#    Configuration ID of new ResourceEnvEntry
#-------------------------------------------------------------------------------
def createResourceEnvEntry(providerId,entryName,baseProps,resourceProps,classname,factoryClassname):
  _app_entry("createResourceEnvEntry(%s,%s,%s,%s,%s,%s)" ,providerId,entryName,baseProps,resourceProps,classname,factoryClassname)
  retval = None
  try:
    baseAttrs = propsToAttrList(baseProps)
    baseAttrs.append(["name",entryName])
    
    refId = findReferenceableInResourceEnvironmentProvider(providerId,classname,factoryClassname)
    if (isEmpty(refId)):
      refId = createReferenceableInResourceEnvironmentProvider(providerId,classname,factoryClassname)
    baseAttrs.append(["referenceable",refId])
    
    _app_trace('About to call AdminConfig.create("ResourceEnvEntry",%s,%s)' %(providerId,baseAttrs))
    retval = AdminConfig.create('ResourceEnvEntry',providerId,baseAttrs)
    
    if (resourceProps != None and len(resourceProps) > 0):
     updateJ2EEResourcePropertySet(retval, resourceProps, attributeName="propertySet")
     
  except:
    _app_exception("Unexpected problem in createResourceEnvEntry()")
  
  _app_exit("createResourceEnvEntry(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# updateResourceEnvEntry
#   
#   - update an existing ResourceEnvEntry configuration item.  This method will also
#     create a corresponding Referenceable configuration item if necessary
#
# Parameters
#   entryId - target configuration item (ResourceEnvEntry)
#   providerId - parent configuration item (ResourceEnvironmentProvider)
#   baseProps - dictionary base properties of ResourceEnvEntry (e.g. jndiName)
#   resourceProps - dictionary with J2C Resource Properties (key=type|required|value[|description])
#   classname - (optional) classname attribute of Referenceable to associate with this ResourceEnvEntry
#   factoryClassname - (optional) factoryClassname attribute of Referenceable to associate with this ResourceEnvEntry
#
# Returns:
#    Configuration ID of new ResourceEnvEntry
#-------------------------------------------------------------------------------
def updateResourceEnvEntry(entryId,providerId,baseProps=None,resourceProps=None,classname=None,factoryClassname=None):
  _app_entry("updateResourceEnvEntry(%s,%s,%s,%s,%s,%s)" ,entryId,providerId,baseProps,resourceProps,classname,factoryClassname)
  retval = None
  try:
    if (baseProps != None and len(baseProps) > 0 or not isEmpty(classname)):
      baseAttrs = propsToAttrList(baseProps)
      
      if (not isEmpty(classname) and not isEmpty(factoryClassname)):
        refId = findReferenceableInResourceEnvironmentProvider(providerId,classname,factoryClassname)
        if (isEmpty(refId)):
          refId = createReferenceableInResourceEnvironmentProvider(providerId,classname,factoryClassname)
        baseAttrs.append(["referenceable",refId])
    
      if (modifyObject(entryId,baseAttrs)):
        raise StandardError("Unable to update ResourceEnvEntry %s" % entryId)
    
    if (resourceProps != None and len(resourceProps) > 0):
     updateJ2EEResourcePropertySet(entryId, resourceProps, attributeName="propertySet")
    
    retval = entryId 
  except:
    _app_exception("Unexpected problem in updateResourceEnvEntry()")
  
  _app_exit("updateResourceEnvEntry(retval=%s)" % retval)
  return retval
  

#-------------------------------------------------------------------------------
# getResourceEnvEntryProperties
#
# Parameters
#    entryId - Configuration ID of ResourceEnvEntry
#
# Returns dictionary with the keys like so:
#      resourceEnvEntry.prop.name = MyResource1
#      resourceEnvEntry.prop.jndiName = resources/MyOtherResource1
#      resourceEnvEntry.propertySet.resourceProperties.prop.ResourceProp1 = java.lang.String|false|100
#      resourceEnvEntry.propertySet.resourceProperties.prop.ResourceProp2 = java.lang.Boolean|false|true
#      resourceEnvEntry.referenceable.type = Referenceable
#      resourceEnvEntry.referenceable.prop.classname = com.ibm.issw.jjm.MyResource
#      resourceEnvEntry.referenceable.prop.factoryClassname = com.ibm.issw.jjm.MyResourceFactory
#-------------------------------------------------------------------------------
def getResourceEnvEntryProperties(entryId):
  _app_entry("getResourceEnvEntryProperties(%s)" , entryId)
  retval = {}
  try:
    idDict = {}
    collectSimpleProperties(retval, "resourceEnvEntry.prop",entryId, optionalSkipList=[],idProps=idDict,getSimpleChildren=1,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=1,getChildType=0)
    
    referenceable = idDict.get("resourceEnvEntry.prop.referenceable")
    if (not isEmpty(referenceable)):
      collectSimpleProperties(retval,"resourceEnvEntry.referenceable.prop",referenceable)
    
  except:
    _app_exception("Unexpected problem in getResourceEnvEntryProperties()")
  
  _app_exit("getResourceEnvEntryProperties(retval=%s)" % retval)
  return retval

