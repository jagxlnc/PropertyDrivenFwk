################################################################################
# ProcessMail.py
#
# This module contains the functions that process the input properties for MailProvider and
# MailSession definitions.  The properties should have already been loaded into a dictionary
# prior to calling the processMail() function.
#
# Primary function:
#   ProcessMail.py
#
# Related Modules:
#   Mail.py
#   Utils.py
#
#-------------------------------------------------------------------------------
# Property Syntax
#   You can use the dumpConfig.py script with the -mail to produce a property
#   file with the properties for existing MailSession configurations. Below is
#   an example of the format:
#
# -- Scope settings -- 
# app.mail.provider.2.cluster = Beta
# app.mail.provider.2.node = 
# app.mail.provider.2.server = 
# -- Provider Settings--
# app.mail.provider.2.name = Built-in Mail Provider
# app.mail.provider.2.prop.description = The built-in mail provider
# app.mail.provider.2.prop.isolatedClassLoader = false
# -- Protocol Provider Settings --
# app.mail.provider.2.protocolProviders.1.prop.classname = com.sun.mail.smtp.SMTPTransport
# app.mail.provider.2.protocolProviders.1.prop.protocol = smtp
# app.mail.provider.2.protocolProviders.1.prop.type = TRANSPORT
# app.mail.provider.2.protocolProviders.2.prop.classname = com.sun.mail.pop3.POP3Store
# app.mail.provider.2.protocolProviders.2.prop.protocol = pop3
# app.mail.provider.2.protocolProviders.2.prop.type = STORE
# app.mail.provider.2.protocolProviders.3.prop.classname = com.sun.mail.imap.IMAPStore
# app.mail.provider.2.protocolProviders.3.prop.protocol = imap
# app.mail.provider.2.protocolProviders.3.prop.type = STORE
# app.mail.provider.2.protocolProviders.4.prop.classname = com.sun.mail.smtp.SMTPSSLTransport
# app.mail.provider.2.protocolProviders.4.prop.protocol = smtps
# app.mail.provider.2.protocolProviders.4.prop.type = TRANSPORT
# app.mail.provider.2.protocolProviders.5.prop.classname = com.sun.mail.pop3.POP3SSLStore
# app.mail.provider.2.protocolProviders.5.prop.protocol = pop3s
# app.mail.provider.2.protocolProviders.5.prop.type = STORE
# app.mail.provider.2.protocolProviders.6.prop.classname = com.sun.mail.imap.IMAPSSLStore
# app.mail.provider.2.protocolProviders.6.prop.protocol = imaps
# app.mail.provider.2.protocolProviders.6.prop.type = STORE
# -- Mail Session Settings --
# app.mail.provider.2.mailsession.1.name = MailSession1
# app.mail.provider.2.mailsession.1.prop.debug = false
# app.mail.provider.2.mailsession.1.prop.jndiName = mail/SessionOne
# app.mail.provider.2.mailsession.1.prop.mailFrom = john@mymail
# app.mail.provider.2.mailsession.1.prop.mailStoreHost = mymail.jjmw530.ibm.com
# app.mail.provider.2.mailsession.1.prop.mailStorePassword = password
# app.mail.provider.2.mailsession.1.prop.mailStorePort = 1415
# app.mail.provider.2.mailsession.1.prop.mailStoreUser = jjm
# app.mail.provider.2.mailsession.1.prop.mailTransportHost = mymail.jjmw530.ibm.com
# app.mail.provider.2.mailsession.1.prop.mailTransportPassword = password
# app.mail.provider.2.mailsession.1.prop.mailTransportPort = 1901
# app.mail.provider.2.mailsession.1.prop.mailTransportUser = jjm
# app.mail.provider.2.mailsession.1.prop.strict = true
# app.mail.provider.2.mailsession.1.resourceProperties.prop.Property1 = java.lang.String|false|One
# -- The store and transport protocol settings are used to find correct reference --
# app.mail.provider.2.mailsession.1.mailStoreProtocol.prop.protocol = pop3s
# app.mail.provider.2.mailsession.1.mailTransportProtocol.prop.protocol = smtp


# 
################################################################################

#---------------------------------------------------------------------
# ProcessMailSessions
#---------------------------------------------------------------------
def processMailSessions(mailConfigInfo,providerName,scopeString,mailProviderId,prefix):
  _app_trace("processMailSessions(mailConfigInfo,%s,%s,%s,%s)" % (providerName,scopeString,mailProviderId,prefix),"entry")
  try:
    sessionCount = int(mailConfigInfo.get("%s.count"% prefix))
    if (sessionCount > 0):
      for idx in range(1,sessionCount+1):
        sessionPrefix = "%s.%d" % (prefix,idx)
        sessionName = mailConfigInfo.get("%s.name" % sessionPrefix,None)
        if (isEmpty(sessionName)):
          #partial list
          continue
        
        mailSessionId = findMailSession(mailProviderId,sessionName)
        if (isEmpty(mailSessionId)):
          _app_message("MailSession %s in MailProvider '%s' at %s scope does not exist" % (sessionName,providerName,scopeString))
          
          props = getPropList(mailConfigInfo, sessionPrefix)
          resourceProps = getPropList(mailConfigInfo,"%s.resourceProperties"%sessionPrefix)
          storeProps = getPropList(mailConfigInfo,"%s.mailStoreProtocol" % sessionPrefix)
          transportProps = getPropList(mailConfigInfo,"%s.mailTransportProtocol" % sessionPrefix)
          mailSessionId = createMailSession(mailProviderId,sessionName,props,storeProps.get("protocol"),transportProps.get("protocol"),resourceProps)
          _app_message("Created MailSession %s in MailProvider '%s' at %s scope" % (sessionName,providerName,scopeString))
                    
        else:
          _app_message("MailSession %s in MailProvider '%s' at %s is defined" % (sessionName,providerName,scopeString))
          existingProps = getMailSessionProperties(mailSessionId)
          
          props = getPropListDifferences(mailConfigInfo, sessionPrefix, existingProps, "mailsession")
          resourceProps = getPropListDifferences(mailConfigInfo,"%s.resourceProperties"%sessionPrefix,existingProps,"mailsession.resourceProperties")
          
          storeProps = getPropListDifferences(mailConfigInfo,"%s.mailStoreProtocol" % sessionPrefix, existingProps, "mailsession.mailStoreProtocol")
          transportProps = getPropListDifferences(mailConfigInfo,"%s.mailTransportProtocol" % sessionPrefix, existingProps, "mailsession.mailTransportProtocol")
          
          if (len(props) > 0 or len(resourceProps) > 0 or len(storeProps)>0 or len(transportProps)>0):
            updateMailSession(mailProviderId,mailSessionId,props,storeProps.get("protocol"),transportProps.get("protocol"),resourceProps)
            _app_message("Updated MailSession %s" % sessionName)
          else:
            _app_message("No need to update MailSession %s" % sessionName)
          
  except:
    _app_exception("Unexpected error in processMailSessions")
  
  _app_trace("processMailSessions()","exit")



#----------------------------------------------------------------------
# processMailProvider
#----------------------------------------------------------------------
def processMailProvider(mailConfigInfo,providerName,prefix):
  _app_trace("processMailProvider(mailConfigInfo,%s)"% prefix,"entry")
  try:
    clusterName = mailConfigInfo.get("%s.cluster"%prefix,None)
    nodeName = mailConfigInfo.get("%s.node" % prefix,None)
    serverName = mailConfigInfo.get("%s.server"% prefix,None)
    
    scopeString = scopeInfoString(clusterName,nodeName,serverName)
    
    mailProviderId = findMailProviderAtScope(providerName,clusterName,nodeName,serverName)
    if (isEmpty(mailProviderId)):
      _app_message("MailProvider %s not found at %s scope" % (providerName,scopeString))
      
      providerProps = getPropList(mailConfigInfo,prefix)
      resourceProps = getPropList(mailConfigInfo,"%s.resourceProperties" % prefix)
      protocolProps = []
      
      protocolCount = int(mailConfigInfo.get("%s.protocolProviders.count" % prefix,0))
      if (protocolCount > 0):
        for pidx in range(1,protocolCount+1):
          pProps = getPropList(mailConfigInfo, "%s.protocolProviders.%d" % (prefix,pidx))
          protocolProps.append(pProps)
      
      mailProviderId = createMailProvider(providerName,clusterName,nodeName,serverName,providerProps,resourceProps,*protocolProps)
      
      _app_message("Created MailProvider %s at %s scope" % (providerName,scopeString))
      
    else:
      _app_message("MailProvider %s found at %s scope" % (providerName,scopeString))
      
      existingProps = getMailProviderProperties(mailProviderId)
      providerProps = getPropListDifferences(mailConfigInfo,prefix,existingProps,"mailprovider")
      resourceProps = getPropListDifferences(mailConfigInfo,"%s.resourceProperties" % prefix,existingProps,"mailprovider.resourceProperties")
      protocolList = []
      pCount = int(mailConfigInfo.get("%s.protocolProviders.count" % prefix))
      if (pCount > 0):
        for pidx in range(1,pCount+1):
          protocol = mailConfigInfo.get("%s.protocolProviders.%d.prop.protocol" %(prefix,pidx))
          if (protocol != None):
            tempProps = getPropListDifferences(mailConfigInfo,"%s.protocolProviders.%d" % (prefix,pidx),
                                               existingProps.get("protocolProvider.%s" % protocol),"protocolProvider")
            if (len(tempProps) > 0):
              tempProps["protocol"] = protocol
              protocolList.append(tempProps)
      
      if (len(providerProps) > 0 or len(resourceProps) > 0 or len(protocolList) > 0):
        
        updateMailProvider(mailProviderId,providerProps,resourceProps,*protocolList)
        _app_message("MailProvider %s has been updated" % (providerName))
      else:
        _app_message("No updates necessary for MailProvider %s" % (providerName))
      
    processMailSessions(mailConfigInfo,providerName,scopeString,mailProviderId,"%s.mailsession" % prefix)
    
      
  except:
    _app_exception("Unexpected error in processMailProvider")
  
  _app_trace("processMailProvider()","exit")

#---------------------------------------------------------------------
# processMail
#---------------------------------------------------------------------
def processMail(mailConfigInfo):
  _app_trace("processMail()","entry")
  try:
    providerCount = int(mailConfigInfo.get("app.mail.provider.count",0))
    
    for idx in range(1,providerCount+1):
      providerName = mailConfigInfo.get("app.mail.provider.%d.name" % idx)
      if (isEmpty(providerName)):
        # Partial list
        continue
        
      processMailProvider(mailConfigInfo,providerName,"app.mail.provider.%d" % idx)
    
  
  except:
    _app_exception("Unexpected error in processMail")
    
  _app_trace("processMail()","exit")