###############################################################################
# ProcessSIBJMS.py
#
# This file contains the methods that process the SIB JMS resource definitions in 
# the configInfo dictionary.
#
# Primary function:
#			processSIBJMS()
#
# Related Modules:
#			Utils.py - common utilities
#     dumpConfig.py - exports existing SIBus JMS resources in property syntax
# 		SIBJMSActivationSpec.py
# 		SIBJMSConnectionFactory.py
#			SIBJMSQueue.py
#     SIBJMSTopic.py
#
# Syntax overview. Use the dumpConfig.py -sibjms option to produce a property file
# built from existing configuration.
#
# -----------------------------------
# SIBJMS Provider - used to locate the provider at the specific scope. Properties
# are not updated.
# -----------------------------------
# app.sibjms.provider.1.cluster = SampleCluster
# app.sibjms.provider.1.node = 
# app.sibjms.provider.1.server = 
# app.sibjms.provider.1.archivePath = ${WAS_INSTALL_ROOT}/installedConnectors/sib.api.jmsra.rar
# app.sibjms.provider.1.classpath = ${WAS_INSTALL_ROOT}/installedConnectors/sib.api.jmsra.rar
# app.sibjms.provider.1.description = Default messaging provider
# app.sibjms.provider.1.name = SIB JMS Resource Adapter
# app.sibjms.provider.1.threadPoolAlias = Default
# app.sibjms.provider.1.genericConnectionFactories.count = 0
# ...
# app.sibjms.provider.count = <max index>
#
# -----------------------------------
# Queue Connection Factory examples:
# -----------------------------------
# app.sibjms.provider.1.queueConnectionFactories.1.name = SampleSIBQueueCF
# app.sibjms.provider.1.queueConnectionFactories.1.prop.logMissingTransactionContext = false
# app.sibjms.provider.1.queueConnectionFactories.1.prop.password = 
# app.sibjms.provider.1.queueConnectionFactories.1.prop.readAhead = Default
# app.sibjms.provider.1.queueConnectionFactories.1.prop.tempQueueNamePrefix = 
# app.sibjms.provider.1.queueConnectionFactories.1.prop.shareDurableSubscriptions = InCluster
# app.sibjms.provider.1.queueConnectionFactories.1.prop.targetTransportChain = 
# app.sibjms.provider.1.queueConnectionFactories.1.prop.authDataAlias = ConfigurationScriptingDmgr/Dude
# app.sibjms.provider.1.queueConnectionFactories.1.prop.userName = 
# app.sibjms.provider.1.queueConnectionFactories.1.prop.targetSignificance = Preferred
# app.sibjms.provider.1.queueConnectionFactories.1.prop.shareDataSourceWithCMP = false
# app.sibjms.provider.1.queueConnectionFactories.1.prop.persistentMapping = ReliablePersistent
# app.sibjms.provider.1.queueConnectionFactories.1.prop.providerEndPoints = 
# app.sibjms.provider.1.queueConnectionFactories.1.prop.nonPersistentMapping = ExpressNonPersistent
# app.sibjms.provider.1.queueConnectionFactories.1.prop.jndiName = jms/SampleSIBQueueCF
# app.sibjms.provider.1.queueConnectionFactories.1.prop.clientID = 
# app.sibjms.provider.1.queueConnectionFactories.1.prop.manageCachedHandles = false
# app.sibjms.provider.1.queueConnectionFactories.1.prop.category = 
# app.sibjms.provider.1.queueConnectionFactories.1.prop.targetType = BusMember
# app.sibjms.provider.1.queueConnectionFactories.1.prop.busName = SampleBus
# app.sibjms.provider.1.queueConnectionFactories.1.prop.description = 
# app.sibjms.provider.1.queueConnectionFactories.1.prop.xaRecoveryAuthAlias = Dude3
# app.sibjms.provider.1.queueConnectionFactories.1.prop.connectionProximity = Bus
# app.sibjms.provider.1.queueConnectionFactories.1.prop.target = SampleCluster
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.agedTimeout = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.connectionTimeout = 180
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.freePoolDistributionTableSize = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.maxConnections = 10
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.minConnections = 1
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.numberOfFreePoolPartitions = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.numberOfSharedPoolPartitions = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.numberOfUnsharedPoolPartitions = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.purgePolicy = EntirePool
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.reapTime = 180
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.stuckThreshold = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.stuckTime = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.stuckTimerTime = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.surgeCreationInterval = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.surgeThreshold = -1
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.testConnection = false
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.testConnectionInterval = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.unusedTimeout = 1800
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.customProperties.prop.customProp1 = CustomVal1|This is my cp custom prop
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.customProperties.prop.customProp2 = CustomVal2
# ...
# app.sibjms.provider.1.queueConnectionFactories.count = <max index for queue connection factory>
#
# ----------------------------------------------------------------
# Topic connection factory example
# ----------------------------------------------------------------
# app.sibjms.provider.1.topicConnectionFactories.1.name = SampleSIBTopicCF
# app.sibjms.provider.1.topicConnectionFactories.1.prop.logMissingTransactionContext = false
# app.sibjms.provider.1.topicConnectionFactories.1.prop.password = 
# app.sibjms.provider.1.topicConnectionFactories.1.prop.readAhead = Default
# app.sibjms.provider.1.topicConnectionFactories.1.prop.shareDurableSubscriptions = InCluster
# app.sibjms.provider.1.topicConnectionFactories.1.prop.durableSubscriptionHome = SampleCluster.000-SampleBus
# app.sibjms.provider.1.topicConnectionFactories.1.prop.targetTransportChain = 
# app.sibjms.provider.1.topicConnectionFactories.1.prop.authDataAlias = ConfigurationScriptingDmgr/Dude
# app.sibjms.provider.1.topicConnectionFactories.1.prop.userName = 
# app.sibjms.provider.1.topicConnectionFactories.1.prop.targetSignificance = Preferred
# app.sibjms.provider.1.topicConnectionFactories.1.prop.shareDataSourceWithCMP = false
# app.sibjms.provider.1.topicConnectionFactories.1.prop.persistentMapping = ReliablePersistent
# app.sibjms.provider.1.topicConnectionFactories.1.prop.providerEndPoints = 
# app.sibjms.provider.1.topicConnectionFactories.1.prop.nonPersistentMapping = ExpressNonPersistent
# app.sibjms.provider.1.topicConnectionFactories.1.prop.jndiName = jms/SampleSIBTopicCF
# app.sibjms.provider.1.topicConnectionFactories.1.prop.clientID = 
# app.sibjms.provider.1.topicConnectionFactories.1.prop.manageCachedHandles = false
# app.sibjms.provider.1.topicConnectionFactories.1.prop.category = 
# app.sibjms.provider.1.topicConnectionFactories.1.prop.targetType = ME
# app.sibjms.provider.1.topicConnectionFactories.1.prop.busName = SampleBus
# app.sibjms.provider.1.topicConnectionFactories.1.prop.description = 
# app.sibjms.provider.1.topicConnectionFactories.1.prop.xaRecoveryAuthAlias = ConfigurationScriptingDmgr/Dude2
# app.sibjms.provider.1.topicConnectionFactories.1.prop.tempTopicNamePrefix = 
# app.sibjms.provider.1.topicConnectionFactories.1.prop.connectionProximity = Cluster
# app.sibjms.provider.1.topicConnectionFactories.1.prop.target = SampleCluster.000.-SampleBus
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.agedTimeout = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.connectionTimeout = 180
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.freePoolDistributionTableSize = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.maxConnections = 10
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.minConnections = 1
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.numberOfFreePoolPartitions = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.numberOfSharedPoolPartitions = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.numberOfUnsharedPoolPartitions = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.purgePolicy = EntirePool
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.reapTime = 180
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.stuckThreshold = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.stuckTime = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.stuckTimerTime = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.surgeCreationInterval = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.surgeThreshold = -1
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.testConnection = false
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.testConnectionInterval = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.unusedTimeout = 1800
# ...
# app.sibjms.provider.1.topicConnectionFactories.count = <max index>
#
# ---------------------------------------------------------------
# Generic connection factory example
# ---------------------------------------------------------------
# app.sibjms.provider.2.genericConnectionFactories.1.name = Cell Scoped Gen CF
# app.sibjms.provider.2.genericConnectionFactories.1.prop.logMissingTransactionContext = true
# app.sibjms.provider.2.genericConnectionFactories.1.prop.password = 
# app.sibjms.provider.2.genericConnectionFactories.1.prop.readAhead = AlwaysOn
# app.sibjms.provider.2.genericConnectionFactories.1.prop.tempQueueNamePrefix = TempQueue
# app.sibjms.provider.2.genericConnectionFactories.1.prop.shareDurableSubscriptions = InCluster
# app.sibjms.provider.2.genericConnectionFactories.1.prop.durableSubscriptionHome = SampleCluster.000-SampleBus
# app.sibjms.provider.2.genericConnectionFactories.1.prop.targetTransportChain = 
# app.sibjms.provider.2.genericConnectionFactories.1.prop.authDataAlias = ConfigurationScriptingDmgr/Dude
# app.sibjms.provider.2.genericConnectionFactories.1.prop.userName = 
# app.sibjms.provider.2.genericConnectionFactories.1.prop.targetSignificance = Required
# app.sibjms.provider.2.genericConnectionFactories.1.prop.shareDataSourceWithCMP = false
# app.sibjms.provider.2.genericConnectionFactories.1.prop.persistentMapping = ReliablePersistent
# app.sibjms.provider.2.genericConnectionFactories.1.prop.providerEndPoints = 
# app.sibjms.provider.2.genericConnectionFactories.1.prop.nonPersistentMapping = ExpressNonPersistent
# app.sibjms.provider.2.genericConnectionFactories.1.prop.jndiName = jms/CellScopedGenCF
# app.sibjms.provider.2.genericConnectionFactories.1.prop.clientID = 
# app.sibjms.provider.2.genericConnectionFactories.1.prop.manageCachedHandles = true
# app.sibjms.provider.2.genericConnectionFactories.1.prop.category = 
# app.sibjms.provider.2.genericConnectionFactories.1.prop.targetType = BusMember
# app.sibjms.provider.2.genericConnectionFactories.1.prop.busName = SampleBus
# app.sibjms.provider.2.genericConnectionFactories.1.prop.description = 
# app.sibjms.provider.2.genericConnectionFactories.1.prop.xaRecoveryAuthAlias = ConfigurationScriptingDmgr/Dude2
# app.sibjms.provider.2.genericConnectionFactories.1.prop.tempTopicNamePrefix = TempTopic
# app.sibjms.provider.2.genericConnectionFactories.1.prop.connectionProximity = Cluster
# app.sibjms.provider.2.genericConnectionFactories.1.prop.target = SampleCluster
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.agedTimeout = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.connectionTimeout = 180
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.freePoolDistributionTableSize = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.maxConnections = 10
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.minConnections = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.numberOfFreePoolPartitions = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.numberOfSharedPoolPartitions = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.numberOfUnsharedPoolPartitions = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.purgePolicy = EntirePool
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.reapTime = 180
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.stuckThreshold = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.stuckTime = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.stuckTimerTime = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.surgeCreationInterval = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.surgeThreshold = -1
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.testConnection = false
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.testConnectionInterval = 0
# app.sibjms.provider.2.genericConnectionFactories.1.connectionPool.prop.unusedTimeout = 1800
# ...
# app.sibjms.provider.2.genericConnectionFactories.count = <max index>
#
# --------------------------------------------------------
# Activation Spec example
# --------------------------------------------------------
# app.sibjms.provider.2.activationSpecs.1.name = ActSpec1
# app.sibjms.provider.2.activationSpecs.1.prop.destinationJndiName = jms/AlphaQueue
# app.sibjms.provider.2.activationSpecs.1.prop.password = 
# app.sibjms.provider.2.activationSpecs.1.prop.providerEndpoints = 
# app.sibjms.provider.2.activationSpecs.1.prop.readAhead = Default
# app.sibjms.provider.2.activationSpecs.1.prop.subscriptionDurability = NonDurable
# app.sibjms.provider.2.activationSpecs.1.prop.destinationType = javax.jms.Queue
# app.sibjms.provider.2.activationSpecs.1.prop.shareDurableSubscriptions = InCluster
# app.sibjms.provider.2.activationSpecs.1.prop.durableSubscriptionHome = 
# app.sibjms.provider.2.activationSpecs.1.prop.acknowledgeMode = Auto-acknowledge
# app.sibjms.provider.2.activationSpecs.1.prop.targetTransportChain = 
# app.sibjms.provider.2.activationSpecs.1.prop.maxBatchSize = 10
# app.sibjms.provider.2.activationSpecs.1.prop.messageSelector = 
# app.sibjms.provider.2.activationSpecs.1.prop.userName = 
# app.sibjms.provider.2.activationSpecs.1.prop.targetSignificance = Preferred
# app.sibjms.provider.2.activationSpecs.1.prop.maxSequentialMessageFailure = -1
# app.sibjms.provider.2.activationSpecs.1.prop.shareDataSourceWithCMP = false
# app.sibjms.provider.2.activationSpecs.1.prop.jndiName = jms/ActSpec1
# app.sibjms.provider.2.activationSpecs.1.prop.destination = 
# app.sibjms.provider.2.activationSpecs.1.prop.targetType = BusMember
# app.sibjms.provider.2.activationSpecs.1.prop.subscriptionName = 
# app.sibjms.provider.2.activationSpecs.1.prop.busName = SampleBus
# app.sibjms.provider.2.activationSpecs.1.prop.description = 
# app.sibjms.provider.2.activationSpecs.1.prop.maxConcurrency = 5
# app.sibjms.provider.2.activationSpecs.1.prop.authenticationAlias = ConfigurationScriptingDmgr/Dude
# app.sibjms.provider.2.activationSpecs.1.prop.clientId = 
# app.sibjms.provider.2.activationSpecs.1.prop.target = SampleCluster
# ...
# app.sibjms.provider.2.activationSpecs.count = <max index>
#
# ----------------------------------------------
# SIBJMSQueue definitions
# ----------------------------------------------
# app.sibjms.provider.2.queues.1.name = MyAlphaQueue
# app.sibjms.provider.2.queues.1.prop.queueName = Alpha
# app.sibjms.provider.2.queues.1.prop.jndiName = jms/MyAlpha
# app.sibjms.provider.2.queues.1.prop.readAhead = AlwaysOff
# app.sibjms.provider.2.queues.1.prop.busName = SampleBus
# app.sibjms.provider.2.queues.1.prop.priority = 5
# app.sibjms.provider.2.queues.1.prop.deliveryMode = Application
# app.sibjms.provider.2.queues.1.prop.description = 
# app.sibjms.provider.2.queues.1.prop.timeToLive = 1000
# ...
# app.sibjms.provider.2.queues.count = <max index>
# 
# ------------------------------------------------------
# SIBJMSTopic Definitions
# ------------------------------------------------------
# app.sibjms.provider.2.topics.1.name = DefaultTopic
# app.sibjms.provider.2.topics.1.prop.topicName = DefaultTopic
# app.sibjms.provider.2.topics.1.prop.jndiName = jms/DefaultTopic
# app.sibjms.provider.2.topics.1.prop.readAhead = AsConnection
# app.sibjms.provider.2.topics.1.prop.busName = SampleBus
# app.sibjms.provider.2.topics.1.prop.topicSpace = Default.Topic.Space
# app.sibjms.provider.2.topics.1.prop.priority = 
# app.sibjms.provider.2.topics.1.prop.deliveryMode = Application
# app.sibjms.provider.2.topics.1.prop.description = 
# app.sibjms.provider.2.topics.1.prop.timeToLive = 100000
#
# app.sibjms.provider.2.topics.count = <max index>
#
#------------------------------------------------------------------------
# Wildcard pattern matching
#
# The @ITERATE(pattern) syntax can be used to match against provider scope
# and/or the names of connection factories, queues, topics, or activation specs.
# The settings in the properties will be applied to all configuration items
# that match the pattern.
#------------------------------------------------------------------------
# 
# Wildcard examples:
#
# 1) Matching against all providers for clusters starting with Sample*
# app.sibjms.provider.1.cluster = @ITERATE(Sample*)
# app.sibjms.provider.1.node = 
# app.sibjms.provider.1.server = 
# app.sibjms.provider.1.name = SIB JMS Resource Adapter
#
# 2) Applying settings to all connection factories that match a pattern at cell scope:
#
# app.sibjms.provider.1.cluster =
# app.sibjms.provider.1.node = 
# app.sibjms.provider.1.server = 
# app.sibjms.provider.1.name = SIB JMS Resource Adapter
#
# app.sibjms.provider.1.genericConnectionFactories.1.name = @ITERATE(*)
# app.sibjms.provider.1.genericConnectionFactories.1.prop.logMissingTransactionContext = false
# app.sibjms.provider.1.genericConnectionFactories.1.prop.persistentMapping = ReliablePersistent
# app.sibjms.provider.1.genericConnectionFactories.1.prop.nonPersistentMapping = ExpressNonPersistent
# app.sibjms.provider.1.genericConnectionFactories.1.connectionPool.prop.agedTimeout = 0
# app.sibjms.provider.1.genericConnectionFactories.1.connectionPool.prop.connectionTimeout = 30
# app.sibjms.provider.1.genericConnectionFactories.1.connectionPool.prop.maxConnections = 10
# app.sibjms.provider.1.genericConnectionFactories.1.connectionPool.prop.minConnections = 0
# app.sibjms.provider.1.genericConnectionFactories.count = 1

# app.sibjms.provider.1.queueConnectionFactories.1.name = @ITERATE(*)
# app.sibjms.provider.1.queueConnectionFactories.1.prop.logMissingTransactionContext = false
# app.sibjms.provider.1.queueConnectionFactories.1.prop.persistentMapping = ReliablePersistent
# app.sibjms.provider.1.queueConnectionFactories.1.prop.nonPersistentMapping = ExpressNonPersistent
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.agedTimeout = 0
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.connectionTimeout = 30
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.maxConnections = 10
# app.sibjms.provider.1.queueConnectionFactories.1.connectionPool.prop.minConnections = 0
# app.sibjms.provider.1.queueConnectionFactories.count = 1

# app.sibjms.provider.1.topicConnectionFactories.1.name = @ITERATE(*)
# app.sibjms.provider.1.topicConnectionFactories.1.prop.logMissingTransactionContext = false
# app.sibjms.provider.1.topicConnectionFactories.1.prop.persistentMapping = ReliablePersistent
# app.sibjms.provider.1.topicConnectionFactories.1.prop.nonPersistentMapping = ExpressNonPersistent
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.agedTimeout = 0
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.connectionTimeout = 30
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.maxConnections = 10
# app.sibjms.provider.1.topicConnectionFactories.1.connectionPool.prop.minConnections = 0
# app.sibjms.provider.1.topicConnectionFactories.count = 1
# 
# 3) Applying settings to all Queues that have the string "Yet" in the name (at cell scope):
#
# app.sibjms.provider.1.cluster =
# app.sibjms.provider.1.node = 
# app.sibjms.provider.1.server = 
# app.sibjms.provider.1.name = SIB JMS Resource Adapter
#
# app.sibjms.provider.1.queues.1.name = @ITERATE(*Yet*)
# app.sibjms.provider.1.queues.1.prop.timeToLive = 3003
#
# 4) Applying settings to all Topics at cell scope
#
# app.sibjms.provider.1.cluster =
# app.sibjms.provider.1.node = 
# app.sibjms.provider.1.server = 
# app.sibjms.provider.1.name = SIB JMS Resource Adapter
#
# app.sibjms.provider.2.topics.3.name = @ITERATE(*)
# app.sibjms.provider.2.topics.3.prop.timeToLive = 15000
#
# 5) Applying settings to all Activation Specs with the string "MyApp" in the name
#
# app.sibjms.provider.1.cluster =
# app.sibjms.provider.1.node = 
# app.sibjms.provider.1.server = 
# app.sibjms.provider.1.name = SIB JMS Resource Adapter
#
# app.sibjms.provider.1.activationSpecs.1.name = @ITERATE(*MyApp*)
# app.sibjms.provider.1.activationSpecs.1.prop.maxBatchSize = 25
# app.sibjms.provider.1.activationSpecs.1.prop.maxConcurrency = 25
# app.sibjms.provider.1.activationSpecs.1.prop.autoStopSequentialMessageFailure = 15
#
#-------------------------------------------------------------------------------
# Creating Multiple Resources that map to specific Messaging Engines
#
# In some cases, you will want to create resources at server or node scope 
# that map to different messagine engines or message engine exception queues.
# The @ME_PARTITION macro allows this to be done with one set of definitions.
#
# The macro works by using the cluster name to determine the servers to create
# resources for and a list of nodes hosting messaging engines to determine the
# distribution and count of SIBus configuration items.
#
# The cluster name is pulled from the cluster scope setting of the provider and
# the messaging engine nodes are specified as the argument of the @ME_PARTITION
# macro. The ME_PARTITION macro can be specified in either the .node or .server
# scope setting of the provider. Where its declared decides if the generated 
# resources are at node scope or server scope.
# 
# If a cluster member or node is on the same node as a messaging engine,
# the corresponding resource will be created with keyword values that
# references the local messaging engine. The remaining cluster members are
# assigned round-robin to reference the messaging engines.
#
# Example 1: In this example, we use the @ME_PARTION macro to create a JMS
# Queue definition for each member of the DynamicClientCluster. After the 
# definition has been processed, cluster members on Node1, Node3, and Node5
# will reference the exception destinations 000,001,002 respectively and 
# the other cluster members will have their references defined in a round-robin
# distribution.  (Node2 will reference 000, Node4 will reference 001, and Node6
# will reference 002)
#
# app.sibjms.provider.1.cluster = DynamicClientCluster
# app.sibjms.provider.1.server = @ME_PARTITION(Node1,Node3,Node5)
#
# app.sibjms.provider.1.queues.1.name = DynamicTestBus_SystemExceptionQueue
# app.sibjms.provider.1.queues.1.prop.queueName = _SYSTEM.Exception.Destination.DynamicTestCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-DynamicTestBus
# app.sibjms.provider.1.queues.1.prop.jndiName = jms/SystemExceptionQueue
#
#-------------------------------------------------------------------------------
#
# Deleting SIBus JMS Resources
#
# This script also supports the deletion of JMS resources as specified by the 
# del.sibjms.provider properties in the configuration information.  In addition to
# the deletion, there is support for moving the deleted configuration to a different
# scope.
#
# The deletion functions also support the @ITERATE syntax to delete/move multiple
# configuration items.
#
# Example: Deleting a SIB JMS connection factory
#
# del.sibjms.provider.2.cluster = 
# del.sibjms.provider.2.node = 
# del.sibjms.provider.2.server = 
#
#
# del.sibjms.provider.2.queueConnectionFactories.1.name = MyQueueCF
# del.sibjms.provider.2.queueConnectionFactories.2.name = MySecondQueueCF
#
# del.sibjms.provider.2.topicConnectionFactories.1.name = MyTopicCF
# 
# del.sibjms.provider.2.genericConnectionFactories.1.name = MyCF
#
# Example: Deleting connection factories that match a certain pattern.
#
# del.sibjms.provider.2.cluster = 
# del.sibjms.provider.2.node = 
# del.sibjms.provider.2.server = 
#
#
# del.sibjms.provider.2.queueConnectionFactories.1.name = @ITERATE(My*)
# del.sibjms.provider.2.topicConnectionFactories.1.name = @ITERATE(My*)
# del.sibjms.provider.2.genericConnectionFactories.1.name = @ITERATE(My*)
#
#
# Example: Moving a connection factory from Cell scoped to cluster scoped.
# The moveProvider settings specify the scope that the listed resources will
# be moved to. Note that only specified resources are moved.
#
# del.sibjms.provider.2.cluster = 
# del.sibjms.provider.2.node = 
# del.sibjms.provider.2.server = 
# del.sibjms.provider.2.moveProvider = true
# del.sibjms.provider.2.moveProvider.cluster = DynamicTestCluster
# del.sibjms.provider.2.moveProvider.node =
# del.sibjms.provider.2.moveProvider.server =
#
# del.sibjms.provider.2.queueConnectionFactories.1.name = MyQueueCF
#
# Example: Deleting Queues, Topics, and Activation Specs
#
# del.sibjms.provider.1.cluster = MyCluster
# del.sibjms.provider.1.node = 
# del.sibjms.provider.1.server = 
#
# del.sibjms.provider.1.topics.1.name = TopicOne
# del.sibjms.provider.1.topics.2.name = TopicTwo
#
# del.sibjms.provider.1.queues.1.name = QueueOne
# del.sibjms.provider.1.queues.2.name = QueueTwo
#
# del.sibjms.provider.1.activationSpecs.1.name = MyActSpec
#
# Example: Deleting Queues, Topics, and Activation Specs 
# that match a pattern.
#
# del.sibjms.provider.1.cluster = MyCluster
# del.sibjms.provider.1.node = 
# del.sibjms.provider.1.server = 
#
# del.sibjms.provider.1.topics.1.name = @ITERATE(*My*)
#
# del.sibjms.provider.1.queues.1.name = @ITERATE(*My*)
#
# del.sibjms.provider.1.activationSpecs.1.name = @ITERATE(*My*)
#
# Example: Moving all JMS configuration items that match a 
# pattern to a different scope.
#
# del.sibjms.provider.1.cluster = 
# del.sibjms.provider.1.node = 
# del.sibjms.provider.1.server = 
# del.sibjms.provider.1.moveProvider = true
# del.sibjms.provider.1.moveProvider.cluster = DynamicTestCluster
# del.sibjms.provider.1.moveProvider.node =
# del.sibjms.provider.1.moveProvider.server =
#
# del.sibjms.provider.1.queueConnectionFactories.1.name = @ITERATE(My*)
# del.sibjms.provider.1.topicConnectionFactories.1.name = @ITERATE(My*)
# del.sibjms.provider.1.genericConnectionFactories.1.name = @ITERATE(My*)
#
# del.sibjms.provider.1.topics.1.name = @ITERATE(*My*)
# del.sibjms.provider.1.queues.1.name = @ITERATE(*My*)#
# del.sibjms.provider.1.activationSpecs.1.name = @ITERATE(*My*)
#
# Example: Deleting a resource at server scope across all cluster 
# members.
#
# del.sibjms.provider.2.cluster = 
# del.sibjms.provider.2.node = 
# del.sibjms.provider.2.server = @CLUSTERMEMBERS(DynamicClientCluster)
#
# del.sibjms.provider.2.queues.1.name = DynamicTestBus_SystemExceptionQueue
#
#
###############################################################################


#----------------------------------------------------------------------------------------
# determineMessagingEngineKeywordsByNode
#
# The @ME_PARTITION macro is used to create a set of resources that reference different
# message engines in a messaging cluster. The resources will be created one-per-node or 
# one-per-server. To support this ability, this function will iterate through the nodes 
# in a cluster and associate each node with a particular message engine, where the message 
# engines are specified by the node that they reside on. The association
# is implemented by associating with each cluster node a set of keyword values for @{DYNAMIC,KEYWORD} 
# substitution as the resource is created.  
#
#----------------------------------------------------------------------------------------
def determineMessagingEngineKeywordsByNode(clusterName,messagingEngineNodes):
  _app_trace("determineMessagingEngineKeywordsByNode(%s,%s)"% (clusterName,messagingEngineNodes),"entry")
  retval = {}
  try:
    clusterNodes = getClusterMemberNodeList(clusterName)
    clusterNodes.sort()
     
    meNodes = [node for node in messagingEngineNodes]
    meNodes.sort()
    #print "MENodes: %s" % meNodes
     
    # Seed the retval with an entry for each messaging node
    idx = 0
    meVals = {}
    for meNode in meNodes:
      nodeDict = {}
      nodeDict["CURRENT_NODE_NAME"] = meNode
      nodeDict["ME_INDEX0"] = str(idx).zfill(3)
      nodeDict["ME_INDEX"] = str(idx+1).zfill(3)
      nodeDict["SERVER_INDEX0"] = str(idx).zfill(3)
      nodeDict["SERVER_INDEX"] = str(idx+1).zfill(3)
      
      
      idx += 1
      meVals[meNode] = nodeDict
     
      if (meNode in clusterNodes):
        retval[meNode] = nodeDict
        clusterNodes.remove(meNode)
    #endfor
     
    # Now associate remaining cluster nodes with messaging nodes
    # By distributing the nodes accoss the messaging nodes
    while (len(clusterNodes) > 0):
      for meNode in meNodes:
        if (len(clusterNodes) == 0):
          break
        
        clusterNode = clusterNodes.pop(0)
        nodeDict = {}
        meNodeDict = meVals[meNode]
        for key in meNodeDict.keys():
          nodeDict[key] = meNodeDict[key]
        
        nodeDict["CURRENT_NODE_NAME"] = clusterNode
        retval[clusterNode] = nodeDict
      #endfor
    #endwhile
  
  except:
    _app_trace("Unexpected error in determineMessagingEngineKeywordsByNode(%s,%s)" % (clusterName,messagingEngineNodes))
    raise StandardError("Unexpected error in determineMessagingEngineKeywordsByNode(%s,%s)" % (clusterName,messagingEngineNodes))
  
  _app_trace("determineMessagingEngineKeywordsByNode()","exit")
  return retval
  

#----------------------------------------------------------------------------------------
# processSingleSIBJMSActivationSpec
#
# Processes the activation specification definition for a single activate spec
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     actspecIndex - Prefix for activationSpec (app.sibjms.provider.<idx>.activationSpecs.<idx> )
#     actSpecId - the specification configuration ID if it is already known
#----------------------------------------------------------------------------------------
def processSingleSIBJMSActivationSpec(jmsInfo,cluster,node,server,actspecIndex,actSpecId=None):


  
  try:
      _app_trace("processSingleSIBJMSActivationSpec(%s,%s,%s,%s,%s)" % (cluster,node,server,actspecIndex,actSpecId), "entry")
      

      scopeString = scopeInfoString(cluster,node,server)
      jmsInfo = toDictionary(jmsInfo)
      actSpecName = jmsInfo.get("%s.name" % actspecIndex, "")
      if (not isEmpty(actSpecName)):
              
          # See if the activation spec is already defined
          existingProps = getSIBJMSActivationSpecProperties(cluster, node, server, actSpecName,actSpecId)
          if (existingProps == None):
              _app_message("Error checking for existing activation spec %s at %s scope" % (actSpecName,scopeString))
              exit()
          
          if (existingProps.size() == 0):
              # The activation spec is not currently defined
              actSpecProps = getPropList(jmsInfo, actspecIndex,1)
              
              # Pull the required properties from the properties set
              jndiName = actSpecProps.remove("jndiName")
              destJNDIName = actSpecProps.remove("destinationJndiName")
              
              retval = createSIBJMSActivationSpec(actSpecName, cluster, node, server,jndiName,  destJNDIName, actSpecProps)
              
              if (isEmpty(retval)):
                  _app_message("Error creating activation spec %s at %s scope" % (actSpecName,scopeString))
                  exit()
              else:
                  _app_message("Created activation spec %s at %s scope" % (actSpecName,scopeString))
              
          else:
              # The activation spec is currently defined
              actSpecProps = getPropListDifferences(jmsInfo, actspecIndex, existingProps, "activationSpec")
              
              if (actSpecProps.size() == 0):
                  _app_message("No updates required for activation spec %s at %s scope" % (actSpecName,scopeString))
              else:
              
                retval = modifySIBJMSActivationSpec(actSpecName, cluster, node, server, actSpecProps)
                if (isEmpty(retval)):
                    _app_message("Error modifying activation spec %s at %s scope" % (actSpecName,scopeString))
                    exit()
                else:
                    _app_message("Modified activation spec %s at %s scope" % (actSpecName,scopeString))
      
  except:
      _app_trace("Unexpected error processing SIBJMSActivationSpec","exception")
      _app_message("Unexpected error processing SIBJMSActivationSpec")
      exit()
  
  _app_trace("processSingleSIBJMSActivationSpec()", "exit")


#----------------------------------------------------------------------------------------
# processSIBJMSActivationSpecs
#
# Processes the activation specification definitions for a particular provider scope.
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider (app.sibjms.provider.<idx> )
#----------------------------------------------------------------------------------------
def processSIBJMSActivationSpecs(jmsInfo,cluster,node,server,prefix):
  
  try:
      _app_trace("processSIBJMSActivationSpecs(%s,%s,%s,%s)" % (cluster,node,server,prefix), "entry")
      
      count = int(jmsInfo.get("%s.activationSpecs.count"%prefix, "0"))
      if (count > 0):
          scopeString = scopeInfoString(cluster,node,server)
          for idx in range(1,count+1):
              actSpecName = jmsInfo.get("%s.activationSpecs.%d.name" % (prefix,idx), "")
              if (isEmpty(actSpecName)):
                # Possibly a partial list, just continue
                continue
              else:
                if (actSpecName.find("@ITERATE") >= 0):
                  tempArgs = parseFunctionParms(actSpecName)
                  if (len(tempArgs) > 0):
                    tPattern = tempArgs[0]
                  else:
                    tPattern = "*"
              
                  tWildcard = wildcardToRegExpString(tPattern)
                  specDict = findMatchingSIBJMSActivationSpecs(cluster,node,server,tWildcard)
                  numberMatch = len(specDict)
                  if (numberMatch == 0):
                    _app_message("No JMS ActivationSpec definitions matched name pattern %s at %s scope" % (tPattern,scopeString))
                  else:
                    _app_message("%d JMS ActivationSpec definitions matched name pattern %s at %s scope" % (numberMatch,tPattern,scopeString))
                    
                    for tempName in specDict.keys():
                      tempDict = filterProperties(jmsInfo, "%s.activationSpecs.%d" % (prefix,idx))
                      tempDict["%s.activationSpecs.%d.name" % (prefix,idx)] = tempName
                      _app_message("Processing matching ActivationSpec name %s" % tempName)
                      processSingleSIBJMSActivationSpec(tempDict,cluster,node,server, "%s.activationSpecs.%d" % (prefix,idx),specDict[tempName])
                      
                else:
                  processSingleSIBJMSActivationSpec(jmsInfo,cluster,node,server,"%s.activationSpecs.%d" % (prefix,idx))
              
      
  except:
      _app_trace("Unexpected error processing SIBJMSActivationSpecs","exception")
      _app_message("Unexpected error processing SIBJMSActivationSpecs")
      exit()
  
  _app_trace("processSIBJMSActivationSpecs()", "exit")


#----------------------------------------------------------------------------------------
# processSingleSIBJMSTopicDefinition
#    Process the SIBus JMS Topic definition for a specific JMS topic definition
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     topicPrefix - Prefix for topic ( app.sibjms.provider.<idx>.topics.<idx> )
#----------------------------------------------------------------------------------------
def processSingleSIBJMSTopicDefinition(jmsInfo,cluster,node,server, topicPrefix,jmsTopicId = None):


	_app_trace("processSingleSIBJMSTopicDefinition(%s,%s,%s,%s,%s)" % (cluster,node,server, topicPrefix,jmsTopicId),"entry")
	
	try:
		jmsInfo = toDictionary(jmsInfo)
		
		jmstopicName = jmsInfo.get("%s.name"%(topicPrefix),"")
		if (not isEmpty(jmstopicName)):
		  
			scopeString = scopeInfoString(cluster,node,server)
		  
			# See if a topic with this name is defined
			existingProps = getSIBJMSTopicProperties(cluster,node,server,jmstopicName,jmsTopicId)
			if (existingProps == None):
					_app_message("Error loading existing topic info: %s at %s scope"  % (jmstopicName,scopeString))
					exit()
			
			if (existingProps.size() == 0):
					# Create a new SIB JMSTopic definition
					topicProps = getPropList(jmsInfo, topicPrefix,1)
					
					jmstopicid = createSIBJMSTopic(jmstopicName, cluster, node, server, topicProps )
					if (isEmpty(jmstopicid)):
							_app_message("Error creating SIB JMSTopic %s at %s scope"  % (jmstopicName,scopeString))
							exit()
					else:
							_app_message("Created SIB JMSTopic %s at %s scope"  % (jmstopicName,scopeString))
					
			else:
					# Process changes only
					topicProps = getPropListDifferences(jmsInfo, topicPrefix, existingProps, "topic")
					if (topicProps.size() > 0):
							
							# Bug workaround, topicName must be included even if not being changed
							if (topicProps.get("topicName") == None):
							  topicProps["topicName"] = existingProps.get("topic.prop.topicName")
							
							result = modifySIBJMSTopic(jmstopicName, cluster, node, server,topicProps)
							if (isEmpty(result)):
									_app_message("Error updating SIB JMS Topic %s at %s scope"  % (jmstopicName,scopeString))
									exit()
							else:
									_app_message("Updated SIB JMS Topic %s at %s scope"  % (jmstopicName,scopeString))
									
					else:
							_app_message("No updates for SIB JMS Topic %s at %s scope"  % (jmstopicName,scopeString))
					
									
	except:
			_app_trace("Unexpected error processing SIB JMSTopic definition","exception")
			_app_message("Unexpected error processing SIB JMSTopic definitions")
			exit()
	
	
	
	_app_trace("processSingleSIBJMSTopicDefinition()","exit")



#----------------------------------------------------------------------------------------
# processSIBJMSTopicDefinitions
#    Process the SIBus JMS Topic definitions for a specific provider scope
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#----------------------------------------------------------------------------------------
def processSIBJMSTopicDefinitions(jmsInfo,cluster,node,server, prefix):


  _app_trace("processSIBJMSTopicDefinitions(%s,%s,%s,%s)" % (cluster,node,server, prefix),"entry")
  
  try:
      count = int(jmsInfo.get("%s.topics.count"%prefix, "0"))
      if (count > 0):
          for idx in range(1,count+1):
              jmstopicName = jmsInfo.get("%s.topics.%d.name"%(prefix,idx),"")
              if (isEmpty(jmstopicName)):
                  # possibly partial input file, skip
                  continue
              
              scopeString = scopeInfoString(cluster,node,server) 
              if (jmstopicName.find("@ITERATE") >= 0):
                  tempArgs = parseFunctionParms(jmstopicName)
                  if (len(tempArgs) > 0):
                    tPattern = tempArgs[0]
                  else:
                    tPattern = "*"
              
                  tWildcard = wildcardToRegExpString(tPattern)
                  topicDict = findMatchingSIBJMSTopics(cluster,node,server,tWildcard)
                  numberMatch = len(topicDict)
                  if (numberMatch == 0):
                    _app_message("No JMS Topic definitions matched name pattern %s at %s scope" % (tPattern,scopeString))
                  else:
                    _app_message("%d JMS Topic definitions matched name pattern %s at %s scope" % (numberMatch,tPattern,scopeString))
                    
                    for tempName in topicDict.keys():
                      tempDict = filterProperties(jmsInfo, "%s.topics.%d" % (prefix,idx))
                      tempDict["%s.topics.%d.name" % (prefix,idx)] = tempName
                      _app_message("Processing matching topic name %s" % tempName)
                      processSingleSIBJMSTopicDefinition(tempDict,cluster,node,server, "%s.topics.%d" % (prefix,idx),topicDict[tempName])
                
              else:  
                processSingleSIBJMSTopicDefinition(jmsInfo,cluster,node,server,"%s.topics.%d" % (prefix,idx),jmsTopicId = None)
                
                  
  except:
      _app_trace("Unexpected error processing SIB JMSTopic definitions","exception")
      _app_message("Unexpected error processing SIB JMSTopic definitions")
      exit()
  
  
  
  _app_trace("processSIBJMSTopicDefinitions()","exit")


#----------------------------------------------------------------------------------------
# processSingleSIBJMSQueueDefinition
#    Process a single SIBus JMS Queue definition
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     queuePrefix - Prefix for queue provider ( app.sibjms.provider.<idx>.queues.<idx> )
#     jmsQueueId - The configuration ID for the JMS queue if it is known
#----------------------------------------------------------------------------------------
def processSingleSIBJMSQueueDefinition(jmsInfo,cluster,node,server, queuePrefix,jmsQueueId = None):

  _app_trace("processSingleSIBJMSQueueDefinition(%s,%s,%s,%s,%s)" % (cluster,node,server, queuePrefix,jmsQueueId),"entry")
  
  try:
      
      jmsInfo = toDictionary(jmsInfo)
      
      jmsqueueName = jmsInfo.get("%s.name"%(queuePrefix),"")
      if (not isEmpty(jmsqueueName)):
        
          scopeString = scopeInfoString(cluster,node,server)
              
          # See if a queue with this name is defined
          existingProps = getSIBJMSQueueProperties(cluster,node,server,jmsqueueName,jmsQueueId)
          if (existingProps == None):
              _app_message("Error loading existing queue info: %s at %s scope"  % (jmsqueueName,scopeString))
              exit()
          
          if (existingProps.size() == 0):
              # Create a new SIB JMSQueue definition
              queueProps = getPropList(jmsInfo, queuePrefix,1)
              queueName = queueProps.get("queueName")
              
              jmsqueueid = createSIBJMSQueue(jmsqueueName, cluster, node, server, queueName, queueProps )
              if (isEmpty(jmsqueueid)):
                  _app_message("Error creating SIB JMSQueue %s at %s scope"  % (jmsqueueName,scopeString))
                  exit()
              else:
                  _app_message("Created SIB JMSQueue %s at %s scope"  % (jmsqueueName,scopeString))
              
          else:
              # Process changes only
              queueProps = getPropListDifferences(jmsInfo, queuePrefix, existingProps, "queue")
              if (queueProps.size() > 0):
                  
                  result = modifySIBJMSQueue(jmsqueueName, cluster, node, server,queueProps)
                  if (isEmpty(result)):
                      _app_message("Error updating SIB JMS Queue %s at %s scope"  % (jmsqueueName,scopeString))
                      exit()
                  else:
                      _app_message("Updated SIB JMS Queue %s at %s scope"  % (jmsqueueName,scopeString))
                      
              else:
                  _app_message("No updates for SIB JMS Queue %s at %s scope"  % (jmsqueueName,scopeString))
                  
                  
  except:
      _app_trace("Unexpected error processing SIB JMSQueue definition","exception")
      _app_message("Unexpected error processing SIB JMSQueue definition")
      exit()
  
  
  
  _app_trace("processSingleSIBJMSQueueDefinition()","exit")






#----------------------------------------------------------------------------------------
# processSIBJMSQueueDefinitions
#    Process the SIBus JMS Queue definitions for a specific provider scope
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#----------------------------------------------------------------------------------------
def processSIBJMSQueueDefinitions(jmsInfo,cluster,node,server, prefix):
  _app_trace("processSIBJMSQueueDefinitions(%s,%s,%s,%s)" % (cluster,node,server, prefix),"entry")
  
  try:
      count = int(jmsInfo.get("%s.queues.count"%prefix, "0"))
      if (count > 0):
          scopeString = scopeInfoString(cluster,node,server)
          
          for idx in range(1,count+1):
              jmsqueueName = jmsInfo.get("%s.queues.%d.name"%(prefix,idx),"")
              if (isEmpty(jmsqueueName)):
                  # possibly partial input file, skip
                  continue
              
              
              if (jmsqueueName.find("@ITERATE") >= 0):
                  tempArgs = parseFunctionParms(jmsqueueName)
                  if (len(tempArgs) > 0):
                    qPattern = tempArgs[0]
                  else:
                    qPattern = "*"
              
                  qWildcard = wildcardToRegExpString(qPattern)
                  queueDict = findMatchingSIBJMSQueues(cluster,node,server,qWildcard)
                  numberMatch = len(queueDict)
                  if (numberMatch == 0):
                    _app_message("No JMS Queue definitions matched name pattern %s at %s scope" % (qPattern,scopeString))
                  else:
                    _app_message("%d JMS Queue definitions matched name pattern %s at %s scope" % (numberMatch,qPattern,scopeString))
                    
                    for tempName in queueDict.keys():
                      tempDict = filterProperties(jmsInfo, "%s.queues.%d" % (prefix,idx))
                      tempDict["%s.queues.%d.name" % (prefix,idx)] = tempName
                      _app_message("Processing matching queue name %s" % tempName)
                      queuePrefix = "%s.queues.%d" % (prefix,idx)
                      processSingleSIBJMSQueueDefinition(tempDict,cluster,node,server, queuePrefix,queueDict[tempName])
              else:
                queuePrefix = "%s.queues.%d" % (prefix,idx)
                processSingleSIBJMSQueueDefinition(jmsInfo,cluster,node,server, queuePrefix)
                              
  except:
      _app_trace("Unexpected error processing SIB JMSQueue definitions","exception")
      _app_message("Unexpected error processing SIB JMSQueue definitions")
      exit()
  
  _app_trace("processSIBJMSQueueDefinitions()","exit")


#-------------------------------------------------------------------------------------------
# processConnectionFactory
#     Process the settings for a single connection factories from the jmsInfoFile
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx>.queueConnectionFactories.<index> OR
#                                    app.sibjms.provider.<idx>.topicConnectionFactories.<index> OR
#                                    app.sibjms.provider.<idx>.genericConnectionFactories.<index> )
#     type - type of connection factory ("Queue", "Topic" or "" for generic)
#-------------------------------------------------------------------------------------------
def processConnectionFactory(jmsInfo,cluster,node,server,prefix, type = ""):

	_app_trace("processConnectionFactory(%s,%s,%s,%s,%s)" % (cluster,node,server,prefix,type),"entry")
	try:
	         						  
						jmsInfo = toDictionary(jmsInfo)
						
						cfName = jmsInfo.get("%s.name" % (prefix),"")
						busName = jmsInfo.get("%s.prop.busName" % (prefix),"")
								
						# See if the connection factory exists
						existingProps = getSIBMJMSConnectionFactoryProperties(cluster,node,server,cfName, type)
						scopeString = scopeInfoString(cluster,node,server)
						
						if (isEmpty(type)):
								typePrefix = "generic"
						else:
								typePrefix = type.lower()
						
						existingPrefix = "%sConnectionFactory" % typePrefix
						
						cfProps = getPropListDifferences(jmsInfo, "%s" % (prefix), existingProps, existingPrefix)
						mappingProps = getPropListDifferences(jmsInfo,"%s.mapping" % prefix, existingProps, "%s.mapping" % existingPrefix)
						poolProps = getPropListDifferences(jmsInfo, "%s.connectionPool" % (prefix),  existingProps, "%s.connectionPool" % existingPrefix)
						poolCustomProps = getPropListDifferences(jmsInfo, "%s.connectionPool.customProperties" % (prefix),  existingProps, "%s.connectionPool.customProperties" % existingPrefix)
						
						if (existingProps == None or existingProps.size() == 0):
								# A new connection factory needs to be created
								cfProps.remove("busName")
								retval = createSIBJMSConnectionFactory(cfName, type, cluster, node, server, busName, cfProps, poolProps,poolCustomProps,mappingProps)
								if (isEmpty(retval)):
										_app_message("Error creating factory %s at %s scope" % (cfName, scopeString))
										exit()
								else:
										_app_message("Created factory %s at %s scope" % (cfName, scopeString))
						else:
								# An existing connection factory is being updated
								if (cfProps.size() == 0 and poolProps.size() == 0 and poolCustomProps.size() == 0 and mappingProps.size() == 0):
										_app_message("No need to update SIBJMSConnectionFactory %s" % cfName)
								else:	
								  retval = modifySIBJMSConnectionFactory(cfName, type, cluster, node, server, cfProps, poolProps, poolCustomProps,mappingProps)
								  if (isEmpty(retval)):
										_app_message("Error modifying factory %s at %s scope" % (cfName, scopeString))
										exit()
								  else:
										_app_message("Modified factory %s at %s scope" % (cfName, scopeString))
								
	except:
		_app_trace("Unexpected error processing connection factories: %s" % prefix,"exception")
		_app_message("Unexpected error processing SIBJMS connection factories: %s" % prefix)
		exit()
		
	_app_trace("processConnectionFactory()","exit")
		
#enddef processConnectionFactory

#-------------------------------------------------------------------------------------------
# processConnectionFactories
#     Process the settings for a list of connection factories from the jmsInfoFile
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx>.queueConnectionFactories OR
#                                    app.sibjms.provider.<idx>.topicConnectionFactories OR
#                                    app.sibjms.provider.<idx>.genericConnectionFactories )
#     type - type of connection factory ("Queue", "Topic" or "" for generic)
#-------------------------------------------------------------------------------------------
def processConnectionFactories(jmsInfo,cluster,node,server,prefix, jmstype = ""):

  _app_trace("processConnectionFactories(%s,%s,%s,%s,%s)" % (cluster,node,server,prefix,jmstype),"entry")
  try:
    count = int(jmsInfo.get("%s.count" % (prefix),"0"))
    scopeString = scopeInfoString(cluster,node,server)
    if (count > 0):
        for idx in range(1, count+1): 
            cfName = jmsInfo.get("%s.%d.name" % (prefix,idx),"")            
            if (isEmpty(cfName)):
                #print "Skipping index %d" %idx
                # Could be a partial list, carry on my wayward son
                continue
            
            # See if this is an iterate
            if (cfName.find("@ITERATE") >= 0):
              tempArgs = parseFunctionParms(cfName)
              if (len(tempArgs) > 0):
                cfPattern = tempArgs[0]
              else:
                cfPattern = "*"
              
              cfWildcard = wildcardToRegExpString(cfPattern)
              cfIds = findMatchingSIBMJMSConnectionFactoryIds(cluster,node,server,cfWildcard, jmstype)
              numberFound = len(cfIds)
              if (numberFound == 0):
                _app_message("No %s connection factories with name pattern %s found at %s scope" % (jmstype,cfPattern,scopeString))
              else:
                _app_message("%d %s connection factories with name pattern %s found at %s scope" % (numberFound,jmstype,cfPattern,scopeString))
                
                for tempCFName in cfIds.keys():
                  cfInfo = filterProperties(jmsInfo,"%s.%d" % (prefix,idx))
                  cfInfo["%s.%d.name" % (prefix,idx)] = tempCFName
                  _app_message("Processing connection factory %s" % tempCFName)
                  processConnectionFactory(cfInfo,cluster,node,server,"%s.%d" %(prefix,idx),jmstype)
            else:
              # This is a single connection factory
              processConnectionFactory(jmsInfo,cluster,node,server,"%s.%d" %(prefix,idx),jmstype)
  except:
    _app_trace("Unexpected error in processConnectionFactories","exception")
    exit()
  
  _app_trace("processConnectionFactories()" ,"exit")
  


#----------------------------------------------------------------------------------------
# processSIBGenericCF
#    Process the generic connection factories for a specific SIB JMS Provider
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#----------------------------------------------------------------------------------------
def processSIBGenericCF(jmsInfo,cluster,node,server, prefix):
	
	_app_trace("processGenericCF(%s,%s,%s,%s)" % (cluster,node,server, prefix),"entry")

	processConnectionFactories(jmsInfo,cluster,node,server,"%s.genericConnectionFactories" % prefix)
	
	_app_trace("processGenericCF()","exit")

#----------------------------------------------------------------------------------------
# processSIBQueueCF
#    Process the queue connection factories for a specific SIB JMS Provider
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#----------------------------------------------------------------------------------------
def processSIBQueueCF(jmsInfo,cluster,node,server, prefix):

	_app_trace("processQueueCF(%s,%s,%s,%s)" % (cluster,node,server, prefix),"entry")

	processConnectionFactories(jmsInfo,cluster,node,server,"%s.queueConnectionFactories" % prefix, "Queue")
	
	_app_trace("processQueueCF()","exit")

#----------------------------------------------------------------------------------------
# processSIBTopicCF
#    Process the topic connection factories for a specific SIB JMS Provider
# 
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#----------------------------------------------------------------------------------------
def processSIBTopicCF(jmsInfo,cluster,node,server, prefix):

	_app_trace("processTopicCF(%s,%s,%s,%s)" % (cluster,node,server, prefix),"entry")
	
	processConnectionFactories(jmsInfo,cluster,node,server,"%s.topicConnectionFactories" % prefix, "Topic")
	
	_app_trace("processTopicCF()","exit")

#--------------------------------------------------------------------------------------------
# processSIBJMSComponentsAtScope
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#--------------------------------------------------------------------------------------------
def processSIBJMSComponentsAtScope(jmsInfo,cluster,node,server,prefix):
  _app_trace("processSIBJMSComponentsAtScope(jmsInfo,%s,%s,%s,%s)" % (cluster,node,server,prefix),"entry")
  try:
      # Generic factories
      processSIBGenericCF(jmsInfo,cluster,node,server,prefix)
      
      # Queue factories
      processSIBQueueCF(jmsInfo,cluster,node,server,prefix)
      
      # Topic factories
      processSIBTopicCF(jmsInfo,cluster,node,server,prefix)
      
      # Queue destinations
      processSIBJMSQueueDefinitions(jmsInfo,cluster,node,server,prefix)
      
      # Topic destinations
      processSIBJMSTopicDefinitions(jmsInfo,cluster,node,server,prefix)
      
      # Activation Specifications
      processSIBJMSActivationSpecs(jmsInfo,cluster,node,server,prefix)
    
  except:
    _app_trace("Unexpected error in processSIBJMSComponentsAtScope","exception")
    exit()
  
  _app_trace("processSIBJMSComponentsAtScope()","exit")
  
#----------------------------------------------------------------------------------------
# processSingleSIBJMSActivationSpecDefinitionDeletion
#    Process the deletion of a single SIBus JMS activationSpec definition. This function
#    supports the option of recreating the JMS Activation Spec at a different scope after
#    the original is deleted.
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     activationSpecPrefix - Prefix for activationSpec ( app.sibjms.provider.<idx>.activationSpecs.<idx> )
#     doMove - 1 = move to a different scope
#     moveCluster - cluster scope to move to
#     moveNode - node scope to move to
#     moveServer - server scope to move to
#     jmsActivationSpecId - The configuration ID for the JMS activationSpec if it is known
#----------------------------------------------------------------------------------------
def processSingleSIBJMSActivationSpecDefinitionDeletion(jmsInfo,cluster,node,server, activationSpecPrefix,doMove=0,moveCluster=None,moveNode=None,moveServer=None,jmsActivationSpecId = None):

  
  _app_trace("processSingleSIBJMSActivationSpecDefinitionDeletion(%s,%s,%s,%s,%d,%s,%s,%s,%s)" % (cluster,node,server, activationSpecPrefix,doMove,moveCluster,moveNode,moveServer,jmsActivationSpecId),"entry")
  
  try:
      jmsactivationSpecName = jmsInfo.get("%s.name"%(activationSpecPrefix),"")
      scopeString = scopeInfoString(cluster,node,server)
      
      if (not isEmpty(jmsactivationSpecName)):
        
        # See if this JMS activationSpec is defined if the ID was not passed in to us
        if (isEmpty(jmsActivationSpecId)):
          jmsActivationSpecId = getSIBJMSActivationSpecID(cluster,node,server,jmsactivationSpecName)
          
          if (isEmpty(jmsActivationSpecId)):
            _app_message("No need to delete JMS ActivationSpec %s at %s scope" % (jmsactivationSpecName, scopeString))
          #endif
        #endif
        
        # Do deletion if we do have the activationSpec
        if (not isEmpty(jmsActivationSpecId)):
          if (doMove):
            # See if a activationSpec with this name is defined
            existingProps = getSIBJMSActivationSpecProperties(cluster,node,server,jmsactivationSpecName,jmsActivationSpecId)
            if (existingProps == None):
              _app_message("Error loading existing activationSpec info: %s at %s scope"  % (jmsactivationSpecName,scopeString))
              exit()
            #endif
          #endif
          if (deleteSIBJMSActivationSpec(jmsactivationSpecName, cluster, node, server,jmsActivationSpecId)):
            _app_message("Error deleting JMS ActivationSpec %s at %s scope"%(jmsactivationSpecName,scopeString))
            exit()
          else:
            _app_message("Deleted JMS ActivationSpec %s at %s scope"%(jmsactivationSpecName, scopeString))
          #endelse
          
          if (doMove):
            processSingleSIBJMSActivationSpec(existingProps,moveCluster,moveNode,moveServer, "activationSpec")
          #endif
        #endif          
  except:
      _app_trace("Unexpected error in processSingleSIBJMSActivationSpecDefinitionDeletion","exception")
      exit()
  
  
  
  _app_trace("processSingleSIBJMSActivationSpecDefinitionDeletion()","exit")

#----------------------------------------------------------------------------------------
# processSIBJMSActivationSpecDefinitionDeletions
#    Process the SIBus JMS ActivationSpec deletions for a specific provider scope.
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#     doMove - if 1, then the activationSpec will be moved to a different scope
#     moveCluster - the cluster to move to
#     moveNode - the node to move to 
#     moveServer - the server to move to
#----------------------------------------------------------------------------------------
def processSIBJMSActivationSpecDefinitionDeletions(jmsInfo,cluster,node,server, prefix,doMove,moveCluster,moveNode,moveServer):
  _app_trace("processSIBJMSActivationSpecDefinitionDeletions(%s,%s,%s,%s,%d,%s,%s,%s)" % (cluster,node,server, prefix,doMove,moveCluster,moveNode,moveServer),"entry")
  
  try:
      scopeString = scopeInfoString(cluster,node,server)
      
      count = int(jmsInfo.get("%s.activationSpecs.count"%prefix, "0"))
      if (count > 0):
          for idx in range(1,count+1):
              jmsactivationSpecName = jmsInfo.get("%s.activationSpecs.%d.name"%(prefix,idx),"")
              if (isEmpty(jmsactivationSpecName)):
                  # possibly partial input file, skip
                  continue
                  
              if (jmsactivationSpecName.find("@ITERATE") >= 0):
                  tempArgs = parseFunctionParms(jmsactivationSpecName)
                  if (len(tempArgs) > 0):
                    qPattern = tempArgs[0]
                  else:
                    qPattern = "*"
              
                  qWildcard = wildcardToRegExpString(qPattern)
                  activationSpecDict = findMatchingSIBJMSActivationSpecs(cluster,node,server,qWildcard)
                  numberMatch = len(activationSpecDict)
                  if (numberMatch == 0):
                    _app_message("No JMS ActivationSpec definitions matched name pattern %s at %s scope" % (qPattern,scopeString))
                  else:
                    _app_message("%d JMS ActivationSpec definitions matched name pattern %s at %s scope" % (numberMatch,qPattern,scopeString))
                    
                    for tempName in activationSpecDict.keys():
                      tempDict = filterProperties(jmsInfo, "%s.activationSpecs.%d" % (prefix,idx))
                      tempDict["%s.activationSpecs.%d.name" % (prefix,idx)] = tempName
                      _app_message("Processing matching activationSpec name %s" % tempName)
                      processSingleSIBJMSActivationSpecDefinitionDeletion(tempDict,cluster,node,server,"%s.activationSpecs.%d" % (prefix,idx),doMove,moveCluster,moveNode,moveServer,activationSpecDict[tempName])
              else:
                processSingleSIBJMSActivationSpecDefinitionDeletion(jmsInfo,cluster,node,server, "%s.activationSpecs.%d" % (prefix,idx),doMove,moveCluster,moveNode,moveServer)
                              
  except:
      _app_trace("Unexpected error in processSIBJMSActivationSpecDefinitionDeletions","exception")
      exit()
  
  _app_trace("processSIBJMSActivationSpecDefinitionDeletions()","exit")


#----------------------------------------------------------------------------------------
# processSingleSIBJMSTopicDefinitionDeletion
#    Process the deletion of a single SIBus JMS topic definition. This function supports
#    the optional recreation of the JMS Topic at a different scope if the move parameters
#    are supplied.
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     topicPrefix - Prefix for topic ( app.sibjms.provider.<idx>.topics.<idx> )
#     doMove - 1 = move to a different scope
#     moveCluster - cluster scope to move to
#     moveNode - node scope to move to
#     moveServer - server scope to move to
#     jmsTopicId - The configuration ID for the JMS topic if it is known
#----------------------------------------------------------------------------------------
def processSingleSIBJMSTopicDefinitionDeletion(jmsInfo,cluster,node,server, topicPrefix,doMove=0,moveCluster=None,moveNode=None,moveServer=None,jmsTopicId = None):

  
  _app_trace("processSingleSIBJMSTopicDefinitionDeletion(%s,%s,%s,%s,%d,%s,%s,%s,%s)" % (cluster,node,server, topicPrefix,doMove,moveCluster,moveNode,moveServer,jmsTopicId),"entry")
  
  try:
      jmstopicName = jmsInfo.get("%s.name"%(topicPrefix),"")
      scopeString = scopeInfoString(cluster,node,server)
      
      if (not isEmpty(jmstopicName)):
        
        # See if this JMS topic is defined if the ID was not passed in to us
        if (isEmpty(jmsTopicId)):
          jmsTopicId = getSIBJMSTopicId(cluster,node,server,jmstopicName)
          
          if (isEmpty(jmsTopicId)):
            _app_message("No need to delete JMS Topic %s at %s scope" % (jmstopicName, scopeString))
          #endif
        #endif
        
        # Do deletion if we do have the topic
        if (not isEmpty(jmsTopicId)):
          if (doMove):
            # See if a topic with this name is defined
            existingProps = getSIBJMSTopicProperties(cluster,node,server,jmstopicName,jmsTopicId,1)
            if (existingProps == None):
              _app_message("Error loading existing topic info: %s at %s scope"  % (jmstopicName,scopeString))
              exit()
            #endif
          #endif
          if (deleteSIBJMSTopic(jmstopicName, cluster, node, server,jmsTopicId)):
            _app_message("Error deleting JMS Topic %s at %s scope"%(jmstopicName,scopeString))
            exit()
          else:
            _app_message("Deleted JMS Topic %s at %s scope"%(jmstopicName, scopeString))
          #endelse
          
          if (doMove):
            processSingleSIBJMSTopicDefinition(existingProps,moveCluster,moveNode,moveServer, "topic")
          #endif
        #endif          
  except:
      _app_trace("Unexpected error in processSingleSIBJMSTopicDefinitionDeletion","exception")
      exit()
  
  
  
  _app_trace("processSingleSIBJMSTopicDefinitionDeletion()","exit")

#----------------------------------------------------------------------------------------
# processSIBJMSTopicDefinitionDeletions
#    Process the SIBus JMS Topic deletions for a specific provider scope
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#     doMove - if 1, then the topic will be moved to a different scope
#     moveCluster - the cluster to move to
#     moveNode - the node to move to 
#     moveServer - the server to move to
#----------------------------------------------------------------------------------------
def processSIBJMSTopicDefinitionDeletions(jmsInfo,cluster,node,server, prefix,doMove,moveCluster,moveNode,moveServer):
  _app_trace("processSIBJMSTopicDefinitionDeletions(%s,%s,%s,%s,%d,%s,%s,%s)" % (cluster,node,server, prefix,doMove,moveCluster,moveNode,moveServer),"entry")
  
  try:
      scopeString = scopeInfoString(cluster,node,server)
      
      count = int(jmsInfo.get("%s.topics.count"%prefix, "0"))
      if (count > 0):
          for idx in range(1,count+1):
              jmstopicName = jmsInfo.get("%s.topics.%d.name"%(prefix,idx),"")
              if (isEmpty(jmstopicName)):
                  # possibly partial input file, skip
                  continue
                  
              if (jmstopicName.find("@ITERATE") >= 0):
                  tempArgs = parseFunctionParms(jmstopicName)
                  if (len(tempArgs) > 0):
                    qPattern = tempArgs[0]
                  else:
                    qPattern = "*"
              
                  qWildcard = wildcardToRegExpString(qPattern)
                  topicDict = findMatchingSIBJMSTopics(cluster,node,server,qWildcard)
                  numberMatch = len(topicDict)
                  if (numberMatch == 0):
                    _app_message("No JMS Topic definitions matched name pattern %s at %s scope" % (qPattern,scopeString))
                  else:
                    _app_message("%d JMS Topic definitions matched name pattern %s at %s scope" % (numberMatch,qPattern,scopeString))
                    
                    for tempName in topicDict.keys():
                      tempDict = filterProperties(jmsInfo, "%s.topics.%d" % (prefix,idx))
                      tempDict["%s.topics.%d.name" % (prefix,idx)] = tempName
                      _app_message("Processing matching topic name %s" % tempName)
                      processSingleSIBJMSTopicDefinitionDeletion(tempDict,cluster,node,server,"%s.topics.%d" % (prefix,idx),doMove,moveCluster,moveNode,moveServer,topicDict[tempName])
              else:
                processSingleSIBJMSTopicDefinitionDeletion(jmsInfo,cluster,node,server, "%s.topics.%d" % (prefix,idx),doMove,moveCluster,moveNode,moveServer)
                              
  except:
      _app_trace("Unexpected error in processSIBJMSTopicDefinitionDeletions","exception")
      exit()
  
  _app_trace("processSIBJMSTopicDefinitionDeletions()","exit")



#----------------------------------------------------------------------------------------
# processSingleSIBJMSQueueDefinitionDeletion
#    Process the deletion of a single SIBus JMS Queue definition. This function supports
#    the optional recreation of the JMS Queue at a different scope if the move parameters
#    are supplied.
#    
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#     idx - the index for this particular queue definition
#     doMove - 1 = move to a different scope
#     moveCluster - cluster scope to move to
#     moveNode - node scope to move to
#     moveServer - server scope to move to
#     jmsQueueId - The configuration ID for the JMS queue if it is known
#----------------------------------------------------------------------------------------
def processSingleSIBJMSQueueDefinitionDeletion(jmsInfo,cluster,node,server, prefix,idx,doMove=0,moveCluster=None,moveNode=None,moveServer=None,jmsQueueId = None):

  
  _app_trace("processSingleSIBJMSQueueDefinitionDeletion(%s,%s,%s,%s,%s,%d,%s,%s,%s,%s)" % (cluster,node,server, prefix,idx,doMove,moveCluster,moveNode,moveServer,jmsQueueId),"entry")
  
  try:
      jmsqueueName = jmsInfo.get("%s.queues.%d.name"%(prefix,idx),"")
      
      scopeString = scopeInfoString(cluster,node,server)
      
      if (not isEmpty(jmsqueueName)):
        
        # See if this JMS queue is defined if the ID was not passed in to us
        if (isEmpty(jmsQueueId)):
          jmsQueueId = getSIBJMSQueueId(cluster,node,server,jmsqueueName)
          
          if (isEmpty(jmsQueueId)):
            _app_message("No need to delete JMS Queue %s at %s scope" % (jmsqueueName, scopeString))
          #endif
        #endif
        
        # Do deletion if we do have the queue
        if (not isEmpty(jmsQueueId)):
          if (doMove):
            # See if a queue with this name is defined
            existingProps = getSIBJMSQueueProperties(cluster,node,server,jmsqueueName,jmsQueueId,1)
            if (existingProps == None):
              _app_message("Error loading existing queue info: %s at %s scope"  % (jmsqueueName,scopeString))
              exit()
            #endif
          #endif
          if (deleteSIBJMSQueue(jmsqueueName, cluster, node, server,jmsQueueId)):
            _app_message("Error deleting JMS Queue %s at %s scope"%(jmsqueueName, scopeString))
            exit()
          else:
            _app_message("Deleted JMS Queue %s at %s scope"%(jmsqueueName, scopeString))
          #endelse
          
          if (doMove):
            processSingleSIBJMSQueueDefinition(existingProps,moveCluster,moveNode,moveServer, "queue")
          #endif
        #endif          
  except:
      _app_trace("Unexpected error in processSingleSIBJMSQueueDefinitionDeletion","exception")
      exit()
  
  
  
  _app_trace("processSingleSIBJMSQueueDefinitionDeletion()","exit")



#----------------------------------------------------------------------------------------
# processSIBJMSQueueDefinitionDeletions
#    Process the SIBus JMS Queue deletions for a specific provider scope
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx> )
#     doMove - if 1, then the topic will be moved to a different scope
#     moveCluster - the cluster to move to
#     moveNode - the node to move to 
#     moveServer - the server to move to
#----------------------------------------------------------------------------------------
def processSIBJMSQueueDefinitionDeletions(jmsInfo,cluster,node,server, prefix,doMove,moveCluster,moveNode,moveServer):
  _app_trace("processSIBJMSQueueDefinitionDeletions(%s,%s,%s,%s,%d,%s,%s,%s)" % (cluster,node,server, prefix,doMove,moveCluster,moveNode,moveServer),"entry")
  
  try:
      count = int(jmsInfo.get("%s.queues.count"%prefix, "0"))
      if (count > 0):
          scopeString = scopeInfoString(cluster,node,server)
          for idx in range(1,count+1):
              jmsqueueName = jmsInfo.get("%s.queues.%d.name"%(prefix,idx),"")
              if (isEmpty(jmsqueueName)):
                  # possibly partial input file, skip
                  continue
                  
              if (jmsqueueName.find("@ITERATE") >= 0):
                  tempArgs = parseFunctionParms(jmsqueueName)
                  if (len(tempArgs) > 0):
                    qPattern = tempArgs[0]
                  else:
                    qPattern = "*"
              
                  qWildcard = wildcardToRegExpString(qPattern)
                  queueDict = findMatchingSIBJMSQueues(cluster,node,server,qWildcard)
                  numberMatch = len(queueDict)
                  if (numberMatch == 0):
                    _app_message("No JMS Queue definitions matched name pattern %s at %s scope" % (qPattern,scopeString))
                  else:
                    _app_message("%d JMS Queue definitions matched name pattern %s at %s scope" % (numberMatch,qPattern,scopeString))
                    
                    for tempName in queueDict.keys():
                      tempDict = filterProperties(jmsInfo, "%s.queues.%d" % (prefix,idx))
                      tempDict["%s.queues.%d.name" % (prefix,idx)] = tempName
                      _app_message("Processing deletion of matching queue name %s" % tempName)
                      processSingleSIBJMSQueueDefinitionDeletion(tempDict,cluster,node,server, prefix,idx,doMove,moveCluster,moveNode,moveServer,queueDict[tempName])
              else:
                processSingleSIBJMSQueueDefinitionDeletion(jmsInfo,cluster,node,server, prefix,idx,doMove,moveCluster,moveNode,moveServer)
                              
  except:
      _app_trace("Unexpected error in processSIBJMSQueueDefinitionDeletions","exception")
      exit()
  
  _app_trace("processSIBJMSQueueDefinitionDeletions()","exit")



  
#-------------------------------------------------------------------------------------------
# processSingleConnectionFactoryDeletion
#
#     Process the deletion for a single connection factories from the jmsInfoFile.  This 
#     function also supports the optional recreation of the connection factory at a different
#     scope.
#
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx>.queueConnectionFactories.<index> OR
#                                    app.sibjms.provider.<idx>.topicConnectionFactories.<index> OR
#                                    app.sibjms.provider.<idx>.genericConnectionFactories.<index> )
#     cftype - type of connection factory ("Queue", "Topic" or "" for generic)
#     doMove - if 1, then the topic will be moved to a different scope
#     moveCluster - the cluster to move to
#     moveNode - the node to move to 
#     moveServer - the server to move to
#     cfName - name of the connection factory (if known)
#     cfId - ID of the connection factory (if known)
#-------------------------------------------------------------------------------------------
def processSingleConnectionFactoryDeletion(jmsInfo,cluster,node,server,prefix, cftype = "",doMove=0,moveCluster=None,moveNode=None,moveServer=None,cfName=None,cfId=None):

  _app_trace("processSingleConnectionFactoryDeletion(%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s)" % (cluster,node,server,prefix,cftype,doMove,moveCluster,moveNode,moveServer,cfName,cfId),"entry")
  try:
      
      if (cfName == None):
        cfName = jmsInfo.get("%s.name" % (prefix),"")
      
      if (isEmpty(cftype)):
          typePrefix = "generic"
      else:
          typePrefix = cftype.lower()
      
      scopeString = scopeInfoString(cluster,node,server)
          
      # See if the connection factory exists
      if (cfId == None):
        cfId = findSIBMJMSConnectionFactoryId(cluster,node,server,cfName, cftype)
        if (cfId == None):
          _app_message("No need to delete: JMS %s connection factory %s at %s scope does not exist" % (typePrefix,cfName, scopeString))
      #endif
      
      if (cfId != None):
        
          # See if the connection factory exists
          if (doMove):
            existingProps = getSIBMJMSConnectionFactoryProperties(cluster,node,server,cfName, cftype,1)
          #endif
          
          if (isEmpty(cftype)):
              typePrefix = "generic"
          else:
              typePrefix = cftype.lower()
          #endelse
          
          # Do the deletion
          if (deleteSIBJMSConnectionFactory(cfName, cluster, node, server,cfId)):
            _app_message("Error occurred removing JMS %s connection factory %s at %s scope" % (typePrefix,cfName, scopeString))
            exit()
          else:
            _app_message("Deleted JMS %s connection factory %s at %s scope" % (typePrefix,cfName, scopeString))
          #endelse
          
          if (doMove):
            existingPrefix = "%sConnectionFactory" % typePrefix
            
            processConnectionFactory(existingProps,moveCluster,moveNode,moveServer,existingPrefix, cftype)
          #endif
        #endelse      
      #endif
  except:
    _app_trace("Unexpected error processing connection factory deletion: %s" % prefix,"exception")
    exit()
		
  _app_trace("processSingleConnectionFactoryDeletion()","exit")
		
#enddef processSingleConnectionFactoryDeletion
 

#-------------------------------------------------------------------------------------------
# processConnectionFactoryDeletions
#     Process the deletions for a list of connection factories from the jmsInfoFile
# Parameters:
#     jmsInfo - A dictionary containing the properties for the resource being configured
#     cluster - Cluster name for finding scoped SIB JMS Provider
#     node - Node name for finding scoped SIB JMS Provider
#     server - server name for finding scoped SIB JMS Provider
#     prefix - Prefix for provider ( app.sibjms.provider.<idx>.queueConnectionFactories OR
#                                    app.sibjms.provider.<idx>.topicConnectionFactories OR
#                                    app.sibjms.provider.<idx>.genericConnectionFactories )
#     jmstype - type of connection factory ("Queue", "Topic" or "" for generic)
#     doMove - if 1, then the topic will be moved to a different scope
#     moveCluster - the cluster to move to
#     moveNode - the node to move to 
#     moveServer - the server to move to
#-------------------------------------------------------------------------------------------
def processConnectionFactoryDeletions(jmsInfo,cluster,node,server,prefix, jmstype = "",doMove=0,moveCluster=None,moveNode=None,moveServer=None):

  _app_trace("processConnectionFactoryDeletions(%s,%s,%s,%s,%s)" % (cluster,node,server,prefix,jmstype),"entry")
  try:
    scopeString = scopeInfoString(cluster,node,server)
    
    count = int(jmsInfo.get("%s.count" % (prefix),"0"))
    
    if (count > 0):
        for idx in range(1, count+1): 
            cfName = jmsInfo.get("%s.%d.name" % (prefix,idx),"")            
            if (isEmpty(cfName)):
                # Could be a partial list, carry on my wayward son
                continue
            
            # See if this is an iterate
            if (cfName.find("@ITERATE") >= 0):
              tempArgs = parseFunctionParms(cfName)
              if (len(tempArgs) > 0):
                cfPattern = tempArgs[0]
              else:
                cfPattern = "*"
              
              cfWildcard = wildcardToRegExpString(cfPattern)
              cfIds = findMatchingSIBMJMSConnectionFactoryIds(cluster,node,server,cfWildcard, jmstype)
              numberFound = len(cfIds)
              if (numberFound == 0):
                _app_message("No %s connection factories with name pattern %s found at %s scope" % (jmstype,cfPattern,scopeString))
              else:
                _app_message("%d %s connection factories with name pattern %s found at %s scope" % (numberFound,jmstype,cfPattern,scopeString))
                
                for tempCFName in cfIds.keys():
                  cfInfo = filterProperties(jmsInfo,"%s.%d" % (prefix,idx))
                  cfInfo["%s.%d.name" % (prefix,idx)] = tempCFName
                  _app_message("Processing connection factory %s" % tempCFName)
                  tempID = cfIds.get(tempCFName)
                  processSingleConnectionFactoryDeletion(cfInfo,cluster,node,server,"%s.%d" %(prefix,idx),jmstype,doMove,moveCluster,moveNode,moveServer,tempCFName,tempID)
            else:
              # This is a single connection factory
              processSingleConnectionFactoryDeletion(jmsInfo,cluster,node,server,"%s.%d" %(prefix,idx),jmstype,doMove,moveCluster,moveNode,moveServer)
  except:
    _app_trace("Unexpected error in processConnectionFactoryDeletions","exception")
    exit()
  
  _app_trace("processConnectionFactoryDeletions()" ,"exit")
  
#-------------------------------------------------------------------------------
# processSIBGenericCFDeletions
#-------------------------------------------------------------------------------
def processSIBGenericCFDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer):
  _app_trace("processSIBGenericCFDeletions(jmsInfo,%s,%s,%s,%s,%d,%s,%s,%s)"% ( cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer),"entry")
  try:
    processConnectionFactoryDeletions(jmsInfo,cluster,node,server,"%s.genericConnectionFactories" % prefix,"",doMove,moveCluster,moveNode,moveServer)
  except:
    _app_trace("Unexpected error in processSIBGenericCFDeletions","exception")
    exit()
    
  _app_trace("processSIBGenericCFDeletions","exit")

#-------------------------------------------------------------------------------
# processSIBQueueCFDeletions
#-------------------------------------------------------------------------------
def processSIBQueueCFDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer):
  _app_trace("processSIBQueueCFDeletions(jmsInfo,%s,%s,%s,%s,%d,%s,%s,%s)"% ( cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer),"entry")
  try:
    processConnectionFactoryDeletions(jmsInfo,cluster,node,server,"%s.queueConnectionFactories" %prefix,"queue",doMove,moveCluster,moveNode,moveServer)
  except:
    _app_trace("Unexpected error in processSIBQueueCFDeletions","exception")
    exit()
    
  _app_trace("processSIBQueueCFDeletions","exit")

#-------------------------------------------------------------------------------
# processSIBTopicCFDeletions
#-------------------------------------------------------------------------------
def processSIBTopicCFDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer):
  _app_trace("processSIBTopicCFDeletions(jmsInfo,%s,%s,%s,%s,%d,%s,%s,%s)"% ( cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer),"entry")
  try:
    processConnectionFactoryDeletions(jmsInfo,cluster,node,server,"%s.topicConnectionFactories" %prefix,"topic",doMove,moveCluster,moveNode,moveServer)
  except:
    _app_trace("Unexpected error in processSIBTopicCFDeletions","exception")
    exit()
    
  _app_trace("processSIBTopicCFDeletions","exit")

#-------------------------------------------------------------------------------
# processSIBJMSDeletionsAtScope
#
# Process the deletion instructions in the provided dictionary at the specified
# scope. 
#
# Parameters:
#     jmsInfo - the dictionary containing configuration data
#     cluster - scope information for the JMS Provider
#     node - scope information for the JMS Provider
#     server - scope information for the JMS Provider
#     prefix - the property prefix for the JMS Provider
#     doMove - if 1, then the topic will be moved to a different scope
#     moveCluster - the cluster to move to
#     moveNode - the node to move to 
#     moveServer - the server to move to
#-------------------------------------------------------------------------------
def processSIBJMSDeletionsAtScope(jmsInfo,cluster,node,server,prefix,doMove=0,moveCluster=None,moveNode=None,moveServer=None):
  _app_trace("processSIBJMSDeletionsAtScope(jmsInfo,%s,%s,%s,%s,%d,%s,%s,%s)" % (cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer),"entry")
  try:
      # Generic factories
      processSIBGenericCFDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer)
      
      # Queue factories
      processSIBQueueCFDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer)
      
      # Topic factories
      processSIBTopicCFDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer)
      
      # Queue destinations
      processSIBJMSQueueDefinitionDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer)
      
      # Topic destinations
      processSIBJMSTopicDefinitionDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer)
      
      # Activation Specifications
      processSIBJMSActivationSpecDefinitionDeletions(jmsInfo,cluster,node,server,prefix,doMove,moveCluster,moveNode,moveServer)
    
  except:
    _app_trace("Unexpected error in processSIBJMSDeletionsAtScope","exception")
    exit()
  
  _app_trace("processSIBJMSDeletionsAtScope()","exit")


  
#-------------------------------------------------------------------------------
# processSIBJMSDeletions
#
# This function will process the deletion instructions in the "del.sibjms.provider..."
# properties.
#-------------------------------------------------------------------------------
def processSIBJMSDeletions(deletionInfo):

  try:
    count = int(deletionInfo.get("del.sibjms.provider.count","0"))
    if (count > 0):
        for idx in range(1,count+1):
            
            # Get the scope fields
            clusterParm = deletionInfo.get("del.sibjms.provider.%d.cluster" % idx,"")
            nodeParm = deletionInfo.get("del.sibjms.provider.%d.node" % idx,"")
            serverParm = deletionInfo.get("del.sibjms.provider.%d.server" % idx,"")
            
            doMove = 0
            moveCluster = None
            moveNode = None
            moveServer = None
            
            moveProvider =  deletionInfo.get("del.sibjms.provider.%d.moveProvider"%idx,"false")
            if (moveProvider.lower() == "true"):
              doMove = 1
              moveCluster = deletionInfo.get("del.sibjms.provider.%d.moveProvider.cluster" % idx,"")
              moveNode = deletionInfo.get("del.sibjms.provider.%d.moveProvider.node" % idx,"")
              moveServer = deletionInfo.get("del.sibjms.provider.%d.moveProvider.server" % idx,"")
            #endif
            
            doIterationProcessing = 0
            doClusterMembers = 0
            cmembers = []
      
            if (clusterParm.find("@ITERATE") >= 0):
              doIterationProcessing = 1
              tempArgs = parseFunctionParms(clusterParm)
              if (len(tempArgs) > 0):
                clusterParm = tempArgs[0]
              else:
                clusterParm = "*"
            #endif
      
            if (nodeParm.find("@ITERATE") >= 0):
              doIterationProcessing = 1
              tempArgs = parseFunctionParms(nodeParm)
              if (len(tempArgs) > 0):
                nodeParm = tempArgs[0]
              else:
                nodeParm = "*"
            #endif
      
            if (serverParm.find("@ITERATE") >= 0):
              doIterationProcessing = 1
              tempArgs = parseFunctionParms(serverParm)
              if (len(tempArgs) > 0):
                serverParm = tempArgs[0]
              else:
                serverParm = "*"    
            elif (serverParm.find("@CLUSTERMEMBERS") >= 0):
              doClusterMembers = 1 
              clusterparms = parseFunctionParms(serverParm)
              cmembers = getClusterMemberList(clusterparms[0])
            #end elif
          
            clusterPattern = clusterParm
            nodePattern = nodeParm
            serverPattern = serverParm 
            
            if (doClusterMembers):
              for cmember in cmembers:
                membername = cmember[0]
                membernode = cmember[1]
                
                  
                # Get a copy of the properties
                subConfigInfo = filterProperties(deletionInfo,"del.sibjms.provider.%d" % idx)
                subConfigInfo["del.sibjms.provider.%d.cluster" % idx] = ""
                subConfigInfo["del.sibjms.provider.%d.node" % idx] = membernode
                subConfigInfo["del.sibjms.provider.%d.server" % idx] = membername
              
                processSIBJMSDeletionsAtScope(subConfigInfo,"",membernode,membername,"del.sibjms.provider.%d" % idx,doMove,moveCluster,moveNode,moveServer)
              #endfor
                
            elif (doIterationProcessing):
              if (serverPattern.find("*") >= 0):
                serverPattern = wildcardToRegExpString(serverPattern)
              if (nodePattern.find("*") >= 0):
                nodePattern = wildcardToRegExpString(nodePattern)
              if (clusterPattern.find("*") >= 0):
                clusterPattern = wildcardToRegExpString(clusterPattern)
                
              providerIds = matchItemsAtScope("SIB JMS Resource Adapter", "J2CResourceAdapter", clusterPattern, nodePattern, serverPattern)
              for providerId in providerIds:
                tc,tn,ts = getScope(providerId)
                
                scopeString = scopeInfoString(tc,tn,ts) 
                _app_message("Processing deletion settings for SIB JMS Resource Adapter at %s scope" % (scopeString))
                
                # Get a copy of the properties
                subConfigInfo = filterProperties(deletionInfo,"del.sibjms.provider.%d" % idx)
                subConfigInfo["del.sibjms.provider.%d.cluster" % idx] = tc
                subConfigInfo["del.sibjms.provider.%d.node" % idx] = tn
                subConfigInfo["del.sibjms.provider.%d.server" % idx] = ts
                
                processSIBJMSDeletionsAtScope(subConfigInfo,tc,tn,ts,"del.sibjms.provider.%d" % idx,doMove,moveCluster,moveNode,moveServer)
              #endfor  
            else:
              # No @ITERATE, so Process the provider as specified
              processSIBJMSDeletionsAtScope(deletionInfo,clusterParm,nodeParm,serverParm,"del.sibjms.provider.%d" % idx,doMove,moveCluster,moveNode,moveServer)
                        
    #endif
  except:
    _app_trace("Unexpected error processing SIBus JMS deletions","exception")
    exit()




#-----------------------------------------------------------------------------------------
# processSIBJMS:
#   This is the entry point to this module.  This method will loop through the 
#   del.sibjms.provider and app.sibjms.provider entries in configInfo and process the settings
#-----------------------------------------------------------------------------------------
def processSIBJMS():

  try:
    
    # Do deletions first
    processSIBJMSDeletions(configInfo)
    
    count = int(configInfo.get("app.sibjms.provider.count","0"))
    if (count > 0):
        for idx in range(1,count+1):
            
            # Get the scope fields
            clusterParm = configInfo.get("app.sibjms.provider.%d.cluster" % idx,"")
            nodeParm = configInfo.get("app.sibjms.provider.%d.node" % idx,"")
            serverParm = configInfo.get("app.sibjms.provider.%d.server" % idx,"")
            
            doIterationProcessing = 0
            mePartitionNode = 0
            mePartitionServer = 0
            meNodes = []
      
            if (clusterParm.find("@ITERATE") >= 0):
              doIterationProcessing = 1
              tempArgs = parseFunctionParms(clusterParm)
              if (len(tempArgs) > 0):
                clusterParm = tempArgs[0]
              else:
                clusterParm = "*"
      
            if (nodeParm.find("@ITERATE") >= 0):
              doIterationProcessing = 1
              tempArgs = parseFunctionParms(nodeParm)
              if (len(tempArgs) > 0):
                nodeParm = tempArgs[0]
              else:
                nodeParm = "*"
            elif (nodeParm.find("@ME_PARTITION") >= 0):
              meNodes = parseFunctionParms(nodeParm)
              mePartitionNode = 1
            
      
            if (serverParm.find("@ITERATE") >= 0):
              doIterationProcessing = 1
              tempArgs = parseFunctionParms(serverParm)
              if (len(tempArgs) > 0):
                serverParm = tempArgs[0]
              else:
                serverParm = "*"
            elif (serverParm.find("@ME_PARTITION") >= 0):
              meNodes = parseFunctionParms(serverParm)
              mePartitionServer = 1
            
            clusterPattern = clusterParm
            nodePattern = nodeParm
            serverPattern = serverParm 
            
            if (doIterationProcessing):
              if (serverPattern.find("*") >= 0):
                serverPattern = wildcardToRegExpString(serverPattern)
              if (nodePattern.find("*") >= 0):
                nodePattern = wildcardToRegExpString(nodePattern)
              if (clusterPattern.find("*") >= 0):
                clusterPattern = wildcardToRegExpString(clusterPattern)
                
              providerIds = matchItemsAtScope("SIB JMS Resource Adapter", "J2CResourceAdapter", clusterPattern, nodePattern, serverPattern)
              for providerId in providerIds:
                tc,tn,ts = getScope(providerId)
                scopeString = scopeInfoString(tc,tn,ts)
                _app_message("Processing settings for SIB JMS Resource Adapter at %s scope" % (scopeString))
                
                # Get a copy of the properties
                subConfigInfo = filterProperties(configInfo,"app.sibjms.provider.%d" % idx)
                subConfigInfo["app.sibjms.provider.%d.cluster" % idx] = tc
                subConfigInfo["app.sibjms.provider.%d.node" % idx] = tn
                subConfigInfo["app.sibjms.provider.%d.server" % idx] = ts
                
                processSIBJMSComponentsAtScope(subConfigInfo,tc,tn,ts,"app.sibjms.provider.%d" % idx)
            elif (mePartitionNode):
              # We'll be creating these resources across the nodes of the cluster
              nodesDict = determineMessagingEngineKeywordsByNode(clusterParm,meNodes)
              
              nodeList = getClusterMemberNodeList(clusterParm)
              for nodeName in nodeList:
                subConfigInfo = filterProperties(configInfo,"app.sibjms.provider.%d" % idx)
                subConfigInfo["app.sibjms.provider.%d.cluster" % idx] = ""
                subConfigInfo["app.sibjms.provider.%d.node" % idx] = nodeName
                subConfigInfo["app.sibjms.provider.%d.server" % idx] = ""
                
                keywordDict = nodesDict.get(nodeName)
                setDynamicKeys(keywordDict)
            
                processSIBJMSComponentsAtScope(subConfigInfo,"",nodeName,"","app.sibjms.provider.%d" % idx)
                
                removeDynamicKeys(keywordDict)
              #endfor
                              
            elif (mePartitionServer):    
              # We'll be creating these resources across the servers of the cluster
              nodesDict = determineMessagingEngineKeywordsByNode(clusterParm,meNodes)
              
              #for key in nodesDict.keys():
                #keywordDict = nodesDict[key]
                #print "%s %s" % (key, keywordDict)

              memberList = getClusterMemberList(clusterParm)
              for memberInfo in memberList:
                
                                
                memberName = memberInfo[0]
                memberNode = memberInfo[1]

                subConfigInfo = filterProperties(configInfo,"app.sibjms.provider.%d" % idx)
                subConfigInfo["app.sibjms.provider.%d.cluster" % idx] = ""
                subConfigInfo["app.sibjms.provider.%d.node" % idx] = memberNode
                subConfigInfo["app.sibjms.provider.%d.server" % idx] = memberName
                
                keywordDict =  nodesDict.get(memberNode)
                setDynamicKeys(keywordDict)
                
                processSIBJMSComponentsAtScope(subConfigInfo,"",memberNode,memberName,"app.sibjms.provider.%d" % idx)
                
                removeDynamicKeys(keywordDict)
              #endfor
                
              
            else:
              # No @ITERATE, so Process the provider as specified
              processSIBJMSComponentsAtScope(configInfo,clusterParm,nodeParm,serverParm,"app.sibjms.provider.%d" % idx)
              
                        
    else:
        _app_message("Skipping SIB JMS Settings")       
  except:
    _app_trace("Unexpected error processing SIBus JMS settings","exception")
    _app_message("Unexpected error processing SIBus JMS settings")
    exit()

		

#enddef