##########################################################################################
# ProcessJDBC.py
#
# This module contains the functions that process the input properties for JDBC provider and
# data source definitions.  The properties should have already been loaded into the global
# configInfo dictionary prior to calling the processJDBC() function.
#
# Primary function: 
#    processJDBC()
#
# Related modules:
#		 Jdbc.py - Contains functions used to create/modify providers and datasources
#    Utils.py - Utility methods
#
# Property Syntax:
# 
# Here's a breakdown of the JDBC Provider and Data Source properties.  There are
# several subsections for a data source definition.  The dumpConfig.py script should
# be used to see specific property names.
#
# # Leave cluster, node,server empty for cell scope
# app.jdbc.provider.<index>.cluster =  <Name of cluster if at cluster scope>
# app.jdbc.provider.<index>.node =     
# app.jdbc.provider.<index>.server =
#
# #Provider Properties
# 
# app.jdbc.provider.<index>.prop.name = <Provider name - should be unique even for script processing>
# app.jdbc.provider.<index>.prop.description = <Provider description>
# app.jdbc.provider.<index>.prop.implementationClassName = <implemenation class>
# app.jdbc.provider.<index>.prop.classpath = <classpath>
# app.jdbc.provider.<index>.prop.nativepath = <Native path>
# app.jdbc.provider.<index>.prop.providerType = <Provider type info>
# app.jdbc.provider.<index>.prop.xa = <true|false>
#
# # The optional allowUpdate flag should be set to false if you want to prevent update existing provider def
# app.jdbc.provider.<index>.allowUpdate = <true|false>
#
# # Data source settings - 0 or more data sources per provider
# # Data source name
# app.jdbc.provider.<index>.ds.<dsindex>.dsAttrs.prop.name = <Data source name - should be unique for script processing>
# # CMP Factory
# app.jdbc.provider.<index>.ds.<dsindex>.createCMPFactory = <true|false>
# # Data source base properties 
# app.jdbc.provider.<index>.ds.<dsindex>.dspropAttrs.prop.<property-name1> = <property-value1>
# app.jdbc.provider.<index>.ds.<dsindex>.dspropAttrs.prop.<property-name2> = <property-value2>
# ...
# # Data source mapping properties
# app.jdbc.provider.<index>.ds.<dsindex>.mapAttrs.prop.<map-property1> = <map-value1>
# app.jdbc.provider.<index>.ds.<dsindex>.mapAttrs.prop.<map-property2> = <map-value2>
# ...
# # Data source connection pool properties
# app.jdbc.provider.<index>.ds.<dsindex>.connpool.prop.<conn-pool-property1> = <conn-pool-value1>
# app.jdbc.provider.<index>.ds.<dsindex>.connpool.prop.<conn-pool-property2> = <conn-pool-value2>
# ...
# app.jdbc.provider.<index>.ds.<dsindex>.connpool.customProperties.prop.<Custom-property1> = <value1>
# app.jdbc.provider.<index>.ds.<dsindex>.connpool.customProperties.prop.<Custom-property2> = <value2>
# ...
# # Data source resource properties (maps custom properties and other fields)
# app.jdbc.provider.<index>.ds.<dsindex>.rpAttrs.prop.<property1> = <value1>
# app.jdbc.provider.<index>.ds.<dsindex>.rpAttrs.prop.<property2> = <value2>|<description2>
# ...
# app.jdbc.provider.<index>.ds.count = <number of data sources for this provider>
# ...
# app.jdbc.provider.count = <number of providers>
#
# ----------------------------------------------------------------------------------------
# Iteration Syntax
#
# There is special support for applying settings accross some or all providers and datasources
# using the special @ITERATE(wildcard-pattern) or @ITERATE syntax.  Here's an example that
# will update the connection pool properties for all data sources that are cluster scoped in
# clusters starting with Sample:
 
# app.jdbc.provider.1.cluster = @ITERATE(Sample*)
# app.jdbc.provider.1.node = 
# app.jdbc.provider.1.server = 
#
# app.jdbc.provider.1.prop.name = @ITERATE(*)
#
# app.jdbc.provider.1.ds.1.dsAttrs.prop.name = @ITERATE
#
# app.jdbc.provider.1.ds.1.dspropAttrs.prop.statementCacheSize = 100
#
# app.jdbc.provider.1.ds.1.connpool.prop.agedTimeout = 0
# app.jdbc.provider.1.ds.1.connpool.prop.connectionTimeout = 65
# app.jdbc.provider.1.ds.1.connpool.prop.freePoolDistributionTableSize = 0
# app.jdbc.provider.1.ds.1.connpool.prop.maxConnections = 10
# app.jdbc.provider.1.ds.1.connpool.prop.minConnections = 0
# app.jdbc.provider.1.ds.1.connpool.prop.purgePolicy = EntirePool
# app.jdbc.provider.1.ds.1.connpool.prop.reapTime = 95
# app.jdbc.provider.1.ds.1.connpool.prop.unusedTimeout = 1801
#
#---------------------------------------------------------------------------------------
# Deleting providers and data sources
# 
# You can use the "del.jdbc.provider" prefix to flag providers and/or data sources for
# deletion.  The following example deletes the data sources under the specified provider
# but does not delete the provider.  
#
# del.jdbc.provider.1.cluster = 
# del.jdbc.provider.1.node = 
# del.jdbc.provider.1.server = 
# 
# del.jdbc.provider.1.prop.name = DB2 Universal JDBC Driver Provider (XA)
#
# del.jdbc.provider.1.deleteProvider = false
#
# del.jdbc.provider.1.ds.1.dsAttrs.prop.name = FirstDS
# 
# del.jdbc.provider.1.ds.2.dsAttrs.prop.name = MySimpleDS
#
# The following example will delete the provider and any data sources underneath it.
#
# del.jdbc.provider.1.cluster = 
# del.jdbc.provider.1.node = 
# del.jdbc.provider.1.server = 
# 
# del.jdbc.provider.1.prop.name = DB2 Universal JDBC Driver Provider (XA)
#
# del.jdbc.provider.1.deleteProvider = true
#----------------------------------------------------------------------------------------
# Moving a provider
#
# You can also use the moveProvider option to recreate the provider in a different scope
# after deleting it. The following will delete a provider and recreate it at a cluster scope.
#
# The moveProvider=true option can only be used with deleteProvider=true
#
# del.jdbc.provider.1.cluster = 
# del.jdbc.provider.1.node = 
# del.jdbc.provider.1.server = 
# 
# del.jdbc.provider.1.prop.name = MyProvider
#
# del.jdbc.provider.1.moveProvider = true
# del.jdbc.provider.1.moveProvider.cluster = MyNewCluster
#
# del.jdbc.provider.1.deleteProvider = true

#----------------------------------------------------------------------------------------
# Moving/Iteration combo
#
# The following example shows how @ITERATE, the moveProvider, and @FINDMATCHINGCLUSTER
# can be used to move all cell scoped providers to a cluster that closely matches the
# providers name.  
#
# 
# del.jdbc.provider.1.cluster = 
# del.jdbc.provider.1.node = 
# del.jdbc.provider.1.server = 
# 
# del.jdbc.provider.1.prop.name = @ITERATE(*_*_*_*)
#
# del.jdbc.provider.1.moveProvider = true
# del.jdbc.provider.1.moveProvider.cluster = @FINDMATCHINGCLUSTER
#
# del.jdbc.provider.1.deleteProvider = true
#
##########################################################################################


def findLikelyCluster(providerName):
  retval = ""
  
  clusterList = AdminConfig.list("ServerCluster").split(progInfo['line.separator'])
  for clusterId in clusterList:
    clusterName = AdminConfig.showAttribute(clusterId,"name")
    if (providerName.startswith(clusterName) and len(clusterName) > len(retval)):
      # Consider this our current best match but keep looking
      retval = clusterName
  
  return retval

#-------------------------------------------------------------------------------
# processDataSourceDeletion
#
# Perform the update processing for a specific datasource definition
# 
# Parameters:
#    jdbcInfo - dictionary with the configuration properties
#    scope - the configuration ID of the object that the provider is scoped under
#    pScope - a text string that identifies the scope
#    pName - the name of the provider
#    provider - the configuration ID of the provider
#    radapter - the configuration ID of the J2CResourceAdapter for CMP factories
#    prefix - the prefix to use for pulling properties
#-------------------------------------------------------------------------------
def processDataSourceDeletion(jdbcInfo,scope, pScope, pName, dsName, provider, radapter, prefix):
  
  
  global progInfo
  
  try:
  
 
    # See if the data source exists
    existingDS=checkForExistingDataSource(provider, dsName)
    if isEmpty(existingDS):
      _app_message("Datasource %s does not exist under %s at %s scope and does not need to be deleted" % (dsName, pName, pScope))
    else:
      # Need to delete any CMP factory that references this data source
      deleteCMPConnectorFactoryForDatasource(radapter, existingDS)
      
      # Now delete the data source
      deleteJDBCDataSource(existingDS)
      
      _app_message("Datasource %s has been deleted under provider %s at %s scope" % (dsName,pName,pScope))
       

  except:
    _app_trace("Unexpected error in processDataSourceDeletion","exception")
    exit()
    
#enddef processDataSourceDeletion


#---------------------------------------------------------------------------------------------------
# processJDBCProviderAndDataSourcesDeletions 
# Process the deletion instructions for a JDBC provider and the data sources defined underneath it
#
# PARAMETERS:
#
#   scope - ID of scoped object 
#   pScope - String indicating type of scope (cell/node/cluster/server)
#   pName - Name of JDBC Provider
#   radapter - ID of J2CResourceAdapter 
#   prefix - prefix used to pull properties from jdbcInfo map
# 
# Based on the old processJDBCProviderAndDataSources code
#---------------------------------------------------------------------------------------------------
def processJDBCProviderAndDataSourcesDeletions(jdbcInfo,scope, pScope, pName, radapter, prefix):

  
  global progInfo
  
  try:
  
    deleteProvider = "false"
    moveProvider = "false"
    newJdbcInfo = {}
    
    # See if the provider exists and if we should delete it
    provider = findExistingJDBCProvider(scope, pName)
    
    setDynamicId("CURRENT_PROVIDER_NAME",pName)
    
    if (provider != None):
        # See if we should do the deletion
        deleteProvider = jdbcInfo.get("%s.deleteProvider" % (prefix),"false")
        
        if (deleteProvider.lower() == "true"):
            # Ok, we're deleting the provider
            
            # First, let's see if we need to harvest the current configuration 
            moveProvider = jdbcInfo.get("%s.moveProvider" % (prefix),"false")
            
            if (moveProvider.lower() == "true"):
              newCluster = jdbcInfo.get("%s.moveProvider.cluster"%prefix,"")
              newNode = jdbcInfo.get("%s.moveProvider.node"%prefix,"")
              newServer = jdbcInfo.get("%s.moveProvider.server"%prefix,"")
              
              # Support dynamic values for these fields
              newCluster = substituteDynamicValues("%s.moveProvider.cluster"%prefix, newCluster)
              newNode = substituteDynamicValues("%s.moveProvider.node"%prefix, newNode)
              newServer = substituteDynamicValues("%s.moveProvider.server"%prefix, newServer)
              
              if (newCluster == "@FINDMATCHINGCLUSTER"):
                newCluster = findLikelyCluster(pName)
                
                if (isEmpty(newCluster)):
                  _app_message("Unable to find matching target cluster for %s" % pName)
                  exit()
                else:
                  _app_message("Provider %s will be moved to cluster %s" % (pName, newCluster))
              
              newJdbcInfo = {}
              
              providerProps = getJDBCProviderProperties(provider,prefix="move.jdbc.provider")
              for key in providerProps.keys():
                newJdbcInfo[key] = providerProps.get(key)
              
              newJdbcInfo["move.jdbc.provider.cluster"] = newCluster
              newJdbcInfo["move.jdbc.provider.node"] = newNode
              newJdbcInfo["move.jdbc.provider.server"] = newServer
              newJdbcInfo["move.jdbc.provider.prop.name"] = pName
              
              # Now create entries for each data source
              moveIds = findMatchingDataSources(provider, ".*")
              moveCount = 0
              for tempId in moveIds:
                if (isEmpty(tempId)): continue
                moveCount += 1
                dsTempProps = getDataSourceInfo(tempId,1,1, "move.jdbc.provider.ds.%d" % moveCount,radapter,1)
                
                for key in dsTempProps.keys():
                  newJdbcInfo[key] = dsTempProps.get(key)
             
              # Store the count of data sources
              newJdbcInfo["move.jdbc.provider.ds.count"] = "%d" % moveCount
              
            
            # First step, clean up CMPConnectorFactory references
            deleteCMPConnectorFactoriesForProvider(radapter, provider)
            
            # Now delete the provider
            deleteJDBCProvider(provider)
            
            _app_message("Provider %s at %s scope has been deleted" % (pName, pScope))
            
            # Now we'll create the new provider and data sources using captured properties
            if (len(newJdbcInfo) > 0):
              defConnPoolProps = java.util.Properties()
              processIndividualJDBC(newJdbcInfo,"move.jdbc.provider", defConnPoolProps)
              
              # Support for additional cluster move targets, space separated
              altClusters = jdbcInfo.get("%s.moveProvider.alternativeClusters"%prefix,"")
              altNames = jdbcInfo.get("%s.moveProvider.alternativeNames"%prefix,"")
              
              if (not isEmpty(altNames)):
                altNamesList = altNames.split(" ")
              else:
                altNamesList = []
              
              if (not isEmpty(altClusters)):
                # print "alternativeClusters: %s" % altClusters
                altClusterList = altClusters.split(" ")
                altNameIdx = -1
                for altCluster in altClusterList:
                  altNameIdx = altNameIdx + 1
                  
                  if (isEmpty(altCluster)):
                    continue
                  # Confirm the cluster exists
                  altId = AdminConfig.getid("/ServerCluster:%s/" % altCluster)
                  if (isEmpty(altId)):
                    _app_message("Server cluster %s does not exist, the provider will not be moved to it" % altCluster)
                    continue
                  else:
                    newJdbcInfo["move.jdbc.provider.cluster"] = altCluster
                    newJdbcInfo["move.jdbc.provider.node"] = ""
                    newJdbcInfo["move.jdbc.provider.server"] = ""
                    
                    # See if we have a new name for the moved provider
                    if (altNameIdx < len(altNamesList)):
                      newJdbcInfo["move.jdbc.provider.prop.name"]  = altNamesList[altNameIdx]
                    else:
                      newJdbcInfo["move.jdbc.provider.prop.name"]  = pName
                    
                    _app_message("Creating JDBC Provider %s under alternative cluster %s" % (newJdbcInfo["move.jdbc.provider.prop.name"], altCluster))
                    processIndividualJDBC(newJdbcInfo,"move.jdbc.provider", defConnPoolProps)
                    
                    
            
            
            
        else:
            _app_message("Found existing JDBC Provider %s - Will only delete specified data sources" % (pName))
    
    else:
        _app_message("JDBC Provider %s does not exist. No delete necessary" % pName)
          
    #end else provider needs to be created
  
    
    # If we did not delete the provider, we need to process individual data source deletions
    if (deleteProvider != "true"):
      # Check to see if there are data sources to process
      if not jdbcInfo.has_key("%s.ds.count" % prefix):
        return
    
      # Process each data source
      for jpidx in range(1, int(jdbcInfo["%s.ds.count" % (prefix)]) + 1):
    
        
        # Process the properties in jdbcInfo into lists for each sub-element of the
        # data source.  If this is an update to an existing data source, we'll only
        # update input properties that are different than existing configuration
            
       
        dsName = jdbcInfo.get("%s.ds.%d.dsAttrs.prop.name" % (prefix,jpidx),"")
        if (isEmpty(dsName)): 
          continue
        
        if (dsName.find("@ITERATE") >= 0):
            originalDSName = dsName
            tempArgs = parseFunctionParms(dsName)
            tempName = None
            if (len(tempArgs) > 0):
              tempName = tempArgs[0]
            else:
              tempName = "*"
              
            dsNamePattern = wildcardToRegExpString(tempName)
            dsIds = findMatchingDataSources(provider, dsNamePattern)
            if (len(dsIds) > 0):
              _app_message("%d Data Sources matched the pattern %s" % (len(dsIds),tempName))
              for dsId in dsIds:
                if (isEmpty(dsId)): continue
                
                # Create a temp copy of the properties we need
                tempJdbcInfo = filterProperties(jdbcInfo,"%s.ds.%d" % (prefix,jpidx))
                
                # Spoof the name into the properties
                currentName = AdminConfig.showAttribute(dsId,"name")
                
                tempJdbcInfo["%s.ds.%d.dsAttrs.prop.name" % (prefix,jpidx)] = currentName
                
                # Now process this datasource
                processDataSourceDeletion(tempJdbcInfo,scope, pScope, pName, currentName, provider, radapter, "%s.ds.%d" % (prefix,jpidx))
          
            else:
              _app_message("No Data Sources matched the pattern %s" % (tempName))
       
        else:
          processDataSourceDeletion(jdbcInfo,scope, pScope, pName, dsName, provider, radapter, "%s.ds.%d" % (prefix,jpidx))

      #endfor each datasource in list
      
    # end if we need to process data sources  
    setDynamicId("CURRENT_PROVIDER_NAME","")
    _app_message(" ")
    
  except:
    _app_trace("Unexpected error in processJDBCProviderAndDataSourcesDeletions","exception")
    exit()     
#enddef
      



#---------------------------------------------------------------------------------------------------
# processIndividualJDBC - process the settings for an indivdual JDBC provider
#                         based on buildCreateIndividualJDBC(prefix, defConnPoolProps):
#---------------------------------------------------------------------------------------------------
def processIndividualJDBCDeletions(jdbcInfo,prefix):
  
  
  global progInfo
  
  try:
    # Delete JDBC Provider
    pCluster = jdbcInfo.get("%s.cluster" % prefix,"")
    pNode   = jdbcInfo.get("%s.node" % (prefix),"")
    pServer = jdbcInfo.get("%s.server" % (prefix),"")
  
    # Template name is optional
    templateName = jdbcInfo.get("%s.templateName" % prefix, "")
  	
    # Database Provider properties
    subProps = getPropList(jdbcInfo, "%s" % (prefix))
    if (subProps.size() > 0):
      pName = subProps["name"]
  
    if (pName.find("Derby") >= 0) :
      _app_message("Skipping Derby provider %s" % (prefix))
      return
      
   
  
    if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
      _app_message("Processing cell scoped JDBC Provider. Provider=[%s]" % pName)
      pScope = "cell"
      cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
      for cell in cells:
        radapter=AdminConfig.getid("/Cell:%s/J2CResourceAdapter:WebSphere Relational Resource Adapter/" % AdminConfig.showAttribute(cell,"name"))
        processJDBCProviderAndDataSourcesDeletions(jdbcInfo,cell, pScope, pName, radapter, prefix)
    else:
      if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer): 
        _app_message("Processing cluster-scoped JDBC Provider.  Cluster=[%s] Provider=[%s]" % (pCluster, pName))
        pScope = "cluster"
        cluster = AdminConfig.getid("/ServerCluster:%s" % pCluster)
        radapter=AdminConfig.getid("/ServerCluster:%s/J2CResourceAdapter:WebSphere Relational Resource Adapter/" % AdminConfig.showAttribute(cluster,"name"))
        processJDBCProviderAndDataSourcesDeletions(jdbcInfo,cluster, pScope, pName, radapter, prefix)
      else:
        if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
          _app_message("Processing node-scoped JDBC Provider.  Node=[%s] Provider=[%s]" % (pNode, pName))
          pScope = "node"
          node = AdminConfig.getid("/Node:%s" % pNode)
          radapter=AdminConfig.getid("/Node:%s/J2CResourceAdapter:WebSphere Relational Resource Adapter/" % AdminConfig.showAttribute(node,"name"))
          processJDBCProviderAndDataSourcesDeletions(jdbcInfo,node, pScope, pName, radapter, prefix)
        else:
          if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
            _app_message("Processing server-scoped JDBC Provider.  Node=[%s] Server=[%s] Provider=[%s]" % (pNode, pServer, pName))
            pScope = "server"
            server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
            radapter=AdminConfig.getid("/Server:%s/J2CResourceAdapter:WebSphere Relational Resource Adapter/" % AdminConfig.showAttribute(server,"name"))
            processJDBCProviderAndDataSourcesDeletions(jdbcInfo,server, pScope, pName, radapter, prefix)
  except:
    _app_trace("Unexpected error in processIndividualJDBCDeletions","exception")
    exit()

#enddef


#---------------------------------------------------------------------------------------------------
# processJDBC(): Process all of the JDBC entries from the jdbcInfo set
#                Based on logic formerly implemented in buildCreateJDBC
#---------------------------------------------------------------------------------------------------
def processJDBCDeletions(jdbcInfo):
  
  try:
  
    providerCount = int(jdbcInfo.get("del.jdbc.provider.count","0"))
  	
    if (providerCount > 0):
      
      for jpidx in range(1, (providerCount + 1)):
        prefix = "del.jdbc.provider.%d" % (jpidx)
        providerName = jdbcInfo.get("%s.prop.name" % prefix,"")
        if (isEmpty(providerName)):
        		# Partial input property file, skip this provider
        		continue
        
        clusterParm = jdbcInfo.get("%s.cluster" % prefix,"")
        nodeParm = jdbcInfo.get("%s.node" % prefix,"")
        serverParm = jdbcInfo.get("%s.server" % prefix,"")
        
        doIterationProcessing = 0
        if (providerName.find("@ITERATE") >= 0):
          
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(providerName)
          if (len(tempArgs) > 0):
            providerName = tempArgs[0]
           
          else:
            providerName = "*"
  
        if (clusterParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(clusterParm)
          if (len(tempArgs) > 0):
            clusterParm = tempArgs[0]
          else:
            clusterParm = "*"
  
        if (nodeParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(nodeParm)
          if (len(tempArgs) > 0):
            nodeParm = tempArgs[0]
          else:
            nodeParm = "*"          
  
        if (serverParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(serverParm)
          if (len(tempArgs) > 0):
            serverParm = tempArgs[0]
          else:
            serverParm = "*"    
        
        providerPattern = providerName
        clusterPattern = clusterParm
        nodePattern = nodeParm
        serverPattern = serverParm 
        
        if (doIterationProcessing):
          if (providerPattern.find("*") >= 0):
            providerPattern = wildcardToRegExpString(providerPattern)
          if (serverPattern.find("*") >= 0):
            serverPattern = wildcardToRegExpString(serverPattern)
          if (nodePattern.find("*") >= 0):
            nodePattern = wildcardToRegExpString(nodePattern)
          if (clusterPattern.find("*") >= 0):
            clusterPattern = wildcardToRegExpString(clusterPattern)
            
          providerIds = findMatchingJDBCProviders(providerPattern, clusterPattern, nodePattern, serverPattern)
          
          if (len(providerIds) > 0):
            _app_message("%d JDBC providers matched the @ITERATE patterns name=%s, cluster=%s, node= %s, server = %s" % (len(providerIds), providerName, clusterParm, nodeParm, serverParm))
            
            # Get a copy of the configuration properties that we can manipulate
            tempJdbcInfo = filterProperties(jdbcInfo,prefix)
            
            for providerId in providerIds:
              if (isEmpty(providerId)): continue
              tempName = AdminConfig.showAttribute(providerId,"name")
              tc,tn,ts,tdc,tapp,tappdep = getScope(providerId)
              
              # We're going to spoof the settings into the jdbcInfo
              tempJdbcInfo["%s.prop.name" % prefix] = tempName
              tempJdbcInfo["%s.cluster" % prefix] = tc
              tempJdbcInfo["%s.node" % prefix] = tn
              tempJdbcInfo["%s.server" % prefix] = ts
              
              processIndividualJDBCDeletions(tempJdbcInfo,prefix)
              
              
          else:
            _app_message("No JDBC providers matched the @ITERATE patterns name=%s, cluster=%s, node= %s, server = %s" % (providerName, clusterParm, nodeParm, serverParm))
        else:
          processIndividualJDBCDeletions(jdbcInfo,prefix)
  
    else:
        _app_message("Skipping JDBC Deletions...")
  except:
    _app_trace("Unexpected error in processJDBCDeletions","exception")
    exit()

#enddef processJDBCDeletions


#-------------------------------------------------------------------------------
# processDataSource
#
# Perform the update processing for a specific datasource definition
# 
# Parameters:
#    jdbcInfo - dictionary with the configuration properties
#    scope - the configuration ID of the object that the provider is scoped under
#    pScope - a text string that identifies the scope
#    pName - the name of the provider
#    provider - the configuration ID of the provider
#    radapter - the configuration ID of the J2CResourceAdapter for CMP factories
#    prefix - the prefix to use for pulling properties
#    defConnPoolProps - default properties for connection pools
#-------------------------------------------------------------------------------
def processDataSource(jdbcInfo,scope, pScope, pName, dsName, provider, radapter, prefix, defConnPoolProps):
  
  
  global progInfo
  
  try:
  
    newds = "true"
    existingdsAttrs=None
    existingrpAttrs=None
    existingmapAttrs=None
    existingdspropAttrs=None
    existingConnPoolProps=None
    existingConnPoolCustomProps=None
    
    createCMP = 0
    
    # Process the properties in jdbcInfo into lists for each sub-element of the
    # data source.  If this is an update to an existing data source, we'll only
    # update input properties that are different than existing configuration
        
    dsAttrs = []
    dsSubProps = getPropList(jdbcInfo, "%s.dsAttrs" % (prefix))
    if (dsSubProps.size() > 0):
      for dsSubKey in dsSubProps.keys():
        dsAttrs.append([dsSubKey,dsSubProps[dsSubKey]])
  

      
    createCMPFlag = jdbcInfo.get("%s.createCMPFactory" % (prefix), "false")
    if (createCMPFlag == "true"):
    		createCMP = 1
    
    # See if the data source exists
    existingDS=checkForExistingDataSource(provider, dsName)
    if not isEmpty(existingDS):
        _app_trace("Get properties for existing data source %s %s" % (dsName, existingDS))
        newds = "false"
        
        checkForConnPoolCustomProps = checkForPrefix(jdbcInfo,"%s.connpool.customProperties" % (prefix))
        checkForResourceProps = checkForPrefix(jdbcInfo,"%s.rpAttrs" % (prefix))
        
        # Get property set representation of the data source
        existingProperties=getDataSourceInfo(existingDS,checkForConnPoolCustomProps,checkForResourceProps) 
        
        # Get sub-properties for specific elements of the existing data source
        existingdsAttrs=getPropList(existingProperties, "ds.dsAttrs")
        existingrpAttrs=getPropList(existingProperties, "ds.rpAttrs")
        existingmapAttrs=getPropList(existingProperties, "ds.mapAttrs")
        existingdspropAttrs=getPropList(existingProperties, "ds.dspropAttrs")
        existingConnPoolProps=getPropList(existingProperties,"ds.connpool")
        existingConnPoolCustomProps=getPropList(existingProperties,"ds.connpool.customProperties")

        
    dsSubProps = getPropList(jdbcInfo, "%s.dsAttrs" % (prefix))
    if (dsSubProps.size() > 0):
    		dsName = dsSubProps["name"]
    		
    if (newds == "false"):
        # We're only going to update the properties that are being modified
        # Compare input to the existing properties and get only the changes
        dsSubProps=getModifiedProperties(dsSubProps,existingdsAttrs)
    
    dsAttrs = []
    if (dsSubProps.size() > 0):
      for dsSubKey in dsSubProps.keys():
        dsAttrs.append([dsSubKey,dsSubProps[dsSubKey]])
        

    rpAttrs = getPropList(jdbcInfo, "%s.rpAttrs" % (prefix))
    if (newds == "false"):
        # We're only going to update the properties that are being modified
        # Compare input to the existing properties and get only the changes
        rpAttrs = getModifiedProperties(rpAttrs,existingrpAttrs)
      

    mapAttrs = []
    dsSubProps = getPropList(jdbcInfo, "%s.mapAttrs" % (prefix))
    if (newds == "false"):
        # We're only going to update the properties that are being modified
        # Compare input to the existing properties and get only the changes
        dsSubProps = getModifiedProperties(dsSubProps,existingmapAttrs)
        
    if (dsSubProps.size() > 0):
      for dsSubKey in dsSubProps.keys():
        # @JM - fix [] in properties
        val = dsSubProps[dsSubKey]
        if (val == "[]"):
          val = ""
        mapAttrs.append([dsSubKey,val])
      
    dspropAttrs = []
    dsSubProps = getPropList(jdbcInfo, "%s.dspropAttrs" % (prefix))
    
    # Trim quotes around description
    descriptionVal = dsSubProps.get("description")
    if (descriptionVal != None and (descriptionVal.startswith("'") or descriptionVal.startswith('"'))):
    		descriptionVal = descriptionVal[1:-1]
    		dsSubProps.put("description",descriptionVal)
    		
    if (newds == "false"):
        # We're only going to update the properties that are being modified
        # Compare input to the existing properties and get only the changes
        dsSubProps = getModifiedProperties(dsSubProps,existingdspropAttrs)
        
    if (dsSubProps.size() > 0):
      for dsSubKey in dsSubProps.keys():
        if (dsSubKey == "providerType"):
          # Skip this read-only value
          continue
          
        val = dsSubProps.get(dsSubKey)
        dspropAttrs.append(["%s" % dsSubKey,"%s" % val])
      
    connPoolProps = defConnPoolProps
    dsSubProps = getPropList(jdbcInfo, "%s.connpool" % (prefix))
    if (newds == "false") :
        # We're only going to update the properties that are being modified
        # Compare input to the existing properties and get only the changes
        dsSubProps = getModifiedProperties(dsSubProps, existingConnPoolProps)
        connPoolProps = dsSubProps
    else:
        # Merge passed in properties with preferred defaults
        if (dsSubProps.size() > 0):
          for dsSubKey in dsSubProps.keys():
            connPoolProps.put(dsSubKey,dsSubProps[dsSubKey])
            
    connPoolCustomProps =  getPropList(jdbcInfo, "%s.connpool.customProperties" % (prefix))
    if (newds == "false"):
    		# We're only going to update the properties that are being modified
    		connPoolCustomProps = getModifiedProperties(connPoolCustomProps, existingConnPoolCustomProps)
    		
          
    connPoolAttrs = []
    if (connPoolProps.size() > 0):
      for dsSubKey in connPoolProps.keys():
        connPoolAttrs.append([dsSubKey,connPoolProps[dsSubKey]])
        
        
    # Now that we've processed the input, create or update the data source
    if (newds == "true"):
      # Create a new data source - calls method from library script
      # Use flag to keep from repeating name search
      ds = createJDBCDataSource(scope, radapter, provider, dsName, dsAttrs, rpAttrs, mapAttrs, dspropAttrs, connPoolAttrs, connPoolCustomProps,createCMP,0)
      if (not isEmpty(ds)):
      		_app_message("Created JDBC Datasource %s for provider %s at %s scope" % (dsName, pName, pScope))
      else:
      		_app_message("Error creating JDBC Datasource %s for provider %s at %s scope" % (dsName, pName, pScope))
      		exit()
      
    else:
      # Modify an existing data source - call method from library script
      if (len(dsAttrs) == 0 and rpAttrs.size() == 0 and len(mapAttrs) == 0 and len(dspropAttrs) == 0 and len(connPoolAttrs) == 0 and connPoolCustomProps.size() == 0):
      		_app_message("No updates needed for JDBC Datasource %s for provider %s at %s scope" % (dsName, pName, pScope))
      else:
      		
        ds = modifyJDBCDataSource(existingDS, radapter, provider, dsName, dsAttrs, rpAttrs, mapAttrs, dspropAttrs, connPoolAttrs,connPoolCustomProps)
        if (ds == None):
            _app_message("Error occurred updating JDBC Datasource %s for provider %s at %s scope" % (dsName, pName, pScope))
            exit()
        else:
            _app_message("Modified JDBC Datasource %s for provider %s at %s scope" % (dsName, pName, pScope))
      

  except:
    _app_trace("Unexpected error in processDataSource","exception")
    exit()
    
#enddef processDataSource
    

#---------------------------------------------------------------------------------------------------
# processJDBCProviderAndDataSources 
# Process the settings for a JDBC provider and the data sources defined underneath it
#
# PARAMETERS:
#
#   scope - ID of scoped object 
#   pScope - String indicating type of scope (cell/node/cluster/server)
#   pName - Name of JDBC Provider
#		templateName - Optional template name
#   radapter - ID of J2CResourceAdapter 
#   providerAttrs - list of attributes for JDBC provider
#   prefix - prefix used to pull properties from jdbcInfo map
#   defConnPoolProps - property set with default settings to use for connection pools
# 
# Based on the old processJDBCProviderAndDataSources code
#---------------------------------------------------------------------------------------------------
def processJDBCProviderAndDataSources(jdbcInfo,scope, pScope, pName, templateName, radapter, providerAttrs, prefix, defConnPoolProps):

  
  global progInfo
  
  try:
	
    # See if the provider exists and if we should update it
    provider = findExistingJDBCProvider(scope, pName)
    
    if (provider != None):
    		# See if we should attempt update
    		allowUpdate = jdbcInfo.get("%s.allowUpdate" % (prefix),"true")
    		
    		if (allowUpdate.lower() == "true"):
    				# See if there is a need by checking the properties
    				existingProps = getJDBCProviderProperties(provider)
    				subProps = getPropListDifferences(jdbcInfo, prefix, existingProps, "jdbc.provider")
    				if (subProps.size() > 0):
    						# We should do the update
    						
    						# First, updating classpath requires clearing existing property
    						if (subProps.get("classpath") != None):
    								if (modifyObject(provider,[["classpath", ""]])):
    										_app_message("Error clearing classpath for provider %s" % pName)
    										exit()
    						if (subProps.get("nativepath") != None):
    								if (modifyObject(provider,[["nativepath", ""]])):
    										_app_message("Error clearing classpath for provider %s" % pName)
    										exit()  						
    						
    						attrs = []
    						for key in subProps.keys():
    								if (key == "name" or key == "providerType"): 
    									continue
    								val = subProps.get(key)
    								if (key == "description" and (val.startswith("'") or val.startswith('"'))):
    										val = val[1:-1]
    								attrs.append([key,val])
    						
    						retval = modifyJDBCProvider(scope, provider, pName, attrs)
    						if (isEmpty(retval)):
    								_app_message("Failed to update JDBC Provider %s at scope %s" % (pName, scope))
    								exit()
    						else:
    								_app_message("Updated JDBC Provider %s" % (pName))
    				else:
    						_app_message("No updates for existing JDBC Provider %s" % (pName))
    		else:
    				_app_message("Found existing JDBC Provider %s - no updates to provider definition" % (pName))
    
    else:
    		# Create (or find existing) JDBC provider at the supplied scope
    		if (isEmpty(templateName)):
    				provider = createJDBCProvider(scope, pName, providerAttrs)
    		else:
    				provider = createJDBCProviderUsingTemplate(scope,pName,templateName,providerAttrs)
  
    		if isEmpty(provider):
    				_app_message("Failed to create JDBC Provider %s at scope %s" % (pName, pScope))
    				exit()
      		
    #end else provider needs to be created
  
    
  
    # Check to see if there are data sources to process
    if not jdbcInfo.has_key("%s.ds.count" % prefix):
      return
  
    # Process each data source
    for jpidx in range(1, int(jdbcInfo["%s.ds.count" % (prefix)]) + 1):
  
      
      # Process the properties in jdbcInfo into lists for each sub-element of the
      # data source.  If this is an update to an existing data source, we'll only
      # update input properties that are different than existing configuration
          
     
      dsName = jdbcInfo.get("%s.ds.%d.dsAttrs.prop.name" % (prefix,jpidx),"")
      if (isEmpty(dsName)): 
        continue
      
      if (dsName.find("@ITERATE") >= 0):
          originalDSName = dsName
          tempArgs = parseFunctionParms(dsName)
          tempName = None
          if (len(tempArgs) > 0):
            tempName = tempArgs[0]
          else:
            tempName = "*"
            
          dsNamePattern = wildcardToRegExpString(tempName)
          dsIds = findMatchingDataSources(provider, dsNamePattern)
          if (len(dsIds) > 0):
            _app_message("%d Data Sources matched the pattern %s" % (len(dsIds),tempName))
            for dsId in dsIds:
              if (isEmpty(dsId)): continue
              
              # Spoof the name into the jdbcInfo properties
              currentName = AdminConfig.showAttribute(dsId,"name")
              jdbcInfo["%s.ds.%d.dsAttrs.prop.name" % (prefix,jpidx)] = currentName
              
              # Now process this datasource
              processDataSource(jdbcInfo,scope, pScope, pName, currentName, provider, radapter, "%s.ds.%d" % (prefix,jpidx), defConnPoolProps)
            
            # Now restore the name for the next provider
            jdbcInfo["%s.ds.%d.dsAttrs.prop.name" % (prefix,jpidx)] = originalDSName
              
              
          else:
            _app_message("No Data Sources matched the pattern %s" % (tempName))
            
          
            
      else:
        processDataSource(jdbcInfo,scope, pScope, pName, dsName, provider, radapter, "%s.ds.%d" % (prefix,jpidx), defConnPoolProps)
        
  
    #endfor each datasource in list
    
    _app_message(" ")
    
  except:
    _app_trace("Unexpected error in processJDBCProviderAndDataSources","exception")
    exit()     
#enddef
      

#---------------------------------------------------------------------------------------------------
# processIndividualJDBC - process the settings for an indivdual JDBC provider
#                         based on buildCreateIndividualJDBC(prefix, defConnPoolProps):
#---------------------------------------------------------------------------------------------------
def processIndividualJDBC(jdbcInfo,prefix, defConnPoolProps):
  
  
  global progInfo
  
  try:
    # Create JDBC Provider
    pCluster = jdbcInfo.get("%s.cluster" % prefix,"")
    pNode   = jdbcInfo.get("%s.node" % (prefix),"")
    pServer = jdbcInfo.get("%s.server" % (prefix),"")
  
    # Template name is optional
    templateName = jdbcInfo.get("%s.templateName" % prefix, "")
  	
    # Database Provider properties
    subProps = getPropList(jdbcInfo, "%s" % (prefix))
    if (subProps.size() > 0):
      pName = subProps["name"]
      providerAttrs = []
      for key in subProps.keys():
        val = subProps.get(key)
        if (key == "description" and (val.startswith("'") or val.startswith('"'))):
            val = val[1:-1]
        providerAttrs.append([key,val])
  
    if (pName.find("Derby") >= 0) :
      _app_message("Skipping Derby provider %s" % (prefix))
      return
      
   
  
    if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
      _app_message("Processing cell scoped JDBC Provider. Provider=[%s]" % pName)
      pScope = "cell"
      cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
      for cell in cells:
        radapter=AdminConfig.getid("/Cell:%s/J2CResourceAdapter:WebSphere Relational Resource Adapter/" % AdminConfig.showAttribute(cell,"name"))
        processJDBCProviderAndDataSources(jdbcInfo,cell, pScope, pName, templateName, radapter, providerAttrs, prefix, defConnPoolProps)
    else:
      if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer): 
        _app_message("Processing cluster-scoped JDBC Provider.  Cluster=[%s] Provider=[%s]" % (pCluster, pName))
        pScope = "cluster"
        cluster = AdminConfig.getid("/ServerCluster:%s" % pCluster)
        radapter=AdminConfig.getid("/ServerCluster:%s/J2CResourceAdapter:WebSphere Relational Resource Adapter/" % AdminConfig.showAttribute(cluster,"name"))
        processJDBCProviderAndDataSources(jdbcInfo,cluster, pScope, pName, templateName, radapter, providerAttrs, prefix, defConnPoolProps)
      else:
        if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
          _app_message("Processing node-scoped JDBC Provider.  Node=[%s] Provider=[%s]" % (pNode, pName))
          pScope = "node"
          node = AdminConfig.getid("/Node:%s" % pNode)
          radapter=AdminConfig.getid("/Node:%s/J2CResourceAdapter:WebSphere Relational Resource Adapter/" % AdminConfig.showAttribute(node,"name"))
          processJDBCProviderAndDataSources(jdbcInfo,node, pScope, pName, templateName, radapter, providerAttrs, prefix, defConnPoolProps)
        else:
          if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
            _app_message("Processing server-scoped JDBC Provider.  Node=[%s] Server=[%s] Provider=[%s]" % (pNode, pServer, pName))
            pScope = "server"
            server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
            radapter=AdminConfig.getid("/Server:%s/J2CResourceAdapter:WebSphere Relational Resource Adapter/" % AdminConfig.showAttribute(server,"name"))
            processJDBCProviderAndDataSources(jdbcInfo,server, pScope, pName, templateName, radapter, providerAttrs, prefix, defConnPoolProps)
  except:
    _app_trace("Unexpected error in processIndividualJDBC","exception")
    exit()




#---------------------------------------------------------------------------------------------------
# processJDBC(): Process all of the JDBC entries from the jdbcInfo set
#                Based on logic formerly implemented in buildCreateJDBC
#---------------------------------------------------------------------------------------------------
def processJDBC():

  global configInfo
  
  try:
    
    # Before we do anything else, lets take a crack at any deletion instructions
    processJDBCDeletions(configInfo)
  
    providerCount = int(configInfo.get("app.jdbc.provider.count","0"))
  	
    if (providerCount > 0):
      # Create Individual JDBC Resources
      defConnPoolProps = getPropList(configInfo, "app.jdbc.ds.connpool")
  
      for jpidx in range(1, (providerCount + 1)):
        prefix = "app.jdbc.provider.%d" % (jpidx)
        providerName = configInfo.get("%s.prop.name" % prefix,"")
        if (isEmpty(providerName)):
        		# Partial input property file, skip this provider
        		continue
        
        clusterParm = configInfo.get("%s.cluster" % prefix,"")
        nodeParm = configInfo.get("%s.node" % prefix,"")
        serverParm = configInfo.get("%s.server" % prefix,"")
        
        doIterationProcessing = 0
        if (providerName.find("@ITERATE") >= 0):
          
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(providerName)
          if (len(tempArgs) > 0):
            providerName = tempArgs[0]
           
          else:
            providerName = "*"
  
        if (clusterParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(clusterParm)
          if (len(tempArgs) > 0):
            clusterParm = tempArgs[0]
          else:
            clusterParm = "*"
  
        if (nodeParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(nodeParm)
          if (len(tempArgs) > 0):
            nodeParm = tempArgs[0]
          else:
            nodeParm = "*"          
  
        if (serverParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(serverParm)
          if (len(tempArgs) > 0):
            serverParm = tempArgs[0]
          else:
            serverParm = "*"    
        
        providerPattern = providerName
        clusterPattern = clusterParm
        nodePattern = nodeParm
        serverPattern = serverParm 
        
        if (doIterationProcessing):
          if (providerPattern.find("*") >= 0):
            providerPattern = wildcardToRegExpString(providerPattern)
          if (serverPattern.find("*") >= 0):
            serverPattern = wildcardToRegExpString(serverPattern)
          if (nodePattern.find("*") >= 0):
            nodePattern = wildcardToRegExpString(nodePattern)
          if (clusterPattern.find("*") >= 0):
            clusterPattern = wildcardToRegExpString(clusterPattern)
            
          providerIds = findMatchingJDBCProviders(providerPattern, clusterPattern, nodePattern, serverPattern)
          
          if (len(providerIds) > 0):
            _app_message("%d JDBC providers matched the @ITERATE patterns name=%s, cluster=%s, node= %s, server = %s" % (len(providerIds), providerName, clusterParm, nodeParm, serverParm))
            
            
            for providerId in providerIds:
              if (isEmpty(providerId)): continue
              tempName = AdminConfig.showAttribute(providerId,"name")
              tc,tn,ts,tdc,tapp,tappdep = getScope(providerId)
              
              # We're going to spoof the settings into the configInfo
              configInfo["%s.prop.name" % prefix] = tempName
              configInfo["%s.cluster" % prefix] = tc
              configInfo["%s.node" % prefix] = tn
              configInfo["%s.server" % prefix] = ts
              
              processIndividualJDBC(configInfo,prefix, defConnPoolProps)
              
              
          else:
            _app_message("No JDBC providers matched the @ITERATE patterns name=%s, cluster=%s, node= %s, server = %s" % (providerName, clusterParm, nodeParm, serverParm))
        else:
          processIndividualJDBC(configInfo,prefix, defConnPoolProps)
  
    else:
        _app_message("Skipping JDBC Resources...")
  except:
    _app_trace("Unexpected error in processJDBC","exception")
    exit()