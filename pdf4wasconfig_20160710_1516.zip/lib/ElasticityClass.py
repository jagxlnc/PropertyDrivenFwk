################################################################################
# ElasticityClass.py
#
# This module contains functions for manipulating the Add and Remove Elasticity
# Operations configuration, which is backed by the ElasticityClass WCCM type.
#
# Required modules: Utils.py, common.py
#
# Functions:
#
#  modifyElasticityClass(ecId, ecProps, elasticityActions)
#  createElasticityClass(ecName, ecProps, elasticityActions) 
#  findElasticityClass(className)
#  getElasticityClassProperties(classId)
#
#
# For operations that define the custom elasticity actions, see CustomActions.py.
################################################################################

#-------------------------------------------------------------------------------
# modifyElasticityClass
#
# Parameters
#    ecId - The Elasticity Class to update
#    ecProps - base properties of the class
#    elasticityActions - a list of (type, attribute-dictionary) tuples that
#                        define the actions
#-------------------------------------------------------------------------------
def modifyElasticityClass(ecId, ecProps, elasticityActions):
  _app_entry("modifyElasticityClass(%s,%s,%s)" , ecId, ecProps, elasticityActions)
  retval = ecId
  try:
    if (ecProps != None and len(ecProps) > 0):
      attrs = propsToAttrList(ecProps)
      if (modifyObject(ecId,attrs)):
        raise StandardError("Propblem updating base properties")
    
    if (elasticityActions != None):
      # Remove existing actions
      actions = wsadminToList(AdminConfig.showAttribute(ecId,"ElasticityAction"))
      for actionId in actions:
        if (isEmpty(actionId)): 
          continue
        
        _app_trace("About to call AdminConfig.remove(%s)" % actionId)
        AdminConfig.remove(actionId)
      
      # Now create new actions
      for eAction in elasticityActions:
        actionType = eAction[0]
        actionProps = eAction[1]
        attrs = propsToAttrList(actionProps)
        AdminConfig.create(actionType,ecId,attrs)
        
  except:
    _app_exception("Unexpected problem in modifyElasticityClass()")
  
  _app_exit("modifyElasticityClass(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# CreateElasticityClass
#
# Normally the Add/Remove should exist and not be removed. This method is added
# for the "just-in-case" requirement that they have to be recreated
#
# Parameters
#    ecName - The Elasticity Class to create
#    ecProps - base properties of the class
#    elasticityActions - a list of (type, attribute-dictionary) tuples that
#                        define the actions
#-------------------------------------------------------------------------------
def createElasticityClass(ecName, ecProps, elasticityActions):
  _app_entry("createElasticityClass(%s,%s,%s)" , ecName, ecProps, elasticityActions)
  retval = None
  try:
    attrs = []
    if (ecProps != None and len(ecProps) > 0):
      attrs = propsToAttrList(ecProps)
    
    attrs.append(["name",ecName])
    
    retval = AdminConfig.create("ElasticityClass",getCellId(),attrs)
    
    if (elasticityActions != None):
      # Now create new actions
      for eAction in elasticityActions:
        actionType = eAction[0]
        actionProps = eAction[1]
        attrs = propsToAttrList(actionProps)
        AdminConfig.create(actionType,retval,attrs)
        
  except:
    _app_exception("Unexpected problem in createElasticityClass()")
  
  _app_exit("createElasticityClass(retval=%s)" % retval)
  return retval



#-------------------------------------------------------------------------------
# findElasticityClass
#
# Parameters
#   className ("Add" or "Remove")
#-------------------------------------------------------------------------------
def findElasticityClass(className):
  _app_entry("findElasticityClass(%s)" , className)
  retval = None
  try:
    #some stuff
    retval = AdminConfig.getid("/ElasticityClass:%s/" %className)
  except:
    _app_exception("Unexpected problem in findElasticityClass()")
  
  _app_exit("findElasticityClass(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# getElasticityClassProperties
#
# Parameters
#
# Returns dictionary with properites of ElasticityClass
#
#     -- Base properties
#     elasticityClass.prop.XXX  - base properties
#     -- Properties for the n HealthActions
#     elasticityClass.ElasticityAction.1-n.type = CustomElasticityAction  
#     elasticityClass.ElasticityAction.1-n.prop.XXX - elasticity action properties
#     elasticityClass.ElasticityAction = [list of 1-n dictionaries containing values with base keys (no .prop.xxx) and special wccmType key]
#-------------------------------------------------------------------------------
def getElasticityClassProperties(classId):
  _app_entry("getElasticityClassProperties(%s)" , classId)
  retval = {}
  try:
    nestedIds = {}
    collectSimpleProperties(retval, "elasticityClass.prop",classId, optionalSkipList=[],idProps=nestedIds)
    
    prefix = "elasticityClass"
    for key in nestedIds.keys():
      val = nestedIds[key]
      shortKey = key[21:]
      
      if (isArray(val)):
        propList = []
        
        idList = wsadminToList(val)
        tidx = 0
        for tempid in idList:
          if (isEmpty(tempid)):
            continue
          tidx +=1
          configType = callGetObjectType(tempid)
          if (not isEmpty(configType)):
            retval["%s.%s.%d.type" % (prefix,shortKey,tidx)] = configType
          collectSimpleProperties(retval,"%s.%s.%d.prop" % (prefix,shortKey,tidx),tempid)
          
          # Now pull out basic key=value pairs to be stored in the list 
          propDict = toDictionary(getPropList(retval,"%s.%s.%d" % (prefix,shortKey,tidx)))
          propDict["wccmType"] = configType
          propList.append(propDict)
          
          
        if (tidx > 0):
          retval["%s.%s.count" % (prefix,shortKey)] = tidx
        
        # Store list as well in results
        retval["%s.%s" % (prefix,shortKey)] = propList
        
      else:
        configType = callGetObjectType(val)
        if (configType != None):
          retval["%s.%s.type" % (prefix,shortKey)] = configType
        collectSimpleProperties(retval,"%s.%s.prop" % (prefix,shortKey),val)
    
  except:
    _app_exception("Unexpected problem in getElasticityClassProperties()")
  
  _app_exit("getElasticityClassProperties(retval=%s)" % retval)
  return retval