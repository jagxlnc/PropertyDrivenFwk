################################################################################
# IMControllers.py
#
# This script provides support for updating the configuration of the
# Intelligent Management controllers. This script is under construction.
#
# Required modules: Utils.py, common.py
#
# def updateHealthController(baseProps=None,customProperties=None):
# def getHealthControllerProperties():
#
#
# 
################################################################################

#---------------------------------------------------------------------
# updateHealthController
#
# Parameters:
#    baseProps - dictionary with base HealthController properties
#    customProperties - dictionary with custom properties (in key=value|description format)
#
# Custom properties will be merged, prohibited times behavior depends
# on the appendProhibitedTimes parameter (defaults to clear-and-update)
#
# Note: 
#   The prohibited restart times update does not work and is documented in the info center as not supported by wsadmin
#   http://www-01.ibm.com/support/knowledgecenter/SSUP64_7.0.0/com.ibm.websphere.virtualenterprise.doc/reference/todhmscript.html
#   http://www-304.ibm.com/support/knowledgecenter/SSAW57_8.5.5/com.ibm.websphere.nd.doc/ae/rwve_odhmscript.html
#---------------------------------------------------------------------
def updateHealthController(baseProps=None,customProperties=None):
  _app_entry('updateHealthController(%s,%s)' % (baseProps,customProperties))
  retval = None
  try:
    hcId = AdminConfig.getid("/Cell:%s/HealthController:/" % getCellName())
    
    if (hcId == None):
      hcId = AdminConfig.create("HealthController",getCellId(),[])
    
    retval = hcId
    if (baseProps != None and len(baseProps) > 0):
      attrs = propsToAttrList(baseProps)
      if (modifyObject(hcId,attrs)):
        raise StandardError("Error applying base properties to HealthController")
    
    if (customProperties != None and len(customProperties)  > 0):
      errMsg = updateCustomProperties(hcId, "properties", "Property", customProperties)
      if (not isEmpty(errMsg)):
        raise StandardError("Error updating HealthController custom properties: %s" % errMsg)
  except:
    _app_exception("Unexpected problem with updateHealthController")
  
  _app_exit('updateHealthController(retval=%s)' % retval)
  
  return retval

#---------------------------------------------------------------------
# getHealthControllerProperties
#---------------------------------------------------------------------
def getHealthControllerProperties():
  _app_entry('getHealthControllerProperties()')
  retval = {}
  try:
    hcId = AdminConfig.getid("/Cell:%s/HealthController:/" % getCellName())
    collectSimpleProperties(retval, "controllers.health.prop",hcId, optionalSkipList=[],idProps=None,getSimpleChildren=1,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=1)
    
  except:
    _app_exception("Unexpected problem with getHealthControllerProperties")
  
  _app_exit('getHealthControllerProperties(retval=%d settings)' % len(retval))
  return retval
  
#-------------------------------------------------------------------------------
# updateAutonomicRequestFlowManager
#
# Parameters:
#   baseProps - Dictionary with base properties of AutonomicRequestFlowManager
#   customProperties - optional dictionary with custom properties
#-------------------------------------------------------------------------------
def updateAutonomicRequestFlowManager(baseProps=None,customProperties=None):
  _app_entry('updateAutonomicRequestFlowManager(%s,%s)',baseProps,customProperties)
  retval = None
  try:
    arfmId = AdminConfig.getid("/Cell:%s/AutonomicRequestFlowManager:/" % getCellName())
    
    if (arfmId == None):
      arfmId = AdminConfig.create("AutonomicRequestFlowManager",getCellId(),[])
    
    retval = arfmId
    if (baseProps != None and len(baseProps) > 0):
      attrs = propsToAttrList(baseProps)
      if (modifyObject(arfmId,attrs)):
        raise StandardError("Error applying base properties to AutonomicRequestFlowManager")
    
    if (customProperties != None and len(customProperties)  > 0):
      errMsg = updateCustomProperties(arfmId, "properties", "Property", customProperties)
      if (not isEmpty(errMsg)):
        raise StandardError("Error updating AutonomicRequestFlowManager custom properties: %s" % errMsg)
  except:
    _app_exception("Unexpected problem with updateAutonomicRequestFlowManager")
  
  _app_exit('updateAutonomicRequestFlowManager(retval=%s)' % retval)
  
  return retval


  
#-------------------------------------------------------------------------------
# getAutonomicRequestFlowManagerProperties
#
# Parameters: None
#
# Returns dictionary
#-------------------------------------------------------------------------------
def getAutonomicRequestFlowManagerProperties():
  _app_entry("getAutonomicRequestFlowManagerProperties()")
  retval = {}
  try:
    arfmId = AdminConfig.getid("/AutonomicRequestFlowManager:/")
    collectSimpleProperties(retval, "controllers.arfm.prop",arfmId, optionalSkipList=[],idProps=None,getSimpleChildren=1,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1)
    
  except:
    _app_exception("Unexpected problem in getAutonomicRequestFlowManagerProperties()")
  
  _app_exit("getAutonomicRequestFlowManagerProperties()")
  return retval
  

#-------------------------------------------------------------------------------
# updateApplicationPlacementController
#
# Parameters:
#   baseProps - Dictionary with base properties of ApplicationPlacementController
#   customProperties - optional dictionary with custom properties
#-------------------------------------------------------------------------------
def updateApplicationPlacementController(baseProps=None,customProperties=None):
  _app_entry('updateApplicationPlacementController(%s,%s)',baseProps,customProperties)
  retval = None
  try:
    apcId = AdminConfig.getid("/AppPlacementController:/")
    
    if (apcId == None):
      apcId = AdminConfig.create("AppPlacementController",getCellId(),[])
    
    retval = apcId
    if (baseProps != None and len(baseProps) > 0):
      attrs = propsToAttrList(baseProps)
      if (modifyObject(apcId,attrs)):
        raise StandardError("Error applying base properties to ApplicationPlacementController")
    
    if (customProperties != None and len(customProperties)  > 0):
      errMsg = updateCustomProperties(apcId, "properties", "Property", customProperties)
      if (not isEmpty(errMsg)):
        raise StandardError("Error updating ApplicationPlacementController custom properties: %s" % errMsg)
  except:
    _app_exception("Unexpected problem with updateApplicationPlacementController")
  
  _app_exit('updateAutonomicRequestFlowManager(retval=%s)' % retval)
  
  return retval
  
  
  
#-------------------------------------------------------------------------------
# getApplicationPlacementControllerProperties
# 
# Returns a dictionary with the current configuration properties of the APC
#    controllers.apc.prop - prefix of base properties
#    controllers.apc.properites.prop - prefix of custom properties
#
#-------------------------------------------------------------------------------
def getApplicationPlacementControllerProperties():
  _app_entry("getApplicationPlacementControllerProperties()")
  retval = {}
  try:
    apcId = AdminConfig.getid("/AppPlacementController:/")
    if (not isEmpty(apcId)):
      collectSimpleProperties(retval, "controllers.apc.prop",apcId, optionalSkipList=[],idProps=None,getSimpleChildren=1,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1)
    
  except:
    _app_exception("Unexpected problem in getApplicationPlacementControllerProperties()")
  
  _app_exit("getApplicationPlacementControllerProperties(retval=%s)" % retval)
  return retval