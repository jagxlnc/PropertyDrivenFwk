#################################################################################
# This module contains a stub implementation of the DecryptHelper class which
# is invoked by substituteDynamicValues() in Utils.py to process the 
# @{DYNAMIC#DECRYPTE#encrypted-password} keyword
#
# 
#################################################################################     	
class DecryptHelper:

	def decrypt(self,inputValue):
	
		global progInfo
	
		_app_trace("DecryptHelper.decrypt(%s)"%inputValue,"entry")
	
		result = None
		try:
		  # This is a placeholder for customized decryption support
		  raise StandardError("Needs to be implemented")
		except:
			_app_trace("Error decrypting", "exception")
			
			stubFlag = progInfo.get("app.stubcontrol.DecryptHelper","")
			if (stubFlag == "true"):
					_app_trace("Using stub value for DecryptHelper results")
					result = "StubPassword"
   
		_app_trace("DecryptHelper.decrypt()","exit")
		return result
          	
          	
        
