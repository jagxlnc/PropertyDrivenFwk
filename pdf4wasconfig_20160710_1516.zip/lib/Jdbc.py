##########################################################################
# File Name:    Jdbc.py
# Description:  This file contains function definitions to create
#               Common JDBC Resources
#
#               createJDBCProvider
#
##########################################################################
def createJDBCProvider(scope, providerName, providerAttrs):

   global progInfo
   retval = None

   try:
    traceStr = "createJDBCProvider(%s, %s, %s)" % (scope, providerName, providerAttrs)
    _app_trace(traceStr, "entry")

    _app_trace("Running command:AdminConfig.list('JDBCProvider', %s)" % scope)
    c,n,s,dc,app,appdep = getScope(scope)
    providerEntries=AdminConfig.list("JDBCProvider", scope)
    provider="None"

    _app_trace("Finding provider %s" % providerName)
    if (providerEntries != ""):
        providerEntryList=providerEntries.split(progInfo["line.separator"])

        for providerEntry in providerEntryList:
          if (isEmpty(providerEntry)): continue
          c1,n1,s1,dc1,app1,appdep1 = getScope(providerEntry)
          if (c1 != c or n1 != n or s1 != s):  continue

          if (providerName == AdminConfig.showAttribute(providerEntry,"name")):
            provider=providerEntry
            break

    #------------------------------------------------------
    # If the JDBC provider does not exist, create a new one
    #------------------------------------------------------
    if (provider == "None"):
      _app_trace("Provider %s Not found so creating new one" % providerName)
      _app_trace("Running command:AdminConfig.create('JDBCProvider', %s, %s)" % (scope,providerAttrs))
      provider=AdminConfig.create("JDBCProvider", scope, providerAttrs)
    else:
      _app_trace("Provider %s already exists" % providerName)
   
    retval=provider

   except:
      _app_trace("An error was encountered creating the JDBCProvider %s" % providerName, "exception")

   _app_trace("createJDBCProvider(%s)" %(retval), "exit")
   return retval


######################################################################################################
# Create a JDBC provider based on a WebSphere Template
######################################################################################################
def createJDBCProviderUsingTemplate(scope, providerName, templateName, providerAttrs):

   global progInfo
   retval = None

   try:
    traceStr = "createJDBCProviderFromTemplate(%s, %s,%s, %s)" % (scope, providerName, templateName, providerAttrs)
    _app_trace(traceStr, "entry")

    _app_trace("Running command:AdminConfig.list('JDBCProvider', %s)" % scope)
    providerEntries=AdminConfig.list("JDBCProvider", scope)
    provider="None"

    _app_trace("Finding provider %s" % providerName)
    if (providerEntries != ""):
        providerEntryList=providerEntries.split(progInfo["line.separator"])

        for providerEntry in providerEntryList:
          if (isEmpty(providerEntry)): continue
          if (providerName == AdminConfig.showAttribute(providerEntry,"name")):
            provider=providerEntry
            break

    #------------------------------------------------------
    # If the JDBC provider does not exist, create a new one
    #------------------------------------------------------
    if (provider == "None"):
      _app_trace("Provider %s Not found so creating new one" % providerName)
      
      # Find the template
      templates =  AdminConfig.listTemplates("JDBCProvider").split(progInfo["line.separator"])
      templateId = None
      for template in templates:
      		if (isEmpty(template)):
      				continue
      		tn = AdminConfig.showAttribute(template,"name")
      		if (tn == templateName):
      				# Found our template
      				templateId = template
      				break
      
      if (templateId == None):
      		raise  StandardError("Unable to find template match for %s" % (templateName))
      
      _app_trace("Running command AdminConfig.createUsingTemplate('JDBCProvider', %s, %s, %s)" % (scope, providerAttrs, templateId))
      provider=AdminConfig.createUsingTemplate('JDBCProvider', scope, providerAttrs, templateId)
      if (not isEmpty(provider)):
      		# Remove any data sources created with the template
      		dslist = AdminConfig.list("DataSource", provider).split(progInfo["line.separator"])
      		for ds in dslist:
      				if (isEmpty(ds)):
      						continue
      				_app_trace("Running command AdminConfig.remove(%s)" % ds)
      				AdminConfig.remove(ds)
    else:
      _app_trace("Provider %s already exists" % providerName)
   
    retval=provider

   except:
      _app_trace("An error was encountered creating the JDBCProvider %s" % providerName, "exception")
      retval = None

   _app_trace("createJDBCProviderFromTemplate(%s)" %(retval), "exit")
   return retval


##########################################################################################
# findExistingJDBCProvider
# 
# Look for an existing JDBC provider at the specified scope
##########################################################################################
def findExistingJDBCProvider(scope, providerName):

   global progInfo
   retval = None

   try:
    traceStr = "findExistingJDBCProvider(%s, %s)" % (scope, providerName)
    _app_trace(traceStr, "entry")
    
    c,n,s,dc,app,appdep = getScope(scope)
    if (isEmpty(c) and isEmpty(n) and isEmpty(s)):
      providerEntries = AdminConfig.getid("/Cell:%s/JDBCProvider:/" % AdminConfig.showAttribute(scope,"name"))
    elif (not isEmpty(c)):
      providerEntries = AdminConfig.getid("/ServerCluster:%s/JDBCProvider:/" % c )
    elif (not isEmpty(s) and not isEmpty(n)):
      providerEntries = AdminConfig.getid("/Node:%s/Server:%s/JDBCProvider:/" % (n,s))
    elif (not isEmpty(n) and isEmpty(s)):
      providerEntries = AdminConfig.getid("/Node:%s/JDBCProvider:/" % (n))
    else:
      providerEntries = ""

    
    provider=None

    _app_trace("Finding provider %s" % providerName)
    if (providerEntries != ""):
        providerEntryList=providerEntries.split(progInfo["line.separator"])

        for providerEntry in providerEntryList:
          if (isEmpty(providerEntry)): continue

          if (providerName == AdminConfig.showAttribute(providerEntry,"name")):
            provider=providerEntry
            break
            
    retval=provider

   except:
      _app_trace("An error was encountered searching for the JDBCProvider %s" % providerName, "exception")
      raise StandardError("An error was encountered searching for the JDBCProvider %s" % providerName)

   _app_trace("findExistingJDBCProvider(%s)" %(retval), "exit")
   return retval

##########################################################################################
# findMatchingJDBCProviders
# 
# Return a list of providers that match the search criteria which can include wildcard
##########################################################################################
def findMatchingJDBCProviders(namePattern, clusterPattern=None, nodePattern=None, serverPattern=None,skipDerby=1):

   global progInfo
   retval = []

   try:
    traceStr = "findMatchingJDBCProviders(%s,%s,%s,%s)" % (namePattern, clusterPattern, nodePattern, serverPattern)
    _app_trace(traceStr, "entry")
    
    c = clusterPattern
    n = nodePattern
    s = serverPattern
    if (isEmpty(c) and isEmpty(n) and isEmpty(s)):
      providerEntries = AdminConfig.getid("/Cell:%s/JDBCProvider:/" % AdminConfig.showAttribute(AdminConfig.getid("/Cell:/"),"name"))
    elif (not isEmpty(c) and c.find("*") == -1):
      # Not a wildcard cluster pattern
      providerEntries = AdminConfig.getid("/ServerCluster:%s/JDBCProvider:/" % c )
    elif (not isEmpty(s) and not isEmpty(n) and s.find("*") == -1 and n.find("*") == -1 ):
      providerEntries = AdminConfig.getid("/Node:%s/Server:%s/JDBCProvider:/" % (n,s))
    elif (not isEmpty(n) and isEmpty(s) and n.find("*") == -1):
      providerEntries = AdminConfig.getid("/Node:%s/JDBCProvider:/" % (n))
    else:
      providerEntries = AdminConfig.getid("/JDBCProvider:/")

    
    provider=None

    
    if (providerEntries != ""):
        providerEntryList=providerEntries.split(progInfo["line.separator"])
        
        if (skipDerby):
          tempList = []
          for providerId in providerEntryList:
            if (providerId.find("Derby JDBC Provider") < 0):
              tempList.append(providerId)
          
          providerEntryList = tempList
              
        
        retval = filterList(providerEntryList, namePattern,clusterPattern,nodePattern,serverPattern)

   except:
      _app_trace("An error was encountered searching for the JDBCProvider (%s,%s,%s,%s)" % (namePattern, clusterPattern, nodePattern, serverPattern), "exception")
      raise StandardError("An error was encountered searching for the JDBCProvider (%s,%s,%s,%s)" % (namePattern, clusterPattern, nodePattern, serverPattern))

   _app_trace("findMatchingJDBCProviders(%s)" %(retval), "exit")
   return retval





##########################################################################
# @JJM
#
# checkForExistingDataSource
#     Checks to see if there is an exiting data source at the specified scope
#     with the specified name.
#     
#     Alternatively, the jndiName can be passed as the third parameter and 
#     the search will be done against that attribute instead of the name.
#
# Parameters:
#     scope - The configuration ID of the search scope.
#     dsName - The name to search for.
#     jndiName - If supplied, the search will be for a matching jndiName, not
#                the data source name.
# Returns:
#     dataSourceID - The configuration ID of the data source matching the
#                    search criteria.  A value of None is returned if 
#                    no match is found.
##########################################################################
def checkForExistingDataSource(scope, dsName, jndiName=None):

  retval = None
  traceStr = "checkForExistingDataSource(%s, %s, %s)" % (scope, dsName, jndiName )
  _app_trace(traceStr, "entry")

  _app_trace("Running command:AdminConfig.list('DataSource', %s)" % scope)

  dataSourceEntries=AdminConfig.list("DataSource", scope)
 
  if (dataSourceEntries != ""):
    dataSourceEntryList=dataSourceEntries.split(progInfo["line.separator"])

    for dataSourceEntry in dataSourceEntryList:
      if (isEmpty(dataSourceEntry)): continue
      if (jndiName != None):
      	if (jndiName == AdminConfig.showAttribute(dataSourceEntry,"jndiName")):
      			# JNDI Name is a match
      			_app_trace("JDBC Datasource with jndiName %s already exists" % jndiName)
        		retval=dataSourceEntry
        		break
      elif (dsName == AdminConfig.showAttribute(dataSourceEntry,"name")):
        _app_trace("JDBC Datasource %s already exists" % dsName)
        retval=dataSourceEntry
        break
  
  _app_trace("checkForExistingDataSource(%s)" % (retval ), "exit")
  return retval
        

##########################################################################
# @JJM
#
# findMatchingDataSources
#     Checks to see if there is an exiting data source at the specified scope
#     with the specified name pattern. Returns a list of matching data sources.
#     
#     Alternatively, the jndiName can be passed as the third parameter and 
#     the search will be done against that attribute instead of the name.
#
# Parameters:
#     scope - The configuration ID of the search scope.
#     dsNamePattern - The name pattern to search for.
#     jndiNamePattern - If supplied, the search will be for a matching jndiName, not
#                the data source name.
# Returns:
#     [dataSourceID] - A list of the configuration ID of the data sources matching the
#                    search criteria.  A value of None is returned if 
#                    no match is found.
##########################################################################
def findMatchingDataSources(scope, dsNamePattern, jndiNamePattern=None):

  import re
  retval = []
  traceStr = "findMatchingDataSources(%s, %s, %s)" % (scope, dsNamePattern, jndiNamePattern )
  _app_trace(traceStr, "entry")

  _app_trace("Running command:AdminConfig.list('DataSource', %s)" % scope)

  dataSourceEntries=AdminConfig.list("DataSource", scope)
 
  if (dataSourceEntries != ""):
    dataSourceEntryList=dataSourceEntries.split(progInfo["line.separator"])

    for dataSourceEntry in dataSourceEntryList:
      if (isEmpty(dataSourceEntry)): continue
      if (jndiNamePattern != None):
        tempName = AdminConfig.showAttribute(dataSourceEntry,"jndiName")
        if (jndiNamePattern.find("*") >= 0):
          if (re.match(jndiNamePattern,tempName)):
            retval.append(dataSourceEntry)
        elif (jndiNamePattern == tempName):
          retval.append(dataSourceEntry)
      else:
        tempName = AdminConfig.showAttribute(dataSourceEntry,"name")
        if (dsNamePattern.find("*") >= 0):
          if (re.match(dsNamePattern,tempName)):
            retval.append(dataSourceEntry)
        elif (dsNamePattern == tempName):
          retval.append(dataSourceEntry)
        
        
  _app_trace("findMatchingDataSources(%s)" % (retval ), "exit")
  return retval

##########################################################################
# createJDBCDataSource
#    Creates a new JDBC Data source at the specified provider
#
# Parameters:
#    scope - The ID of the configuration item the provider is scoped at
#    rsadapter - The configuration ID of the J2CResourceAdapter. Used to create a CMPConnectorFactory
#    dsName - The name of the data source.
#    dsAttrs - Attribute list used to create data source (Usually just "name")
#    rpAttrs - Property set with ResourceProperty key/value pairs
#    mapAttrs - Attribute list used to create mapping attribute
#    dspropAttrs - Attributes list of top-level DataSource attributes
#    connPoolAttrs - Attribute list of connection pool
#    connPoolCustomProperties - Property set of key/value pairs used to define connection pool custom properties
#    createCMP - If 0, no CMPConnectorFactory for this datasource will be created
#    checkNames - If 1, we'll skip the search for a DataSource with the same name
#
# Returns
#    datasourceId - The configuration ID of the new data source. A value of None
#                   is returned if an error occurred
##########################################################################
def createJDBCDataSource(scope, radapter, provider, dsName, dsAttrs, rpAttrs, mapAttrs, dspropAttrs, connPoolAttrs, connPoolCustomProperties=None, createCMP = 1, checkNames=1 ):

  global progInfo
  retval = None

  try:
    traceStr = "createJDBCDataSource(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %d, %d)" % (scope, radapter, provider, dsName, dsAttrs, rpAttrs, mapAttrs, dspropAttrs, connPoolAttrs, connPoolCustomProperties, createCMP, checkNames )
    _app_trace(traceStr, "entry")

    if (checkNames):
      existingDS = checkForExistingDataSource(provider, dsName)
      if (existingDS):
         raise StandardError("JDBC Datasource %s already exists" % dsName) 
      		
      
    #---------------------------------------------------
    # If the DataSource does not exist, create a new one
    #---------------------------------------------------
    _app_trace("Running command:AdminConfig.create('DataSource', %s, %s)" % (provider, dsAttrs))
    datasource=AdminConfig.create("DataSource", provider, dsAttrs)

    mapping_attr=["mapping", mapAttrs]

    dstAttrs = dspropAttrs
    dstAttrs.append(mapping_attr)
    
    _app_trace("Running command:AdminConfig.modify(%s, %s)" % (datasource, dstAttrs))
    
    AdminConfig.modify(datasource, dstAttrs)

    
    #-----------------------------------------------------------
    # Modify the new datasource by adding some custom properties
    #-----------------------------------------------------------
    propSet = AdminConfig.showAttribute(datasource,"propertySet")
    if (isEmpty(propSet)):
      _app_trace("Running command:AdminConfig.create('J2EEResourcePropertySet', %s, [])" % (datasource))
      propSet=AdminConfig.create("J2EEResourcePropertySet", datasource, [])

    if (rpAttrs.size() > 0):
      for rpKey in rpAttrs.keys():
        rpProps = []
        valDes = rpAttrs[rpKey].split("|")
        if (len(valDes) == 1):
          rpProps = [["name", rpKey],["value",rpAttrs[rpKey]]]
        else:
          rpProps = [["name", rpKey],["value",valDes[0]], ["description", valDes[1]]]
 
      
        _app_trace("Running command:AdminConfig.create('J2EEResourceProperty', %s, %s)" % (propSet, rpProps))
        AdminConfig.create("J2EEResourceProperty", propSet, rpProps)
      #endfor each property
    #endif
    
    cpid = AdminConfig.showAttribute(datasource, "connectionPool")
    if (isEmpty(cpid)):
      _app_trace("Running command:AdminConfig.create('ConnectionPool', %s, %s)" % (datasource, connPoolAttrs))
      cpid = AdminConfig.create("ConnectionPool", datasource, connPoolAttrs)
    else:
      # Need to modify data source
      if (modifyObject(cpid, connPoolAttrs)):
      		raise StandardError("Problem updating connection pool")
    
    # Create custom properties for the connection pool
    if (connPoolCustomProperties != None and connPoolCustomProperties.size() > 0):
    		for cpKey in connPoolCustomProperties.keys():
    				cpProps = []
    				valDes = connPoolCustomProperties[cpKey].split("|")
    				if (len(valDes) == 1):
    						# Just a value
    						cpProps = [["name", cpKey], ["value", valDes[0]]]
    				else:
    						cpProps = [["name", cpKey], ["value", valDes[0]] , ["description", valDes[1]] ]
    				_app_trace("Running command: AdminConfig.create('Property', %s, %s)" % (cpid, cpProps))
    				AdminConfig.create("Property", cpid, cpProps)
    		#endfor each property
    #endif
    						

    #---------------------------------------------------------------
    # Create an associated connection factory for the new DataSource
    #---------------------------------------------------------------
    if createCMP == 1 and not isEmpty(radapter):
      connFactAttrs=[]
      connFactAttrs.append(["name", "%s_CF" % dsName])
      connFactAttrs.append(["authMechanismPreference", "BASIC_PASSWORD"])
      connFactAttrs.append(["cmpDatasource", datasource])
      connFactAttrs.append(mapping_attr)

      _app_trace("Running command:AdminConfig.create('CMPConnectorFactory', %s, %s)" % (radapter, connFactAttrs))
      AdminConfig.create("CMPConnectorFactory", radapter, connFactAttrs)
  
    # return
    retval=datasource

  except:
    _app_trace("An error was encountered creating the Datasource %s" % dsName, "exception")

  _app_trace("createJDBCDataSource(%s)" %(retval), "exit")
  return retval


##########################################################################
# modifyJDBCProvider
##########################################################################
def modifyJDBCProvider(scope, provider, providerName, providerAttrs):

	global progInfo
	retval = None

	try:
		traceStr = "modifyJDBCProvider(%s, %s, %s, %s)" % (scope, provider, providerName, providerAttrs)
		_app_trace(traceStr, "entry")

		if (isEmpty(provider)):
				# Search by name and scope
				_app_trace("Running command:AdminConfig.list('JDBCProvider', %s)" % scope)
				providerEntries=AdminConfig.list("JDBCProvider", scope)
				
				_app_trace("Finding provider %s" % providerName)
				if (providerEntries != ""):
				
						providerEntryList=providerEntries.split(progInfo["line.separator"])
						for providerEntry in providerEntryList:
								if (isEmpty(providerEntry)): continue
								if (providerName == AdminConfig.showAttribute(providerEntry,"name")):
										provider=providerEntry
										break
    
		if (isEmpty(provider)):
				raise StandardError("Provider %s does not exist at scope %s" % (providerName,scope))
    
		_app_trace("Running command: modifyObject(%s, %s)" % (provider,providerAttrs))
		modifyObject(provider, providerAttrs)
    
		retval=provider

	except:
		_app_trace("An error was encountered modifing the JDBCProvider %s" % providerName, "exception")
		retval = None

	_app_trace("modifyJDBCProvider(%s)" %(retval), "exit")
	return retval

  

##########################################################################
# modifyJDBCDataSource
#    Updates an existing JDBC Data source at the specified provider
#
# Parameters:
#    existingId - The ID of the datasource.  If None, will search for ds with the specified name.
#    rsadapter - The configuration ID of the J2CResourceAdapter. Used to update CMPConnectorFactory
#    provider - Id of the parent JDBC provider
#    dsName - The name of the data source.
#    dsAttrs - Attribute list used to create data source (Usually just "name")
#    rpAttrs - Property set with ResourceProperty key/value pairs
#    mapAttrs - Attribute list used to create mapping attribute
#    dspropAtts - Attributes list of top-level DataSource attributes
#    connPoolAttrs - Attribute list of connection pool
#    connPoolCustomProperties - Property set of key/value pairs used to define connection pool custom properties
#
# Returns
#    datasourceId - The configuration ID of the modified data source. A value of None
#                   is returned if an error occurred
##########################################################################
def modifyJDBCDataSource(existingId, radapter, provider, dsName, dsAttrs, rpAttrs, mapAttrs, dspropAttrs, connPoolAttrs,  connPoolCustomProperties=None ):

  global progInfo
  retval = None

  try:
    traceStr = "modifyJDBCDataSource(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)" % (existingId, radapter, provider, dsName, dsAttrs, rpAttrs, mapAttrs, dspropAttrs, connPoolAttrs, connPoolCustomProperties )
    _app_trace(traceStr, "entry")

    _app_trace("Running command:AdminConfig.list('DataSource', %s)" % provider)

    dataSourceEntries=AdminConfig.list("DataSource", provider)
    
    datasource="None"
    if (existingId != None):
        datasource = existingId
    else:
        # Search for it
        datasource = checkForExistingDataSource(provider, dsName)
    
    if (datasource == None):
        raise StandardError("Existing ID is None and unable to find match for name %s in provider %s" % (dsName, provider))
        
    # general props

    # modify mapping module props
    objId = AdminConfig.showAttribute(datasource, "mapping")
    if not isEmpty(objId) and len(mapAttrs) > 0:
         _app_trace("Running command:modifyObject(%s, %s)" % (objId, mapAttrs))
         modifyObject(objId, mapAttrs)

    # modify connecion Pool props
    objId = AdminConfig.showAttribute(datasource, "connectionPool")
    cpid = objId
    if (len(connPoolAttrs) > 0):
        _app_trace("Running command:modifyObject(%s, %s)" % (objId, connPoolAttrs))
        modifyObject(objId, connPoolAttrs)
            
        cpid = objId
            
    # modify connection pool custom properties
    if (connPoolCustomProperties != None and len(connPoolCustomProperties) > 0):
    	updateCustomProperties(cpid, "properties", "Property", connPoolCustomProperties)
      				
        
    # modify J2EEResourcePropertySet props
    objIds = AdminConfig.showAttribute(datasource, "propertySet").split(progInfo["line.separator"])
    if (len(objIds) == 0 or isEmpty(objIds[0])):
     		propSet=AdminConfig.create("J2EEResourcePropertySet", datasource, [])
    else:
     		propSet = objIds[0]
          
    errmsg = updateCustomProperties(propSet, "resourceProperties", "J2EEResourceProperty", rpAttrs)
    if (not isEmpty(errmsg)):
    	raise StandardError("Error updating resource properties for datastource: %s" % errmsg)
    

    # modify dspropsAttrs props
    dstAttrs = dspropAttrs
    if (len(dstAttrs) > 0):
        _app_trace("Running command:AdminConfig.modify(%s, %s)" % (datasource, dstAttrs))
        AdminConfig.modify(datasource, dstAttrs)
    

    #---------------------------------------------------------------
    # Create an associated connection factory for the new DataSource
    # We'll only update if mapping_attributes are new
    #---------------------------------------------------------------
    if (not isEmpty(radapter)) and (len(mapAttrs) > 0):
      mapping_attr=["mapping", mapAttrs]
      connFactAttrs=[]
      ccfName = "%s_CF" % dsName
      connFactAttrs.append(["name", ccfName])
      connFactAttrs.append(["authMechanismPreference", "BASIC_PASSWORD"])
      connFactAttrs.append(["cmpDatasource", datasource])
      connFactAttrs.append(mapping_attr)

    
      ccfs = AdminConfig.list("CMPConnectorFactory").split(progInfo["line.separator"])
      for ccf in ccfs:
        if (isEmpty(ccf)):continue
        if ( ccfName == AdminConfig.showAttribute(ccf,"name")):
          _app_trace("Found ccf info:  %s %s" % (ccfName, ccf))
          _app_trace("Running command:AdminConfig.modify('CMPConnectorFactory', %s, %s)" % (radapter, connFactAttrs))
          AdminConfig.modify(ccf, connFactAttrs)
          _app_trace("ran command:AdminConfig.modify('CMPConnectorFactory', %s, %s)" % (radapter, connFactAttrs))
          break
    #endif need to create ccf
      
    # Set return value
    retval=datasource

  except:
    _app_trace("An error was encountered modifying the Datasource %s" % dsName, "exception")
    retval = None

  _app_trace("modifyJDBCDataSource(%s)" %(retval), "exit")
  return retval


##########################################################################
# deleteJDBCProvider
#
# This method can be called to delete a specific provider or search for
# a provider under a specified scope and the deletes.
#
##########################################################################
def deleteJDBCProvider(providerId, scopeId=None, providerName=None):
  _app_trace("deleteJDBCProvider(%s,%s,%s)" % (providerId, scopeId, providerName),"entry")
  try:
    if (isEmpty(providerId)):
      providerId = findExistingJDBCProvider(scopeId, providerName)
    
    if (isEmpty(providerId)):
      _app_trace("No provider exists with the specified scope and name")
    else:
      _app_trace("About to call AdminConfig.remove(%s)" % (providerId))
      AdminConfig.remove(providerId)
    
  except:
    _app_trace("Unexpected error in deleteJDBCProvider()", "exception")
    raise StandardError("Unexpected error in deleteJDBCProvider()")
    
  _app_trace("deleteJDBCProvider()","exit")


#-------------------------------------------------------------------------------
# deleteCMPConnectorFactoryForDatasource
#
# Searches the J2CResourceAdapater for a CMPConnectorFactory that corresponds to 
# the specific data source Id and deletes
#-------------------------------------------------------------------------------
def deleteCMPConnectorFactoryForDatasource(radapter, dsId):
  _app_trace("deleteCMPConnectorFactoryForDatasource(%s,%s)" % (radapter, dsId),"entry")
  
  try:
    if (not isEmpty(radapter)):
      factories = AdminConfig.list("CMPConnectorFactory",radapter).split(progInfo['line.separator'])
      for factory in factories:
        if (isEmpty(factory)):
          continue
        
        tempId = AdminConfig.showAttribute(factory,"cmpDatasource")
        if (tempId == dsId):
          _app_trace("About to call AdminConfig.remove(%s)" % factory)
          AdminConfig.remove(factory)
          
          break
      
  except:
    _app_trace("Unexpected error in deleteCMPConnectorFactoryForDatasource","exception")
    raise StandardError("Unexpected error in deleteCMPConnectorFactoryForDatasource")
  
  _app_trace("deleteCMPConnectorFactoryForDatasource()","exit")
  
#-------------------------------------------------------------------------------
# deleteCMPConnectorFactoryForProvider
#
# Searches the J2CResourceAdapater for a CMPConnectorFactory that corresponds to 
# any datasource under the provider
#-------------------------------------------------------------------------------
def deleteCMPConnectorFactoriesForProvider(radapter, providerId):
  _app_trace("deleteCMPConnectorFactoriesForProvider(%s,%s)" % (radapter, providerId),"entry")
  
  try:
    if (not isEmpty(radapter)):
      datasources = AdminConfig.list("DataSource",providerId).split(progInfo['line.separator'])
      
      factories = AdminConfig.list("CMPConnectorFactory",radapter).split(progInfo['line.separator'])
      for factory in factories:
        if (isEmpty(factory)):
          continue
      
        tempId = AdminConfig.showAttribute(factory,"cmpDatasource")
        if tempId in datasources:
          _app_trace("About to call AdminConfig.remove(%s)" % factory)
          AdminConfig.remove(factory)

      
  except:
    _app_trace("Unexpected error in deleteCMPConnectorFactoriesForProvider","exception")
    raise StandardError("Unexpected error in deleteCMPConnectorFactoriesForProvider")
  
  _app_trace("deleteCMPConnectorFactoriesForProvider()","exit")
  

##########################################################################
# deleteJDBCDataSource
#
# This method can be called to delete a specific data source or search for
# a datasource under a specified provider and then delete it.
#
##########################################################################
def deleteJDBCDataSource(dsId,providerId=None, dsName = None):
  _app_trace("deleteJDBCDataSource(%s,%s,%s)" % (dsId,providerId, dsName),"entry")
  try:
    if (isEmpty(dsId)):
      dsId = checkForExistingDataSource(providerId, dsName)
    
    if (isEmpty(dsId)):
      _app_trace("No datasource exists with the specified scope and name")
    else:
      _app_trace("About to call AdminConfig.remove(%s)" % (dsId))
      AdminConfig.remove(dsId)
    
  except:
    _app_trace("Unexpected error in deleteJDBCDataSource()", "exception")
    raise StandardError("Unexpected error in deleteJDBCDataSource()")
    
  _app_trace("deleteJDBCDataSource()","exit")


##########################################################################
# getJDBCProviderProperties
#
# Return the attributes of the JDBCProvider in a Properties set with 
# format of: jdbc.provider.attribute_name = val
##########################################################################
def getJDBCProviderProperties(provider,prefix="jdbc.provider",checkSettingsOverride=0):
	
	_app_trace("getJDBCProviderProperties(%s)" % provider,"entry")
	
	retval = java.util.Properties()

	incKeys = ['name', 'description', 'implementationClassName', 'classpath', 'nativepath', 'providerType','xa' ]
	
	if (checkSettingsOverride or isCheckSettingsEnabled()):
		tempProps = collectSimpleProperties(None, "prop",provider)
		
		for attr in incKeys:
			value = tempProps.get("prop.%s" % attr)
			
			#value= AdminConfig.showAttribute(provider,attr)
			if (value == "[]" or value == None):
					continue
			retval.put("%s.prop.%s" % (prefix,attr), value) 
   
	_app_trace("getJDBCProviderProperties()","exit")
	
	return retval




##########################################################################
# @JJM
# 
# getDataSourceInfo(ds)
#
# Returns a property set containing Data Source settings in property format.  This format
# allows the Data Source's current configuration to be compared against the property
# format created by the dumpConfig.py script
#
##########################################################################
def getDataSourceInfo(ds,includePoolProps = 1, includeResourceProps = 1, propPrefix = "ds",radapter=None,checkSettingsOverride = 0):
  _app_trace("getDataSourceInfo(%s)" %ds , "entry")
    
  dsProperties=java.util.Properties()
    
  #keys = ['connectionPool', 'properties', 'mapping', 'propertySet']
  #incKeys = ['authMechanismPreference', 'description', 'jndiName', 'statementCacheSize', 'authDataAlias', 'datasourceHelperClassname', 'manageCachedHandles', 'xaRecoveryAuthAlias', 'diagnoseConnectionUsage','logMissingTransactionContext']
  #cpKeys = ['agedTimeout', 'connectionTimeout', 'freePoolDistributionTableSize', 'maxConnections', 'minConnections', 'numberOfFreePoolPartitions', 'numberOfSharedPoolPartitions', 'numberOfUnsharedPoolPartitions', 'purgePolicy', 'reapTime', 'stuckThreshold', 'stuckTime', 'stuckTimerTime', 'surgeCreationInterval', 'surgeThreshold', 'testConnection', 'testConnectionInterval', 'unusedTimeout' ]

    
  dsProperties.setProperty ("%s.dsAttrs.prop.name" % propPrefix,AdminConfig.showAttribute(ds, 'name'))
    
  if (checkSettingsOverride or isCheckSettingsEnabled()):

    # dsAttrs attributes

    # mapping attributes
    mId = AdminConfig.showAttribute(ds,"mapping")
    if not (isEmpty(mId)):
        attrs =  AdminConfig.showall(mId).split(progInfo["line.separator"])
        for attr in attrs:
            k,v = toKeyValue(attr)
            dsProperties.setProperty ("%s.mapAttrs.prop.%s" % (propPrefix,k) , v)

        
    mId = AdminConfig.showAttribute(ds,"connectionPool")
    if (not isEmpty(mId)):
    	collectSimpleProperties(dsProperties, "%s.connpool.prop"% propPrefix,mId)
    	if (includePoolProps):
    		collectCustomProperties(dsProperties,"%s.connpool.customProperties" % propPrefix, mId,"properties")

    if (includeResourceProps):
      mId = AdminConfig.showAttribute(ds,"propertySet")
      if not (isEmpty(mId)):
    	  collectCustomProperties(dsProperties,"%s.rpAttrs"%propPrefix, mId,"resourceProperties")
      
    # dspropAttrs attributes
    collectSimpleProperties(dsProperties, "%s.dspropAttrs.prop" % propPrefix,ds)
    
    if (not isEmpty(radapter)):
      # See if we need to set the cmp flag
      cmpList = AdminConfig.list("CMPConnectorFactory",radapter).split(progInfo['line.separator'])
      for cmp in cmpList:
        if (isEmpty(cmp)):
            continue
        
        cmpDatasource = AdminConfig.showAttribute(cmp,"cmpDatasource")
        #print ds
        #print cmpDatasource
        
        if (ds == cmpDatasource):
            #print "Found matching cmp factory"
            dsProperties.put("%s.createCMPFactory" %propPrefix ,"true")
            break
      

  _app_trace("getDataSourceInfo(%s)" % dsProperties, "exit")
  return dsProperties
#enddef

