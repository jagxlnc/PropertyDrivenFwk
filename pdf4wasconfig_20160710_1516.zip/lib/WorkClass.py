###########################################################################################
# WorkClass.py
#
#    Provides functions for finding, creating, updating, deleting a WorkClass configuration.
#
# Requires: Utils.py, common.py
#
#    createApplicationServiceWorkClass(appName,wcName,transactionClass=None,wcType=None,wcProps=None,moduleList=None,matchRuleList=None)
#    modifyApplicationServiceWorkClass(wcId=None,appName=None,wcName=None,transactionClass=None,wcType=None,wcProps=None,
#                                       moduleList=None,matchRuleList=None,appendModules=0,appendRules=0)
#    deleteApplicationServiceWorkClass(appName,wcName)
#    findApplicationServiceWorkClass(appName,wcName)
#    createApplicationRoutingWorkClass(appName,wcName,cuName=None,wcType=None,actionType=None,action=None,wcProps=None,matchRuleList=None,moduleList=None)
#    modifyApplicationRoutingWorkClass(wcId=None,appName=None,wcName=None,actionType=None,action=None,
#                                       wcProps=None,matchRuleList=None,moduleList=None,appendModules=0,appendRules=0)
#    deleteApplicationRoutingWorkClass(appName,wcName,cuName = None)
#    findApplicationRoutingWorkClass(appName,wcName)
#    findCompUnitRoutingWorkClass(cuName,wcName)
#    findCompUnitServiceWorkClass(cuName,wcName)
#    getWorkClassProperties(workClassId)
#    findODRRoutingWorkClass(odrNode,odrName,workClassName)
#    findODRServiceWorkClass(odrNode,odrName,workClassName)
#    createODRRoutingWorkClass(wcName,odrName=None,odrNode=None,odrDynamicCluster=None,wcType="HTTPWORKCLASS",actionType=None,action=None,vhost=None,wcProps=None,matchRuleList=None,moduleList=None)
#    createODRServiceWorkClass(wcName,odrName=None,odrNode=None,odrDynamicCluster=None,transactionClass=None,wcType="HTTPWORKCLASS",vhost=None,members=None,wcProps=None,moduleList=None,matchRuleList=None)
#
#
#  
# wsadmin>print AdminConfig.attributes("WorkClass")
# description String
# matchAction String
# matchRules MatchRule*
# name String
# type ENUM(JMSWORKCLASS, IIOPWORKCLASS, HTTPWORKCLASS, SOAPWORKCLASS)
# workClassModules WorkClassModule*
#
# wsadmin>print AdminConfig.attributes("MatchRule")
# matchAction String
# matchExpression String
# priority int
#
# wsadmin>print AdminConfig.attributes("WorkClassModule")
# id String
# matchExpression String
# moduleName String
########################################################################################



#-------------------------------------------------------------------------------
# createApplicationServiceWorkClass
#
# Parameters
#   appName - Application name (includes -editionXXXX if editioned app)
#   wcName - Name of the work class
#   transactionClass - Name of transaction class to associate this Service Work Class with
#                      Optional, will be pulled from wcProps["matchAction"] if not supplied
#   wcType - Type of service Work Class
#            Optional, will be pulled from wcProps["type"] if not supplied
#            Support both short and long names
#            {'JMS', "JMSWORKCLASS", 'IIOP',"IIOPWORKCLASS", 'HTTP',"HTTPWORKCLASS", 'SOAP',"SOAPWORKCLASS"}
#
#    matchRuleList - List of dictionaries that define MatchRule definitions to create
#    moduleList - List of dictionaries that define WorkClassModule definitions to create
#-------------------------------------------------------------------------------
def createApplicationServiceWorkClass(appName,wcName,transactionClass=None,wcType=None,wcProps=None,moduleList=None,matchRuleList=None):
  _app_entry("createApplicationServiceWorkClass(%s,%s,%s,%s,%s,%s,%s)" , appName,wcName,transactionClass,wcType,wcProps,moduleList,matchRuleList)
  retval = None
  
  typeMap = {'JMS': "JMSWORKCLASS", 'IIOP':"IIOPWORKCLASS", 'HTTP':"HTTPWORKCLASS", 'SOAP':"SOAPWORKCLASS"}
    
  try:
    deploymentId = AdminConfig.getid("/Deployment:%s/" % appName)
    if (isEmpty(deploymentId)):
      raise StandardError("Unable to locate Application Deployment configuration for %s" % appName)
    
    wcProps = toDictionary(wcProps)
    
    if (not isEmpty(wcType)):
      if typeMap.has_key(wcType):
        # Get long name
        wcType = typeMap[wcType]  
    else:
      tempType = wcProps.get("type","HTTP")
      if (typeMap.has_key(tempType)):
        wcProps["type"] = typeMap[tempType]
    
    # Use the default Transaction Class if not specified
    if (isEmpty(transactionClass)):
      tempClass = wcProps.get("matchAction",None)
      if (tempClass == None):
        wcProps["matchAction"] = "Default_TC"
      
    # Build attribute list, using optional params if supplied
    # otherwise values will be pulled from dictionary  
    attrs = propsToAttrList(wcProps)
    attrs.append(["name",wcName])
    
    if (not isEmpty(wcType)):
      attrs.append(["type",wcType])
    
    if (not isEmpty(transactionClass)):
      attrs.append(["matchAction",transactionClass])
    
    _app_trace('About to call AdminConfig.create("WorkClass",%s,%s)' %(deploymentId,attrs))
    retval = AdminConfig.create("WorkClass",deploymentId,attrs)
    
    createMultipleChildren(moduleList,"WorkClassModule",retval)
   
    createMultipleChildren(matchRuleList,"MatchRule",retval)

    
  except:
    _app_exception("Unexpected problem in createApplicationServiceWorkClass()")
  
  _app_exit("createApplicationServiceWorkClass(retval=%s)" % retval)
  return retval

# wsadmin>print AdminTask.help("createServicePolicyWorkClass")
# WASX8006I: Detailed help for command: createServicePolicyWorkClass
# 
# Description: Use these commands to configure Service Policy Workclasses
# 
# Target object: null
# 
# Arguments:
#   odrname - Name of the On Demand Router resource related to the workclass.
#   odrnode - Name of the node which the On Demand Router resides on.
#   dcname - Name of the On Demand Router dynamic cluster resource related to the workclass.
#   *wcname - Name of the workclass, must be unique.
#   *type - Type of the workclass, must be HTTP, IIOP, or SOAP
#   tcname - Name of the transaction class to map the workclass to.  If not provided, this will default to the Default_TC of the Default_SP.
#   members - Workclass type specific pattern
#         HTTP = /test1?/test2/*
#         IIOP = <ejbName>:<ejbMethod>?<ejbName>:<ejbMethod>
#         SOAP = <webService>:<operationName>?<webSerivce>:<operationName>
#         JMS  = <bus>:<destination>?<bus>:<destination>
#   vhost - Name of the virtual host to apply the workclass to.
# 
# Steps:
#   None
# 

#-------------------------------------------------------------------------------
# createODRServiceWorkClass
#    Creates a generic server Service Work Class definition for an ODR
#
# Parameters
#   wcName - Name of the work class
#   odrName - Name of ODR (can be null if cluster is specified)
#   odrNode - Node of ODR (can be null if cluster is specified)
#   odrDynamicCluster - ODR cluster template to update
#   transactionClass - Name of transaction class to associate this Service Work Class with
#                      Optional, will be pulled from wcProps["matchAction"] if not supplied
#   wcType - Type of service Work Class
#            Optional, will be pulled from wcProps["type"] if not supplied
#            Support both short and long names
#            {'JMS', "JMSWORKCLASS", 'IIOP',"IIOPWORKCLASS", 'HTTP',"HTTPWORKCLASS", 'SOAP',"SOAPWORKCLASS"}
#   vhost - virtual host name
#   members - (optional) pattern that will be used to define match expression of WorkClassModule
#   matchRuleList - List of dictionaries that define MatchRule definitions to create
#   moduleList - List of dictionaries that define WorkClassModule definitions to create
#-------------------------------------------------------------------------------
def createODRServiceWorkClass(wcName,odrName=None,odrNode=None,odrDynamicCluster=None,transactionClass=None,wcType="HTTPWORKCLASS",vhost=None,members=None,wcProps=None,moduleList=None,matchRuleList=None):
  _app_entry("createODRServiceWorkClass(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)" , wcName,odrName,odrNode,odrDynamicCluster,transactionClass,wcType,vhost,members,wcProps,moduleList,matchRuleList)
  retval = None
  
  typeMap = {"JMSWORKCLASS":'JMS', "IIOPWORKCLASS":"IIOP", "HTTPWORKCLASS":"HTTP", "SOAPWORKCLASS":"SOAP"}
    
  try:
   
    wcProps = toDictionary(wcProps)
    
    if (isEmpty(wcType) and wcProps != None):
      wcType = wcProps.get("type")
    
    # Make sure we use type value required by AdminTask
    if (typeMap.has_key(wcType)):
      wcType = typeMap[wcType]
      
    if (isEmpty(transactionClass) and wcProps != None):
      actionProp = wcProps.get("matchAction")
      if (not isEmpty(actionProp)):
        actionInfo = actionProp.split(":")
        if (len(actionInfo) == 2):
          vhost = actionInfo[0]
          transactionClass = actionInfo[1]
                    

    parms = ""
    if (not isEmpty(odrDynamicCluster)):
      parms = "-dcname %s" % odrDynamicCluster
    else:
      parms = "-odrname %s -odrnode %s" % (odrName,odrNode)
    
    parms = "-wcname %s -type %s %s" %(wcName,wcType,parms)
    
    if (not isEmpty(transactionClass)):
      parms ="%s -tcname %s" % (parms,transactionClass)
    
    if (not isEmpty(members)):
      parms = "%s -members %s" % (parms,members)
    
    if (not isEmpty(vhost)):
      parms = "%s -vhost %s" % (parms,vhost)
    
    parms = "[ %s ]" % parms
    
    _app_trace("About to call AdminTask.createServicePolicyWorkClass(%s)" % parms)    
    retval = AdminTask.createServicePolicyWorkClass(parms)    
    
    createMultipleChildren(moduleList,"WorkClassModule",retval)
   
    createMultipleChildren(matchRuleList,"MatchRule",retval)

    
  except:
    _app_exception("Unexpected problem in createODRServiceWorkClass()")
  
  _app_exit("createODRServiceWorkClass(retval=%s)" % retval)
  return retval





#-------------------------------------------------------------------------------
# modifyApplicationServiceWorkClass
#
# Parameters
#   wcId - the WorkClass configuration ID to update - Optional - can be determined by appName/wcName parms
#   appName - Name of the Application that Routing Work Class is defined for (optional, can be ignored in wcId supplied)
#   wcName  - Name of the work class (optional, can be ignored in wcId supplied)
#   transactionClass - Name of transaction class to associate this Service Work Class with
#                      Optional, will be pulled from wcProps["matchAction"] if not supplied
#   wcType - Type of service Work Class
#            Optional, will be pulled from wcProps["type"] if not supplied
#            Support both short and long names
#            {'JMS', "JMSWORKCLASS", 'IIOP',"IIOPWORKCLASS", 'HTTP',"HTTPWORKCLASS", 'SOAP',"SOAPWORKCLASS"}
#
#    matchRuleList - List of dictionaries that define MatchRule definitions to create
#    moduleList - List of dictionaries that define WorkClassModule definitions to create
#    appendModules - If true, modules defined in moduleList will be appended to existing definitions, otherwise
#                    moduleList will replace existing WorkClassModule definitions
#    appendRuless - If true, MatchRules defined in ruleList will be appended to existing definitions, otherwise
#                    ruleList will replace existing MatchRule definitions
#-------------------------------------------------------------------------------
def modifyApplicationServiceWorkClass(wcId=None,appName=None,wcName=None,transactionClass=None,wcType=None,wcProps=None,
                                      moduleList=None,matchRuleList=None,appendModules=0,appendRules=0):
  _app_entry("modifyApplicationServiceWorkClass(%s,%s,%s,%s,%s,%s,%s,%s,%d,%d)" , 
             wcId,appName,wcName,transactionClass,wcType,wcProps,moduleList,matchRuleList,appendModules,appendRules)
  retval = None
  
  typeMap = {'JMS': "JMSWORKCLASS", 'IIOP':"IIOPWORKCLASS", 'HTTP':"HTTPWORKCLASS", 'SOAP':"SOAPWORKCLASS"}
    
  try:
    if (isEmpty(wcId) and not isEmpty(appName) and not isEmpty(wcName)):
      wcId = findApplicationServiceWorkClass(appName,wcName)
      
    
    wcProps = toDictionary(wcProps)
    
    # Confirm the appropriate type is passed in (if passed in at all)
    if (not isEmpty(wcType)):
      if typeMap.has_key(wcType):
        # Get long name
        wcType = typeMap[wcType]  
    else:
      tempType = wcProps.get("type")
      if (not isEmpty(tempType) and (typeMap.has_key(tempType))):
        wcProps["type"] = typeMap[tempType]
    
      
    # Build attribute list, using optional params if supplied
    # otherwise values will be pulled from dictionary  
    attrs = propsToAttrList(wcProps)
    
    if (not isEmpty(wcType)):
      attrs.append(["type",wcType])
    
    if (not isEmpty(transactionClass)):
      attrs.append(["matchAction",transactionClass])
    
    if (len(attrs) > 0):
      if (modifyObject(wcId,attrs)):
        raise StandardError("Unable to update WorkClass %s configuration with %s" % (wcId,attrs))

    if (moduleList != None and not appendModules):
      # Erase existing modules
      modList = wsadminToList(AdminConfig.showAttribute(wcId,"workClassModules"))
      for modId in modList:
        if (isEmpty(modId)):
          continue
        _app_trace('About to call AdminConfig.remove(%s)' % modId)
        AdminConfig.remove(modId)
    
      
    createMultipleChildren(moduleList,"WorkClassModule",wcId)
    
    if (matchRuleList != None and not appendRules):
      # Erase existing rules
      ruleList = wsadminToList(AdminConfig.showAttribute(wcId,"matchRules"))
      for ruleId in ruleList:
        if (isEmpty(ruleId)):
          continue
        _app_trace('About to call AdminConfig.remove(%s)' % ruleId)
        AdminConfig.remove(ruleId)
    elif (matchRuleList != None and len(matchRuleList) > 0 and appendRules):
      # Make sure we don't have any conflicts
      existingRules = wsadminToList(AdminConfig.showAttribute(wcId,"matchRules"))
      for existingId in existingRules:
        if (isEmpty(existingId)): 
          continue
        matchExpression = AdminConfig.showAttribute(existingId,"matchExpression")
        for newRule in matchRuleList:
          if newRule.get("matchExpression") == matchExpression:
            # Conflict - erase existing
            _app_trace('About to call AdminConfig.remove(%s)' % existingId)
            AdminConfig.remove(existingId)
            break
            
      
        
    createMultipleChildren(matchRuleList,"MatchRule",wcId)        
    
    retval = wcId
    
    
  except:
    _app_exception("Unexpected problem in modifyApplicationServiceWorkClass()")
  
  _app_exit("modifyApplicationServiceWorkClass(retval=%s)" % retval)
  return retval
  

#-------------------------------------------------------------------------------
# deleteApplicationServiceWorkClass
#   Delete the configuration for a Service Work Class
#
#   Note - this method does not support BLA comp-units because it does not appear
#   possible to create one besides the Default_HTTP_WC
# Parameters
#   appName - Name of application
#   wcName - Name of WorkClass
#
# Returns the configuration ID of removed WorkClass item, None if not defined
#-------------------------------------------------------------------------------
def deleteApplicationServiceWorkClass(appName,wcName):
  _app_entry("deleteApplicationServiceWorkClass(%s,%s)" , appName,wcName)
  defaults = ["Default_HTTP_WC", "Default_SOAP_WC","Default_IIOP_WC","Default_JMS_WC" ]

  retval = None
  
  try:
    if (wcName in defaults):
      raise StandardError("Deleting default workclass %s is not supported" % wcName)
      
    wcId = findApplicationServiceWorkClass(appName,wcName)
    if (not isEmpty(wcId)):
      _app_trace("About to call AdminConfig.remove(%s)" % wcId)
      AdminConfig.remove(wcId)
      retval = wcId
    
  except:
    _app_exception("Unexpected problem in deleteApplicationServiceWorkClass()")
  
  _app_exit("deleteApplicationServiceWorkClass(retval=%s)" % retval)
  
  return retval


#-------------------------------------------------------------------------------
# findApplicationServiceWorkClass
#
# Parameters
#    appName - application name (includes -editionX.Y if this is editioned application)
#    wcName - name of work class
#
# Returns configuration ID if found, empty string if not
#-------------------------------------------------------------------------------
def findApplicationServiceWorkClass(appName,wcName):
  _app_entry("findServiceWorkClass(%s,%s)" , appName,wcName)
  retval = None
  try:
    retval = AdminConfig.getid("/Deployment:%s/WorkClass:%s/" % (appName,wcName))
  except:
    _app_exception("Unexpected problem in findApplicationServiceWorkClass()")
  
  _app_exit("findApplicationServiceWorkClass(retval=%s)" % retval)
  return retval






#wsadmin>print AdminTask.help("createRoutingPolicyWorkClass")
#WASX8006I: Detailed help for command: createRoutingPolicyWorkClass
#
#Description: Use this command to create a Routing Policy Workclass
#
#Target object: null
#
#Arguments:
#  appname - Name of the application to apply the routing policy workclass to (non edition qualified, ie MyApplication).
#  cuname - WXDO0321
#  odrname - Name of the On Demand Router resource related to the workclass.
#  odrnode - Name of the node which the On Demand Router resides on.
#  dcname - Name of the On Demand Router dynamic cluster resource related to the workclass.
#  *wcname - Name of the workclass, must be unique.
#  *type - Type of the workclass, must be HTTP, IIOP, or SOAP
#  *actiontype - Default action type for the workclass, must be permit, permitsticky, permitMM, permitstickyMM, reject, or redirect
#  *action - Default action for the workclass.  If the actionType is a permit action, provide the generic server cluster name to route to.  If the action Type is reject, provide the error code to reutrn.  If the actionType is redirect, provide the URI to redirect to.
#  members - Workclass type specific pattern
#        HTTP = /test1?/test2/*
#        IIOP = <ejbName>:<ejbMethod>?<ejbName>:<ejbMethod>
#        SOAP = <webService>:<operationName>?<webSerivce>:<operationName>
#        JMS  = <bus>:<destination>?<bus>:<destination>
#  vhost - Name of the virtual host to apply the workclass to.
#
#Steps:
#  None


#-------------------------------------------------------------------------------
# createApplicationRoutingWorkClass
#
# Parameters
#    appName - Name of the Application that Routing Work Class is defined for
#    wcName  - Name of the work class
#    cuName  - Placeholder - this actually can't be done in wsadmin
#    wcType  - optional, can be specified here or in wcProps dictionary at wcProps["type"]
#                  Valid values are: "JMSWORKCLASS",'JMS', "IIOPWORKCLASS","IIOP", "HTTPWORKCLASS","HTTP", "SOAPWORKCLASS","SOAP"
#    actionType,
#    action    - optional, can also be specified as wcProps["matchAction"]="actionType:action"
#                actiontype - Default action type for the workclass, must be permit, permitsticky, permitMM, permitstickyMM, reject, or redirect
#                action - Default action for the workclass.  If the actionType is a permit action, provide the generic server cluster name to route to.  If the action Type is reject, provide the error code to reutrn.  If the actionType is redirect, provide the URI to redirect to.
#    wcProps - Base properties can be passed in as a dictionary (optional)
#    matchRuleList - List of dictionaries that define MatchRule definitions to create
#    moduleList - List of dictionaries that define WorkClassModule definitions to create
#-------------------------------------------------------------------------------
def createApplicationRoutingWorkClass(appName,wcName,cuName=None,wcType=None,actionType=None,action=None,wcProps=None,matchRuleList=None,moduleList=None):
  _app_entry("createApplicationRoutingWorkClass(%s,%s,%s,%s,%s,%s,%s,%s)" , appName,wcName,wcType,actionType,action,wcProps,matchRuleList,moduleList)
  retval = None
  typeMap = {"JMSWORKCLASS":'JMS', "IIOPWORKCLASS":"IIOP", "HTTPWORKCLASS":"HTTP", "SOAPWORKCLASS":"SOAP"}
  try:
    if (isEmpty(wcType) and wcProps != None):
      wcType = wcProps.get("type")
    
    # Make sure we use type value required by AdminTask
    if (typeMap.has_key(wcType)):
      wcType = typeMap[wcType]
      
    if (isEmpty(actionType) and wcProps != None):
      actionProp = wcProps.get("matchAction")
      if (not isEmpty(actionProp)):
        actionInfo = actionProp.split(":")
        if (len(actionInfo) == 2):
          actionType = actionInfo[0]
          action=actionInfo[1]
    
    # Confirm that required fields are defined
    if ( (isEmpty(appName) and isEmpty(cuName)) or isEmpty(wcName) or isEmpty(wcType) or isEmpty(actionType) or isEmpty(action)):
      raise StandardError("Missing a requred value: appName=%s cuName=%s wcName=%s wcType=%s actionType=%s action=%s" %(appName,cuName,wcName,wcType,actionType,action))
    
    if (not isEmpty(cuName)):
      
      # Turns out the -cuname option isn't supported and the createRoutingPolicyWorkClass
      # command does not support BLA applications
      #
      # If app name is not supplied, see this error in trace 
      #RoutingPolicy 3   Must provide valid application name or on demand router name or on demand router dynamic cluster name.
      
      if (appName.startswith("WebSphere:blaname=")):
        tempName = appName[10:]
      else:
        tempName = appName
      parms = "[ -cuname %s -wcname %s -type %s -actiontype %s -action %s ]" % (cuName,wcName,wcType,actionType,action)
      
      raise StandardError("cuName is unsupported option - unable to configure with wsadmin")
    else:  
      parms = "[ -appname %s -wcname %s -type %s -actiontype %s -action %s ]" % (appName,wcName,wcType,actionType,action)
    _app_trace('About to call AdminTask.createRoutingPolicyWorkClass(%s)'% parms)
    retval = AdminTask.createRoutingPolicyWorkClass(parms)
    
    # Now see if there are any additional attrs to modify
    tempDict = {}
    if (wcProps != None):
      for key in wcProps.keys():
        if key in ['name','type','matchAction']:
          continue
        tempDict[key] = wcProps[key]
    
    if (len(tempDict) > 0):
      attrs = propsToAttrList(tempDict)
      if (modifyObject(retval,attrs)):
        raise StandardError("Problem applying attributes %s" % (attrs))
    
    createMultipleChildren(moduleList,"WorkClassModule",retval)
    
    createMultipleChildren(matchRuleList,"MatchRule",retval)
    
  except:
    _app_exception("Unexpected problem in createApplicationRoutingWorkClass()")
  
  _app_exit("createApplicationRoutingWorkClass(retval=%s)" % retval)
  return retval
  

#-------------------------------------------------------------------------------
# createApplicationRoutingWorkClass
#    Create a Generic Server Routing Work Class for an On Demand Router
# Parameters
#    wcName  - Name of the work class
#    odrName - Name of On Demand Router
#    odrNode - Node of On Demand Router
#    odrDynamicCluster optional, can be used instead of odrName and odrNode
#    wcType  - optional, can be specified here or in wcProps dictionary at wcProps["type"]
#                  Valid values are: "JMSWORKCLASS",'JMS', "IIOPWORKCLASS","IIOP", "HTTPWORKCLASS","HTTP", "SOAPWORKCLASS","SOAP"
#    actionType,
#    action,
#    vhost    - optional, can also be specified as wcProps["matchAction"]="virtualHost:actionType:action"
#                actiontype - Default action type for the workclass, must be permit, permitsticky, permitMM, permitstickyMM, reject, or redirect
#                action - Default action for the workclass.  If the actionType is a permit action, provide the generic server cluster name to route to.  If the action Type is reject, provide the error code to reutrn.  If the actionType is redirect, provide the URI to redirect to.
#                vhost - Virtual host to associate with this generic server routing
#    wcProps - Base properties can be passed in as a dictionary (optional)
#    matchRuleList - List of dictionaries that define MatchRule definitions to create
#    moduleList - List of dictionaries that define WorkClassModule definitions to create
#-------------------------------------------------------------------------------
def createODRRoutingWorkClass(wcName,odrName=None,odrNode=None,odrDynamicCluster=None,wcType="HTTPWORKCLASS",actionType=None,action=None,vhost=None,wcProps=None,matchRuleList=None,moduleList=None):
  _app_entry("createODRRoutingWorkClass(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)" , wcName,odrName,odrNode,odrDynamicCluster,wcType,actionType,action,wcProps,matchRuleList,moduleList)
  retval = None
  typeMap = {"JMSWORKCLASS":'JMS', "IIOPWORKCLASS":"IIOP", "HTTPWORKCLASS":"HTTP", "SOAPWORKCLASS":"SOAP"}
  try:
    if (isEmpty(wcType) and wcProps != None):
      wcType = wcProps.get("type")
    
    # Make sure we use type value required by AdminTask
    if (typeMap.has_key(wcType)):
      wcType = typeMap[wcType]
      
    if (isEmpty(actionType) and wcProps != None):
      actionProp = wcProps.get("matchAction")
      if (not isEmpty(actionProp)):
        actionInfo = actionProp.split(":")
        if (len(actionInfo) == 3):
          vhost = actionInfo[0]
          actionType = actionInfo[1]
          action=actionInfo[2]
        elif (len(actionInfo) == 2):
          actionType = actionInfo[0]
          action=actionInfo[1]          
    
    # Confirm that required fields are defined
    if ( (isEmpty(odrName) and isEmpty(odrNode) and isEmpty(odrDynamicCluster)) or isEmpty(wcName) or isEmpty(wcType) or isEmpty(actionType) or isEmpty(action)):
      raise StandardError("Missing a requred value: odrName=%s odrNode=%s odrDynamicCluster=%s wcName=%s wcType=%s actionType=%s action=%s" %(odrName,odrNode,odrDynamicCluster,wcName,wcType,actionType,action))
    
    parms = "-wcname %s -type %s -actiontype %s -action %s" % (wcName,wcType,actionType,action)
    if (not isEmpty(vhost)):
      parms = "%s -vhost %s" % (parms,vhost)
      
    if (not isEmpty(odrDynamicCluster)):
      parms = "[ %s -dcname %s ]" % (parms,odrDynamicCluster)
    else:
      parms = "[ %s -odrname %s -odrnode %s ]" % (parms,odrName,odrNode)

    _app_trace('About to call AdminTask.createRoutingPolicyWorkClass(%s)'% parms)
    retval = AdminTask.createRoutingPolicyWorkClass(parms)
    
    # Now see if there are any additional attrs to modify
    tempDict = {}
    if (wcProps != None):
      for key in wcProps.keys():
        if key in ['name','type','matchAction']:
          continue
        tempDict[key] = wcProps[key]
    
    if (len(tempDict) > 0):
      attrs = propsToAttrList(tempDict)
      if (modifyObject(retval,attrs)):
        raise StandardError("Problem applying attributes %s" % (attrs))
    
    createMultipleChildren(moduleList,"WorkClassModule",retval)
    
    createMultipleChildren(matchRuleList,"MatchRule",retval)
    
  except:
    _app_exception("Unexpected problem in createODRRoutingWorkClass()")
  
  _app_exit("createODRRoutingWorkClass(retval=%s)" % retval)
  return retval
  




#-------------------------------------------------------------------------------
# modifyApplicationRoutingWorkClass
#
# Parameters
#    wcId - the WorkClass configuration ID to update - Optional - can be determined by appName/wcName parms
#    appName - Name of the Application that Routing Work Class is defined for (optional, can be ignored in wcId supplied)
#    wcName  - Name of the work class (optional, can be ignored in wcId supplied)
#    actionType,
#    action    - optional, can also be specified as wcProps["matchAction"]="actionType:action"
#                actiontype - Default action type for the workclass, must be permit, permitsticky, permitMM, permitstickyMM, reject, or redirect
#                action - Default action for the workclass.  If the actionType is a permit action, provide the generic server cluster name to route to.  If the action Type is reject, provide the error code to reutrn.  If the actionType is redirect, provide the URI to redirect to.
#    wcProps - Base properties can be passed in as a dictionary (optional)
#    matchRuleList - List of dictionaries that define MatchRule definitions to create
#    moduleList - List of dictionaries that define WorkClassModule definitions to create
#    appendModules - If true, modules defined in moduleList will be appended to existing definitions, otherwise
#                    moduleList will replace existing WorkClassModule definitions
#    appendRuless - If true, MatchRules defined in ruleList will be appended to existing definitions, otherwise
#                    ruleList will replace existing MatchRule definitions
#
# Returns:
#   WorkClass configuration ID
#-------------------------------------------------------------------------------
def modifyApplicationRoutingWorkClass(wcId=None,appName=None,wcName=None,actionType=None,action=None,
                                      wcProps=None,matchRuleList=None,moduleList=None,appendModules=0,appendRules=0):
  _app_entry("modifyApplicationRoutingWorkClass(%s,%s,%s,%s,%s,%s,%s,%s,%d,%d)" , 
             wcId,appName,wcName,actionType,action,wcProps,matchRuleList,moduleList,appendModules,appendRules)
  retval = None
  
  try:
    wcProps = toDictionary(wcProps)
    
    attrList = propsToAttrList(wcProps)
    if not wcProps.has_key("matchAction") and not isEmpty(actionType) and not isEmpty(action) :
      attrList.append(["matchAction", "%s:%s" % (actionType,action)])
    
    if (isEmpty(wcId) and not isEmpty(appName) and not isEmpty(wcName)):
      wcId = findApplicationRoutingWorkClass(appName,wcName)
    
    if (isEmpty(wcId)):
      raise StandardError("WorkClass ID is required")
    
    if (len(attrList) > 0):
      if (modifyObject(wcId,attrList)):
        raise StandardError("Unable to modify WorkClass %s" % wcId)
      
    if (moduleList != None and not appendModules):
      # Erase existing modules
      modList = wsadminToList(AdminConfig.showAttribute(wcId,"workClassModules"))
      for modId in modList:
        if (isEmpty(modId)):
          continue
        _app_trace('About to call AdminConfig.remove(%s)' % modId)
        AdminConfig.remove(modId)
    
      
    createMultipleChildren(moduleList,"WorkClassModule",wcId)
    
    if (matchRuleList != None and not appendRules):
      # Erase existing rules
      
      ruleList = wsadminToList(AdminConfig.showAttribute(wcId,"matchRules"))
      for ruleId in ruleList:
        if (isEmpty(ruleId)):
          continue
        AdminConfig.remove(ruleId)
    elif (matchRuleList != None and len(matchRuleList) > 0 and appendRules):
      # Make sure we don't have any conflicts
      
      existingRules = wsadminToList(AdminConfig.showAttribute(wcId,"matchRules"))
      for existingId in existingRules:
        if (isEmpty(existingId)): 
          continue
        matchExpression = AdminConfig.showAttribute(existingId,"matchExpression")
        for newRule in matchRuleList:
          if newRule.get("matchExpression") == matchExpression:
            # Conflict - erase existing
            _app_trace('About to call AdminConfig.remove(%s)' % existingId)
            AdminConfig.remove(existingId)
            break
        
    createMultipleChildren(matchRuleList,"MatchRule",wcId)
    
    retval = wcId
    
  except:
    _app_exception("Unexpected problem in modifyApplicationRoutingWorkClass()")
  
  _app_exit("modifyApplicationRoutingWorkClass(retval=%s)" % retval)
  return retval
  

#-------------------------------------------------------------------------------
# deleteApplicationRoutingWorkClass
#
#   Deletes configuration of Routing work class. Default work classes are
#   protected from deletion.
#
# Parameters
#   appName - Name of application
#   wcName - Name of WorkClass
#   cuName - Name of BLA composition unit (optional)
#
# Returns the configuration ID of removed WorkClass item, None if not defined
#-------------------------------------------------------------------------------
def deleteApplicationRoutingWorkClass(appName,wcName,cuName = None):
  _app_entry("deleteApplicationRoutingWorkClass(%s,%s)" , appName,wcName)
  
  defaults = ["Default_HTTP_WC", "Default_SOAP_WC","Default_IIOP_WC","Default_JMS_WC" ]

  retval = None
  
  try:
    if (wcName in defaults):
      raise StandardError("Deleting default workclass %s is not supported" % wcName)
    
    wcId = None
    
    if (not isEmpty(cuName)):  
      wcId = findCompUnitRoutingWorkClass(cuName,wcName)
    else:
      wcId = findApplicationRoutingWorkClass(appName,wcName)
      
    if (not isEmpty(wcId)):
      _app_trace("About to call AdminConfig.remove(%s)" % wcId)
      AdminConfig.remove(wcId)
    
  except:
    _app_exception("Unexpected problem in deleteApplicationRoutingWorkClass()")
  
  _app_exit("deleteApplicationRoutingWorkClass(retval=%s)" % retval)
  
  return retval

#-------------------------------------------------------------------------------
# findApplicationRoutingWorkClass
#  
#
# Parameters
#    appName - application name (exclude -editionX.Y if this is editioned application)
#    wcName - name of work class
#
# Returns the configuration ID of the Routing WorkClass item
#-------------------------------------------------------------------------------
def findApplicationRoutingWorkClass(appName,wcName):
  _app_entry("findApplicationRoutingWorkClass(%s,%s)" , appName,wcName)
  retval = None
  try:
    # This will return list of WorkClass items with the name, and we'll have
    # to narrow it down to the correct scope
    # Looking for IDs with structure like: 
    #   Default_HTTP_WC(cells/IMScriptingCell/applications/IntelligentManagementApp.ear/workclasses/Default_HTTP_WC|workclass.xml#Default_HTTP_WC)
    wcList = AdminConfig.getid("/WorkClass:%s/" % wcName).splitlines()
    for wcId in wcList:
      if (isEmpty(wcId)):
        continue
      if (wcId.find(appName) < 0):
        continue
      if (wcId.find("/deployments/") >= 0):
        continue
      
      idTokens = wcId.split("/")
      
      tempApplicationName = idTokens[idTokens.index("applications")+1]
      if (tempApplicationName.endswith(".ear") and not appName.endswith(".ear")):
        tempApplicationName = tempApplicationName[:-4]
      if (tempApplicationName == appName):
        retval = wcId
        break
      
      
  except:
    _app_exception("Unexpected problem in findApplicationRoutingWorkClass()")
  
  _app_exit("findApplicationRoutingWorkClass(retval=%s)" % retval)
  return retval




#-------------------------------------------------------------------------------
# findCompUnitRoutingWorkClass
#
# Parameters
#   cuName - Comp Unit the workclass is defined for
#   wcName - name of the work class
#
# Returns the configuration ID of the Routing WorkClass item
#-------------------------------------------------------------------------------
def findCompUnitRoutingWorkClass(cuName,wcName):
  _app_entry("findCompUnitRoutingWorkClass(%s,%s)" , cuName,wcName)
  retval = None
  try:
   
    # Looking for IDs that match this pattern                                   
    #   Default_HTTP_WC(cells/IMScriptingCell/cus/com.ibm.samples.websphere.osgi.blog_0001.eba/workclasses/Default_HTTP_WC|workclass.xml#Default_HTTP_WC)
    #   Default_HTTP_WC(cells/IMScriptingCell/cus/com.ibm.samples.websphere.osgi.colors_0002.eba/workclasses/Default_HTTP_WC|workclass.xml#Default_HTTP_WC)

    wcList = AdminConfig.getid("/WorkClass:%s/" % wcName).splitlines()
    for wcId in wcList:
      if (isEmpty(wcId)):
        continue

      if (wcId.find("/cus/%s/workclasses/" % cuName) < 0):
        continue
      
      retval = wcId
      break
  except:
    _app_exception("Unexpected problem in findCompUnitRoutingWorkClass()")
  
  _app_exit("findCompUnitRoutingWorkClass(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# findCompUnitServiceWorkClass
#
# Parameters
#    cuName - Name of the composition unit (e.g. the eba)
#    wcName - AFAIK, only Default_HTTP_WC is valid as of 8.5.5
#
# Returns the configuration ID of the Service WorkClass
#-------------------------------------------------------------------------------
def findCompUnitServiceWorkClass(cuName,wcName):
  _app_entry("findCompUnitServiceWorkClass(%s,%s)" ,cuName,wcName)
  retval = None
  try:
    # Looking for IDs that match this pattern     
    # Default_HTTP_WC(cells/IMScriptingCell/cus/com.ibm.samples.websphere.osgi.blog_0001.eba/cver/BASE/workclasses/Default_HTTP_WC|workclass.xml#Default_HTTP_WC)
                              
    wcList = AdminConfig.getid("/WorkClass:%s/" % wcName).splitlines()
    for wcId in wcList:
      if (isEmpty(wcId)):
        continue

      if (wcId.find("/cus/%s/cver/"%cuName) < 0):
        continue
      
      retval = wcId
      break

  except:
    _app_exception("Unexpected problem in findCompUnitServiceWorkClass()")
  
  _app_exit("findCompUnitServiceWorkClass(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# findODRRoutingWorkClass
#
# Parameters
#     odrNode - Name of node hosting ODR server
#     odrName - Name of odr server
#     workClassName - Name of workclass to look up
#
# Returns:
#    Configuration ID of work class (if exists, None otherwise)
#-------------------------------------------------------------------------------
def findODRRoutingWorkClass(odrNode,odrName,workClassName):
  _app_entry("findODRRoutingWorkClass(%s,%s,%s)" , odrNode,odrName,workClassName)
  retval = None
  try:
    workclasses = []
    nodeId = AdminConfig.getid("/Node:%s/"%odrNode)
    
    if (not isEmpty(nodeId)):
      workclasses = AdminConfig.list("WorkClass",nodeId).splitlines()
    for wc in workclasses:
      if (isEmpty(wc)):
        continue
      tokens = wc.split("/")
      if odrName not in tokens:
        continue
      if ("routing" not in tokens):
        continue
      
      tempname = splitOffName(wc)
      if (tempname == workClassName):
        retval = wc
        break  
    

  except:
    _app_exception("Unexpected problem in findODRRoutingWorkClass()")
  
  _app_exit("findODRRoutingWorkClass(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# findODRServiceWorkClass
#
# Parameters
#     odrNode - Name of node hosting ODR server
#     odrName - Name of odr server
#     workClassName - Name of workclass to look up
#
# Returns:
#    Configuration ID of work class (if exists, None otherwise)
#-------------------------------------------------------------------------------
def findODRServiceWorkClass(odrNode,odrName,workClassName):
  _app_entry("findODRServiceWorkClass(%s,%s,%s)" , odrNode,odrName,workClassName)
  retval = None
  try:
    workclasses = []
    nodeId = AdminConfig.getid("/Node:%s/"%odrNode)
    
    if (not isEmpty(nodeId)):
      workclasses = AdminConfig.list("WorkClass",nodeId).splitlines()

    for wc in workclasses:
      if (isEmpty(wc)):
        continue
      tokens = wc.split("/")
      if odrName not in tokens:
        continue
      if ("sla" not in tokens):
        continue
      
      tempname = splitOffName(wc)
      if (tempname == workClassName):
        retval = wc
        break  

  except:
    _app_exception("Unexpected problem in findODRServiceWorkClass()")
  
  _app_exit("findODRServiceWorkClass(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# getWorkClassProperties
#
# Parameters
#
# Returns a dictionary with key/value pairs that represent settings of WorkClass, such
# as this example for a routing work class:
#
# workclass.prop.name = Default_SOAP_WC
# workclass.prop.matchAction = permit:IntelligentManagementApp-edition1.0
# workclass.prop.type = SOAPWORKCLASS
# workclass.workClassModules.1.prop.id = Default_SOAP_WC:!:IntelligentManagementApp:!:EJBModuleTwo.jar
# workclass.workClassModules.1.prop.matchExpression = *
# workclass.workClassModules.1.prop.moduleName = EJBModuleTwo.jar
# workclass.workClassModules.count = 1
# workclass.matchRules.1.prop.matchAction = permit:IntelligentManagementApp-edition2.0
# workclass.matchRules.1.prop.matchExpression = service$CLIENT_TYPE = 'NEW_APP_TESTER'
# workclass.matchRules.1.prop.priority = 0
# workclass.matchRules.count = 1
#-------------------------------------------------------------------------------
def getWorkClassProperties(workClassId):
  _app_entry("getWorkClassProperties(%s)" , workClassId)
  retval = {}
  try:
    collectSimpleProperties(retval,"workclass.prop" ,workClassId,getSimpleChildren=1,collectListChildren=1,collectPropertyAttributes=1,getChildType=0)
  except:
    _app_exception("Unexpected problem in getWorkClassProperties()")
  
  _app_exit("getWorkClassProperties(retval=%s)" % retval)
  return retval
  

