################################################################################
# HealthClass.py
#
# Contains methods for manipulating HealthClass configuration items (Health Policies)
#
#  createHealthClass(hcName, hcProps, conditionType, conditionProps, healthActions, targetMemberships)
#  modifyHealthClass(hcId, hcProps, conditionProps, healthActions, targetMemberships)
#  deleteHealthClass(hcName)
#  findHealthClass(hcName)
#  getHealthClassProperties(hcID)
#
################################################################################

#---------------------------------------------------------------------
# createHealthClass
#
# Parameters
#     hcName - Name of the HealthClass
#     hcProps - Basic properties of HealthClass
#     conditionType - WCCM type of the Health Condition
#                      HealthCondition(AgeCondition, WorkloadCondition, MemoryCondition, 
#                      ResponseCondition, StuckRequestCondition, StormDrainCondition, 
#                      MemoryLeakAlgorithm, GCPercentageCondition)
#     conditionProps
#     healthActions - a list of tuples that specify healthActions 
#                         ("HealthAction"|"CustomHealthAction", properties)
#                     Assumes list is in proper step order
#     targetMembers - a list of dictionaries that have properties for each TargetMembership
#
# Returns:
#   Configuration ID
#---------------------------------------------------------------------
def createHealthClass(hcName, hcProps, conditionType, conditionProps, healthActions, targetMemberships):
  _app_entry('createHealthClass(%s,%s,%s,%s,%s,%s)' % (hcName, hcProps,conditionType, conditionProps, healthActions, targetMemberships))
  retval = None
  try:
    #some stuff
    attrs = propsToAttrList(hcProps)
    
    attrs.append( ["name",hcName] )
    
    cellId = getCellId()
    _app_trace('About to call AdminConfig.create("HealthClass",%s,%s)'% (cellId,attrs))
    retval = AdminConfig.create("HealthClass",cellId,attrs)
    
    if (not isEmpty(conditionType)):
      condAttrs = propsToAttrList(conditionProps)
      _app_trace("About to call AdminConfig.create(%s,%s,%s)" % (conditionType,retval,condAttrs))
      conditionId = AdminConfig.create(conditionType,retval,condAttrs)
    
    if (healthActions != None):
      idx = 0
      for ha in healthActions:
        idx += 1
        haType = ha[0]
        haDict = ha[1]
        haDict["stepNum"] = str(idx)
        haAttrs = propsToAttrList(haDict)
        _app_trace("About to call AdminConfig.create(%s,%s,%s)" % (haType,retval,haAttrs))
        haId = AdminConfig.create(haType,retval,haAttrs)
    
    if (targetMemberships != None):
      for tm in targetMemberships:
        tmAttrs = propsToAttrList(tm)
        _app_trace('About to call AdminConfig.create("TargetMembership",%s,%s)' % (retval,tmAttrs))
        tmId = AdminConfig.create("TargetMembership",retval,tmAttrs)    
  except:
    _app_exception("Unexpected problem with createHealthClass(%s....)" % hcName)
  
  _app_exit('createHealthClass(retval=%s)' % retval)
  return retval


#---------------------------------------------------------------------
# modifyHealthClass
#
# Parameters
#     hcId - ConfigurationId of the health class
#     hcProps - Basic properties of HealthClass
#     conditionProps - Properties to update existing HealthCondition configuration
#     healthActions - a list of tuples that specify healthActions 
#                         ("HealthAction"|"CustomHealthAction", properties)
#                     Assumes list is in proper step order
#     targetMembers - a list of dictionaries that have properties for each TargetMembership
#
# Returns:
#   Configuration ID
#---------------------------------------------------------------------
def modifyHealthClass(hcId, hcProps, conditionProps, healthActions, targetMemberships):
  _app_entry('modifyHealthClass(%s,%s,%s,%s,%s)' % (hcId, hcProps,conditionProps, healthActions, targetMemberships))
  retval = hcId
  try:
    #some stuff
    if (hcProps != None and len(hcProps) > 0):
      attrs = propsToAttrList(hcProps)
      if (modifyObject(hcId,attrs)):
        raise StandardError("Propblem updating base properties")
    
    
    if (conditionProps != None and len(conditionProps) > 0):
      conditionId = AdminConfig.showAttribute(hcId,"HealthCondition")
      condAttrs = propsToAttrList(conditionProps)
      if (modifyObject(conditionId,condAttrs)):
        raise StandardError("Error updating HealthCondition %s" % conditionId)
        
    
    if (healthActions != None):
      # Remove existing health actions
      actions = wsadminToList(AdminConfig.showAttribute(hcId,"healthActions"))
      for actionId in actions:
        if (not isEmpty(actionId)):
          _app_trace("About to call AdminConfig.remove(%s)" % actionId)
          AdminConfig.remove(actionId)
          
      idx = 0
      for ha in healthActions:
        idx += 1
        haType = ha[0]
        haDict = ha[1]
        haDict["stepNum"] = str(idx)
        haAttrs = propsToAttrList(haDict)
        _app_trace("About to call AdminConfig.create(%s,%s,%s)" % (haType,retval,haAttrs))
        haId = AdminConfig.create(haType,retval,haAttrs)
    
    if (targetMemberships != None):
      # Remove existing target Memberships
      tmlist = wsadminToList(AdminConfig.showAttribute(hcId,"targetMemberships"))
      for tmid in tmlist:
        if (not isEmpty(tmid)):
          _app_trace("About to call AdminConfig.remove(%s)" % tmid) 
          AdminConfig.remove(tmid)
          
      for tm in targetMemberships:
        tmAttrs = propsToAttrList(tm)
        _app_trace('About to call AdminConfig.create("TargetMembership",%s,%s)' % (retval,tmAttrs))
        tmId = AdminConfig.create("TargetMembership",retval,tmAttrs)    
  except:
    _app_exception("Unexpected problem with modifyHealthClass(%s....)" % hcId)
  
  _app_exit('modifyHealthClass(retval=%s)' % retval)
  return retval  


#---------------------------------------------------------------------
# deleteHealthClass
#
# Removes the health class with the specified ID from the configuration
#
# Returns: ID of the removed configuration, None if did not exist
#---------------------------------------------------------------------
def deleteHealthClass(hcName):
  _app_entry('deleteHealthClass(%s)' % (hcName))
  retval = None
  try:
    retval = findHealthClass(hcName)
    if (not isEmpty(retval)):
      _app_trace("About to call AdminConfig.remove(%s)" % retval)
      AdminConfig.remove(retval)
  except:
    _app_exception("Unexpected problem with deleteHealthClass")
  
  _app_exit('deleteHealthClass(retval=%s)' % retval)
  return retval

#---------------------------------------------------------------------
# findHealthClass
#     Returns the configuration ID for the HealthClass with the specified name
#---------------------------------------------------------------------
def findHealthClass(hcName):
  _app_entry('findHealthClass(%s)' % (hcName))
  retval = None
  try:
    # Find the HealthClass with the specified name
    hcId = AdminConfig.getid("/HealthClass:%s/" %hcName)
    if (not isEmpty(hcId)):
      retval = hcId
  except:
    _app_exception("Unexpected problem with findHealthClass")
  
  _app_exit('findHealthClass(retval=%s)' % retval)
  return retval
  
#---------------------------------------------------------------------
# getHealthClassProperties
# 
# Returns a dictionary with the configuration properties for a HealthClass using
# the following key syntax
#     -- Base properties
#     healthClass.prop.XXX  - base properties
#     -- Properties for the n HealthActions
#     healthClass.healthActions.1-n.type = HealthAction  
#     healthClass.healthActions.1-n.prop.XXX - health action properties
#     healthClass.healthActions = [list of 1-n dictionaries containing values with base keys (no .prop.xxx) and special wccmType key]
#     -- Properties for HealthCondition
#     healthClass.HealthCondition.type = HealthCondition (or other WCCM type)
#     app.healthClass.HealthCondition.prop.XXX 
#     -- Properties for n TargetMembership
#     healthClass.targetMemberships.1-n.type = TargetMembership 
#     healthClass.1.targetMemberships.1-n.prop.memberString = SampleCluster_2:!:IMScriptingNode2
#     healthClass.1.targetMemberships.1-n.prop.type = 1
#     healthClass.targetMemberships = [list of 1-n dictionaries containing properies]
#---------------------------------------------------------------------  
def getHealthClassProperties(hcID):
  _app_entry('getHealthClassProperties(%s)' % (hcID))
  retval = {}
  try:
    
    nestedIds = {}
    collectSimpleProperties(retval, "healthClass.prop",hcID, optionalSkipList=[],idProps=nestedIds)
    
    prefix = "healthClass"
    for key in nestedIds.keys():
      val = nestedIds[key]
      shortKey = key[17:]
      
      if (isArray(val)):
        propList = []
        
        idList = wsadminToList(val)
        tidx = 0
        for tempid in idList:
          if (isEmpty(tempid)):
            continue
          tidx +=1
          configType = callGetObjectType(tempid)
          if (not isEmpty(configType)):
            retval["%s.%s.%d.type" % (prefix,shortKey,tidx)] = configType
          collectSimpleProperties(retval,"%s.%s.%d.prop" % (prefix,shortKey,tidx),tempid)
          
          # Now pull out basic key=value pairs to be stored in the list 
          propDict = toDictionary(getPropList(retval,"%s.%s.%d" % (prefix,shortKey,tidx)))
          propDict["wccmType"] = configType
          propList.append(propDict)
          
          
        if (tidx > 0):
          retval["%s.%s.count" % (prefix,shortKey)] = tidx
        
        # Store list as well in results
        retval["%s.%s" % (prefix,shortKey)] = propList
        
      else:
        configType = callGetObjectType(val)
        if (configType != None):
          retval["%s.%s.type" % (prefix,shortKey)] = configType
        collectSimpleProperties(retval,"%s.%s.prop" % (prefix,shortKey),val)
  except:
    _app_exception("Unexpected problem with getHealthClassProperties")
  
  _app_exit('getHealthClassProperties()')
  return retval