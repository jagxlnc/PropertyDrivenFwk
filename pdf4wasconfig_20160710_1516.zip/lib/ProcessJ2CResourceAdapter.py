##############################################################################
# ProcessJ2CResourceAdapter.py
#
# This module is used to process J2C Resource Adapter definitions and resources
# from the jc2ConfigInfo dictionary passed to the entry points.  
# Used for standalone resource adapters and
# Resource Adapters that are deployed as part of an enterprise application.
#
# Because the processing methods in this module are used for two sources of
# J2CResourceAdapter definitions, the prefix for the properties varies.
#
# When used for an Enterprise application connector module, the properties start
# with a prefix like this:
# 
#	app.appdeployment.1.deploymentObject.modules.1.resourceAdapter
#
# When used with a standalone J2C Resource Adapter, the properties start with a prefix 
# like this:
# 
# <TBD>
#
# Primary functions:
# 		processJ2CConnectionFactories 
#			processJ2CAdminObjects
#			processJ2CActivationSpec
#
# Related modules:
#			Utils.py - Utility methods
#			J2CResourceAdapter.py - methods for finding and manipulating J2CResourceAdapter configurations
#     ProcessAppDeployment.py - Calls methods in this module
#
#
#
# Syntax overview:
#
# Connection Factory Syntax Example:
# 
# <prefix>.cf.1.name = ScriptedCF
# <prefix>.cf.1.prop.authDataAlias = Dude3
# <prefix>.cf.1.prop.authMechanismPreference = BASIC_PASSWORD
# <prefix>.cf.1.prop.diagnoseConnectionUsage = false
# <prefix>.cf.2.prop.jndiName = eis/ScriptedCF2
# <prefix>.cf.1.prop.logMissingTransactionContext = true
# <prefix>.cf.1.prop.manageCachedHandles = false
# # settings used to locate ConnectionDefinition reference (if more than one)
# <prefix>.cf.1.connectionDefinition.prop.connectionFactoryImplClass = com.ibm.jjm.samplera.myeis.MyEISConnectionFactoryImpl
# <prefix>.cf.1.connectionDefinition.prop.connectionFactoryInterface = com.ibm.jjm.samplera.myeis.MyEISConnectionFactory
# <prefix>.cf.1.connectionDefinition.prop.connectionImplClass = com.ibm.jjm.samplera.myeis.MyEISConnectionImpl
# <prefix>.cf.1.connectionDefinition.prop.connectionInterface = com.ibm.jjm.samplera.myeis.MyEISConnection
# <prefix>.cf.1.connectionDefinition.prop.managedConnectionFactoryClass = com.ibm.jjm.samplera.myeis.MyEISManagedConnectionFactory
# # Connection pool properties
# <prefix>.cf.1.connectionPool.prop.agedTimeout = 39
# <prefix>.cf.1.connectionPool.prop.connectionTimeout = 60
# <prefix>.cf.1.connectionPool.prop.freePoolDistributionTableSize = 0
# <prefix>.cf.1.connectionPool.prop.maxConnections = 15
# <prefix>.cf.1.connectionPool.prop.minConnections = 0
# <prefix>.cf.1.connectionPool.prop.numberOfFreePoolPartitions = 0
# <prefix>.cf.1.connectionPool.prop.numberOfSharedPoolPartitions = 0
# <prefix>.cf.1.connectionPool.prop.numberOfUnsharedPoolPartitions = 0
# <prefix>.cf.1.connectionPool.prop.purgePolicy = EntirePool
# <prefix>.cf.1.connectionPool.prop.reapTime = 180
# <prefix>.cf.1.connectionPool.prop.stuckThreshold = 0
# <prefix>.cf.1.connectionPool.prop.stuckTime = 0
# <prefix>.cf.1.connectionPool.prop.stuckTimerTime = 0
# <prefix>.cf.1.connectionPool.prop.surgeCreationInterval = 0
# <prefix>.cf.1.connectionPool.prop.surgeThreshold = -1
# <prefix>.cf.1.connectionPool.prop.testConnection = false
# <prefix>.cf.1.connectionPool.prop.testConnectionInterval = 0
# <prefix>.cf.1.connectionPool.prop.unusedTimeout = 600
# <prefix>.cf.1.connectionPool.properties.prop.PoolProp1 = Sample 1|Description
# <prefix>.cf.1.connectionPool.properties.prop.PoolProp2 = Sample 2
# <prefix>.cf.1.connectionPool.properties.prop.PoolProp3 = Sample 3
# # Auth mapping properties
# <prefix>.cf.1.mapping.prop.authDataAlias = Dude3
# <prefix>.cf.1.mapping.prop.mappingConfigAlias = DefaultPrincipalMapping
# <prefix>.cf.count = <last cf index>
#
# J2CAdminObjects:
# <prefix>.j2cAdminObjects.1.name = AdminObjectAlpha
# <prefix>.j2cAdminObjects.1.prop.jndiName = eis/AdminObjectAlpha
# <prefix>.j2cAdminObjects.1.properties.prop.propertyOne = java.lang.String|false|ValueOne
# <prefix>.j2cAdminObjects.1.properties.prop.propertyTwo = java.lang.String|false|ValueTwo
# <prefix>.j2cAdminObjects.1.properties.prop.propertyThree = int|false|100
# # used to find corresponding AdminObject to reference
# <prefix>.j2cAdminObjects.1.adminObject.prop.adminObjectClass = com.ibm.jjm.samplera.myeis.AdminObjectAlphaImpl
# <prefix>.j2cAdminObjects.1.adminObject.prop.adminObjectInterface = com.ibm.jjm.samplera.myeis.AdminObjectAlpha
# ...
# <prefix>.j2cAdminObjects.count = <max index of J2CAdminObjects>
##############################################################################


#-------------------------------------------------------------------------------
# processJ2CAdminObjects
#
# Process the settings for J2CAdminObject defintions that are stored as properties
# in j2cConfigInfo dictionary
# 
# Parameters:
#   resourceAdapterId - The configuration ID of the J2CResourceAdapter that the
#                       J2CAdminObjects will be created under
#   prefix            - The prefix of the resource adapter.
#                       Example: app.appdeployment.1.deploymentObject.modules.1.resourceAdapter
#   raName            - The name of the resource adapter (for logging only)
#   parentDescription - A description of the RA's context for logging only 
#                      (e.g: applicaton name or resource scope)
#-------------------------------------------------------------------------------
def processJ2CAdminObjects(j2cConfigInfo,resourceAdapterId, prefix, raName, parentDescription):

	
	_app_trace("processJ2CAdminObjects(%s,%s,%s,%s)" % (resourceAdapterId, prefix, raName, parentDescription), "entry")
	
	count = int(j2cConfigInfo.get("%s.j2cAdminObjects.count" % prefix,"0"))
	for idx in range(1,count+1):
	
			name = j2cConfigInfo.get("%s.j2cAdminObjects.%d.name" % (prefix,idx),"")
			if (isEmpty(name)):
					continue
			
			# See if the AdminObject is already defined
			adminObjectId = findJ2CAdminObject(name, resourceAdapterId)
			if (not isEmpty(adminObjectId)):
					# Update logic
					existingProps = getJ2CAdminObjectProperties(adminObjectId)
					subProps = getPropListDifferences(j2cConfigInfo,"%s.j2cAdminObjects.%d" % (prefix,idx), existingProps,"j2cAdminObject")
					resourceProps = getPropListDifferences(j2cConfigInfo,"%s.j2cAdminObjects.%d.properties" % (prefix,idx), existingProps, "j2cAdminObject.properties")
					if (subProps.size() > 0 or resourceProps.size() > 0):
							# Update
							retval = modifyJ2CAdminObject(adminObjectId, subProps, resourceProps)
							if (isEmpty(retval)):
									_app_message("Error updating J2CAdminObject %s for resourceAdapter %s at %s" % (name, raName, parentDescription))
									exit()
							else:
									_app_message("Updated J2CAdminObject %s for resourceAdapter %s at %s" % (name, raName, parentDescription))
									
					else:
							_app_message("No need to update J2CAdminObject %s for resourceAdapter %s at %s" % (name, raName, parentDescription))
			else:
					# Will create it
					subProps = getPropList(j2cConfigInfo,"%s.j2cAdminObjects.%d" % (prefix,idx))
					resourceProps = getPropList(j2cConfigInfo,"%s.j2cAdminObjects.%d.properties" % (prefix,idx))
					interfaceClassName = j2cConfigInfo.get("%s.j2cAdminObjects.%d.adminObject.prop.adminObjectInterface" % (prefix,idx),"")
					
					adminObjectId = createJ2CAdminObject(resourceAdapterId, name, subProps.get("jndiName"), subProps.get("description"), interfaceClassName, resourceProps)
					
					if (isEmpty(adminObjectId)):
							_app_message("Error creating J2CAdminObject %s for resourceAdapter %s at %s" % (name, raName, parentDescription))
							exit()
					else:
							_app_message("Created J2CAdminObject %s for resourceAdapter %s at %s" % (name, raName, parentDescription))
	
	_app_trace("processJ2CAdminObjects()","exit")


#-------------------------------------------------------------------------------
# processJ2CActivationSpec
#
# Parameters:
#   resourceAdapterId - The configuration ID of the J2CResourceAdapter that the
#                       J2CActivationSpecs will be created under
#   prefix            - The prefix of the resource adapter.
#                       Example: app.appdeployment.1.deploymentObject.modules.1.resourceAdapter
#   raName            - The name of the resource adapter (for logging only)
#   parentDescription - A description of the RA's context for logging only 
#                      (e.g: applicaton name or resource scope)
#-------------------------------------------------------------------------------
def processJ2CActivationSpec(j2cConfigInfo,resourceAdapterId, prefix, raName, parentDescription):

	_app_trace("processJ2CActivationSpec(%s,%s,%s,%s)" % (resourceAdapterId, prefix, raName, parentDescription), "entry")
	try:
	  specCount = int(j2cConfigInfo.get("%s.j2cActivationSpec.count" % prefix,"0"))
	  if (specCount > 0):
	    for idx in range(1,specCount+1):
	      specPrefix = "%s.j2cActivationSpec.%d" % (prefix,idx)
	      
	      specName = j2cConfigInfo.get("%s.name" % specPrefix)
	      if (isEmpty(specName)):
	        # partial list
	        continue
	      
	      existingId = findJ2CActivationSpec(resourceAdapterId,specName)
	      if (not isEmpty(existingId)):
	        existingProps = getJ2CActivationSpecProperties(existingId)
	        actSpecProps = getPropListDifferences(j2cConfigInfo,specPrefix,existingProps,"j2cActivationSpec")
	        resourceProps = getPropListDifferences(j2cConfigInfo,"%s.properties" % specPrefix,existingProps,"j2cActivationSpec.properties")
	        
	        if (len(actSpecProps) > 0 or len(resourceProps) > 0):
	          modifyJ2CActivationSpec(existingId,actSpecProps,resourceProps)
	          _app_message("Modified J2CActivationSpec %s under J2CResourceAdapter %s at %s" % (specName,raName,parentDescription))
	        else:
	          _app_message("No need to modify J2CActivationSpec %s under J2CResourceAdapter %s at %s" % (specName,raName,parentDescription))
	        
	      else:
	        # Needs to be created
	        actSpecProps = getPropList(j2cConfigInfo,specPrefix)
	        resourceProps = getPropList(j2cConfigInfo,"%s.properties" % specPrefix)
	        
	        messageListenerType = j2cConfigInfo.get("%s.messageListener.messageListenerType" % specPrefix)
	        jndiName = actSpecProps.get("jndiName")
	        
	        retval = createJ2CActivationSpec(resourceAdapterId,specName,jndiName,messageListenerType,actSpecProps,resourceProps)
	        
	        _app_message("Created J2CActivationSpec %s under J2CResourceAdapter %s at %s" % (specName, raName, parentDescription))
	  
	  
	except:
	  _app_exception("Unexpected error in processJ2CActivationSpec") 
	
	
	_app_trace("processJ2CActivationSpec()","exit")


#------------------------------------------------------------------------------
# processJ2CConnectionFactories
#
# This method loops through the settings in j2cConfigInfo for connection factories 
# defined for a specific J2CResourceAdapter
#
# Parameters:
#   resourceAdapterId - The configuration ID of the J2CResourceAdapter that the
#                       connection factories will be created under
#   prefix            - The prefix of the resource adapter.
#                       Example: app.appdeployment.1.deploymentObject.modules.1.resourceAdapter
#   raName            - The name of the resource adapter (for logging only)
#   parentDescription - A description of the RA's context for logging only 
#                      (e.g: applicaton name or resource scope)
#------------------------------------------------------------------------------
def processJ2CConnectionFactories(j2cConfigInfo,resourceAdapterId, prefix, raName, parentDescription):


	_app_trace("processJ2CConnectionFactories(%s,%s,%s,%s)" % (resourceAdapterId, prefix, raName, parentDescription), "entry")
	
	try:
		count = int(j2cConfigInfo.get("%s.cf.count" %prefix,"0"))
		for idx in range(1,count+1):
				cfName = j2cConfigInfo.get("%s.cf.%d.name" % (prefix,idx),"")
				if (isEmpty(cfName)):
						continue
				
				# See if it exists
				cf = findJ2CConnectionFactory(resourceAdapterId, cfName)
				if (not isEmpty(cf)):
						# Update
						existingProps = getJ2CConnectionFactoryProperties(cf)
						baseProps = getPropListDifferences(j2cConfigInfo,"%s.cf.%d" % (prefix,idx),existingProps,"cf")
						
						cpProps = getPropListDifferences(j2cConfigInfo,"%s.cf.%d.connectionPool" % (prefix,idx), existingProps,"cf.connectionPool")
						
						cpCustProps = getPropListDifferences(j2cConfigInfo,"%s.cf.%d.connectionPool.properties" % (prefix,idx), existingProps,"cf.connectionPool.properties")
						
						preTestProps = getPropListDifferences(j2cConfigInfo,"%s.cf.%d.preTestConfig" % (prefix,idx), existingProps,"cf.preTestConfig")
						
						mapProps = getPropListDifferences(j2cConfigInfo,"%s.cf.%d.mapping" % (prefix,idx), existingProps,"cf.mapping")
						
						resourceProps = getPropListDifferences(j2cConfigInfo,"%s.cf.%d.propertySet.resourceProperties" % (prefix,idx), existingProps,"cf.propertySet.resourceProperties")
						
						connectionFactoryInterface = j2cConfigInfo.get("%s.cf.%d.connectionDefinition.prop.connectionFactoryInterface" % (prefix,idx),"")
						existingFactoryInterface = existingProps.get("cf.connectionDefinition.prop.connectionFactoryInterface")
						if (connectionFactoryInterface == existingFactoryInterface):
								connectionFactoryInterface = None
						
						if (baseProps.size() > 0 or cpProps.size() > 0 or cpCustProps.size() > 0 or preTestProps.size() > 0 or mapProps.size() > 0 or resourceProps.size() > 0 or (not isEmpty(connectionFactoryInterface))):
								retval = modifyJ2CConnectionFactory(cf, resourceAdapterId, connectionFactoryInterface, baseProps, cpProps, cpCustProps, preTestProps, mapProps, resourceProps)
								if (isEmpty(retval)):
										_app_message("Error modifying J2CConnectionFactory %s for %s %s" % (cfName, raName, parentDescription))
										exit()
								else:
										_app_message("Updated J2CConnectionFactory %s for %s %s" % (cfName, raName, parentDescription))
						else:
								_app_message("No need to update J2CConnectionFactory %s for %s %s" % (cfName, raName, parentDescription))
						
				else:
						# Create
						baseProps = getPropList(j2cConfigInfo,"%s.cf.%d" % (prefix,idx))
						
						cpProps = getPropList(j2cConfigInfo,"%s.cf.%d.connectionPool" % (prefix,idx))
						
						cpCustProps = getPropList(j2cConfigInfo,"%s.cf.%d.connectionPool.properties" % (prefix,idx))
						
						
						preTestProps = getPropList(j2cConfigInfo,"%s.cf.%d.preTestConfig" % (prefix,idx))
						
						mapProps = getPropList(j2cConfigInfo,"%s.cf.%d.mapping" % (prefix,idx))
						
						resourceProps = getPropList(j2cConfigInfo,"%s.cf.%d.propertySet.resourceProperties" % (prefix,idx))
						
						connectionFactoryInterface = j2cConfigInfo.get("%s.cf.%d.connectionDefinition.prop.connectionFactoryInterface" % (prefix,idx),"")
						
						retval = createJ2CConnectionFactory(resourceAdapterId, cfName, connectionFactoryInterface, baseProps, cpProps, cpCustProps, preTestProps, mapProps, resourceProps)
						
						if (not isEmpty(retval)):
								_app_message("Created J2CConnectionFactory %s for resource adapter %s %s"  % (cfName, raName, parentDescription))
						else:
								_app_message("Error trying to create J2CConnectionFactory %s for resource adapter %s %s"  % (cfName, raName, parentDescription))
								exit()
	except:
		_app_trace("Unexpected error processing J2CConnectionFactory settings","exception")
		_app_message("Unexpected error processing J2CConnectionFactory settings")
		exit()
	
	
	_app_trace("processJ2CConnectionFactories()","exit")
	
#--------------------------------------------------------------------------------
# processSingleJ2CResourceAdapter
#--------------------------------------------------------------------------------
def processSingleJ2CResourceAdapter(j2cConfigInfo,prefix):
  _app_trace("processSingleJ2CResourceAdapter(j2cConfigInfo,%s)"%prefix,"entry")
  try:
    raName = j2cConfigInfo.get("%s.name" % prefix)
    if (not isEmpty(raName)):
      # Get scope settings
      cluster = j2cConfigInfo.get("%s.cluster" % prefix)
      node = j2cConfigInfo.get("%s.node" % prefix)
      server = j2cConfigInfo.get("%s.server" % prefix)
      dynCluster = j2cConfigInfo.get("%s.dynamicCluster" % prefix)
      appDeployment = j2cConfigInfo.get("%s.deployment" % prefix)
      application = j2cConfigInfo.get("%s.application" % prefix)
      
      scopeInfo = scopeInfoString(cluster,node,server,dynamicCluster=dynCluster,appDeployment=appDeployment)
      
      # Try to find the resource adapter
      j2cId = getJ2CResourceAdapter(raName, cluster,node,server,dynCluster,appDeployment)
      if (isEmpty(j2cId)):
        # Fatal error - can't create without source code installation
        _app_message("Error: J2CResource Adapter %s not found at scope %s" % (raName,scopeInfo))
        exit()
      
      # See if any settings need to be applied to J2CResourceAdapter itself
      existingProps = getJ2CResourceAdapterProperties(j2cId)
      subProps = getPropListDifferences(j2cConfigInfo,prefix,existingProps,"resourceAdapter")
      resourceProps = getPropListDifferences(j2cConfigInfo,"%s.propertySet.resourceProperties" % prefix,existingProps,"resourceAdapter.propertySet.resourceProperties")
      if (len(subProps) > 0 or len(resourceProps) > 0):
        modifyJ2CResourceAdapter(j2cId,baseProperties=subProps,resourceProperties=resourceProps)
        if (len(subProps) > 0):
          _app_message("Updated base properties of resource adapter %s at scope=%s" % (raName,scopeInfo))
        if (len(resourceProps) > 0):
          _app_message("Updated resource properties of resource adapter %s at scope=%s" % (raName,scopeInfo))
      else:
        _app_message("No need to modify J2CResourceAdapter %s at scope %s" % (raName,scopeInfo))
          
      
      # Now we can process other configuration items
      processJ2CConnectionFactories(j2cConfigInfo,j2cId, prefix, raName, "Scope=%s" % scopeInfo)
      processJ2CActivationSpec(j2cConfigInfo,j2cId, prefix, raName, "Scope=%s" % scopeInfo)
      processJ2CAdminObjects(j2cConfigInfo,j2cId, prefix, raName, "Scope=%s" % scopeInfo)
      
      
  except:
    _app_exception("Uexpected error in processJ2CResourceAdapter")
    
  _app_trace("processSingleJ2CResourceAdapter(j2cConfigInfo,%s)","exit")

#-------------------------------------------------------------------------------
# processJ2CResourceAdapter
#-------------------------------------------------------------------------------
def processJ2CResourceAdapter(j2cConfigInfo):
  _app_trace("processJ2CResourceAdapter(j2cConfigInfo)","entry")
  try:
    j2cCount = int(j2cConfigInfo.get("app.j2c.count",0))
    if (j2cCount > 0):
      for idx in range(1,j2cCount+1):
        processSingleJ2CResourceAdapter(j2cConfigInfo,"app.j2c.%d" % idx)
  except:
    _app_exception("Unexpected error in processJ2CResourceAdapter")
     
  _app_trace("processJ2CResourceAdapter(j2cConfigInfo)","exit")  