###########################################################################################
# ProcessNameSpaceBindings.py
# 
# This module contains the methods that process the NameSpaceBinding configuration 
# properties that are in the global configInfo dictionary.
#
# Primary Function:  
#     processNameSpaceBindings()
#
# Related modules:
#     NameSpaceBinding.py
#     Utils.py
#     common.py
# 
# Syntax overview:  The properties for a NameSpaceBinding depends on the type 
# involved.  Below are examples of the 4 different types
#			
# Each NameSpaceBinding has scope attributes, a type, and properties
#
# # CORBAObjectNameSpaceBinding
# app.wasnsb.1.cluster = 
# app.wasnsb.1.node    = 
# app.wasnsb.1.server  = 
# 
# app.wasnsb.1.nsb.type = CORBAObjectNameSpaceBinding
# app.wasnsb.1.nsb.prop.name = CellCORBABinding1
# app.wasnsb.1.nsb.prop.corbanameUrl = corbaloc:iiop:jjm.net:1111
# app.wasnsb.1.nsb.prop.nameInNameSpace = nsb/CellCORBABinding1
# app.wasnsb.1.nsb.prop.federatedContext = true
#
# # StringNameSpaceBinding
# app.wasnsb.2.cluster = SampleCluster
# app.wasnsb.2.node    = 
# app.wasnsb.2.server  = 
# 
# app.wasnsb.2.nsb.type = StringNameSpaceBinding
# app.wasnsb.2.nsb.prop.name = ClusterBinding1
# app.wasnsb.2.nsb.prop.nameInNameSpace = env/com/ClusterBinding1
# app.wasnsb.2.nsb.prop.stringToBind = Hello again
#  
# # IndirectLookupNameSpaceBinding has optional context props
# app.wasnsb.3.cluster = SampleCluster
# app.wasnsb.3.node    = 
# app.wasnsb.3.server  = 
#
# app.wasnsb.3.nsb.type = IndirectLookupNameSpaceBinding
# app.wasnsb.3.nsb.prop.name = Indirect1
# app.wasnsb.3.nsb.prop.nameInNameSpace = env/indirect/Binding1
# app.wasnsb.3.nsb.prop.jndiName = env/jdbc
# app.wasnsb.3.nsb.prop.providerURL = jjm.net::1011
# app.wasnsb.3.nsb.prop.initialContextFactory = com.jjm.contextfactory
# app.wasnsb.3.nsb.otherCtxProperties.prop.Prop1 = Value1Description goes here
# 
# EjbNameSpaceBinding
# app.wasnsb.4.cluster = 
# app.wasnsb.4.node    = ConfigurationScriptingNode1
# app.wasnsb.4.server  = 
#  
# app.wasnsb.4.nsb.type = EjbNameSpaceBinding
# app.wasnsb.4.nsb.prop.name = NodeEJBBinding1
# app.wasnsb.4.nsb.prop.applicationServerName = SampleCluster
# app.wasnsb.4.nsb.prop.applicationNodeName = 
# app.wasnsb.4.nsb.prop.nameInNameSpace = ejb/myNodeBinding1
# app.wasnsb.4.nsb.prop.bindingLocation = SERVERCLUSTER
# app.wasnsb.4.nsb.prop.ejbJndiName = ejb/com/jjm/lockingjartest/ejb/LockingEJBHome
# 
# <End up with a count property>
# app.wasnsb.count = <total count of nsb definitions>
# 
###########################################################################################



#------------------------------------------------------------------------------------------
# processExistingNameSpaceBinding
# 
# Processes the settings for an existing name space binding.
#
# Parameters:
#      existingId - Configuration ID of NameSpaceBinding
#      bindingType - the bindingType
#      bindingName - the name of the NameSpaceBinding
#      prefix - the prefix of the properties (e.g. app.wasnsb.<index>)
#------------------------------------------------------------------------------------------
def processExistingNameSpaceBinding(existingId, bindingType, bindingName, prefix):

	global configInfo
  
	_app_trace("processExistingNameSpaceBinding(%s,%s,%s,%s)" % (existingId, bindingType, bindingName, prefix),"entry")
	retval = existingId
	try:
	
		existingProps = getNameSpaceBindingProperties(existingId)
		if (existingProps == None):
				_app_message("Unable to loading existing configuration for %s %s" % (bindingType, bindingName))
				exit()
				
		nsbProps = getPropListDifferences(configInfo, "%s.nsb" % (prefix), existingProps, "app.wasnsb.nsb")
		customProps = None
		if (bindingType == "IndirectLookupNameSpaceBinding"):
				customProps = getPropListDifferences(configInfo,"%s.nsb.otherCtxProperties" % prefix, existingProps, "app.wasnsb.nsb.otherCtxProperties")
				
		if (nsbProps.size() > 0 or (customProps != None and customProps.size() > 0)):
				# Need to do an update
				retval = updateNameSpaceBinding(existingId, nsbProps, bindingType, customProps)
				if (isEmpty(retval)):
						_app_message("Error updating %s %s" % (bindingType, bindingName))
						exit()
				else:
						_app_message("Updated %s %s" % (bindingType, bindingName))
		else:
				_app_message("No updates requred for %s %s" % (bindingType, bindingName))
		
		
		
		
	
	except:
		_app_trace("Unexpected error processing definition for existing NameSpaceBinding","exception")
		_app_message("Unexpected error processing definition for existing NameSpaceBinding")
		exit()
	
	_app_trace("processExistingNameSpaceBinding()","exit")
	return retval

#------------------------------------------------------------------------------------------
# processNewNameSpaceBinding
# 
# Processes the settings for an existing name space binding.
#
# Parameters:
#      scopeId - Configuration ID of scope object ( cell,node,cluster, or server)
#      scope - a string represent type of scope (for logging)
#      bindingType - the bindingType
#      bindingName - the name of the NameSpaceBinding
#      prefix - the prefix of the properties (e.g. app.wasnsb.<index>)
#------------------------------------------------------------------------------------------
def processNewNameSpaceBinding(scopeId, scope, bindingType, bindingName, prefix):

	global configInfo
	_app_trace("processNewNameSpaceBinding(%s,%s,%s,%s,%s)" % (scopeId, scope, bindingType, bindingName,  prefix),"entry")
	retval = None
	try:
		
		bindingProperties = getPropList(configInfo, "%s.nsb" % (prefix))
		customProps = None
		
		if (bindingType == "IndirectLookupNameSpaceBinding"):
				customProps = getPropList(configInfo,"%s.nsb.otherCtxProperties" % prefix)
		
		retval = createNameSpaceBinding(scopeId, bindingType, bindingName, bindingProperties, customProps)
		
		if isEmpty(retval):
			_app_message("Failed to create %s %s at %s scope" % (bindingType, bindingName, scope))
			exit()
		else:
			_app_message("Created %s %s at %s scope" % (bindingType, bindingName, scope))

	except:
		_app_trace("Unexpected error processing definition for new NameSpaceBinding","exception")
		_app_message("Unexpected error processing definition for new NameSpaceBinding")
		exit()
	
	_app_trace("processNewNameSpaceBinding(retval = %s)"%retval, "exit")
	return retval

#------------------------------------------------------------------------------------------
# processNameSpaceBindings
#
# Iterates through the NameSpaceBinding properties in the global configInfo dictionary
# and creates or updates the NameSpaceBinding configurations in the cell
#------------------------------------------------------------------------------------------
def processNameSpaceBindings():

	global configInfo
	
	try:
	
		configCount = int(configInfo.get("app.wasnsb.count","0"))
		if (configCount == 0):
				_app_message("Skipping NameSpaceBindings")
				return
	
		#	Create Name Space Bindings 
		for jpidx in range(1, configCount + 1):
			prefix = "app.wasnsb.%d" % (jpidx)
	
			pName = configInfo.get("%s.nsb.prop.name" % (prefix),"")
			if (isEmpty(pName)):
					# Most likely a partial list
					continue
			
			bindingType = configInfo.get("%s.nsb.type" % (prefix),"")
			
			pCluster = configInfo.get("%s.cluster" % prefix,"")
			pNode   = configInfo["%s.node" % (prefix)]
			pServer = configInfo["%s.server" % (prefix)]
			pName = configInfo["%s.nsb.prop.name" % (prefix)]
			
			# Lets see if the name space binding already exists
			existingId = checkForExistingNameSpaceBinding(pCluster, pNode, pServer, bindingType, pName)
			if (existingId == "ERROR"):
					_app_message("Error checking for existance of NameSpaceBinding %s" % pName)
					exit()
			
			if (not isEmpty(existingId)):
					processExistingNameSpaceBinding(existingId, bindingType, pName, prefix)
					continue
					
			if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
				pScope = "cell"
				cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
				for cell in cells:
					retval = processNewNameSpaceBinding(cell, pScope, bindingType, pName, prefix)
			
			else:
				if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer): 
					pScope = "cluster"
					cluster = AdminConfig.getid("/ServerCluster:%s" % pCluster)
					retval = processNewNameSpaceBinding(cluster, pScope, bindingType, pName, prefix)
				else:
					if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
						pScope = "node"
						node = AdminConfig.getid("/Node:%s" % pNode)
						retval = processNewNameSpaceBinding(node, pScope, bindingType, pName, prefix)
					else:
						if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
							pScope = "server"
							server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
							retval = processNewNameSpaceBinding(server, pScope, bindingType, pName, prefix)
	
	except:
			_app_trace("Unexpected error processing NameSpaceBindings","exception")
			_app_message("Unexpected error processing NameSpaceBindings")
			exit()
