##########################################################################
# File Name:    SIBJMSTopic.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere SIB JMS Topics
#
#               createSIBJMSTopic
#               deleteSIBJMSTopic
#               listSIBJMSTopics
#               listSIBJMSTopicMessages
#               deleteSIBJMSTopicMessages
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createSIBJMSTopic: Create a SIB JMS Topic
#
# SYNTAX:
#    createSIBJMSTopic name, (cluster|node, server), topicName, attrs
#
# PARAMETERS:
#    name  -  Name for SIB JMS Topic entry
#    cluster  -  Cluster to assign JMS Topic to
#    node  -  Node to assign JMS Topic to
#    server  -  Server to assign JMS Topic to
#    topicName  -  Name of underlying SIB topic
#    attrs  -  Hash map of attributes
#
# USAGE NOTES:
#    Creates a SIB JMS Topic at the desired scope.  
#
# RETURNS:
#    ObjID  Object ID of new appserver
#    None  Failure
#
# THROWS:
#    N/A
#
#$ ./wsadmin.bat -lang jython
#wsadmin>print AdminTask.help("createSIBJMSTopic")
#WASX8006I: Detailed help for command: createSIBJMSTopic
#
#Description: Create a SIB JMS topic at the scope identified by the target object.
#
#*Target object: Scope at which to create the SIB JMS topic.
#
#Arguments:
#  *name - The SIB JMS topic's name.
#  *jndiName - The SIB JMS topic's JNDI name.
#  description - A description of the SIB JMS topic.
#  topicSpace - The name of the underlying SIB topic space to which the topic points.
#  topicName - The topic to be used inside the topic space (for example, stock/IBM).
#  deliveryMode - The delivery mode for messages. Legal values are "Application", "NonPersistent" and "Persistent".
#  timeToLive - The time in milliseconds to be used for message expiration.
#  priority - The priority for messages. Whole number in the range 0 to 9.
#  readAhead - Read-ahead value. Legal values are "AsConnection", "AlwaysOn" and "AlwaysOff".
#  busName - The name of the bus on which the topic resides.
#
# Steps
#
##########################################################################
def createSIBJMSTopic(name, cluster, node, server, attrs):

  global progInfo

  retval = None
  
  # No difference betweenn V6.1,V7,V8,and V8.5
  dashParms = [  'jndiName', 'description', 'topicSpace', 'topicName', 'deliveryMode', 'timeToLive', 'priority', 'readAhead', 'busName' ]

  try:
    traceStr = "createSIBJMSTopic(%s, %s, %s, %s, %s)" % (name, cluster, node, server, attrs)
    _app_trace(traceStr, "entry")  

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to create SIB JMS Topic on" % (configID))
      
    if isEmpty(name):
      raise StandardError("SIB JMS Topic name, SIBus or SIB Topic name not specified")
      
    topicid = getSIBJMSTopicId(cluster,node,server,name)
    
    if (not isEmpty(topicid)):
      raise StandardError("SIB JMS Topic %s already exists at scope %s" % (name, configID))
      
    parentID  = AdminConfig.getid(configID)

    if isEmpty(parentID):
      raise StandardError("Cannot find ID; check cluster or node/server and SIB values are correct")

    _app_trace("Got parent ID = " + parentID)

     
    attributes = ""
    if (name.find(" ") > 0 and not name.startswith("'") and not name.startswith('"')):
      attributes = "-name '%s'" % (name)
    else:
      attributes  = " -name %s" % (name)    
    
    for key in attrs.keys():
        if key in dashParms:
            val = attrs.get(key)
            if (isEmpty(val)):
                continue
            if (key == "description"):
                if (not val.startswith('"')):
                    val = '"%s"' % val

            if (val.find(' ') >= 0):
              if (not val.startswith('"') and not val.startswith("'") ) :
                val = '"%s"' % val
        
            attributes = "%s -%s %s" % (attributes, key, val)

    #  Get the templates for SIBJMSTopic
    _app_trace("Running command: AdminTask.createSIBJMSTopic(%s, %s)" % (parentID, attributes))

    retval = AdminTask.createSIBJMSTopic(parentID, attributes)

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered creating the SIB JMS Topic", "exception")
    retval = None

  _app_trace("createSIBJMSTopic(%s)" %(retval), "exit")
  return retval

############################################################################################################
#wsadmin>print AdminTask.help("modifySIBJMSTopic")
#WASX8006I: Detailed help for command: modifySIBJMSTopic
#
#Description: Modify the attributes of the supplied SIB JMS topic using the supplied attribute values.
#
#*Target object: The SIB JMS topic to be modified.
#
#Arguments:
#  name - The SIB JMS topic's new name.
#  jndiName - The SIB JMS topic's new JNDI name.
#  description - The SIB JMS topic's new description.
#  topicSpace - The name of the underlying SIB topic space to which the topic points.
#  topicName - The topic to be used inside the topic space (for example, stock/IBM).
#  deliveryMode - The delivery mode for messages. Legal values are "Application", "NonPersistent" and "Persistent".
#  timeToLive - The time in milliseconds to be used for message expiration.
#  priority - The priority for messages. Whole number in the range 0 to 9.
#  readAhead - Read-ahead value. Legal values are "AsConnection", "AlwaysOn" and "AlwaysOff".
#  busName - The name of the bus on which the topic resides.
#
#Steps:
#  None
############################################################################################################
def modifySIBJMSTopic(name, cluster, node, server,attrs):

  global progInfo

  retval = None
  
  dashParms = [  'jndiName', 'description', 'topicSpace', 'topicName', 'deliveryMode', 'timeToLive', 'priority', 'readAhead', 'busName' ]

  try:
    traceStr = "modifySIBJMSTopic(%s, %s, %s, %s, %s)" % (name, cluster, node, server, attrs)
    _app_trace(traceStr, "entry")  

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to modify SIB JMS Topic on" % (configID))


    topicid = getSIBJMSTopicId(cluster,node,server,name)
    
    if (isEmpty(topicid)):
        raise StandardError("Unable to find SIBJMSTopic %s at scope %s %s %s" % (name,cluster,node,server))

    attributes = ""
    
    for key in attrs.keys():
        if key in dashParms:
            val = attrs.get(key)
            if (isEmpty(val)):
                continue
            if (key == "description"):
                if (not val.startswith('"')):
                    val = '"%s"' % val

            if (val.find(' ') >= 0):
              if (not val.startswith('"') and not val.startswith("'") ) :
                val = '"%s"' % val

        
            attributes = "%s -%s %s" % (attributes, key, val)

    #  Get the templates for SIBJMSTopic
    _app_trace("Running command: AdminTask.modifySIBJMSTopic(%s, %s)" % (topicid, attributes))

    AdminTask.modifySIBJMSTopic(topicid, attributes)
    
    retval = topicid

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered modifying the SIB JMS Topic", "exception")
    retval = None

  _app_trace("modifySIBJMSTopic(%s)" %(retval), "exit")
  return retval


##########################################################################
#
# FUNCTION:
#    deleteSIBJMSTopic: Delete a SIB JMS Topic
#
# SYNTAX:
#    deleteSIBJMSTopic name, cluster|(node, server)
#
# PARAMETERS:
#    name  -  Name for SIB JMS Topic entry
#    cluster  -  Name of cluster for cluster scoped topic
#    node  -  Name of node for server scoped topic
#    server  -  Name of server for server scoped topic
#
# USAGE NOTES:
#    Deletes a SIB JMS Topic from the desired scope.  
#    
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBJMSTopic(name, cluster, node, server):
  deleteSIBJMSTopic(name, cluster, node, server)
  
def deleteSIBJMSTopic(name, cluster, node, server):

  global progInfo

  retval = 1

  try:
    traceStr = "deleteSIBJMSTopic(%s, %s, %s, %s)" % (name, cluster, node, server)
    _app_trace(traceStr, "entry")  

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to delete SIB JMS Topic from" % (configID))
      
    if isEmpty(name):
      raise StandardError("SIB JMS Topic name not specified")
      
    if not existsSIBJMSTopic(name, cluster, node, server):
      raise StandardError("SIB JMS Topic %s does not exist at scope %s" % (name, configID))
      
    parentID = AdminConfig.getid(configID)
    idList  = AdminTask.listSIBJMSTopics(parentID)

    if isEmpty(idList):
      raise StandardError("Cannot find ID; check SIB topic name, cluster and node/server values are correct")
      
    qList = idList.split(progInfo["line.separator"])

    _app_trace("Got SIB JMS Topics = %s" % (qList))

    #  Delete ALL SIB JMS Topics with the same name (hmmmm!) at this scope
    for q in qList:
      nameAttr = AdminConfig.showAttribute(q, 'name')

      if nameAttr == name:
        _app_trace("Running command: AdminTask.deleteSIBJMSTopic(%s)" % (q))
        AdminTask.deleteSIBJMSTopic(q)

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()
      
    retval = 0
  except:
    _app_trace("An error was encountered deleting the SIB JMS Topic", "exception")
    retval = 1

  _app_trace("deleteSIBJMSTopic(%d)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    listSIBJMSTopics: List SIB JMS Topics at scope
#
# SYNTAX:
#    listSIBJMSTopics cluster| (node, server), displayFlag
#
# PARAMETERS:
#    cluster  -  Name of cluster for cluster scoped topic
#    node  -  Name of node for server scoped topic
#    server  -  Name of server for server scoped topic
#    displayFlag-  Boolean indicating whether to print list 
#      (default = 1)
#
# USAGE NOTES:
#    Lists SIB JMS Topics at the desired scope.  
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showSIBJMSTopics(cluster, node, server, displayFlag = 1):
  listSIBJMSTopics(cluster, node, server, displayFlag)
  
def listSIBJMSTopics(cluster, node, server, displayFlag = 1):

  global progInfo
  
  retval = None
  
  try:
    traceStr = "listSIBJMSTopics(%s, %s, %s, %d)" % (cluster, node, server, displayFlag)
    _app_trace(traceStr, "entry")  

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)

    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to list SIB JMS Topics at" % (configID))
      
    #  Get the parentID
    parentID = AdminConfig.getid(configID)

    _app_trace("Running command: AdminTask.listSIBJMSTopics(%s)" % (parentID))
    str = AdminTask.listSIBJMSTopics(parentID)

    if isEmpty(str):
      retval = []
    else:
      retval = str.split(progInfo["line.separator"])

    if displayFlag:
      print "\nSI Bus JMS Topics\n-------------------"

      for r in retval:
        print AdminConfig.showAttribute(r, "name")

      print "-------------------"
  except:
    _app_trace("An error was encountered listing the SIB JMS Topics", "exception")
    retval = None

  _app_trace("listSIBJMSTopics(%s)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    listSIBJMSTopicMessages: List SIB JMS Topic Messages
#
# SYNTAX:
#    listSIBJMSTopicMessages engine, topic
#
# PARAMETERS:
#    engine  -  Messaging engine name
#    topic  -  Optional topic name, if None then all topics 
#    -  will be displayed
#
# USAGE NOTES:
#    Lists SIB JMS Topic Messages
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def showSIBJMSTopicMessages(engine, topic = None):
  listSIBJMSTopicMessages(engine, topic)
  
def listSIBJMSTopicMessages(engine, topic = None):

  global progInfo

  retval = 1

  try:
    traceStr = "listSIBJMSTopicMessages(%s, %s)" % (engine, topic)
    _app_trace(traceStr, "entry")
    
    #  Check args
    if isEmpty(engine):
      raise StandardError("SIB Messaging Engine name not specified")
      
    if not objectExists("SIBMessagingEngine", None, engine):
      raise StandardError("Messaging engine %s does not exist" % (engine))

    #  Build AdminControl object name
    configID = AdminConfig.getid("/SIBMessagingEngine:%s/" % (engine))
    localizationPointsStr = AdminConfig.showAttribute(configID, "localizationPoints")

    if isEmpty(localizationPointsStr):
      raise StandardError("No topics found on messaging engine %s" % (engine))

    _app_trace("ConfigID = %s | localTopics = %s" % (configID, localizationPointsStr))

    length = len(localizationPointsStr) - 1
    localizationPointsList = localizationPointsStr[1:length].split(" ")

    print "\n\n%-60.60s\t%-6.6s" % ("Topic Name", "Depth")
    print "------------------------------------------------------------\t------"

    for localizationPoint in localizationPointsList:

      name = AdminConfig.showAttribute(localizationPoint, "identifier")

      #  Topic name  = name[0:first occ of @]
      idx = name.find("@")

      if idx == -1:
        _app_trace("Topic name format looks wrong (%s), expected name@engine" % (name))
        continue

      qname = name[0:idx]

      if topic is not None and qname != topic:
        continue

      MBeanName = "WebSphere:name=%s,type=SIBTopicPoint,SIBMessagingEngine=%s,*" % (qname, engine)
      MBeanObj  = AdminControl.completeObjectName(MBeanName)

      if isEmpty(MBeanObj):
        raise StandardError("Cannot get MBean information - is the Messaging Engine running?")

      print "\n%-60.60s\t%6d" % (qname, int(AdminControl.getAttribute(MBeanObj, "depth")))
      
    retval = 0

  except:
    _app_trace("An error was encountered listing the SIB JMS Topic Messages", "exception")
    retval = 1

  _app_trace("listSIBJMSTopicMessages(%d)" % (retval), "exit")
  return retval


##########################################################################
#
# FUNCTION:
#    deleteSIBJMSTopicMessages: Delete SIB JMS Topic Messages
#
# SYNTAX:
#    deleteSIBJMSTopicMessages engine, topic
#
# PARAMETERS:
#    engine  -  Messaging engine name
#    username  -  Username (required to access MBean)
#    password  -  Password (required to access MBean)
#    topic  -  Optional topic name, if None then all messages
#    -  on all topics will be deleted.  USE WITH CAUTION
#
# USAGE NOTES:
#    Deletes all SIB JMS Messages on either a given topic, or all topics
#    if no topic specified
#
# RETURNS:
#    0  -  Success
#    1  -  Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBJMSTopicMessages(engine, username, password, topic = None):
  deleteSIBJMSTopicMessages(engine, username, password, topic)
  
def deleteSIBJMSTopicMessages(engine, username, password, topic = None):

  from jarray import array, zeros
  import java
  import javax
  import com

  global progInfo

  retval = 1

  try:
    traceStr = "deleteSIBJMSTopicMessages(%s, %s, %s, %s)" % (engine, username, "*****", topic)
    _app_trace(traceStr, "entry")
    
    #  Check args
    if isEmpty(engine):
      raise StandardError("SIB Messaging Engine name not specified")

    if isEmpty(username) or isEmpty(password):
      raise StandardError("Username / password not specified ")
      
    if not objectExists("SIBMessagingEngine", None, engine):
      raise StandardError("Messaging engine %s does not exist" % (engine))
      
    #  Build AdminControl object name
    configID = AdminConfig.getid("/SIBMessagingEngine:%s/" % (engine))
    localizationPointsStr = AdminConfig.showAttribute(configID, "localizationPoints")

    if isEmpty(localizationPointsStr):
      raise StandardError("No topics found on messaging engine %s" % (engine))

    _app_trace("ConfigID = %s | localTopics = %s" % (configID, localizationPointsStr))

    length = len(localizationPointsStr) - 1
    localizationPointsList = localizationPointsStr[1:length].split(" ")

    for localizationPoint in localizationPointsList:

      name = AdminConfig.showAttribute(localizationPoint, "identifier")

      #  Topic name  = name[0:first occ of @]
      idx = name.find("@")

      if idx == -1:
        _app_trace("Topic name format looks wrong (%s), expected name@engine" \
          % (name))
        continue

      qname = name[0:idx]

      _app_trace("Found topic name = %s" % (qname))

      if not isEmpty(topic) and qname != topic:
        continue

      #  AdminControl.invoke() will always return a String.  This is useless
      #  if the return is not a String  e.g. getTopicdMessages() which returns
      #  an array of com.ibm.ws.sib.admin.impl.SIBTopicdMessageImpl
      #  which we need to traverse to get the message ID to then be 
      #  able to delete it!
      #  
      #  Use the Java API instead
      MBeanName = "WebSphere:name=%s,type=SIBTopicPoint,SIBMessagingEngine=%s,*" \
        % (qname, engine)
      MBeanObj  = AdminControl.completeObjectName(MBeanName)
      objectName = javax.management.ObjectName(MBeanObj)

      _app_trace("MBeanName = %s | MBeanObj = %s | objectName = %s" \
        % (MBeanName, MBeanObj, objectName))

      #  Set AdminClient properties - not sure why as we are already connected?
      props = java.util.Properties()
      props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_HOST, \
        AdminControl.getHost())
      props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_PORT, \
        AdminControl.getPort())
      props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_TYPE, \
        com.ibm.websphere.management.AdminClient.CONNECTOR_TYPE_SOAP)
      props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_SECURITY_ENABLED, "true")
      props.setProperty(com.ibm.websphere.management.AdminClient.USERNAME, username) 
      props.setProperty(com.ibm.websphere.management.AdminClient.PASSWORD, password) 

      #  Get an AdminClient to connect to server JMX
      service = com.ibm.websphere.management.AdminClientFactory.createAdminClient(props)

      if isEmpty(service):
        raise StandardError("Unable to get an AdminClient object")

      #  Get topicd messages
      topicdMessages = service.invoke(objectName, 'getTopicdMessages', None, None)

      #  Set flag to not move messages to exception topic instead of discard
      bool = java.lang.Boolean("false")

      #  Loop through each one
      for m in topicdMessages:
        id = m.getId()
        param = array((id, bool), java.lang.Object)
        sign  = array(("java.lang.String", "java.lang.Boolean"), \
          java.lang.String)

        _app_trace("Deleting message %s" % (id))
        service.invoke(objectName, "deleteTopicdMessage", param, sign)
        
    retval = 0
  except:
    _app_trace("An error was encountered listing the SIB JMS Topic Messages", "exception")
    retval = 1

  _app_trace("deleteSIBJMSTopicMessages(%d)" % (retval), "exit")
  return retval
  
#--------------------------------------------------------------------------------------------
# getSIBJMSTopicId
#
# Search for the topic with the specified scope and name. If it exists, return the id
#--------------------------------------------------------------------------------------------
def getSIBJMSTopicId(cluster,node,server,jmsTopicName):

  result = ""
  
  try:
  
    _app_trace("getSIBJMSTopicId(%s,%s,%s,%s)" % (cluster,node,server,jmsTopicName), "entry")
    
    shortName = jmsTopicName
    if (jmsTopicName.startswith("'") or jmsTopicName.startswith('"')):
      shortName = jmsTopicName[1:-1]

    # See if the topic exists
    qlist = []
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        
        qlist = AdminTask.listSIBJMSTopics(scopeId).split(progInfo["line.separator"])
        
        for topic in qlist:
            if (not isEmpty(topic)):
                name = AdminConfig.showAttribute(topic,"name")
                if (name == jmsTopicName):
                    result = topic
                    break
                elif (shortName != jmsTopicName and name == shortName):
                  result = topic
                  break
  except:
    _app_trace("Unexpected error getting SIBJMSTopic ID","exception")
    result = None

  _app_trace("getSIBJMSTopicId(%s)" % (result),"exit")
  return result

#--------------------------------------------------------------------------------------------
# findMatchingSIBJMSTopics
#
# Search for the topics with the specified scope and name pattern. Returns matching topics in
# a dictionary where jmstopicname = id
# 
#--------------------------------------------------------------------------------------------
def findMatchingSIBJMSTopics(cluster,node,server,namePattern):

  retval = {}
  
  import re
  
  try:
    _app_trace("findMatchingSIBJMSTopics(%s,%s,%s,%s)" % (cluster,node,server,namePattern), "entry")

    # See if the topic exists
    tlist = []
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        tlist = AdminTask.listSIBJMSTopics(scopeId).split(progInfo["line.separator"])
        
        for topic in tlist:
            if (not isEmpty(topic)):
                tempName = AdminConfig.showAttribute(topic,"name")
                if (namePattern.find("*") >= 0):
                  # Regular express
                  if (re.match(namePattern,tempName)):
                      # Add ID to result list
                      retval[tempName] = topic
                else:
                  if (namePattern == tempName):
                      retval[tempName] = topic

  except:
    _app_trace("Unexpected error in findMatchingSIBJMSTopics","exception")
    raise StandardError("Unexpected error in findMatchingSIBJMSTopics")

  _app_trace("findMatchingSIBJMSTopics(%s)" % (retval),"exit")
  return retval


#--------------------------------------------------------------------------------------------
# getSIBJMSTopicProperties
#
# Search for the topic with the specified scope and name. If it exists, gather properties and
# store in property set with "topic.prop.key = val" naming format.
#
# Return empty Properties set if no match found.
# Return None if error occurs
#--------------------------------------------------------------------------------------------
def getSIBJMSTopicProperties(cluster,node,server,jmsTopicName,jmsTopicId=None,checkSettingsOverride=0):

  result = java.util.Properties()
  
  try:
  
    _app_trace("getSIBJMSTopicProperties(%s,%s,%s,%s)" % (cluster,node,server,jmsTopicName), "entry")

    # See if the topic exists
    tlist = []
    
    if (isEmpty(jmsTopicId)):
      if (jmsTopicName.startswith("'") or jmsTopicName.startswith('"')):
        jmsTopicName = jmsTopicName[1:-1]
      scopeId = getScopeId(cluster,node,server)
      if (not isEmpty(scopeId)):
          tlist = AdminTask.listSIBJMSTopics(scopeId).split(progInfo["line.separator"])
          
          for topic in tlist:
              if (not isEmpty(topic)):
                  
                  # ID should contain the name
                  
                  if (topic.find(jmsTopicName) < 0):
                    continue
                  
                  # Verify, to be sure
                  name = AdminConfig.showAttribute(topic,"name")
                  if (name == jmsTopicName):
                    jmsTopicId = topic
                    break
      
      
    if (not isEmpty(jmsTopicId)):
      topic = jmsTopicId
      result.put("topic.name", name)
      
      if (checkSettingsOverride or isCheckSettingsEnabled("sibjms")):
      
        # Note: turns oout that showSIBJMSTopic is very very slow
        # and it is much quicker to pull attributes and custom properties directly 
        # from the J2CAdminObject
        #
        # The only drawback from this approach is that the attribute names may 
        # have an uppercase starting character, which doesn't map to AdminTask.updateSIBJMSTopic
        # After collecting the properties, we'll need to transform the keys
        
        collectSimpleProperties(result, "topic.prop",topic)
        collectCustomProperties(result,"topic", topic, "properties")
      
        tempKeys = []
        for key in result.keys():
          tempKeys.append(key)
        
        for key in tempKeys:
          propName = key.split(".")[-1]
          replaceName = "%s%s" % (propName[0].lower(), propName[1:])
          replaceKey = "topic.prop.%s" % replaceName
          val = result.get(key)
          result.put(replaceKey,val)
                        
  except:
    _app_trace("Unexpected error getting SIBJMSTopic properties","exception")
    result = None

  _app_trace("getSIBJMSTopicProperties(%s)" % (result),"exit")
  return result
    