################################################################################
#
# ProcessWorkClass.py
#
#    Processes input properties that define Routing and Service 
#    WorkClass properties. Supports WebSphere JEE and BLA applications,
#    but see notes below about BLA limitations.
#
# Entry point function: processWorkClass()
#
# Requires: WorkClass.py, Utils.py, common.py
#
# 
# -- Routing WorkClass Example --
# Routing workclasses are defined separately from application editions.
#
# appendWorkClassModule and appendMatchRules are special meta properties
# that changes the processing logic if the WorkClass exists. 
#
# The default behavior is to replace the existing WorkClassModule and MatchRule
# definitions with the input properties. If the append property is set to 
# true, the input properties will be merged.
#
# app.im.workclass.application.1.name = IntelligentManagementApp
#
# app.im.workclass.application.1.routing.3.name = NewRoutingWorkClass
# app.im.workclass.application.1.routing.3.prop.matchAction = permit:IntelligentManagementApp-edition2.0
# app.im.workclass.application.1.routing.3.prop.type = HTTPWORKCLASS
# app.im.workclass.application.1.routing.3.appendWorkClassModules=false
# app.im.workclass.application.1.routing.3.workClassModules.1.prop.id = NewRoutingWorkClass:!:IntelligentManagementApp-edition1.0:!:WebModuleOne.war
# app.im.workclass.application.1.routing.3.workClassModules.1.prop.matchExpression = /ServletOne
# app.im.workclass.application.1.routing.3.workClassModules.1.prop.moduleName = WebModuleOne.war

# app.im.workclass.application.1.routing.3.workClassModules.count = 1
# app.im.workclass.application.1.routing.3.appendMatchRules=true
# app.im.workclass.application.1.routing.3.matchRules.1.prop.matchAction = permit:IntelligentManagementApp-edition1.0
# app.im.workclass.application.1.routing.3.matchRules.1.prop.matchExpression = header$CLIENT_TYPE = 'SOME_OLD_APP_USER'
# app.im.workclass.application.1.routing.3.matchRules.1.prop.priority = 6
# app.im.workclass.application.1.routing.3.matchRules.2.prop.matchAction = permit:IntelligentManagementApp-edition1.0
# app.im.workclass.application.1.routing.3.matchRules.2.prop.matchExpression = header$CLIENT_TYPE = 'NOT_KIDDING_THIS_IS_SOME_REALLY_OLD_APP_USER'
# app.im.workclass.application.1.routing.3.matchRules.2.prop.priority = 11
# app.im.workclass.application.1.routing.3.matchRules.count = 2
#
# --- Service Workclass Example --
#
# The property syntax for a Service WorkClass can vary depending on
# the use of application editions. If the application has editions defined,
# service workclasses are defined at the edition level. If not, they are
# defined at the application level. Examples of both are shown below.
#
# app.im.workclass.application.1.name = IntelligentManagementApp
# #Service Policy work classes for application edition IntelligentManagementApp-edition1.0
# app.im.workclass.application.1.edition.1.name = IntelligentManagementApp-edition1.0
# 
# app.im.workclass.application.1.edition.1.service.1.name = Default_HTTP_WC
# app.im.workclass.application.1.edition.1.service.1.prop.matchAction = Default_TC
# app.im.workclass.application.1.edition.1.service.1.prop.type = HTTPWORKCLASS
# app.im.workclass.application.1.edition.1.service.1.workClassModules.1.prop.id = Default_HTTP_WC:!:IntelligentManagementApp:!:WebModuleTwo.war
# app.im.workclass.application.1.edition.1.service.1.workClassModules.1.prop.matchExpression = *
# app.im.workclass.application.1.edition.1.service.1.workClassModules.1.prop.moduleName = WebModuleTwo.war
# app.im.workclass.application.1.edition.1.service.1.workClassModules.2.prop.id = Default_HTTP_WC:!:IntelligentManagementApp:!:WebModuleOne.war
# app.im.workclass.application.1.edition.1.service.1.workClassModules.2.prop.matchExpression = *
# app.im.workclass.application.1.edition.1.service.1.workClassModules.2.prop.moduleName = WebModuleOne.war
# app.im.workclass.application.1.edition.1.service.1.workClassModules.3.prop.id = Default_HTTP_WC:!:IntelligentManagementApp:!:EJBModuleTwo_HTTPRouter.war
# app.im.workclass.application.1.edition.1.service.1.workClassModules.3.prop.matchExpression = *
# app.im.workclass.application.1.edition.1.service.1.workClassModules.3.prop.moduleName = EJBModuleTwo_HTTPRouter.war
# app.im.workclass.application.1.edition.1.service.1.workClassModules.count = 3
#
#
# 
# app.im.workclass.application.2.name = SecureEAR
# #Service Policy work classes for application SecureEAR
# app.im.workclass.application.2.service.1.name = Default_HTTP_WC
# app.im.workclass.application.2.service.1.prop.matchAction = Default_TC
# app.im.workclass.application.2.service.1.prop.type = HTTPWORKCLASS
# app.im.workclass.application.2.service.1.workClassModules.1.prop.id = Default_HTTP_WC:!:SecureEAR:!:SecureWeb.war
# app.im.workclass.application.2.service.1.workClassModules.1.prop.matchExpression = *
# app.im.workclass.application.2.service.1.workClassModules.1.prop.moduleName = SecureWeb.war
# app.im.workclass.application.2.service.1.workClassModules.count = 1
#
# -- Business Level Application (OSGi) example --
# OSGi applications defined as BLAs can also have WorkClasses defined for their
# eba composition units. Examples are shown below.
#
# LIMITATIONS: Only the default Service workclass can be created for a BLA 
# in the admin console and no Routing work classes can be created with a wsadmin
# script. Existing work classes can be modified, including add modules and
# match rules, so that should be preferred manner in setting up the rules
# for the application.
#
#
# WorkClass configurations in BLA (OSGi) applications
#
# app.im.workclass.blas.1.name = WebSphere:blaname=Blog
# app.im.workclass.blas.1.compUnit.1.name = com.ibm.samples.websphere.osgi.blog_0001.eba

# Routing workclasses for com.ibm.samples.websphere.osgi.blog_0001.eba
# app.im.workclass.blas.1.compUnit.1.routing.1.name = Default_HTTP_WC
# app.im.workclass.blas.1.compUnit.1.routing.1.prop.matchAction = permit:com.ibm.samples.websphere.osgi.blog_0001.eba
# app.im.workclass.blas.1.compUnit.1.routing.1.prop.type = HTTPWORKCLASS
# app.im.workclass.blas.1.compUnit.1.routing.1.workClassModules.1.prop.id = Default_HTTP_WC:!:com.ibm.samples.websphere.osgi.blog_0001.eba:!:com.ibm.samples.websphere.osgi.blog.web_1.0.0
# app.im.workclass.blas.1.compUnit.1.routing.1.workClassModules.1.prop.matchExpression = *
# app.im.workclass.blas.1.compUnit.1.routing.1.workClassModules.1.prop.moduleName = com.ibm.samples.websphere.osgi.blog.web_1.0.0
# app.im.workclass.blas.1.compUnit.1.routing.1.workClassModules.count = 1
# app.im.workclass.blas.1.compUnit.1.routing.2.name = AnotherNewOSGIAppRoutingClass
# app.im.workclass.blas.1.compUnit.1.routing.2.prop.matchAction = permit:com.ibm.samples.websphere.osgi.blog_0001.eba
# app.im.workclass.blas.1.compUnit.1.routing.2.prop.type = HTTPWORKCLASS
# app.im.workclass.blas.1.compUnit.1.routing.2.workClassModules.1.prop.id = NewOSGIAppRoutingClass:!:com.ibm.samples.websphere.osgi.blog_0001.eba:!:com.ibm.samples.websphere.osgi.blog.web..1.0.0.war
# app.im.workclass.blas.1.compUnit.1.routing.2.workClassModules.1.prop.matchExpression = /MyServlet2/*
# app.im.workclass.blas.1.compUnit.1.routing.2.workClassModules.1.prop.moduleName = com.ibm.samples.websphere.osgi.blog.web..1.0.0.war
# app.im.workclass.blas.1.compUnit.1.routing.2.workClassModules.count = 1
# app.im.workclass.blas.1.compUnit.1.routing.2.matchRules.1.prop.matchAction = permit:com.ibm.samples.websphere.osgi.blog_0001.eba
# app.im.workclass.blas.1.compUnit.1.routing.2.matchRules.1.prop.matchExpression = virtualport = 80
# app.im.workclass.blas.1.compUnit.1.routing.2.matchRules.1.prop.priority = 0
# app.im.workclass.blas.1.compUnit.1.routing.2.matchRules.count = 1
# app.im.workclass.blas.1.compUnit.1.routing.count = 2
#
# Service workclasses for com.ibm.samples.websphere.osgi.blog_0001.eba
# app.im.workclass.blas.1.compUnit.1.service.1.name = Default_HTTP_WC
# app.im.workclass.blas.1.compUnit.1.service.1.prop.matchAction = Default_TC
# app.im.workclass.blas.1.compUnit.1.service.1.prop.type = HTTPWORKCLASS
# app.im.workclass.blas.1.compUnit.1.service.1.workClassModules.1.prop.id = Default_HTTP_WC:!:com.ibm.samples.websphere.osgi.blog_0001.eba:!:com.ibm.samples.websphere.osgi.blog.web_1.0.0
# app.im.workclass.blas.1.compUnit.1.service.1.workClassModules.1.prop.matchExpression = *
# app.im.workclass.blas.1.compUnit.1.service.1.workClassModules.1.prop.moduleName = com.ibm.samples.websphere.osgi.blog.web_1.0.0
# app.im.workclass.blas.1.compUnit.1.service.1.workClassModules.count = 1
# app.im.workclass.blas.1.compUnit.1.service.count = 1
#
# app.im.workclass.blas.1.compUnit.count = 1 
# app.im.workclass.blas.count = 1
################################################################################



#-------------------------------------------------------------------------------
# getRoutingUpdateProps
#
# Parameters
#
# 
# Returns a tuple with 
#    (wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules)
#-------------------------------------------------------------------------------
def getRoutingUpdateProps(wcConfigInfo,prefix,wcId):
  _app_entry("getRoutingUpdateProps(wcConfigInfo,%s,%s)" , prefix,wcId)
  retval = ()
  try:
      existingProps = {}
      if (not isEmpty(wcId)):
        existingProps  = getWorkClassProperties(wcId)
      
      # See what needs updating
      wcProps = getPropListDifferences(wcConfigInfo,prefix,existingProps,"workclass")
      
      inputMatchRuleList = getDictionaryList(wcConfigInfo,"%s.matchRules"%prefix)
      inputModuleList = getDictionaryList(wcConfigInfo,"%s.workClassModules" % prefix)
      
      appendMatchRules = (wcConfigInfo.get("%s.appendMatchRules"%prefix,"false").lower() == "true")
      appendWorkClassModules = (wcConfigInfo.get("%s.appendWorkClassModules"%prefix,"false").lower() == "true")
      
      existingMatchRuleList = getDictionaryList(existingProps,"workclass.matchRules")
      existingModuleList = getDictionaryList(existingProps,"workclass.workClassModules")
      
      
      if (inputMatchRuleList == existingMatchRuleList):
        inputMatchRuleList = None
      else:
        if (appendMatchRules):
          tempList = []
          for rule in inputMatchRuleList:
            if rule not in existingMatchRuleList:
              tempList.append(rule)
          
          if (len(tempList) > 0):
            inputMatchRuleList = tempList
          else:
            inputMatchRuleList = None
      
      if (inputModuleList == existingModuleList):
        # No updates necessary
        inputModuleList = None
      else:
        print "%s\n%s" % (inputModuleList,existingModuleList)
        if (appendWorkClassModules):
          tempList = []
          for module in inputModuleList:
            if module not in existingModuleList:
              tempList.append(module)
          
          if (len(tempList) > 0):
            inputModuleList = tempList
          else:
            inputModuleList = None
            
           
      retval = (wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules)
         
  except:
    _app_exception("Unexpected problem in getRoutingUpdateProps()")
  
  _app_exit("getRoutingUpdateProps(retval=%s)" % str(retval))
  return retval

#-------------------------------------------------------------------------------
# processApplicationRoutingWorkClass
#
# Parameters
#
#-------------------------------------------------------------------------------
def processApplicationRoutingWorkClass(wcConfigInfo,prefix,appName,wcName):
  _app_entry("processApplicationRoutingWorkClass(wcConfigInfo,%s,%s,%s)" ,prefix,appName,wcName)
  
  try:
    # See if the Work Class is defined
    wcId = findApplicationRoutingWorkClass(appName,wcName)
    if (not isEmpty(wcId)):
      #_app_message("Application %s Routing WorkClass %s is already defined" % (appName,wcName))
      existingProps  = getWorkClassProperties(wcId)
      
      # See what needs updating
      wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules =  getRoutingUpdateProps(wcConfigInfo,prefix,wcId)
            
      if (len(wcProps) == 0 and inputModuleList == None and inputMatchRuleList == None):
        _app_message("Application %s Routing WorkClass %s does not need to be updated" % (appName,wcName))
      else:
        modifyApplicationRoutingWorkClass(wcId=wcId,wcProps=wcProps,matchRuleList=inputMatchRuleList,moduleList=inputModuleList,
                                          appendModules=appendWorkClassModules,appendRules=appendMatchRules)
        _app_message("Application %s Routing WorkClass %s has been updated" % (appName,wcName))
                                          
        
      
    else:
      _app_message("Application %s Routing WorkClass %s is not defined" % (appName,wcName))
      
      # Pull the attributes of the work class
      wcProps = getPropList(wcConfigInfo,prefix)
      matchRuleList = getDictionaryList(wcConfigInfo,"%s.matchRules"%prefix)
      moduleList = getDictionaryList(wcConfigInfo,"%s.workClassModules" % prefix)
      
      
      
      wcId = createApplicationRoutingWorkClass(appName,wcName,wcProps=wcProps,
                                               matchRuleList=matchRuleList,moduleList=moduleList)
                                               
      _app_message("Application %s Routing WorkClass %s has been created" % (appName,wcName))
      
  except:
    _app_exception("Unexpected problem in processApplicationRoutingWorkClass()")
  
  _app_exit("processApplicationRoutingWorkClass()")
  


#-------------------------------------------------------------------------------
# processRoutingWorkClassesForApplication
#
# Parameters
#
#-------------------------------------------------------------------------------
def processRoutingWorkClassesForApplication(wcConfigInfo,appPrefix,appName):
  _app_entry("processRoutingWorkClassesForApplication(wcConfigInfo,%s,%s)" , appPrefix,appName)
  
  try:
    routingPrefix = "%s.routing" % appPrefix
    routingCount = int(wcConfigInfo.get("%s.count" % routingPrefix,0))
    if (routingCount > 0):
      for idx in range(1,routingCount+1):
        prefix = "%s.%d" % (routingPrefix,idx)
        wcName = wcConfigInfo.get("%s.name"%prefix,None)
        if (isEmpty(wcName)):
          # Partial list
          continue
        # Now process the settings for this individual routing work class
        processApplicationRoutingWorkClass(wcConfigInfo,prefix,appName,wcName)
  except:
    _app_exception("Unexpected problem in processRoutingWorkClassesForApplication()")
  
  _app_exit("processRoutingWorkClassesForApplication()")


#-------------------------------------------------------------------------------
# getServiceUpdateProps
#
# Parameters
#
#-------------------------------------------------------------------------------
def getServiceUpdateProps(wcConfigInfo,prefix,wcId=None):
  _app_entry("getServiceUpdateProps(wcConfigInfo,%s,%s)" , prefix,wcId)
  retval = ()
  try:
      existingProps  = None
      if (not isEmpty(wcId)):
        existingProps = getWorkClassProperties(wcId)
      else:
        existingProps = {}
      
      # See what needs updating
      wcProps = getPropListDifferences(wcConfigInfo,prefix,existingProps,"workclass")
      
      inputMatchRuleList = getDictionaryList(wcConfigInfo,"%s.matchRules"%prefix)
      inputModuleList = getDictionaryList(wcConfigInfo,"%s.workClassModules" % prefix)
      
      appendMatchRules = (wcConfigInfo.get("%s.appendMatchRules"%prefix,"false").lower() == "true")
      appendWorkClassModules = (wcConfigInfo.get("%s.appendWorkClassModules"%prefix,"false").lower() == "true")
      
      existingMatchRuleList = getDictionaryList(existingProps,"workclass.matchRules")
      existingModuleList = getDictionaryList(existingProps,"workclass.workClassModules")
      
      
      if (inputMatchRuleList == existingMatchRuleList):
        inputMatchRuleList = None
      else:
        if (appendMatchRules):
          tempList = []
          for rule in inputMatchRuleList:
            if rule not in existingMatchRuleList:
              tempList.append(rule)
          
          if (len(tempList) > 0):
            inputMatchRuleList = tempList
          else:
            inputMatchRuleList = None
            
      
      if (inputModuleList == existingModuleList):
        # No updates necessary
        inputModuleList = None
      else:
        if (appendWorkClassModules):
          tempList = []
          for module in inputModuleList:
            if module not in existingModuleList:
              tempList.append(module)
          
          if (len(tempList) > 0):
            inputModuleList = tempList
          else:
            inputModuleList = None
      
      retval = (wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules)
    
  except:
    _app_exception("Unexpected problem in getServiceUpdateProps()")
  
  _app_exit("getServiceUpdateProps(retval=%s)" % str(retval))
  return retval
  
  

#-------------------------------------------------------------------------------
# processApplicationServiceWorkClass
#
#   Processes an individual Service WorkClass definition
#
# Parameters
#
#-------------------------------------------------------------------------------
def processApplicationServiceWorkClass(wcConfigInfo,prefix,appName,wcName):
  _app_entry("processApplicationServiceWorkClass(servicePrefix,%s,%s,%s)" , prefix,appName,wcName)
  
  try:
    # See if it is already defined
    wcId = findApplicationServiceWorkClass(appName,wcName)
    if (not isEmpty(wcId)):
      
      wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules = getServiceUpdateProps(wcConfigInfo,prefix,wcId)
      
      
      if (len(wcProps) == 0 and inputModuleList == None and inputMatchRuleList == None):
        _app_message("Application %s Service WorkClass %s does not need to be updated" % (appName,wcName))
      else:
        modifyApplicationServiceWorkClass(wcId=wcId,wcProps=wcProps,moduleList=inputModuleList,matchRuleList=inputMatchRuleList,
                                          appendModules=appendWorkClassModules,appendRules=appendMatchRules)
        _app_message("Application %s Service WorkClass %s has been updated" % (appName,wcName))
                                          
      
    else:
      #_app_message("Application %s Service WorkClass %s is not defined" % (appName,wcName))
      
      wcProps = getPropList(wcConfigInfo,prefix)
      matchRuleList = getDictionaryList(wcConfigInfo,"%s.matchRules"%prefix)
      moduleList = getDictionaryList(wcConfigInfo,"%s.workClassModules" % prefix)
      
      wcId = createApplicationServiceWorkClass(appName,wcName,wcProps=wcProps,moduleList=moduleList,matchRuleList=matchRuleList)
      _app_message("Application %s Service WorkClass %s has been created" % (appName,wcName))
  except:
    _app_exception("Unexpected problem in processApplicationServiceWorkClass()")
  
  _app_exit("processApplicationServiceWorkClass(retval=%s)")
  


#-------------------------------------------------------------------------------
# processServiceWorkClassesForApplication
#   Process multiple Service WorkClass definitions for an application or application-edition
#
# Parameters
#
#-------------------------------------------------------------------------------
def processServiceWorkClassesForApplication(wcConfigInfo,appPrefix,appName):
  _app_entry("processServiceWorkClassesForApplication(wcConfigInfo,%s,%s)" , appPrefix,appName)
  retval = None
  try:
    serviceCount = int(wcConfigInfo.get("%s.service.count" % appPrefix,0))
    if (serviceCount > 0):
      for idx in range(1,serviceCount+1):
        servicePrefix = "%s.service.%d" % (appPrefix,idx)
        wcName = wcConfigInfo.get("%s.name" % servicePrefix)
        if (isEmpty(wcName)):
          # Partial list
          continue
        
        processApplicationServiceWorkClass(wcConfigInfo,servicePrefix,appName,wcName)
       
  except:
    _app_exception("Unexpected problem in processServiceWorkClassesForApplication()")
  
  _app_exit("processServiceWorkClassesForApplication(retval=%s)" % retval)
  return retval



#-------------------------------------------------------------------------------
# processCompUnitRoutingWorkClass
#   Process an individual Routing WorkClass definition associated with a 
#   BLA comp unit.
#
# Parameters
#
#-------------------------------------------------------------------------------
def processCompUnitRoutingWorkClass(wcConfigInfo,routingPrefix,appName,cuName,wcName):
  _app_entry("processCompUnitRoutingWorkClass(wcConfigInfo,%s,%s,%s,%s)" , routingPrefix,appName,cuName,wcName)
  retval = None
  try:
    # See if the WorkClass is defined
    wcId = findCompUnitRoutingWorkClass(cuName,wcName)
    if (not isEmpty(wcId)):
      _app_message("Routing WorkClass %s is defined for BLA=%s , CU=%s" % (wcName,appName,cuName))
      
      # See what needs updating
      wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules =  getRoutingUpdateProps(wcConfigInfo,routingPrefix,wcId)
            
      if (len(wcProps) == 0 and inputModuleList == None and inputMatchRuleList == None):
        _app_message("No updates needed for routing WorkClass %s for BLA=%s , CU=%s" % (wcName,appName,cuName))
      else:
        modifyApplicationRoutingWorkClass(wcId=wcId,wcProps=wcProps,matchRuleList=inputMatchRuleList,moduleList=inputModuleList,
                                          appendModules=appendWorkClassModules,appendRules=appendMatchRules)
                                          
        _app_message("Routing WorkClass %s has been updated for BLA=%s , CU=%s" % (wcName,appName,cuName))
      
    else:
      _app_message("Routing WorkClass %s is not defined for BLA=%s , CU=%s" % (wcName,appName,cuName))
      
      # LIMITATION:
      # Turns out we can't do this in wsadmin - the call below will produce an exception
      
      # Pull the attributes of the work class
      wcProps = getPropList(wcConfigInfo,routingPrefix)
      matchRuleList = getDictionaryList(wcConfigInfo,"%s.matchRules"%routingPrefix)
      moduleList = getDictionaryList(wcConfigInfo,"%s.workClassModules" % routingPrefix)
      
      
      
      wcId = createApplicationRoutingWorkClass(appName,wcName,cuName=cuName,wcProps=wcProps,
                                               matchRuleList=matchRuleList,moduleList=moduleList)
                                               
      _app_message("Routing WorkClass %s has been created for BLA=%s , CU=%s" % (wcName,appName,cuName))

      
  except:
    _app_exception("Unexpected problem in processCompUnitRoutingWorkClass()")
  
  _app_exit("processCompUnitRoutingWorkClass(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# processRoutingWorkClassesForCompUnit
#    Process multiple Routing Work Class definitions associated
#    with a BLA comp unit
#
# Parameters
#
#    wcConfigInfo - dictionary with settings to process
#    cuPrefix - prefix to use with property keys
#    appName - Name of BLA being processed
#    cuName - Name of the BLA compunit (asset) being processed

#-------------------------------------------------------------------------------
def processRoutingWorkClassesForCompUnit(wcConfigInfo,cuPrefix,appName,cuName):
  _app_entry("processRoutingWorkClassesForCompUnit(wcConfigInfo,%s,%s,%s)" , cuPrefix,appName,cuName)
  retval = None
  try:
    routingCount = int(wcConfigInfo.get("%s.routing.count" % cuPrefix,0))
    if (routingCount > 0):
      for idx in range(1,routingCount+1):
        routingPrefix = "%s.routing.%d" % (cuPrefix,idx)
        wcName = wcConfigInfo.get("%s.name" % routingPrefix)
        if (isEmpty(wcName)):
          # Partial list
          continue
        
        processCompUnitRoutingWorkClass(wcConfigInfo,routingPrefix,appName,cuName,wcName)
  except:
    _app_exception("Unexpected problem in processRoutingWorkClassesForCompUnit()")
  
  _app_exit("processRoutingWorkClassesForCompUnit(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# processCompUnitServiceWorkClass
#
#   Process the settings for an individual Service WorkClass for a specific
#   BLA comp unit. Only the Default_HTTP_WC can be editied with this function
#   as there is no capability to create other service work classes.
#
# Parameters
#    wcConfigInfo - dictionary with settings to process
#    servicePrefix - prefix to use with property keys
#    appName - Name of BLA being processed
#    cuName - Name of the BLA compunit (asset) being processed
#    wcName - Name of the Work Class
#-------------------------------------------------------------------------------
def processCompUnitServiceWorkClass(wcConfigInfo,servicePrefix,appName,cuName,wcName):
  _app_entry("processCompUnitServiceWorkClass(wcConfigInfo,%s,%s,%s,%s)" , servicePrefix,appName,cuName,wcName)
  retval = None
  try:
    # See if the Service Work Class is defined
    wcId = findCompUnitServiceWorkClass(cuName,wcName)
    if (not isEmpty(wcId)):
      wcProps,inputModuleList,inputMatchRuleList,appendWorkClassModules,appendMatchRules = getServiceUpdateProps(wcConfigInfo,servicePrefix,wcId)
      
      
      if (len(wcProps) == 0 and inputModuleList == None and inputMatchRuleList == None):
        _app_message("Service WorkClass %s does not need to be updated for App=%s, CU=%s" % (wcName,appName,cuName))
      else:
        modifyApplicationServiceWorkClass(wcId=wcId,wcProps=wcProps,moduleList=inputModuleList,matchRuleList=inputMatchRuleList,
                                          appendModules=appendWorkClassModules,appendRules=appendMatchRules)
        _app_message("Service WorkClass %s has been updated for App=%s, CU=%s" % (wcName,appName,cuName))
      
    else:
      _app_message("ERROR: New Service Work Classes cannot be defined for a BLA comp unit. Use Default_HTTP_WC. App=%s,CU=%s,WC=%s" % (appName,cuName,wcName))
      
      raise StandardError("New Service Work Classes cannot be defined for a BLA comp unit. Use Default_HTTP_WC. App=%s,CU=%s,WC=%s" % (appName,cuName,wcName))
    
  except:
    _app_exception("Unexpected problem in processCompUnitServiceWorkClass()")
  
  _app_exit("processCompUnitServiceWorkClass(retval=%s)" % retval)
  return retval

            
#-------------------------------------------------------------------------------
# processServiceWorkClassesForCompUnit
#    Process multiple service work classes for a BLA comp unit
#    
# Parameters
#
#    wcConfigInfo - dictionary with settings to process
#    cuPrefix - prefix to use with property keys
#    appName - Name of BLA being processed
#    cuName - Name of the BLA compunit (asset) being processed
#-------------------------------------------------------------------------------
def processServiceWorkClassesForCompUnit(wcConfigInfo,cuPrefix,appName,cuName):
  _app_entry("processServiceWorkClassesForCompUnit(wcConfigInfo,%s,%s,%s)" , cuPrefix,appName,cuName)
  retval = None
  try:
    serviceCount = int(wcConfigInfo.get("%s.service.count" % cuPrefix,0))
    if (serviceCount > 0):
      for idx in range(1,serviceCount+1):
        servicePrefix = "%s.service.%d" % (cuPrefix,idx)
        wcName = wcConfigInfo.get("%s.name" % servicePrefix)
        if (isEmpty(wcName)):
          # Partial list
          continue
        
        processCompUnitServiceWorkClass(wcConfigInfo,servicePrefix,appName,cuName,wcName)

  except:
    _app_exception("Unexpected problem in processServiceWorkClassesForCompUnit()")
  
  _app_exit("processServiceWorkClassesForCompUnit(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# processWorkClass
#   Process work class definitions in the supplied dictionary. This is the primary
#   entry point of the module and processes workclass definitions defined in the
#   property trees: app.im.workclass.application and app.im.workclass.bla
#
# Parameters
#   wcConfigInfo - a dictionary with properties that define WorkClasses
#-------------------------------------------------------------------------------
def processWorkClass(wcConfigInfo):
  _app_entry("processWorkClass(wcConfigInfo)")
  
  try:
    #Work classes are organized on a per-application basis
    basePrefix = "app.im.workclass.application"
    
    appCount = int(wcConfigInfo.get("%s.count" % basePrefix,0))
    if (appCount  > 0):
      for idx in range(1,appCount+1):
        appPrefix = "%s.%d" % (basePrefix,idx)
        appName = wcConfigInfo.get("%s.name" % appPrefix,None)
        if (isEmpty(appName)):
          # Partial list
          continue
        
        processRoutingWorkClassesForApplication(wcConfigInfo,appPrefix,appName)
        
        editionCount = int(wcConfigInfo.get("%s.edition.count" % appPrefix,0))
        if (editionCount > 0):
          for eidx in range(1,editionCount+1):
            editionPrefix = "%s.edition.%d" % (appPrefix,eidx)
            editionName = wcConfigInfo.get("%s.name" % editionPrefix,None)
            if (isEmpty(editionName)):
              # Partial list
              continue
            
            processServiceWorkClassesForApplication(wcConfigInfo,editionPrefix,editionName)
        else:
          # This is not an editioned application
          processServiceWorkClassesForApplication(wcConfigInfo,appPrefix,appName)
    
    # Now do work classes for BLA 
    blaPrefix = "app.im.workclass.blas"
    appCount = int(wcConfigInfo.get("%s.count" % blaPrefix,0))
    if (appCount > 0):
      for idx in range(1,appCount+1):
        appPrefix = "%s.%d" % (blaPrefix,idx)
        appName = wcConfigInfo.get("%s.name" % appPrefix,None)
        if (isEmpty(appName)):
          # Partial list
          continue  
        
        cuCount = int(wcConfigInfo.get("%s.compUnit.count" % appPrefix,0))
        if (cuCount > 0):
          for cuIdx in range(1,cuCount+1):
            cuPrefix = "%s.compUnit.%d" % (appPrefix,cuIdx)
            cuName = wcConfigInfo.get("%s.name" % cuPrefix)
            if (isEmpty(cuName)):
              # partial list
              continue
            
            processRoutingWorkClassesForCompUnit(wcConfigInfo,cuPrefix,appName,cuName)
            
            processServiceWorkClassesForCompUnit(wcConfigInfo,cuPrefix,appName,cuName)
            
  except:
    _app_exception("Unexpected problem in processWorkClass()")
  
  _app_exit("processWorkClass()")
  