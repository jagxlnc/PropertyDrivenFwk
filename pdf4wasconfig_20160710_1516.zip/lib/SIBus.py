##########################################################################
# File Name:    SIBus.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere SIBuses
#
#               createSIBus
#               deleteSIBus
#               listSIBuses
#
#               In addition to those, it has functions for updating the SIBAuthSpace
#               authorization settings for a bus:
#
#								updateBusConnectorUserGroups
#               updateSIBAuthDefaultUsersGroups
#
# wsadmin>AdminConfig.attributes("SIBus")
# busMembers SIBusMember*
# configurationReloadEnabled boolean
# description String
# discardMsgsAfterQueueDeletion boolean
# foreignBus SIBForeignBus*
# highMessageThreshold long
# interEngineAuthAlias String
# mediationsAuthAlias String
# name String
# permittedChains SIBPermittedChain*
# properties Property(TypedProperty, DescriptiveProperty)*
# protocol String
# secure boolean
# usePermittedChains ENUM(SSL_ENABLED, LISTED, ALL)
# uuid String
#
# wsadmin>AdminTask.help('createSIBus')
#
# "WASX8006I: Detailed help for command: createSIBus
#
# Description: Create a bus.
#
# Target object:   None
# 
# Arguments:
#  *bus - Name of bus to create, which must be unique in the cell.
#  description - Descriptive information about the bus.
#  secure - Enable or disable bus security.  Deprecated.  Use busSecurity parameter instead.
#  interEngineAuthAlias - Name of the authentication alias used to authorize communication between messaging engines on the bus.
#  mediationsAuthAlias - Name of the authentication alias used to authorize mediations to access the bus.
#  protocol - The protocol used to send and receive messages between messaging engines, and between API clients and messaging engines.
#  discardOnDelete - Indicate whether or not any messages left in a queue's data store should be discarded when the queue is deleted.
#  highMessageThreshold - The maximum number of messages that any queue on the bus can hold.
#  configurationReloadEnabled - Indicate whether configuration files should be dynamically reloaded for this bus.
#  busSecurity - Enables or disables bus security.
# scriptCompatibility - Set script compatibility to 6 to maintain version 6 command behavior.  Default value is 6.1.
# 
#  securityGroupCacheTimeout - The length of time, in minutes, that a security group will be cached for.
#  scriptCompatibility - Set script compatibility to 6 to maintain version 6 command behavior.  Default value is 6.1.
#  bootstrapPolicy - The bootstrap policy value can be set to one of the following SIBSERVICE_ENABLED, MEMBERS_AND_NOMINATED or MEMBERS_ONLY.
#  useServerIdForMediations - Configure the bus to use the server identity for calling mediations rather than the mediationsAuthAlias.
#  auditAllowed - Used to allow or prevent the bus from auditing when the application server auditing support is enabled. 
#
# Note: no new parms in V8 and V8.5
##########################################################################

##########################################################################
#
# FUNCTION:
#    createSIBus: Create a service integration bus
#
# SYNTAX:
#    createSIBus name, attrs
#
# PARAMETERS:
#    name	-	Name for SIBus which must be unique within cell
#    attrs	-	Properties set with key/value pairs where the keys are
#             the attribute names of the SIBus configuration type.  This
#             method will map these to the correct values for AdminTask.createSIBus
#    customProps - Properties set with attributes for custom propertes
#
# USAGE NOTES:
#    Creates a SIBus
#
# RETURNS:
#    ObjID	Object ID of new bus
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addSIBus(name, attrs):
	createSIBus(name, attrs)
	
def createSIBus(name, attrs, customProps = None):

	global progInfo

	retval = None
	
	adminTaskParmMapV7 = { 'securityGroupCacheTimeout' : '-securityGroupCacheTimeout' , 'bootstrapMemberPolicy' : '-bootstrapPolicy', 'useServerIdForMediations' : '-useServerIdForMediations', 'secure': '-busSecurity' , 'description':'-description',   'interEngineAuthAlias':'-interEngineAuthAlias', 'mediationsAuthAlias':'-mediationsAuthAlias', 'protocol':'-protocol', 'discardMsgsAfterQueueDeletion':'-discardOnDelete', 'highMessageThreshold':'-highMessageThreshold', 'configurationReloadEnabled':'-configurationReloadEnabled', 'auditAllowed':'-auditAllowed' }
	adminTaskParmMapV6 = {'secure': '-busSecurity' , 'description':'-description',   'interEngineAuthAlias':'-interEngineAuthAlias', 'mediationsAuthAlias':'-mediationsAuthAlias', 'protocol':'-protocol', 'discardMsgsAfterQueueDeletion':'-discardOnDelete', 'highMessageThreshold':'-highMessageThreshold', 'configurationReloadEnabled':'-configurationReloadEnabled'}
	
	ignoreAttributesV7 = ['uuid']
	ignoreAttributesV6 = ['uuid', 'securityGroupCacheTimeout' , 'bootstrapMemberPolicy' , 'useServerIdForMediations' ]

	try:
		traceStr = "createSIBus(%s, %s)" % (name, attrs)
		_app_trace(traceStr, "entry")
		
		adminTaskParmMap = adminTaskParmMapV7
		ignoreAttributes = ignoreAttributesV7
		if ( progInfo["dmgrVersion"].startswith("6")):
				adminTaskParmMap = adminTaskParmMapV6
				ignoreAttributes = ignoreAttributesV6

		#	Check function parameters
		if isEmpty(name):
			raise StandardError("Bus Name not specified")
		
		#	If object already exists, warn and exit
		if objectExists("SIBus", None, name):
			raise StandardError("SIBus %s already exists" % (name))

		attributes = '-bus "%s"' % (name)
		
		for key in attrs.keys():
				if adminTaskParmMap.has_key(key):
						val = attrs[key]
						if (key == "description" and not val.startswith('"')):
								val = '"%s"' % val
						attributes = "%s %s %s" % (attributes, adminTaskParmMap[key], val)
		
		_app_trace("Running command: AdminTask.createSIBus('[%s]')" % (attributes))
		retval = AdminTask.createSIBus('[%s]' % (attributes))
		
		
		# Now process those attributes that aren't passed in to the AdminTask
		updateAttrs = []
		for key in attrs.keys():
				if adminTaskParmMap.has_key(key):
						continue
				if (key in ignoreAttributes):
						continue
						
				updateAttrs.append([key, attrs.get(key)])
		
		if (len(updateAttrs) > 0):
				if (modifyObject(retval, updateAttrs)):
						_app_trace("Error updating attributes for new bus %s" % name)
						raise StandardError("Error updating attributes for new bus %s" % name )
						
		
		if (customProps != None and customProps.size() > 0):
				errMsg = updateCustomProperties(retval, "properties", "Property", customProps)
				if (not isEmpty(errMsg)):
						_app_trace("Error updating custom properties for bus %s : %s" % (name, errMsg))
						raise StandardError("Error updating custom properties for bus %s : %s" % (name, errMsg))
				
				


		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
		
	except:
		_app_trace("An error was encountered creating the SIBus", "exception")
		retval = None

	_app_trace("createSIBus(%s)" %(retval), "exit")
	return retval
	

##########################################################################
#
# FUNCTION:
#    updateSIBus: Update a service integration bus basic settings
#
# SYNTAX:
#    updateSIBus busId, name, attrs, customProps
#
# PARAMETERS:
#    busId - The configuration ID of the existing bus
#    name	-	Name for SIBus which must be unique within cell
#    attrs	-	Properties set with key/value pairs where the keys are
#             the attribute names of the SIBus configuration type.  This
#             method will map these to the correct values for AdminTask.createSIBus
#    customProps - Properties set with attributes for custom propertes
#
# USAGE NOTES:
#    Updates a SIBus
#
# RETURNS:
#    ObjID	Object ID of the bus
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def updateSIBus(busId, name, attrs, customProps = None):

	global progInfo

	retval = busId
	
	ignoreAttributes = ['uuid']

	try:
		traceStr = "updateSIBus(%s, %s, %s, %s)" % (busId, name, attrs, customProps)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		if isEmpty(busId):
			raise StandardError("Bus Name not specified")
		
		
		# Now process those attributes
		updateAttrs = []
		for key in attrs.keys():
				if (key in ignoreAttributes):
						continue
						
				updateAttrs.append([key, attrs.get(key)])
		
		if (len(updateAttrs) > 0):
				if (modifyObject(retval, updateAttrs)):
						_app_trace("Error updating attributes for bus %s" % name)
						raise StandardError("Error updating attributes for bus %s" % name )
						
		
		if (customProps != None and customProps.size() > 0):
				errMsg = updateCustomProperties(retval, "properties", "Property", customProps)
				if (not isEmpty(errMsg)):
						_app_trace("Error updating custom properties for bus %s : %s" % (name, errMsg))
						raise StandardError("Error updating custom properties for bus %s : %s" % (name, errMsg))
				
		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
		
	except:
		_app_trace("An error was encountered updating the SIBus", "exception")
		retval = None

	_app_trace("updateSIBus(%s)" %(retval), "exit")
	return retval
	
##########################################################################
#
# FUNCTION:
#    deleteSIBus: Delete a SIBus
#
# SYNTAX:
#    deleteSIBus name
#
# PARAMETERS:
#    name	-	Name of SIBus to delete.
#
# USAGE NOTES:
#    Deletes an SIBus AND all members on it.  Use with caution

# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBus(name):
	deleteSIBus(name)

def deleteSIBus(name):

	global progInfo

	retval = 1

	try:
		traceStr = "deleteSIBus(%s)" % (name)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		if isEmpty(name):
			raise StandardError("SIBus Name not specified")
		
		#	If object doesn't exist, warn and exit
		if not objectExists("SIBus", None, name):
			raise StandardError("SIBus %s doesn't exist" % (name))

		_app_trace("Running command: AdminTask.deleteSIBus(-bus %s)" % (name))

		AdminTask.deleteSIBus('[-bus "%s"]' % (name))

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
			
		retval = 0
		
	except:
		_app_trace("An error was encountered deleting the SIBus", "exception")
		retval = 1

	_app_trace("deleteSIBus(%d)" %(retval), "exit")
	return retval

##########################################################################
#
# FUNCTION:
#    listSIBuses: List SIBuses
#
# SYNTAX:
#    listSIBuses displayFlag
#
# PARAMETERS:
#    displayFlag- Boolean indicating whether to print list 
#		  (default = 1)
#
# USAGE NOTES:
#    Lists SIBuses in the current cell
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showSIBuses(displayFlag = 1):
	listSIBuses(displayFlag)
	
def listSIBuses(displayFlag = 1):

	global progInfo
	
	retval = None
	
	try:
		_app_trace("listSIBuses(%d)" % (displayFlag), "entry")	

		_app_trace("Running command: AdminTask.listSIBuses()")
		str = AdminTask.listSIBuses()
		 
		if isEmpty(str):
			retval = []
		else:
			retval = str.split(progInfo["line.separator"])


		if displayFlag:
			print "\nSI Buses\n-------------------"

			for r in retval:
				print AdminConfig.showAttribute(r, "name")

			print "-------------------"
		 

	except:
		_app_trace("An error was encountered listing the SIBuses", "exception")
		retval = None

	_app_trace("listSIBuses(%s)" %(retval), "exit")
	return retval
	
#------------------------------------------------------------------------------
# checkExistingBus
#
# See if a bus with the specified name already exists
#
# Returns - configuration ID of the bus if it exists
#           None if not
#------------------------------------------------------------------------------
def checkExistingBus(name):

	_app_trace("checkExistingBus(%s)" %(name), "entry")

	
	result = None

	try:
			objid = AdminConfig.getid("/SIBus:%s/"%name)
	
			if (not isEmpty(objid)):
					result = objid
	except:
			_app_trace("An error was encountered lookin up the SIBus", "exception")
			retval = None
			

	_app_trace("checkExistingBus(%s) = %s" %(name,result), "exit")
	return result

#--------------------------------------------------------------------------------------
# buidIDMap - utility method that preloads SIBAuthSpace user or group information
# into a dictionary for later reference.  Various SIBAuth..... configuration items
# use references to these IDs in their configuration, so we preload a dictionary to
# avoid unnecessary searches.
#
# Parameters:
#			authSpaceId - configuration ID of the SIBAuthSpace
#			propertyName - either "group" or "user"
#            
#--------------------------------------------------------------------------------------
def buildIDMap(authSpaceId, propertyName):
	retval = {}
	
	idlist = wsadminToList(AdminConfig.showAttribute(authSpaceId,propertyName))

	for authid in idlist:
		if (isEmpty(authid)):
			continue
		tempIdentifier = AdminConfig.showAttribute(authid,"identifier")
		tempUniqueName = AdminConfig.showAttribute(authid,"uniqueName")
		
		if (tempUniqueName == None):
			tempUniqueName = ""
		
		retval["ID_%s_UN_%s" % (tempIdentifier,tempUniqueName)] = authid
	
	return retval

#-----------------------------------------------------------------------------
# updateBusConnectorUserGroups - adds users and groups to the busConnect settings
# of an SIBus.  These users and groups should have previously been added to the 
# SIBAuthSpace configuration through use of the updateSibAuthSpaceUsersGroups method.
#
# Parameters:
#		busId - configuration ID of the bus to update
#   newUserList - list of [identifier, uniqueName] pairs 
#   newGroupList - list of [identifier, uniqueName] pairs 
#   
#-----------------------------------------------------------------------------
def updateBusConnectorUserGroups(busId, newUserList, newGroupList):
	_app_trace("updateBusConnectorUserGroups(%s,%s,%s)"%(busId, newUserList, newGroupList),"entry")
	
	try:
		busName = AdminConfig.showAttribute(busId,"name")		
	
		newUserIdList = ""
		for newuser in newUserList:
			newIdentifier = newuser[0]
			newUniqueName = newuser[1]
			
			parms = '-bus "%s" -user %s' % (busName, newIdentifier)
			if (not isEmpty(newUniqueName)):
				parms = "%s -uniqueName %s" % (parms, newUniqueName)
			
			AdminTask.addUserToBusConnectorRole("[ %s ]" % parms)			


		newGroupIdList = ""
		for newgroup in newGroupList:
			newIdentifier = newgroup[0]
			newUniqueName = newgroup[1]
			
			parms = '-bus "%s" -group %s' % (busName, newIdentifier)
			if (not isEmpty(newUniqueName)):
				parms = "%s -uniqueName %s" % (parms, newUniqueName)
			
			AdminTask.addGroupToBusConnectorRole("[ %s ]" % parms)		
						
	except:
		_app_trace("Error setting up bus connector users and groups","exception")
		raise StandardError("Error setting up bus connector users and groups")
		
	_app_trace("updateBusConnectorUserGroups()","exit")
	
#---------------------------------------------------------------------------------------------------
# updateSibAuthSpaceUsersGroups
#
# Note: This method is not used if AdminTask commands are used to add users/groups to the roles
#
# Add new users and groups to the SibAuthSpace configuration item
#
# Parameters
#		busId - The ID of the bus to be updated
#		newUserList - list of [identifier, uniqueName] pairs 
#		newGroupList - list of [identifier, uniqueName] pairs 
#---------------------------------------------------------------------------------------------------
def updateSibAuthSpaceUsersGroups(busId, newUserList=[], newGroupList=[]):
	
	_app_trace("updateSibAuthSpaceUsersGroups(%s,%s,%s)" % (busId, newUserList, newGroupList),"entry")
	try:
		authSpaceId = AdminConfig.list("SIBAuthSpace",busId)
		
		for newUser in newUserList:
			newIdentifier = newUser[0]
			newUniqueName = newUser[1]
			
			if (isEmpty(newUniqueName)):
				attrs = [["identifier",newIdentifier]]
			else:
				attrs = [ ["identifier",newIdentifier],["uniqueName",newUniqueName] ]
			
			_app_trace("About to call AdminConfig.create(SIBAuthUser,%s,%s)" % (authSpaceId,attrs))
			AdminConfig.create("SIBAuthUser",authSpaceId,attrs)

		for newGroup in newGroupList:
			newIdentifier = newGroup[0]
			newUniqueName = newGroup[1]
			
			if (isEmpty(newUniqueName)):
				attrs = [["identifier",newIdentifier]]
			else:
				attrs = [ ["identifier",newIdentifier],["uniqueName",newUniqueName] ]
			
			_app_trace("About to call AdminConfig.create(SIBAuthGroup,%s,%s)" % (authSpaceId,attrs))
			AdminConfig.create("SIBAuthGroup",authSpaceId,attrs)			
		
	except:
		_app_trace("Error adding new users and groups to SibAuthSpace","exception")
		raise StandardError("Error adding new users and groups to SibAuthSpace")
	
	_app_trace("updateSibAuthSpaceUsersGroups()","exit")
	
#-----------------------------------------------------------------------------------------------
# updateUserGroupsForId - Utility method used to add new users/groups to items like
# SIBAuthSender, SIBAuthCreator,....
#
# Parameters:
#		configId - Configuration ID of item that has group (SIBAuthGroup) and user (SIBAuthUser) attributes
# 	newUsers - a list of new users to add (a list of [identifier, uniqueName] pairs
# 	newGroups - a list of new groups to add (a list of [identifier, uniqueName] pairs
#   userMap - a dictionary containing the IDs of the users registered with the SIBAuthSpace
#             The new configuration uses references to the IDs in this dictionary and the groupMap
#   groupMap - a dictionary containing the IDs of the groups registered with the SIBAuthSpace
#-----------------------------------------------------------------------------------------------
def updateUserGroupsForId(configId, newUsers, newGroups,userMap,groupMap):
	_app_trace("updateUserGroupsForId(%s,%s,%s,groupMap,userMap)" % (configId, newUsers, newGroups),"entry")
	try:
		existingGroups = AdminConfig.showAttribute(configId,"group")
		existingUsers = AdminConfig.showAttribute(configId,"user")
		
	
		newUserIdList = ""
		for newuser in newUsers:
			newIdentifier = newuser[0]
			newUniqueName = newuser[1]
			
			# Find ID
			searchKey = "ID_%s_UN_%s" % (newIdentifier,newUniqueName)
			newUserId = userMap.get(searchKey)
			if (isEmpty(newUserId)):
				raise StandardError("ID is missing: %s %s" % (newIdentifier,newUniqueName))
			
			if isEmpty(newUserIdList):
				newUserIdList = newUserId
			else:
				newUserIdList = "%s %s" % (newUserIdList, newUserId)
	
		if (not isEmpty(newUserIdList)):	
			attrs = [['user',newUserIdList]]
			if (modifyObject(configId,attrs)):
				raise StandardError("Error adding new users to bus connector role settings")


		newGroupIdList = ""
		for newgroup in newGroups:
			newIdentifier = newgroup[0]
			newUniqueName = newgroup[1]
			
			# Find ID
			searchKey = "ID_%s_UN_%s" % (newIdentifier,newUniqueName)
			newGroupId = groupMap.get(searchKey)
			if (isEmpty(newGroupId)):
				raise StandardError("ID is missing: %s %s" % (newIdentifier,newUniqueName))
			
			if isEmpty(newGroupIdList):
				newGroupIdList = newGroupId
			else:
				newGroupIdList = "%s %s" % (newGroupIdList, newGroupId)
	
		if (not isEmpty(newGroupIdList)):	
			attrs = [['group',newGroupIdList]]
			if (modifyObject(configId,attrs)):
				raise StandardError("Error adding new groups to bus connector role settings")		

	except:
		_app_trace("Unexpected error in updateUserGroupsForId","exception")
		raise StandardError("Unexpected error in updateUserGroupsForId")
		
	_app_trace("updateUserGroupsForId()","exit")

#-----------------------------------------------------------------------------------------------
# updateUserGroupsForDefaultRole - Utility method used to add new users/groups to items like
# SIBAuthSender, SIBAuthCreator,....
#
# Parameters:
#   busName  - Name of the bus
#   roleName - Name of the role
#		configId - Configuration ID of item that has group (SIBAuthGroup) and user (SIBAuthUser) attributes
# 	newUsers - a list of new users to add (a list of [identifier, uniqueName] pairs
# 	newGroups - a list of new groups to add (a list of [identifier, uniqueName] pairs
#-----------------------------------------------------------------------------------------------
def updateUserGroupsForDefaultRole(busName, roleName, newUsers, newGroups):
	_app_trace("updateUserGroupsForDefaultRole(%s,%s,%s,%s)" % (busName, roleName,newUsers, newGroups),"entry")
	try:
	
		newUserIdList = ""
		for newuser in newUsers:
			newIdentifier = newuser[0]
			newUniqueName = newuser[1]
			
			parms = '-bus "%s" -role %s -user %s' % (busName, roleName, newIdentifier)
			if (not isEmpty(newUniqueName)):
					parms = "%s -uniqueName %s" % (parms, newUniqueName)
					
			AdminTask.addUserToDefaultRole("[ %s ]" % parms)


		newGroupIdList = ""
		for newgroup in newGroups:
			newIdentifier = newgroup[0]
			newUniqueName = newgroup[1]
			
			parms = '-bus "%s" -role %s -group %s' % (busName, roleName, newIdentifier)
			if (not isEmpty(newUniqueName)):
					parms = "%s -uniqueName %s" % (parms, newUniqueName)
					
			AdminTask.addGroupToDefaultRole("[ %s ]" % parms)
	except:
		_app_trace("Unexpected error in updateUserGroupsForDefaultRole","exception")
		raise StandardError("Unexpected error in updateUserGroupsForDefaultRole")
		
	_app_trace("updateUserGroupsForDefaultRole()","exit")

	
#--------------------------------------------------------------------------------------------------------------------
# updateSIBAuthDefaultUsersGroups 
#
# Add users and groups to the SIBAuthDefault settings for an SIBusConfiguration
# 
# Parameters:
#			busId          - The configuration ID of the bus
#			browserUsers   - a list of [identifier, uniqueName] pairs 
#     browserGroups  - a list of [identifier, uniqueName] pairs 
#     creatorUsers   - a list of [identifier, uniqueName] pairs 
#     creatorGroups  - a list of [identifier, uniqueName] pairs
#   	receiverUsers  - a list of [identifier, uniqueName] pairs
#     receiverGroups - a list of [identifier, uniqueName] pairs
#     senderUsers    - a list of [identifier, uniqueName] pairs
#     senderGroups   - a list of [identifier, uniqueName] pairs
#     adopterUsers   - a list of [identifier, uniqueName] pairs
#     adopterGroups  - a list of [identifier, uniqueName] pairs
#
#--------------------------------------------------------------------------------------------------------------------	
def updateSIBAuthDefaultUsersGroups(busId,browserUsers, browserGroups, creatorUsers, creatorGroups,	receiverUsers, receiverGroups,	senderUsers, senderGroups, adopterUsers, adopterGroups):
	_app_trace("updateSIBAuthDefaultUsersGroups(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"%(busId,browserUsers, browserGroups, creatorUsers, creatorGroups,	receiverUsers, receiverGroups,	senderUsers, senderGroups, adopterUsers, adopterGroups),"entry")
	try:
		
		busName = AdminConfig.showAttribute(busId,"name")
		
		if ((browserUsers != None and len(browserUsers) > 0) or (browserGroups != None and len(browserGroups) > 0)):
			updateUserGroupsForDefaultRole(busName, "Browser", browserUsers, browserGroups)


		if ((creatorUsers != None and len(creatorUsers) > 0) or (creatorGroups != None and len(creatorGroups) > 0)):
			updateUserGroupsForDefaultRole(busName, "Creator", creatorUsers, creatorGroups)

		if ((receiverUsers != None and len(receiverUsers) > 0) or (receiverGroups != None and len(receiverGroups) > 0)):
			updateUserGroupsForDefaultRole(busName, "Receiver", receiverUsers, receiverGroups)

		if ((senderUsers != None and len(senderUsers) > 0) or (senderGroups != None and len(senderGroups) > 0)):
			updateUserGroupsForDefaultRole(busName, "Sender", senderUsers, senderGroups)

		if ((adopterUsers != None and len(adopterUsers) > 0) or (adopterGroups != None and len(adopterGroups) > 0)):
			updateUserGroupsForDefaultRole(busName, "IdentityAdopter", adopterUsers, adopterGroups)
	except:
		_app_trace("Unexpected error in updateSIBAuthDefaultUsersGroups","exception")
		raise StandardError("Unexpected error in updateSIBAuthDefaultUsersGroups")
		
	_app_trace("updateSIBAuthDefaultUsersGroups()","exit")
	

#-------------------------------------------------------------------------------	
# getMessagingEngineProperties
#
# Get the properties for a specific messaging engine.
#
# Parameters
#   sibProperties - Property 
#   messagingEngineId - Configuration ID of the messaging engine
#-------------------------------------------------------------------------------	
def getMessagingEngineProperties(sibProperties,mePrefix, messagingEngineId):
  _app_trace("getMessagingEngineProperties(sibProperties,%s,%s)" % (mePrefix, messagingEngineId),"entry")
  if (sibProperties == None):
    sibProperties = java.util.Properties()
    
  try:
				name = AdminConfig.showAttribute(messagingEngineId,"name")
				sibProperties["%s.name" % (mePrefix)] =name
				
				sibProperties["%s.CONFIG_ID" % mePrefix] = messagingEngineId
				
				collectSimpleProperties(sibProperties,"%s.prop" % (mePrefix), messagingEngineId, ['name'])
				
				storeType = sibProperties.get("%s.prop.messageStoreType" % mePrefix)
				if (storeType == "DATASTORE"):
						collectSimpleProperties(sibProperties,"%s.dataStore.prop" % (mePrefix), AdminConfig.showAttribute(messagingEngineId,"dataStore"))
				elif (storeType == "FILESTORE"):
						collectSimpleProperties(sibProperties,"%s.fileStore.prop" % (mePrefix), AdminConfig.showAttribute(messagingEngineId,"fileStore"))
				
				collectCustomProperties(sibProperties,"%s.customProperties" % (mePrefix), messagingEngineId, attributeName="properties")		
    
  except:
    _app_trace("Unexpected error in getMessagingEngineProperties","exception")
    raise StandardError("Unexpected error in getMessagingEngineProperties")
    
    
  
  _app_trace("getMessagingEngineProperties()","exit")
  
  return sibProperties
			
#------------------------------------------------------------------------------
# getMessageEnginesProperties
#------------------------------------------------------------------------------
def getMessageEnginesProperties(sibProperties,prefix, messageEngineList):

    _app_trace("getMessageEnginesProperties(sibProperties,%s,%s)"% (prefix, messageEngineList), "entry")

    try:
      idx = 0
      for messageEngine in messageEngineList:
        if (not isEmpty(messageEngine)):
            idx=idx+1
        
        getMessagingEngineProperties(sibProperties,"%s.messageEngines.%d" % (prefix,idx), messageEngine)
    
      sibProperties["%s.messageEngines.count" % prefix] = "%d" % idx
    except:
      _app_trace("Exception in getMessageEnginesProperties while getting message engine properties", "exception")
      raise StandardError("Exception in getMessageEnginesProperties while getting message engine properties")
    
    _app_trace("getMessageEnginesProperties()", "exit")

#enddef

#----------------------------------------------------------------------------------
# getMessageEnginePropertiesForBusMember
#----------------------------------------------------------------------------------
def getMessageEnginePropertiesForBusMember(sibProperties, busMemberPrefix, busName, clusterName, nodeName, serverName):

  try:  
      if (not isEmpty(clusterName)):
          # Get list from cluster
          messageEngines = AdminTask.listSIBEngines('[-bus "%s" -cluster %s]' % (busName, clusterName))
      else:
          # Get list from server
          messageEngines = AdminTask.listSIBEngines('[-bus "%s" -server %s -node %s]' % (busName, serverName, nodeName))
      
      getMessageEnginesProperties(sibProperties, busMemberPrefix, wsadminToList(messageEngines))
      
  except:
    _app_trace("Unexpected error in getMessageEnginePropertiesForBusMember","exception")
    raise StandardError("Unexpected error in getMessageEnginePropertiesForBusMember")

#----------------------------------------------------------------------------------
# getBusMemberAndMessageEngineProperties
#
# Return the bus members and corresponding message engines in property file
#----------------------------------------------------------------------------------
def getBusMemberAndMessageEngineProperties(sibProperties, bus, busName, prefix,loadEngines=0):

  _app_trace("getBusMemberAndMessageEngineProperties(sibProperties,%s,%s)"% (bus, prefix), "entry")

  try:
    busMembers = AdminConfig.showAttribute(bus,"busMembers")
    if (not isEmpty(busMembers)):
          bmidx = 0
          for busMember in wsadminToList(busMembers):
              if (not isEmpty(busMember)):
                  bmidx = bmidx + 1
                  clusterName = AdminConfig.showAttribute(busMember,"cluster")
                  nodeName = AdminConfig.showAttribute(busMember,"node")
                  serverName = AdminConfig.showAttribute(busMember,"server")
                  
                  if (not isEmpty(clusterName)):
                      sibProperties["%s.busmembers.%d.cluster" % (prefix, bmidx)] = clusterName
                  else:
                      sibProperties["%s.busmembers.%d.cluster" % (prefix, bmidx)]= ""
                  
                  if (not isEmpty(nodeName)):
                      sibProperties["%s.busmembers.%d.node" % (prefix, bmidx)]= nodeName
                  else:
                      sibProperties["%s.busmembers.%d.node" % (prefix, bmidx)]= ""
                  
                  if (not isEmpty(serverName)):
                      sibProperties["%s.busmembers.%d.server" % (prefix, bmidx)]= serverName
                  else:
                      sibProperties["%s.busmembers.%d.server" % (prefix, bmidx)]= ""
                  
                  collectSimpleProperties(sibProperties, "%s.busmembers.%d.prop" % (prefix,bmidx), busMember, ['cluster','node','server'])
                  
                  # Store the bus member ID for later use
                  sibProperties["%s.busmembers.%d.CONFIG_ID" % (prefix,bmidx)] = busMember

                  if (loadEngines):
                    getMessageEnginePropertiesForBusMember(sibProperties, "%s.busmembers.%d" % (prefix,bmidx), busName, clusterName, nodeName, serverName)
                  
          sibProperties["%s.busmembers.count" % (prefix)] = "%d" % bmidx

  except:
    _app_trace("Error getting bus member properties in getBusMemberAndMessageEngineProperties","exception")
    raise StandardError("Error getting bus member properties in getBusMemberAndMessageEngineProperties")
  
  _app_trace("getBusMemberAndMessageEngineProperties()","exit")
  return sibProperties

#enddef getBusMemberAndMessageEngineProperties

#---------------------------------------------------------------------------------------------
# getSIBAuthUsersGroups
#
# local method used by getAuthSpaceProperties to get properties for turn user and group
# attributes of variaous SIBAuth..... types to lists of user and group information
#---------------------------------------------------------------------------------------------
def getSIBAuthUsersGroups(sibProperties,parentId,prefix):
	if (isEmpty(parentId)):
			return
			
	authgroups = AdminConfig.showAttribute(parentId,"group")
	if (not isEmpty(authgroups)):
			groupidx = 0
			for authgroup in wsadminToList(authgroups):
					groupidx = groupidx + 1
					collectSimpleProperties(sibProperties, "%s.group.%d.prop" % (prefix, groupidx), authgroup)
					
			sibProperties["%s.group.count" % (prefix)] = "%d" % groupidx
		
	authusers = AdminConfig.showAttribute(parentId,"user")
	if (not isEmpty(authusers)):
			useridx = 0
			for authuser in wsadminToList(authusers):
					useridx = useridx + 1
					collectSimpleProperties(sibProperties,"%s.user.%d.prop" % (prefix, useridx), authuser)
					
			sibProperties["%s.user.count" % (prefix)] = "%d"% useridx

#------------------------------------------------------------------------------------------
# getAuthSpaceProperties
#
# Returns the user and group lists, busConnector and default authorization settings in
# property format
#------------------------------------------------------------------------------------------
def getAuthSpaceProperties(bus,sibProperties=None):
	_app_trace("getAuthSpaceProperties(%s,sibProperties)" % bus, "entry")
	try:
			if (sibProperties == None):
				sibProperties = java.util.Properties()
				
			prefix = "app.sibus"
			authspace = AdminConfig.list("SIBAuthSpace",bus)
			if (not isEmpty(authspace)):
				getSIBAuthUsersGroups(sibProperties,authspace,"%s.sibauthspace" % (prefix))
					
				busConnect = AdminConfig.showAttribute(authspace,"busConnect")
				if (not isEmpty(busConnect)):
					getSIBAuthUsersGroups(sibProperties,busConnect,"%s.sibauthspace.busConnect" % (prefix))
					
				defaultAuth = AdminConfig.showAttribute(authspace,"default")
				if (not isEmpty(defaultAuth)):
					browserAuth = AdminConfig.showAttribute(defaultAuth,"browser")
					getSIBAuthUsersGroups(sibProperties,browserAuth,"%s.sibauthspace.default.browser" % (prefix))
					
					creatorAuth = AdminConfig.showAttribute(defaultAuth,"creator")
					getSIBAuthUsersGroups(sibProperties,creatorAuth,"%s.sibauthspace.default.creator" % (prefix))
					
					identityAdopterAuth = AdminConfig.showAttribute(defaultAuth,"identityAdopter")
					getSIBAuthUsersGroups(sibProperties,identityAdopterAuth,"%s.sibauthspace.default.identityAdopter" % (prefix))
					
					receiverAuth = AdminConfig.showAttribute(defaultAuth,"receiver")
					getSIBAuthUsersGroups(sibProperties,receiverAuth,"%s.sibauthspace.default.receiver" % (prefix))
					
					senderAuth = AdminConfig.showAttribute(defaultAuth, "sender")
					getSIBAuthUsersGroups(sibProperties,senderAuth,"%s.sibauthspace.default.sender" % (prefix))
	except:
		_app_trace("Error getting SIBAuthSpace properties","exception")
	
	_app_trace("getAuthSpaceProperties()","exit")
	
	return sibProperties
	
#----------------------------------------------------------------------------------
# getBusProperties
# 
# Returns the current settings for the SIBus as Properties object with the "app.sibus"
# prefix.
#
# Parameters;
#			bus - ID of the bus
#     force - controls whether certain properties are not immediately loaded
#----------------------------------------------------------------------------------
def getBusProperties(bus, force=0):

    _app_trace("getBusProperties(%s,%d)" % (bus, force), "entry")
    
    try:

      result = {}
      
      if (force == 0):
          result["app.sibus.delayedLoad"] = "true"
      else:
          result["app.sibus.delayedLoad"] = "false"
      
      prefix = "app.sibus"
      busName = AdminConfig.showAttribute(bus,'name')
      result["%s.name" % prefix] = busName
      collectSimpleProperties(result, "%s.prop" % prefix, bus, ['name'])
      
      
      custprops=AdminConfig.showAttribute(bus,"properties")
      if (not isEmpty(custprops)):
          for cpropsitem in wsadminToList(custprops):
              cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
              cpropname = AdminConfig.showAttribute(cpropsitem,"name")
              cpropval = AdminConfig.showAttribute(cpropsitem,"value")
              if isEmpty(cpropdesc):
                  result["%s.customProperties.prop.%s" % (prefix,   cpropname)] = cpropval
              else:
                  result["%s.customProperties.prop.%s" % (prefix,   cpropname)] = "%s|%s" %(cpropval,cpropdesc)
      
      if (force):
          getBusMemberAndMessageEngineProperties(result, bus, busName,prefix,force)
          
      if (force):
          getSIBDestinationMediationProperties(result,busName, prefix)  
          getSIBQueueProperties(result,busName, prefix)
          getSIBTopicProperties(result,busName, prefix)
          
    except:
        _app_trace("Error loading bus information","exception")
    
    
    _app_trace("getBusProperties(result = %d properties)"% len(result), "exit")
    
    
    
    return result
		

#enddef getBusProperties
