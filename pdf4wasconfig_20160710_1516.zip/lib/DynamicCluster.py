


# Create a dynamic cluster
def createDynamicCluster(clusterName, dynamicProperties, clusterProperties, customProperties=None):
  
  _app_trace("createDynamicCluster(%s,%s,%s,%s)"%(clusterName, dynamicProperties, clusterProperties, customProperties),"entry")
  
  dynamicClusterId = None
  clusterId = None
  
  try:
    
    if (dynamicProperties == None):
      dynamicProperties = {}
    
    if (clusterProperties == None):
      clusterProperties = {}
    
    if (customProperties == None):
      customProperties = {}
    
    # Accept various map formats, force them to Jython dictionaries
    dynamicProperties = toDictionary(dynamicProperties)
    clusterProperties = toDictionary(clusterProperties)
    customProperties = toDictionary(customProperties)
    
    # Do some validation
    minInstances = dynamicProperties.get("minInstances","1")
    if (str(minInstances) != "0"):
      if (dynamicProperties.has_key("serverInactivityTime")):
        del dynamicProperties["serverInactivityTime"]
    
    
    # Build out the argument strings
    membershipPolicy = dynamicProperties.get("membershipPolicy","node_nodegroup = 'DefaultNodeGroup'")
    if (dynamicProperties.has_key("membershipPolicy")):
      del dynamicProperties["membershipPolicy"]
    
    dcArgs = []
    for key in dynamicProperties.keys():
      val = dynamicProperties[key]
      dcArgs.append([key,val])
    
    clusterArgs = []
    for key in clusterProperties.keys():
      val = clusterProperties[key]
      clusterArgs.append([key,val])
    
    argList = [ "-membershipPolicy", membershipPolicy, "-dynamicClusterProperties", dcArgs, "-clusterProperties", clusterArgs ]
    
    
    if (dynamicProperties.get("serverType") == "ONDEMAND_ROUTER"):
      _app_trace("About to call AdminTask.createODRDynamicCluster(%s,%s)" % (clusterName, argList))
      retval =  AdminTask.createODRDynamicCluster(clusterName, argList)
      _app_trace("AdminTask.createODRDynamicCluster retval is %s" % retval)
    else:
      _app_trace("About to call AdminTask.createDynamicCluster(%s,%s)" % (clusterName, argList))
      retval =  AdminTask.createDynamicCluster(clusterName, argList)
      _app_trace("AdminTask.createDynamicCluster retval is %s" % retval)
    
    dynamicClusterId = AdminConfig.getid("/DynamicCluster:%s/" % clusterName)
    clusterId = AdminConfig.getid("/ServerCluster:%s/" % clusterName)
    
    if (len(customProperties) > 0):
      errMsg = updateCustomProperties(dynamicClusterId, "properties", "Property", customProperties)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update custom properties on dynamic cluster %s: %s" % (clusterName,errMsg))
  
  except:
    _app_trace("Unexpected error in createDynamicCluster","exception")
    raise StandardError("Unexpected error in createDynamicCluster","exception")

  _app_trace("createDynamicCluster(retval=%s,%s)" % (dynamicClusterId, clusterId),"exit")
  return dynamicClusterId,clusterId
  
def updateDynamicCluster(dynamicClusterId,clusterName,dynamicClusterProperties,dynamicClusterCustomProperties):
  _app_trace("updateDynamicCluster(%s,%s,%s)" % (dynamicClusterId,dynamicClusterProperties,dynamicClusterCustomProperties),"entry")
  try:
    if (dynamicClusterProperties != None and len(dynamicClusterProperties) > 0):
      # Here we are going to use AdminTask in case there are side effects to the updates
      dynamicClusterProperties = toDictionary(dynamicClusterProperties)
      
      # Step 1 - see if we need invoke modifyDynamicClusterIsolationProperties
      isolationGroup = dynamicClusterProperties.get("isolationGroup",None)
      strictIsolationEnabled = dynamicClusterProperties.get("strictIsolationEnabled",None)
      
      args = []
      if (isolationGroup != None):
        args.extend(["-isolationGroup", isolationGroup])
      if (strictIsolationEnabled != None):
        args.extend(["-strictIsolationEnabled", strictIsolationEnabled])
      
      if (len(args) > 0):
        _app_trace("About to call AdminTask.modifyDynamicClusterIsolationProperties(%s,%s)" % (clusterName, args))
        AdminTask.modifyDynamicClusterIsolationProperties(clusterName, args)
        
      # Step 2 - setDynamicClusterOperationalMode
      operationalMode = dynamicClusterProperties.get("operationalMode",None)
      if (operationalMode != None):
        args = ["-operationalMode", operationalMode]
        _app_trace("About to call AdminTask.setDynamicClusterOperationalMode(%s,%s)"% (clusterName, args))
        AdminTask.setDynamicClusterOperationalMode(clusterName, args)
      
      # Step 3 - setDynamicClusterMembershipPolicy
      membershipPolicy = dynamicClusterProperties.get("membershipPolicy",None)
      if (membershipPolicy != None):
        args = ['-membershipPolicy', membershipPolicy]
        _app_trace("About to call AdminTask.setDynamicClusterMembershipPolicy(%s,%s)" %(clusterName,args))
        AdminTask.setDynamicClusterMembershipPolicy(clusterName,args)
      
      # Step 4 setDynamicClusterMinInstances
      minInstances = dynamicClusterProperties.get("minInstances",None)
      if (minInstances != None):
        args = ['-minInstances',minInstances]
        _app_trace("About to call AdminTask.setDynamicClusterMinInstances(%s,%s)" % (clusterName,args))
        AdminTask.setDynamicClusterMinInstances(clusterName,args)
      
      # Step 5
      maxInstances = dynamicClusterProperties.get("maxInstances",None)
      if (maxInstances != None):
        args = ['-maxInstances',maxInstances]
        _app_trace("About to call AdminTask.setDynamicClusterMaxInstances(%s,%s)" % (clusterName,args))
        AdminTask.setDynamicClusterMaxInstances(clusterName,args)
      
      # Step 6 setDynamicClusterVerticalInstances
      numVerticalInstances = dynamicClusterProperties.get("numVerticalInstances",None)
      if (numVerticalInstances != None):
        args = ["-numVerticalInstances",numVerticalInstances]
        _app_trace("About to call AdminTask.setDynamicClusterVerticalInstances(%s,%s)" % (clusterName, args))
        AdminTask.setDynamicClusterVerticalInstances(clusterName, args)
      
      # Step 7 setDynamicClusterMaxNodes
      maxNodes = dynamicClusterProperties.get("maxNodes",None)
      if (maxNodes != None):
        args = ["-maxNodes",maxNodes]
        _app_trace("About to call AdminTask.setDynamicClusterMaxNodes(%s,%s)" % (clusterName,args))
        AdminTask.setDynamicClusterMaxNodes(clusterName,args)
      
      minNodes = dynamicClusterProperties.get("minNodes",None)
      if (minNodes != None):
        args = ["-minNodes",minNodes]
        _app_trace("About to call AdminTask.setDynamicClusterMinNodes(%s,%s)" % (clusterName,args))
        AdminTask.setDynamicClusterMinNodes(clusterName,args)
        
    if (dynamicClusterCustomProperties != None and len(dynamicClusterCustomProperties) > 0):
      errMsg = updateCustomProperties(dynamicClusterId, "properties", "Property", dynamicClusterCustomProperties)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update custom properties on dynamic cluster %s: %s" % (dynamicClusterId,errMsg))
      
  except:
    _app_trace("Unexpected error in updateDynamicCluster()","exception")
    raise StandardError("Unexpected error in updateDynamicCluster()")
  
  _app_trace("updateDynamicCluster()","exit")
  
  
#-------------------------------------------------------------------------------
# getDynamicClusterProperties
#
# Return settings of DynamicCluster as "dc.prop.xxx" and custom properties as "dc.properties.prop"
#-------------------------------------------------------------------------------
def getDynamicClusterProperties(dynamicClusterId):
  _app_trace("getDynamicClusterProperties(%s)" % (dynamicClusterId), "entry")
  retval = None
  try:
    retval = collectSimpleProperties(None, "dc.prop",dynamicClusterId, ["name"])
    
    collectCustomProperties(retval,"dc.properties", dynamicClusterId, attributeName="properties")
    
  except:
    _app_trace("Exception in getDynamicClusterProperties(%s)" % (dynamicClusterId), "exception")
    raise StandardError("Exception in getDynamicClusterProperties(%s)" % (dynamicClusterId))
  
  _app_trace("getDynamicClusterProperties(%s)" %retval,"exit")
  return retval
  
  
#-------------------------------------------------------------------------------
# findMatchingDynamicClusters
#
# Parameters:
#   clusterPattern - a regexp pattern to use
#
# Returns:
#   A list of (clusterName,dynamicId,clusterId) tupples that match the pattern
#-------------------------------------------------------------------------------
def findMatchingDynamicClusters(clusterPattern):
  _app_trace("findMatchingClusters(%s)" %(clusterPattern),"entry")
  import re
  retval = []
  try:
    tempList = None
    try:
      tempList = AdminConfig.list("DynamicCluster").split(progInfo["line.separator"])
    except:
      tempList = []
      
    for tempId in tempList:
      if (isEmpty(tempId)): continue
      matchId = None
      clusterId = None
      
      tempName = AdminConfig.showAttribute(tempId,"name")
      if (clusterPattern.find("*") >= 0):
        # Do regexp comparison
        if (re.match(clusterPattern,tempName)):
          matchId = tempId
      else:
        # Just treat as name search
        if (clusterPattern == tempName):
          matchId = tempId
      
      if (matchId != None):
        clusterId = AdminConfig.getid("/ServerCluster:%s/" % tempName)
        retval.append( (tempName,matchId, clusterId))
    #endfor    
  except:
    _app_trace("Unexpected error in findMatchingClusters","exception")
    raise StandardError("Unexpected error in findMatchingClusters")
    
  _app_trace("findMatchingClusters(retval=%s)" %retval,"exit")
  return retval