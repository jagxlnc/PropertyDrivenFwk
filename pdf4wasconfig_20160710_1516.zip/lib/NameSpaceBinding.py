##########################################################################################
# NameSpaceBinding.py
#
# Contains utility functions for creating,updating,finding, and getting properties for
# a NameSpaceBinding configuration.
##########################################################################################


#-----------------------------------------------------------------------------------------
# createNameSpaceBinding
#
# Parameters:
#   scopeId - Configuration ID of scope object (cell,node,cluster,server)
#   bindingType - The type of binding to be creating
#   bindingName - The name of the binding 
#   bindingProperties - A Properties object or dictionary containing the attributes
#   bindingCustomProperties - An optional Properties object that contain the settings
#                             for the otherCtxProperties custom properties of an
#                             IndirectLookupNameSpaceBinding
#-----------------------------------------------------------------------------------------
def createNameSpaceBinding(scopeId, bindingType, bindingName, bindingProperties, bindingCustomProperties=None):

	_app_trace("createNameSpaceBinding(%s,%s,%s,%s,%s)" % (scopeId, bindingType, bindingName, bindingProperties, bindingCustomProperties), "entry")
	retval = None
	
	try:
	
		attrs = "[name %s]" % bindingName
		for key in bindingProperties.keys():
				if (key == "name"):
						continue
				val = bindingProperties.get(key)
				if (key == "description" and not val.startswith("'") and not val.startswith('"')):
						val = '"%s"' % val
				if (key == "stringToBind" and not val.startswith("'") and not val.startswith('"')):
						val = '"%s"' % val
				if (key == "applicationNodeName" and val == "None"):
						val = "''"
				
				if (val == "[]"):
						val = "''"
				
				if (val == ""):
						val = "''"
				
				attrs = "%s [%s %s]" % (attrs,key,val)		
		
		attrs = "[ %s ]" % attrs
		
		_app_trace("About to call AdminConfig.create(%s,%s,%s)" % (scopeId, bindingType, attrs))
		retval = AdminConfig.create(bindingType, scopeId, attrs)
		
		if (not isEmpty(retval)):
				if (bindingType == "IndirectLookupNameSpaceBinding" and bindingCustomProperties != None and bindingCustomProperties.size() > 0):
						errMsg = updateCustomProperties(retval, "otherCtxProperties", "Property", bindingCustomProperties)
						if (not isEmpty(errMsg)):
								raise StandardError("Error creating custom properties for NameSpaceBinding: %s" % errMsg)
	
	except:
		_app_trace("Error creating name space binding","exception")
		retval = None



	_app_trace("createNameSpaceBinding(retval = %s)" % retval , "exit")
	return retval


#-----------------------------------------------------------------------------------------
# updateNameSpaceBinding
#
# Updates an existing Name Space Binding configuration.
#
# Parameters:
#   bindingId - Configuration ID of NameSpaceBinding to be updated
#   bindingProperties - A Properties object or dictionary containing the attributes
#   bindingType - The type of binding to be creating (optional, needed if IndirectLookupNameSpaceBinding
#                  custom properties need to be updated)
#   bindingCustomProperties - An optional Properties object that contain the settings
#                             for the otherCtxProperties custom properties of an
#                             IndirectLookupNameSpaceBinding
#-----------------------------------------------------------------------------------------
def updateNameSpaceBinding(bindingId, bindingProperties, bindingType = None, bindingCustomProperties=None):

	_app_trace("updateNameSpaceBinding(%s,%s,%s,%s)" % (bindingId, bindingProperties, bindingType, bindingCustomProperties), "entry")
	retval = None
	
	try:
	
		attrs = ""
		for key in bindingProperties.keys():
				if (key == "name"):
						continue
				val = bindingProperties.get(key)
				
				
				if (key == "description" and not val.startswith("'") and not val.startswith('"')):
						val = '"%s"' % val
				if (key == "stringToBind" and not val.startswith("'") and not val.startswith('"')):
						val = '"%s"' % val
				if (key == "applicationNodeName" and val == "None"):
						val = "''"				
				if (val == "[]"):
						val = "''"
				
				if (val == ""):
						val = "''"
				
				attrs = "%s [%s %s]" % (attrs,key,val)		
		
		attrs = "[ %s ]" % attrs
		
		if (modifyObject(bindingId,attrs)):
				raise StandardError("Error updating binding")
		else:
				retval = bindingId
		
		if (not isEmpty(retval)):
				if (bindingType == "IndirectLookupNameSpaceBinding" and bindingCustomProperties != None and bindingCustomProperties.size() > 0):
						errMsg = updateCustomProperties(retval, "otherCtxProperties", "Property", bindingCustomProperties)
						if (not isEmpty(errMsg)):
								raise StandardError("Error updating custom properties for NameSpaceBinding: %s" % errMsg)
	
	except:
		_app_trace("Error updating name space binding","exception")
		retval = None

	_app_trace("updateNameSpaceBinding(retval = %s)" % retval , "exit")
	return retval

#----------------------------------------------------------------------------------------
# checkForExistingNameSpaceBinding
#
# Returns the ID of the NameSpaceBinding with the specified name and scope
# "" is returned if the NameSpaceBinding does not exist
# "ERROR" is returned if a processing error occurs
#----------------------------------------------------------------------------------------
def checkForExistingNameSpaceBinding(cluster, node, server, bindingType, bindingName):

	retval = None
	global progInfo
	
	_app_trace("checkForExistingNameSpaceBinding(%s,%s,%s,%s,%s)" % (cluster, node, server, bindingType, bindingName),"entry")
	
	try:
		if (not isEmpty(cluster)):
				retval = AdminConfig.getid("/ServerCluster:%s/%s:%s/" % (cluster, bindingType, bindingName))
		elif (not isEmpty(server) and not isEmpty(node)):
				retval = AdminConfig.getid("/Node:%s/Server:%s/%s:%s/" % (node, server, bindingType, bindingName))
		elif (not isEmpty(node)):
				retval = AdminConfig.getid("/Node:%s/%s:%s/" % (node, bindingType, bindingName))
		elif (isEmpty(cluster) and isEmpty(node) and isEmpty(server)):
				# Cell scoped
				# Need cell name
				cellName = ""
				cells = AdminConfig.list("Cell").split(progInfo["line.separator"])
				for cell in cells:
						cellName = AdminConfig.showAttribute(cell,"name")
						break
				retval = AdminConfig.getid("/Cell:%s/%s:%s" % (cellName, bindingType, bindingName))
    
	
	except:
		_app_trace("Error checking for NameSpaceBinding", "exception")
		retval = "ERROR"
	
	_app_trace("checkForExistingNameSpaceBinding(retval=%s)"%retval, "exit")
	return retval

#------------------------------------------------------------------------------------------
# getNameSpaceBindingProperties
# 
# Returns the attributes of a NameSpaceBinding in properties format
# app.wasnsb.nsb.type =
# app.wasnsb.nsb.prop.name = Binding name
# app.wasnsb.nsb.prop.key = val
#
# For IndirectLookupNameSpaceBinding types:
# app.wasnsb.nsb.otherCtxProperties.prop.key = val
#------------------------------------------------------------------------------------------
def getNameSpaceBindingProperties(bindingId):
	
	_app_trace("getNameSpaceBindingProperties(%s)" %(bindingId), "entry")
	results = java.util.Properties()
	
	try:
	
		collectSimpleProperties(results, "app.wasnsb.nsb.prop",bindingId)
	
		if (results.get("app.wasnsb.nsb.prop.corbanameUrl") != None):
			results.put("app.wasnsb.nsb.type", "CORBAObjectNameSpaceBinding")
		elif (results.get("app.wasnsb.nsb.prop.ejbJndiName") != None):
			results.put("app.wasnsb.nsb.type", "EjbNameSpaceBinding")
		elif (results.get("app.wasnsb.nsb.prop.jndiName") != None):
			results.put("app.wasnsb.nsb.type", "IndirectLookupNameSpaceBinding")
			
			custprops=AdminConfig.showAttribute(bindingId,"otherCtxProperties")
			
			if (not isEmpty(custprops)):
				for cpropsitem in wsadminToList(custprops):
					cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
					cpropname = AdminConfig.showAttribute(cpropsitem,"name")
					cpropval = AdminConfig.showAttribute(cpropsitem,"value")
					if isEmpty(cpropdesc):
						results.put("app.wasnsb.nsb.otherCtxProperties.prop.%s" % (cpropname), cpropval)
					else:
						results.put("app.wasnsb.nsb.otherCtxProperties.prop.%s" % (cpropname), "%s|%s" % (cpropval,cpropdesc))
		elif (results.get("app.wasnsb.nsb.prop.stringToBind") != None):
	 		results.put("app.wasnsb.nsb.type", "StringNameSpaceBinding")
	
	except:
		_app_trace("Unexpected error getting NameSpacingBinding properties", "exception")
		results = None
	
	_app_trace("getNameSpaceBindingProperties(%s)" %(results), "exit")
	return results