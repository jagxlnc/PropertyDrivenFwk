################################################################################
# CustomActions.py
#
# Requires: Utils.py
#
# Utility methods for CRUD operations involving Custom Actions used in
# Intelligent Management Health Policies and also the Elasticity Custom Actions
# used by the Application Placement controller
################################################################################



#-------------------------------------------------------------------------------
# createHealthManagementCustomAction
#
# Parameters:
#    actionName
#    actionType (NamedProcessDef or NamedJavaProcessDef)
#    actionProps - dictionary containing attributes of actionType
#
# Returns configuration ID of the created CustomProcessDefs
#-------------------------------------------------------------------------------
def createHealthManagementCustomAction(actionName,actionType,actionProps):
  _app_entry("createHealthManagementCustomAction(%s,%s,actionProps)" % (actionName,actionType))
  retval = None
  
  try:
    attrs = [ ["name",actionName]] 
    retval = AdminConfig.create("CustomProcessDefs",getCellId(),attrs)
    
    for key in actionProps.keys():
      if (key == "name"):
        continue
      attrs.append([key,actionProps[key]])
      
    AdminConfig.create(actionType,retval,attrs)
  except:
    _app_exception("Unexpected error in createHealthManagementCustomAction(%s,%s,actionProps)" % (actionName,actionType))
  
  _app_exit("createHealthManagementCustomAction(retval = %s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# updateHealthManagementCustomAction 
#
#  Parameters:
#    actionID - configuration ID of the CustomProcessDefs 
#    actionType - (NamedProcessDef or NamedJavaProcessDef)
#    actionProps - dictionary containing attributes of actionType
#
#-------------------------------------------------------------------------------
def updateHealthManagementCustomAction(actionID,actionType,actionProps):
  _app_entry("updateHealthManagementCustomAction(%s,%s,actionProps)" % (actionID,actionType))
  try:
    definitions = wsadminToList(AdminConfig.showAttribute(actionID,"definitions"))
    
    # Utility method handles list and password logic
    modifyObjectProperties(definitions[0],actionProps,configurationType=actionType)
    
  except:
    _app_exception("Unexpected error in updateHealthManagementCustomAction()")
  
  _app_exit("updateHealthManagementCustomAction()")

#-------------------------------------------------------------------------------
# deleteHealthManagementCustomAction
#    Removes the specified action from the configuration. Returns the configuration
#    ID of the CustomProcessDefs that was removed, None if it did not exist
#-------------------------------------------------------------------------------
def deleteHealthManagementCustomAction(actionName):
  _app_entry("deleteHealthManagementCustomAction(%s)" % actionName)
  retval = None
  try:
    retval = findHealthManagementCustomAction(actionName)
    if (not isEmpty(retval)):
      AdminConfig.remove(retval)
  except:
    _app_exception("Unexpected error in deleteHealthManagementCustomAction(%s)" % actionName)
  
  _app_exit("deleteHealthManagementCustomAction(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# findHealthManagementCustomAction
#
#    Returns the configuration name of the CustomProcessDefs 
#    configuration item of the specified custom action. Returns None
#    if does not exist
#
#  Parameters:
#     actionName - name to lookup
#-------------------------------------------------------------------------------
def findHealthManagementCustomAction(actionName):
  _app_entry("findCustomerAction(%s)" % actionName)
  retval = None
  
  try:
    actionList = AdminConfig.list("CustomProcessDefs").splitlines()
    for ca in actionList:
      if (isEmpty(ca)):
        continue
      
      if (ca.find(actionName) >= 0):
        # confirm that name matches
        caName = AdminConfig.showAttribute(ca,"name")
        if (caName == actionName):
          retval = ca
          break
      
  except:
    _app_exception("Unexpected error in findHealthManagementCustomAction")
  
  _app_exit("findHealthManagementCustomAction(retval=%s)" % retval)
  
  return retval
#enddef

#-------------------------------------------------------------------------------
# getHealthManagementCustomActionProperties
# 
# Returns a dictionary with the configuration properties of the action
#   customAction.definitions.type - specifies the configuration type
#   customAction.definitions.prop.XXX - specifies the value of property XXX
#-------------------------------------------------------------------------------
def getHealthManagementCustomActionProperties(actionID):
  _app_entry("getHealthManagementCustomActionProperties(%s)" % (actionID))
  retval = {}
  try:
    definitions = wsadminToList(AdminConfig.showAttribute(actionID,"definitions"))
    retval["customAction.definitions.type"] = callGetObjectType(definitions[0])
    collectSimpleProperties(retval,"customAction.definitions.prop",definitions[0],getSimpleChildren=1,collectPropertyAttributes=1,useAttrNameWithProperties=1)
  except:
    _app_exception("Unexpected error in getHealthManagementCustomActionProperties(%s)" % actionID)

  _app_exit("getHealthManagementCustomActionProperties()")
  return retval
  
#enddef

#-------------------------------------------------------------------------------
# createElasticityCustomAction
#
# Parameters:
#    actionName
#    actionType (NamedProcessDef or NamedJavaProcessDef)
#    actionProps - dictionary containing attributes of actionType
#
# Returns configuration ID of the created ElasticityCustomProcessDefs
#-------------------------------------------------------------------------------
def createElasticityCustomAction(actionName,actionType,actionProps):
  _app_entry("createElasticityCustomAction(%s,%s,actionProps)" ,actionName,actionType)
  retval = None
  
  try:
    attrs = [ ["name",actionName]] 
    retval = AdminConfig.create("ElasticityCustomProcessDefs",getCellId(),attrs)
    
    for key in actionProps.keys():
      if (key == "name"):
        continue
      attrs.append([key,actionProps[key]])
    
      
    AdminConfig.create(actionType,retval,attrs)
  except:
    _app_exception("Unexpected error in createElasticityCustomAction(%s,%s,actionProps)" % (actionName,actionType))
  
  _app_exit("createElasticityCustomAction(retval = %s)" % retval)
  return retval



#-------------------------------------------------------------------------------
# updateElasticityCustomAction 
#
#  Parameters:
#    actionID - configuration ID of the ElasticityCustomProcessDefs 
#    actionType - (NamedProcessDef or NamedJavaProcessDef)
#    actionProps - dictionary containing attributes of actionType
#
#-------------------------------------------------------------------------------
def updateElasticityCustomAction(actionID,actionType,actionProps):
  _app_entry("updateElasticityCustomAction(%s,%s,actionProps)",actionID,actionType)
  try:
    definitions = wsadminToList(AdminConfig.showAttribute(actionID,"definitions"))
    
    # Utility method handles list and password logic
    modifyObjectProperties(definitions[0],actionProps,configurationType=actionType)
    
  except:
    _app_exception("Unexpected error in updateElasticityCustomAction()")
  
  _app_exit("updateElasticityCustomAction()")


#-------------------------------------------------------------------------------
# deleteElasticityCustomAction
#    Removes the specified action from the configuration. Returns the configuration
#    ID of the ElasticityCustomProcessDefs that was removed, None if it did not exist
#-------------------------------------------------------------------------------
def deleteElasticityCustomAction(actionName):
  _app_entry("deleteElasticityCustomAction(%s)",actionName)
  retval = None
  try:
    retval = findElasticityCustomAction(actionName)
    if (not isEmpty(retval)):
      AdminConfig.remove(retval)
  except:
    _app_exception("Unexpected error in deleteElasticityCustomAction(%s)" % actionName)
  
  _app_exit("deleteElasticityCustomAction(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# findElasticityCustomAction
#
#    Returns the configuration name of the ElasticityCustomProcessDefs 
#    configuration item of the specified custom action. Returns None
#    if does not exist
#
#  Parameters:
#     actionName - name to lookup
#
#  Returns configuration ID of ElasticityCustomProcessDefs, empty string if not found
#-------------------------------------------------------------------------------
def findElasticityCustomAction(actionName):
  _app_entry("findCustomerAction(%s)" , actionName)
  retval = None
  
  try:
    retval =  AdminConfig.getid("/ElasticityCustomProcessDefs:%s/" % actionName)
    
  except:
    _app_exception("Unexpected error in findElasticityCustomAction")
  
  _app_exit("findElasticityCustomAction(retval=%s)" % retval)
  
  return retval
#enddef



#-------------------------------------------------------------------------------
# getElasticityCustomActionProperties
# 
# Returns a dictionary with the configuration properties of the action
#   customAction.definitions.type - specifies the configuration type
#   customAction.definitions.prop.XXX - specifies the value of property XXX
#-------------------------------------------------------------------------------
def getElasticityCustomActionProperties(actionID):
  _app_entry("getElasticityCustomActionProperties(%s)" ,actionID)
  retval = {}
  try:
    definitions = wsadminToList(AdminConfig.showAttribute(actionID,"definitions"))
    retval["customAction.definitions.type"] = callGetObjectType(definitions[0])
    collectSimpleProperties(retval,"customAction.definitions.prop",definitions[0],getSimpleChildren=1,collectPropertyAttributes=1,useAttrNameWithProperties=1)
  except:
    _app_exception("Unexpected error in getElasticityCustomActionProperties(%s)" % actionID)

  _app_exit("getElasticityCustomActionProperties()")
  return retval
  
#enddef


