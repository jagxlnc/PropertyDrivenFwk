################################################################################
#  URIGroup.py - provides methods for manipulating URIGroup configuration items
# 
#  Requires: Utils.py, common.py
# 
################################################################################

#-------------------------------------------------------------------------------
# findURIGroup
#
# Parameters
#    uriGroupName - Name of URIGroup to look up
# 
# Returns:
#    configuration ID of URIGroup, if exists, empty string otherwise
#-------------------------------------------------------------------------------
def findURIGroup(uriGroupName):
  _app_entry("findURIGroup(%s)" , uriGroupName)
  retval = None
  try:
    retval = AdminConfig.getid("/URIGroup:%s/" % uriGroupName)
  except:
    _app_exception("Unexpected problem in findURIGroup()")
  
  _app_exit("findURIGroup(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# getURIGroupProperties - return a dictionary with properties of 
#  URIGroup
#
# Parameters
#    uriGroupId - configuration ID of URIGroup
#    uriGroupName - Name of URIGroup to look up if ID is not supplied
#
# Returns:
#   dictionary with uriGroup.prop.XXXX key/value pairs 
#-------------------------------------------------------------------------------
def getURIGroupProperties(uriGroupId=None,uriGroupName=None):
  _app_entry("getURIGroupProperties(%s,%s)",uriGroupId,uriGroupName)
  retval = {}
  try:
    if (isEmpty(uriGroupId)):
      uriGroupId = findURIGroup(uriGroupName)
    
    if (not isEmpty(uriGroupId)):
      collectSimpleProperties(retval,"uriGroup.prop",uriGroupId)
  except:
    _app_exception("Unexpected problem in getURIGroupProperties()")
  
  _app_exit("getURIGroupProperties(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# createURIGroup - create a new URIGroup
#
# Parameters
#    uriGroupName - Name of URIGroup to create
#    ugProps - dictionary with URIGroup attributes 
#
# Returns:
#    Configuration ID of new URIGroup
#-------------------------------------------------------------------------------
def createURIGroup(uriGroupName,ugProps):
  _app_entry("createURIGroup(%s,%s)" , uriGroupName,ugProps)
  retval = None
  try:
    attrs =  [["name",uriGroupName]]
    attrs.extend(propsToAttrList(ugProps))
    
    _app_trace('About to call AdminConfig.create("URIGroup",%s,%s)' % (getCellId(),attrs))
    retval = AdminConfig.create("URIGroup",getCellId(),attrs)
  except:
    _app_exception("Unexpected problem in createURIGroup()")
  
  _app_exit("createURIGroup(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# updateURIGroup - update an existing URIGroup
#
# Parameters
#   uriGroupId - Configuration ID of URIGroup to update
#   ugProps - dictionary with attributes to update
#   clearURIPatterns - if 1, then URIPatterns will be cleared before updated
#                      otherwise value in ugProps will be merged in
#-------------------------------------------------------------------------------
def updateURIGroup(uriGroupId,ugProps,clearURIPatterns=0):
  _app_entry("updateURIGroup(%s,%s,%d)" , uriGroupId,ugProps,clearURIPatterns)
  retval = None
  try:
    if (clearURIPatterns):
      attrs = " [ URIPatterns [] ] "
      if(modifyObject(uriGroupId,attrs)):
        raise StandardError("Unable to clear URIPatterns attribute")
      
    attrs = propsToAttrList(ugProps)
    if (len(attrs) > 0):
       if (modifyObject(uriGroupId,attrs)):
         raise StandardError("Unable to update URIGroup %s" % uriGroupId)
 
  except:
    _app_exception("Unexpected problem in updateURIGroup()")
  
  _app_exit("updateURIGroup(retval=%s)" % retval)
  return retval
    