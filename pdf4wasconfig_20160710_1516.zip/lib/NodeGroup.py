################################################################################
# NodeGroup.py - utility methods for manipulating Node Group configurations
#
# Requires: Utils.py, common.py
#
# Functions in this module:
#
#     createNodeGroup(ngName,baseProps,customProps,members)
#     deleteNodeGroup(ngName)
#     updateNodeGroupSettings(ngId,baseProps,customProps=None)
#     addNodeGroupMember(ngName,memberNode,customProps=None)
#     removeNodeGroupMember(ngName,memberNode)
#     updateNodeGroupMemberCustomProperties(memberId,customProps)
#     getNodeGroupId(ngName)
#     getNodeGroupProperties(ngId=None,ngName=None)
#
################################################################################


# 
# AdminTask methods for manipulating NodeGroups
#addNodeGroupMember - add node to the node group
#canNodeJoinNodeGroup - Check if a specified node can be added to a specified node group.
#checkDynamicClustersForNodeGroupRemoval - Check Node Group for XD Dynamic Clusters
#convertToSysplexNodeGroup - Converts to a sysplex node group
#createNodeGroup - create a node group
#createNodeGroupProperty - add a custom property for a node group
#createSysplexNodeGroup - create sysplex node group
#listNodeGroupProperties - list properties of a node group
#listNodeGroups - list node groups containing given node, or list all node groups if no target node is given
#modifyNodeGroup - modify a node group configuration
#modifyNodeGroupProperty - modify the property of a node group
#removeNodeFromNodeGroups - remove a given node from node groups
#removeNodeGroup - remove a node group from the configuration.
#removeNodeGroupMember - remove a member from the node group.
#removeNodeGroupProperty - remove a property from a node group


#-------------------------------------------------------------------------------
# createNodeGroup
#
# Parameters
#    Returns dictionary of IDs:
#       NODE_GROUP_ID = Configuration ID of node group
#       nodeName = NodeGroupMember ID 
#-------------------------------------------------------------------------------
def createNodeGroup(ngName,baseProps,customProps,members): 
  _app_entry("createNodeGroup(%s,%s,%s,%s)" , ngName,baseProps,customProps,members)
  retval = {}
  try:
    #some stuff
    parms = ""
    if (baseProps != None and len(baseProps) > 0):
      
      for key in baseProps.keys():
        if key == "name":continue
        parms = "%s -%s '%s' " % (parms,key,baseProps[key])
      
    parms = "[ %s ]"% parms
    
    _app_trace('About to call AdminTask.createNodeGroup(%s,%s)'% (ngName,parms))
    ngId = AdminTask.createNodeGroup(ngName,parms)
    retval["NODE_GROUP_ID"] = ngId
     
    
    if (customProps != None and len(customProps) > 0):
      errMsg = updateCustomProperties(ngId, "properties", "Property", customProps)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update custom properties on NodeGroup %s" % (ngName,errMsg))
    
    if (members != None and len(members) > 0):
      for nodeName in members:
        memberId = addNodeGroupMember(ngName,nodeName)
        retval[nodeName] = memberId
      
        
  except:
    _app_exception("Unexpected problem in createNodeGroup()")
  
  _app_exit("createNodeGroup(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# deleteNodeGroup
#
# Parameters
#   ngName - Name of Node Group to delete
#-------------------------------------------------------------------------------
def deleteNodeGroup(ngName):
  _app_entry("deleteNodeGroup(%s)" , ngName)
  retval = None
  try:
    ngId = getNodeGroupId(ngName)
    if (not isEmpty(ngId)):
      retval = ngId
      
      
      
      members = AdminConfig.showAttribute(ngId,"members")
      if (not isEmpty(members)):
        memberList = wsadminToList(members)
        for memberId in memberList:
          mName = AdminConfig.showAttribute(memberId,"nodeName")
          removeNodeGroupMember(ngName,mName)
          
      _app_trace('About to call AdminTask.removeNodeGroup(%s)' % ngName)
      AdminTask.removeNodeGroup(ngName)
    else:
      _app_trace("Node Group %s does not exist" % ngName)
  except:
    _app_exception("Unexpected problem in deleteNodeGroup()")
  
  _app_exit("deleteNodeGroup(retval=%s)" % retval)
  return retval
  

#-------------------------------------------------------------------------------
# updateNodeGroupSettings
#
# Parameters
#   ngId - Node Group Configuration Id
#   baseProps - dictionary containing base properties to update
#   customProps - dictionary containing custom properties to update
#-------------------------------------------------------------------------------
def updateNodeGroupSettings(ngId,baseProps,customProps=None):
  _app_entry("updateNodeGroupSettings(%s,%s,%s)" , ngId,baseProps,customProps)
  retval = ngId
  try:
    if (baseProps != None and len(baseProps) > 0):
      attrs = propsToAttrList(baseProps,skipList = ["name"])
      if (len(attrs) > 0):
        if (modifyObject(ngId,attrs)):
          raise StandardError("Problem updating nodegroup %s" % ngId)
    
    if (customProps != None and len(customProps) > 0):
      errMsg = updateCustomProperties(ngId, "properties", "Property", customProps)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update custom properties for %s: %s" % (ngId,errMsg))
  except:
    _app_exception("Unexpected problem in updateNodeGroupSettings()")
  
  _app_exit("updateNodeGroupSettings(retval=%s)" % retval)
  return retval
  




#-------------------------------------------------------------------------------
# addNodeGroupMember
#
# Parameters
#     ngName - name of node group
#     memberNode - name of node group member
#     
# Returns member ID
#-------------------------------------------------------------------------------
def addNodeGroupMember(ngName,memberNode,customProps=None):
  _app_entry("addNodeGroupMember(%s,%s)",ngName,memberNode)
  retval = None
  try:
     args = "[-nodeName %s]" % memberNode
     _app_trace("About to call AdminTask.addNodeGroupMember(%s,%s)" % (ngName,args))
     retval = AdminTask.addNodeGroupMember(ngName,args)
     
     if (customProps != None and len(customProps) > 0):
        updateNodeGroupMemberCustomProperties(retval,customProps)
  except:
    _app_exception("Unexpected problem in addNodeGroupMember()")
  
  _app_exit("addNodeGroupMember(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# removeNodeGroupMember
#
# Parameters
#     ngName - Name of Node Group
#     memberNode - name of node to be removed
#-------------------------------------------------------------------------------
def removeNodeGroupMember(ngName,memberNode):
  _app_entry("removeNodeGroupMember(%s,%s)" , ngName,memberNode)
  retval = None
  try:
    args = "[ -nodeName %s ]" % memberNode
    _app_trace('About to call AdminTask.removeNodeGroupMember(%s,%s)' % (ngName,args))
    AdminTask.removeNodeGroupMember(ngName,args)
  except:
    _app_exception("Unexpected problem in removeNodeGroupMember()")
  
  _app_exit("removeNodeGroupMember(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# updateNodeGroupMemberCustomProperties
#
# Parameters
#     memberId - Configuration ID of Node Group Member
#     customProps - dictionary of custom properties in key=val[|desc] syntax
#-------------------------------------------------------------------------------
def updateNodeGroupMemberCustomProperties(memberId,customProps):
  _app_entry("updateNodeGroupMemberCustomProperties(%s,%s)" ,memberId,customProps)
  retval = None
  try:
    #some stuff
    errMsg = updateCustomProperties(memberId, "properties", "Property", customProps)
    if (not isEmpty(errMsg)):
      raise StandardError("Unable to update custom properties for %s: %s" % (memberId,errMsg))
  except:
    _app_exception("Unexpected problem in updateNodeGroupMemberCustomProperties()")
  
  retval = memberId
  
  _app_exit("updateNodeGroupMemberCustomProperties(retval=%s)" % retval)
  return retval
    

#-------------------------------------------------------------------------------
# getNodeGroupId
#
# Parameters
#    ngName - Name of Node Group to look up
#
# Returns:
#     Configuration ID of Node Group
#-------------------------------------------------------------------------------
def getNodeGroupId(ngName):
  _app_entry("getNodeGroupId(%s)" , ngName)
  retval = None
  try:
    #some stuff
    retval = AdminConfig.getid("/NodeGroup:%s/" % ngName)
  except:
    _app_exception("Unexpected problem in getNodeGroupId(%s)"%ngName)
  
  _app_exit("getNodeGroupId(retval=%s)" % retval)
  return retval
  
  
#-------------------------------------------------------------------------------
# getNodeGroupProperties
#
# Parameters
#
# Returns dictionary with following keys:
#    nodegroup.prop.XXXX - base porperties of node group
#    nodegroup.properties.prop.YYYY - custom properties of node group
#    MEMBERS_DICTIONARY - Another dictionary of dictionaries, where the keys are node names
#      and the dictionary contains the following values
#        nodegroup.prop.ZZZZ - base properties of nodegroupmember 
#        nodegroup.properties.prop.AAAA - custom properties of nodegroup member
#-------------------------------------------------------------------------------
def getNodeGroupProperties(ngId=None,ngName=None):
  _app_entry("getNodeGroupProperties(%s)" , ngId)
  retval = {}
  nestedIds = {}
  memberDict = {}
  try:
    
    if (isEmpty(ngId) and not isEmpty(ngName)):
      ngId = getNodeGroupId(ngName)
    
    collectSimpleProperties(retval, "nodegroup.prop",ngId, optionalSkipList=[],idProps=nestedIds,getSimpleChildren=0,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=0,getChildType=0)
    
    if (len(nestedIds) > 0):
      members = nestedIds.get("nodegroup.prop.members","")
      if (not isEmpty(members)):
        memberList = wsadminToList(members)
        for memberId in memberList:
           memberProps = {}
           collectSimpleProperties(memberProps, "nodegroupmember.prop",memberId, optionalSkipList=[],idProps=nestedIds,getSimpleChildren=0,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=0,getChildType=0)
           memberProps["ID"] = memberId
           memberDict[memberProps.get("nodegroupmember.prop.nodeName")] = memberProps
           
  
    retval["MEMBERS_DICTIONARY"] = memberDict
             
  except:
    _app_exception("Unexpected problem in getNodeGroupProperties()")
  
  _app_exit("getNodeGroupProperties(retval=%s)" % retval)
  return retval