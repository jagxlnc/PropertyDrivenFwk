###################################################################################################
# ProcessJAASAliases.py
# 
# This module contains the functions that process the J2C Authentication Alias properties in the
# global configInfo dictionary.

# Primary Function:
#     processJAASAliases()
#
# Related Modules:
#    JAASAlias.py - functions for creating J2C AuthenticationAlias entries
#		 Utils.py - utility functions
# 
# Property Syntax:
# app.j2c.aliases.<index>.alias = <Alias name>
# app.j2c.aliases.<index>.userId = <Alias user ID>
# app.j2c.aliases.<index>.password = <Password value, can be clear text, encoded xor value or @{DYNAMIC#DECRYPT#encryptedstring} >
# app.j2c.aliases.<index>.description = <alias description>
# # allowUpdate is an optional field that can be used to prevent updates to existing (default is allow update)
# app.j2c.aliases.<index>.allowUpdate = <true|false>
# ...
# Alternative syntax - The credentials syntax allows dynamic lookup of user ID and password from a
# repository. The object returned from the @DYNAMIC must have getUserId and getPassword methods
# app.j2c.aliases.<index>.alias = <Alias name>
# app.j2c.aliases.<index>.description = <alias description>
# app.j2c.aliases.<index>.credentials = @{DYNAMIC#CREDENTIALRETRIEVER#app|hhrr|env|credbsrv|creddbname}
# ...
# app.j2c.aliases.count = <count>
###################################################################################################



#---------------------------------------------------------------------------------------------------
# processJAASAliases
#
# Processes the J2C Authentication Alias definitions in the configInfo dictionary.
#---------------------------------------------------------------------------------------------------
def processJAASAliases():
  
	global configInfo
  
	if not configInfo.has_key("app.j2c.aliases.count"):
		_app_message("Skipping Building JAAS Aliases....")
		return

	_app_message("Building JAAS Aliases....")

	#	Create JAAS Aliases
	for jidx in range(1, int(configInfo["app.j2c.aliases.count"]) + 1):
		try:
			alias	 	= configInfo["app.j2c.aliases.%d.alias" % (jidx)]
		except:
			_app_message("Skipping J2C alias app.j2c.aliases.%d.alias" % (jidx))
			continue
	
		alias = substituteDynamicValues("alias",alias)
		
	
		description=userid=password=""
			
		if (configInfo.has_key("app.j2c.aliases.%d.description" % (jidx))):
				description	= configInfo["app.j2c.aliases.%d.description" % (jidx)]
	
		userid		= configInfo.get("app.j2c.aliases.%d.userId" % (jidx),"")
		password	= configInfo.get("app.j2c.aliases.%d.password" % (jidx),"")
		
		
		
		
		allowUpdate = configInfo.get("app.j2c.aliases.%d.allowUpdate" % (jidx),"true")
		
		# Dynamic credential lookup
		credentials =  configInfo.get("app.j2c.aliases.%d.credentials" % (jidx),"")
		if (not isEmpty(credentials)):
				credentialsObj = substituteDynamicValues("credentials",credentials)
				userid = credentialsObj.getUserId()
				password = credentialsObj.getPassword()
				
				if (userid == None or password == None):
						# Something has gone wrong
						_app_message("Error retrieving credentials for alias %s" % alias)
						exit()
						
				
		elif (not isEmpty(password,1)):
				# Dynamic variable support for password
				password = substituteDynamicValues("password",password)
				
				if (password == None):
						_app_message("Password is unknown for alias %s" % alias)
						exit()

		#[["alias", aliasName], ["description", description], ["userId", userID], ["password", userPW]]
		existingId = checkForExistingJAASAlias(alias)
		if (not isEmpty(existingId)):
				if (allowUpdate == "false"):
						# Skip this update
						_app_message("Skipping update of existing J2C Authentication Alias %s" % alias)
						continue
		
		
				# Update existing
				currentUserId = AdminConfig.showAttribute(existingId,"userId")
				currentDescription = AdminConfig.showAttribute(existingId,"description")
				
				trcstring = "Updating alias %s" % alias
				attrs = []
				
				if (not isEmpty(userid) and currentUserId != userid):
						attrs.append(["userId", userid])
						
						trcstring = "%s [userId %s]" % (trcstring, userid)
						
				if (not isEmpty(description) and currentDescription != description):
						attrs.append(["description",description])
						trcstring = "%s [description %s]" % (trcstring, description)
						
				if (not isEmpty(password,1) and password != "*****"):
						attrs.append(["password",password])
						trcstring = "%s [password ???????]" % (trcstring)
						
						
				
				if (len(attrs) > 0):
						# Use modifyObject minimum tracing option
						_app_trace("Modifying object %s %s" % (existingId, trcstring))
						if (modifyObject(existingId,attrs,1)):
								_app_message("Failed to update J2C Authentication Alias %s" % alias)
								exit()
						else:
								_app_message("Modified existing J2C Authentication Alias %s" % alias)
				else:
						_app_message("No need to update existing J2C Authentication Alias %s" % alias)
			
				continue
				
		# end if existing
			
		#_app_message("Creating J2C Authentication Alias %s" % (alias))
		# Check for required fields
		if (isEmpty(userid)):
				_app_message("Missing required user ID value for alias %s" % alias)
				exit()
		
		if (isEmpty(password,1)):
				_app_message("Missing required password value for alias %s" % alias)
				exit()
				
		if isEmpty(createJAASAlias(alias, description, userid, password)):
			_app_message("Failed to create J2C Authentication Alias %s" % (alias))
			exit()
		else:
			_app_message("Created J2C Authentication Alias %s" % (alias))
