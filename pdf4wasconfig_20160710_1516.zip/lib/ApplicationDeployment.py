###################################################################################
# ApplicationDeployment.py
#
# This module contains utility methods for finding and loading Application deployment
# configuration items.  This is the set of configuration items that are manipulated
# after an application is deployed and does not involve functionality related to AdminApp.
#
# Related modules:
# 		Utils.py - Utility methods
#     ApplicationServer.py - Used for SessionManager properties
#
###################################################################################


#---------------------------------------------------------------------------------
# getApplicationDeployment
#---------------------------------------------------------------------------------
def getApplicationDeployment(appName):

	_app_trace("getApplicationDeployment(%s)" % (appName),"entry")
	retval = None
	try:
		deploymentId = AdminConfig.getid("/Deployment:%s/" % appName)
		if (isEmpty(deploymentId)):
				raise StandardError("Unable to find Deployment for application %s" % appName)
		
		retval = AdminConfig.showAttribute(deploymentId,"deployedObject")
	
	except:
		_app_trace("Error finding ApplicationDeployment","exception")
		retval = None
	
	_app_trace("getApplicationDeployment(retval = %s)"% retval,"exit")
	return retval
	
#--------------------------------------------------------------------------------------
# getModuleDeployedObjectConfig
#--------------------------------------------------------------------------------------
def getModuleDeployedObjectConfig(moduleId, configType):

	retval = None
	_app_trace("getModuleDeployedObjectConfig(%s,%s)" %(moduleId, configType),"entry")
	
	configs = wsadminToList(AdminConfig.showAttribute(moduleId,"configs"))
	for config in configs:
			if (config.find(configType) >= 0):
					retval = config
					break

	_app_trace("getModuleDeployedObjectConfig(retval = %s)" % retval, "exit")
	return retval


#--------------------------------------------------------------------------------------
# findApplicationModule
#--------------------------------------------------------------------------------------	
def findApplicationModule(applicationId, moduleUri, moduleType):

	retval = None
	_app_trace("findApplicationModule(%s,%s,%s)" % (applicationId, moduleUri, moduleType),"entry")
	
	try:
		modules = wsadminToList(AdminConfig.showAttribute(applicationId,"modules"))
		for module in modules:
			if (module.find(moduleType) >= 0):
					try:
						tempUri = AdminConfig.showAttribute(module,"uri")
						if (tempUri == moduleUri):
								retval = module
					except:
						pass
					if (retval != None):
						break
	except:
		_app_trace("Error finding application submodule","exception")
		retval = None
	
	_app_trace("findApplicationModule(retval = %s)" % retval,"exit")
	return retval


#--------------------------------------------------------------------------------------
# Find the DeploymentTargetMapping configuration for a DeployedObject that has the 
# MappingTarget with the specified name (and optional nodeName)
# moduleDeploymentId - Id of deployment to search under
# searchTargetName - Name of MappingTarget to search for
# searchTargetNode  - Optional node of Mapping Target to search for
# deployedObjectUri - Uri of object (if MODULE)
#--------------------------------------------------------------------------------------
def findDeploymentTargetMapping(moduleDeploymentId, searchTargetName, searchTargetNode=None):

	_app_trace("findTargetMapping(%s,%s,%s)" % (moduleDeploymentId, searchTargetName, searchTargetNode),"entry")
	retval = None
	try:
		targetMappingList = wsadminToList(AdminConfig.showAttribute(moduleDeploymentId,"targetMappings"))
		tmidx = 0
		for targetMapping in targetMappingList:
			if (isEmpty(targetMapping)):
					continue
					
			deploymentTarget = AdminConfig.showAttribute(targetMapping, "target")
			targetName = AdminConfig.showAttribute(deploymentTarget,"name")
			if (targetName == searchTargetName):
					if (isEmpty(searchTargetNode)):
							retval = targetMapping
							break
					else:
							# See if we have a node attribute
							try:
								targetNodeName = AdminConfig.showAttribute(deploymentTarget,"nodeName")
								if (targetNodeName == searchTargetNode):
										retval = targetMapping
										break
							except:
								pass
		
	except:
		_app_trace("Exception searching for matching TargetMapping")
		retval = None
	
	_app_trace("findTargetMapping(retval = %s)" % retval, "exit")
	return retval



#--------------------------------------------------------------------------------------
# findEnterpriseBeanConfig
#--------------------------------------------------------------------------------------
def findEnterpriseBeanConfig(moduleConfigId, beanName, beanConfigType):

	retval = None
	_app_trace("findEnterpriseBeanConfigs(%s,%s,%s)" % (moduleConfigId, beanName, beanConfigType),"entry")
	
	try:
	
		enterpriseBeanConfigs = AdminConfig.showAttribute(moduleConfigId,"enterpriseBeanConfigs")
		if (not isEmpty(enterpriseBeanConfigs)):
				enterpriseBeanConfigsList = wsadminToList(enterpriseBeanConfigs)
				beanIdx = 0
				for enterpriseBeanConfig in enterpriseBeanConfigsList:
						if (enterpriseBeanConfig.find(beanConfigType) >= 0):
								# See if we have a match for bean name
								if (beanName == AdminConfig.showAttribute(enterpriseBeanConfig,"ejbName")):
										retval = enterpriseBeanConfig
										break
	
	except:
		_app_trace("Error searching for EnterpriseBeanConfig","exception")
		raise StandardError("Error searching for EnterpriseBeanConfig")
	
	_app_trace("findEnterpriseBeanConfigs(retval = %s)" % retval,"exit")
	return retval

#--------------------------------------------------------------------------------------
# getDeploymentTargetMappingProperties
#
# Returns the properties for DeploymentTargetMapping configuration.
#--------------------------------------------------------------------------------------
def getDeploymentTargetMappingProperties(targetMapping):

	_app_trace("getDeploymentTargetMappingProperties(%s)" % (targetMapping),"entry")
	retval = None
	
	try:
		retval = java.util.Properties()

		deploymentTarget = AdminConfig.showAttribute(targetMapping, "target")
		if (not isEmpty(deploymentTarget)):
					
			retval.put("targetMapping.enable",AdminConfig.showAttribute(targetMapping,"enable"))
			collectSimpleProperties(retval,"targetMapping.target.prop", deploymentTarget)
			
			DeployedObject = AdminConfig.showAttribute(targetMapping,"DeployedObject")
			if (not isEmpty(DeployedObject)):
					
					try:
						retval.put("targetMapping.DeployedObject.prop.uri",AdminConfig.showAttribute(DeployedObject,"uri"))
						retval.put("targetMapping.DeployedObject.type","MODULE")
					except:
						retval.put("targetMapping.DeployedObject.type","APPLICATION")
					
			config = AdminConfig.showAttribute(targetMapping, "config")
			if (not isEmpty(config)):
					collectSimpleProperties(retval,"targetMapping.config.prop", config, [])
		
	except:
		_app_trace("Error getting DeploymentTargetMapping properties","exception")
		retval = None
	
	_app_trace("getDeploymentTargetMappingProperties()","exit")
	return retval


#--------------------------------------------------------------------------------------
# getEnterpriseBeanConfigProperties
#--------------------------------------------------------------------------------------
def getEnterpriseBeanConfigProperties(beanConfigId):
	_app_trace("getEnterpriseBeanConfigProperties(%s)" % beanConfigId, "entry")
	try:
			retval = java.util.Properties()
			try:
				timeout = AdminConfig.showAttribute(beanConfigId,"timeout")
				retval.put("enterpriseBeanConfig.type" , "StatefulSessionBeanConfig")
			except:
				retval.put("enterpriseBeanConfig.type" , "SessionBeanConfig")
							
			collectSimpleProperties(retval,"enterpriseBeanConfig.prop" , beanConfigId,[])
									
			instancePool = AdminConfig.showAttribute(beanConfigId,"instancePool")
			if (not isEmpty(instancePool)):
					collectSimpleProperties(retval,"enterpriseBeanConfig.instancePool.prop" , instancePool,[])
		
	except:
		_app_trace("Error getting EnterpriseBeanConfig properties","exception")
		raise StandardError("Error getting EnterpriseBeanConfig properties")
	
	_app_trace("getEnterpriseBeanConfigProperties()", "exit")
	return retval

#--------------------------------------------------------------------------------------
# getModuleDeployedObjectConfigProperties
#--------------------------------------------------------------------------------------
def getModuleDeployedObjectConfigProperties(configId, configType): 

	_app_trace("getModuleDeployedObjectConfigProperties(%s,%s)" % (configId, configType), "entry")
	try:
		retval = java.util.Properties()
		
		retval.put("config.type", configType)
		collectSimpleProperties(retval, "config.prop", configId, [])
		
		if (configType == "ApplicationConfig"):
				drsSettings = AdminConfig.showAttribute(configId,"drsSettings")
				if (not isEmpty(drsSettings)):
						collectSimpleProperties(retval, "config.drsSettings.prop", drsSettings, [])
				
				sessionManagement = AdminConfig.showAttribute(configId,"sessionManagement")
				if (not isEmpty(sessionManagement)):
						getSessionManagerProperties(retval,sessionManagement,"config.sessionManagement")
		elif (configType == "WebModuleConfig"):
				sessionManagement = AdminConfig.showAttribute(configId,"sessionManagement")
				if (not isEmpty(sessionManagement)):
						getSessionManagerProperties(retval,sessionManagement,"config.sessionManagement")
		elif (configType == "EJBModuleConfiguration"):
				drsSettings = AdminConfig.showAttribute(configId,"drsSettings")
				if (not isEmpty(drsSettings)):
						collectSimpleProperties(retval, "config.drsSettings.prop", drsSettings, [])
								
				enterpriseBeanConfigs = AdminConfig.showAttribute(configId,"enterpriseBeanConfigs")
				if (not isEmpty(enterpriseBeanConfigs)):
						enterpriseBeanConfigsList = wsadminToList(enterpriseBeanConfigs)
						beanIdx = 0
						for enterpriseBeanConfig in enterpriseBeanConfigsList:
							if (isEmpty(enterpriseBeanConfig)):
									continue
									
							beanIdx = beanIdx + 1
							try:
								timeout = AdminConfig.showAttribute(enterpriseBeanConfig,"timeout")
								retval.put("config.enterpriseBeanConfigs.%d.type" % (beanIdx), "StatefulSessionBeanConfig")
							except:
								retval.put("config.enterpriseBeanConfigs.%d.type" % (beanIdx), "SessionBeanConfig")
									
							collectSimpleProperties(retval,"config.enterpriseBeanConfigs.%d.prop" % (beanIdx), enterpriseBeanConfig,[])
									
							instancePool = AdminConfig.showAttribute(enterpriseBeanConfig,"instancePool")
							if (not isEmpty(instancePool)):
									collectSimpleProperties(retval,"config.enterpriseBeanConfigs.%d.instancePool.prop" % (beanIdx), instancePool,[])
						retval.put("config.enterpriseBeanConfigs.count", "%s" % (beanIdx))
		
	
	except:
		_app_trace("Error pulling configuration properties for module","exception")
		raise StandardError("Error pulling configuration properties for module")
		
	_app_trace("getModuleDeployedObjectConfigProperties(retval = %s)" % retval,"exit")
	return retval


#--------------------------------------------------------------------------------------	
# collectModuleClassloaderProperties
#--------------------------------------------------------------------------------------	
def collectModuleClassloaderProperties(props,prefix,cldr):

	_app_trace("collectModuleClassloaderProperties(props,%s,%s)" % (prefix,cldr),"entry")

	try:
		global progInfo
		clmode = AdminConfig.showAttribute(cldr,"mode")
					
		props.put("%s.prop.mode" % prefix, clmode)
		libRefIdx = 0
		libraryRefs = AdminConfig.list("LibraryRef", cldr).split(progInfo["line.separator"])
		for libraryRef in libraryRefs:
				if (isEmpty(libraryRef)):
						continue
				libRefIdx = libRefIdx+1
				libraryName = AdminConfig.showAttribute(libraryRef,"libraryName")
				sharedClassloader = AdminConfig.showAttribute(libraryRef,"sharedClassloader")
							
				props.put("%s.libraries.%d.prop.libraryName" % (prefix,   libRefIdx), libraryName)
				props.put("%s.libraries.%d.prop.sharedClassloader" % (prefix,   libRefIdx), sharedClassloader)
							
		props.put("%s.libraries.count" % (prefix), "%s" % libRefIdx)
	except:
		_app_trace("Error loading module classloader","exception")
		raise StandardError("Unable to load classloader properties")
	
	_app_trace("collectModuleClassloaderProperties()" , "exit")


#--------------------------------------------------------------------------------------	
# getModuleDeploymentProperties
#--------------------------------------------------------------------------------------	
def getModuleDeploymentProperties(moduleId, prefix):

	_app_trace("getModuleDeploymentProperties(%s,%s)" % (moduleId, prefix), "entry")
	try:
		retval = java.util.Properties()

		moduleTypes = [ "WebModuleDeployment", "ApplicationDeployment", "EJBModuleDeployment", "ConnectorModuleDeployment","ModuleDeployment" ]

		
		for moduleType in moduleTypes:
				if (moduleId.find(moduleType) >= 0):
						retval.put("%s.type" % prefix, moduleType)
						break
		
		try:
			retval.put("%s.uri" % prefix, AdminConfig.showAttribute(moduleId,"uri"))
		except:
			pass
		
		collectSimpleProperties(retval,"%s.prop" % prefix, moduleId, ["uri"],collectPropertyAttributes=1)
		
		try:
			classloaderid = AdminConfig.showAttribute(moduleId,"classloader")
		except:
			classloaderid = None
			pass
			
		if (not isEmpty(classloaderid)):
					collectModuleClassloaderProperties(retval, "%s.classloader" % prefix,classloaderid)

		
	except:	
		_app_trace("Error getting module properties","exception")
		retval = None
		
	_app_trace("getModuleDeploymentProperties(%s)" % retval,"exit")
	return retval
