#################################################################################
# Scheduler.py - Utility methods for finding, creating, and updating Scheduler
# configurations
#
# Primary functions:
#   createScheduler(schedulerName, schedulerProps, resourceProps=None,providerId=None,pCluster=None,pNode=None,pServer=None)
#   updateScheduler(schedulerId,props,resourceProps)
#   findSchedulerProviderAtScope(pCluster, pNode, pServer)
#   findSchedulerAtScope(pCluster, pNode, pServer, schedulerName)
#   findSchedulerWithName(schedulerName,schedulerProviderId)
#   findMatchingSchedulerProviders(clusterPattern=None, nodePattern=None, serverPattern=None)
#   findMatchingSchedulers(schedulerPattern,schedulerProviderId)
#   getSchedulerProperties(schedulerId)

#
#################################################################################


#---------------------------------------------------------------------
# createScheduler - Create a new scheduler at the specified scope.
#
# Parameters:
#     schedulerName - Name of Scheduler to create
#     schedulerProps - dictionary with settings for SchedulerConfiguration 
#     resourceProps - dictionary with settings for resource properties (key=type|required|val|description)
#     providerId - SchedulerProvider configuration ID that scheduler will be created or specify pCluster,pNode,pServer parameters
#     pCluster - Optional parameter used to search for SchedulerProvider at specified scope
#     pNode - Optional parameter used to search for SchedulerProvider at specified scope
#     pServer - Optional parameter used to search for SchedulerProvider at specified scope
#
# Returns:
#   Configuarion ID of new scheduler
#
# Throws error if invalid parameters or unexpected error
#
#---------------------------------------------------------------------
def createScheduler(schedulerName, schedulerProps, resourceProps=None,providerId=None,pCluster=None,pNode=None,pServer=None):
  _app_trace("createScheduler(%s,%s,%s,%s,%s,%s,%s)"% (schedulerName, schedulerProps, resourceProps,providerId,pCluster,pNode,pServer),"entry")
  retval = None
  try:
    if (providerId == None):
      # Look up the provider
      providerId = findSchedulerProviderAtScope(pCluster, pNode, pServer)
      if (isEmpty(providerId)):
        raise StandardError("Scheduler not provided and could not be found at scope c=%,n=%s,s=%s" % (pCluster, pNode, pServer))
    
    
    attrs = [["name",schedulerName]]
    for key in schedulerProps.keys():
      val = schedulerProps.get(key)
      attrs.append([key,val])
    
    _app_trace('About to call AdminConfig.create("SchedulerConfiguration",%s,%s)' %(providerId,attrs))
    retval = AdminConfig.create("SchedulerConfiguration",providerId,attrs)
    
    if (resourceProps != None and len(resourceProps) > 0):
      updateJ2EEResourcePropertySet(retval, resourceProps)
      
  except:
    _app_exception("Unexpected error in createScheduler(%s,...)" % schedulerName)
  
  _app_trace("createScheduler(retval = %s)" % retval,"exit")
  return retval
  
#---------------------------------------------------------------------
# updateScheduler
#
# Parameters:
#     schedulerId - Configuration of Scheduler to update
#     schedulerProps - dictionary with settings for SchedulerConfiguration 
#     resourceProps - dictionary with settings for resource properties (key=type|required|val|description)
#
# Throws error if invalid parameters or unexpected error
#
#---------------------------------------------------------------------
def updateScheduler(schedulerId,props,resourceProps):
  _app_trace("updateScheduler(%s,%s,%s)" % (schedulerId,props,resourceProps), "entry")
  
  attr = []
  try:
    for key in props.keys():
      if (key == "name"):
        continue
      val = props.get(key)  
      attr.append([key,val])
    
    if (len(attr) > 0):  
      if (modifyObject(schedulerId,attr)):
        raise StandardError("Unable to update scheduler %s with values %s" % (schedulerId,attr))
      
    if (resourceProps != None and len(resourceProps) > 0):
      updateJ2EEResourcePropertySet(schedulerId, resourceProps)
      
      
  except:
    _app_exception("Unexpected error in updateScheduler(%s)" % schedulerId)
  
  _app_trace("updateScheduler()","exit")

#--------------------------------------------------------------------------------------
# findSchedulerProviderAtScope
#
# Returns the ID of the Scheduler Provider with the specified scope.  Returns None or empty string
# if no match is found.
#--------------------------------------------------------------------------------------
def findSchedulerProviderAtScope(pCluster, pNode, pServer) :

  retval = None
  try:
  
    _app_trace("findSchedulerProviderAtScope(%s,%s,%s)" % (pCluster, pNode, pServer),"entry")
  
    global progInfo
    global configInfo
    
    pScope = ""

    if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
        pScope = "cell"
        cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
        for cell in cells:
            schedulerProviderId=AdminConfig.getid("/Cell:%s/SchedulerProvider:SchedulerProvider/" % AdminConfig.showAttribute(cell,"name"))
            retval = schedulerProviderId
            break
    else:
      if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer):
          pScope = "cluster"
   
          schedulerProviderId=AdminConfig.getid("/ServerCluster:%s/SchedulerProvider:SchedulerProvider/" % pCluster)
          retval = schedulerProviderId
          
      else:
        if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
            pScope = "node"
            
            schedulerProviderId=AdminConfig.getid("/Node:%s/SchedulerProvider:SchedulerProvider/" % pNode)
            retval = schedulerProviderId
                
        else:
            if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
                pScope = "server"
                server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
            
                schedulerProviderId=AdminConfig.getid("/Node:%s/Server:%s/SchedulerProvider:SchedulerProvider/" % (pNode,pServer))
                retval = schedulerProviderId

  except:
      _app_exception("Error searching for scheduler provider at scope %s%s:%s"%(pCluster, pNode, pServer))
      
  _app_trace("findSchedulerProviderAtScope(retval=%s)" % (retval),"exit")
  return retval




#--------------------------------------------------------------------------------------
# findSchedulerAtScope
#
# Returns the ID of the Scheduler with the specified name and scope.  Returns None if no match is
# found. Returns "ERROR" if an unexpected error occurs.
#--------------------------------------------------------------------------------------
def findSchedulerAtScope(pCluster, pNode, pServer, schedulerName) :

  retval = None
  try:
  
    _app_trace("findSchedulerAtScope(%s,%s,%s,%s)" % (pCluster, pNode, pServer, schedulerName),"entry")
  
    global progInfo
    global configInfo
    
    pScope = ""

    if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
        pScope = "cell"
        cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
        for cell in cells:
            schedulerProviderId=AdminConfig.getid("/Cell:%s/SchedulerProvider:SchedulerProvider/" % AdminConfig.showAttribute(cell,"name"))
            retval = findSchedulerWithName(schedulerName,schedulerProviderId)
            break
    else:
      if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer):
          pScope = "cluster"
          cluster = AdminConfig.getid("/ServerCluster:%s" % pCluster)
          schedulerProviderId=AdminConfig.getid("/ServerCluster:%s/SchedulerProvider:SchedulerProvider/" % AdminConfig.showAttribute(cluster,"name"))
          retval = findSchedulerWithName(schedulerName,schedulerProviderId)
          
      else:
        if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
            pScope = "node"
            node = AdminConfig.getid("/Node:%s" % pNode)
            schedulerProviderId=AdminConfig.getid("/Node:%s/SchedulerProvider:SchedulerProvider/" % pNode)
            if (not isEmpty(schedulerProviderId)):
                retval = findSchedulerWithName(schedulerName,schedulerProviderId)
            else:
                raise StandardError("SchedulerProvider not found at node scope %s" % pNode)
                
        else:
            if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
                pScope = "server"
                server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
            
                schedulerProviderId=AdminConfig.getid("/Server:%s/SchedulerProvider:SchedulerProvider/" % AdminConfig.showAttribute(server,"name"))
                if (not isEmpty(schedulerProviderId)):
                    retval = findSchedulerWithName(schedulerName,schedulerProviderId)
                else:
                    raise StandardError("SchedulerProvider not found at server scope %s:%s" % (pNode,pServer))

  except:
      _app_trace("Error searching for scheduler %s at scope %s%s:%s"%(schedulerName,pCluster, pNode, pServer),"exception")
      raise StandardError("Error searching for scheduler %s at scope %s%s:%s"%(schedulerName,pCluster, pNode, pServer))
      retval = "ERROR" 
  
  _app_trace("findSchedulerAtScope(retval=%s)" % (retval),"exit")
  return retval
  
#--------------------------------------------------------------------------------------
# findSchedulerWithName
#
# Returns the ID of the Scheduler with the specified name.  Returns None if no match is
# found. Returns "ERROR" if an unexpected error occurs.
#--------------------------------------------------------------------------------------
def findSchedulerWithName(schedulerName,schedulerProviderId):

    _app_trace("findSchedulerWithName(%s,%s)" % (schedulerName,schedulerProviderId),"entry")
    retval = None
    
    try:
    
        if (isEmpty(schedulerProviderId)):
            raise StandardError("SchedulerProvider Id not specified")
    
        if (isEmpty(schedulerName)):
            raise StandardError("scheduler Name is not specified")
        
        wmList = wsadminToList(AdminConfig.list("SchedulerConfiguration",schedulerProviderId))
        for wm in wmList:
            if (isEmpty(wm)):
                continue
            
            tempName = AdminConfig.showAttribute(wm,"name")
            if (tempName == schedulerName):
                retval = wm
                break
    except:
        _app_trace("Unexpected error looking for scheduler %s" % (schedulerName), "exception")
        raise StandardError("Unexpected error looking for scheduler %s" % (schedulerName))
        
    
    _app_trace("findSchedulerWithName(retval = %s)" % retval, "exit")
    return retval

##########################################################################################
# findMatchingSchedulerProviders
# 
# Return a list of providers that match the search criteria which can include wildcard
##########################################################################################
def findMatchingSchedulerProviders(clusterPattern=None, nodePattern=None, serverPattern=None):

   global progInfo
   retval = []
   namePattern = "SchedulerProvider"

   try:
    traceStr = "findMatchingSchedulerProviders(%s,%s,%s)" % (clusterPattern, nodePattern, serverPattern)
    _app_trace(traceStr, "entry")
    
    c = clusterPattern
    n = nodePattern
    s = serverPattern
    if (isEmpty(c) and isEmpty(n) and isEmpty(s)):
      providerEntries = AdminConfig.getid("/Cell:%s/SchedulerProvider:/" % AdminConfig.showAttribute(AdminConfig.getid("/Cell:/"),"name"))
    elif (not isEmpty(c) and c.find("*") == -1):
      # Not a wildcard cluster pattern
      providerEntries = AdminConfig.getid("/ServerCluster:%s/SchedulerProvider:/" % c )
    elif (not isEmpty(s) and not isEmpty(n) and s.find("*") == -1 and n.find("*") == -1 ):
      providerEntries = AdminConfig.getid("/Node:%s/Server:%s/SchedulerProvider:/" % (n,s))
    elif (not isEmpty(n) and isEmpty(s) and n.find("*") == -1):
      providerEntries = AdminConfig.getid("/Node:%s/SchedulerProvider:/" % (n))
    else:
      providerEntries = AdminConfig.getid("/SchedulerProvider:/")

    
    provider=None

    
    if (providerEntries != ""):
        providerEntryList=providerEntries.split(progInfo["line.separator"])
        
        retval = filterList(providerEntryList, "SchedulerProvider",clusterPattern,nodePattern,serverPattern)

   except:
      _app_trace("An error was encountered searching for the SchedulerProvider (%s,%s,%s)" % (clusterPattern, nodePattern, serverPattern), "exception")
      raise StandardError("An error was encountered searching for the SchedulerProvider (%s,%s,%s)" % (clusterPattern, nodePattern, serverPattern))

   _app_trace("findMatchingSchedulerProviders(%s)" %(retval), "exit")
   return retval




#--------------------------------------------------------------------------------------
# findMatchingSchedulers
#
# Returns the list of Scheduler Configuration IDs that match the specified name pattern.
# Returns empty list if no match is found.
# 
#--------------------------------------------------------------------------------------
def findMatchingSchedulers(schedulerPattern,schedulerProviderId):
    import re
    _app_trace("findMatchingSchedulers(%s,%s)" % (schedulerPattern,schedulerProviderId),"entry")
    retval = []
    
    try:
    
        if (isEmpty(schedulerProviderId)):
            raise StandardError("SchedulerProvider Id not specified")
    
        if (isEmpty(schedulerPattern)):
            raise StandardError("scheduler pattern is not specified")
        
        schedulerList = wsadminToList(AdminConfig.list("SchedulerConfiguration",schedulerProviderId))
        for schedulerId in schedulerList:
            if (isEmpty(schedulerId)):
                continue
            
            tempName = AdminConfig.showAttribute(schedulerId,"name")
            if (re.match(schedulerPattern, tempName)):
              retval.append(schedulerId)
    except:
        _app_trace("Unexpected error looking for scheduler %s" % (schedulerName), "exception")
        raise StandardError("Unexpected error looking for scheduler %s" % (schedulerName))
        
    
    _app_trace("findMatchingSchedulers(retval = %s)" % retval, "exit")
    return retval



#------------------------------------------------------------------------------------
# getSchedulerProperties
#
# Returns a property set with the attributes and custom properties of the scheduler
# The property prefixes returned are:
#     app.scheduler.prop
#     app.scheduler.resourceProperties.prop
#------------------------------------------------------------------------------------
def getSchedulerProperties(schedulerId):
    
    _app_trace("getSchedulerProperties(%s)" %(schedulerId), "entry")
    results = java.util.Properties()
    
    name = AdminConfig.showAttribute(schedulerId,"name")
    results.put("app.scheduler.name",name)
    collectSimpleProperties(results, "app.scheduler.prop" , schedulerId, ["name"])
    
    
    collectResourceProperties(results,schedulerId,"propertySet","app.scheduler")
        
    _app_trace("getSchedulerProperties(%d properties)" % results.size(), "exit")
    return results
