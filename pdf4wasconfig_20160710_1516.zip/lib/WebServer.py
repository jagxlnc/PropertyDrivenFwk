##########################################################################
# File Name:    WebServer.py
# Description:  This file contains function definitions to create, delete
#               and list WebServers
#
#               createWebServer
#               deleteWebServer
#               listWebServers
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createWebServer: Create a WebServer
#
# SYNTAX:
#    createWebServer name, nodeName, templateName, serverConfigAttrs, remoteAttrs 
#
# PARAMETERS:
#    name	-	Name of WebServer
#    nodeName	-	Name of Node
#    templateName-	Name of Template to Use
#    serverConfigAttrs 	- ServerConfig Attributes
#    remoteAttrs	- RemoteConfig Attributes
#
# USAGE NOTES:
#    Creates a Web Server named 'name' 
#
# RETURNS:
#    ObjID	Object ID of new WebServer
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addWebServer(name, nodeName, templateName, serverConfigAttrs, remoteAttrs):
	createWebServer(name, nodeName, templateName, serverConfigAttrs, remoteAttrs)
	
def createWebServer(name, nodeName, templateName, serverConfigAttrs, remoteAttrs):

	global progInfo

	retval = None

	try:
		traceStr = "createWebServer(%s, %s, %s, %s, %s)" % (name, nodeName, templateName, serverConfigAttrs, remoteAttrs)
		_app_trace(traceStr, "entry")	

		if isEmpty(name):
			raise StandardError("No name provided")

		if isEmpty(nodeName):
			raise StandardError("No Node Name provided")

		if isEmpty(templateName):
			raise StandardError("No TemplateName provided")

		if isEmpty(serverConfigAttrs):
			raise StandardError("No serverConfig Attributes provided")

		if isEmpty(remoteAttrs):
			raise StandardError("No remoteAttrs Attributes provided")

		#	Check it doesn't already exist 
		if existsWebServer(name,nodeName):
			raise StandardError("Cannot create %s, already exists at %s" % (name, nodeName))

		serverConfig=""
		for sc in serverConfigAttrs:
			serverConfig += "%s " % sc

		remoteConfig=""
		for sc in remoteAttrs:
			remoteConfig += "%s " % sc

		cmdStr = "-name %s -templateName %s -serverConfig [[%s]] -remoteServerConfig [[%s]]" % (name, templateName, serverConfig, remoteConfig)
		_app_trace("Running command: AdminTask.createWebServer('%s', '[%s]' )" % (nodeName, cmdStr))
		retval = AdminTask.createWebServer('%s' % nodeName, '[%s]' % cmdStr)

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
	except:
		_app_trace("An error was encountered creating the WebServer", "exception")
		retval = None

	_app_trace("createWebServer(%s)" %(retval), "exit")
	return retval

#------------------------------------------------------------------------------------------------------
def getWebServerPortInfo(nodeName,wsName):
      webPort = adminPort = ""
      se = AdminConfig.getid("/Cell:%s/Node:%s/ServerIndex:/ServerEntry:%s/" % (getCellName(),nodeName,wsName) )
      seps=wsadminToList(AdminConfig.showAttribute(se,"specialEndpoints"))
      for sep in seps:
          if ("WEBSERVER_ADDRESS" == AdminConfig.showAttribute(sep,"endPointName")):
              webPort = AdminConfig.showAttribute(AdminConfig.showAttribute(sep,"endPoint"),"port")
          if ("WEBSERVER_ADMIN_ADDRESS" == AdminConfig.showAttribute(sep,"endPointName")):
              adminPort = AdminConfig.showAttribute(AdminConfig.showAttribute( sep,"endPoint"),"port")
          if (not isEmpty(webPort) and not isEmpty(adminPort)):
            break
            
      return webPort, adminPort


#-------------------------------------------------------------------------------
# enableWebServerIntelligentManagement
#
# Parameters:
#   nodeName - node hosting the web server
#   serverName - the name of the web server
#   **imProperties - additonal IM properties to set. These are arguments to 
#                    AdminTask.enableIntelligentManagement
#-------------------------------------------------------------------------------				
def enableWebServerIntelligentManagement(nodeName,serverName,**imProperties):
  _app_trace("enableWebServerIntelligentManagement(%s,%s,%s)" %(nodeName,serverName,imProperties),"entry")
  retval = None
  try:
    args = "-node %s -webserver %s " % (nodeName,serverName)
    if (imProperties != None and len(imProperties) > 0):
      for key in imProperties.keys():
        val = imProperties.get(key)
        if (val.startswith("-")):
          val = '"%s"' % val
        args = "%s -%s %s" % (args,key,val)
        
    _app_trace('About to call AdminTask.enableIntelligentManagement("[ %s ]")' % args)
    retval = AdminTask.enableIntelligentManagement("[ %s ]" % args)
  except:
    _app_exception("Unexpected error in enableWebServerIntelligentManagement(%s,%s)" % (nodeName,serverName))
    
  _app_trace("enableWebServerIntelligentManagement(retval = %s)","exit")
  return retval

#------------------------------------------------------------------------------------------------------
# disableWebServerIntelligentManagement
#
# Parameters:
#   nodeName - node hosting the web server
#   serverName - the name of the web server
#
# Turns off the intelligent management feature for the webserver plug-in. Settings are not deleted.
#------------------------------------------------------------------------------------------------------
def disableWebServerIntelligentManagement(nodeName,serverName):
  _app_trace("disableWebServerIntelligentManagement(%s,%s)" % (nodeName,serverName),"entry")
  try:
    _app_trace('About to call AdminTask.disableIntelligentManagement("[ -node %s -webserver %s ]")' % (nodeName,serverName))
    AdminTask.disableIntelligentManagement("[ -node %s -webserver %s ]" % (nodeName,serverName))
  except:
    _app_exception("Unexpected error in disableWebServerIntelligentManagement(%s,%s)" % (nodeName,serverName))
  _app_trace("disableWebServerIntelligentManagement()","exit")

#------------------------------------------------------------------------------------------------------
# modifyWebServerIntelligentManagement
#
# Parameters:
#   nodeName - node hosting the web server
#   serverName - the name of the web server
#   **imProps - dictionary containing properties to be set. Contains arguments to 
#                 AdminTask.modifyIntelligentManagement
#------------------------------------------------------------------------------------------------------  
def modifyWebServerIntelligentManagement(nodeName,serverName,**imProps):
  retval =None
  _app_trace("modifyWebServerIntelligentManagement(%s,%s,%s)" % (nodeName,serverName,imProps),"entry")
  try:
    if (imProps != None and len(imProps) > 0):
      args = "-node %s -webserver %s " % (nodeName,serverName)
      if (imProps != None and len(imProps) > 0):
        for key in imProps.keys():
          val = imProps.get(key)
          if (val.startswith("-")):
            val = '"%s"' % val
          args = "%s -%s %s" % (args,key,val)
      
      _app_trace('About to call AdminTask.modifyIntelligentManagement("[ %s ]")' % args)
      retval = AdminTask.modifyIntelligentManagement("[ %s ]" % args)
        
      
  except:
    _app_exception("Unexpected error in modifyWebServerIntelligentManagement(%s,%s,%s)" % (nodeName,serverName,imProps))
    
  _app_trace("modifyWebServerIntelligentManagement(retval=%s)" % retval,"exit")

#------------------------------------------------------------------------------------------------------
# setWebServerIntelligentManagmentPluginProperties 
#
# Sets custom properties for the Intelligent Management feature of the plug-in. If properties already
# exist they will be updated.
#
# Parameters:
#   nodeName - node hosting the web server
#   serverName - the name of the web server
#   **pluginProperties - a dictionary containing the property key/value pairs to set
#------------------------------------------------------------------------------------------------------
def setWebServerIntelligentManagmentPluginProperties(nodeName,serverName,**pluginProperties):
  _app_trace("setWebServerIntelligentManagmentPluginProperties(%s,%s,%s)" % (nodeName,serverName,pluginProperties),"entry")
  try:
    if (pluginProperties != None and len(pluginProperties) > 0):
      for key in pluginProperties.keys():
        args = "[-node %s -webserver %s -name %s -value %s ]" % (nodeName,serverName,key,pluginProperties.get(key))
        
        _app_trace("About to call AdminTask.addPluginPropertyForIntelligentManagement(%s)" % args)
        AdminTask.addPluginPropertyForIntelligentManagement(args)
  except:
    _app_exception("Unexpected error in setWebServerIntelligentManagmentPluginProperties(%s,%s,%s)" % (nodeName,serverName,pluginProperties))
    
  _app_trace("setWebServerIntelligentManagmentPluginProperties()","exit")

#-------------------------------------------------------------------------------
# removeWebServerIntelligentManagementPluginProperties
#
# Removes the specified properties from the Intelligent Management plugin properties
#-------------------------------------------------------------------------------
def removeWebServerIntelligentManagementPluginProperties(nodeName, serverName, *properties):
  _app_trace("removeWebServerIntelligentManagementPluginProperties(%s,%s,%s)" % (nodeName, serverName, properties),"entry")
  try:
    for propName in properties:
      if (isEmpty(propName)):
        continue
      
      parms = "[ -node %s -webserver %s -name %s]" % (nodeName,serverName,propName)
      _app_trace('About to call AdminTask.removePluginPropertyForIntelligentManagement(%s)' % parms)
      AdminTask.removePluginPropertyForIntelligentManagement(parms)
  except:
    _app_exception("Unexpected error in removeWebServerIntelligentManagementPluginProperties(%s,%s,%s)" % (nodeName, serverName, properties))
  
  _app_trace("removeWebServerIntelligentManagementPluginProperties()","exit")
  

#--------------------------------------------------------------------------------
# addWebServerIntelligentManagementRemoteCell
#   nodeName - node hosting the web server
#   serverName - the name of the web server
#   host - host of the remote cell
#   port - administration port of the remote cell
#   userid - userid used to connect to remote cell(optional)
#   password - password used to connect to remote cell (optional)
#   **options - dictionary containing options to be set. The keys should be 
#               arguments to AdminTask.addRemoteCellToIntelligentManagement()
#--------------------------------------------------------------------------------
def addWebServerIntelligentManagementRemoteCell(nodeName,serverName,host,port,userid,password,**options):
  _app_trace("addWebServerIntelligentManagementRemoteCell(%s,%s,%s,%s,%s,password,%s)" %(nodeName,serverName,host,port,userid,options),"entry")
  retval = None
  try:
    parms = "-node %s -webserver %s -host %s -port %s" % (nodeName,serverName,host,port)
    if (not isEmpty(password)):
      parms = "%s -userid %s -password %s" % (parms,userid,password)
    
    if (options != None and len(options) > 0):
      for key in options.keys():
        val = options[key]
        if (key == "enabled"):
          key = "enable"
        parms = "%s -%s %s" % (parms, key, val)
    
    _app_trace("About to call AdminTask.addRemoteCellToIntelligentManagement(-node %s -webserver %s -host %s -port %s ......)" % (nodeName,serverName,host,port))
    retval = AdminTask.addRemoteCellToIntelligentManagement("[ %s ]" % parms)
  except:
    _app_exception("Unexpected error in addWebServerIntelligentManagementRemoteCell()")
  
  _app_trace("addWebServerIntelligentManagementRemoteCell(retval=%s)" % retval,"exit")
  return retval

#-------------------------------------------------------------------------------
# modifyWebServerIntelligentManagementRemoteCell
#
# Modify the settings of an existing remote cell configuration. Host and port
# values are used to identify the existing remote cell.
#
#   nodeName - node hosting the web server
#   serverName - the name of the web server
#   host - host of the remote cell
#   port - administration port of the remote cell
#   **options - dictionary containing options to be set. The keys should be 
#               arguments to AdminTask.modifyRemoteCellForIntelligentManagement()
#-------------------------------------------------------------------------------  
def modifyWebServerIntelligentManagementRemoteCell(nodeName,serverName,host,port,**options):
  _app_trace("modifyWebServerIntelligentManagementRemoteCell(%s,%s,%s,%s,%s)" % (nodeName,serverName,host,port,options), "entry")

  retval = None
  try:
    parms = "-node %s -webserver %s -host %s -port %s" % (nodeName,serverName,host,port)
    
    if (options != None and len(options) > 0):
      for key in options.keys():
        val = options[key]
        if (key == "enabled"):
          key = "enable"
        parms = "%s -%s %s" % (parms, key, val)
    
    _app_trace("About to call AdminTask.modifyRemoteCellForIntelligentManagement(%s)" % (parms))
    retval = AdminTask.modifyRemoteCellForIntelligentManagement("[ %s ]" % parms)
  except:
    _app_exception("Unexpected error in addWebServerIntelligentManagementRemoteCell()")
    
  _app_trace("modifyWebServerIntelligentManagementRemoteCell()","exit")
  return retval

#--------------------------------------------------------------------------------------------------------------------------
# modifyWebServerIntelligentManagementTraceSpecs
#
# Parameters:
#    nodeName - node hosting the web server
#    serverName - web server name
#    defaultSpec - default trace spec, if "" will be cleared
#    condition - the condition for the conditional spec. If "" will be cleared.
#    conditionalSpec - the conditional spec to be set. A condition can be specified with this value, in which
#                      case default trace settings will be used with the condition
#--------------------------------------------------------------------------------------------------------------------------
def modifyWebServerIntelligentManagementTraceSpecs(nodeName,serverName,defaultSpec=None,conditionalSpec=None,condition=None):  
  _app_trace("modifyWebServerIntelligentManagementTraceSpecs(%s,%s,%s,%s,%s)" % (nodeName,serverName,defaultSpec,conditionalSpec,condition),"entry")
  try:
    if (defaultSpec != None):
      _app_trace('About to call AdminTask.setDefaultTraceRuleForIntelligentManagement([ "-node", %s, "-webserver", %s, "-spec", "%s")' % (nodeName,serverName,defaultSpec))
      AdminTask.setDefaultTraceRuleForIntelligentManagement([ "-node", nodeName, "-webserver", serverName, "-spec", defaultSpec])
    
    if (conditionalSpec != None):
      if (isEmpty(condition)):
        # remove conditional trace
        _app_trace('About to call AdminTask.removeConditionalTraceRuleForIntelligentManagement("[-node %s -webserver %s ]")' %  (nodeName,serverName))
        AdminTask.removeConditionalTraceRuleForIntelligentManagement("[-node %s -webserver %s ]" %  (nodeName,serverName))
      else:
        args = '-node %s -webserver %s -condition "%s" ' % (nodeName,serverName,condition)
        if (not isEmpty(conditionalSpec)):
          args = '%s -spec "%s"' % (args,conditionalSpec)
        
        _app_trace("About to call  AdminTask.addConditionalTraceRuleForIntelligentManagement('[ %s ]')" % args)
        AdminTask.addConditionalTraceRuleForIntelligentManagement('[ %s ]' % args)
      
  except:
    _app_exception("Unexpected error in modifyWebServerIntelligentManagementTraceSpecs")
    
  _app_trace("modifyWebServerIntelligentManagementTraceSpecs()","exit")
    

#-------------------------------------------------------------------------------
# findMatchingWebServers
#
# Returns a list of (nodeName,wsName,serverId,wsId) tuples
#-------------------------------------------------------------------------------
def findMatchingWebServers(nodePattern, serverPattern):
  
  _app_trace("findMatchingWebServers(%s,%s)" % (nodePattern, serverPattern),"entry")
  retval = []
  
  try:
    import re
    
    wsList = None
    if (not isEmpty(nodePattern) and nodePattern.find("*") < 0):
      # No pattern sent in for node, specific node is specified, so optimize search
      nodeId = AdminConfig.getid("/Node:%s" % nodePattern)
      wsList = AdminConfig.list("WebServer",nodeId).splitlines()
    else:
      # List is for entire cell
      wsList = AdminConfig.list("WebServer").splitlines()
    
    for wsId in wsList:
      serverId = AdminConfig.showAttribute(wsId,"server")
      nodeName = getNodeNameForServer(serverId)
      wsName = AdminConfig.showAttribute(serverId,"name")
      
      nodeMatch = 0
      
      if ( isEmpty(nodePattern)):
        nodeMatch = 1
      elif (nodePattern.find("*") < 0 and nodePattern == nodeName):
        nodeMatch = 1
      elif (nodePattern.find("*") >= 0 and re.match(nodePattern,nodeName)):
        nodeMatch = 1
      
      serverMatch = 0
      if (nodeMatch):
        if (isEmpty(serverPattern)):
          serverMatch = 1
        elif (serverPattern.find("*") < 0 and serverPattern == wsName):
          serverMatch = 1
        elif (serverPattern.find("*") >= 0 and re.match(serverPattern,wsName)):
          serverMatch = 1
      
      if (serverMatch):
        retval.append((nodeName,wsName,serverId,wsId))
      
  except:
    _app_exception("Unexpected error in findMatchingWebServers(%s,%s)" % (nodePattern, serverNamePattern))
  
  _app_trace("findMatchingWebServers(retval=%s)" % retval, "exit")
  return retval

#------------------------------------------------------------------------------------------------------
# Get webserver definition as a set of properties
#------------------------------------------------------------------------------------------------------
def getWebServerProperties(webserverId):

  _app_trace("getWebServerProperties(%s)" %(webserverId), "entry")

  results={}
  prefix = "webServer"
    
  serverval = AdminConfig.showAttribute(webserverId,"server")
  
  servername = AdminConfig.showAttribute(serverval,"name")
  nodeName = getNodeNameForServer(serverval)
  webPort, adminPort = getWebServerPortInfo(nodeName,servername)
  
  results["%s.name" % (prefix)] = servername
  results["%s.nodeName" % prefix] =  nodeName
  results["%s.webPort" % prefix] = webPort
  results["%s.adminPort" % prefix] =  adminPort
    
  collectSimpleProperties(results, prefix ,webserverId, ["name"])
  collectSimpleProperties(results, "webServer.prop" ,webserverId, ["name"])
  
    
  adminServerAuthenticationId = AdminConfig.showAttribute(webserverId,"adminServerAuthentication")
  if not isEmpty(adminServerAuthenticationId):
      collectSimpleProperties(results,"%s.adminServerAuthentication.prop" % (prefix) ,adminServerAuthenticationId)
        
  stateManagementId = AdminConfig.showAttribute(webserverId,"stateManagement")
  if (not isEmpty(stateManagementId)):
      collectSimpleProperties(results,"%s.stateManagement.prop" % (prefix), stateManagementId)
      
  pd = AdminConfig.list("JavaProcessDef",serverval)
  if (not isEmpty(pd)):
    collectSimpleProperties(results,"%s.processDef.prop" % (prefix),pd,getSimpleChildren=1,collectPropertyAttributes=1,useAttrNameWithProperties=1)
  
  collectCustomProperties(results,"%s.properties"% prefix,webserverId,"properties")
      
  pluginProperties = AdminConfig.list("PluginProperties", webserverId)
  if (not isEmpty(pluginProperties)):
      pluginPropertiesList = wsadminToList(pluginProperties)
      collectSimpleProperties(results,"%s.pluginProperties.prop" % (prefix), pluginPropertiesList[0])
        
      pluginServerClusterProperties = AdminConfig.list("PluginServerClusterProperties",pluginPropertiesList[0])
      collectSimpleProperties(results,"%s.pluginProperties.pluginServerClusterProperties.prop"  % (prefix) , pluginServerClusterProperties)
      
      collectCustomProperties(results,"%s.pluginProperties.properties"% prefix,pluginProperties,"properties")
      
  # Now for 8.5.5 onwards, get Intelligent Management properties
  getWebServerIntelligentManagementProperties(results,servername,nodeName,prefix)
  
  _app_trace("getWebServerProperties(%d properties returned)" % (len(results)), "exit")
  return results

#enddef getWebServerProperties

#-------------------------------------------------------------------------
# getWebServerIntelligentManagementProperties
#
# This function will pull the intelligentManagement settings for the web server
# plug-in (8.5.5 onwards) and store them in the supplied dictionary with the
# webServer.intelligentManagement prefix.
#
# To simplify the lookup of remote cells, the following special items are 
# stored in the dictionary:
#    webServer.intelligentManagement.remoteCells.<host>_<port> = a dictionary
#       with the properties defining the remote cell with the host and port name
#-------------------------------------------------------------------------
def getWebServerIntelligentManagementProperties(props,webserverName,webserverNode,prefix):
  try:
     AdminTask.help("enableIntelligentManagement")
  except:
    return
  
  intelId = None
  resetChanges = 1
  try:
    if AdminConfig.hasChanges():
      resetChanges = 0
    intelId = AdminTask.modifyIntelligentManagement("[ -node %s -webserver %s ]" % (webserverNode,webserverName))
    
    if (resetChanges):
      AdminConfig.reset()
    
  except:
    #print formatExceptionData("")
    intelId = None
  
  prefix = "%s.intelligentManagement" % prefix
  
  if (intelId == None):
    props["%s.prop.enabled" % prefix] = "false"
    return
  
  nestedIds = {}
  collectSimpleProperties(props, "%s.prop"%prefix,intelId, [],nestedIds)
  
  # The connector clusters configuration items give us more details on remote cells than       
  # listRemoteCellsFromIntelligentManagement does
  remoteDict = {}
  connectorClusters = wsadminToList(nestedIds.get("%s.prop.connectorClusters" % prefix,"[]"))
  ccidx = 0
  for connectorClusterId in connectorClusters:
    if (isEmpty(connectorClusterId)):
      continue
    connectorDict = {}
    collectSimpleProperties(connectorDict, "prop", connectorClusterId)
    cellIdentifier = connectorDict.get("prop.cellIdentifier","")
    remoteDict[cellIdentifier] = connectorDict
    
    ccidx += 1
    
    # Store the connector cluster properties in our results
    for key in connectorDict.keys():
      props["%s.connectorClusters.%d.%s" % (prefix,ccidx,key)] = connectorDict[key]
    
  
  if (ccidx > 0):
    props["%s.connectorClusters.count" % prefix] = "%d" % (ccidx)
    
  remoteCellList =  AdminTask.listRemoteCellsFromIntelligentManagement('[-node %s -webserver %s ]' % (webserverNode,webserverName)).splitlines()
  remoteCellIdx = 0
  for remoteCell in remoteCellList:
    if (isEmpty(remoteCell)):
      continue
    
    split2 = []
    split1 = remoteCell.split(" ")
    if (len(split1) == 2):
      split2 = split1[1].split(":")
    
    if (len(split2) == 2):
      # Correct format
      remoteCellLabel = split1[0]
      remoteCellHost = split2[0]
      remoteCellPort = split2[1]
      
      connectorClusterProps = remoteDict.get(remoteCellLabel,{})
      
      remoteCellIdx += 1
      props["%s.remoteCells.%d.prop.cellIdentifier" % (prefix,remoteCellIdx)] = remoteCellLabel
      props["%s.remoteCells.%d.prop.host" % (prefix,remoteCellIdx)] = remoteCellHost
      props["%s.remoteCells.%d.prop.port" % (prefix,remoteCellIdx)] =  remoteCellPort
      props["%s.remoteCells.%d.prop.enabled" % (prefix,remoteCellIdx)] = connectorClusterProps.get("prop.enabled","")
      props["%s.remoteCells.%d.imSettings.prop.maxRetries" % (prefix,remoteCellIdx)] = connectorClusterProps.get("prop.maxRetries","")
      props["%s.remoteCells.%d.imSettings.prop.retryInterval" % (prefix,remoteCellIdx)] = connectorClusterProps.get("prop.retryInterval","")
      
      # For quick searching by name return remote cells with different keys
      props["%s.remoteCells.%s_%s" % (prefix,remoteCellHost,remoteCellPort)] = toDictionary(getPropList(props,"%s.remoteCells.%d" % (prefix,remoteCellIdx)))
      
      props["%s.remoteCells.imSettings.%s_%s" % (prefix,remoteCellHost,remoteCellPort)] = toDictionary(getPropList(props,"%s.remoteCells.%d.imSettings" % (prefix,remoteCellIdx)))

      
  props["%s.remoteCells.count" % (prefix)] = "%d" % remoteCellIdx
  
  userDefinedLines = wsadminToList(nestedIds.get("%s.prop.userDefinedLines" % prefix,"[]"))
    
    

  # The plugin Properties are stored as individual userDefinedLines
  # with entry = <Property name="webserverName" value="ScriptingCell_ScriptingNode1_IHS1"/>
  for udl in userDefinedLines:
    if (isEmpty(udl)):
      continue
    udlprops = {} 
    collectSimpleProperties(udlprops, "prop",udl, [])
    
    nameval = parsePropertyXML(udlprops.get("prop.entry",""))
    if nameval != None:
     props["%s.pluginProperties.prop.%s" % (prefix,nameval[0])]  =  nameval[1]
  
  # Note, could also have used listTraceRulesForIntelligentManagement
  traceSpecs = wsadminToList(nestedIds.get("%s.prop.traceSpecs" % prefix,"[]"))
  traceidx = 0
  defaultTraceProps = None
  otherTraceProps = []
  for traceSpecId in traceSpecs:
    if (isEmpty(traceSpecId)):
      continue
    traceprops = {}
    collectSimpleProperties(traceprops,"prop",traceSpecId,[])
    if (traceprops.get("prop.name","") == "default"):
      defaultTraceProps = traceprops
    elif (not isEmpty(traceprops.get("prop.condition",""))):
      otherTraceProps.append(traceprops)
  
  if (defaultTraceProps != None):
    props["%s.traceSpecs.default.prop.name" % (prefix)] = defaultTraceProps.get("prop.name","")
    props["%s.traceSpecs.default.prop.spec" % (prefix)] = defaultTraceProps.get("prop.spec","")
    
  if (len(otherTraceProps) > 0):
    
    traceidx = 0
    for traceProps in otherTraceProps:
      if (len(otherTraceProps) == 1 and not isEmpty(traceProps.get("prop.condition"))):
        # single condition format - looks like this is how it works in 8.5.5 so far
        props["%s.traceSpecs.conditional.prop.name" % (prefix)] = traceProps.get("prop.name","")
        props["%s.traceSpecs.conditional.prop.spec" % (prefix)] = traceProps.get("prop.spec","")
        props["%s.traceSpecs.conditional.prop.condition" % (prefix)] =traceProps.get("prop.condition","")
        
        props["%s.traceSpecs.conditional.1.prop.name" % (prefix)] = traceProps.get("prop.name","")
        props["%s.traceSpecs.conditional.1.prop.spec" % (prefix)] = traceProps.get("prop.spec","")
        props["%s.traceSpecs.conditional.1.prop.condition" % (prefix)] =traceProps.get("prop.condition","")
      else:
        # List format - naming convention implies room for growth
        traceidx += 1
        props["%s.traceSpecs.conditional.%d.prop.name" % (prefix,traceidx) ] = traceProps.get("prop.name","")
        props["%s.traceSpecs.conditional.%d.prop.spec" % (prefix,traceidx)] = traceProps.get("prop.spec","")
        props["%s.traceSpecs.conditional.%d.prop.condition" % (prefix,traceidx)] = traceProps.get("prop.condition","")
    
    props["%s.traceSpecs.conditional.count" % prefix] = "%d" % (traceidx)
  
  
  

