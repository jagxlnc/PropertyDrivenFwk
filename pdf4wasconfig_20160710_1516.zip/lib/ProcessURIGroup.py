################################################################################
# ProcessURIGroup.py - Processes input properties for URIGroup definitions and
# applies them to the system.
#
# Requires: URIGroup.py, Utils.py, common.py
#
# Primary entry point: processURIGroup.py
#
# Example property syntax:
#
# app.uriGroup.2.name = UriGroup3
# app.uriGroup.2.clearURIPatterns = false
# app.uriGroup.2.prop.URIPattern = /myapp/doug;/myapp-secure/bob
# 
# Set clearURIPatterns to true to force the clearing of the URIPattern list
# before updating to the new value. Default behavior is to merge the list.
################################################################################

#-------------------------------------------------------------------------------
# processURIGroup
#
# Parameters
#    uriGroupInfo - A dictionary with the input properties
#-------------------------------------------------------------------------------
def processURIGroup(uriGroupInfo):
  _app_entry("processURIGroup(uriGroupInfo)")
  retval = None
  try:
    ugCount = int(uriGroupInfo.get("app.uriGroup.count",0))
    if (ugCount > 0):
      for idx in range(1,ugCount+1):
        ugName = uriGroupInfo.get("app.uriGroup.%d.name" % idx,None)
        if (isEmpty(ugName)):
          # Partial list
          continue
        
        # See if exists
        ugId = findURIGroup(ugName)
        
        if (isEmpty(ugId)):
          # URIGroup does not exist
          _app_message("URIGroup %s does not exist" % ugName)
          baseProps = getPropList(uriGroupInfo,"app.uriGroup.%d" % idx)
          createURIGroup(uriGroupName=ugName,ugProps=baseProps)
          _app_message("URIGroup %s has been created" % ugName)
        else:
          
          existingProps = getURIGroupProperties(uriGroupId=ugId)
          baseProps = getPropListDifferences(uriGroupInfo,"app.uriGroup.%d" % idx,existingProps,"uriGroup")
          if (len(baseProps) > 0):
          
            clearURIPatterns = 0
            clearURIPatternsText=uriGroupInfo.get("app.uriGroup.%d.clearURIPatterns" % idx,"false").lower()
            if (clearURIPatterns in ["true","yes"]):
              clearURIPatterns = 1
              
            updateURIGroup(uriGroupId=ugId,ugProps=baseProps,clearURIPatterns=clearURIPatterns)
            _app_message("URIGroup %s has been updated" % ugName)
          else:
            _app_message("No need to update URIGroup %s" % ugName)
          
  except:
    _app_exception("Unexpected problem in processURIGroup()")
  
  _app_exit("processURIGroup(retval=%s)" % retval)
  return retval