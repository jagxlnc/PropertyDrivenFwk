
#--------------------------------------------------------------------------------------
# createWorkManager
#
# Creates a new Work Manager
#
# ARGUMENTS:
# 	wmProviderId - Configuration ID of the Work Manager Provider
#   wmName - Name of the work manager to create
#   wmProps - a Properties object used to define Work Manager attributes
#   wmResourceProperties - a Properties object used to define custom properties
#
# RETURNS:
#   ID of the new work manager, None if an error occurred
#--------------------------------------------------------------------------------------
def createWorkManager(wmProviderId, wmName, wmProps, wmResourceProps=None):

  _app_trace("createWorkManager(%s,%s,%s,%s)" % (wmProviderId, wmName, wmProps, wmResourceProps),"entry")
  retval = None
  try:
    attrs = [["name",wmName]]
    for key in wmProps.keys():
      value = wmProps.get(key)
      if (isEmpty(value)):
          value = ""
      elif (value == "None"):
          value = ""
          
      #if (key == "serviceNames" and not isEmpty(value)):
      #   value = value.split(";")
          
      attrs.append([key, value])
          
    # create the Work Manager
    _app_trace("Executing AdminConfig.create(WorkManagerInfo, %s, %s)" % (wmProviderId, attrs))
    retval = AdminConfig.create("WorkManagerInfo", wmProviderId, attrs)
    wmId = retval
    
    if (wmResourceProps != None and len(wmResourceProps) > 0):
      updateJ2EEResourcePropertySet(wmId, wmResourceProps)
            
  except:
    _app_trace("Unexpected error creating WorkManager %s" % (wmName),"exception")
    retval = None
  
  _app_trace("createWorkManager(retval = %s)" % retval,"exit")
  return retval
	
#--------------------------------------------------------------------------------------
# updateWorkManager
#   Updates an existing work manager
#
# ARGUMENTS:
# 	wmId - Configuration ID of the Work Manager Provider
#   wmName - Name of the work manager to create
#   wmProps - a Properties object used to define Work Manager attributes
#   wmResourceProperties - a Properties object used to define custom properties
#
# RETURNS:
#   ID of the updated work manager, None if an error occurred
#--------------------------------------------------------------------------------------
def updateWorkManager(wmId, wmName, wmProps, wmResourceProps=None):

	_app_trace("updateWorkManager(%s,%s,%s,%s)" % (wmId, wmName, wmProps, wmResourceProps),"entry")
	retval = None
	try:
	
		#See if we are updating serviceNames
		serviceNames = wmProps.get("serviceNames")
		if (serviceNames != None):
				_app_trace("Clearing serviceNames values")
				if (modifyObject(wmId, [ ["serviceNames",""]])):
						raise StandardError("Error clearing serviceNames")
	
		attrs = []
		for key in wmProps.keys():
			value = wmProps.get(key)
			if (isEmpty(value)):
					value = ""
			if (value == "None"):
					value = ""
			attrs.append([key,value])
					
		# Update the work manager
		if (modifyObject(wmId,attrs)):
				_app_trace("Error updating WorkManagerInfo %s)" % (wmName))
				retval = None
		else:
				retval = wmId
		
		if (wmResourceProps != None and len(wmResourceProps) > 0):
		  updateJ2EEResourcePropertySet(wmId, wmResourceProps)
	except:
		_app_trace("Unexpected error updating WorkManager %s" % (wmName),"exception")
		retval = None
	
	_app_trace("updateWorkManager(retval = %s)" % retval,"exit")
	return retval


#--------------------------------------------------------------------------------------
# findWorkManagerAtScope
#
# Returns the ID of the WorkManager with the specified name and scope.  Returns None if no match is
# found. Returns "ERROR" if an unexpected error occurs.
#--------------------------------------------------------------------------------------
def findWorkManagerAtScope(pCluster, pNode, pServer, wmName) :

	retval = None
	try:
	
		_app_trace("findWorkManagerAtScope(%s,%s,%s,%s)" % (pCluster, pNode, pServer, wmName),"entry")
	
		global progInfo
		global configInfo
		
		pScope = ""

		if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
				pScope = "cell"
				cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
				for cell in cells:
						wmProviderId=AdminConfig.getid("/Cell:%s/WorkManagerProvider:WorkManagerProvider/" % AdminConfig.showAttribute(cell,"name"))
						retval = findWorkManagerWithName(wmName,wmProviderId)
						break
		else:
			if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer):
					pScope = "cluster"
					cluster = AdminConfig.getid("/ServerCluster:%s" % pCluster)
					wmProviderId=AdminConfig.getid("/ServerCluster:%s/WorkManagerProvider:WorkManagerProvider/" % AdminConfig.showAttribute(cluster,"name"))
					retval = findWorkManagerWithName(wmName,wmProviderId)
					
			else:
				if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
						pScope = "node"
						node = AdminConfig.getid("/Node:%s" % pNode)
						wmProviderId=AdminConfig.getid("/Node:%s/WorkManagerProvider:WorkManagerProvider/" % pNode)
						if (not isEmpty(wmProviderId)):
								retval = findWorkManagerWithName(wmName,wmProviderId)
						else:
								raise StandardError("WorkManagerProvider not found at node scope %s" % pNode)
								
				else:
						if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
								pScope = "server"
								server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
						
								wmProviderId=AdminConfig.getid("/Server:%s/WorkManagerProvider:WorkManagerProvider/" % AdminConfig.showAttribute(server,"name"))
								if (not isEmpty(wmProviderId)):
										retval = findWorkManagerWithName(wmName,wmProviderId)
								else:
										raise StandardError("WorkManagerProvider not found at server scope %s:%s" % (pNode,pServer))

	except:
			_app_trace("Error searching for work manager %s at scope %s%s:%s"%(wmName,pCluster, pNode, pServer),"exception")
			retval = "ERROR" 
	
	_app_trace("findWorkManagerAtScope(retval=%s)" % (retval),"exit")
	return retval
	
#--------------------------------------------------------------------------------------
# findWorkManagerWithName
#
# Returns the ID of the WorkManager with the specified name.  Returns None if no match is
# found. Returns "ERROR" if an unexpected error occurs.
#--------------------------------------------------------------------------------------
def findWorkManagerWithName(wmName,wmProviderId):

		_app_trace("findWorkManagerWithName(%s,%s)" % (wmName,wmProviderId),"entry")
		retval = None
		
		try:
		
				if (isEmpty(wmProviderId)):
						raise StandardError("WorkManagerProvider Id not specified")
		
				if (isEmpty(wmName)):
						raise StandardError("Work Manager Name is not specified")
				
				wmList = wsadminToList(AdminConfig.list("WorkManagerInfo",wmProviderId))
				for wm in wmList:
						if (isEmpty(wm)):
								continue
						
						tempName = AdminConfig.showAttribute(wm,"name")
						if (tempName == wmName):
								retval = wm
								break
		except:
				_app_trace("Unexpected error looking for Work Manager %s" % (wmName), "exception")
				retval = "ERROR"
		
		_app_trace("findWorkManagerWithName(retval = %s)" % retval, "exit")
		return retval

#------------------------------------------------------------------------------------
# getWorkManagerProperties
#
# Returns a property set with the attributes and custom properties of the Work Manager
# The property prefixes returned are:
#			app.workmanager.prop
#			app.workmanager.resourceProperties.prop
#------------------------------------------------------------------------------------
def getWorkManagerProperties(wmId):
		
		_app_trace("getWorkManagerProperties(%s)" %(wmId), "entry")
		results = java.util.Properties()
		
		name = AdminConfig.showAttribute(wmId,"name")
		results.put("app.workmanager.name",name)
		collectSimpleProperties(results, "app.workmanager.prop" , wmId, ["name"])
		
		collectResourceProperties(results,wmId,"propertySet","app.workmanager")
		
		
		_app_trace("getWorkManagerProperties(%d properties)" % results.size(), "exit")
		return results
		
		