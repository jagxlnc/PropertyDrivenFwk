##########################################################################
# File Name:    JAASAlias.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere JAAS Authentication Aliases
#
#               createJAASAlias
#               deleteJAASAlias
#               listJAASAliases
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createJAASAlias: Create a JAAS J2C Alias
#
# SYNTAX:
#    createJAASAlias name, description, userID, userPW
#
# PARAMETERS:
#    name	-	The name of the authentication data entry
#    description-	Specifies an optional description
#    userID	-	Specifies the user identity
#    userPW	-	Specifies the user userPW
#
# USAGE NOTES:
#    Creates a JAAS J2C Alias
#
# RETURNS:
#    ObjID	Object ID of new appserver
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addJAASAlias(aliasName, description, userID, userPW):
	createJAASAlias(aliasName, description, userID, userPW)
	
def createJAASAlias(aliasName, description, userID, userPW):

	global progInfo
	
	retval = None

	try:
		traceStr = "createJAASAlias(%s, %s, %s, ****)" % (aliasName, description, userID)
		_app_trace(traceStr, "entry")	

		if isEmpty(aliasName) or isEmpty(userID) or isEmpty(userPW,1):
			raise StandardError("Alias name, userID or userPW not specified")

		cell = AdminControl.getCell()
		sec = AdminConfig.getid("/Cell:" + cell + "/Security:/")

		attributes  = [["alias", aliasName], ["description", description], ["userId", userID], ["password", userPW]]

		#_app_trace("attributes = %s" % (attributes))
		_app_trace("Running command: AdminConfig.create('JAASAuthData', %s, %s, ...)" % (sec, aliasName))
		retval = AdminConfig.create("JAASAuthData", sec, attributes) 

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
			
	except:
		_app_trace("An error was encountered creating the JAAS Alias", "exception")
		retval = None

	_app_trace("createJAASAlias(%s)" %(retval), "exit")
	return retval
	
##########################################################################
#
# FUNCTION:
#    deleteJAASAlias: Delete a JAAS J2C Alias
#
# SYNTAX:
#    deleteJAASAlias name
#
# PARAMETERS:
#    name	-	The name of the authentication data entry
#
# USAGE NOTES:
#    Deletes a JAAS J2C Alias
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeJAASAlias(aliasName):
	deleteJAASAlias(aliasName)
	
def deleteJAASAlias(aliasName):

	global progInfo

	retval = 1

	try:
		traceStr = "deleteJAASAlias(%s)" % (aliasName)
		_app_trace(traceStr, "entry")	

		if isEmpty(aliasName):
			raise StandardError("Alias name not specified")
			
		found = 0

		JAASStr = AdminConfig.list("JAASAuthData")

		if isEmpty(JAASStr):
			#	Not an error, just no entries
			raise StandardError("No JAAS Aliases exist!")

		JAASList = JAASStr.split(progInfo["line.separator"])

		for entry in JAASList:
			alias = AdminConfig.showAttribute(entry, "alias")

			_app_trace("%s == %s (%d)" %(aliasName, alias, aliasName == alias))

			if alias == aliasName:
				found = 1
				aliasID = entry
				break

		if not found:
			raise StandardError("JAAS J2C Alias %s not found" % (aliasName))

		_app_trace("Running command: AdminConfig.remove(%s)" % (aliasID))
		AdminConfig.remove(aliasID)

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
			
		retval = 0

	except:
		_app_trace("An error was encountered creating the JAAS Alias", "exception")
		retval = 1

	_app_trace("deleteJAASAlias(%d)" %(retval), "exit")
	return retval
	
##########################################################################
#
# FUNCTION:
#    listJAASAliases: List JAAS J2C Aliases
#
# SYNTAX:
#    listJAASAliases displayFlag
#
# PARAMETERS:
#    displayFlag-	Boolean indicating whether to print list 
#			(default = 1)
#
# USAGE NOTES:
#    Lists JAAS J2C Aliases
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showJAASAliases(displayFlag = 1):
	listJAASAliases(displayFlag)

def listJAASAliases(displayFlag = 1):
	
	global progInfo

	retval = None
	
	try:
		traceStr = "listJAASAliases(%d)" % (displayFlag)
		_app_trace(traceStr, "entry")	

		_app_trace("Running command: AdminConfig.list('JAASAuthData')")
		str = AdminConfig.list("JAASAuthData")

		if isEmpty(str):
			retval = []
		else:
			retval = str.split(progInfo["line.separator"])

		if displayFlag:
			print "\nJAAS Aliases\n-------------------"
			
			for r in retval:
				print AdminConfig.showAttribute(r, "alias")
			
			print "-------------------"

	except:
		_app_trace("An error was encountered listing the JAAS Aliases", "exception")
		retval = None

	_app_trace("listJAASAliases(%s)" % (retval), "exit")
	return retval
   

#-------------------------------------------------------------------------
# Check for an existing JAAS alias and return its id
# @JJM-
#-------------------------------------------------------------------------
def checkForExistingJAASAlias(alias):
		
		retval = None
		j2c_aliases = AdminConfig.list("JAASAuthData").split(progInfo["line.separator"])
		for entry in j2c_aliases:
			if (isEmpty(entry)): 
				continue
				
			if (AdminConfig.showAttribute(entry, "alias") == alias):
				retval = entry
				break
				
		return retval


