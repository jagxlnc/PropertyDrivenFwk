################################################################################
# ProcessCell.py
#    - Parse Cell component properties and applies them to the configuration.
#      (The WCCM Cell configuration item, not the whole administrative cell)
#
# Requires: Cell.py, Utils.py, common.py
#
# Entry point: processCell(cellConfigInfo)
#
# Example properties:
#
# Example Cell properties as produced by dumpConfig.py
#
# - Cell name doesn't matter ---
# app.cell.name = IMScriptingCell
# app.cell.prop.biDiTextDirection = LTR
# app.cell.prop.cellDiscoveryProtocol = TCP
# app.cell.prop.cellRegistered = false
# app.cell.prop.cellType = DISTRIBUTED
# app.cell.prop.enableBiDi = false
# app.cell.properties.prop.IM.enabled = true
# app.cell.properties.prop.enableAdminAuthorizationCache = true
# app.cell.properties.prop.MyCustomCellProp = Hello World|Some description
# app.cell.monitoredDirectoryDeployment.type = MonitoredDirectoryDeployment
# app.cell.monitoredDirectoryDeployment.prop.enabled = true
# app.cell.monitoredDirectoryDeployment.prop.monitoredDirectory = ${USER_INSTALL_ROOT}/monitoredDeployableApps
# app.cell.monitoredDirectoryDeployment.prop.pollingInterval = 15
################################################################################

#-------------------------------------------------------------------------------
# processCell
#
# Parameters
#    cellConfigInfo - dictionary with cell properties to be processed
#-------------------------------------------------------------------------------
def processCell(cellConfigInfo):
  _app_entry("processCell(cellConfigInfo)")
  retval = None
  try:
    if (checkForPrefix(cellConfigInfo,"app.cell.")):
      cellName = getCellName()
      
      # Some settings have been passed in
      existingProps = getCellProperties()
      
      baseProps = getPropListDifferences(cellConfigInfo,"app.cell",existingProps,"cell")
      customProps = getPropListDifferences(cellConfigInfo,"app.cell.properties",existingProps,"cell.properties")
      mddProps = getPropListDifferences(cellConfigInfo,"app.cell.monitoredDirectoryDeployment",existingProps,"cell.monitoredDirectoryDeployment")
      
      if (len(baseProps) > 0 or len(customProps) > 0 or len(mddProps) > 0):
        updateCellProperties(baseProps,customProps,mddProps)
        _app_message("Cell %s configuration item properties have been updated" % cellName)
      else:
        _app_message("No updates required for Cell %s configuration item" % cellName)
    
  except:
    _app_exception("Unexpected problem in processCell()")
  
  _app_exit("processCell(retval=%s)" % retval)
  return retval
  