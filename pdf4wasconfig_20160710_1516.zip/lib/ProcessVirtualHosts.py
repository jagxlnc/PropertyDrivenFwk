#################################################################################
# ProcessVirtualHosts.py
#
# Property Syntax
#
# Classic format: single line for each alias
# app.virtualHosts.2.name = default_host
# app.virtualHosts.2.aliases.prop.1 = *|25012
# app.virtualHosts.2.aliases.prop.2 = *|80
# app.virtualHosts.2.aliases.prop.3 = *|25013
# app.virtualHosts.2.aliases.prop.4 = *|25014
# 
# Multiple aliases per alias property
# app.virtualHosts.3.name = myhost
# app.virtualHosts.3.aliases.prop.1 = *|80 *|8080 JJMW500|8080
# app.virtualHosts.3.aliases.prop.2 = *|443 *|8443 JJMW500|443
# app.virtualHosts.count = 3
# 
# Alternative non-indexed aliases property
#
# app.virtualHosts.3.name = myhost2
# app.virtualHosts.3.aliases = *|80 *|8080 JJMW500|8080
#
# Special functions to lookup endpoint values
#   app.virtualHosts.3.aliases.1 = @CLUSTER{cluster-name,endpoint1[,endpoint2 ...]}
#   app.virtualHosts.3.aliases.2 = @SERVER{server-name,node-name,endpoint1[,endpoint2 ...]}

#########################################################################################################################
# getServerEndPointsAsAliases
#########################################################################################################################
def getServerEndPointsAsAliases(serverName, serverNode, endpointNames, virtualHostName, existingAliasList, aliasAttrs):

  try:
    _app_trace("getServerEndPointsAsAliases(%s,%s,%s,%s,%s,%s)" % (serverName, serverNode, endpointNames, virtualHostName, existingAliasList, aliasAttrs),"entry")
    
    nodeid = AdminConfig.getid("/Node:%s" % serverNode)
    nodeHostName = AdminConfig.showAttribute(nodeid,"hostName")

    serverEntries = AdminConfig.list('ServerEntry', nodeid).split(progInfo["line.separator"])
    for serverEntry in serverEntries:
        if (isEmpty(serverEntry)):
          continue
                      
        sName = AdminConfig.showAttribute(serverEntry,"serverName")
        if (sName != serverName):
            continue
                      
        endPtStr = AdminConfig.showAttribute(serverEntry, "specialEndpoints")
        specialEndPoints = wsadminToList(endPtStr)
        for specialEndPoint in specialEndPoints:
            if (isEmpty(specialEndPoint)):
                continue
            epointname = AdminConfig.showAttribute(specialEndPoint,"endPointName")
            if (epointname in endpointNames):
                ePoint =  AdminConfig.showAttribute(specialEndPoint, "endPoint")
                aliasPort = AdminConfig.showAttribute(ePoint,"port")
                              
                newalias = "%s|%s" % (nodeHostName,aliasPort)
                              
                # See if this is a match to an existing alias
                matchingAlias = 0
                if newalias in existingAliasList:
                    matchingAlias = 1
                              
                if (not matchingAlias):
                    # Add this alias to our list of new aliases
                    trcString = "Adding alias %s to virtual host %s (from server %s:%s %s)" % (newalias,  virtualHostName, serverName, serverNode,  epointname)
                    _app_trace(trcString)
                    _app_message(trcString)
                    aliasAttrs.append([["hostname", nodeHostName], ["port", aliasPort]])
                else:
                    _app_message("Skipping exisitng alias %s for VirtualHost %s" % (newalias,virtualHostName))
                          
                          
        # Break out of the serverEntry loop
        break
                                  
    # end for each serverEntry in node
  
  except:
      _app_trace("Unexpected exception in getServerEndPointsAsAliases","exception")
      _app_message("Unexcpected exception in getServerEndPointsAsAliases")
      exit()
      
  _app_trace("getServerEndPointsAsAliases(%s,%s,%s,%s,%s,%s)" % (serverName, serverNode, endpointNames, virtualHostName, existingAliasList, aliasAttrs),"exit")

#enddef getServerEndPointsAsAliases

#########################################################################################################################
# getClusterEndPointsAsAliases
#########################################################################################################################
def getClusterEndPointsAsAliases(clusterName, endpointNames, virtualHostName, existingAliasList, aliasAttrs):

  try:
  
    _app_trace("getClusterEndPointsAsAliases(%s,%s,%s,%s,%s)" % (clusterName, endpointNames, virtualHostName, existingAliasList, aliasAttrs), "entry")

    # iterate across cluster members
    clusterId = AdminConfig.getid("/ServerCluster:%s/" % clusterName)
    if (isEmpty(clusterId)):
        _app_message("Unable to locate cluster %s for setting up virtual host %s aliases" % (clusterName, virtualHostName))
        exit()
                    
    clusterMembers = AdminConfig.list("ClusterMember", clusterId).split(progInfo["line.separator"])
    for cmid in clusterMembers:
        if (isEmpty(cmid)):
            continue
                      
        mName = AdminConfig.showAttribute(cmid, "memberName")
        mNode = AdminConfig.showAttribute(cmid, "nodeName")
        
        getServerEndPointsAsAliases(mName, mNode, endpointNames, virtualHostName, existingAliasList, aliasAttrs)
                  
                  
    # end for each cluster member             

  except:
      _app_trace("Unexpected error in getClusterEndPointsAsAliases","exception")
      _app_message("Unexpected error in getClusterEndPointsAsAliases")
      exit()
  
  _app_trace("getClusterEndPointsAsAliases(%s,%s,%s,%s,%s)" % (clusterName, endpointNames, virtualHostName, existingAliasList, aliasAttrs), "exit")

#########################################################################################################################
# 
#########################################################################################################################
def processDynamicAliases(prefix, virtualHostName, existingAliasList, aliasAttrs):

    global configInfo

    # Now process dynamic virtual host members
    dynamicCount = int(configInfo.get("%s.aliases.dynamic.count"% prefix ,"0"))
    
    if (dynamicCount > 0):
        for didx in range(1,dynamicCount+1):
            dprefix = "%s.aliases.dynamic.%d" % (prefix, didx)
            dcluster = configInfo.get("%s.cluster" % dprefix,"")
            dnode = configInfo.get("%s.node" % dprefix,"")
            dserver = configInfo.get("%s.server" % dprefix,"")
            #dendpointName  = configInfo.get("%s.endpointName" % dprefix,"")
            dendpointNames = configInfo.get("%s.endpointNames" % dprefix,"")
            
            endpointNames = []
            if (not isEmpty(dendpointNames)):
                endpointList = dendpointNames.split(",")
                for e in endpointList:
                    endpointNames.append(e)
            
            if (len(endpointNames) == 0):
                # Partial list? Continue
                continue
            
            if (not isEmpty(dcluster)):
                getClusterEndPointsAsAliases(dcluster, endpointNames, virtualHostName, existingAliasList, aliasAttrs)

#-----------------------------------------------------------------------------------------------------------
# processVirtualHosts
# Process the virtual host settings from the property file.
#
# formerly buildCreateVirtualHosts
#-----------------------------------------------------------------------------------------------------------
def processVirtualHosts():

  global configInfo
  
  if not configInfo.has_key("app.virtualHosts.count"):
    _app_message("Skipping Building Virtual Hosts...")
    return

  _app_message("Building Virtual Hosts...")

  # Create VirtualHosts 
  for jpidx in range(1, int(configInfo["app.virtualHosts.count"]) + 1):
    prefix = "app.virtualHosts.%d" % (jpidx)
    
    if not configInfo.has_key("%s.name" % prefix):
        #skipping missing virtual host
        continue
       
    pName = configInfo["%s.name" % prefix]

    #@JJM - Don't recreate admin_host
    if (pName == "admin_host") :
        _app_message("Skipping admin host")
        continue

    vhId = getVirtualHost(pName)
    aliasList = []
    
    if (isEmpty(vhId)):
      vhId = createVirtualHost(pName) 
      if isEmpty(vhId):
        _app_message("Failed to create VirtualHost %s" % (pName))
        exit()
      else:
        _app_message("Created VirtualHost %s" % (pName))
    else:
      aliasList = getAliases(vhId)
      _app_message("VirtualHost %s Found" % (pName))

    subProps = getPropList(configInfo, "%s.aliases" % (prefix))
    
    aliasesProp = configInfo.get("%s.aliases" % prefix)
    if (not isEmpty(aliasesProp)):
      print aliasesProp
      subProps["aliases"] = aliasesProp

    attrs = [] 
    if (len(subProps) > 0):      
      
      for key in subProps.keys():
          newalias = subProps[key]
          
          
          if (newalias.startswith("@CLUSTER{")):
              clusterparms = newalias[9:-1].split(",")
              if (len(clusterparms) > 1):
                  clusterName = clusterparms[0]
                  endpointNames= clusterparms[1:]
                  getClusterEndPointsAsAliases(clusterName, endpointNames, pName, aliasList, attrs)
              else:
                  _app_message("Invalid @CLUSTER directive for virtual host %s", pName)
                  exit()
                  
              continue
          elif (newalias.startswith("@SERVER{")):
              serverparms = newalias[8:-1].split(",")
              if (len(serverparms) > 2):
                  serverName = serverparms[0]
                  nodeName = serverparms[1]
                  endpointNames= serverparms[2:]
                  getServerEndPointsAsAliases(serverName, nodeName, endpointNames, pName, aliasList, attrs)
              else:
                  _app_message("Invalid @CLUSTER directive for virtual host %s", pName)
                  exit()
              
              continue
              
          # No special processing rules
          matchingAlias = 0
          
          # See if this is a match to an existing alias
          if newalias in aliasList:
              matchingAlias = 1
          
          if (not matchingAlias):
              valDes = newalias.split("|")
              if (len(valDes) < 2 or isEmpty(valDes[0]) or isEmpty(valDes[1])):
                _app_message("Skipping invalid alias definition %s for VirtualHost %s" % (newalias,pName))
              elif (len(valDes) == 2):
                attrs.append([["hostname", valDes[0]], ["port", valDes[1]]])
                _app_message("Alias %s will be added to VirtualHost %s" % (newalias,pName))
              elif (len(valDes) > 2):
                # Multiple aliases listed on one line
                tempAliasList = newalias.split(" ")
                for tempAlias in tempAliasList:
                  if (tempAlias not in aliasList):
                    valDes = tempAlias.split("|")
                    if (len(valDes) != 2):
                      _app_message("Skipping invalid alias definition %s for VirtualHost %s" % (tempAlias,pName))
                    else:
                      attrs.append([["hostname", valDes[0]], ["port", valDes[1]]])
                      _app_message("Alias %s will be added to VirtualHost %s" % (tempAlias,pName))
                  else:
                    _app_message("Skipping existing alias %s for VirtualHost %s" % (tempAlias,pName))
                   
          else:
              _app_message("Skipping existing alias %s for VirtualHost %s" % (newalias,pName))
              
    # Now process dynamic virtual host members
    processDynamicAliases(prefix, pName, aliasList, attrs)
    
    
    # Now see if we have any aliases to update the VirtualHost with             
    if (len(attrs) > 0):
    
      attrs = ['aliases',attrs]

      # Remove old aliases
      # @TODO - Make this optional based on property setting?
      #deleteAliases(vhId)

      if (len(attrs[1]) > 0):
          if modifyObject(vhId, [attrs]):
            _app_message("Failed to modify VirtualHost aliases for %s" % (pName))
            exit()
          else:
            _app_message("Modified VirtualHost aliases %s" % (pName))
      else:
          _app_message("No alias updates for VirtualHost %s" % (pName))