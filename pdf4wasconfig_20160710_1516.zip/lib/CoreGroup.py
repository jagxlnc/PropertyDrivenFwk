################################################################################################
# CoreGroup.py
#
# This module contains functions used to manipulate core group settings.
#
# Primary functions:
#			
#     createCoreGroup(cgName, cgProperties, cgCustomProps, discoveryProps, discoveryCustomProps)
#     modifyCoreGroup(cgName, cgId, cgProperties, cgCustomProps, discoveryProps, discoveryCustomProps)
#     deleteCoreGroup(cgName)
#     createCoreGroupPolicy(coregroupId, policyName, policyType, policyProps, policyCustomProps,preferredServerList, criteriaList)
#     updateCoreGroupPolicy(coregroupId, policyId, policyProps, policyCustomProps,preferredServerList, criteriaList)
#     deleteCoreGroupPolicy(cgName, policyName, policyId)
#     findMatchingCoreGroupPolicies(cgName, policyPattern)
#     updateCoreGroupPreferredCoordinatorList(cgName, cgId, serverList)
#     addClusterToCoreGroup(clusterName, cgName)
#     getCoreGroupId(cgName)
#     findPolicyId(cgId, policyName, policyType)
#     getCoreGroupProperties(cgId)
#
################################################################################################



###############################################################################################
# createCoreGroup
#
# Creates a new core group and sets base properties, custom properties, discovery (liveness) properties,
# and discovery custom properties.
#
# Parameters:
#			cgName - Name of core group to create
#			cgProperties - properties object with base properties for core group
#			cgCustomProps - properties object containing core group custom properties in the
#                     key = val|desc format
#     discoveryProps - properties object containing settings for discovery (liveness) settings (V7 onward)
#     discoveryCustomProps - properties object containing discovery custom properties
###############################################################################################
def createCoreGroup(cgName, cgProperties, cgCustomProps, discoveryProps, discoveryCustomProps):
	_app_trace("createCoreGroup(%s,%s,%s,%s,%s)" % (cgName, cgProperties, cgCustomProps, discoveryProps, discoveryCustomProps), "entry")
	retval = None
	
	try:
		retval = getCoreGroupId(cgName)
		if (not isEmpty(retval)):
			raise StandardError("Core group already exists")
			
		retval = AdminTask.createCoreGroup('[-coreGroupName %s]' % cgName)
		cgId = retval
		
		if (isEmpty(retval)):
				raise StandardError("Problem creating core group")
		
		# Now apply properties
		skipProps = ["name","coreGroupUID","multiCastGroupIPEnd","multiCastGroupIPStart","multiCastPort"]
		attrs = []
		if (cgProperties != None):
				for key in cgProperties.keys():
						val = cgProperties.get(key)
						if (key in skipProps):
								continue
						
						attrs.append([key,val])
		
		if (len(attrs) > 0):
				if (modifyObject(retval,attrs)):
						raise StandardError("Unable to apply core group properties")
		
		if (cgCustomProps != None):
				errmsg = updateCustomProperties(retval, "customProperties", "Property", cgCustomProps)
				if (not isEmpty(errmsg)):
						raise StandardError("Unable to update coregroup custom properties: %s" % errmsg)
		
		attrs = []			
		if (discoveryProps != None):
			for key in discoveryProps.keys():
					val = discoveryProps.get(key)
					attrs.append([key,val])
		
		liveness = None
		if (len(attrs) > 0):
			liveness = AdminConfig.showAttribute(retval,"liveness")
			if (isEmpty(liveness)):
					_app_trace("About to call AdminConfig.create(Liveness, %s,%s)" % (cgId, attrs))
					liveness = AdminConfig.create("Liveness", cgId, attrs)
			else:
					if (modifyObject(liveness,attrs)):
							raise StandardError("Error updating liveness discovery settings")
		
		if (discoveryCustomProps != None and discoveryCustomProps.size() > 0):
				liveness = AdminConfig.showAttribute(retval,"liveness")
				if (isEmpty(liveness)):
					_app_trace("About to call AdminConfig.create(Liveness, %s,%s)" % (cgId, attrs))
					liveness = AdminConfig.create("Liveness", cgId, attrs)
					
				errmsg = updateCustomProperties(liveness, "customProperties", "Property", discoveryCustomProps)
				if (not isEmpty(errmsg)):
						raise StandardError("Unable to update coregroup discovery custom properties: %s" % errmsg)
			
	except:
		_app_trace("Error creating coregroup","exception")
		retval = None
	
	_app_trace("createCoreGroup(retval = %s)" % retval,"exit")
	return retval

###############################################################################################
# modifyCoreGroup
#
# Updates an existing core group and sets base properties, custom properties, discovery (liveness) properties,
# and discovery custom properties.
#
# Parameters:
#			cgName - Name of core group to update
#     cgId - Configuration Id of the core group
#			cgProperties - properties object with base properties for core group
#			cgCustomProps - properties object containing core group custom properties in the
#                     key = val|desc format
#     discoveryProps - properties object containing settings for discovery (liveness) settings (V7 onward)
#     discoveryCustomProps - properties object containing discovery custom properties
###############################################################################################
def modifyCoreGroup(cgName, cgId, cgProperties, cgCustomProps, discoveryProps, discoveryCustomProps):
	_app_trace("modifyCoreGroup(%s,%s,%s,%s,%s,%s)" % (cgName, cgId, cgProperties, cgCustomProps, discoveryProps, discoveryCustomProps), "entry")
	retval = None
	
	try:
		if (isEmpty(cgId)):
				cgId = getCoreGroupId(cgName)

		if (isEmpty(cgId)):
			raise StandardError("Core group does not exist")
			
		retval = cgId
		
		
		# Now apply properties
		skipProps = ["name","coreGroupUID","multiCastGroupIPEnd","multiCastGroupIPStart","multiCastPort"]
		attrs = []
		if (cgProperties != None):
				for key in cgProperties.keys():
						val = cgProperties.get(key)
						if (key in skipProps):
								continue
						
						attrs.append([key,val])
		
		if (len(attrs) > 0):
				if (modifyObject(retval,attrs)):
						raise StandardError("Unable to apply core group properties")
		
		if (cgCustomProps != None):
				errmsg = updateCustomProperties(retval, "customProperties", "Property", cgCustomProps)
				if (not isEmpty(errmsg)):
						raise StandardError("Unable to update coregroup custom properties: %s" % errmsg)
		
		attrs = []			
		if (discoveryProps != None):
			for key in discoveryProps.keys():
					val = discoveryProps.get(key)
					attrs.append([key,val])
		
		liveness = None
		if (len(attrs) > 0):
			liveness = AdminConfig.showAttribute(retval,"liveness")
			if (isEmpty(liveness)):
					_app_trace("About to call AdminConfig.create(Liveness, %s,%s)" % (cgId, attrs))
					liveness = AdminConfig.create("Liveness", cgId, attrs)
			else:
					if (modifyObject(liveness,attrs)):
							raise StandardError("Error updating liveness discovery settings")
		
		if (discoveryCustomProps != None and discoveryCustomProps.size() > 0):
				liveness = AdminConfig.showAttribute(retval,"liveness")
				if (isEmpty(liveness)):
					_app_trace("About to call AdminConfig.create(Liveness, %s,%s)" % (cgId, attrs))
					liveness = AdminConfig.create("Liveness", cgId, attrs)
					
				errmsg = updateCustomProperties(liveness, "customProperties", "Property", discoveryCustomProps)
				if (not isEmpty(errmsg)):
						raise StandardError("Unable to update coregroup discovery custom properties: %s" % errmsg)
			
	except:
		_app_trace("Error creating coregroup","exception")
		retval = None
	
	_app_trace("modifyCoreGroup(retval = %s)" % retval,"exit")
	return retval

#------------------------------------------------------------------------------
# deleteCoreGroup
#
# Deletes a complete core group configuration.  Core group must be empty before
# this can happen.
#
# Parameters:
#   cgName
#
# Returns:
#   1 - core group was deleted
#   0 - core group was not found, no deletion necessary
#   Raises StandardError if problem occurs
#------------------------------------------------------------------------------
def deleteCoreGroup(cgName):
  _app_trace("deleteCoreGroup(%s)" % cgName,"entry")
  retval = 0
  try:
    cgId = getCoreGroupId(cgName)
    if (not isEmpty(cgId)):
      _app_trace('About to call AdminTask.deleteCoreGroup([-coreGroupName %s])' % cgName)
      AdminTask.deleteCoreGroup("[-coreGroupName %s]" % cgName)
      retval = 1 
  except:
    _app_trace("Unexpected error in  deleteCoreGroup(%s)"%cgName,"exception")
    raise StandardError("Unexpected error in  deleteCoreGroup(%s)"%cgName)
  
  _app_trace("deleteCoreGroup(retval=%d)"%retval,"exit")
  return retval

#----------------------------------------------------------------------------------------------------------------------------------
# createCoreGroupPolicy
#
# Parameters:
#    coregroupId - The core group that holds the policy
#    policyName - The name of the policy to create
#    policyType - Type of policy to create
#    policyProps - key/val set of base properties
#    policyCustomProps - key/val set of custom properties
#    preferredServerList - list in the form ["server1 node1" "server2 node2" ... ] 
#    criteria list - a list of lists: [  [criteria-name1, value-1, description-1] [ criteria-name-2, value-2, description-2 ] ....]
#-------------------------------------------------------------------------------------------------------------------------
def createCoreGroupPolicy(coregroupId, policyName, policyType, policyProps, policyCustomProps,preferredServerList, criteriaList):
	_app_trace("createCoreGroupPolicy(%s,%s,%s,%s,%s,%s,%s)"%(coregroupId, policyName, policyType, policyProps, policyCustomProps,preferredServerList, criteriaList),"entry")
	retval = None
	try:
	
		existingId = findPolicyId(coregroupId, policyName, policyType)
		if (not isEmpty(existingId)):
			# Do an update instead
			_app_trace("%s %s already exists in coregroup" % (policyName, policyType))
			retval = updateCoreGroupPolicy(coregroupId, existingId, policyProps, policyCustomProps,preferredServerList, criteriaList)
			
		else:
	
			attrs = [["name", policyName]]
			for key in policyProps.keys():
				val = policyProps.get(key)
				attrs.append([key,val])
		
			_app_trace("About to call AdminConfig.create(%s,%s,%s)" % (policyType,coregroupId,attrs))
			retval = AdminConfig.create(policyType,coregroupId,attrs)
		
			if (policyCustomProps != None and len(policyCustomProps) > 0):
				# Update the custom properties
				errmsg = updateCustomProperties(retval, "customProperties", "Property", policyCustomProps)
				if (not isEmpty(errmsg)):
						raise StandardError("Unable to update coregroup policy custom properties: %s" % errmsg)
		
			if (preferredServerList != None and len(preferredServerList) > 0):
				# Set the preferred server list
				serverIdList = serverListToCoreGroupServerIdList(coregroupId, preferredServerList)
				if (serverIdList == None):
						raise StandardError("Unable to build preferred server list for input %s" %  preferredServerList)
				attrs = [ [ "preferredServers", serverIdList] ]
				if (modifyObject(retval,attrs)):
						raise StandardError("Unable to set preferred server list for %s %s" % (policyType, policyName))
		
			if (criteriaList != None and len(criteriaList) > 0):
				updateMatchCriteria(retval, criteriaList)
				
		# end else create new policy
				
	except:
		_app_trace("Unexpected error in createCoreGroupPolicy","exception")
		retval = None
	
	_app_trace("createCoreGroupPolicy(retval = %s)" % retval, "exit")
	return retval

#----------------------------------------------------------------------------------------------------------------------------------
# updateCoreGroupPolicy
# Parameters:
#    coregroupId - The core group that holds the policy
#    policyId - The ID of the policy to update
#    policyProps - key/val set of base properties
#    policyCustomProps - key/val set of custom properties
#    preferredServerList - list in the form ["server1 node1" "server2 node2" ... ] 
#    criteria list - a list of lists: [  [criteria-name1, value-1, description-1] [ criteria-name-2, value-2, description-2 ] ....]
#-------------------------------------------------------------------------------------------------------------------------
def updateCoreGroupPolicy(coregroupId, policyId, policyProps, policyCustomProps,preferredServerList, criteriaList):
	_app_trace("updateCoreGroupPolicy(%s,%s,%s,%s,%s,%s)"%(coregroupId, policyId, policyProps, policyCustomProps,preferredServerList, criteriaList),"entry")
	retval = None
	try:
	
	
		attrs = []
		if (policyProps != None):
			for key in policyProps.keys():
				val = policyProps.get(key)
				attrs.append([key,val])
		
		if (len(attrs) > 0):
			if (modifyObject(policyId, attrs)):
					raise StandardError("Unable to update base core group policy properties")
		
		if (policyCustomProps != None and len(policyCustomProps) > 0):
				# Update the custom properties
				errmsg = updateCustomProperties(policyId, "customProperties", "Property", policyCustomProps)
				if (not isEmpty(errmsg)):
						raise StandardError("Unable to update coregroup policy custom properties: %s" % errmsg)
		
		if (preferredServerList != None):
				# First clear out existing preferred servers
				attrs = [ [ "preferredServers", []] ]
				if (modifyObject(policyId,attrs)):
						raise StandardError("Unable to clear preferred server list for policy") 
								
				# Set the preferred server list
				serverIdList = serverListToCoreGroupServerIdList(coregroupId, preferredServerList)
				attrs = [ [ "preferredServers", serverIdList] ]
				if (modifyObject(policyId,attrs)):
						raise StandardError("Unable to set preferred server list for policy") 
		
		if (criteriaList != None and len(criteriaList) > 0):
				updateMatchCriteria(policyId, criteriaList)
				
		retval = policyId
				
	except:
		_app_trace("Unexpected error in updateCoreGroupPolicy","exception")
		retval = None
	
	_app_trace("updateCoreGroupPolicy(retval = %s)" % retval, "exit")
	return retval


	
#-------------------------------------------------------------------------------------------------
# updateCoreGroupPreferredCoordinatorList
#
# Utility method that will take a list of "servername nodename" strings and update the 
# preferred coordinator attribute of the coregroup
# 
# Parameters:
#
# cgName - Name of coregroup to update
# cgId - Id of the core group to update. If none, will use name to look it up
# serverList - List of strings in ["server1 node1" "server2 node2" ... ]  format
#
# Returns coregroup ID if successful, None if not
#-------------------------------------------------------------------------------------------------
def updateCoreGroupPreferredCoordinatorList(cgName, cgId, serverList):
	
	retval = cgId
	_app_trace("updateCoreGroupPreferredCoordinatorList(cgName(%s,%s,%s)" % (cgName, cgId, serverList), "entry")
	
	try:
		
		if (cgId == None):
				cgId = getCoreGroupId(cgName)
	
		cgsList = serverListToCoreGroupServerIdList(cgId, serverList)
		
		if (cgsList == None):
			# Unable to build the list
			retval = None
			raise StandardError("Unable to build preferred coordinator list")
		
		# First, let's clear the list
		attrs = [ ["preferredCoordinatorServers", [] ] ]
		if (modifyObject(cgId, attrs)):
				raise StandardError("Error clearing preferred coordinator list")
		
		# Now set the new servers
		attrs = [ ["preferredCoordinatorServers", cgsList ] ]
		if (modifyObject(cgId, attrs)):
				raise StandardError("Error setting preferred coordinator list")
	except:
		_app_trace("Unexpected error in updateCoreGroupPreferredCoordinatorList","exception")
		retval = None
	
	_app_trace("updateCoreGroupPreferredCoordinatorList(cgName(retval = %s)" % retval, "exit")
	return retval	

#----------------------------------------------------------------------------------------------
# addClusterToCoreGroup
# 
# This function will add a cluster to a core group.  It checks the coregroup attributes of the
# first cluster member. If its currently in the new core group, nothing is done.  Otherwise, the
# whole cluster is moved to the new coregroup.
#
# Parameters:
#		clusterName - Name of the cluster to move
#   cgName - Name of the coregroup to move to 
# 
# Returns: oldCoreGroupName,newCoreGroupName
#----------------------------------------------------------------------------------------------	
def addClusterToCoreGroup(clusterName, cgName):
  _app_trace("addClusterToCoreGroup(%s,%s)" % (clusterName, cgName), "entry")
  
  global progInfo  
  try:
    newCoreGroupName = cgName
    
    # Step one see what core group we are currently in
    clusterId = AdminConfig.getid("/ServerCluster:%s/" % clusterName)
    if (isEmpty(clusterId)):
        raise StandardError("Cluster %s not found"%clusterName)
        
    cgId = getCoreGroupId(cgName)
    if (isEmpty(cgId)):
        raise StandardError("CoreGroup %s does not exist" % cgName)
    
    clusterMembers = AdminConfig.list("ClusterMember", clusterId)

    oldCoreGroupName = None
    
    if not isEmpty(clusterMembers):
        clusterMemberList = clusterMembers.split(progInfo["line.separator"])
        for cmid in clusterMemberList:
            mName = AdminConfig.showAttribute(cmid, "memberName")
            mNode = AdminConfig.showAttribute(cmid, "nodeName")
          
            serverId = AdminConfig.getid("/Node:%s/Server:%s" % (mNode, mName))
            
            haserviceList = AdminConfig.list("HAManagerService",serverId).split(progInfo["line.separator"])
            if (len(haserviceList) >= 1 and not isEmpty(haserviceList[0])):
              haservice = haserviceList[0]
              oldCoreGroupName = AdminConfig.showAttribute(haservice,"coreGroupName")
              
            break
            
    
    if (isEmpty(oldCoreGroupName)):
        _app_trace("Unable to determine existing core group name for %s" % clusterName)
        raise StandardError("Unable to determine existing core group name for %s" % clusterName)
        
    elif (oldCoreGroupName == cgName):
        _app_trace("Cluster %s servers are already members of %s core group" % (clusterName, cgName))
        
    else:
        # We need to change the cluster members core group
        _app_trace("About to call AdminTask.moveClusterToCoreGroup([-source %s -target %s -clusterName %s ])" % (oldCoreGroupName, cgName, clusterName) )
        AdminTask.moveClusterToCoreGroup("[-source %s -target %s -clusterName %s ]" % (oldCoreGroupName, cgName, clusterName))
      
  
  except:
    _app_trace("Unexpected error adding cluster to core group","exception")
    raise StandardError("Unexpected error adding cluster to core group")
  
  
  _app_trace("addClusterToCoreGroup(%s,%s)" % (oldCoreGroupName,newCoreGroupName),"exit")
  return oldCoreGroupName,newCoreGroupName


#-------------------------------------------------------------------------------
# getClusterCoreGroup
# 
# Determine the name of the coregroup the cluster is in
#-------------------------------------------------------------------------------
def getClusterCoreGroup(clusterName):

  _app_trace("getClusterCoreGroup(%s)" % (clusterName), "entry")
  retval = ""
  
  try:
    
    
    # Step one see what core group we are currently in
    clusterId = AdminConfig.getid("/ServerCluster:%s/" % clusterName)
    if (isEmpty(clusterId)):
        raise StandardError("Cluster %s not found"%clusterName)
        
    
    clusterMembers = AdminConfig.list("ClusterMember", clusterId)

    oldCoreGroupName = None
    
    if not isEmpty(clusterMembers):
        clusterMemberList = clusterMembers.split(progInfo["line.separator"])
        for cmid in clusterMemberList:
            mName = AdminConfig.showAttribute(cmid, "memberName")
            mNode = AdminConfig.showAttribute(cmid, "nodeName")
          
            serverId = AdminConfig.getid("/Node:%s/Server:%s" % (mNode, mName))
            
            haserviceList = AdminConfig.list("HAManagerService",serverId).split(progInfo["line.separator"])
            if (len(haserviceList) >= 1 and not isEmpty(haserviceList[0])):
              haservice = haserviceList[0]
              oldCoreGroupName = AdminConfig.showAttribute(haservice,"coreGroupName")
              
            break
            
    
    if (isEmpty(oldCoreGroupName)):
        _app_trace("Unable to determine existing core group name for %s" % clusterName)
        raise StandardError("Unable to determine existing core group name for %s" % clusterName)
    else:
      retval = oldCoreGroupName
      
  except:
    _app_trace("Unexpected error looking up cluster coregroup information","exception")
    raise StandardError("Unexpected error looking up cluster coregroup information")
  
  
  _app_trace("getClusterCoreGroup(retval = %s)" % (retval),"exit")
  return retval

#-------------------------------------------------------------------------------
# trimClusterPolicies
#
# Utility method that can be used to remove obsolete policies that will no 
# longer match removed values.
#
# Parameters:
#    clusterName - A cluster name used to determine the appropriate core group
#    mcValueList - A list of strings that will be used in the search of match criteria (e.g. Messaging Engine names)
#------------------------------------------------------------------------------
def trimClusterPolicies(clusterName, mcValueList):
  _app_trace("trimMEPolicies(clusterName, meList)","entry")
  try:
    coregroupName = getClusterCoreGroup(clusterName)
    
    cgId = getCoreGroupId(coregroupName)
    
    policies = AdminConfig.showAttribute(cgId,"policies")
    policyList = wsadminToList(policies)
    if (not isEmpty(policies)):
        for policy in policyList:

            matchCriteria = AdminConfig.showAttribute(policy,"MatchCriteria")
            if (not isEmpty(matchCriteria)):
                for mc in wsadminToList(matchCriteria):
                    if (isEmpty(mc)): continue
                    mcvalue = AdminConfig.showAttribute(mc,"value")
                    if (mcvalue in mcValueList):
                      # This policy is to be deleted
                      _app_trace("About to call AdminConfig.remove(%s)" % policy)
                      AdminConfig.remove(policy)
    
    
  except:
    _app_trace("Unexpected error in trimMEPolicies","exception")
    raise StandardError("Unexpected error in trimMEPolicies")
    
  _app_trace("trimMEPolicies()","exit")
  return coregroupName

#-------------------------------------------------------------------------------
# deleteCoreGroupPolicy
#
# Parameters:
#     cgName - Name of the Core Group
#     policyName - Name of the policy to delete
# Returns:
#     1 - Policy found and deleted
#     0 - Policy was not found
#
# Raises StandardError if error during processing
#-------------------------------------------------------------------------------
def deleteCoreGroupPolicy(cgName, policyName, policyId=None):
  retval = 0
  _app_trace("deleteCoreGroupPolicy(%s,%s,%s)" % (cgName, policyName, policyId),"entry")
  try:
    
    if (not isEmpty(policyId)):
      # just go ahead and delete it
      _app_trace("About to call AdminConfig.remove(%s)" % policyId)
      AdminConfig.remove(policyId)
      retval = 1
    else:
      cgId = getCoreGroupId(cgName)
      
      policies = AdminConfig.showAttribute(cgId,"policies")
      policyList = wsadminToList(policies)
      if (not isEmpty(policies)):
          for policy in policyList:
            if (not isEmpty(policy)):
              if (policy.find(policyName) >= 0):
                tempName = AdminConfig.showAttribute(policy,"name")
                if (tempName == policyName):
                  _app_trace("About to call AdminConfig.remove(%s)" % policy)
                  AdminConfig.remove(policy)
                  retval = 1
                  break
    #endelse
  except:
    _app_trace("Unexpected error in deleteCoreGroupPolicy(%s,%s)" % (cgName, policyName), "exception")  
    raise StandardError("Unexpected error in deleteCoreGroupPolicy(%s,%s)" % (cgName, policyName))
    
  _app_trace("deleteCoreGroupPolicy(retval = %d)" % retval,"exit")
  return retval

#-------------------------------------------------------------------------------
# findMatchingCoreGroupPolicies
# Parameters:
#     cgName - Name of the core group
#     policyPattern - regular expression pattern to match against policy names
# Returns: dictionary consisting of policyName=configID
#-------------------------------------------------------------------------------
def findMatchingCoreGroupPolicies(cgName, policyPattern):
  import re
  retval = {}
  
  _app_trace("findMatchingCoreGroupPolicies(%s,%s)" %(cgName, policyPattern),"entry")
  
  try:
    cgId = getCoreGroupId(cgName)
    
    policies = AdminConfig.showAttribute(cgId,"policies")
    policyList = wsadminToList(policies)
    if (not isEmpty(policies)):
        for policy in policyList:
          if (not isEmpty(policy)):
              tempName = AdminConfig.showAttribute(policy,"name")
              if (re.match(policyPattern,tempName)):
                retval[tempName] = policy
  except:
    _app_trace("Unexpected error in findMatchingCoreGroupPolicies","exception")
    raise StandardError("Unexpected error in findMatchingCoreGroupPolicies")
  
  _app_trace("findMatchingCoreGroupPolicies(%d matches)" % (len(retval)),"exit")
  return retval
  

#----------------------------------------------------------------------------------------------
# addServerToCoreGroup
# 
# This function will add a cluster to a core group.  It checks the coregroup attributes of the
# first cluster member. If its currently in the new core group, nothing is done.  Otherwise, the
# whole cluster is moved to the new coregroup.
#
# Parameters:
#		clusterName - Name of the cluster to move
#   cgName - Name of the coregroup to move to 
# 
# Returns: OldCoreGroupName,NewCoreGroupName
#          Raises error if error occurrs
#----------------------------------------------------------------------------------------------	
def addServerToCoreGroup(serverName,nodeName,cgName,serverId=None):

  _app_trace("addServerToCoreGroup(%s,%s,%s,%s)" %(serverName,nodeName,cgName,serverId),"entry")
  
  
  try:
    newCoreGroupName = cgName
    
    # Step one see what core group we are currently in
    if (serverId == None):
      serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (nodeName,serverName))
      if (isEmpty(serverId)):
        raise StandardError("Server %s %s not found"%(serverName,nodeName))
        
    cgId = getCoreGroupId(cgName)
    if (isEmpty(cgId)):
        raise StandardError("CoreGroup %s does not exist" % cgName)
    
    

    oldCoreGroupName = None

    haserviceList = AdminConfig.list("HAManagerService",serverId).split(progInfo["line.separator"])
    if (len(haserviceList) >= 1 and not isEmpty(haserviceList[0])):
          haservice = haserviceList[0]
          oldCoreGroupName = AdminConfig.showAttribute(haservice,"coreGroupName")
    
    if (isEmpty(oldCoreGroupName)):
        raise StandardError("Unable to determine existing core group name for %s %s" % (serverName,nodeName))
    elif (oldCoreGroupName == newCoreGroupName):
        _app_trace("Server %s %s is already member of %s core group" % (serverName,nodeName, cgName))
        
    else:
        # We need to change the cluster members core group
        _app_trace("About to call AdminTask.moveServerToCoreGroup([-source %s -target %s -nodeName %s -serverName %s ])" % (oldCoreGroupName, cgName, nodeName,serverName ) )
        AdminTask.moveServerToCoreGroup("[-source %s -target %s -nodeName %s -serverName %s  ]" % (oldCoreGroupName, cgName, nodeName,serverName))
        retval = cgId
      
    
  except:
    _app_trace("Unexpected error in addServerToCoreGroup","exception")
    raise StandardError("Unexpected error in addServerToCoreGroup")
  
  _app_trace("addServerToCoreGroup(%s,%s)" %(oldCoreGroupName,newCoreGroupName),"exit")
  return oldCoreGroupName,newCoreGroupName


#----------------------------------------------------------------------------------------------
# serverListToCoreGroupServerIdList
#
# Takes a list in the form ["server1 node1" "server2 node2" ... ] and returns a list of
# CoreGroupServer Ids from the list of servers in this core group.
#
# If there is a server in the list that is not in the coregroup, None will be returned.
#----------------------------------------------------------------------------------------------
def serverListToCoreGroupServerIdList(cgId, serverList):
	_app_trace("serverListToCoreGroupServerIdList(%s, %s)" % (cgId, serverList),"entry")
	retval = []
	try:
		
		tempdict = { }
		cgs = AdminConfig.showAttribute(cgId,"coreGroupServers")
		if (isEmpty(cgs) and len(serverList) > 0):
			retval = None
		else:
			cgsList = wsadminToList(cgs)
			searchIdx = 0
			for namenode in serverList:
				foundId = None
				namenodeList = namenode.split(" ")
				if (len(namenodeList) != 2):
					raise StandardError("Invalid name/node string: %s" % namenode)
				
				serverName = namenodeList[0]
				nodeName = namenodeList[1]
				
				#print "Searching for %s %s" % (serverName,nodeName)
				
				# See if we have already found the coregroupserver with this name and node
				tempId = tempdict.get(namenode)
				if (not isEmpty(tempId)):
						foundId = tempId
				else:
						# Go through the list
						while (searchIdx < len(cgsList)):
								cgsId = cgsList[searchIdx]
								searchIdx = searchIdx + 1
								
								if (not isEmpty(cgsId)):
									tempServerName = AdminConfig.showAttribute(cgsId,"serverName")
									tempNodeName = AdminConfig.showAttribute(cgsId,"nodeName")
									tempKey = "%s %s" % (tempServerName,tempNodeName)
									tempdict[tempKey] = cgsId
									
									
									#print "Checking against server %d:  %s %s" % (searchIdx,tempServerName,tempNodeName)
									if (tempServerName == serverName and tempNodeName == nodeName):
											foundId = cgsId
											break
				
				if (foundId != None):
						# Add the found Id to the result list
						retval.append(foundId)
				else:
						# We did not find a match for this server name
						retval = None
						_app_trace("No CoreGroupServer found for %s %s" % (serverName, nodeName))
						break
						
		
	except:
		_app_trace("Unexpected error in serverListToCoreGroupServerIdList","exception")
		retval = None

	_app_trace("serverListToCoreGroupServerIdList(retval = %s)" % (retval),"exit")
	return retval


#----------------------------------------------------------------------------------------------
# getCoreGroupId
#
# Get the configuration ID of the core group with the specified name.
#
# Parameter:
#   
#----------------------------------------------------------------------------------------------
def getCoreGroupId(cgName):
	_app_trace("getCoreGroupId(%s)" % cgName, "entry")
	try:
		retval = AdminConfig.getid("/CoreGroup:%s/" % cgName)
	except:
		_app_trace("Error getting coregroup Id")
		retval = None
		
	_app_trace("getCoreGroupId(retval = %s)" % retval, "exit")
	return retval

#----------------------------------------------------------------------------------------------
# findPolicyId
#
# Finds a policy under a coregroup with a specific type and name. Returns None if no match
#----------------------------------------------------------------------------------------------
def findPolicyId(cgId, policyName, policyType):
	_app_trace("findPolicyId(%s,%s,%s)" % (cgId, policyName, policyType), "entry")
	retval = None
	try:
			policies = AdminConfig.showAttribute(cgId,"policies")
			policyList = wsadminToList(policies)
			if (not isEmpty(policies)):
					pidx = 0
					for policy in policyList:
							pidx = pidx + 1
							if (policy.find(policyType) >= 0):
									tempPolicyName = AdminConfig.showAttribute(policy,"name")		
									if (tempPolicyName == policyName):
											retval = policy
											break
	except:
		_app_trace("Unexpected error in findPolicyId","exception")
		raise StandardError("Unexpected error in findPolicyId")
	
	_app_trace("findPolicyId(retval = %s)" % retval ,"exit")
	return retval

#---------------------------------------------------------------------------------------------
# Updates or creates match criteria for a core group policy
#
# Parameters:
#    policyId - The policy to be updated
#    criteria list - a list of lists: [  [criteria-name1, value-1, description-1] [ criteria-name-2, value-2, description-2 ] ....]
#
# Raises and error if any problem occurs during the update
#---------------------------------------------------------------------------------------------
def updateMatchCriteria(policyId, criteriaList):
	_app_trace("updateMatchCriteria(%s,%s)" % (policyId, criteriaList),"entry")
	try:
		for criteria in criteriaList:
				if (len(criteria) > 3 or len(criteria) < 2):
					raise StandardError("Invalid match criteria input: %s" % criteria)
				
				description = ""
				if (len(criteria) == 3):
					 description = criteria[2]
				
				criteriaName = criteria[0]
				criteriaValue = criteria[1]
				
				# See if the criteria already exists
				criteriaId = findMatchCriteriaId(policyId, criteriaName)
				if (isEmpty(criteriaId)):
						# Will be doing a create
						attr = [ ["name", criteriaName], ["value", criteriaValue], ["description",description] ]
						_app_trace("About to call AdminConfig.create(MatchCriteria,%s,%s)" % (policyId,attr))
						criteriaId = AdminConfig.create("MatchCriteria",policyId,attr)
				else:
						# Will be doing an update
						attr = []
						tempValue = AdminConfig.showAttribute(criteriaId,"value")
						tempDesc = AdminConfig.showAttribute(criteriaId,"description")
						if (tempValue != criteriaValue):
								attr.append(["value",criteriaValue])
						if (tempDesc != description):
								attr.append(["description",description])
						
						if (len(attr) > 0):
								if (modifyObject(criteriaId,attr)):
										raise StandardError("Error updating criteria %s" % criteriaName)
						
				
	except:
		_app_trace("Unexpected error in updateMatchCriteria", "exception")
		raise StandardError("Unexpected error in updateMatchCriteria")
		
	_app_trace("updateMatchCriteria()","exit")

#---------------------------------------------------------------------------------------------
# findMatchCriteriaId
#
# Finds a match criteria with the specific name
#
# Parameters:
#    policyId - the configuration ID of the policy to search under
#    matchName  - the name to look for
#
# Returns - configuration ID of the MatchCriteria, None if not found
#           Raises an error if problem occurs
#---------------------------------------------------------------------------------------------
def findMatchCriteriaId(policyId, matchName):
	_app_trace("findMatchCriteriaId(%s,%s)" % (policyId, matchName), "entry")
	retval = None
	try:
		matchCriteria = AdminConfig.showAttribute(policyId,"MatchCriteria")
		if (not isEmpty(matchCriteria)):
			for mc in wsadminToList(matchCriteria):
					if (isEmpty(mc)): continue
					tempname = AdminConfig.showAttribute(mc,"name")
					if (tempname == matchName):
							retval = mc
							break
		
	except:
		_app_trace("Unexpected error in findMatchCriteriaId","exception")
		raise StandardError("Unexpected error in findMatchCriteriaId")
			
	_app_trace("findMatchCriteriaId(retval = %s)" % (retval), "exit")	
	return retval
		

#----------------------------------------------------------------------------------------------
# getCoreGroupProperties
#
# Returns the settings of an existing coregroup as properties
#     app.coregroup.prop.xxxxxx
#     app.coregroup.customProperties.prop.xxxxxx
#     app.coregroup.liveness.prop.xxxxxx
#     app.coregroup.liveness.customProperties.prop.xxxxx
#     app.coregroup.preferredCoordinatorServers.[idx].serverName
#     app.coregroup.preferredCoordinatorServers.[idx].nodeName
#     app.coregroup.policies.[idx].policyType
#     app.coregroup.policies.[idx].name
#     app.coregroup.policies.[idx].prop.*******
#     app.coregroup.policies.[idx].matchCriteria.[idx].name
#     app.coregroup.policies.[idx].matchCriteria.[idx].description
#     app.coregroup.policies.[idx].matchCriteria.[idx].value
#     app.coregroup.policies.[idx].preferredServers.[idx].serverName
#     app.coregroup.policies.[idx].preferredServers.[idx].nodeName
#----------------------------------------------------------------------------------------------
def getCoreGroupProperties(cgId):

	_app_trace("getCoreGroupProperties(%s)" % cgId, "entry")
	try:
			retval = java.util.Properties()
					
			cgName = AdminConfig.showAttribute(cgId,"name")
			
			retval.put("coregroup.name",cgName)
			collectSimpleProperties(retval,"app.coregroup.prop", cgId, ["name"])
			
			collectCustomProperties(retval,"app.coregroup.customProperties" , cgId, "customProperties")
			
			#customProperties =AdminConfig.showAttribute(cgId,"customProperties")
			#if (not isEmpty(customProperties)):
			#	for cpropsitem in wsadminToList(customProperties):
			#		if (isEmpty(cpropsitem)):
			#			continue
			#		cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
			#		cpropname = AdminConfig.showAttribute(cpropsitem,"name")
			#		cpropval = AdminConfig.showAttribute(cpropsitem,"value")
			#		if isEmpty(cpropdesc):
			#			retval.put("app.coregroup.customProperties.prop.%s" % (cpropname), cpropval)
			#		else:
			#			retval.put("app.coregroup.customProperties.prop.%s" % (cpropname),"%s|%s" % (cpropval, cpropdesc))

			# liveness (discovery) settings introduced in V7
			try:
				liveness = AdminConfig.showAttribute(cgId,"liveness")
			except:
				liveness = ""
			
			if (not isEmpty(liveness)):
					collectSimpleProperties(retval,"app.coregroup.liveness.prop", liveness)
					collectCustomProperties(retval,"app.coregroup.liveness.customProperties" , liveness, "customProperties")		
			
			## Currently no need for this expensive information
			#coreGroupServers = wsadminToList(AdminConfig.showAttribute(cgId,"coreGroupServers"))
			#serverIdx = 0
			#
			#for coreGroupServer in coreGroupServers:
			#		if (isEmpty(coreGroupServer)):
			#				continue
			#		
			#		serverIdx = serverIdx + 1
			#		
			#		serverName = AdminConfig.showAttribute(coreGroupServer,"serverName")
			#		nodeName = AdminConfig.showAttribute(coreGroupServer,"nodeName")
			#		retval.put("app.coregroup.coreGroupServers.%d.serverName" % (serverIdx), serverName)
			#		retval.put("app.coregroup.coreGroupServers.%d.nodeName"% (serverIdx),nodeName)
			#		collectSimpleProperties(retval,"app.coregroup.coreGroupServers.%d.prop"% (serverIdx), coreGroupServer,["serverName","nodeName"])
			#		
			#		customProperties = AdminConfig.showAttribute(coreGroupServer,"customProperties")
			#		
			#		if (not isEmpty(customProperties)):
			#			for cpropsitem in wsadminToList(customProperties):
			#				if (isEmpty(cpropsitem)):
			#					continue
			#				cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
			#				cpropname = AdminConfig.showAttribute(cpropsitem,"name")
			#				cpropval = AdminConfig.showAttribute(cpropsitem,"value")
			#				if isEmpty(cpropdesc):
			#					retval.put("app.coregroup.coreGroupServers.%d.customProperties.prop.%s" % (serverIdx, cpropname), cpropval)
			#				else:
			#					retval.put("app.coregroup.coreGroupServers.%d.customProperties.prop.%s" % (serverIdx, cpropname), "%s|%s" % ( cpropval, cpropdesc))			
			#					
			#retval.put("app.coregroup.coreGroupServers.count", "%d" % ( serverIdx))
					
			preferredCoordinatorServers = wsadminToList(AdminConfig.showAttribute(cgId,"preferredCoordinatorServers"))
			serverIdx = 0
			for preferredCoordinatorServer in preferredCoordinatorServers:
					if (isEmpty(preferredCoordinatorServer)):
							continue
					
					serverIdx = serverIdx + 1
					serverName = AdminConfig.showAttribute(preferredCoordinatorServer,"serverName")
					nodeName = AdminConfig.showAttribute(preferredCoordinatorServer,"nodeName")
					retval.put("app.coregroup.preferredCoordinatorServers.%d.serverName"% (serverIdx), serverName)
					retval.put("app.coregroup.preferredCoordinatorServers.%d.nodeName"% (serverIdx), nodeName)
					collectSimpleProperties(retval,"app.coregroup.preferredCoordinatorServers.%d.prop"% (serverIdx), preferredCoordinatorServer,["serverName","nodeName"])	
			
			retval.put("app.coregroup.preferredCoordinatorServers.count", "%d" % ( serverIdx))
			
			policyTypes = ["AllActivePolicy", "NoOpPolicy", "PreferredServerPolicy", "MOfNPolicy", "OneOfNPolicy", "StaticPolicy"]
			
			policies = AdminConfig.showAttribute(cgId,"policies")
			policyList = wsadminToList(policies)
			if (not isEmpty(policies)):
					pidx = 0
					for policy in policyList:
							pidx = pidx + 1
							for policyType in policyTypes:
									if (policy.find(policyType) > 0):
											retval.put("app.coregroup.policies.%d.policyType" % ( pidx), policyType)
											break
							
							
							collectSimpleProperties(retval,"app.coregroup.policies.%d.prop" % (pidx), policy, [])
							pname = retval.remove("app.coregroup.policies.%d.prop.name" % (pidx))
							retval.put("app.coregroup.policies.%d.name" % pidx, pname)
							
							pdesc = retval.get("app.coregroup.policies.%d.prop.description" % (pidx))
							if (pdesc == None):
							  retval.put("app.coregroup.policies.%d.prop.description" % ( pidx), "")
							
							
							#getMatchCriteriaPropertiesForPolicy(retval,policy,"app.coregroup.policies.%d" % (pidx))
							
							collectCustomProperties(retval,"app.coregroup.policies.%d.customProperties" %  (pidx), policy, "customProperties")
							  							
							# Not all policies have preferred servers
							try:
									preferredServers = AdminConfig.showAttribute(policy,"preferredServers")
							except:
									preferredServers = ""
							
							if (not isEmpty(preferredServers)):
									serverIdx = 0
									for svr in wsadminToList(preferredServers):
											if (isEmpty(svr)): continue
											serverIdx = serverIdx + 1
											
											collectSimpleProperties(retval,"app.coregroup.policies.%d.preferredServers.%d"% (pidx,serverIdx),svr)
											
											#serverName = AdminConfig.showAttribute(svr,"serverName")
											#nodeName = AdminConfig.showAttribute(svr,"nodeName")
											#retval.put("app.coregroup.policies.%d.preferredServers.%d.serverName"% (pidx,serverIdx),serverName)
											#retval.put("app.coregroup.policies.%d.preferredServers.%d.nodeName"% (pidx,serverIdx),nodeName)
											
									
									retval.put("app.coregroup.policies.%d.preferredServers.count" % (pidx), "%d" % (serverIdx))
											
						
					retval.put("app.coregroup.policies.count" , "%d" % (pidx))		
	except:
		_app_trace("Error getting coregroup properties","exception")
		raise StandardError("Error getting coregroup properties")
	
	_app_trace("getCoreGroupProperties()" ,"exit")
	return retval
	
#-------------------------------------------------------------------------------
# getMatchCriteriaPropertiesForPolicy
#
# Returns the match criteria of a policy as set of properties
#-------------------------------------------------------------------------------
def getMatchCriteriaPropertiesForPolicy(propSet,policy,policyPrefix=None):
  _app_trace("getMatchCriteriaPropertiesForPolicy(propSet,%s,%s)" % (policy,policyPrefix),"entry")
  try:
    if (propSet == None):
      propSet = java.util.Properties()
    
    retval = propSet
    
    if (isEmpty(policyPrefix)):
      policyPrefix = "policy"
    
    matchCriteria = AdminConfig.showAttribute(policy,"MatchCriteria")
    if (not isEmpty(matchCriteria)):
        mcidx = 0
        for mc in wsadminToList(matchCriteria):
            if (isEmpty(mc)): continue
            mcidx = mcidx+1
            collectSimpleProperties(retval,"%s.matchCriteria.%d" % (policyPrefix,mcidx),mc)
            mcdesc = retval.get("%s.matchCriteria.%d.description" % (policyPrefix,mcidx))
            if (mcdesc == None):
              retval.put("%s.matchCriteria.%d.description" % (policyPrefix,mcidx),"")
                                
        retval.put("%s.matchCriteria.count" % (policyPrefix), "%d" % (mcidx))

  except:
    _app_trace("Unexpected error in getMatchCriteriaPropertiesForPolicy","exception")
    raise StandardError("Unexpected error in getMatchCriteriaPropertiesForPolicy")
  
  _app_trace("getMatchCriteriaPropertiesForPolicy()","exit")
  return retval