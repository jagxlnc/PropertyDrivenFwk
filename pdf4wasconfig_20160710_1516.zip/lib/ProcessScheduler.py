# ProcessScheduler.py
#
# This module contains the functions that process the input properties for SchedulerProvider and
# Scheduler definitions.  The properties should have already been loaded into a dictionary
# prior to calling the processSchedulers() function.
#
# Primary function: 
#    processSchedulers()
#
# Related modules:
#		 Schedulers.py - Contains functions used to create/modify Schedulers
#    Utils.py - Utility methods
#
# Property Syntax:
#
#
# -------------------------------------------------------------------------------
# ITERATE Support:
#
# These sample properties illustrate how to use the @ITERATE macro to apply
# settings to multiple schedulers.  The @ITERATE can be used in the scope fields
# (cluster,node,server) or in the scheduler name field.
# -------------------------------------------------------------------------------
# 
# app.scheduler.provider.1.cluster = @ITERATE(Sc*)
# app.scheduler.provider.1.node = 
# app.scheduler.provider.1.server = 
# app.scheduler.provider.1.name = SchedulerProvider
# 
# app.scheduler.provider.1.scheduler.1.name = @ITERATE(C*)
# app.scheduler.provider.1.scheduler.1.prop.pollInterval = 26
#
# app.scheduler.provider.1.scheduler.1.resourceProperties.prop.daemonAutoStart = java.lang.String|false|false
#
# app.scheduler.provider.2.cluster = 
# app.scheduler.provider.2.node = @ITERATE(*)
# app.scheduler.provider.2.server = @ITERATE(*)
# app.scheduler.provider.2.name = SchedulerProvider
# 
# app.scheduler.provider.2.scheduler.1.name = @ITERATE(ServerScheduler*)
# app.scheduler.provider.2.scheduler.1.prop.pollInterval = 26


#-------------------------------------------------------------------------------
# processIndividualScheduler
#
# Processes the settings for a specific scheduler. The scheduler will be updated if
# it exists (schedulerId passed in or found on lookup) or created if it does not 
#
# Parameters:
#    schedulerInfo - dictionary containing properties to be processed
#    schedulerPrefix - property prefix for the particular scheduler to be processed
#    schedulerName - Name of the scheduler
#    providerId - configuration ID of the SchdulerProvider
#    clusterName, nodeName, serverName - scope information of provider for logging purposes
#    schedulerId (optional) - if None, then will check to see if scheduler exists
#-------------------------------------------------------------------------------
def processIndividualScheduler(schedulerInfo,schedulerPrefix,schedulerName,providerId,clusterName,nodeName,serverName,schedulerId=None):
  try:
    scopeInfo = scopeInfoString(clusterName,nodeName,serverName)
    
    if (schedulerId == None):
      # See if the scheduler exists
      schedulerId = findSchedulerWithName(schedulerName,providerId)
    
    if (isEmpty(schedulerId)):
      schedulerProps = getPropList(schedulerInfo,schedulerPrefix)
      resourceProps = getPropList(schedulerInfo,"%s.resourceProperties" % schedulerPrefix)
      schedulerId = createScheduler(schedulerName, schedulerProps, resourceProps,providerId)
      _app_message("Created scheduler %s at %s scope" % (schedulerName,scopeInfo))
      
    else:
      existingProps = getSchedulerProperties(schedulerId);
      schedulerProps = getPropListDifferences(schedulerInfo, schedulerPrefix, existingProps, "app.scheduler")
      resourceProps = getPropListDifferences(schedulerInfo, "%s.resourceProperties" % schedulerPrefix, existingProps, "app.scheduler.resourceProperties")
      
      if (len(schedulerProps) > 0 or len(resourceProps) > 0):
        updateScheduler(schedulerId,schedulerProps,resourceProps)
        _app_message("Updated Scheduler %s at %s scope" % (schedulerName,scopeInfo))
      else:
        _app_message("No need to update scheduler %s at %s scope" % (schedulerName,scopeInfo))
  except:
    _app_exception("Unexpected error in processIndividualScheduler: %s %s %s" % (schedulerName, providerId,schedulerPrefix))

#-------------------------------------------------------------------------------
# processIndividualSchedulerProvider
#
# Process the settings for a single SchedulerProvider and the schduler settings
# associated with it.
#
# Parameters:
#    schedulerInfo - dictionary containing properties to be processed
#    prefix - property prefix for the particular SchedulerProvider

#-------------------------------------------------------------------------------
def processIndividualSchedulerProvider(schedulerInfo,prefix):
  
  _app_trace("processIndividualSchedulerProvider(schedulerInfo,%s)" % prefix,"entry")
  
  try:
    #print "Processing %s" % prefix
    schedulerCount = int(schedulerInfo.get("%s.scheduler.count"%prefix,"0"))
    
    
    if (schedulerCount > 0):
      clusterName = schedulerInfo.get("%s.cluster" % prefix)
      nodeName = schedulerInfo.get("%s.node" % prefix)
      serverName = schedulerInfo.get("%s.server" % prefix)
      
      
      for schedulerIndex in range(1,schedulerCount+1):
        schedulerPrefix = "%s.scheduler.%d" % (prefix,schedulerIndex)
        
        schedulerName = schedulerInfo.get("%s.name" % schedulerPrefix)
        if (isEmpty(schedulerName)):
          # partial list
          #print "No name"
          continue
        
        
        if (schedulerName.find("@ITERATE") >= 0):
          # We'll apply settings to matching Schedulers
          tempArgs = parseFunctionParms(schedulerName)
          schedulerPattern = None
          if (len(tempArgs) > 0):
            schedulerPattern = tempArgs[0]
          else:
            schedulerPattern = "*"
          
          if (schedulerPattern.find("*") >= 0):
            schedulerPattern = wildcardToRegExpString(schedulerPattern)
          
          providerId = findSchedulerProviderAtScope(clusterName, nodeName, serverName)
          if (isEmpty(providerId)):
            _app_message("Unable to find %s SchedulerProvider at scope c=%s n=%s s=%s" % (prefix, clusterName, nodeName, serverName))
            exit()
            
          schedulerList = findMatchingSchedulers(schedulerPattern,providerId)
          if (len(schedulerList) == 0):
            _app_message("No matching schedulers name=%s c=%s n=%s s=%s" % (schedulerPattern, clusterName,nodeName,serverName))
          else:
            for schedulerId in schedulerList:
              if (isEmpty(schedulerId)):
                continue
              tempName = AdminConfig.showAttribute(schedulerId,"name")
              processIndividualScheduler(schedulerInfo,schedulerPrefix,tempName,providerId,clusterName,nodeName,serverName,schedulerId)
              
          
        else:
          providerId = findSchedulerProviderAtScope(clusterName, nodeName, serverName)
          if (isEmpty(providerId)):
            _app_message("Unable to find %s SchedulerProvider at scope c=%s n=%s s=%s" % (prefix, clusterName, nodeName, serverName))
            exit()
          else:
            processIndividualScheduler(schedulerInfo,schedulerPrefix,schedulerName,providerId,clusterName,nodeName,serverName)   
    #endif
  except:
    _app_exception("Unexpected error in processIndividualSchedulerProvider(schedulerInfo,%s)" % prefix)
    
  _app_trace("processIndividualSchedulerProvider(schedulerInfo,%s)" % prefix,"exit")

#---------------------------------------------------------------------------------------------------
# processScheduler(): Process all of the Scheduler entries from the schedulerInfo set
#
# Parameters:
#   schedulerInfo: a dictionary with the input properties to be processed.
#---------------------------------------------------------------------------------------------------
def processSchedulers(schedulerInfo):

  _app_trace("processSchedulers()","entry")
  
  try:
    providerCount = int(schedulerInfo.get("app.scheduler.provider.count","0"))
  	
    if (providerCount > 0):
      # Create Individual Scheduler Resources
  
      for schedulerIndex in range(1, (providerCount + 1)):
        prefix = "app.scheduler.provider.%d" % (schedulerIndex)
        providerName = schedulerInfo.get("%s.name" % prefix,"")
        if (isEmpty(providerName)):
        		# Partial input property file, skip this provider
        		continue
        
        clusterParm = schedulerInfo.get("%s.cluster" % prefix,"")
        nodeParm = schedulerInfo.get("%s.node" % prefix,"")
        serverParm = schedulerInfo.get("%s.server" % prefix,"")
        
        doIterationProcessing = 0
        if (providerName.find("@ITERATE") >= 0):
          
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(providerName)
          if (len(tempArgs) > 0):
            providerName = tempArgs[0]
           
          else:
            providerName = "*"
  
        if (clusterParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(clusterParm)
          if (len(tempArgs) > 0):
            clusterParm = tempArgs[0]
          else:
            clusterParm = "*"
  
        if (nodeParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(nodeParm)
          if (len(tempArgs) > 0):
            nodeParm = tempArgs[0]
          else:
            nodeParm = "*"          
  
        if (serverParm.find("@ITERATE") >= 0):
          doIterationProcessing = 1
          tempArgs = parseFunctionParms(serverParm)
          if (len(tempArgs) > 0):
            serverParm = tempArgs[0]
          else:
            serverParm = "*"    
        
        providerPattern = providerName
        clusterPattern = clusterParm
        nodePattern = nodeParm
        serverPattern = serverParm 
        
        if (doIterationProcessing):
          if (providerPattern.find("*") >= 0):
            providerPattern = wildcardToRegExpString(providerPattern)
          if (serverPattern.find("*") >= 0):
            serverPattern = wildcardToRegExpString(serverPattern)
          if (nodePattern.find("*") >= 0):
            nodePattern = wildcardToRegExpString(nodePattern)
          if (clusterPattern.find("*") >= 0):
            clusterPattern = wildcardToRegExpString(clusterPattern)
            
          providerIds = findMatchingSchedulerProviders(clusterPattern, nodePattern, serverPattern)
          
          if (len(providerIds) > 0):
            _app_message("%d Scheduler providers matched the @ITERATE patterns name=%s, cluster=%s, node= %s, server = %s" % (len(providerIds), providerName, clusterParm, nodeParm, serverParm))
            
            
            for providerId in providerIds:
              if (isEmpty(providerId)): continue
              tempName = AdminConfig.showAttribute(providerId,"name")
              tc,tn,ts,tdc,tapp,tappdep = getScope(providerId)
              
              # We're going to spoof the settings into the schedulerInfo
              schedulerInfo["%s.name" % prefix] = tempName
              schedulerInfo["%s.cluster" % prefix] = tc
              schedulerInfo["%s.node" % prefix] = tn
              schedulerInfo["%s.server" % prefix] = ts
              
              processIndividualSchedulerProvider(schedulerInfo,prefix)
              
              
          else:
            _app_message("No Scheduler providers matched the @ITERATE patterns name=%s, cluster=%s, node= %s, server = %s" % (providerName, clusterParm, nodeParm, serverParm))
        else:
          processIndividualSchedulerProvider(schedulerInfo,prefix)
  
    else:
        _app_message("Skipping Scheduler Resources...")
  except:
    _app_trace("Unexpected error in processScheduler","exception")
    exit()
    
  _app_trace("processSchedulers()","exit")