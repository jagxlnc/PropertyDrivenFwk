##########################################################################
# File Name:    VirtualHost.py
# Description:  This file contains function definitions to create, delete
#               and list Replication Domains
#
#               createVirtualHost
#               deleteVirtualHost
#               listVirtualHosts
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createVirtualHost: Create a VirtualHost
#
# SYNTAX:
#    createVirtualHost name 
#
# PARAMETERS:
#    name	-	Name of VirtualHost
#
# USAGE NOTES:
#    Creates a Virtual Host named 'name' 
#
# RETURNS:
#    ObjID	Object ID of new VirtualHost
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addVirtualHost(name):
	createVirtualHost(name)
	
def createVirtualHost(name):

	global progInfo

	retval = None

	try:
		traceStr = "createVirtualHost(%s)" % (name)
		_app_trace(traceStr, "entry")	

		if isEmpty(name):
			raise StandardError("No name provided")

		#	Check it doesn't already exist 
		if not isEmpty(getVirtualHost(name)):
			raise StandardError("Cannot create %s, already exists" % (name))
			return retval

		cellId = AdminConfig.getid("/Cell:/")
		vtempl = AdminConfig.listTemplates("VirtualHost")

		_app_trace("Running command: AdminConfig.createUsingTemplate('VirtualHost', %s, [[ 'name', %s]], %s )" % (cellId, name, vtempl))

		retval = AdminConfig.createUsingTemplate('VirtualHost', cellId, [['name', name]], vtempl)

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
	except:
		_app_trace("An error was encountered creating the VirtualHost", "exception")
		retval = None

	_app_trace("createVirtualHost(%s)" %(retval), "exit")
	return retval

def deleteAliases(vhId):

	global progInfo

	retval = None

	try:
		traceStr = "deleteAliases(%s)" % (vhId)
		_app_trace(traceStr, "entry")	

		if isEmpty(vhId):
			raise StandardError("No vhId provided")

		aliases = wsadminToList(AdminConfig.showAttribute(vhId, "aliases"))
		
		for alias in aliases:
			_app_trace("Running command: AdminConfig.remove(%s)" % (aliases))
			retval = AdminConfig.remove(alias)

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
	except:
		_app_trace("An error was encountered deleting the aliases", "exception")
		retval = None

	_app_trace("deleteAlises(%s)" %(retval), "exit")
	return retval
	

#-----------------------------------------------------------------------------
# getAliases
# Returns the host/port aliases as a list of host|port strings that can be
# compared against input strings
#
# @JJM
#-----------------------------------------------------------------------------
def getAliases(vhId):
	global progInfo

	retval = []

	try:
		traceStr = "getAliases(%s)" % (vhId)
		_app_trace(traceStr, "entry")	

		if isEmpty(vhId):
			raise StandardError("No vhId provided")

		aliases = wsadminToList(AdminConfig.showAttribute(vhId, "aliases"))
		
		for alias in aliases:
				hostname = AdminConfig.showAttribute(alias,"hostname")
				port = AdminConfig.showAttribute(alias,"port")
				
				retval.append(hostname+"|"+port)

	except:
		_app_trace("An error was encountered searching the aliases", "exception")
		retval = []

	_app_trace("getAliases(%s)" %(retval), "exit")
	return retval


#---------------------------------------------------------------------------------
# addAliasToVirtualhost
# Add alias to a virtual host, but first check to make sure its not already there
#---------------------------------------------------------------------------------
def addAliasToVirtualhost(vhId, hostname, port):
	global progInfo

	retval = None

	try:
		traceStr = "addAliasToVirtualhost(%s, %s, %s)" % (vhId,hostname,port)
		_app_trace(traceStr, "entry")	

		if isEmpty(vhId):
			raise StandardError("No vhId provided")

		createFlag = 1
		
		aliases = wsadminToList(AdminConfig.showAttribute(vhId, "aliases"))
		
		
		for alias in aliases:
				existingHostname = AdminConfig.showAttribute(alias,"hostname")
				existingPort = AdminConfig.showAttribute(alias,"port")
				
				if (existingHostname == hostname and existingPort == port):
						_app_trace("Alias %s %s already exists for virtual host %s" % (hostname, port, vhId))
						createFlag = 0
						break
		
		if (createFlag):
				hostAlias = "[[hostname %s][port %d]]" % (hostname, port)
				traceStr = "AdminConfig.create('HostAlias', %s, %s)" % (vhId, hostAlias)
				_app_trace("Running command: %s" % (traceStr))

				retval = AdminConfig.create("HostAlias", vhId, hostAlias)
				_app_trace("Added port %d to virtual host %s" % (port, AdminConfig.showAttribute(vhId, "name")))
				
	except:
		_app_trace("An error was encountered setting up the alias", "exception")
		retval = None

	_app_trace("addAliasToVirtualhost(%s)" %(retval), "exit")
	return retval
		

