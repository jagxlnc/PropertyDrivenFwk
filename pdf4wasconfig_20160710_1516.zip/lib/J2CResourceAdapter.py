####################################################################################
# J2CResourceAdapter.py
# This module contains functions that are used to find, create, modify, and pull properties from
# J2CResourceAdapter configuration items.
#
# Currently supported: J2CAdminObject and J2CConnectionFactory
#
####################################################################################


def getJ2CResourceAdapter(name, cluster=None,node=None,server=None,dynamicCluster=None,appDeployment=None):
  _app_trace("getJ2CResourceAdapter(%s,%s,%s,%s,%s,%s)" % ( name, cluster,node,server,dynamicCluster,appDeployment),"entry")
  retval = None
  try:
    tempList = findItemsAtScope("J2CResourceAdapter:%s" % name,cluster, node, server, dyncluster=dynamicCluster, appName=None, appDeployment=appDeployment)
    if (len(tempList) > 0):
      retval = tempList[0]
  except:
    _app_exception("Unexpected error in getJ2CResourceAdapter")
  
  _app_trace("getJ2CResourceAdapter(retval=%s)"% retval,"exit")
  return retval

#-------------------------------------------------------------------------------
# getJ2CResourceAdapterProperties
#
# Returns a dictionary with properties of existing J2CResourceAdapter
#    resourceAdapter.prop.XXXX - keys for base properties
#    resourceAdapter.propertiesSet.properties.resourceProperties
#-------------------------------------------------------------------------------
def getJ2CResourceAdapterProperties(raId):
  _app_entry("getJ2CResourceAdapterProperties(%s)" % raId)
  try:
    retval = {}
    collectSimpleProperties(retval,"resourceAdapter.prop",raId,["name"])
    collectResourceProperties(retval,raId,"propertySet","resourceAdapter.propertySet")
  except:
    _app_exception("Unexpected error in getJ2CResourceAdapterProperties(%s)"% raId)
  
  _app_exit("getJ2CResourceAdapterProperties(retval=%d entries)" % len(retval))
  return retval

#-------------------------------------------------------------------------------
# modifyJ2CResourceAdapter
# 
# Parameters:
#     raId - Configuration ID of the resource adapter
#     baseProperties - base J2CResourceAdapter properties to modify
#     resourceProperties - J2C Resource Properties to modify
#-------------------------------------------------------------------------------    
def modifyJ2CResourceAdapter(raId,baseProperties,resourceProperties=None):
  try:
    if (baseProperties != None and len(baseProperties) > 0):
      attrs = propsToAttrList(baseProperties)
      if (modifyObject(raId,attrs)):
        raise StandardError("Error modifying base properties of J2CResourceAdapter %s" % raId)
    
    if (resourceProperties != None and len(resourceProperties) > 0):
      updateJ2EEResourcePropertySet(raId, resourceProperties, attributeName="propertySet")
      
  except:
    _app_exception("Unexpected error in modifyJ2CResourceAdapter(%s)"% raId)

#-------------------------------------------------------------------------------
# createJ2CAdminObject
#
# Creates a new J2CAdminObject
#
# Parameters:
#    resourceAdapterId - ID of parent J2CResourceAdapter
#    name - name of J2CAdminObject
#    jndiName - JNDI name for J2CAdminObject
#    description 
#    adminObjectInterface - used to find corresponding AdminObject to reference
#    resourceProps - A property set with key = type|requred|value|desc syntax used 
#                    to define resource properties
#
# Returns:
#    configuration ID or None if error
#-------------------------------------------------------------------------------
def createJ2CAdminObject(resourceAdapterId, name, jndiName, description, adminObjectInterface, resourceProps):
	_app_trace("createJ2CAdminObject(%s,%s,%s,%s,%s,%s)" % (resourceAdapterId, name, jndiName, description, adminObjectInterface, resourceProps), "entry")
	retval = None
	try:
	
		if (description == None):
				description = ""
				
		adminObject = ""
		if (not isEmpty(adminObjectInterface)):
			# Find the first (only?) AdminObject and we'll use it
			adminObjects = AdminConfig.list("AdminObject",resourceAdapterId).split(progInfo["line.separator"])
			for tempAdminObject in adminObjects:
					if (isEmpty(tempAdminObject)):
							continue
					if (adminObjectInterface == AdminConfig.showAttribute(tempAdminObject,"adminObjectInterface")):
							adminObject = tempAdminObject
		
		attrs = [ ["name", name], ["jndiName", jndiName], ["description", description]]
		if (not isEmpty(adminObject)):
				attrs.append(["adminObject",adminObject])
		
		_app_trace("About to call: AdminConfig.create(J2CAdminObject,%s,%s)" % (resourceAdapterId,attrs))
		retval = AdminConfig.create("J2CAdminObject",resourceAdapterId,attrs)
		
		if (resourceProps != None and resourceProps.size() > 0):
				errMsg = updateCustomProperties(retval, "properties", "J2EEResourceProperty", resourceProps)
				if (not isEmpty(errMsg)):
						raise StandardError("Error setting resource properties: %s" % errMsg)
	
	except:
		_app_trace("Unexpected error creating J2CAdminObject","exception")
		retval = None
	
	_app_trace("createJ2CAdminObject(retval = %s)" % retval, "exit")
	return retval


#-------------------------------------------------------------------------------
# modifyJ2CAdminObject
# 
# Updates an existing J2CAdminObject.
#
# Parameters:
#     objectId - ID of J2CAdminObject to update
#     modifiedProps - property set with key/values of base properties to change
#     resourceProps - A property set with key = type|requred|value|desc syntax used 
#                     to define resource properties
#
# Returns
#   objectId - ID of update item, None if an error occurred
#-------------------------------------------------------------------------------
def modifyJ2CAdminObject(objectId, modifiedProps, resourceProps):
	_app_trace("modifyJ2CAdminObject(%s,%s,%s)" % (objectId, modifiedProps, resourceProps), "entry")
	retval = None
	try:
	
		if (modifiedProps != None and modifiedProps.size() > 0):
			attrs = []
			for key in modifiedProps.keys():
					attrs.append( [ key, modifiedProps.get(key)] )
					
					if (modifyObject(objectId, attrs)):
						raise StandardError("Error modifying object")
						
						
		
		if (resourceProps != None and resourceProps.size() > 0):
				errMsg = updateCustomProperties(objectId, "properties", "J2EEResourceProperty", resourceProps)
				if (not isEmpty(errMsg)):
						raise StandardError("Error updating resource properties: %s" % errMsg)
						
		retval = objectId
	
	except:
		_app_trace("Unexpected error modifying J2CAdminObject","exception")
		retval = None
	
	_app_trace("modifyJ2CAdminObject(retval = %s)" % retval, "exit")
	return retval

#-------------------------------------------------------------------------------
# findJ2CAdminObject 
#  		Finds the J2CAdminObject with the supplied name and defined under the specified
#     resourceAdapater ID
#
# Parameters:
#    name - name of J2CAdminObject to find
#    resourceAdapterId - ID of J2CResourceAdapter to search under
#-------------------------------------------------------------------------------
def findJ2CAdminObject(name, resourceAdapterId):
	_app_trace("findJ2CAdminObject(%s,%s)" % (name, resourceAdapterId),"entry")
	retval = None
	try:
	
		j2cAdminObjects = AdminConfig.showAttribute(resourceAdapterId, "j2cAdminObjects")
		if (not isEmpty(j2cAdminObjects)):
			j2cAdminObjects = wsadminToList(j2cAdminObjects)
			for j2cAdminObject in j2cAdminObjects:
					if (name == AdminConfig.showAttribute(j2cAdminObject,"name")):
							retval = j2cAdminObject
							break
	
	except:
		_app_trace("Error searching for the J2CAdminObject","exception")
		raise StandardError("Error searching for the J2CAdminObject")
	
	_app_trace("findJ2CAdminObject(retval = %s)" % (retval),"exit")
	return retval

#-------------------------------------------------------------------------------
# getJ2CAdminObjectProperties
#
# Returns a property set with properties that represent the configuration 
# of the J2CAdminObject
#
#  Input:
#      j2cAdminObject - Configuration ID of the item
#  Output: 
#      java.util.Properties object with following syntax:
#						Base props: j2cAdminObject.prop.key = value              
# 					Resource props: j2cAdminObject.properties.prop.key = type|required|value|description
#-------------------------------------------------------------------------------
def getJ2CAdminObjectProperties(j2cAdminObject):
	
	_app_trace("getJ2CAdminObjectProperties(%s)" % j2cAdminObject,"entry")
	retval = None
	try:
		retval = java.util.Properties()
	
		retval.put("j2cAdminObject.name", AdminConfig.showAttribute(j2cAdminObject,"name"))
		
		collectSimpleProperties(retval, "j2cAdminObject.prop", j2cAdminObject, ["name"])
		resourcePropList = wsadminToList(AdminConfig.showAttribute(j2cAdminObject,"properties"))
		collectResourcePropertiesList(retval,"j2cAdminObject.properties", resourcePropList)
		# Need to dump information on the AdminObject this J2CAdminObject refers to
		adminObjectId = AdminConfig.showAttribute(j2cAdminObject,"adminObject")
		if (not isEmpty(adminObjectId)):
				collectSimpleProperties(retval, "j2cAdminObject.adminObject.prop", adminObjectId)
		
	except:
		_app_trace("Error getting J2CAdminObject properties","exception")
		raise StandardError("Error getting J2CAdminObject properties")
		
	_app_trace("getJ2CAdminObjectProperties()","exit")
	return retval


#-------------------------------------------------------------------------------
# createJ2CConnectionFactory
# 
#-------------------------------------------------------------------------------
def createJ2CConnectionFactory(resourceAdapterId, cfName, connectionFactoryInterface, cfProps, connPoolProps, connPoolCustomProps, pretestProps, mappingProps, resourceProps):

	_app_trace("createJ2CConnectionFactory(%s,%s,%s,%s,%s,%s,%s,%s,%s)" % (resourceAdapterId, cfName, connectionFactoryInterface, cfProps, connPoolProps, connPoolCustomProps, pretestProps, mappingProps, resourceProps),"entry")
	retval = None
	try:
	
		attrs = [ ["name", cfName]]
		
		if (cfProps != None and cfProps.size() > 0):
				for key in cfProps.keys():
						val = cfProps.get(key)
						attrs.append([key, val])
						
		# Now lets see if we need to set up the connectionDefinition attribute
		if (not isEmpty(connectionFactoryInterface)):
				connDefs = AdminConfig.list("ConnectionDefinition",resourceAdapterId).split(progInfo["line.separator"])
				for connDef in connDefs:
						if (isEmpty(connDef)):
								continue
						if (connectionFactoryInterface == AdminConfig.showAttribute(connDef,"connectionFactoryInterface")):
								# Found a match
								attrs.append(["connectionDefinition",connDef])
								break
		
		# Ok, time to create
		_app_trace("About to call AdminConfig.create(J2CConnectionFactory,%s,%s)" %(resourceAdapterId, attrs))
		cf = AdminConfig.create("J2CConnectionFactory",resourceAdapterId, attrs)
		
		connPoolId = None
		if (connPoolProps != None and connPoolProps.size() > 0):
				connPoolAttrs = []
				for key in connPoolProps.keys():
					val = connPoolProps.get(key)
					connPoolAttrs.append([key,val])
					
				connPoolId = AdminConfig.showAttribute(cf,"connectionPool")
				if (isEmpty(connPoolId)):
						# Need to create
						_app_trace("About to call AdminConfig.create(ConnectionPool, %s,%s)" % ( cf, connPoolAttrs))
						connPoolId = AdminConfig.create("ConnectionPool", cf, connPoolAttrs)
				else:
						# Need to update
						if (modifyObject(connPoolId,connPoolAttrs)):
								raise StandardError("Problem occurred updating Connection Pool for connection factory %s" % cfName)

		# Connection pool custom properties
		if (connPoolCustomProps != None and connPoolCustomProps.size() > 0):
				if (connPoolId == None):
						connPoolId = AdminConfig.showAttribute(cf,"connectionPool")
						if (isEmpty(connPoolId)):
								connPoolId = AdminConfig.create("ConnectionPool",cf,[])
				
				errMsg = updateCustomProperties(connPoolId, "properties", "Property", connPoolCustomProps)
				if (not isEmpty(errMsg)):
						raise StandardError("Error updating connection pool custom properties: %s" % errMsg)

		# Pretest
		if (pretestProps != None and pretestProps.size() > 0):
				pretestAttrs = []
				for key in pretestProps.keys():
						val = pretestProps.get(key)
						pretestAttrs.append([key,val])
						
				pretestId = AdminConfig.showAttribute(cf,"preTestConfig")
				if (isEmpty(pretestId)):
						# Create
						_app_trace("About to call AdminConfig.create(ConnectionTest,%s,%s)" % (cf,pretestAttrs))
						pretestId = AdminConfig.create("ConnectionTest",cf,pretestAttrs)
				else:
						# Update
						if (modifyObject(pretestId,pretestAttrs)):
								raise StandardError("Error updated ConnectionTest for connection factory %s" % cfName)

		# Mapping
		if (mappingProps != None and mappingProps.size() > 0):
				mappingAttrs = []
				for key in mappingProps.keys():
					val = mappingProps.get(key)
					mappingAttrs.append([key,val])
					
					mappingId = AdminConfig.showAttribute(cf,"mapping")
					if (isEmpty(mappingId)):
							# Create
							_app_trace("About to call AdminConfig.create(MappingModule,%s,%s)" %(cf,mappingAttrs))
							mappingId = AdminConfig.create("MappingModule",cf,mappingAttrs)
					else:
							# Update
							if (modifyObject(mappingId, mappingAttrs)):
									raise StandardError("Problem updating mapping module for connection factory %s" % cfName)

		# Resource Properties
		if (resourceProps != None and resourceProps.size() > 0):
				propertySetId = AdminConfig.showAttribute(cf,"propertySet")
				if (isEmpty(propertySetId )):
						propertySetId = AdminConfig.create("J2EEResourcePropertySet",cf,[])
				
				errMsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
				if (not isEmpty(errMsg)):
						raise StandardError("Error updating resource properties for connection factory %s" % cfName)
						
		
		# Ok, we should be good to go
		retval = cf
	
	except:
		_app_trace("Error creating J2CConnectionFactory", "exception")
		retval = None
		
	_app_trace("createJ2CConnectionFactory(retval = %s)" % retval,"exit")
	return retval
	
#-------------------------------------------------------------------------------
# createJ2CConnectionFactory
#-------------------------------------------------------------------------------
def modifyJ2CConnectionFactory(cf, resourceAdapterId, connectionFactoryInterface, cfProps, connPoolProps, connPoolCustomProps, pretestProps, mappingProps, resourceProps):
  _app_trace("modifyJ2CConnectionFactory(%s,%s,%s,%s,%s,%s,%s,%s,%s)" % (cf, resourceAdapterId, connectionFactoryInterface, cfProps, connPoolProps, connPoolCustomProps, pretestProps, mappingProps, resourceProps),"entry")
  retval = None
  try:
  
    cfName = AdminConfig.showAttribute(cf, "name")
  
    attrs = [ ]
    
    if (cfProps != None and cfProps.size() > 0):
        for key in cfProps.keys():
            val = cfProps.get(key)
            attrs.append([key, val])
            
    # Now lets see if we need to set up the connectionDefinition attribute
    if (not isEmpty(connectionFactoryInterface)):
        connDefs = AdminConfig.list("ConnectionDefinition",resourceAdapterId).split(progInfo["line.separator"])
        for connDef in connDefs:
            if (isEmpty(connDef)):
                continue
            if (connectionFactoryInterface == AdminConfig.showAttribute(connDef,"connectionFactoryInterface")):
                # Found a match
                attrs.append(["connectionDefinition",connDef])
                break
    
    # Ok, time to update
    if (len(attrs) > 0):
      if (modifyObject(cf,attrs)):
        raise StandardError("Error updating J2CConnectionFactory %s" % cfName)
    
    connPoolId = None
    if (connPoolProps != None and connPoolProps.size() > 0):
        connPoolAttrs = []
        for key in connPoolProps.keys():
          val = connPoolProps.get(key)
          connPoolAttrs.append([key,val])
          
        connPoolId = AdminConfig.showAttribute(cf,"connectionPool")
        if (isEmpty(connPoolId)):
            # Need to create
            _app_trace("About to call AdminConfig.create(ConnectionPool, %s,%s)" % ( cf, connPoolAttrs))
            connPoolId = AdminConfig.create("ConnectionPool", cf, connPoolAttrs)
        else:
            # Need to update
            if (modifyObject(connPoolId,connPoolAttrs)):
                raise StandardError("Problem occurred updating Connection Pool for connection factory %s" % cfName)

    # Connection pool custom properties
    if (connPoolCustomProps != None and connPoolCustomProps.size() > 0):
        if (connPoolId == None):
            connPoolId = AdminConfig.showAttribute(cf,"connectionPool")
            if (isEmpty(connPoolId)):
                connPoolId = AdminConfig.create("ConnectionPool",cf,[])
        
        errMsg = updateCustomProperties(connPoolId, "properties", "Property", connPoolCustomProps)
        if (not isEmpty(errMsg)):
            raise StandardError("Error updating connection pool custom properties: %s" % errMsg)

    # Pretest
    if (pretestProps != None and pretestProps.size() > 0):
        pretestAttrs = []
        for key in pretestProps.keys():
            val = pretestProps.get(key)
            pretestAttrs.append([key,val])
            
        pretestId = AdminConfig.showAttribute(cf,"preTestConfig")
        if (isEmpty(pretestId)):
            # Create
            _app_trace("About to call AdminConfig.create(ConnectionTest,%s,%s)" % (cf,pretestAttrs))
            pretestId = AdminConfig.create("ConnectionTest",cf,pretestAttrs)
        else:
            # Update
            if (modifyObject(pretestId,pretestAttrs)):
                raise StandardError("Error updated ConnectionTest for connection factory %s" % cfName)

    # Mapping
    if (mappingProps != None and mappingProps.size() > 0):
        mappingAttrs = []
        for key in mappingProps.keys():
          val = mappingProps.get(key)
          mappingAttrs.append([key,val])
          
          mappingId = AdminConfig.showAttribute(cf,"mapping")
          if (isEmpty(mappingId)):
              # Create
              _app_trace("About to call AdminConfig.create(MappingModule,%s,%s)" %(cf,mappingAttrs))
              mappingId = AdminConfig.create("MappingModule",cf,mappingAttrs)
          else:
              # Update
              if (modifyObject(mappingId, mappingAttrs)):
                  raise StandardError("Problem updating mapping module for connection factory %s" % cfName)

    # Resource Properties
    if (resourceProps != None and resourceProps.size() > 0):
        propertySetId = AdminConfig.showAttribute(cf,"propertySet")
        if (isEmpty(propertySetId )):
            propertySetId = AdminConfig.create("J2EEResourcePropertySet",cf,[])
        
        errMsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
        if (not isEmpty(errMsg)):
            raise StandardError("Error updating resource properties for connection factory %s" % cfName)
            
    
    # Ok, we should be good to go
    retval = cf
  
  except:
    _app_trace("Error updating J2CConnectionFactory", "exception")
    retval = None
    
  _app_trace("modifyJ2CConnectionFactory(retval = %s)" % retval,"exit")
  return retval


#-------------------------------------------------------------------------------
# findJ2CConnectionFactory
#
# Returns the ID of the connection factory with the specific name
#-------------------------------------------------------------------------------
def findJ2CConnectionFactory(resourceAdapterId, cfName):

	_app_trace("findJ2CConnectionFactory(%s,%s)" % (resourceAdapterId, cfName),"entry")
	retval = None
	try:
		cfList = AdminConfig.list("J2CConnectionFactory", resourceAdapterId).split(progInfo["line.separator"])
		for cf in cfList:
				if (isEmpty(cf)):
						continue
				
				tempName = AdminConfig.showAttribute(cf,"name")
				if (tempName == cfName):
						retval = cf
						break
	
	except:
		_app_trace("Error finding J2CConnectionFactory","exception")
	
	_app_trace("findJ2CConnectionFactory(retval = %s)" % (retval),"exit")
	return retval

#-------------------------------------------------------------------------------
# getJ2CConnectionFactoryProperties
#-------------------------------------------------------------------------------
def getJ2CConnectionFactoryProperties(cf):

	_app_trace("getJ2CConnectionFactoryProperties(%s)" % cf,"entry")
	
	try:
		retval = java.util.Properties()
		
		retval.put("cf.name", AdminConfig.showAttribute(cf,"name"))
		collectSimpleProperties(retval, "cf.prop", cf, ["name"])
		
		# Output connectionDefinition for reference
		connectionDefinition =  AdminConfig.showAttribute(cf,"connectionDefinition")
		if (not isEmpty(connectionDefinition)):
				collectSimpleProperties(retval,"cf.connectionDefinition.prop", connectionDefinition, [])
		
		
		connPool = AdminConfig.showAttribute(cf,"connectionPool")
		if (not isEmpty(connPool)):
				collectSimpleProperties(retval,"cf.connectionPool.prop", connPool, [])
				
				custprops=AdminConfig.showAttribute(connPool,"properties")
				if (not isEmpty(custprops)):
					for cpropsitem in wsadminToList(custprops):
						cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
						cpropname = AdminConfig.showAttribute(cpropsitem,"name")
						cpropval = AdminConfig.showAttribute(cpropsitem,"value")
						if isEmpty(cpropdesc):
							retval.put("cf.connectionPool.properties.prop.%s" % cpropname, cpropval)
						else:
							retval.put("cf.connectionPool.properties.prop.%s" % cpropname, "%s|%s" % ( cpropval, cpropdesc))
				
		preTestConfig = AdminConfig.showAttribute(cf,"preTestConfig")
		if (not isEmpty(preTestConfig)):
				collectSimpleProperties(retval, "cf.preTestConfig.prop", preTestConfig, [])
		
		mapping = AdminConfig.showAttribute(cf,"mapping")
		if (not isEmpty(mapping)):
				collectSimpleProperties(retval, "cf.mapping.prop" , mapping, [])
				
		collectResourceProperties(retval, cf,"propertySet","cf.propertySet")		
		
		# V7 introduced a "properties" attribute
		cfproperties = None
		try:
			cfproperties = AdminConfig.showAttribute(cf,"properties")
		except:
			cfproperties = ""
		
		if (not isEmpty(cfproperties)):
					for cpropsitem in wsadminToList(cfproperties):
						cpropdesc = AdminConfig.showAttribute(cpropsitem,"description")
						cpropname = AdminConfig.showAttribute(cpropsitem,"name")
						cpropval = AdminConfig.showAttribute(cpropsitem,"value")
						if isEmpty(cpropdesc):
							retval.put("cf.properties.prop.%s" % cpropname, cpropval)
						else:
							retval.put("cf.properties.prop.%s" % cpropname, "%s|%s" % ( cpropval, cpropdesc))

	except:
		_app_trace("Error loading Connection Factory properties","exception")
		raise StandardError("Error loading Connection Factory properties")
	
	_app_trace("getJ2CConnectionFactoryProperties()","exit")
	return retval
	
	



#---------------------------------------------
# createJ2CActivationSpec
#
# Creates a new J2CActivationSpec under an existing J2CResourceAdapter
# 
# Note, this method uses AdminTask.createJ2CActivationSpec and only works
# in V7 onwards
#
# Parameters: 
#
#  providerId - Configuration ID of J2CResourceAdapter that defines the activation spec
#  name - name of the new J2CActivationSpec
#  jndiName - JNDI name assigned to new J2CActivationSpec
#  messageListenerType - message listener interface supported by spec, (e.g. javax.jms.MessageListener)
#  actSpecProps - optional dictionary containing properties for base J2CActivationSpec settings
#  resourceProps - properties to be assigned to Resource Properties defined for this J2CActivationSpec
#
# Returns
#  configuration ID of the new activation spec
#---------------------------------------------
def createJ2CActivationSpec(providerId,name,jndiName,messageListenerType,actSpecProps,resourceProps):
  _app_trace("createJ2CActivationSpec(%s,%s,%s,%s,%s,%s)" % (providerId,name,jndiName,messageListenerType,actSpecProps,resourceProps),"entry")
  retval = None
  try:
    if (isEmpty(name)):
      raise StandardError("J2CActivationSpec name not specified")
      
    if (isEmpty(jndiName)):
      raise StandardError("JNDI Name not specified for J2CActivationSpec")
    
    if (isEmpty(messageListenerType)):
      raise StandardError("messageListenerType not specified for J2CActivationSpec")
    
    args = "[-name %s -messageListenerType %s -jndiName %s ]" % (name,messageListenerType,jndiName)
    
    _app_trace("About to call createJ2CActivationSpec(%s,%s)" % (providerId,args))
    retval = AdminTask.createJ2CActivationSpec(providerId, args)
    
    if (actSpecProps != None and len(actSpecProps) > 0):
      modifyObjectProperties(retval,actSpecProps,configurationType="J2CActivationSpec")
    
    if (resourceProps != None and len(resourceProps) > 0):
      errmsg = updateCustomProperties(retval, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Unable to update resourceProperties for %s: %s" % (retval,errmsg))
      
    
  except:
    _app_exception("Unexpected error in createJ2CActivationSpec")
  
  _app_trace("createJ2CActivationSpec(retval=%s)" % retval,"exit")
  return retval

#---------------------------------------------
# modifyJ2CActivationSpec
#
# updates an existing J2ActivationSpec
# 
# Note, this method uses AdminTask.createJ2CActivationSpec and only works
# in V7 onwards
#
# Parameters: 
#
#  activationSpecId - Configuration ID of J2CActivationSpec to be updated
#  actSpecProps - optional dictionary containing properties for base J2CActivationSpec settings
#  resourceProps - properties to be assigned to Resource Properties defined for this J2CActivationSpec
#
# Returns
#  configuration ID of the new activation spec
#---------------------------------------------
def modifyJ2CActivationSpec(activationSpecId,actSpecProps,resourceProps):
  _app_trace("modifyJ2CActivationSpec(%s,%s,%s)" % (activationSpecId,actSpecProps,resourceProps),"entry")
  try:

    if (actSpecProps != None and len(actSpecProps) > 0):
      modifyObjectProperties(activationSpecId,actSpecProps,configurationType="J2CActivationSpec")
    
    if (resourceProps != None and len(resourceProps) > 0):
      errmsg = updateCustomProperties(activationSpecId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Unable to update resourceProperties for %s: %s" % (retval,errmsg))
      
    
  except:
    _app_exception("Unexpected error in modifyJ2CActivationSpec")
  
  _app_trace("modifyJ2CActivationSpec()","exit")

#--------------------------------------------------------------------------------
# Returns a dictionary with key/value pairs that represent the properties of the
# J2CActivationSpec
#   j2cActivationSpec.prop.key = val - attributes of J2CActivationSpec configuration type
#   j2cActivationSpec.properties.prop.key = val - resource properties of J2CActivationSpec 
#--------------------------------------------------------------------------------
def getJ2CActivationSpecProperties(activationSpecId):
  _app_trace("getJ2CActivationSpecProperties(%s)" % (activationSpecId),"entry")
  retval = {}
  
  collectSimpleProperties(retval,"j2cActivationSpec.prop",activationSpecId)
  
  rprops = wsadminToList(AdminConfig.showAttribute(activationSpecId,"resourceProperties"))
  collectResourcePropertiesList(retval,"j2cActivationSpec.properties", rprops)
  
  _app_trace("getJ2CActivationSpecProperties()","exit")
  return retval

#-------------------------------------------------------------------------------
# findJ2CActivationSpec
#
# Searches for activation spec with specified name under existing J2CResourceAdapter
#
# Parameters:
#    providerId - J2CResourceAdapter configuration ID
#    name - name of J2CActivationSpec to search for
#-------------------------------------------------------------------------------
def findJ2CActivationSpec(providerId,name):
  _app_trace("findJ2CActivationSpec(providerId,name)","entry")
  retval = None
  actSpecs = AdminConfig.list("J2CActivationSpec",providerId).splitlines()
  for actSpec in actSpecs:
    if (isEmpty(actSpec)):
      continue
    
    tempName = AdminConfig.showAttribute(actSpec,"name")
    if (tempName == name):
      retval = actSpec
      break
  
  
  _app_trace("findJ2CActivationSpec(retval=%s)" % retval,"exit")
  
  return retval