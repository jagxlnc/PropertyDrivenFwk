##########################################################################
# File Name:    ApplicationServer.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere application servers
#
#               createApplicationServer
#               deleteApplicationServer
#               listApplicationServers
#
#
# It also contains functions for manipulating the subcomponents of the application server
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createApplicationServer: Creates a stand-alone Application Server
#
# SYNTAX:
#    createApplicationServer name, node, template
#
# PARAMETERS:
#    name   - Name for Application Server entry
#    node   - Node on which to create application server
#    startingPort - The port to start at for all ports for this app server
#       If empty, then ports allocated by WebSphere
#    attrs    - Attributes in the form of -name1 value1 -name2 value2 ...
#    template   -   Name of ApplicationServer template to use 
#       Fefaults to "default"
#
#       Use AdminConfig.listTemplates("Server")
#       for a complete list of templates
#
#    amendVHost   - Boolean whether to add WC entries to Virtual Hosts
#       Defaults to true
#
# USAGE NOTES:
#    Creates a Application Server at node.  Uses a template to 
#    create the server
#
# RETURNS:
#    ObjID  Object ID of new appserver
#    None Failure
#
# THROWS:
#    N/A
##########################################################################
def addApplicationServer(name, node, startingPort, attrs, templateName = "default", amendVHost = 1,virtualHostTarget="",keepHostNames=0):
  createApplicationServer(name, node, startingPort, attrs, templateName, amendVHost,virtualHostTarget,keepHostNames)

def createApplicationServer(name, node, startingPort, attrs, templateName = "default", amendVHost = 1, virtualHostTarget="", keepHostNames=0):
  
  global progInfo
  retval = None

  try:
    traceStr = "createApplicationServer(%s, %s, %s, %s, %s)" % (name, node, startingPort, attrs, templateName)
    _app_trace(traceStr, "entry") 

    configID = "/Node:%s/" % (node)
    
    # Check function parameters
    if isEmpty(name) or isEmpty(node):
      raise StandardError("Application server name or destination node not specified")
    
    if objectExists("Server", configID, name):
      raise StandardError("Application Server %s already exists on node %s" % (name, node))

    # Get the templates for ApplicationServer
    templates = AdminTask.listServerTemplates("-serverType APPLICATION_SERVER -name %s" % templateName).splitlines()
    
    #templates = AdminConfig.listTemplates("Server", templateFilter).split(progInfo["line.separator"])

    # templateFilter must be an exact match, therefore list should be one element
    if len(templates) < 1: 
      raise StandardError("ApplicationServer template %s not found" % (templateName))
    
    if len(templates) > 1 and templateFilter != "default":
      raise StandardError("More than 1 ApplicationServer template found for %s" % (templateFilter))

    template = AdminConfig.showAttribute(templates[0], "name")

    _app_trace("Using template %s to create Application Server" % (template)) 

    attributes  = " -name %s" % (name)

    # @JJM: -templateName now working, no longer ignoring templates for now
    attributes += " -templateName %s" % (template)
    
    attributes = "[ %s ]" % attributes
    
    _app_trace("Running command: AdminTask.createApplicationServer(%s, '%s')" % (node, attributes))
    serverid = AdminTask.createApplicationServer(node,attributes)
    retval = serverid
    _app_trace("Result of AdminConfig: %s" % (retval))
  
    
    #serverattributes = [["name",name]]
    #nodeid = AdminConfig.getid(configID)
    #if nodeid == "" :
    #    _app_message("Skipping server due to missing node(%s, %s)" % (configID,attributes))
    #    retval=""
    #    return retval
    #
    #_app_trace("Running command: AdminConfig.create(Server, %s, %s)" % (nodeid,attributes))
    #retval = AdminConfig.create("Server",nodeid,serverattributes)


    # Now add the attributes
    if not isEmpty(attrs):
      _app_trace("Running command: AdminConfig.modify(%s, '%s')" % (retval, attrs))
      AdminConfig.modify(retval, attrs)
      
    # If startingPort not empty then modify ports
    if not isEmpty(startingPort) and modifyApplicationServerPorts(name, node, startingPort, amendVHost,virtualHostTarget,keepHostNames):
      raise StandardError("Failed to allocate port numbers starting at %s" % (startingPort))

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered creating the Application Server", "exception")
    retval = None

  _app_trace("createApplicationServer(%s)" %(retval), "exit")
  return retval
  
##########################################################################
#
# FUNCTION:
#    modifyApplicationServerPorts: Modify an Application Server's ports
#
# SYNTAX:
#    modifyApplicationServer name, node
#
# PARAMETERS:
#    name - Application server
#    node - Node where application server resides
#    port - Starting port number 
#    amendVHost - Boolean whether to add WC entries to Virtual Hosts
#     defaults to true
#
# USAGE NOTES:
#    Modifies an Application Server's port numbers as set in serverindex.xml
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def modifyApplicationServerPorts(name, node, port, amendVHost = 1, virtualHostTarget = "", keepHostNames=0):

  global progInfo
  retval = 1
  
  
  portNum = int(port)
  startingPort = portNum

  try:
    traceStr = "modifyApplicationServerPorts(%s, %s, %s, %s)" % (name, node, port, amendVHost)
    _app_trace(traceStr, "entry") 

    # Check function parameters
    if isEmpty(name) or isEmpty(node) or isEmpty(port):
      raise StandardError("Application server name, node or port not specified")

    configID = "/Node:%s/" % (node)
    nodeID = AdminConfig.getid(configID)
    
    if (keepHostNames):
      nodeHostname = ""
    else:
      nodeHostname = AdminConfig.showAttribute(nodeID, "hostName")

    if not objectExists("Server", configID, name):
      raise StandardError("Application Server %s not found on node %s" % (name, node))

    serverEntryId = AdminConfig.getid("/Node:%s/ServerIndex:/ServerEntry:%s/" % (node,name))
    if (not isEmpty(serverEntryId)):
      serverList = [ serverEntryId ]
    else:
      # Build the list the old way
      serverList = AdminConfig.list("ServerEntry", nodeID)
      if isEmpty(serverList):
        raise StandardError("Cannot find ServerEntry config IDs for node %s" % (node))

      serverList = serverList.split(progInfo["line.separator"])

    targetVirtualHostId = None
    if not isEmpty(amendVHost):
    
      if (isEmpty(virtualHostTarget)):
          virtualHostTarget = "default_host"
      
      
      targetVirtualHostId = getVirtualHost(virtualHostTarget)
      if (targetVirtualHostId == None):
          targetVirtualHostId = createVirtualHost(virtualHostTarget)
          if (not isEmpty(targetVirtualHostId)):
              _app_message("Created new virtual host %s to map server %s ports to" % ( virtualHostTarget, name))
      
      _app_trace("Target virtual host %s %s" % (virtualHostTarget,targetVirtualHostId))
      
        
    for server in serverList:

      thatServerName = AdminConfig.showAttribute(server, "serverName")

      _app_trace("Comparing %s with %s..." % (name, thatServerName))
      
      if name == thatServerName:

        _app_trace("Found match for %s" % (name))

        specialEndpoints = AdminConfig.showAttribute(server, "specialEndpoints")
        specialEndpoints = specialEndpoints[1:len(specialEndpoints) - 1].split(" ")
        
        baseProps = {}
        idProps = {}
        for specialEndpoint in specialEndpoints:
          
          baseProps.clear()
          idProps.clear()
          collectSimpleProperties(baseProps, "prop",specialEndpoint, [],idProps)
          specialEndpointName = baseProps.get("prop.endPointName")
          objID = idProps.get("prop.endPoint")
          
          #specialEndpointName = AdminConfig.showAttribute(specialEndpoint, "endPointName")
          #objID = AdminConfig.showAttribute(specialEndpoint, "endPoint")
          
          endPointHost = AdminConfig.showAttribute(objID,"host")
          
          if (not keepHostNames and endPointHost == "*" and (not isEmpty(nodeHostname))):
              endPointHost = nodeHostname
          
            
          _app_trace("Setting %s for %s to %s %d" % (specialEndpointName, name, endPointHost, portNum))

          traceStr = "AdminConfig.modify(%s, [['port', %d],['host', %s] ])" % (objID, portNum, endPointHost)
          _app_trace("Running command: %s" % (traceStr))
          
          attrs = []
          attrs.append(["port", portNum])
          attrs.append(["host", endPointHost])

          AdminConfig.modify(objID, attrs)
          
          if amendVHost and specialEndpointName[0:14] == "WC_defaulthost":
          
            addAliasToVirtualhost(targetVirtualHostId, "*", "%d" % portNum)
                      
          portNum = portNum + 1
        
        #endfor
        
        # Add the port range to our cache
        addServerToPortList(node, nodeID, name, startingPort, portNum-1)
        
        retval = 0
        break
      else:
        _app_trace("Does NOT match")

  except:
    _app_trace("An error was encountered modifying the Application Server's ports", "exception")
    retval = 1

  _app_trace("modifyApplicationServerPorts(%d)" % (retval), "exit")
  return retval

#-------------------------------------------------------------------------------
# getNamedEndPoints
#
# Returns endpoints as dictionary of name = (host, port) tuples
# Dictionary also includes name.ENDPOINT_CONFIG_ID = EndPoint configuration ID
#
# Parameters
#    nodeName
#    serverName
#-------------------------------------------------------------------------------
def getNamedEndPoints(nodeName,serverName):
  _app_entry("getNamedEndPoints(%s,%s)" , nodeName,serverName)
  retval = {}
  try:
      se  = AdminConfig.getid("/Node:%s/ServerIndex:/ServerEntry:%s/" % (nodeName,serverName))
      
      if (not isEmpty(se)):
          tName = se.split("(")[0]
          if (tName == serverName):
            # Listen
            endpoints = AdminConfig.list("NamedEndPoint",se).splitlines()
            endPointDict = {}
            for nep in endpoints:
              if (isEmpty(nep)): continue
              namedEndPointProps = {}
              subItems = {}
              collectSimpleProperties(namedEndPointProps, "prop",nep, [],subItems)
              endPointName = namedEndPointProps.get("prop.endPointName")
              endPointId = subItems.get("prop.endPoint")
              
              endPointProps = {}
              collectSimpleProperties(endPointProps,"endPoint.prop",endPointId)
              retval[endPointName] = (endPointProps.get("endPoint.prop.host"),endPointProps.get("endPoint.prop.port"))
              retval["%s.ENDPOINT_CONFIG_ID" % endPointName] = endPointId
          
  except:
    _app_exception("Unexpected problem in getNamedEndPoints()")
  
  _app_exit("getNamedEndPoints(retval=%s)" % retval)
  return retval
  

##########################################################################
#
# FUNCTION:
#    deleteApplicationServer: Delete an Application Server
#
# SYNTAX:
#    deleteApplicationServer name, node
#
# PARAMETERS:
#    name - Name for Application Server entry
#    node - Name of node where server exists
#
# USAGE NOTES:
#    Deletes a Application Server from the desired node.  
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeApplicationServer(name, node):
  deleteApplicationServer(name, node)
  
def deleteApplicationServer(name, node):
  
  global progInfo
  retval = 1

  try:
    traceStr = "deleteApplicationServer(%s, %s)" % (name, node)
    _app_trace(traceStr, "entry") 

    if isEmpty(name) or isEmpty(node):
      raise StandardError("Application server name or node not specified")

    # Check function parameters
    if not objectExists("Server", "/Node:%s/" % (node), name):
      raise StandardError("No such Application Server as %s on node %s" % (name, node))

    attributes  = " -serverName %s" % (name)
    attributes += " -nodeName   %s" % (node)

    _app_trace("Running command: AdminTask.deleteServer(%s)" % (attributes))
    AdminTask.deleteServer(attributes)

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()
      
    retval = 0
  except:
    _app_trace("An error was encountered deleting the Application Server", "exception")
    retval = 1

  _app_trace("deleteApplicationServer(%d)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    listApplicationServers: List Application Servers on node
#
# SYNTAX:
#    listApplicationServers node, displayFlag
#
# PARAMETERS:
#    node - Node name
#    displayFlag- Boolean indicating whether to print list 
#     (default = 1)
#
# USAGE NOTES:
#    Lists Application Servers at the desired scope.  
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showApplicationServers(node, displayFlag = 1):
  listApplicationServers(node, displayFlag)
  
def listApplicationServers(node, displayFlag = 1):
  
  global progInfo
  retval = None
  
  try:
    traceStr = "listApplicationServers(%s, %d)" % (node, displayFlag)
    _app_trace(traceStr, "entry") 

    # Check function parameters
    configID = getContainmentPath(None, node, None)

    if isEmpty(configID):
      retval = None
    else:
      attributes  = " -serverType APPLICATION_SERVER"
      attributes += " -nodeName %s" % (node)
      
      _app_trace("Running command: AdminTask.listServers(%s)" % (attributes))
      str = AdminTask.listServers("%s" % (attributes))

      if isEmpty(str):
        retval = []
      else:
        retval = str.split(progInfo["line.separator"])

      if displayFlag:
        print "\nApplication Servers\n-------------------"
        
        for r in retval:
          print AdminConfig.showAttribute(r, "name")
              
        print "-------------------"

  except:
    _app_trace("An error was encountered listing the Application Servers", "exception")
    retval = None

  _app_trace("listApplicationServers(%s)" %(retval), "exit")
  return retval


#-------------------------------------------------------------------------------
# findMatchingApplicationServers
#-------------------------------------------------------------------------------
def findMatchingApplicationServers(namePattern, includeManagementServers=0,includeODR=0,includeProxy=0,includeClusterMembers=0):
  import re
  retval = []
  _app_trace("findMatchingApplicationServers(namePattern, includeManagementServers)","entry")
  
  # Start with a list of servers
  tempList = []
  appServers = AdminTask.listServers(" -serverType APPLICATION_SERVER")
  if (not isEmpty(appServers)):
    tempList = appServers.split(progInfo["line.separator"])
  
  if (includeManagementServers):
    nodeagents = AdminTask.listServers(" -serverType NODE_AGENT")
    if (not isEmpty(nodeagents)):
      nodeAgentList = nodeagents.split(progInfo["line.separator"])
      for nodeAgent in nodeAgentList:
        if (not isEmpty(nodeAgent)):
          tempList.append(nodeAgent)
    
    dmgrs = AdminTask.listServers(" -serverType DEPLOYMENT_MANAGER")
    if (not isEmpty(dmgrs)):
      dmgrList = dmgrs.split(progInfo["line.separator"])
      for dmgr in dmgrList:
        if (not isEmpty(dmgr)):
          tempList.append(dmgr)
  
  if (includeODR):
    odrs = AdminTask.listServers("-serverType ONDEMAND_ROUTER").splitlines()
    for odr in odrs:
      if (isEmpty(odr)): continue
      tempList.append(odr)
      
  if (includeProxy):
    proxies = AdminTask.listServers("-serverType PROXY_SERVER").splitlines()
    for proxyServer in proxies:
      if (isEmpty(proxyServer)): continue
      tempList.append(proxyServer)
          
  # Now see if the server names match
  for tempId in tempList:
    if (not includeClusterMembers):
      # Make sure this is not a cluster member
      clusterName = AdminConfig.showAttribute(tempId,"clusterName")
      if (not isEmpty(clusterName)):
        continue
    
    tempName = AdminConfig.showAttribute(tempId,"name")
    if (namePattern.find("*") >= 0):
        # Do regexp comparison
        if (re.match(namePattern,tempName)):
          retval.append(tempId)
    else:
        # Just treat as name search
        if (namePattern == tempName):
          retval.append(tempId)
    
  _app_trace("findMatchingApplicationServers(retval = %s)" % retval,"exit")
  return retval


##########################################################################
# checkForExistingApplicationServer
# Returns configuration id of the server if it exists, None otherwise
##########################################################################
def checkForExistingApplicationServer(node,name):
  _app_trace("checkForExistingApplicationServer(%s,%s)" % (node,name), "entry") 
  retval = None
  serverList=listApplicationServers(node,0)
  for svr in serverList:
      if (AdminConfig.showAttribute(svr,"name") == name):
          retval = name
          break
          
  _app_trace("checkForExistingApplicationServer(%s)" % (retval), "exit")  
  return retval

#enddef checkForExistingApplicaitonServer


##########################################################################
# getMessageListenerService
##########################################################################
def getMessageListenerService(serverId):
  mlsId = AdminConfig.list('MessageListenerService', serverId)
  if (mlsId == "") :
      mlsId = AdminConfig.create('MessageListenerService', serverId, [])
  
  return mlsId

##########################################################################
# getListenerPortWithName
##########################################################################
def getListenerPortWithName(serverId, lpportName):
    _app_trace("getListenerPortWithName(%s,%s)" % (serverId,lpportName), "entry") 
    result = None
    mlsId = getMessageListenerService(serverId)
    if (mlsId != None):
        lports = AdminConfig.list('ListenerPort',mlsId).split(progInfo["line.separator"])
        for lp in lports:
            if (not isEmpty(lp)):
                lpn = AdminConfig.showAttribute(lp,"name")
                if (lpn == lpportName):
                    result = lp
                    break
                    
    _app_trace("getListenerPortWithName(returns %s)" % (result), "exit")  
    return result

##########################################################################
# getListenerPortProperties
# 
# In some cases, we need to get properties for a particular listener port
# This method returns a property set with the prefix "listenerPort.prop"
##########################################################################
def getListenerPortProperties(lpid):
    result={}
    
    subItemIds = {}
    collectSimpleProperties(result, "listenerPort.prop" , lpid, [],subItemIds)

    lp_stateManagement = subItemIds.get("listenerPort.prop.stateManagement")

    storePropertiesInSet("listenerPort.stateManageable.prop",lp_stateManagement,result)
    
    return result
    
#--------------------------------------------------------------------------------------------
# findTransportChain
#--------------------------------------------------------------------------------------------
def findTransportChain(searchName, server, serverName=None, nodeName = None ):
  
  _app_trace("findTransportChain(%s,%s)" % (searchName, server), "entry")
  
  retval = None
  
  SEPARATOR=progInfo["line.separator"]
  
  if (serverName == None and nodeName == None):
    serverName = AdminConfig.showAttribute(server,"name")
    nodeName = getNodeNameForServer(server)
  
  retval = AdminConfig.getid("/Node:%s/Server:%s/TransportChannelService:/Chain:%s/" % (nodeName, serverName,searchName))
  
  if (isEmpty(retval)):
    chainList = AdminConfig.list("Chain",server).split(SEPARATOR)
    for chain in chainList:
      if (not isEmpty(chain)):
          name = AdminConfig.showAttribute(chain,"name")
          if (name == searchName):
              retval = chain
              break
  
  _app_trace("findTransportChain(retval=%s)" % retval,"exit")
  return retval
  
#--------------------------------------------------------------------------------------------
# getTransportChainProperties
#--------------------------------------------------------------------------------------------
def getTransportChainProperties(chain,checkSettingsOverride=0):
  _app_trace("getTransportChainProperties(%s)" % chain, "entry")
  results = java.util.Properties()

  # Pull the settings as long as the precheck setting is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()): 
    idProps = {}
    collectSimpleProperties(results, "chain.prop" , chain, ["name"],idProps=idProps)
    
    
  _app_trace("getTransportChainProperties(%d items)"%results.size(), "exit")
  return results
    
#--------------------------------------------------------------------------------------------
# findTransportChannel
#
# Return the ID of the channel with the specified name
#--------------------------------------------------------------------------------------------
def findTransportChannel(channelName,chain):

    _app_trace("findTransportChannel(%s,%s)" % (channelName,chain), "entry")
    retval = None
    
    channels = wsadminToList(AdminConfig.showAttribute(chain, "transportChannels"))
    for channel in channels:
        if (not isEmpty(channel)):
            # Avoid extra call by seeing if ID contains name, then confirm
            if (channel.find(channelName) >= 0):
              name = AdminConfig.showAttribute(channel,"name")
              if (name == channelName):
                retval = channel
                break

    _app_trace("findTransportChannel(retval=%s)"% (retval), "exit")
    return retval

#-------------------------------------------------------------------------------------------------
# getTransportChannelProperties
#
# Return a property set with channel properties and custom properties
#-------------------------------------------------------------------------------------------------
def getTransportChannelProperties(channel, checkSettingsOverride=0):
    
  _app_trace("getTransportChannelProperties(%s)" % channel, "entry")
  results = {}
    
  # Pull the settings as long as the precheck setting is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()):

    name = AdminConfig.showAttribute(channel,"name")
    results["channel.name"] =name
    childIds = {}
    collectSimpleProperties(results, "channel.prop" , channel, ["name"],getSimpleChildren=1,idProps=childIds)
    
    collectCustomProperties(results,"channel.customProperties", channel, "properties")
    
    threadPool = childIds.get("channel.prop.threadPool")
    if (not isEmpty(threadPool)):
      results["channel.threadPool.name"] = AdminConfig.showAttribute(threadPool,"name")

    
  _app_trace("getTransportChannelProperties(retval = %d elements)"% len(results), "exit")
    
  return results

#-------------------------------------------------------------------------------------------
# getApplicationServerComponentProperties
#
# This method loads the simple properties and custom properties of the ApplicationServer
# component for the specified server using the following prefixes:
#    appserver.applicationServer.prop
#    appserver.applicationServer.properties.prop
# 
# The properties are added to the supplied properties set.
#
# Parameters:
#     server - the configuration ID of the server
#     appServerProperties - a Properties object to store the properties in
#     checkSettingsOverride - if 1, we'll load the properties even if the global
#                             checkSettingsEnabled flag is false
#-------------------------------------------------------------------------------------------
def getApplicationServerComponentProperties(server, appServerProperties,checkSettingsOverride=0):
  
  
  _app_trace("getApplicationServerComponentProperties(%s, appServerProperties)" % server,"entry")

  SEPARATOR=progInfo["line.separator"]
  
  # ApplicationServer Service
  
  # Get settings as long as the precheck feature is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()):
    appsrvid = AdminConfig.list("ApplicationServer",server)
    if (not isEmpty(appsrvid)):
      collectSimpleProperties(appServerProperties,"appserver.applicationServer.prop", appsrvid, ["id","name"])
      collectCustomProperties(appServerProperties,"appserver.applicationServer.properties", appsrvid, "properties")
          
    
  _app_trace("getApplicationServerComponentProperties()","exit")



#-------------------------------------------------------------------------------------------------------    
# getSessionManagerProperties
#-------------------------------------------------------------------------------------------------------    
def getSessionManagerProperties(props,sessionMgrId,prefix,checkSettingsOverride=0):

  _app_trace("getSessionManagerProperties(props,%s,%s)" % (sessionMgrId,prefix),"entry")
  try:
      # Session Manager properties do not have to be returned if we are not enabled
      # for prechecking existing values
      if (checkSettingsOverride or  isCheckSettingsEnabled()):
          
          collectSimpleProperties(props,"%s.prop" % prefix, sessionMgrId, [],collectPropertyAttributes=1)
          
          tuningParams = AdminConfig.list("TuningParams",sessionMgrId)
   
          invalidationSchedule = ""
          if (not isEmpty(tuningParams)):
            invalidationSchedule = AdminConfig.list("InvalidationSchedule",tuningParams)
            
            collectSimpleProperties(props,"%s.tuningParams.prop" % prefix, tuningParams, [])
  
            if (invalidationSchedule != "") :
              collectSimpleProperties(props,"%s.tuningParams.invalidationSchedule.prop" % prefix, invalidationSchedule, [])

          
          cookieid = AdminConfig.showAttribute(sessionMgrId,"defaultCookieSettings")
          if (cookieid != "") :  
            collectSimpleProperties(props,"%s.defaultCookieSettings.prop" % prefix, cookieid, [])
          
          sessionDatabasePersistenceid = AdminConfig.showAttribute(sessionMgrId,"sessionDatabasePersistence")          
          if (not isEmpty(sessionDatabasePersistenceid)):
            collectSimpleProperties(props,"%s.sessionDatabasePersistence.prop" % prefix, sessionDatabasePersistenceid, [])

          drssettingsid = AdminConfig.showAttribute(sessionMgrId,"sessionDRSPersistence")
          if (not isEmpty(drssettingsid)) :
                  collectSimpleProperties(props,"%s.sessionDRSPersistence.prop" % prefix, drssettingsid, [])

  
  except:
    _app_trace("Error loading session properties","exception")
    raise StandardError("Error loading session properties")
    
  _app_trace("getSessionManagerProperties()","exit")
  return
                  
#-------------------------------------------------------------------------------------------------------
# getSessionManagementProperties
#
# Get the session management settings for an application server.
#-------------------------------------------------------------------------------------------------------
def getSessionManagementProperties(server, appServerProperties,checkSettingsOverride=0):

  _app_trace("getSessionManagementProperties(%s,appServerProperties)" % server, "entry")
  
  # Session Manager properties do not have to be returned if we are not enabled
  # for prechecking existing values
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
      
      webContainerId = AdminConfig.list("WebContainer", server)
      sessionMgrId = AdminConfig.list("SessionManager", webContainerId)
      sessionMgrSubItems = {}
      if (sessionMgrId != "") :
          collectSimpleProperties(appServerProperties,"appserver.webContainer.sessionManagement.prop", sessionMgrId, [],sessionMgrSubItems,
          collectPropertyAttributes=1)
          

          #appServerProperties.put("appserver.webContainer.sessionManagement.prop.maxWaitTime" , maxWaitTime)
          
          #tuningParams = AdminConfig.list("TuningParams",sessionMgrId)
          tuningParams = sessionMgrSubItems.get("appserver.webContainer.sessionManagement.prop.tuningParams")
          invalidationSchedule = AdminConfig.list("InvalidationSchedule",tuningParams)
          
          collectSimpleProperties(appServerProperties,"appserver.webContainer.sessionManagement.tuningParams.prop", tuningParams, [])
                  
          if (invalidationSchedule != "") :
              collectSimpleProperties(appServerProperties,"appserver.webContainer.sessionManagement.tuningParams.invalidationSchedule.prop", invalidationSchedule, [])
              
          
          #cookieid = AdminConfig.showAttribute(sessionMgrId,"defaultCookieSettings")
          cookieid = sessionMgrSubItems.get("appserver.webContainer.sessionManagement.prop.defaultCookieSettings")
          if (cookieid != "") :
              collectSimpleProperties(appServerProperties,"appserver.webContainer.sessionManagement.defaultCookieSettings.prop", cookieid, [])
              
              
          sessionDatabasePersistenceid = sessionMgrSubItems.get("appserver.webContainer.sessionManagement.prop.sessionDatabasePersistence")
          #sessionDatabasePersistenceid = AdminConfig.showAttribute(sessionMgrId,"sessionDatabasePersistence")
          if (not isEmpty(sessionDatabasePersistenceid)):
                  collectSimpleProperties(appServerProperties,"appserver.webContainer.sessionManagement.sessionDatabasePersistence.prop", sessionDatabasePersistenceid, [])
          
          drssettingsid = sessionMgrSubItems.get("appserver.webContainer.sessionManagement.prop.sessionDRSPersistence")
          #drssettingsid = AdminConfig.showAttribute(sessionMgrId,"sessionDRSPersistence")
          if (not isEmpty(drssettingsid)) :
                  collectSimpleProperties(appServerProperties,"appserver.webContainer.sessionManagement.sessionDRSPersistence.prop", drssettingsid, [])
                                    
  _app_trace("getSessionManagementProperties()", "exit")
      
#enddef getSessionManagementProperties

#------------------------------------------------------------------------------------------------------------------------------------
# getJavaVirtualMachineProperties
#
# Add properties representing current settings of JavaVirtualMachine to the passed in properties object.
#
# Returns:
#   Configuration ID of JavaVirtualMachine
#------------------------------------------------------------------------------------------------------------------------------------
def getJavaVirtualMachineProperties(server,appServerProperties,processId = None) :
    

      _app_trace("getJavaVirtualMachineProperties(%s)" % server, "entry")
      
      # JavaVirtualMachine
      if (processId != None):
        tp = AdminConfig.list("JavaVirtualMachine", processId)
      else:
        tp = AdminConfig.list("JavaVirtualMachine",AdminConfig.list("JavaProcessDef",server))
      
      jvmId = tp
      
        
      
      collectSimpleProperties(appServerProperties,"appserver.processdef.jvm.prop", tp, [])
      genericJvmArguments = appServerProperties.get("appserver.processdef.jvm.prop.genericJvmArguments")
      if (genericJvmArguments == None):
        appServerProperties["appserver.processdef.jvm.prop.genericJvmArguments"] = '""'
      elif (genericJvmArguments != None and (not genericJvmArguments.startswith('"'))):
        genericJvmArguments = '"%s"' % genericJvmArguments
        appServerProperties["appserver.processdef.jvm.prop.genericJvmArguments"] = genericJvmArguments
      debugArgs = appServerProperties.get("appserver.processdef.jvm.prop.debugArgs")
      if (debugArgs != None and (not debugArgs.startswith('"'))):
        debugArgs = '"%s"' % debugArgs
        appServerProperties["appserver.processdef.jvm.prop.debugArgs"] = debugArgs
        
      
      # JVM System properties do not have to be returned if we are not enabled
      # for prechecking existing values
      if (isCheckSettingsEnabled()):
        #_app_trace("Getting custom properties for %s" % tp)
        collectCustomProperties(appServerProperties,"appserver.processdef.jvm.sys", tp, "systemProperties")
        #_app_trace("Done getting custom properties for %s" % tp)
      
      _app_trace("getJavaVirtualMachineProperties(retval = %s)" % jvmId, "exit")
      return jvmId

#enddef

#----------------------------------------------------------------------------------------------------------------------
# getThreadPoolProperties
#
#----------------------------------------------------------------------------------------------------------------------
def getThreadPoolProperties(server,appServerProperties,checkSettingsOverride=0):

  _app_trace("getThreadPoolProperties(%s,appServerProperties)" % server , "entry")
  
  # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):    
    
      SEPARATOR=progInfo["line.separator"]
      
      # @JJM - Dump all thread pools
      tpm = AdminConfig.list("ThreadPoolManager", server)
      if (tpm != "") :
          
          tplist = AdminConfig.list("ThreadPool",tpm).split(SEPARATOR)
          tpidx = 0
          for tp in tplist:
            tpidx = tpidx + 1
            collectSimpleProperties(appServerProperties,"appserver.threadPoolManager.threadPool.%d.prop" % tpidx, tp, [])
            
          appServerProperties["appserver.threadPoolManager.threadPool.count"] =  "%d" % tpidx
      
  _app_trace("getThreadPoolProperties()", "exit")     

#enddef getThreadPoolProperties

#--------------------------------------------------------------------------------------------------------------------------
# getMessageListenerServiceProperties
#--------------------------------------------------------------------------------------------------------------------------
def getMessageListenerServiceProperties(server,appServerProperties):
      
      _app_trace("getMessageListenerServiceProperties(%s)" % server, "entry")     
      
      SEPARATOR=progInfo["line.separator"]
      
      # Listener port
      lpcount = 0
      mlService = AdminConfig.list('MessageListenerService', server)
      lports = AdminConfig.list('ListenerPort',mlService).split(SEPARATOR)
      if (len(lports) > 0 and lports[0] != "") :
        collectSimpleProperties(appServerProperties,"appserver.messageListenerService.prop", mlService, [])
        
        mlsThreadPool = AdminConfig.list('ThreadPool',mlService)
        collectSimpleProperties(appServerProperties,"appserver.messageListenerService.threadPool.prop", mlsThreadPool, [])
        for lport in lports:
          if (isEmpty(lport)):continue
            
          lpcount = lpcount + 1
          collectSimpleProperties(appServerProperties,"appserver.messageListenerService.listenerPorts.%d.prop" % lpcount, lport, [])
                    
          lp_stateManagement = AdminConfig.list('StateManageable',lport)
          storePropertiesInSet("appserver.messageListenerService.listenerPorts.%d.stateManageable.prop" % lpcount,lp_stateManagement,appServerProperties)
        
        appServerProperties["appserver.messageListenerService.listenerPorts.count"] = "%d" % lpcount

      _app_trace("getMessageListenerServiceProperties()", "exit")     
#enddef getMessageListenerServiceProperties


#---------------------------------------------------------------------------------------------------------
# getClassloaderProperties
#
# Note: this function does not implement the isCheckSettingsEnabled() logic because the
# classloader logic is always needed
#---------------------------------------------------------------------------------------------------------
def getClassloaderProperties(server,appServerProperties):

      _app_trace("getClassloaderProperties(%s, appServerProperties)" % server, "entry")
      
      SEPARATOR=progInfo["line.separator"]

      # @JJM - Dump classloaders/shared libraries
      clidx = 0
      classloaders = AdminConfig.list("Classloader", server).split(SEPARATOR)
      for cldr in classloaders:
          if (cldr == ""):
              continue
          clidx = clidx + 1
          
          clmode = AdminConfig.showAttribute(cldr,"mode")
          
          appServerProperties["appserver.classloaders.%d.prop.mode" % clidx] =  clmode
          libRefIdx = 0
          libraryRefs = AdminConfig.list("LibraryRef", cldr).split(SEPARATOR)
          for libraryRef in libraryRefs:
              libRefIdx = libRefIdx+1
              collectSimpleProperties(appServerProperties,"appserver.classloaders.%d.libraries.%d.prop" % (clidx, libRefIdx), libraryRef, [])
                            
          appServerProperties["appserver.classloaders.%d.libraries.count" % clidx] = "%d" %libRefIdx
      
      appServerProperties["appserver.classloaders.count"] =  "%d" % clidx
      
      _app_trace("getClassloaderProperties()", "exit")

#enddef getClassloaderProperties

#-----------------------------------------------------------------------------------------
# getTraceServiceProperties
#-----------------------------------------------------------------------------------------
def getTraceServiceProperties(server,appServerProperties,checkSettingsOverride=0):
      
  _app_trace("getTraceServiceProperties(%s,appServerProperties)" % server , "entry")
  
    # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
      
      # @JJM - Trace service
      traceServiceId = AdminConfig.list('TraceService',server)
      if (traceServiceId != "") :
          
          traceSubItemIds = {}
          collectSimpleProperties(appServerProperties,"appserver.processdef.traceService.prop", traceServiceId, [],traceSubItemIds)
                
          traceLogFileId = traceSubItemIds.get("appserver.processdef.traceService.prop.traceLog")
          #traceLogFileId = AdminConfig.showAttribute(traceServiceId,"traceLog")
          if not isEmpty(traceLogFileId) :
              collectSimpleProperties(appServerProperties,"appserver.processdef.traceService.traceLog.prop", traceLogFileId, [])
            
      
  _app_trace("getTraceServiceProperties()", "exit")

#enddef getTraceServiceProperties

#-----------------------------------------------------------------------------------------
# getRASLoggingServiceProperties
#-----------------------------------------------------------------------------------------
def getRASLoggingServiceProperties(server,appServerProperties,checkSettingsOverride=0):
      
  _app_trace("getRASLoggingServiceProperties(%s,appServerProperties)" % server , "entry")
  
    # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
      
      # @JJM - Trace service
      RASLoggingServiceId = AdminConfig.list('RASLoggingService',server)
      if (RASLoggingServiceId != "") :
          
          rasSubItemIds = {}
          collectSimpleProperties(appServerProperties,"appserver.rasLoggingService.prop", RASLoggingServiceId, [],rasSubItemIds)
                
          serviceLogId = rasSubItemIds.get("appserver.rasLoggingService.prop.serviceLog")
    
          if not isEmpty(serviceLogId) :
              collectSimpleProperties(appServerProperties,"appserver.rasLoggingService.serviceLog.prop", serviceLogId, [])
            
      
  _app_trace("getRASLoggingServiceProperties()", "exit")

#-----------------------------------------------------------------------------------------
# getHPELoggingServiceProperties
#-----------------------------------------------------------------------------------------
def getHPELoggingServiceProperties(server,appServerProperties,checkSettingsOverride=0):
      
  _app_trace("getHPELoggingServiceProperties(%s,appServerProperties)" % server , "entry")
  
  hpeLoggingServiceId = None
  # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
  
      #V8
      
      try:
        hpeLoggingServiceId = AdminConfig.list('HighPerformanceExtensibleLogging',server)
      except:
        # Must not be V8
        pass
      
      try:  
        if (hpeLoggingServiceId != "") :
          collectSimpleProperties(appServerProperties,"appserver.hpeLoggingService.prop" , hpeLoggingServiceId, [],getSimpleChildren=1,collectPropertyAttributes=1,useAttrNameWithProperties=0)
           
      except:
        _app_exception("Unexpected error in getHPELoggingServiceProperties(%s)" % server)
       
   
      
  _app_trace("getHPELoggingServiceProperties(retval=%s)" % hpeLoggingServiceId, "exit")
  return hpeLoggingServiceId

#-----------------------------------------------------------------------------------------
# getHTTPAccessLoggingServiceProperties
#-----------------------------------------------------------------------------------------
def getHTTPAccessLoggingServiceProperties(server,appServerProperties,checkSettingsOverride=0):
  _app_trace("getHTTPAccessLoggingServiceProperties(%s,appServerProperties,%d)" % (server,checkSettingsOverride),"entry")
  
  configId = None
  try:
    configId = AdminConfig.list("HTTPAccessLoggingService",server)   
  except:
    # Must not be supported
    pass
  
  if (not isEmpty(configId)):
    # This call will collect simple properties and simple properties of child items      
    collectSimpleProperties(appServerProperties, "appserver.httpAccessLoggingService.prop",configId, optionalSkipList=[],idProps=None,getSimpleChildren=1,childrenSkipList=None)
    
  _app_trace("getHTTPAccessLoggingServiceProperties(retval=%s)" % configId ,"exit")
  return configId

#-----------------------------------------------------------------------------------------
# getTransactionServiceProperties
#-----------------------------------------------------------------------------------------
def getTransactionServiceProperties(server,appServerProperties,checkSettingsOverride=0):
  _app_trace("getTransactionServiceProperties(%s,appServerProperties)" % server, "entry")
  
  # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
      
      SEPARATOR=progInfo["line.separator"]
      
      # @JJM-TransactionService
      tservice = AdminConfig.list("TransactionService",server)
      for s in AdminConfig.show(tservice).split(SEPARATOR):
          k,v = toKeyValue(s)
          
          if (isEmpty(v)): v = ""
          if (k != "context" and k != "properties"):
              appServerProperties["appserver.transactionService.prop.%s" % k] =  v
      
      collectCustomProperties(appServerProperties,"appserver.transactionService.customProperties", tservice, "properties")


  _app_trace("getTransactionServiceProperties()", "exit")
      
#enddef getTransactionServiceProperties

#-----------------------------------------------------------------------------------------
# getWebServerPluginProperties
#-----------------------------------------------------------------------------------------
def getWebServerPluginProperties(server,appServerProperties,checkSettingsOverride=0):

  _app_trace("getWebServerPluginProperties(%s,appServerProperties)" % server, "entry")
  
  # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):    
    
      SEPARATOR=progInfo["line.separator"]

      # Webserver Plugin Settings
      tp = AdminConfig.list("WebserverPluginSettings",server).split(SEPARATOR)
      for p in tp:
          for s in AdminConfig.show(p).split(SEPARATOR):
              k,v = toKeyValue(s)
              if (isEmpty(v)): v = ""
              appServerProperties["appserver.webserverPluginSettings.prop.%s" % k] =  v
      
  _app_trace("getWebServerPluginProperties()", "exit")

#enddef

#-----------------------------------------------------------------------------------------
# getProcessEnvironmentProperties
#-----------------------------------------------------------------------------------------
def getProcessEnvironmentProperties(server,appServerProperties, checkSettingsOverride=0):
  _app_trace("getProcessEnvironmentProperties(%s,appServerProperties) % server", "entry")

  # Pull the settings as long as the precheck setting is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()):
      
      collectCustomProperties(appServerProperties,"appserver.processdef.environment", AdminConfig.list("ProcessDef", server), "environment")
                
  _app_trace("getProcessEnvironmentProperties()", "exit")
      
#enddef getProcessEnvironmentProperties


##########################################################################
# getCustomServiceProperties
# Adds the configuration properties for the custom services to the supplied Properties set
# The prefix "appserver.customService.[idx]" is used for each service.
# The configuration ID for each service is stored as appserver.customService.[idx].CONFIGURATION_ID
# appserver.customService.count contains the number of custom services
#
# Note: this method should not support the "disable precheck" settings
##########################################################################
def getCustomServiceProperties(server, appServerProperties):

    _app_trace("getCustomServiceProperties(%s,appServerProperties)" % server,"entry")
    
    SEPARATOR=progInfo["line.separator"]
    
    customServices = AdminConfig.list("CustomService",server).split(SEPARATOR)
    sidx = 0
    for service in customServices:
        if (isEmpty(service)):
            continue
        sidx = sidx + 1
        collectSimpleProperties(appServerProperties,"appserver.customService.%d.prop" % sidx, service, [])
        
        # Also Store the configuration ID in this properties
        appServerProperties["appserver.customService.%d.CONFIGURATION_ID"%sidx] =  service
        
        collectCustomProperties(appServerProperties,"appserver.customService.%d.customProperties" % (sidx), service, "properties")
                      
    appServerProperties["appserver.customService.count"] = "%d" % (sidx)

    
    _app_trace("getCustomServiceProperties()","exit")

#enddef getCustomServiceProperties


#-------------------------------------------------------------------------------------------
# getWebContainerProperties
# Get the settings for the WebContainer and WebContainer custom properties
#    appserver.webContainer.prop
#    appserver.webContainer.customProperties.prop
#-------------------------------------------------------------------------------------------
def getWebContainerProperties(server, appServerProperties,checkSettingsOverride=0):

  _app_trace("getWebContainerProperties(%s, appServerProperties)" % (server),"entry")

  # Get settings as long as the precheck feature is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()):
    webContainerId = AdminConfig.list("WebContainer", server)
    collectSimpleProperties(appServerProperties,"appserver.webContainer.prop", webContainerId, [])
    collectCustomProperties(appServerProperties,"appserver.webContainer.customProperties", webContainerId, "properties")
      
  _app_trace("getWebContainerProperties(%s, appServerProperties)" % (server),"exit")

#-----------------------------------------------------------------------------------------
# getPortletContainerProperties
#-----------------------------------------------------------------------------------------
def getPortletContainerProperties(server,appServerProperties,checkSettingsOverride=0):
      
  _app_trace("getPortletContainerProperties(%s,appServerProperties)" % server , "entry")
  
    # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
      try:
        portletContainerId = AdminConfig.list('PortletContainer',server)
      except:
        # Not supported in earlier versions
        portletContainerId = None
        
      if (not isEmpty(portletContainerId)) :
          collectSimpleProperties(appServerProperties,"appserver.portletContainer.prop", portletContainerId, [])
          collectCustomProperties(appServerProperties,"appserver.portletContainer.properties", portletContainerId, "properties")
          
      
  _app_trace("getPortletContainerProperties()", "exit")

#enddef getPortletContainerProperties

#-----------------------------------------------------------------------------------------
# getSIPContainerProperties
#-----------------------------------------------------------------------------------------
def getSIPContainerProperties(server,appServerProperties,checkSettingsOverride=0):
      
  _app_trace("getSIPContainerProperties(%s,appServerProperties)" % server , "entry")
  
    # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
      
      
      try:
        sipId = AdminConfig.list('SIPContainer',server)
      except:
        # Not supported
        sipId = None
        
      if (not isEmpty(sipId)) :
          collectSimpleProperties(appServerProperties,"appserver.sipContainer.prop", sipId, [])
          collectCustomProperties(appServerProperties,"appserver.sipContainer.properties", sipId, "properties")
          
          sipthreadpool = AdminConfig.showAttribute(sipId,"threadPool")
          if (not isEmpty(sipthreadpool)):
            appServerProperties["appserver.sipContainer.threadPool.name"] =  AdminConfig.showAttribute(sipthreadpool,"name")
          sessionMgrId = AdminConfig.list("SessionManager",sipId)
          if (not isEmpty(sessionMgrId)):
            getSessionManagerProperties(appServerProperties,sessionMgrId,"appserver.sipContainer.sessionManager",checkSettingsOverride)
          
          stackId = AdminConfig.showAttribute(sipId,"stack")
          if (not isEmpty(stackId)):
            collectSimpleProperties(appServerProperties, "appserver.sipContainer.stack.prop" , stackId)
            
            timersId = AdminConfig.showAttribute(stackId,"timers")
            if (not isEmpty(timersId)):
              collectSimpleProperties(appServerProperties,"appserver.sipContainer.stack.timers.prop", timersId)
                
            
      
  _app_trace("getSIPContainerProperties()", "exit")

#enddef getSIPContainerProperties


#------------------------------------------------------------------------------------------
# getJavaPersistenceAPIServiceProperties
#------------------------------------------------------------------------------------------
def getJavaPersistenceAPIServiceProperties(serverId,appServerProperties,checkSettingsOverride=0):
  _app_trace("getJavaPersistenceAPIServiceProperties(%s,appServerProperties,%d" % (serverId,checkSettingsOverride),"entry")
  if (checkSettingsOverride or isCheckSettingsEnabled()):
    try:
      jpaId = AdminConfig.list("JavaPersistenceAPIService",server)
      if (not isEmpty(jpaId)):
        collectSimpleProperties(appServerProperties,"appserver.javaPersistenceAPIService.prop",jpaId)
        collectCustomProperties(appServerProperties,"appserver.javaPersistenceAPIService.properties" % jpaId,"properties")
    except:
      # V7 onwards
      pass
  _app_trace("getJavaPersistenceAPIServiceProperties()","exit")

#-------------------------------------------------------------------------------------------
# getORBServiceProperties
#-------------------------------------------------------------------------------------------
def getORBServiceProperties(server, appServerProperties,checkSettingsOverride=0):
  
  
  _app_trace("getORBServiceProperties(%s, appServerProperties)" % server,"entry")

  SEPARATOR=progInfo["line.separator"]
  
  # ObjectRequestBroker Service
  
  # Get settings as long as the precheck feature is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()):
    orb = AdminConfig.list("ObjectRequestBroker",server)
    if (not isEmpty(orb)):
  
      subItemIds = {}
      collectSimpleProperties(appServerProperties,"appserver.orbService.prop", orb, [],subItemIds)
      
      threadPoolId = subItemIds.get("appserver.orbService.prop.threadPool")
      #threadPoolId = AdminConfig.showAttribute(orb,"threadPool")
      if (not isEmpty(threadPoolId)):
          collectSimpleProperties(appServerProperties,"appserver.orbService.threadPool.prop" , threadPoolId, [])
      
      collectCustomProperties(appServerProperties,"appserver.orbService.customProperties", orb, "properties")
          
    
  _app_trace("getORBServiceProperties()","exit")

#-------------------------------------------------------------------------------------------
# getEJBContainerProperties
#-------------------------------------------------------------------------------------------
def getEJBContainerProperties(server, appServerProperties,checkSettingsOverride=0):
  
  
  _app_trace("getEJBContainerProperties(%s, appServerProperties)" % server,"entry")

  SEPARATOR=progInfo["line.separator"]
    
  # EJBContainer
  # Get settings as long as the precheck feature is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()):
    ejbId = AdminConfig.list("EJBContainer",server)
    if (not isEmpty(ejbId)):
      subItemIds = {}
      collectSimpleProperties(appServerProperties,"appserver.ejbContainer.prop", ejbId, [],subItemIds)
      
      cacheId = subItemIds.get("appserver.ejbContainer.prop.cacheSettings")
      #cacheId = AdminConfig.showAttribute(ejbId, "cacheSettings")
      if (not isEmpty(cacheId)):
          collectSimpleProperties(appServerProperties,"appserver.ejbContainer.cacheSettings.prop", cacheId, [])
      drsId = subItemIds.get("appserver.ejbContainer.prop.drsSettings")
      #drsId = AdminConfig.showAttribute(ejbId, "drsSettings")
      if (not isEmpty(drsId)):
          collectSimpleProperties(appServerProperties,"appserver.ejbContainer.drsSettings.prop", drsId, [])
      timerId = subItemIds.get("appserver.ejbContainer.prop.timerSettings")
      #timerId = AdminConfig.showAttribute(ejbId,"timerSettings")
      if (not isEmpty(timerId)):
          collectSimpleProperties(appServerProperties,"appserver.ejbContainer.timerSettings.prop", timerId, [])

      try:
        asyncid =  subItemIds.get("appserver.ejbContainer.prop.asyncSettings") 
        if (not isEmpty(asyncid)):
            collectSimpleProperties(appServerProperties,"appserver.ejbContainer.asyncSettings.prop",asyncid,[])
      except:
        # pre 8.0
        pass
  
  _app_trace("getEJBContainerProperties()","exit")

#-------------------------------------------------------------------------------------------
# Add properties for a servers HAManagerService to the supplied Properties object.
# Property keys use the following names:
#     appserver.hamanagerService.prop.attribute
#     appserver.hamanagerService.threadPool.prop.attribute
#     appserver.hamanagerService.customProperties.prop.propertyname
#-------------------------------------------------------------------------------------------
def getHAManagerServiceProperties(server, appServerProperties,checkSettingsOverride=0):
  
  
  _app_trace("getHAManagerServiceProperties(%s, appServerProperties)" % server,"entry")

  # Get settings as long as the precheck feature is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()):
    
    SEPARATOR=progInfo["line.separator"]    
    
    haserviceList = AdminConfig.list("HAManagerService",server).split(SEPARATOR)
    if (len(haserviceList) >= 1 and not isEmpty(haserviceList[0])):
        haservice = haserviceList[0]
        
        subItemIds = {}
        collectSimpleProperties(appServerProperties,"appserver.hamanagerService.prop" , haservice, [],subItemIds) 

        threadPoolId = subItemIds.get("appserver.hamanagerService.prop.threadPool")
        #threadPoolId = AdminConfig.showAttribute(haservice,"threadPool")
        if (not isEmpty(threadPoolId)):
            collectSimpleProperties(appServerProperties,"appserver.hamanagerService.threadPool.prop" , threadPoolId, [])  
      
        collectCustomProperties(appServerProperties,"appserver.hamanagerService.customProperties", haservice, "properties")
          
    
  _app_trace("getHAManagerServiceProperties()","exit")
    

############################################################################
# getStreamRedirectProperties
############################################################################
def getStreamRedirectProperties(server,appServerProperties,checkSettingsOverride=0):
  _app_trace("getStreamRedirectProperties(%s,appServerProperties)" % server,"entry")
  
  # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
      # Log Properties
      ol = AdminConfig.showAttribute(server, 'outputStreamRedirect')
      if ( ol != "" ):
        storePropertiesInSet("appserver.processdef.outputLog.prop"  ,ol,appServerProperties)
        

      ol = AdminConfig.showAttribute(server, 'errorStreamRedirect')
      if ( ol != "" ):
        storePropertiesInSet("appserver.processdef.errorLog.prop",ol,appServerProperties)
        
  _app_trace("getStreamRedirectProperties()","exit")
  
##########################################################################
# getPMISettings
##########################################################################
def getPMISettings(server, appServerProperties,checkSettingsOverride=0):
  _app_trace("getPMISettings(%s,appServerProperties)" % server,"entry")

  # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
    
    # PMI Settings - Basic enablement only
    pmiServiceId = AdminConfig.list('PMIService',server)
    if (pmiServiceId != "") :
      collectSimpleProperties(appServerProperties,"appserver.pmiService.prop" , pmiServiceId, [])

  _app_trace("getPMISettings()","exit")


##########################################################################
# getMonitoringPolicyProperties
##########################################################################
def getMonitoringPolicyProperties(server, appServerProperties,checkSettingsOverride=0):
  
  _app_trace("getMonitoringPolicyProperties(%s, appServerProperties)" % server, "entry")

  # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
    # Monitoringpolicy
    tp = AdminConfig.showAttribute(AdminConfig.list("JavaProcessDef",server),"monitoringPolicy")
    if ( tp != "" ):
      collectSimpleProperties(appServerProperties, "appserver.processdef.monitoringpolicy.prop" , tp, [])


  _app_trace("getMonitoringPolicyProperties()", "exit")
  

##########################################################################
# getProcessExcecutionSettings
##########################################################################
def getProcessExcecutionSettings(server, appServerProperties,checkSettingsOverride=0):

  _app_trace("getProcessExecutionSettings(%s, appServerProperties)" % server,"entry")
  
  # Pull the properties if we are enabled for the precheck feature
  if (checkSettingsOverride or  isCheckSettingsEnabled()):
    
    SEPARATOR=progInfo["line.separator"]
    # ProcessExecution 
    tp = AdminConfig.list("ProcessExecution",server).split(SEPARATOR)
    for p in tp:
      for s in AdminConfig.show(p).split(SEPARATOR):
          k,v = toKeyValue(s)
          if (isEmpty(v)): v = ""
          appServerProperties["appserver.processExecution.prop.%s" %k] = v
  
  _app_trace("getProcessExecutionSettings()","exit")
  

##########################################################################
# getWorkingDirectoryProperties
##########################################################################
def getWorkingDirectoryProperties(server, processId, appServerProperties,checkSettingsOverride=0):
  _app_trace("getWorkingDirectory(%s, %s, appServerProperties,%d)" % ( server,processId,checkSettingsOverride), "entry")
  
    # Pull the settings as long as the precheck setting is enabled
  if (checkSettingsOverride or isCheckSettingsEnabled()):
    # @JJM Working directory
    if (isEmpty(processId)):
      processId = AdminConfig.list("ProcessDef", server)
    wd = AdminConfig.showAttribute(processId,"workingDirectory")
    if ( wd != "" ):
      appServerProperties["appserver.processdef.process.prop.workingDirectory"] = wd
        
  _app_trace("getWorkingDirectory()","exit")

#-------------------------------------------------------------------------------
# getIoRedirectProperties
#
# Parameters
#
#-------------------------------------------------------------------------------
def getIoRedirectProperties(server,processId,appServerProperties,checkSettingsOverride=0):
  _app_entry("getIoRedirectProperties(%s,%s,appServerProperties,%d)" , server,processId,checkSettingsOverride)
  retval = None
  try:
        # Pull the settings as long as the precheck setting is enabled
    if (checkSettingsOverride or isCheckSettingsEnabled()):
      # @JJM 
      if (isEmpty(processId)):
        processId = AdminConfig.list("ProcessDef", server)
        
      ioRedirect = AdminConfig.showAttribute(processId,"ioRedirect")
      if (not isEmpty(ioRedirect)):
        collectSimpleProperties(appServerProperties,"appserver.processdef.ioRedirect.prop",ioRedirect)
      
      retval = appServerProperties
        
  except:
    _app_exception("Unexpected problem in getIoRedirectProperties()")
  
  _app_exit("getIoRedirectProperties()")
  return retval

##########################################################################
# getStartBeanServiceProperties
##########################################################################
def getStartBeanServiceProperties(server, appServerProperties):
  _app_trace("getStartBeanServiceProperties(%s,appServerProperties)" % server,"entry")
  
  tp = AdminConfig.list("StartupBeansService",server)
  appServerProperties["appserver.startupbeansservice.enable"] = AdminConfig.showAttribute(tp,"enable")

  _app_trace("getStartBeanServiceProperties()","exit")

#-------------------------------------------------------------------------------
# getDynamicCacheServiceProperties
#
# Parameters
#   server - configurationId of server
#   appServerProperties - dictionary to load into
#   checkSettingsOverride - forces collection if checkSettings option is disabled
#-------------------------------------------------------------------------------
def getDynamicCacheServiceProperties(server,appServerProperties,checkSettingsOverride=0):
  _app_entry("getDynamicCacheServiceProperties(%s,appServerProperties,%d)" , server,checkSettingsOverride)
  retval = None
  try:
    if (checkSettingsOverride or isCheckSettingsEnabled()):
      idProps = {}
      
      cacheId = AdminConfig.list("DynamicCache",server)
      
      if (not isEmpty(cacheId)):
        collectSimpleProperties(appServerProperties,"appserver.dynamicCache.prop",cacheId,idProps=idProps,getSimpleChildren=1,
                                collectListChildren=1,collectPropertyAttributes=1)
  except:
    _app_exception("Unexpected problem in getDynamicCacheServiceProperties()")
  
  _app_exit("getDynamicCacheServiceProperties(retval=%s)" % retval)
  return retval

  
       
#-------------------------------------------------------------------------------
# modifyDynamicCache
#
# Parameters
#    dynamicCacheId - configuration ID of DynamicCache configuration item to be updated
#    serverId - configuration ID of server - will be used to lookup DynamicCache if necessary
#    baseProps - a dictionary containing DynamicCache configuration properties to apply
#    replicationProps - a dictionary containing settings for the cacheReplication attribute
#    diskPerformanceProps - a dictionary containing settings for the diskCacheCustomPerformanceSettings attribute
#    diskEvictionProps - a dictionary containing settings for the diskCacheEvictionPolicy attribute
#    memoryEvictionProps - a dictionary contain settings for the memoryCacheEvictionPolicy attribute
#    cacheGroups - a list of dictionarys with attributes for defining multipe ExternalCacheGroup items
#                   [  { name: value, type: value,
#                             members: [ {adapterBeanName : value, address: value, frcaCacheGroupMember: {key:value}} , ....] },
#                       ...
#                   ]
#    resetCacheGroups - boolean flag, if 1, the existing cacheGroups will be deleted and replaced, if 0
#                       cacheGroups input will be merged in to existing CacheGroups and CacheGroup members
#
# Returns:
#   configuration ID of DynamicCache configuration item
#-------------------------------------------------------------------------------
def modifyDynamicCache(dynamicCacheId=None,serverId=None,baseProps=None,customProperties=None,replicationProps=None,diskPerformanceProps=None,diskEvictionProps=None,memoryEvictionProps=None,cacheGroups=None,resetCacheGroups=0):
  _app_entry("modifyDynamicCache(%s,%s,%s,%s,%s,%s,%s,%s,%d)" , dynamicCacheId,serverId,baseProps,replicationProps,diskPerformanceProps,diskEvictionProps,memoryEvictionProps,cacheGroups,resetCacheGroups)
  retval = None
  try:
    baseAttrs = propsToAttrList(baseProps)
    if (isEmpty(dynamicCacheId) and not isEmpty(serverId)):
      dynamicCacheId = AdminConfig.list("DynamicCache",serverId)
      
      if (isEmpty(dynamicCacheId)):
        if (len(baseAttrs) == 0):
          baseAttrs = [["defaultPriority","1"], ["cacheSize","2000"]]
        
        _app_trace('About to call AdminConfig.create("DynamicCache",%s,%s)' % (serverId,baseAttrs))
        dynamicCacheId = AdminConfig.create("DynamicCache",serverId,baseAttrs)
        
    if (isEmpty(dynamicCacheId)):
      raise StandardError("Missing DynamicCache configuration ID")
    
    if ( len(baseAttrs) > 0):
      if (modifyObject(dynamicCacheId,baseAttrs)):
        raise StandardError("Error updating base attributes in DynamicCache %s" % dynamicCacheId)
        
    if (len(customProperties) > 0):
      errMsg = updateCustomProperties(dynamicCacheId,"properties", "Property", customProperties)
      if (not isEmpty(errMsg)):
        raise StandardError("Error updating custom properties in DynamicCache %s: %s" % (dynamicCacheId,errMsg))
    
    if (replicationProps != None and len(replicationProps) > 0):
      doUpdateCreate("DRSSettings",dynamicCacheId,replicationProps,"cacheReplication")
    
    if (diskPerformanceProps != None and len(diskPerformanceProps) > 0):
      doUpdateCreate("DiskCacheCustomPerformanceSettings",dynamicCacheId,diskPerformanceProps,"diskCacheCustomPerformanceSettings")
    
    if (diskEvictionProps != None and len(diskEvictionProps) > 0):
      doUpdateCreate("DiskCacheEvictionPolicy",dynamicCacheId,diskEvictionProps,"diskCacheEvictionPolicy")
    
    if (memoryEvictionProps != None and len(memoryEvictionProps) > 0):
      doUpdateCreate("MemoryCacheEvictionPolicy",dynamicCacheId,memoryEvictionProps,"memoryCacheEvictionPolicy")
    
    existingCacheGroupIds = []
    
    if (resetCacheGroups):
      # We'll be rebuilding the cache groups
      idsToClear = wsadminToList(AdminConfig.showAttribute(dynamicCacheId,"cacheGroups"))
      for clearId in idsToClear:
        if (isEmpty(clearId)):
          continue
        _app_trace('About to call AdminConfig.remove(%s)'% clearId)
        AdminConfig.remove(clearId)
    
    if (cacheGroups != None and len(cacheGroups) > 0):  
      existingCacheGroups = wsadminToList(AdminConfig.showAttribute(dynamicCacheId,"cacheGroups"))
      if (len(existingCacheGroups) == 1 and isEmpty(existingCacheGroups[0])):
        existingCacheGroups = []
      existingDict = {}
      for gid in existingCacheGroups:
        existingDict[splitOffName(gid)] = gid
      
      for cacheGroup in cacheGroups:
        cgName = cacheGroup.get("name")
        if (isEmpty(cgName)):
          raise StandardError("Invalid input: name missing from CacheGroup")
        
        existingId = existingDict.get(cgName)
        if (isEmpty(existingId)):
          # Create new cache group
          cgattrs = propsToAttrList(cacheGroup)
          _app_trace('About to call AdminConfig.create("ExternalCacheGroup",%s,%s)'% (dynamicCacheId,cgattrs))
          cgId = AdminConfig.create("ExternalCacheGroup",dynamicCacheId,cgattrs)
        else:
          # Merging of settings
          # First step is to get information on current members
          existingMemberIds = wsadminToList(AdminConfig.showAttribute(existingId,"members"))
          existingMemberData = []
          for memberId in existingMemberIds:
            if (isEmpty(memberId)):
              existingMemberData.append({})
            else:
              memberData = {}
              existingMemberData.append(collectSimpleProperties(memberData,"member.prop",memberId,getSimpleChildren=1))
          
          inputMembers = cacheGroup.get("members",[])
          
          for inputMember in inputMembers:    
            matchExisting = None
            matchId = None
            matchIdx = -1
            midx = -1
            for existingMember in existingMemberData:
              midx += 1
              if (existingMember.get("member.prop.adapterBeanName") == inputMember.get("adapterBeanName") and
                  existingMember.get("member.prop.address") == inputMember.get("address")):
                    matchIdx = midx
                    matchExisting = existingMember
                    matchId = existingMemberIds[matchIdx]
                    break
            
            if (isEmpty(matchId)):
              # Need to create a new member
              memberAttrs = propsToAttrList(inputMember)
              _app_trace('About to call AdminConfig.create("ExternalCacheGroupMember",%s,%s)'% (existingId,memberAttrs))
              memberId = AdminConfig.create("ExternalCacheGroupMember",existingId,memberAttrs)
            elif (len(inputMember)>2):
              # Have more than the identifying properties
              memberAttrs = propsToAttrList(inputMember)
              if (modifyObject(matchId,memberAttrs)):
                raise StandardError("Error updating %s" % matchId)
          # end for each input cache group      
        #end merging of ExternalCacheGroup Settings
                      
    
    retval = dynamicCacheId  
  except:
    _app_exception("Unexpected problem in modifyDynamicCache()")
  
  _app_exit("modifyDynamicCache(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# getObjectPoolServiceProperties
#
# Parameters
#
#-------------------------------------------------------------------------------
def getObjectPoolServiceProperties(server,appServerProperties,checkSettingsOverride=0,objectPoolServiceId=None):
  _app_entry("getObjectPoolServiceProperties(%s,appServerProperties,%d)" , server,checkSettingsOverride)
  retval = None
  try:
    if (isValidType("ObjectPoolService")):
      if (checkSettingsOverride or isCheckSettingsEnabled()):
        if (isEmpty(objectPoolServiceId)):
          objectPoolServiceId = AdminConfig.list("ObjectPoolService",server)
          if (not isEmpty(objectPoolServiceId)):
            retval = objectPoolServiceId
            collectSimpleProperties(appServerProperties,"appserver.objectPoolService.prop",objectPoolServiceId,collectPropertyAttributes=1)
    
  except:
    _app_exception("Unexpected problem in getObjectPoolServiceProperties(%s)" % server)
  
  _app_exit("getObjectPoolServiceProperties(retval=%s)" % retval)
  return retval
  


##########################################################################
# getAdminServicesProperties
#
# If collectedIds parameter is supplied, the following properties will be
# returned to the caller:
#    appserver.adminService.id - configuration ID of the admin service
#    appserver.adminService.prop.connectors - The configuration IDs of the connectors in wsadmin list format: "[ id1 id2 id3 ...]"
##########################################################################
def getAdminServicesProperties(server,appServerProperties,checkSettingsOverride=0,collectedIds = None):
  
  _app_trace("getAdminServicesPropertiess(%s, appServerProperties,%d)" % (server, checkSettingsOverride), "entry")
  
  try:
    # Pull the settings as long as the precheck setting is enabled
    if (checkSettingsOverride or isCheckSettingsEnabled()):
    
      connectors = ["SOAPConnector", "JSR160RMIConnector", "RMIConnector","IPCConnector"]
      adminServiceId = AdminConfig.list("AdminService",server)
      if (not isEmpty(adminServiceId)):
        if (collectedIds != None):
          collectedIds["appserver.adminService.id"] = adminServiceId
        nestedIds = {}
        serviceprops =  collectSimpleProperties(None, "appserver.adminService.prop",adminServiceId,[],nestedIds)
        for key in serviceprops.keys():
          appServerProperties[key] = serviceprops.get(key)
        
        for key in nestedIds.keys():
          val = nestedIds.get(key)
          
          # Return this key to the caller
          if (collectedIds != None):
            collectedIds[key] = val
          
          if (isArray(val)):
            continue
            
          # Ok, if this is an reference to a connector, we'll use the connector type as the value
          for connectorType in connectors:
            if (val.find(connectorType) >= 0):
              appServerProperties[key] = connectorType
              break
        
        collectCustomProperties(appServerProperties,"appserver.adminService.properties", adminServiceId, "properties")
        
        connectorIds = wsadminToList(nestedIds.get("appserver.adminService.prop.connectors","[ ]"))
        connectorIdx = 0
        for connectorId in connectorIds:
          for connectorType in connectors:
            if (connectorId.find(connectorType) >= 0):
              connectorIdx = connectorIdx + 1
              appServerProperties["appserver.adminService.connectors.%d.type" % (connectorIdx)] = connectorType
              collectSimpleProperties(appServerProperties,"appserver.adminService.connectors.%d.prop"% (connectorIdx),connectorId,[])
              collectCustomProperties(appServerProperties,"appserver.adminService.connectors.%d.properties"% (connectorIdx), connectorId, "properties")
              break
        appServerProperties["appserver.adminService.connectors.count"] = "%d" % connectorIdx

  except:
    _app_trace("Unexpected error in getAdminServicesProperties","exception")
    raise StandardError("Unexpected error in getAdminServicesProperties")
        
  _app_trace("getAdminServicesPropertiess()", "exit")
  
#-------------------------------------------------------------------------------
# updateAdminServiceConnectorProperties
#-------------------------------------------------------------------------------
def updateAdminServiceConnectorProperties(serverId, remoteAdminProtocol, localAdminProtocol,adminServiceId=None, connectorIds=None, adminServiceProps=None, soapProps=None,rmiProps=None,jsr160props=None,localProps=None):
  _app_trace("updateAdminServiceConnectorProperties(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)" % (serverId, remoteAdminProtocol, localAdminProtocol,adminServiceId, connectorIds, adminServiceProps, soapProps,rmiProps,jsr160props,localProps),"entry")
  try:
    connectorTypes = ["SOAPConnector", "JSR160RMIConnector", "RMIConnector","IPCConnector"]
    
    if (isEmpty(adminServiceId)):
      adminServiceId = AdminConfig.list("AdminService",serverId)
    if (isEmpty(connectorIds)):
      connectorsId = AdminConfig.showAttribute(adminServiceId,"connectors")
    
    connectorList = wsadminToList(connectorIds)
    
    attrs = []

    if (not isEmpty(remoteAdminProtocol)):
      foundId = None
      # Determine ID to set it to
      for connectorId in connectorList:
        if (connectorId.find(remoteAdminProtocol) >= 0):
          if (remoteAdminProtocol == "RMIConnector"):
            # Make sure this id is not for the JSR160
            if (connectorId.find("JSR160") >= 0):
              continue
          foundId =  connectorId
          break
      
      if (isEmpty(foundId)):
        raise StandardError("Could not find a connector match for %s" % remoteAdminProtocol)
      
      attrs.append(["remoteAdminProtocol", foundId])

    if (not isEmpty(localAdminProtocol)):
      foundId = None
      # Determine ID to set it to
      for connectorId in connectorList:
        if (connectorId.find(localAdminProtocol) >= 0):
          if (localAdminProtocol == "RMIConnector"):
            # Make sure this id is not for the JSR160
            if (connectorId.find("JSR160") >= 0):
              continue
          foundId =  connectorId
          break
      
      if (isEmpty(foundId)):
        raise StandardError("Could not find a connector match for %s" % localAdminProtocol)
      
      attrs.append(["localAdminProtocol", foundId])
      
    if (len(attrs) > 0):
      if (modifyObject(adminServiceId,attrs)):
        raise StandardError("Unable to update AdminService configuration: %s" % attrs)
    
    # Update the AdminService custom properties
    if (adminServiceProps != None and len(adminServiceProps) > 0):
      errMsg = updateCustomProperties(adminServiceId, "properties","Property", adminServiceProps)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update AdminService custom properties: %s" % errMsg)
    
    # Now let's update the connector properties
    if (soapProps != None and len(soapProps) > 0):
      # Get the soap connector ID
      connectorId = findConnectorId(connectorList, "SOAPConnector")
      
      errMsg = updateCustomProperties(connectorId, "properties", "Property", soapProps)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update SOAPConnector custom properties: %s" % errMsg)
        
    if (rmiProps != None and len(rmiProps) > 0):
      # Get the soap connector ID
      connectorId = findConnectorId(connectorList, "RMIConnector")
      
      errMsg = updateCustomProperties(connectorId, "properties", "Property", rmiProps)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update RMIConnector custom properties: %s" % errMsg)      

    if (jsr160props != None and len(jsr160props) > 0):
      # Get the soap connector ID
      connectorId = findConnectorId(connectorList, "JSR160RMIConnector")
      
      errMsg = updateCustomProperties(connectorId, "properties", "Property", jsr160props)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update JSR160RMIConnector custom properties: %s" % errMsg)       
     
    if (localProps != None and len(localProps) > 0):
      # Get the soap connector ID
      connectorId = findConnectorId(connectorList, "IPCConnector")
      
      errMsg = updateCustomProperties(connectorId, "properties", "Property", localProps)
      if (not isEmpty(errMsg)):
        raise StandardError("Unable to update IPCConnector custom properties: %s" % errMsg)          
    
  except:
    _app_trace("Unexpected error in updateAdminServiceConnectorProperties","exception")
    raise StandardError("Unexpected error in updateAdminServiceConnectorProperties")
    
  _app_trace("updateAdminServiceConnectorProperties()","exit")

#enddef updateAdminServiceConnectorProperties

##########################################################################
# findConnectorId
##########################################################################
def findConnectorId(connectorList, connectorType):
      foundId = None
      
      for connectorId in connectorList:
        if (connectorId.find(connectorType) >= 0):
          if (connectorType == "RMIConnector"):
            # Make sure this id is not for the JSR160
            if (connectorId.find("JSR160") >= 0):
              continue
          foundId =  connectorId
          break
      
      if (isEmpty(foundId)):
        raise StandardError("Could not find a connector match for %s" % connectorType)
        
      return foundId
      
#-------------------------------------------------------------------------
# createPMIModule
#
# Utility method for creating a PMIModule configuration. 
#
# Parameters:
#     parentModuleId - The configuration ID of the parent module that the new
#                      module will be created under.
#     moduleName      - The moduleName attribute 
#     moduleType      - The value for the type attribute
#     enableSettings  - The value for the enable attribute
#
# Returns: The configuration ID for the new module, otherwise raises StandardError
#-------------------------------------------------------------------------      
def createPMIModule(parentModuleId, moduleName, moduleType, enableSettings):
  _app_trace("createPMIModule(%s,%s,%s,%s)" % (parentModuleId, moduleName, moduleType, enableSettings),"entry")
  
  newModuleId = None
  
  try:
    if (enableSettings == None):
      enableSettings = ""
      
    attrs = [  ["moduleName", moduleName] , ["type",moduleType], ["enable", enableSettings]]
    
    _app_trace('About to call AdminConfig.create("PMIModule", %s,%s)' % (parentModuleId, attrs))
    newModuleId = AdminConfig.create("PMIModule", parentModuleId, attrs)
    
  except:
    _app_trace("Unexpected error in createPMIModule","exception")
    raise StandardError("Unexpected error in createPMIModule")
  
  _app_trace("createPMIModule(retval = %s)" % newModuleId, "exit")
  return newModuleId
  
#------------------------------------------------------------------
# getPMIModulePropertiesForService
#
# Returns a dictionary representing the PMIModule tree for the specified
# PMIService. See getPMIModuleProperties for addtional details of this
# dictionary structure.
#------------------------------------------------------------------
def getPMIModulePropertiesForService(pmiServiceId):
  _app_trace("getPMIModulePropertiesForService(%s)" %( pmiServiceId),"entry")
  retval = None
  try:
    topModuleId = AdminConfig.list("PMIModule",pmiServiceId)
    if (topModuleId):
      retval = getPMIModuleProperties(topModuleId)
    else:
      raise StandardError("Could not locate top PMI Module for %s" % pmiServiceId)
  except:
    _app_trace("Unexpected error in getPMIModulePropertiesForService","exception")
    raise StandardError("Unexpected error in getPMIModulePropertiesForService")    
  
  _app_trace("getPMIModulePropertiesForService","exit")
  return retval
  
#------------------------------------------------------------------------------
# getPMIModuleProperties
#
# This function will recursive traverse through the PMIModule tree
# structure and return a dictionary containing the PMI module settings
# for each entry in the tree.
#
# The keys to the dictionary are:
#    A string representation of the PMI descriptor. This is build by getting the
#    string representation of the Jython list of tuples used to represent the 
#    PMI descriptor:  [ (module-name, module-type), (submodule-name, sub-module-type), ...]
# 
# The values in the returned dictionary are a dictionary with the settings
# for a specific module:
#     pmiModule.prop.moduleName
#     pmiModule.prop.type
#     pmiModule.prop.enable
#     pmiModule.CONFIG_ID - The configuration ID of this module
#     pmiModule.PMIMODULES - A jython list holding the configuration ID of direct submodules.
#
# If the PMI tree structure is known (the name/type of each node in the PMI tree), then the caller
# will be able to pull the module informaiton from this dictionary.
#
# A duplicate entries is also stored using the configuration ID as the key instead  of the string.
#    
# 
# Parameters:
#   moduleId - the configuration ID of the PMI module to be processed
#   parentDescriptor - A list reperesentation of the PMI name/type structure used to 
#      find the parent PMIModule in the tree. This will be used as the root for the 
#      descriptors built by this class.
#
# Returns a dicitonary containing PMIModule cofiguration for the supplied PMIModule and all
# of its children
def getPMIModuleProperties(moduleId, parentDescriptor=[]):
  
  _app_trace("getPMIModuleProperties(%s %s)" % (moduleId, parentDescriptor),"entry")
  retval = {}
  
  try:
    moduleDescriptor = []
    moduleDescriptor.extend(parentDescriptor)
    idProps = {}
    
    tempProps = {}
    tempProps = collectSimpleProperties(tempProps, "pmiModule.prop",moduleId, [],idProps)
    
    moduleName = tempProps.get("pmiModule.prop.moduleName")
    moduleType = tempProps.get("pmiModule.prop.type","")
    
    if (moduleName != "pmi" and moduleType != ""):
    
      moduleDescriptor.append( (moduleName,moduleType))
    
    tempProps["pmiModule.CONFIG_ID"] = moduleId
    subModules =  wsadminToList(idProps.get("pmiModule.prop.pmimodules",""))
    tempProps["pmiModule.PMIMODULES"] = subModules
    
    retval[str(moduleDescriptor)] = tempProps
    retval[moduleId] = tempProps
    
    for subModule in subModules:
      if (not isEmpty(subModule)):
        tempReturn = getPMIModuleProperties(subModule,moduleDescriptor)
        
        retval.update(tempReturn)
  except:
    _app_trace("Unexpected error in getPMIModuleProperties","exception")
    raise StandardError("Unexpected error in getPMIModuleProperties")    
  
  _app_trace("getPMIModuleProperties()","exit")
  
  return retval
  
#enddef getPMIModuleProperties  



#-------------------------------------------------------------------------------
# getWorkAreaServiceProperties
#    Adds the following properties to the dictionary:
#        workAreaService.prop.XXXX
#        workAreaService.properties.XXXXX
#        workAreaService.CONFIG_ID
# Parameters
#   serverId 
#-------------------------------------------------------------------------------
def getWorkAreaServiceProperties(serverId,appServerProperties,checkSettingsOverride=0):
  _app_entry("getWorkAreaServiceProperties(%s,appServerProperties,%d)" , serverId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = {}
    
    retval = appServerProperties
      
    # Pull the properties if we are enabled for the precheck feature
    if (checkSettingsOverride or  isCheckSettingsEnabled()):
        workAreaServiceId = AdminConfig.list("WorkAreaService",serverId)
        if (not isEmpty(workAreaServiceId)):
          collectSimpleProperties(appServerProperties,"workAreaService.prop",workAreaServiceId,collectPropertyAttributes=1)
          appServerProperties["workAreaService.CONFIG_ID"] = workAreaServiceId
  except:
    _app_exception("Unexpected problem in getWorkAreaServiceProperties()")
  
  _app_exit("getWorkAreaServiceProperties()" )
  return retval
  
#-------------------------------------------------------------------------------
# getWorkAreaPartitionServiceProperties
#
#      workAreaPartitionService.prop.enable = false
#      workAreaPartitionService.partitions.1.name = WAP_ALPHA
#      workAreaPartitionService.partitions.1.prop.bidirectional = false
#      workAreaPartitionService.partitions.1.prop.deferredAttributeSerialization = false
#      workAreaPartitionService.partitions.1.prop.enable = true
#      workAreaPartitionService.partitions.1.prop.enableWebServicePropagation = false
#      workAreaPartitionService.partitions.1.prop.maxReceiveSize = 32768
#      workAreaPartitionService.partitions.1.prop.maxSendSize = 32768
#      ...
#      workAreaPartitionService.partitions.count = x
# Parameters
#     serverId - Configuration ID of server
#     appServerProperties - dictionary to store results in
#     checkSettingsOverride - Override possible disablement of the attribute comparison function
#-------------------------------------------------------------------------------
def getWorkAreaPartitionServiceProperties(serverId,appServerProperties,checkSettingsOverride=0):
  _app_entry("getWorkAreaPartitionServiceProperties(%s,appServerProperties,%d)" , serverId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = {}
      
    retval = appServerProperties
    
    # Pull the properties if we are enabled for the precheck feature
    if (checkSettingsOverride or  isCheckSettingsEnabled()):
      wapServiceId = AdminConfig.list("WorkAreaPartitionService",serverId)
      if (not isEmpty(wapServiceId)):
        collectSimpleProperties(appServerProperties,"workAreaPartitionService.prop",wapServiceId,collectListChildren=1,collectPropertyAttributes=1,sortListChildren=1)
  
  except:
    _app_exception("Unexpected problem in getWorkAreaPartitionServiceProperties()")
  
  _app_exit("getWorkAreaPartitionServiceProperties(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# updateWorkAreaServiceProperties
#
# Parameters
#
#-------------------------------------------------------------------------------
def updateWorkAreaServiceProperties(serverId=None,workAreaServiceId=None,baseProps=None,customProps=None):
  _app_entry("updateWorkAreaServiceProperties(%s,%s,%s,%s)" , serverId,workAreaServiceId,baseProps,customProps)
  retval = None
  try:
    if (isEmpty(workAreaServiceId) and not isEmpty(serverId)):
      workAreaServiceId = doUpdateCreate("WorkAreaService",serverId,baseProps)
    elif (not isEmpty(workAreaServiceId)):
      modifyObjectProperties(workAreaServiceId,baseProps,"WorkAreaService")
    else:
      raise StandardError("No configuration IDs supplied")
    
    if (customProps != None):
      errmsg = updateCustomProperties(workAreaServiceId, "properties", "Property", customProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Problem updating custom properties for WorkAreaService %s : %s" % workAreaServiceId, errmsg) 
    
    retval = workAreaServiceId  
  except:
    _app_exception("Unexpected problem in updateWorkAreaServiceProperties()")
  
  _app_exit("updateWorkAreaServiceProperties(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# updateWorkAreaPartitionService
#    Updates WorkAreaPartitionServices, creating if necessary
#    Either serverId or wapServiceID parameters are requried
# Parameters
#    serverId (optional) Configuration ID of application server
#    wapServiceId (optional) Configuration ID of WorkAreaPartitionService
#    baseProps - properties to apply
#-------------------------------------------------------------------------------
def updateWorkAreaPartitionService(serverId=None,wapServiceId=None,baseProps=None):
  _app_entry("updateWorkAreaPartitionService(%s,%s,%s)" , serverId,wapServiceId,baseProps)
  retval = None
  try:
    if (isEmpty(wapServiceId) and not isEmpty(serverId)):
      wapServiceId = doUpdateCreate("WorkAreaPartitionService",serverId,baseProps)
    else:
      modifyObjectProperties(wapServiceId,baseProps,"WorkAreaPartitionService")
    
    retval = wapServiceId
  except:
    _app_exception("Unexpected problem in updateWorkAreaPartitionService()")
  
  _app_exit("updateWorkAreaPartitionService(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# getWorkAreaPartitionId
#
# Parameters
#
#-------------------------------------------------------------------------------
def getWorkAreaPartitionId(wapName,serverId=None,nodeName=None,serverName=None):
  _app_entry("getWorkAreaPartitionId(%s,%s,%s,%s)" , wapName,serverId,nodeName,serverName)
  retval = None
  try:
    if (isEmpty(serverName) and not isEmpty(serverId)):
      serverName = AdminConfig.showAttribute(serverId,"name")
    if (isEmpty(nodeName) and not isEmpty(serverId)):
      nodeName = getNodeNameForServer(serverId)
      
    if (not isEmpty(serverName) and not isEmpty(nodeName)):
      retval = AdminConfig.getid("/Node:%s/Server:%s/PME51ServerExtension:/WorkAreaPartitionService:/WorkAreaPartition:%s/" %(nodeName,serverName,wapName))
    elif (not isEmpty(serverId)):
      # Could be a template
      waps = AdminConfig.list("WorkAreaPartition",serverId).splitlines()
      for wapId in waps():
        if (not isEmpty(wapId)):
          tempName = splitOffName(wapId)
          if (tempName == wapName):
            retval = wapId
            break
  except:
    _app_exception("Unexpected problem in getWorkAreaPartitionId()")
  
  _app_exit("getWorkAreaPartitionId(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# createWorkAreaPartition
#
# Parameters
#
#-------------------------------------------------------------------------------
def createWorkAreaPartition(wapName,baseProps,customProps,serverId=None,wapServiceId=None):
  _app_entry("createWorkAreaPartition(%s,%s,%s,%s,%s)" , wapName,baseProps,customProps,serverId,wapServiceId)
  retval = None
  try:
    if (isEmpty(wapServiceId)):
      wapServiceId = AdminConfig.list("WorkAreaPartitionService",serverId)
    
    baseProps["name"] = wapName
    
    retval = doUpdateCreate("WorkAreaPartition",wapServiceId,baseProps,forceCreate=1)
    
    if (customProps != None and len(customProps) > 0):
      errmsg = updateCustomProperties(retval, "properties", "Property", customProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Problem updating custom properties for WorkAreaPartition %s : %s" % retval, errmsg) 
  except:
    _app_exception("Unexpected problem in createWorkAreaPartition()")
  
  _app_exit("createWorkAreaPartition(retval=%s)" % retval)
  return retval

  
#-------------------------------------------------------------------------------
# modifyWorkAreaPartition
#
# Parameters
#    wapName - name of Work Area Partition
#    baseProperties - base properties of WorkAreaPartition configuration item
#    customProperties - custom properties of WorkAreaPartition configuration item
#    wapId - Configuration ID to upate (optional)
#    serverId - Optional Parent ID if need to look up by name
#-------------------------------------------------------------------------------
def modifyWorkAreaPartition(wapName,baseProps,customProps,wapId=None,serverId=None):
  _app_entry("modifyWorkAreaPartition(%s,%s,%s,%s,%s)" , wapName,baseProps,customProps,wapId,serverId)
  retval = None
  try:
    if (isEmpty(wapId)):
      wapId = getWorkAreaPartitionId(wapName,serverId=serverId)
      
    modifyObjectProperties(wapId,baseProps,"WorkAreaPartition")
    
    if (customProps != None and len(customProps) > 0):
      errmsg = updateCustomProperties(wapId, "properties", "Property", customProps)
      if (not isEmpty(errmsg)):
        raise StandardError("Problem updating custom properties for WorkAreaPartition %s : %s" % retval, errmsg) 
        
    retval = wapId
  except:
    _app_exception("Unexpected problem in modifyWorkAreaPartitionmodifyWorkAreaPartition()")
  
  _app_exit("modifyWorkAreaPartitionmodifyWorkAreaPartitionmodifyWorkAreaPartition(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# getCEASettingsProperties
#    Returns settings of CEASettings configuration item as properties in dictionary
#
# Parameters
#    parentId - Parent ID (optional, will be used to look up CEASettings ID)
#    ceaSettingsId - configuration ID of CEASettings item 
#    appServerProperties - dictionary to add results to, may be null
#    checkSettingsOverride - If the global settings check featuere is disabled,
#                             set this parameter to 1 to override and pull properties anyway
#
#    Adds the following properties to the input dictionary
#      CEASettings.prop.xxx - base properties
#      CEASettings.propoperties.prop.xxx - custom properties
#      CEASettings.commsvc.prop.xxx - base properties of Commsvc subitem
#      CEASettings.commsvc.properties.prop.xxx - custom properties of Commsvc subitem
#      CEASettings.ctiGateway.props.xxx - base properties of CTIGateway subitem
#      CEASettings.ctiGateway.properties.xxx - custom properties of CTIGateway subitem
#-------------------------------------------------------------------------------
def getCEASettingsProperties(parentId=None,ceaSettingsId=None,appServerProperties=None,checkSettingsOverride=0):
  _app_entry("getCEASettings(%s,%s,appServerProperties,%d)" , parentId,ceaSettingsId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = []
      
    if (isEmpty(ceaSettingsId)):  
      ceaSettingsId = AdminConfig.list("CEASettings",parentId)
    
    if (not isEmpty(ceaSettingsId)):
       appServerProperties["CEASettings.CONFIG_ID"] = ceaSettingsId
       collectSimpleProperties(appServerProperties,"CEASettings.prop" ,ceaSettingsId,getSimpleChildren=1,collectPropertyAttributes=1)
  except:
    _app_exception("Unexpected problem in getCEASettings()")
  
  _app_exit("getCEASettings(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# updateCEASettings
#
# Parameters
#    parentId - (optional) Parent configuration ID of CEASettings configuration item
#    ceaSettingsId (optional) Configuration Id of CEASettings (if known, otherwise looked up from parent)
#    ceaProps - base properties of CEASettings item
#    ceaCustomProps - (optional) custom properties of CEASettings
#    commsvcProps (optional) base properties of Commsvc attribute subitem
#    commsvcCustomProps (optional) custom properties of Commsvc subitem
#    ctiGatewayProps  (optional) base properties of CTIGateway subitem
#    citGatewayCustomProps (optional) custom properties of CTIGateway subitem
#-------------------------------------------------------------------------------
def updateCEASettings(parentId=None, ceaSettingsId=None,ceaProps=None,ceaCustomProps=None,commsvcProps=None,commsvcCustomProps=None,ctiGatewayProps=None,ctiGatewayCustomProps=None):
  _app_entry("updateCEASettings(%s,%s,%s,%s,%s,%s,%s,%s)" , parentId, ceaSettingsId,ceaProps,ceaCustomProps,commsvcProps,commsvcCustomProps,ctiGatewayProps,ctiGatewayCustomProps)
  retval = None
  try:
    ceaSettingsId = doUpdateCreate("CEASettings",parentId=parentId,newAttributes=ceaProps,parentAttributeName=None,forceCreate=0,
                                   updateId=ceaSettingsId,customProperties=ceaCustomProps)
    
    doUpdateCreate("Commsvc",parentId=ceaSettingsId,newAttributes=commsvcProps,parentAttributeName="commsvc",forceCreate=0,customProperties=commsvcCustomProps)
    
    doUpdateCreate("CTIGateway",parentId=ceaSettingsId,newAttributes=ctiGatewayProps,parentAttributeName="ctiGateway",forceCreate=0,customProperties=ctiGatewayCustomProps)
                       
    retval = ceaSettingsId
  except:
    _app_exception("Unexpected problem in updateCEASettings()")
  
  _app_exit("updateCEASettings(retval=%s)" % retval)
  return retval



#-------------------------------------------------------------------------------
# getCompensationServiceId
#    Locate the configuration ID of the CompensationService depending on parameters
#    supplied.
#
# Parameters
#    serverId - (Optional) Configuration ID of server or template
#    nodeName - (Optional) Node name of server
#    serverName - (Optional) Server name
#-------------------------------------------------------------------------------
def getCompensationServiceId(serverId=None,nodeName=None,serverName=None):
  _app_entry("getCompensationServiceId(%s,%s,%s)" , serverId,nodeName,serverName)
  retval = None
  try:
    
    retval = None
    
    if (not isEmpty(serverId)):
      retval = AdminConfig.list("CompensationService",serverId)
    elif (not isEmpty(nodeName) and not isEmpty(serverName)):
      retval = AdminConfig.getid("/Node:%s/Server:%s/PME51ServerExtension:/CompensationService:/" % (nodeName,serverName))
    
    
  except:
    _app_exception("Unexpected problem in getCompensationServiceId()")
  
  _app_exit("getCompensationServiceId(retval=%s)" % retval)
  return retval




#-------------------------------------------------------------------------------
# getCompensationServiceProperties
#
# Parameters
#    compensationServiceId - ConfigurationID of CompensationService, if known
#    serverId - (Optional) Server/template parent of CompensationService, if need to look up
#    appServerProperties - dictionary to add results to, may be null
#    checkSettingsOverride - If the global settings check featuere is disabled,
#                             set this parameter to 1 to override and pull properties anyway
#
#    Adds the following properties to the input dictionary
#         compensationService.prop.XXXX - base properties of CompensationService
#         compensationService.properties.XXXX - custom properties of CompensationService
#-------------------------------------------------------------------------------
def getCompensationServiceProperties(compensationServiceId=None,serverId=None,appServerProperties=None,checkSettingsOverride=0):
  _app_entry("getCompensationServiceProperties(%s,%s,appServerProperties,%d)" , compensationServiceId,serverId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = {}
    
    retval = appServerProperties
    
    # Pull the properties if we are enabled for the precheck feature
    if (checkSettingsOverride or  isCheckSettingsEnabled()):
      
      if (isEmpty(compensationServiceId) and not isEmpty(serverId)):
        # Call the function to look up the compensation service ID
        compensationServiceId = getCompensationServiceId(serverId=serverId)
      
      if (not isEmpty(compensationServiceId)):
        # Call the utility function that will retrieve these settings
        # and the custom properties
        
        collectSimpleProperties(appServerProperties,"compensationService.prop" ,compensationServiceId,getSimpleChildren=1,collectPropertyAttributes=1)
  except:
    _app_exception("Unexpected problem in getCompensationServiceProperties()")
  
  _app_exit("getCompensationServicePropeties()")
  return retval
  
  
#-------------------------------------------------------------------------------
# updateCompensationService
#
# Parameters
#     compensationServiceId - Configuration ID of the CompensationService to update
#     baseProps - dictionary with base properties to update 
#     customProperties - dictionary with custom properties to update
#-------------------------------------------------------------------------------
def updateCompensationService(compensationServiceId,baseProps=None,customProperties=None):
  _app_entry("updateCompensationService(%s,%s,%s)" , compensationServiceId,baseProps,customProperties)
  retval = None
  try:
    # Use the doUpdateCreate utility function to update the existing
    # CompensationService
    #
    doUpdateCreate("CompensationService",parentId=None,newAttributes=baseProps,parentAttributeName=None,forceCreate=0,
                   updateId=compensationServiceId,customProperties=customProperties,customPropertiesType="Property",customPropertiesAttribute="properties")
  except:
    _app_exception("Unexpected problem in updateCompensationService()")
  
  _app_exit("updateCompensationService(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# createCompensationService
#
# Parameters
#     serverId - Configuration ID of the parent server or template
#     baseProps - dictionary with base properties to update 
#     customProperties - dictionary with custom properties to update
#-------------------------------------------------------------------------------
def createCompensationService(serverId,baseProps,customProperties):
  _app_entry("createCompensationService(%s,%s,%s)" , serverId,baseProps,customProperties)
  retval = None
  try:
    
    # Use the doUpdateCreate utility function to create a new 
    # CompensationService
    retval = doUpdateCreate("CompensationService",parentId=serverId,newAttributes=baseProps,parentAttributeName=None,forceCreate=0,
                   updateId=None,customProperties=customProperties,customPropertiesType="Property",customPropertiesAttribute="properties")
                   
  except:
    _app_exception("Unexpected problem in createCompensationService()")
  
  _app_exit("createCompensationService(retval=%s)" % retval)
  return retval


      
#-------------------------------------------------------------------------------
# getRecoveryLogId
#
# Parameters
#     serverName - name of server
#     nodeName - name of Node - if we're looking for recovery log associated with server
#     clusterName - name of cluster - if we're looking for recovery log associated with cluster template
#     dynamicClusterName - name of dynamic cluster, if looking for recovery log associated with dynamic cluster
#     serverId = None
#
#  Returns:
#    Configuration ID if exists, None or '' if not
#-------------------------------------------------------------------------------
def getRecoveryLogId(serverName=None,nodeName=None,clusterName=None,dynamicClusterName=None,serverId=None):
  _app_entry("getRecoveryLogId(%s,%s,%s,%s,%s)" , serverName,nodeName,clusterName,dynamicClusterName,serverId)
  retval = None
  try:
    
    if (not isEmpty(serverId)):
      serverName = splitOffName(serverId)
      nodeName,clusterName,dynamicClusterName = parseNodeClusterDynamic(serverId)
    
    
    if (not isEmpty(serverName) and not isEmpty(nodeName)):
      # Locate the recovery log in the appropriate ServerIndex ServerEntry
      
      retval = AdminConfig.getid("/Node:%s/ServerIndex:/ServerEntry:%s/RecoveryLog:/" % (nodeName,serverName))
    elif (not isEmpty(clusterName)):
      # Locate the recovery log under the clusters template serverindex
      
      #
      # This is a little tricker than the server logic
      
      # Because of the way listTemplates work, the clusterName is not an exact match, just a startswith
      # We'll need to check for multiple results
      templates = AdminConfig.listTemplates("RecoveryLog","templates/clusters/%s"%clusterName)
      if (not isEmpty(templates)):
        templateList = templates.splitlines()
        if (len(templateList) == 1):
          retval = templateList[0]
        else:
          for templateId in templateList:
            if (templateId.find("%s|" % clusterName) > 0):
              retval = templateId
              break
              
    elif (not isEmpty(dynamicClusterName)):
      # Navigate through the structure of the serverindex.xml
      # file stored under a DynamicCluster definition to locate
      # the RecoveryLog item (if it is defined)

      # Locate the recovery log under dynamic cluster template serverindex
      dcId = AdminConfig.getid("/DynamicCluster:%s" % dynamicClusterName)
      if (not isEmpty(dcId)):
        siId = AdminConfig.list("ServerIndex",dcId)
        if (not isEmpty(siId)):
          seId = AdminConfig.list("ServerEntry",siId)
          if (not isEmpty(seId)):
            retval = AdminConfig.list("RecoveryLog",seId)
      
  except:
    _app_exception("Unexpected problem in getRecoveryLogId()")
  
  _app_exit("getRecoveryLogId(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# getRecoveryLogProperties
#
# Parameters
#   recoveryLogId - Configuration ID of RecoveryLog item
#   appServerProperties - dictionary to add properties to
#   checkSettingsOverride - If the global settings check featuere is disabled,
#                             set this parameter to 1 to override and pull properties anyway
#
# Returns
#   Adds the following properties to the appServerProperties dictionary
#      recoveryLog.prop.XXXX - Base properties of RecoveryLog configuration item
#
#   Returns the dictionary
#-------------------------------------------------------------------------------
def getRecoveryLogProperties(recoveryLogId=None,appServerProperties=None,checkSettingsOverride=0):
  _app_entry("getRecoveryLogProperties(%s,appServerProperties,%d)" ,recoveryLogId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = {}
    
    retval = appServerProperties
    
    # Pull the properties if we are enabled for the precheck feature
    if (checkSettingsOverride or  isCheckSettingsEnabled()):
      
      # Use collectSimpleProperties to pull in the properties
      collectSimpleProperties(appServerProperties, "recoveryLog.prop",recoveryLogId)
        
  except:
    _app_exception("Unexpected problem in getRecoveryLogProperties()")
  
  _app_exit("getRecoveryLogProperties()")
  return retval

#-------------------------------------------------------------------------------
# updateRecoveryLog
#   Apply settings to an existing RecoveryLog configuration item
#
# Parameters
#   recoveryLogId - Confiugration ID to update
#   baseProps - dictionary with properties to apply
#-------------------------------------------------------------------------------
def updateRecoveryLog(recoveryLogId,baseProps):
  _app_entry("updateRecoveryLog(%s,%s)" , recoveryLogId,baseProps)
  retval = None
  try:
    
    # Use the modifyObjectProperties() function from Utils.py to 
    # update the configuration item
    modifyObjectProperties(recoveryLogId,baseProps,configurationType="RecoveryLog")
    
  except:
    _app_exception("Unexpected problem in updateRecoveryLog()")
  
  _app_exit("updateRecoveryLog(retval=%s)" % retval)
  return retval



#-------------------------------------------------------------------------------
# createRecoveryLog
#     Create a new RecoveryLog configuration item
#    
#
# Parameters
#     serverName - name of server
#     recoveryLogProps - dictionary with base properties of RecoveryLog
#     nodeName - name of Node - if we're creating for recovery log associated with server
#     clusterName - name of cluster - if we're creating for recovery log associated with cluster template
#     dynamicClusterName - name of dynamic cluster, if creating for recovery log associated with dynamic cluster
#
#-------------------------------------------------------------------------------
def createRecoveryLog(serverName,recoveryLogProps, nodeName=None, clusterName=None,dynamicClusterName=None):
  _app_entry("createRecoveryLog(%s,%s,%s,%s,%s)" , serverName,recoveryLogProps, nodeName, clusterName,dynamicClusterName)
  retval = None
  parentId = None
  try:
    
    
    # Before we can create the RecoveryLog, we need to locate the ServerEntry item that
    # is its parent configuration item
    
    if (not isEmpty(serverName) and not isEmpty(nodeName)):
      # Locate the appropriate ServerIndex ServerEntry
      
      parentId = AdminConfig.getid("/Node:%s/ServerIndex:/ServerEntry:%s/" % (nodeName,serverName))
    elif (not isEmpty(clusterName)):
      
      # Locate the recovery log under the clusters template serverindex
      
      
      # Because of the way listTemplates work, the clusterName is not an exact match, just a startswith
      # We'll need to check for multiple results
      templates = AdminConfig.listTemplates("ServerEntry","templates/clusters/%s"%clusterName)
      if (not isEmpty(templates)):
        templateList = templates.splitlines()
        if (len(templateList) == 1):
          parentId = templateList[0]
        else:
          for templateId in templateList:
            if (templateId.find("%s|" % clusterName) > 0):
              parentId = templateId
              break
              
    elif (not isEmpty(dynamicClusterName)):
      # Locate the recovery log under dynamic cluster template serverindex
      
      
      dcId = AdminConfig.getid("/DynamicCluster:%s" % dynamicClusterName)
      if (not isEmpty(dcId)):
        siId = AdminConfig.list("ServerIndex",dcId)
        if (not isEmpty(siId)):
          parentId = AdminConfig.list("ServerEntry",siId)
    
    if (isEmpty(parentId)):
      raise StandardError("Unable to find parent ServerEntry to create RecoveryLog")
    
    
    # Having found the parent, create the recovery Log
    
    # Use the doUpdateCreate function from Utils.py to create the RecoveryLog    
    retval = doUpdateCreate("RecoveryLog",parentId,recoveryLogProps,parentAttributeName="recoveryLog",forceCreate=0)
    
  except:
    _app_exception("Unexpected problem in createRecoveryLog()")
  
  _app_exit("createRecoveryLog(retval=%s)" % retval)
  return retval

#------------------------------------------------------------------------------------------
# Parameters

#    serverId - (Optional) Server/template parent
#    appServerProperties - dictionary to add results to, may be null
#    checkSettingsOverride - If the global settings check featuere is disabled,
#                             set this parameter to 1 to override and pull properties anyway
#
#    Adds the following properties to the input dictionary
#         sibService.prop.XXXX - base properties of CompensationService
#         sibSerivce.customProperties.prop.XXX - custom properties
#         sibService.CONFIG_ID - Configuration ID of sib service
#-------------------------------------------------------------------------------
def getSIBServiceProperties(serverId=None,appServerProperties=None,checkSettingsOverride=0):
  _app_entry("getSIBServiceProperties(%s,appServerProperties,%d)" ,serverId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = {}
    
    retval = appServerProperties
    
    # Pull the properties if we are enabled for the precheck feature
    if (checkSettingsOverride or  isCheckSettingsEnabled()):
      sibService = AdminConfig.list("SIBService",serverId)
      if (not isEmpty(sibService)):
        # Use collectSimpleProperties to pull in the properties
        collectSimpleProperties(appServerProperties, "sibService.prop",sibService,collectPropertyAttributes=1)
        appServerProperties["sibService.CONFIG_ID"] = sibService
        
  except:
    _app_exception("Unexpected problem in getSIBServiceProperties()")
  
  _app_exit("getSIBServiceProperties()")
  return retval

#-------------------------------------------------------------------------------
# updateSIBService
#
# Parameters
#     sibServiceId - Configuration ID of SIBService (optional)
#     serverId - Configuraiton ID of parent (optional)
#     serviceProps - base properties to update
#     customProps - custom properties to update
#-------------------------------------------------------------------------------
def updateSIBService(sibServiceId=None,serverId=None,serviceProps=None,customProps=None):
  _app_entry("updateSIBService(%s,%s,%s,%s)" , sibServiceId,serverId,serviceProps,customProps)
  retval = None
  try:
    retval = doUpdateCreate("SIBService",parentId=serverId,newAttributes=serviceProps,parentAttributeName=None,updateId=sibServiceId,
                            customProperties=customProps,customPropertiesType="Property",customPropertiesAttribute="properties")
  except:
    _app_exception("Unexpected problem in updateSIBService()")
  
  _app_exit("updateSIBService(retval=%s)" % retval)
  return retval


#------------------------------------------------------------------------------------------
# Parameters

#    serverId - (Optional) Server/template parent
#    appServerProperties - dictionary to add results to, may be null
#    checkSettingsOverride - If the global settings check featuere is disabled,
#                             set this parameter to 1 to override and pull properties anyway
#
#    Adds the following properties to the input dictionary
#         activitySession.prop.XXXX - base properties of CompensationService
#         activitySession.customProperties.prop.XXX - custom properties
#         activitySession.CONFIG_ID - Configuration ID of sib service
#-------------------------------------------------------------------------------
def getActivitySessionServiceProperties(serverId=None,appServerProperties=None,checkSettingsOverride=0):
  _app_entry("getActivitySessionServiceProperties(%s,appServerProperties,%d)" ,serverId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = {}
    
    retval = appServerProperties
    
    # Pull the properties if we are enabled for the precheck feature
    if (checkSettingsOverride or  isCheckSettingsEnabled()):
      activitySessionService = AdminConfig.list("ActivitySessionService",serverId)
      if (not isEmpty(activitySessionService)):
        # Use collectSimpleProperties to pull in the properties
        collectSimpleProperties(appServerProperties, "activitySessionService.prop",activitySessionService,collectPropertyAttributes=1)
        appServerProperties["activitySessionService.CONFIG_ID"] = activitySessionService
        
  except:
    _app_exception("Unexpected problem in getActivitySessionServiceProperties()")
  
  _app_exit("getActivitySessionServiceProperties()")
  return retval

#-------------------------------------------------------------------------------
# updateActivitySessionService
#
# Parameters
#     activitySessionServiceId - Configuration ID of ActivitySessionService (optional)
#     serverId - Configuraiton ID of parent (optional)
#     serviceProps - base properties to update
#     customProps - custom properties to update
#-------------------------------------------------------------------------------
def updateActivitySessionService(activitySessionServiceId=None,serverId=None,serviceProps=None,customProps=None):
  _app_entry("updateActivitySessionService(%s,%s,%s,%s)" , activitySessionServiceId,serverId,serviceProps,customProps)
  retval = None
  try:
    retval = doUpdateCreate("ActivitySessionService",parentId=serverId,newAttributes=serviceProps,parentAttributeName=None,updateId=activitySessionServiceId,
                            customProperties=customProps,customPropertiesType="Property",customPropertiesAttribute="properties")
  except:
    _app_exception("Unexpected problem in updateActivitySessionService()")
  
  _app_exit("updateActivitySessionService(retval=%s)" % retval)
  return retval

#------------------------------------------------------------------------------------------
# Parameters

#    serverId - (Optional) Server/template parent
#    appServerProperties - dictionary to add results to, may be null
#    checkSettingsOverride - If the global settings check featuere is disabled,
#                             set this parameter to 1 to override and pull properties anyway
#
#    Adds the following properties to the input dictionary
#         i18NService.prop.XXXX - base properties of CompensationService
#         i18NService.customProperties.prop.XXX - custom properties
#         i18NService.CONFIG_ID - Configuration ID of sib service
#-------------------------------------------------------------------------------
def getI18NServiceProperties(serverId=None,appServerProperties=None,checkSettingsOverride=0):
  _app_entry("getI18NServiceProperties(%s,appServerProperties,%d)" ,serverId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = {}
    
    retval = appServerProperties
    
    # Pull the properties if we are enabled for the precheck feature
    if (checkSettingsOverride or  isCheckSettingsEnabled()):
      i18NService = AdminConfig.list("I18NService",serverId)
      if (not isEmpty(i18NService)):
        # Use collectSimpleProperties to pull in the properties
        collectSimpleProperties(appServerProperties, "i18NService.prop",i18NService,collectPropertyAttributes=1)
        appServerProperties["i18NService.CONFIG_ID"] = i18NService
        
  except:
    _app_exception("Unexpected problem in getI18NServiceProperties()")
  
  _app_exit("getI18NServiceProperties()")
  return retval

#-------------------------------------------------------------------------------
# updateI18NService
#
# Parameters
#     i18NServiceId - Configuration ID of I18NService (optional)
#     serverId - Configuraiton ID of parent (optional)
#     serviceProps - base properties to update
#     customProps - custom properties to update
#-------------------------------------------------------------------------------
def updateI18NService(i18NServiceId=None,serverId=None,serviceProps=None,customProps=None):
  _app_entry("updateI18NService(%s,%s,%s,%s)" , i18NServiceId,serverId,serviceProps,customProps)
  retval = None
  try:
    retval = doUpdateCreate("I18NService",parentId=serverId,newAttributes=serviceProps,parentAttributeName=None,updateId=i18NServiceId,
                            customProperties=customProps,customPropertiesType="Property",customPropertiesAttribute="properties")
  except:
    _app_exception("Unexpected problem in updateI18NService()")
  
  _app_exit("updateI18NService(retval=%s)" % retval)
  return retval



#------------------------------------------------------------------------------------------
# Parameters

#    serverId - (Optional) Server/template parent
#    appServerProperties - dictionary to add results to, may be null
#    checkSettingsOverride - If the global settings check featuere is disabled,
#                             set this parameter to 1 to override and pull properties anyway
#
#    Adds the following properties to the input dictionary
#         sibService.prop.XXXX - base properties of CompensationService
#         sibSerivce.customProperties.prop.XXX - custom properties
#         sibService.CONFIG_ID - Configuration ID of sib service
#-------------------------------------------------------------------------------
def getApplicationProfileServiceProperties(serverId=None,appServerProperties=None,checkSettingsOverride=0):
  _app_entry("getApplicationProfileServiceProperties(%s,appServerProperties,%d)" ,serverId,checkSettingsOverride)
  retval = None
  try:
    if (appServerProperties == None):
      appServerProperties = {}
    
    retval = appServerProperties
    
    # Pull the properties if we are enabled for the precheck feature
    if (checkSettingsOverride or  isCheckSettingsEnabled()):
      applicationProfileService = AdminConfig.list("ApplicationProfileService",serverId)
      if (not isEmpty(applicationProfileService)):
        # Use collectSimpleProperties to pull in the properties
        collectSimpleProperties(appServerProperties, "applicationProfileService.prop",applicationProfileService,collectPropertyAttributes=1)
        appServerProperties["ApplicationProfileService.CONFIG_ID"] = applicationProfileService
        
  except:
    _app_exception("Unexpected problem in getApplicationProfileServiceProperties()")
  
  _app_exit("getApplicationProfileServiceProperties()")
  return retval

#-------------------------------------------------------------------------------
# updateApplicationProfileService
#
# Parameters
#     ApplicationProfileServiceId - Configuration ID of ApplicationProfileService (optional)
#     serverId - Configuraiton ID of parent (optional)
#     serviceProps - base properties to update
#     customProps - custom properties to update
#-------------------------------------------------------------------------------
def updateApplicationProfileService(applicationProfileServiceId=None,serverId=None,serviceProps=None,customProps=None):
  _app_entry("updateApplicationProfileService(%s,%s,%s,%s)" , applicationProfileServiceId,serverId,serviceProps,customProps)
  retval = None
  try:
    retval = doUpdateCreate("ApplicationProfileService",parentId=serverId,newAttributes=serviceProps,parentAttributeName=None,updateId=applicationProfileServiceId,
                            customProperties=customProps,customPropertiesType="Property",customPropertiesAttribute="properties")
  except:
    _app_exception("Unexpected problem in updateApplicationProfileService()")
  
  _app_exit("updateApplicationProfileService(retval=%s)" % retval)
  return retval







#########################################################################
# getApplicationServerInfo
# 
# Returns a property set representation of an existing application server
# If the force flag is 0, some of the settings will not be loaded.  The 
# appserver.delayedLoad property is added to signal that this has occurred.
##########################################################################
def getApplicationServerInfo(server,force=0):
  
  try:
      SEPARATOR=progInfo["line.separator"]

      _app_trace("getApplicationServerInfo(%s,%d)" % (server,force),"entry")
      appServerProperties={}
      
      
      if (force == 0):
          appServerProperties["appserver.delayedLoad"] = "true"
      else:
          appServerProperties["appserver.delayedLoad"] = "false"
      
      if (force):
        getApplicationServerComponentProperties(server, appServerProperties,1)

      # Thread Pool properties
      # Removed since this was needed only for v6.0
      #tp = AdminConfig.list("ThreadPool", AdminConfig.list("WebContainer",server))

      #if ( tp != "" ):
      # 
      # appServerProperties.put("appserver.webContainer.threadPool.prop.inactivityTimeout" , AdminConfig.showAttribute(tp,"inactivityTimeout"))
      # appServerProperties.put("appserver.webContainer.threadPool.prop.isGrowable" , AdminConfig.showAttribute(tp,"isGrowable"))
      # appServerProperties.put("appserver.webContainer.threadPool.prop.minimumSize" , AdminConfig.showAttribute(tp,"minimumSize"))
        

      # @JJM - Dump classloaders/shared libraries
      # This is deferred unless we do a force
      if (force):
          getClassloaderProperties(server,appServerProperties)

      # @JJM - Dump all thread pools
      # Thread pool load is deferred unless force flag is on
      if (force):
          getThreadPoolProperties(server,appServerProperties,1)       
              
          
      # @JJM Session properties
      # Session properties are deferred until needed unless force flag is on
      if (force):
          getSessionManagementProperties(server, appServerProperties,1)
      
      # Listener port 
      # These properties are deferred until needed unless force flag is on
      if (force):
          getMessageListenerServiceProperties(server,appServerProperties)
          
          
      # Log Properties
      if (force):
        getStreamRedirectProperties(server,appServerProperties,1)
        
        
        
      # @JJM - Trace service
      if (force):
          getTraceServiceProperties(server,appServerProperties,1)
      
      # @JJM - RasLoggingService activity log
      if (force):
          getRASLoggingServiceProperties(server,appServerProperties,1)
      
      if (force):
        getHPELoggingServiceProperties(server,appServerProperties,1)
    
      if (force):
        getHTTPAccessLoggingServiceProperties(server,appServerProperties,1)    
        
      # PMI Settings - Basic enablement only
      if (force):
        getPMISettings(server, appServerProperties,1)
          
      
      # Monitoringpolicy
      if (force):
        getMonitoringPolicyProperties(server, appServerProperties,1)
        
        
      # @JJM Working directory
      if (force):
        getWorkingDirectoryProperties(server, None, appServerProperties,1)
      
      
      if (force):
        getIoRedirectProperties(server,None,appServerProperties,checkSettingsOverride=1)
      
      # @JJM Environment properties
      if (force):
          getProcessEnvironmentProperties(server,appServerProperties,1)

      # ORB settings
      if (force):
        getORBServiceProperties(server, appServerProperties,1)
        
      if (force):
        getEJBContainerProperties(server, appServerProperties,checkSettingsOverride=1)
      
      if (force):
        getJavaPersistenceAPIServiceProperties(server,appServerProperties,checkSettingsOverride=1)
        
      if (force):
        getDynamicCacheServiceProperties(server,appServerProperties,checkSettingsOverride=1)
        
      # JavaVirtualMachine is deferred until needed unless force flag is on
      if (force):
          getJavaVirtualMachineProperties(server,appServerProperties)

      # ProcessExecution 
      if (force):
        getProcessExcecutionSettings(server, appServerProperties,1)
      
      
      # @JJM-TransactionService
      if (force):
          getTransactionServiceProperties(server,appServerProperties,1)

      # Webserver Plugin Settings
      if (force):
          getWebServerPluginProperties(server,appServerProperties,1)
      

      # StartupBeansService
      if (force):
        getStartBeanServiceProperties(server, appServerProperties)
      
      # Custom Service properties
      if (force):
          getCustomServiceProperties(server, appServerProperties)
      
      # HA Manager Service    
      if (force):
          getHAManagerServiceProperties(server, appServerProperties,1)
      
      # WebContainer settings
      if (force):
          getWebContainerProperties(server, appServerProperties,1)
          
      if (force):
          getPortletContainerProperties(server,appServerProperties,1)
      
      if (force):
          getSIPContainerProperties(server,appServerProperties,1)
      
      if (force):
        getAdminServicesProperties(server,appServerProperties,1,None)
      
      if (force):
        getWorkAreaServiceProperties(serverId=server,appServerProperties=appServerProperties,checkSettingsOverride=1)
      
      if (force):
        getWorkAreaPartitionServiceProperties(serverId=server,appServerProperties=appServerProperties,checkSettingsOverride=1)
          
      if (force):
        getCEASettingsProperties(parentId=server,ceaSettingsId=None,appServerProperties=appServerProperties,checkSettingsOverride=1)
      
      if (force):
        getCompensationServiceProperties(serverId=server,appServerProperties=appServerProperties,checkSettingsOverride=1)
        
      if (force):
        recoveryLogId = getRecoveryLogId(serverId=server)
        if (not isEmpty(recoveryLogId)):
          getRecoveryLogProperties(recoveryLogId,appServerProperties=appServerProperties,checkSettingsOverride=1)
      
      _app_trace("getApplicationServerInfo(%d properties)" % len(appServerProperties),"exit")
  except:
      _app_trace("Unexpected error in getApplicationServerInfo()","exception")
      raise StandardError("Unexpected error in getApplicationServerInfo()")
      
  return appServerProperties
