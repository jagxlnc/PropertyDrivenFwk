################################################################################
# ReplicationDomain.py
#
# This method contains utility methods for creating, updating, finding, and
# getting the properties of a DataReplicationDomain.
################################################################################


#-------------------------------------------------------------------------
# createReplicationDomain
#
# Parameters:
#    domainName - Name of domain to create
#    defaultDataReplicationSettings - dictionary or Properties set with key/value
#                               pairs of  DataReplication settings.
# 
# Returns: ID of the new replication domain
#-------------------------------------------------------------------------
def createReplicationDomain(domainName, defaultDataReplicationSettings):

		retval = None
		_app_trace("createReplicationDomain(%s,%s)" % (domainName, defaultDataReplicationSettings), "entry")
		try:
			attrs = [ ["name", domainName] ]
			defaultAttrs = []
			if (defaultDataReplicationSettings != None):
				defaultAttrs = []
				for key in defaultDataReplicationSettings.keys():
						val = defaultDataReplicationSettings.get(key)
						defaultAttrs.append([key,val])
				
				if (len(defaultAttrs) > 0):
						attrs.append(["defaultDataReplicationSettings", defaultAttrs])
				
			cellId = None
			cells = wsadminToList(AdminConfig.list("Cell"))
			cellId = cells[0]
			
			_app_trace("About to call AdminConfig.create(DataReplicationDomain, %s, %s)" % (cellId, attrs))
			retval = AdminConfig.create("DataReplicationDomain",cellId, attrs)
		except:
			_app_trace("Error creating a replication domain","exception")
			retval = None
		
		_app_trace("createReplicationDomain(retval = %s)" % retval, "exit")
		return retval

#-------------------------------------------------------------------------
# updateReplicationDomain
#
# Parameters:
#    domainName - Name of domain to update
#    domainId - ID of the domain, if None will look it up
#    defaultDataReplicationSettings - dictionary or Properties set with key/value
#                               pairs of  DataReplication settings.
# 
# Returns: ID of the updated replication domain
#-------------------------------------------------------------------------
def updateReplicationDomain(domainName, domainId,defaultDataReplicationSettings):

		retval = None
		_app_trace("updateReplicationDomain(%s,%s,%s)" % (domainName, domainId,defaultDataReplicationSettings), "entry")
		try:
			if (domainId == None):
					domainId = findReplicationDomain(domainName)
					if (isEmpty(domainId)):
							raise StandardError("ReplicationDomain %s does not exist" % domainName)
							
			attrs = [ ]
			defaultAttrs = []
			dataSettingsId = AdminConfig.showAttribute(domainId,"defaultDataReplicationSettings")
			if (isEmpty(dataSettingsId)):
					dataSettingsId = AdminConfig.create("DataReplication",domainId,[])
			
			if (defaultDataReplicationSettings != None):
				defaultAttrs = []
				for key in defaultDataReplicationSettings.keys():
						val = defaultDataReplicationSettings.get(key)
						defaultAttrs.append([key,val])
				
				if (len(defaultAttrs) > 0):
						# Now we update the default DataReplicationSettings
						if (modifyObject(dataSettingsId, defaultAttrs)):
								raise StandardError("Error updating defaultDataReplicationSettings")
			
			retval = domainId
			
		except:
			_app_trace("Error updating a replication domain","exception")
			retval = None
		
		_app_trace("updateReplicationDomain(retval = %s)" % retval, "exit")
		return retval

#-------------------------------------------------------------------------
# findReplicationDomain
#
# Returns the configuration ID of the domain if it exists. Empty string is
# returned if no such domain exists. 
#-------------------------------------------------------------------------
def findReplicationDomain(domainName):
		
		_app_trace("findReplicationDomain(%s)" %(domainName),"entry")
		
		repId = None
		
		try:
			repId = AdminConfig.getid("/DataReplicationDomain:%s/" % domainName)
		except:
			_app_trace("Error getting domain ID","exception")
			repId = "ERROR"
		
		_app_trace("findReplicationDomain(retval = %s)" %(repId),"exit")
		
		if (repId == "ERROR"):
				raise StandardError("Problem looking for DataReplicationDomain")
				
		return repId	
		
#-------------------------------------------------------------------------
# getReplicationDomainProperties
#-------------------------------------------------------------------------
def getReplicationDomainProperties(domainId):

		_app_trace("getReplicationDomainProperties(%s)" % (domainId),"entry")
		retval = java.util.Properties()
		try:
				retval.put("replicationDomain.name", AdminConfig.showAttribute(domainId,"name"))
				ddrs = AdminConfig.showAttribute(domainId,"defaultDataReplicationSettings")
				if (not isEmpty(ddrs)):
						collectSimpleProperties(retval, "replicationDomain.defaultDataReplicationSettings.prop", ddrs, ["name"])
		except:
				_app_trace("Error getting properties for replication domain","exception")
				retval = None

		_app_trace("getReplicationDomainProperties()","exit")
		return retval
		