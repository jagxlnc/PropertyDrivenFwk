################################################################################
# ProcessResourceEnvironment.py - this module supports the processing of input
# properties for defining or updating ResourceEnvironmentProvider and 
# ResourceEnvEntry.py property files.
#
# Required modules: ResourceEnvironment.py Utils.py common.py
# Module Entry Point: processResourceEnvironment()
# 
#-------------------------------------------------------------------------------
# Property Example:
#
# app.resourceEnvProvider.1.cluster = SampleCluster
# app.resourceEnvProvider.1.node = 
# app.resourceEnvProvider.1.server = 
# app.resourceEnvProvider.1.name = MyOtherResourceEnvironmentProvider
# app.resourceEnvProvider.1.prop.classpath = 
# app.resourceEnvProvider.1.prop.isolatedClassLoader = false
# app.resourceEnvProvider.1.prop.nativepath = 
# app.resourceEnvProvider.1.propertySet.resourceProperties.prop.ResourceProviderProperty1 = java.lang.String|false|Value1|Description1
# app.resourceEnvProvider.1.propertySet.resourceProperties.prop.ResourceProviderProperty2 = java.lang.Boolean|false|true|Description 2
# app.resourceEnvProvider.1.referenceables.1.type = Referenceable
# app.resourceEnvProvider.1.referenceables.1.prop.classname = com.ibm.issw.jjm.MyOtherResource
# app.resourceEnvProvider.1.referenceables.1.prop.factoryClassname = com.ibm.issw.jjm.MyOtherResourceFactory
# app.resourceEnvProvider.1.referenceables.2.prop.classname = com.ibm.issw.jjm.MyResource
# app.resourceEnvProvider.1.referenceables.2.prop.factoryClassname = com.ibm.issw.jjm.MyResourceFactory
# app.resourceEnvProvider.1.referenceables.count = 2
# # ResourceEnvEntry settings
# app.resourceEnvProvider.1.entries.1.name = MyResource2
# app.resourceEnvProvider.1.entries.1.prop.jndiName = resources/MyOtherResource2
# app.resourceEnvProvider.1.entries.1.propertySet.resourceProperties.prop.ResourceProp1 = java.lang.String|false|100
# app.resourceEnvProvider.1.entries.1.propertySet.resourceProperties.prop.ResourceProp2 = java.lang.Boolean|false|true
# app.resourceEnvProvider.1.entries.1.propertySet.resourceProperties.prop.ResourceProp3 = java.lang.Boolean|false|false|New property
# app.resourceEnvProvider.1.entries.1.referenceable.type = Referenceable
# app.resourceEnvProvider.1.entries.1.referenceable.prop.classname = com.ibm.issw.jjm.managedobject.MyResource
# app.resourceEnvProvider.1.entries.1.referenceable.prop.factoryClassname = com.ibm.issw.jjm.factories.MyResourceFactory
# 
# app.resourceEnvProvider.1.entries.count = 1
# app.resourceEnvProvider.count = 1
#
# Note about ResourceEnvEntry referenceable settings:
# The entries referenceable settings are used to find the correspond configuration ID of 
# the Referenceables declared under the provider. If no match is found, a new Referenceable
# entry will be created
################################################################################

#-------------------------------------------------------------------------------
# referenceablesPropsToTupleList
# 
# Local utility method that will parse the properties that represent a list of
# Referenceable definitions and turn it into a list of (classname,factoryClassname)
# tuples for easier searching and comparison
#
# Parameters: 
#   refInfo - dictionary with settings to parse
#   prefix - prefix to use with property keys
#
# Returns:
#   list of (classname,factoryClassname)
#-------------------------------------------------------------------------------
def referenceablesPropsToTupleList(refInfo,prefix):
  retval = []
  try:
    refCount = int(refInfo.get("%s.referenceables.count" % prefix,0))
    if (refCount > 0):
      for idx in range(1,refCount+1):
        classname = refInfo.get("%s.referenceables.%d.prop.classname" % (prefix,idx),"")
        factoryClassname = refInfo.get("%s.referenceables.%d.prop.factoryClassname" % (prefix,idx),"")
        retval.append((classname,factoryClassname))
  except:
    _app_exception("Unexpected problem in referenceablesToTupleList")
  return retval


#-------------------------------------------------------------------------------
# processResourceEnvironmentEntry - processes the input settings for a single
#   ResourceEnvEntry configuration
#
# Parameters:
#     resourceInfo - input dictionary
#     entryName - name of ResourceEnvEntry
#     entryPrefix - prefix to use for keys into resourceInfo dictionary
#     providerName - Name of ResourceEnvironmentProvider that is parent configuration item
#     providerId - Configuration ID of ResourceEnvironmentProvider that is parent configuration item
#     pCluster,pNode,pServer - Scope settings of provider
#     scopeString - descriptive scope string used for logging
#     newProvider - flag used to indicate if provider was just created (1) or pre-existing (0)
#
#-------------------------------------------------------------------------------
def processResourceEnvironmentEntry(resourceInfo,entryName, entryPrefix, providerName,providerId,pCluster,pNode,pServer,scopeString,newProvider=0):
  _app_entry("processResourceEnvironmentEntry(resourceInfo,%s,%s,%s,%s,%s,%s,%s,%s,%d)" , entryName, entryPrefix, providerName,providerId,pCluster,pNode,pServer,scopeString,newProvider)
  retval = None
  try:
    entryId = None
    if (not newProvider):
      # try to find the entry
      entryId = findResourceEnvEntryAtScope(providerName,entryName,pCluster,pNode,pServer)
      
    
    if (not isEmpty(entryId)):
      existingProps = getResourceEnvEntryProperties(entryId)
      
      baseProps = getPropListDifferences(resourceInfo,entryPrefix,existingProps,"resourceEnvEntry")
      resourceProps = getPropListDifferences(resourceInfo,"%s.propertySet.resourceProperties"%entryPrefix,existingProps,"resourceEnvEntry.propertySet.resourceProperties")
      refProps = getPropListDifferences(resourceInfo,"%s.referenceable" % entryPrefix,existingProps,"resourceEnvEntry.referenceable")
      
      if (len(baseProps) > 0 or len(resourceProps) > 0 or len(refProps) > 0):
        classname = None
        factoryClassname = None
        
        # Make sure we have proper values for classname and factoryClassname
        if (len(refProps)> 0):
          classname = refProps.get("classname")
          if (isEmpty(classname)):
            classname = existingProps.get("resourceEnvEntry.referenceable.prop.classname")
          factoryClassname = refProps.get("factoryClassname")
          if (isEmpty(factoryClassname)):
            factoryClassname = existingProps.get("resourceEnvEntry.referenceagble.prop.factoryClassname")
        
        updateResourceEnvEntry(entryId,providerId,baseProps,resourceProps,classname,factoryClassname)
        
        _app_message("ResourceEnvEntry %s has been updated in provider %s at scope %s" % (entryName,providerName,scopeString))
      else:
        _app_message("No need to update ResourceEnvEntry %s in provider %s at scope %s" % (entryName,providerName,scopeString))
    else:
      
      baseProps = getPropList(resourceInfo,entryPrefix)
      resourceProps = getPropList(resourceInfo,"%s.propertySet.resourceProperties"%entryPrefix)
      refProps = getPropList(resourceInfo,"%s.referenceable" % entryPrefix)
      entryId = createResourceEnvEntry(providerId,entryName,baseProps,resourceProps,refProps["classname"],refProps["factoryClassname"])
      
      _app_message("ResourceEnvEntry %s has been created in provider %s at scope %s" % (entryName,providerName,scopeString))
  except:
    _app_exception("Unexpected problem in processResourceEnvironmentEntry()")
  
  _app_exit("processResourceEnvironmentEntry(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# processResourceEnvironmentEntries - Process all of the ResourceEnvEntry input properties
#   found under a specific provider
#
# Parameters
#     resourceInfo - input dictionary
#     providerName - Name of ResourceEnvironmentProvider that is parent configuration item
#     providerId - Configuration ID of ResourceEnvironmentProvider that is parent configuration item
#     providerPrefix - Property key prefix for provider
#     pCluster,pNode,pServer - Scope settings of provider
#     scopeString - descriptive scope string used for logging
#     newProvider - flag used to indicate if provider was just created (1) or pre-existing (0)
#-------------------------------------------------------------------------------
def processResourceEnvironmentEntries(resourceInfo,providerName,providerId,providerPrefix,pCluster,pNode,pServer,scopeString,newProvider=0):
  _app_entry("processResourceEnvironmentEntries(resourceInfo,%s,%s,%s,%s,%s,%s,%s,%d)" , providerName,providerId,providerPrefix,pCluster,pNode,pServer,scopeString,newProvider)
  retval = None
  try:
    entryCount = int(resourceInfo.get("%s.entries.count" % providerPrefix,0))
    if (entryCount > 0):
      for idx in range(1,entryCount+1):
        entryPrefix = "%s.entries.%d" % (providerPrefix,idx)
        
        entryName = resourceInfo.get("%s.name" % entryPrefix)
        if (isEmpty(entryName)):
          #partial list
          continue
          
        processResourceEnvironmentEntry(resourceInfo,entryName, entryPrefix, providerName,providerId,pCluster,pNode,pServer,scopeString,newProvider=newProvider)
          
  except:
    _app_exception("Unexpected problem in processResourceEnvironmentEntries()")
  
  _app_exit("processResourceEnvironmentEntries(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# processResourceEnvironmentProvider - Process the definition of a single resource
#   environment provider and then the entries defined under it
#  
#
# Parameters
#     resourceInfo - input dictionary
#     pName - Name of ResourceEnvironmentProvider that is parent configuration item
#     pCluster,pNode,pServer - Scope settings of provider
#     scopeString - descriptive scope string used for logging
#     prefix - Property key prefix for provider
#-------------------------------------------------------------------------------
def processResourceEnvironmentProvider(resourceInfo,pName,pCluster,pNode,pServer,prefix):
  _app_entry("processResourceEnvironmentProvider(resourceInfo,%s,%s,%s,%s,%s)" , pName,pCluster,pNode,pServer,prefix)
  retval = None
  try:
    # See if the provider exists
    scopeString = scopeInfoString(pCluster, pNode, pServer)
    providerId = findResourceEnvironmentProviderAtScope(pName,pCluster,pNode,pServer)
    
    if (isEmpty(providerId)):
      # Need to create
      baseProps = getPropList(resourceInfo,prefix)
      resourceProps = getPropList(resourceInfo,"%s.propertySet.resourceProperties" %prefix)
      referenceables = referenceablesPropsToTupleList(resourceInfo,prefix)
      
      parentObject = getScopeId(pCluster, pNode, pServer)
      
      if (isEmpty(parentObject)):
        raise StandardError("Unable to find parent configuration item for ResourceEnvironmentEntry %s at scope %s" % (pName,scopeString))
      
      retval = createResourceEnvironmentProvider(parentObject,pName,baseProps,resourceProps,referenceables)
      _app_message("Provider %s has been created at scope %s" % (pName,scopeString))
      
      providerId = retval
      
      processResourceEnvironmentEntries(resourceInfo,providerName=pName,providerId=retval,providerPrefix=prefix,
                                        pCluster=pCluster,pNode=pNode,pServer=pServer,scopeString=scopeString,newProvider=1)
      
    else:
      _app_message("Provider %s exists" % pName)
      retval = providerId
      existingProps = getResourceEnvironmentProviderProperties(providerId)
      baseProps = getPropListDifferences(resourceInfo,prefix,existingProps,"resourceEnvProvider")
      resourceProps = getPropListDifferences(resourceInfo,"%s.propertySet.resourceProperties" %prefix,existingProps,"resourceEnvProvider.propertySet.resourceProperties")
      
      inputReferenceables = referenceablesPropsToTupleList(resourceInfo,prefix)
      existingReferenceables = referenceablesPropsToTupleList(existingProps,"resourceEnvProvider")
      changeReferenceables = []
      for ref in inputReferenceables:
        if ref not in existingReferenceables:
          changeReferenceables.append(ref)
      
      if (len(baseProps) > 0 or len(resourceProps) > 0 or len(changeReferenceables) > 0):
        updateResourceEnvironmentProvider(providerId,baseProps,resourceProps,referenceables=changeReferenceables)
        _app_message("Provider %s has been modified at scope %s" % (pName,scopeString))
      else:
        _app_message("No need to update ResourceEnvironmentProvider %s at scope %s" % (pName,scopeString))

      processResourceEnvironmentEntries(resourceInfo,providerName=pName,providerId=providerId,providerPrefix=prefix,
                                        pCluster=pCluster,pNode=pNode,pServer=pServer,scopeString=scopeString,newProvider=0)

  except:
    _app_exception("Unexpected problem in processResourceEnvironmentProvider()")
  
  _app_exit("processResourceEnvironmentProvider(retval=%s)" % retval)
  return retval



#---------------------------------------------------------------------------------
# processResourceEnvironment
#
#   Primary entry point for this module
#
# Parameters
#     resourceInfo - input dictionary
#---------------------------------------------------------------------------------
def processResourceEnvironment(resourceInfo):
  _app_entry("processResourceEnvironment(resourceInfo)")
  retval = None
  try:
      repCount = int(resourceInfo.get("app.resourceEnvProvider.count",0))
      if (repCount > 0):
        for idx in range(1,repCount+1):
          prefix = "app.resourceEnvProvider.%d" % idx
          
          pCluster = resourceInfo.get("%s.cluster" % prefix)
          pNode = resourceInfo.get("%s.node" % prefix)
          pServer = resourceInfo.get("%s.server" % prefix)
          
          pName = resourceInfo.get("%s.name" % prefix)
          
          if (isEmpty(pName)):
            # Partial list
            continue
            
          processResourceEnvironmentProvider(resourceInfo,pName,pCluster,pNode,pServer,prefix)
          
  except:
    _app_exception("Unexpected problem in processResourceEnvironment()")
  
  _app_exit("processResourceEnvironment(retval=%s)" % retval)
  return retval