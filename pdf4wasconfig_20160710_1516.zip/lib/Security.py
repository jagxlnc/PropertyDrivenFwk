##########################################################################################
# Security.py
#
# This module contains utility methods for getting and updating some basic Security settings.
# It is not a comprehensive set of security functions and the user is reminded that in more
# complex configurations, custom wsadmin scripts may be more suitable for setting up security.
#
# Related modules:
#			ProcessSecurity.py : Reads property file format and calls functions in this module
#			Utils.py: utility functions
#
# Entry point functions:
#
#		updateSecurityProperties(securityProps, customProperties, securityDomainName)
#		getSecurityProperties(securityDomainName=None)
#		getKeyStoreId(name, scopeName, scopeType, securityDomainName=None)
#		getKeyStoreProperties(keystoreId)
#		modifyKeyStore(keyStoreName, scopeName, keyStoreProperties)
#
##########################################################################################

#-------------------------------------------------------------------------------------------
# updateSecurityProperties
#
# This function will update basic security properties in the global security settings or
# in the basic settings for a security domain. Corresponds to simple settings in the Security
# or AppSecurity configurations and the custom properties for those configuration components.
#
# Parameters:
#			securityProps: key/value pairs for basic security properties
#			customPropererties: key/value pairs for security custom properties
#			securityDomainName: V7+ only - Specifies the security domain to be updated.
#
# Returns: Nothing, StandardError will be raised if problems occur.
#-------------------------------------------------------------------------------------------
def updateSecurityProperties(securityProps, customProperties = None, securityDomainName=None):
	_app_trace("updateSecurityProperties(%s,%s,%s)"% (securityProps, customProperties, securityDomainName),"entry")
	global progInfo
	
	try:
		if (not isEmpty(securityDomainName)):
			configId = appsecurity =AdminConfig.getid("/SecurityDomain:%s/AppSecurity:/" % securityDomainName)
			if (isEmpty(configId)):
				raise StandardError("Unable to load configuration ID for security domain %s" % securityDomainName)
		else:
			configId = AdminConfig.list("Security").split(progInfo["line.separator"])[0]
		
		attrs = []
		for key in securityProps.keys():
			val = securityProps.get(key)
			attrs.append([key,val])
		
		if (modifyObject(configId, attrs)):
			raise StandardError("Problem updating security settings")
		
		if (customProperties != None and len(customProperties) > 0):
			errmsg = updateCustomProperties(configId, "properties", "Property", customProperties)
			if not isEmpty(errmsg):
				raise StandardError("Problem updating custom properties: %s" % errmsg)
				
	except:
		_app_trace("Unexpected error in updateSecurityProperties","exception")
		raise StandardError("Unexpected error in updateSecurityProperties")
			
	_app_trace("updateSecurityProperties()","exit")
	
#--------------------------------------------------------------------------------
# getSecurityProperties
# 
# Returns a property set with basic security properties and custom properties
#
# Parameters:
#    securityDomainName: If None, global security settings are returned, otherwise
#                        the settings for the security domain are returned
#
# Returns a property set containing key/value pairs for basic settings and the 
# custom properties.  Prefix varies if global or security domain:
#
#      app.security.global.prop.key=val  
#      app.security.global.properties.prop.key=val
#
#      app.security.domain.prop.key=val  
#      app.security.domain.properties.prop.key=val
#
# A StandardError is raised if a problem occurs loading information        
#--------------------------------------------------------------------------------
def getSecurityProperties(securityDomainName=None):
	_app_trace("getSecurityProperties(%s)" % (securityDomainName),"entry")
	global progInfo
	
	retval = java.util.Properties()

	try:
		prefix = "app.security.global"
		
		if (not isEmpty(securityDomainName)):
			configId = appsecurity =AdminConfig.getid("/SecurityDomain:%s/AppSecurity:/" % securityDomainName)
			if (isEmpty(configId)):
				raise StandardError("Unable to load configuration ID for security domain %s" % securityDomainName)
			
			prefix = "app.security.domain"
			retval.put("app.security.domain.name",securityDomainName)
		else:
			configId = AdminConfig.list("Security").split(progInfo["line.separator"])[0]
		
		collectSimpleProperties(retval,"%s.prop" % prefix, configId,[])
		collectCustomProperties(retval,"%s.properties" % prefix, configId, "properties")
				
	except:
		_app_trace("Unexpected error in getSecurityProperties","exception")
		raise StandardError("Unexpected error in getSecurityProperties")
			
	
	_app_trace("getSecurityProperties()","exit")
	return retval
	
#--------------------------------------------------------------------------------
# getKeyStoreId
#
# Returns the basic configuration Id for a key store, None if it can't be found
#
# Parameters:
#    name - keystore Name
#    scopeName - string representing scope of key store (e.g.: "(cell):SecurityConfigCell:(node):SecurityConfigDmgr" )
#    scopeType - cell, node, ...
#--------------------------------------------------------------------------------
def getKeyStoreId(name, scopeName, scopeType):
	retval = None
	global progInfo
	_app_trace("getKeyStoreId(%s,%s,%s)" % (name, scopeName, scopeType),"entry")
	
	try:
		securityId = AdminConfig.list("Security").split(progInfo["line.separator"])[0]
		keystores = wsadminToList( AdminConfig.showAttribute(securityId,"keyStores"))
		

		for keystore in keystores:
			if isEmpty(keystore):
				continue
		
			
			keyname = AdminConfig.showAttribute(keystore,"name")
			if (keyname != name):
				continue

				
		
			managementScope =  AdminConfig.showAttribute(keystore,"managementScope")
			if isEmpty(managementScope):	
				continue
		
			tempScopeName = AdminConfig.showAttribute(managementScope,"scopeName")
			tempScopeType = AdminConfig.showAttribute(managementScope,"scopeType")
			
			if (tempScopeName == scopeName and tempScopeType == scopeType):
				retval = keystore
				break
	except:
		_app_trace("Unexpected exception in getKeyStoreId","exception")
		raise StandardError("Unexpected exception in getKeyStoreId")
		
	_app_trace("getKeyStoreId(retval = %s)" % retval,"exit")
	return retval

#-----------------------------------------------------------------------------------
# getKeyStoreProperties
#-----------------------------------------------------------------------------------
def getKeyStoreProperties(keystoreId):
	_app_trace("getKeyStoreProperties(%s)" % keystoreId,"entry")
	
	try:
		retval = java.util.Properties()
		
		ksname = AdminConfig.showAttribute(keystoreId,"name")
		retval.put("app.security,keyStore.name",ksname)
		managementScope =  AdminConfig.showAttribute(keystoreId,"managementScope")
		if not isEmpty(managementScope):
			collectSimpleProperties(retval,"app.security.keyStore.managementScope.prop" , managementScope)
			
		collectSimpleProperties(retval, "app.security.keyStore.prop" , keystoreId, ["name"])
		collectCustomProperties(retval,"app.security.keyStore.additionalKeyStoreAttrs", keystoreId, "additionalKeyStoreAttrs")
	
	except:
		_app_trace("Unexpected error in getKeyStoreProperties","exception")
		raise StandardError("Unexpected error in getKeyStoreProperties")
		
	_app_trace("getKeyStoreProperties()","exit")
	return retval

#------------------------------------------------------------------------------------------------	
# modifyKeyStore - update a keystores properties (V7 + only)
#
# Input:
#		keystoreName - the name of the keystore to update
#   keystoreScope - the scope of the keystore
#   keyStoreProperties - A set of key/values to be updated. Key names are names from the 
#                        KeyStore configuration type
#  
# This function will map the input parameters into the syntax required for
# AdminTask.modifyKeyStore.
#
# Generally, this is of limited use with initAtStartup being most likely attribute to 
# be modified.
# 
#
# wsadmin>print AdminTask.help("modifyKeyStore")
#WASX8006I: Detailed help for command: modifyKeyStore
#
#Description: Modifies a Keystore object.
#
#Target object:   None
#
#Arguments:
#  *keyStoreName - Specifies the unique name to identify the keystore.
#  scopeName - Specifies the management scope.
#  keyStoreType - Specifies one of the predefined keystore types.
#  keyStoreLocation - Specifies the location of the keystore file.
#  keyStorePassword - Specifies the password to open the keystore.
#  keyStoreIsFileBased - Keystore is File Based
#  keyStoreInitAtStartup - Specifies whether the keystore needs to be initialized at server startup or not.
#  keyStoreReadOnly - Specifies whether the keystore can be written to or not.
#  keyStoreDescription - Statement that describes the keystore.
#  keyStoreProvider - Specifies the provider for the keystore.
#  keyStoreUsage - What the key store can be used for.
#------------------------------------------------------------------------------------------------	
def modifyKeyStore(keyStoreName, scopeName, keyStoreProperties):
	parmMap = {'description': 'keyStoreDescription', 'initializeAtStartup':'keyStoreInitAtStartup', 'location': 'keyStoreLocation','password':'keyStorePassword','provider':'keyStoreProvider','readOnly':'keyStoreReadOnly','type':'keyStoreType','usage':'keyStoreUsage'}
	_app_trace("modifyKeyStore(%s,%s,%s)" % (keyStoreName, scopeName, keyStoreProperties),"entry")
	try:
		parms = "-keyStoreName %s -scopeName %s" % (keyStoreName, scopeName)
		for key in keyStoreProperties.keys():
			parm = parmMap.get(key)
			if isEmpty(parm):
				continue
			val = keyStoreProperties.get(key)
			if (key == "description"):
				if not val.startswith("'"):
					val = "'%s'" % val
				
			parms = "%s -%s %s" % (parms,parm,val)
		
		parms = "[%s]" % parms
		
		_app_trace("About to call AdminTask.modifyKeyStore(%s)" % parms)
		AdminTask.modifyKeyStore(parms)
			
		
	except:
		_app_trace("Unexpected error in modifyKeyStore()","exception")
		raise StandardError("Unexpected error in modifyKeyStore()")
		
	_app_trace("modifyKeyStore()","exit")

#-------------------------------------------------------------------------------
# getAuthMechanismId
#-------------------------------------------------------------------------------
def getAuthMechanismId(authType, securityId = None):
	_app_trace("getAuthMechanismId(%s,%s)" % (authType, securityId),"entry")
	retval = None

	try:	
		if (securityId == None):
			securityId = AdminConfig.list("Security").split(progInfo["line.separator"])[0]
		
		authMechanisms = wsadminToList(AdminConfig.showAttribute(securityId,"authMechanisms"))
	
		for authMechanism in authMechanisms:
			if (isEmpty(authMechanism)): continue
			if authMechanism.find(authType) >= 0:
				retval = authMechanism
				break

	except:
		_app_trace("Unexpected error in getAuthMechanismId","exception")
	
	_app_trace("getAuthMechanismId(retval = %s)" % retval,"exit")
	return retval

#-------------------------------------------------------------------------------
# getAuthMechanismProperties
#-------------------------------------------------------------------------------
def getAuthMechanismProperties(authMechanismId):
	_app_trace("getAuthMechanismProperties(%s)" % (authMechanismId), "entry")
	retval = java.util.Properties()
	try:
		
		collectSimpleProperties(retval,"authMechanism.prop",authMechanismId)
		
		try:
			digestAuthId = AdminConfig.showAttribute(authMechanismId,"digestAuthentication")
		except:
			digestAuthId = None
		if (not isEmpty(digestAuthId)):
			collectSimpleProperties(retval,"authMechanism.digestAuthentication.prop", digestAuthId)
	
		singleSignonId = AdminConfig.showAttribute(authMechanismId,"singleSignon")
		if (not isEmpty(singleSignonId)):
			collectSimpleProperties(retval,"authMechanism.singleSignon.prop", singleSignonId)
		
		collectCustomProperties(retval,"authMechanism.properties" , authMechanismId, "properties")
	
	except:
		raise StandardError("Unexpected error in getAuthMechanismProperties","exception")
	
	_app_trace("getAuthMechanismProperties()", "exit")
	return retval
	
def getTrustAssociationProperties(authMechanismId):
	_app_trace("getTrustAssociationProperties(%s)" % (authMechanismId),"entry")
	retval = java.util.Properties()
	
	try:
		trustAssociationId = AdminConfig.showAttribute(authMechanismId,"trustAssociation")
		if (not isEmpty(trustAssociationId)):
			collectSimpleProperties(retval, "trustAssociation.prop", trustAssociationId)
			tais = wsadminToList(AdminConfig.showAttribute(trustAssociationId,"interceptors"))
			taiidx = 0
			for tai in tais:
				if (isEmpty(tai)):continue
				taiidx = taiidx + 1
				interceptorClassName = AdminConfig.showAttribute(tai,"interceptorClassName")
				retval.put("trustAssociation.interceptors.%d.interceptorClassName " % (taiidx), interceptorClassName)
				collectCustomProperties(retval,"trustAssociation.interceptors.%d.trustProperties"% (taiidx) , tai, "trustProperties")
			retval.put("trustAssociation.interceptors.count", "%s" % taiidx)
	
	except:
		_app_trace("Unexpected error in getTrustAssociationProperties","exception")
		raise StandardError("Unexpected error in getTrustAssociationProperties")
		
	_app_trace("getTrustAssociationProperties()","exit")
	return retval