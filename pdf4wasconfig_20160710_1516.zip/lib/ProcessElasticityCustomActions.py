################################################################################
# ProcessCustomActions.py - process input properties that define custom actions
# used for elasticity actions by the Application Placement Controller
#
# Module entry point: processElasticityCustomActions()
#
# Requires: CustomActions.py
#           Utils.py
#
# Property syntax examples:
#
# -- Creating or modifying Elasticity Custom Actions
#
# app.im.customElasticityActions.1.name = GrabDumps4
# app.im.customElasticityActions.1.definitions.type = NamedProcessDef
# app.im.customElasticityActions.1.definitions.prop.executableName = grabDumps.sh
# app.im.customElasticityActions.1.definitions.prop.name = GrabDumps4
# app.im.customElasticityActions.1.definitions.prop.osnames = unix
# app.im.customElasticityActions.1.definitions.prop.workingDirectory = /opt/was/scripts
#
# app.im.customElasticityActions.2.name = MyClassAction3
# app.im.customElasticityActions.2.definitions.type = NamedJavaProcessDef
# app.im.customElasticityActions.2.definitions.prop.executableArguments = -Dude -take -some -action $MyUser $MyPassword;-moreoptions yes
# app.im.customElasticityActions.2.definitions.prop.executableName = com.ibm.issw.jjm.TakeAction
# app.im.customElasticityActions.2.definitions.prop.executableTarget = /opt/was/actions
# app.im.customElasticityActions.2.definitions.prop.executableTargetKind = JAVA_CLASS
# app.im.customElasticityActions.2.definitions.prop.name = MyClassAction3
# app.im.customElasticityActions.2.definitions.prop.osnames = unix
# app.im.customElasticityActions.2.definitions.prop.passwordVal = *****
# app.im.customElasticityActions.2.definitions.prop.passwordVar = *****
# app.im.customElasticityActions.2.definitions.prop.usernameVal = wsadmin
# app.im.customElasticityActions.2.definitions.prop.usernameVar = MyUser
# app.im.customElasticityActions.2.definitions.prop.workingDirectory = /opt/was/actions
#
# app.im.customElasticityActions.3.name = MyJarAction2
# app.im.customElasticityActions.3.definitions.type = NamedJavaProcessDef
# app.im.customElasticityActions.3.definitions.prop.executableArguments = -NewOption1;-NewOption2
# app.im.customElasticityActions.3.definitions.prop.executableName = MyActions.jar
# app.im.customElasticityActions.3.definitions.prop.executableTarget = /opt/was/action/jars
# app.im.customElasticityActions.3.definitions.prop.executableTargetKind = EXECUTABLE_JAR
# app.im.customElasticityActions.3.definitions.prop.name = MyJarAction
# app.im.customElasticityActions.3.definitions.prop.osnames = unix
# app.im.customElasticityActions.3.definitions.prop.workingDirectory = /opt/was/action
#
# app.im.customElasticityActions.count = 3
#
# -- Syntax for deleting custom actions
#
# del.im.customActions.1.name = GrabDumps3
# del.im.customActions.2.name = MyClassAction2
#
# del.im.customActions.count = 2
################################################################################

#-------------------------------------------------------------------------------
# processElasticityCustomActionDeletions
#
# Process the settings that specify deletions of Elasticity Custom Actions
#-------------------------------------------------------------------------------
def processElasticityCustomActionDeletions(actionInfo):

  _app_entry("processElasticityCustomActionDeletions(actionInfo)")
  try:
    caCount = int(actionInfo.get("del.im.customElasticityActions.count",0))
    if (caCount > 0):
      for idx in range(1,caCount+1):
        prefix = "del.im.customElasticityActions.%d" % idx
        caName = actionInfo.get("%s.name" % prefix)
        if (isEmpty(caName)):
          # Partial list
          continue
        else:
          retval = deleteElasticityCustomAction(caName)
          if (isEmpty(retval)):
            _app_message("Elasticity Custom Action %s did not exist - no need to delete" % caName)
          else:
            _app_message("Elasticity Custom Action %s has been deleted" % caName)
          
  except:
    _app_exception("Unexpected error in processElasticityCustomActionDeletions(actionInfo)")
    
  _app_exit("processElasticityCustomActionDeletions()")  

#-------------------------------------------------------------------------------
# processElasticityCustomAction
#
# Process the settings for a single Elasticity Custom Action definition
#
# Parameters:
#    actionInfo - dictionary containing settings
#    caName - Name of custom action
#    actionType - NamedProcessDef or NamedJavaProcessDef
#    prefix - property key prefix used to access settings in actionInfo
#-------------------------------------------------------------------------------
def processElasticityCustomAction(actionInfo, caName, actionType, prefix):
  _app_entry("processElasticityCustomAction(actionInfo, %s,%s,%s)" % (caName, actionType,prefix))
  try:
    # See if the custom action is defined
    actionID = findElasticityCustomAction(caName)
    if (not isEmpty(actionID)):
      
      actionProps = getElasticityCustomActionProperties(actionID)
      existingType = actionProps.get("customAction.definitions.type")
      
      if ( (not isEmpty(actionType)) and existingType != actionType):
        # Will have to redefine this action
        _app_message("Redefinition required")
        pass
      else:
        subProps = getPropListDifferences(actionInfo,"%s.definitions"%prefix,actionProps,"customAction.definitions")
        if (len(subProps) > 0):
          updateElasticityCustomAction(actionID,existingType,subProps)
          _app_message("Elasticity Custom Action %s has been updated" % caName)
        else:
          _app_message("Elasticity Custom Action %s does not need to be updated" % caName)
        
    else:
      subProps = getPropList(actionInfo,"%s.definitions"%prefix)
      actionID = createElasticityCustomAction(caName,actionType,subProps)
      _app_message("Elasticity Custom Action %s has been created" % caName)
      
  except:
    _app_exception("Unexpected error in processElasticityCustomAction(actionInfo, %s, %s, %s)" % (caName,actionType, prefix))
    
  _app_exit("processElasticityCustomAction()")

#-------------------------------------------------------------------------------
# processElasticityCustomActions
# Parameters:
#    actionInfo - dictionary containing settings
#-------------------------------------------------------------------------------
def processElasticityCustomActions(actionInfo):
  _app_entry("processElasticityCustomActions(actionInfo)")
  try:
    # First, process deletions
    processElasticityCustomActionDeletions(actionInfo)
    
    caCount = int(actionInfo.get("app.im.customElasticityActions.count",0))
    if (caCount > 0):
      for idx in range(1,caCount+1):
        prefix = "app.im.customElasticityActions.%d" % idx
        caName = actionInfo.get("%s.name" % prefix)
        if (isEmpty(caName)):
          # Partial list
          continue
        else:
          actionType = actionInfo.get("%s.definitions.type" % prefix)
          processElasticityCustomAction(actionInfo, caName, actionType, prefix)
  except:
    _app_exception("Unexpected error in processElasticityCustomActions(actionInfo)")
    
  _app_exit("processElasticityCustomActions()")