###################################################################################
# ApplicationDeployment.py
#
# This module contains utility methods for loading and processing the properties 
# for pplication deployment configuration items.  This is the set of configuration
# items that are manipulated after an application is deployed and does not involve
# functionality related to AdminApp.
#
# Primary function: 
# 		processAppDeployment()
#
# Related modules:
# 		Utils.py - General purpose utility methods
#     ApplicationDeployment.py - Utility methods for manipulating Deployment configuration
#     ApplicationServer.py - Used for SessionManager properties
#
###################################################################################


#------------------------------------------------------------------------------------------
# This utillity method can actually be used for most configuration items
#------------------------------------------------------------------------------------------
def updatePropertiesForModule(moduleId, moduleName, props):
	
	_app_trace("updatePropertiesForModule(%s, props)" % moduleId, "entry")
	retval = moduleId
	
	try:
		attrs = ""
		for key in props.keys():
				val = props.get(key)
				attrs = "%s [%s '%s']" % (attrs,key,val)
		
		attrs = "[ %s ]" % attrs
		if (modifyObject(moduleId,attrs)):
				retval = None
	
	except:
		_app_message("Error updating module %s properties" % moduleName,"exception")
		retval = None
	
	_app_trace("updatePropertiesForModule(retval = %s)" % retval)
	return retval
	
#------------------------------------------------------------------------------------------
# updateModuleClassloader
# Updates and application or submodule classloader settings. 
#------------------------------------------------------------------------------------------
def updateModuleClassloader(moduleId, moduleName, prefix):

	global configInfo
	retval = None
	_app_trace("updateModuleClassloader(%s,%s,%s)" % (moduleId, moduleName, prefix),"entry")
	try:
		classloaderId = AdminConfig.showAttribute(moduleId, "classloader")
		if (isEmpty(classloaderId)):
				classloaderId = AdminConfig.create("Classloader", moduleId, [])
		
		# At this point, we're just replacing existing configuration, we've already
		# done comparisons
		classloaderProps = getPropList(configInfo,"%s.classloader"%prefix)
		tempval = updatePropertiesForModule(classloaderId, "%s classloader" % moduleName, classloaderProps)
		if (isEmpty(tempval)):
				raise StandardError("Error updating classloader")
				
		# Remove any existing shared libraries
		libraries = wsadminToList(AdminConfig.showAttribute(classloaderId, "libraries"))
		for libraryref in libraries:
				if (not isEmpty(libraryref)):
						AdminConfig.remove(libraryref)
		
		# Now build library refs from input
		librefcount = int(configInfo.get("%s.classloader.libraries.count"%prefix,"0"))
		for libidx in range(1,librefcount+1):
				libprops = getPropList(configInfo,"%s.classloader.libraries.%d" % (prefix,libidx))
				if (libprops.size() > 0):
						# Create a new library ref
						librefid = AdminConfig.create("LibraryRef",classloaderId,[])
						tempval = updatePropertiesForModule(librefid, "%s classloader library reference" % moduleName, libprops)
						if (isEmpty(tempval)):
								raise StandardError("Error updating library reference")
	
		retval = classloaderId
	
	except:
		_app_trace("Error updating module classloader")
		retval = None
	
	_app_trace("updateModuleClassloader(retval = %s)" % (retval),"exit")
	return retval
		

#------------------------------------------------------------------------------------------
# compareModuleClassloaders
#
# Compare the module class loader settings in configInfo against the current configuration
# 
#------------------------------------------------------------------------------------------
def compareModuleClassloaders(prefix, existingProps, existingPrefix):

	global configInfo
	_app_trace("compareModuleClassloaders(%s, existingProps,%s)" % (prefix,existingPrefix), "entry")
	try:
		retval = 1
		
		if (checkForPrefix(configInfo,"%s.classloader"%prefix)):
			if (checkForPrefix(existingProps,existingPrefix)):
					# Currently have classloader settings, need to compare
					subProps = getPropListDifferences(configInfo, "%s.classloader"%prefix, existingProps, existingPrefix)
					if (subProps.size() > 0):
							# different base classloader properties
							retval = 0
					else:
							# So far, identical, need to compare library references
							inputLibCount = configInfo.get("%s.classloader.libraries.count" % prefix,"0")
							existingLibCount = existingProps.get("%s.libraries.count" % existingPrefix)
							
							if (inputLibCount != existingLibCount):
									retval = 0
							elif (inputLibCount != "0"):
									# Iterate through libraries and compare
									for libidx in range(1, int(inputLibCount)+1):
											libProps = getPropListDifferences(configInfo,"%s.classloader.libraries.%d" % (prefix,libidx), existingProps,"%s.libraries.%d" % (existingPrefix,libidx))
											if (libProps.size() > 0):
													retval = 0
													break
											
			else:
					# No current settings, need to process input
					retval = 0
		else:
			# No input props
			if (checkForPrefix(existingProps,existingPrefix)):
					# Currently have classloader settings - need to remove
					retval = 0
			else:
					# No current settings, no input
					retval = 1
			
		
	except:
		_app_trace("Error comparing classloader settings","exception")
		raise StandardError("Problem analyzing classloader")
	
	_app_trace("compareModuleClassloaders(result = %d)" % retval, "exit")		
	return retval


#--------------------------------------------------------------------------------------------------
# processModuleSessionManagerSettings
#
# Processes the SessionManager settings for an Application module or Web module
#--------------------------------------------------------------------------------------------------	
def processModuleSessionManagerSettings(sessionMgrId, prefix, moduleName, configType, existingProps, existingPrefix):

  global configInfo
  _app_trace("processModuleSessionManagerSettings(%s,%s,%s,%s,existingProps,%s)" % (sessionMgrId, prefix, moduleName, configType, existingPrefix),"entry")
  try:
  
    # Do base session props
    subProps = getPropListDifferences(configInfo,prefix,existingProps,existingPrefix)
    if (subProps.size() > 0):
        retval = updatePropertiesForModule(sessionMgrId, "%s SessionManager" % moduleName, subProps)
        if (retval != None):
            _app_message("Updated base SessionManager properties for %s" % moduleName)
        else:
            _app_message("Error Updating base SessionManager properties for %s" % moduleName)
            exit()
            
    else:
        _app_message("No need to update base SessionManager properties for %s" % moduleName)
        
    # Custom properties
    if (checkForPrefix(configInfo,"%s.properties" % prefix)):
      customProps = getPropListDifferences(configInfo,"%s.properties" % prefix, existingProps, "%s.properties" % existingPrefix)
      if (customProps.size() > 0):
        errMsg = updateCustomProperties(sessionMgrId, "properties", "Property", customProps) 
        if (not isEmpty(errMsg)):
          _app_exception("Error updating Session Manager custom properties for module %s, error=%s" % (moduleName,errMsg))
        else:
          _app_message("Updated Session Manager custom properties for module %s" % (moduleName))

      else:
        _app_message("No need to modify SessionManager custom properties for %s" % moduleName)
        
    
    # Tuning params 
    tuningParamsId = None
    subProps = getPropListDifferences(configInfo,"%s.tuningParams" % prefix,existingProps, "%s.tuningParams" % existingPrefix)
    if (subProps.size() > 0):
        tuningParamsId = AdminConfig.list("TuningParams", sessionMgrId)
        if (isEmpty(tuningParamsId)) :
          tuningParamsId = AdminConfig.create("TuningParams", sessionMgrId,[])
        
        retval = updatePropertiesForModule(tuningParamsId, "%s SessionManager TuningParams" % moduleName, subProps)
        if (retval != None):
            _app_message("Updated SessionManager TuningParams for %s" % moduleName)
        else:
            _app_message("Error updating SessionManager TuningParams for %s" % moduleName)
            exit()
              
        
    # Tuning params invalidation schedule
    subProps = getPropListDifferences(configInfo,"%s.tuningParams.invalidationSchedule" % prefix,existingProps, "%s.tuningParams.invalidationSchedule" % existingPrefix)
    if (subProps.size() > 0):
        # Find tuningParamsId
        if (tuningParamsId == None):
            tuningParamsId = AdminConfig.list("TuningParams", sessionMgrId)
            if (isEmpty(tuningParamsId)) :
                tuningParamsId = AdminConfig.create("TuningParams", sessionMgrId,[])
                
        invalidationScheduleId = AdminConfig.list("InvalidationSchedule", tuningParamsId)
        if (invalidationScheduleId == "") :
            invalidationScheduleId = AdminConfig.create("InvalidationSchedule", tuningParamsId, [])
        
        retval = updatePropertiesForModule(invalidationScheduleId, "%s SessionManager TuningParams InvalidationSchedule " % moduleName, subProps)
        if (retval != None):
            _app_message("Updated SessionManager TuningParams InvalidationSchedule for %s" % moduleName)
        else:
            _app_message("Error updating SessionManager TuningParams InvalidationSchedule for %s" % moduleName)
            exit()
            
    subProps = getPropListDifferences(configInfo, "%s.defaultCookieSettings" % (prefix), existingProps, "%s.defaultCookieSettings" % existingPrefix)  
    if (subProps.size() > 0) :
      cookieid = AdminConfig.list("Cookie",sessionMgrId)
      if (cookieid == "") :
          cookieid = AdminConfig.create("Cookie",sessionMgrId,[])
      
      retval = updatePropertiesForModule(cookieid, "%s SessionManager Cookie Settings " % moduleName, subProps)
      if (retval != None):
          _app_message("Updated SessionManager Cookie settings for %s" % moduleName)
      else:
          _app_message("Error updating SessionManager Cookie settings for %s" % moduleName)
          exit()
        
    # @JJM - session management database persistence parameters
    subProps = getPropListDifferences(configInfo, "%s.sessionDatabasePersistence" % (prefix), existingProps, "%s.sessionDatabasePersistence" % existingPrefix)  
    if (subProps.size() > 0) :
      sdp_id = AdminConfig.list("SessionDatabasePersistence",sessionMgrId)
      if (sdp_id == "") :
          sdp_id = AdminConfig.create("SessionDatabasePersistence",sessionMgrId,[])
        
      retval = updatePropertiesForModule(sdp_id, "%s SessionManager Database Persistence settings " % moduleName, subProps)
      if (retval != None):
          _app_message("Updated SessionManager Database Persistence settings for %s" % moduleName)
      else:
          _app_message("Error updating SessionManager Database Persistence settings for %s" % moduleName)
          exit()      
    
    # @JJM - session management memory-to-memory persistence parameters
    subProps = getPropListDifferences(configInfo, "%s.sessionDRSPersistence" % (prefix), existingProps, "%s.sessionDRSPersistence" % existingPrefix)
    if (subProps.size() > 0) :
      sdrs_id = AdminConfig.list("DRSSettings",sessionMgrId)
      if (sdrs_id == "") :
          attrs = []
          sdrs_id = AdminConfig.create("DRSSettings",sessionMgrId,attrs)
          
      retval = updatePropertiesForModule(sdrs_id, "%s SessionManager DRSPersistence settings " % moduleName, subProps)
      if (retval != None):
          _app_message("Updated SessionManager DRSPersistence settings for %s" % moduleName)
      else:
          _app_message("Error updating SessionManager DRSPersistence settings for %s" % moduleName)
          exit()      


  except:
    _app_trace("Error processing SessionManager settings","exception")
    raise StandardError("Error processing SessionManager settings")
    
  _app_trace("processModuleSessionManagerSettings()","exit")


#--------------------------------------------------------------------------------------------------
# processModuleConfigDRSSettings
#
# Processes the DRSSettings for an application config or submodule config
#--------------------------------------------------------------------------------------------------
def processModuleConfigDRSSettings(drssettingsId, moduleName, configType, prefix, existingProps, existingPrefix):

	global configInfo
	
	_app_trace("processModuleConfigDRSSettings(%s,%s,%s,%s,existingProps,%s)" % (drssettingsId, moduleName, configType, prefix, existingPrefix), "entry")
	
	try:
		
		subProps = getPropListDifferences(configInfo,prefix,existingProps, existingPrefix)
		if (subProps.size() > 0):
			retval = updatePropertiesForModule(drssettingsId, "%s DRSSettings " % moduleName, subProps)
			if (retval != None):
					_app_message("Updated DRSSettings settings for %s" % moduleName)
			else:
					_app_message("Error updating DRSSettings settings for %s" % moduleName)
					exit()
				
	
	except:
		_app_trace("Error updating DRS Settings","exception")
		raise StandardError("Error updating DRS Settings")
		
	_app_trace("processModuleConfigDRSSettings()" ,"exit")


#--------------------------------------------------------------------------------------------------
# processApplicationConfig
#--------------------------------------------------------------------------------------------------
def processApplicationConfig(moduleId, configId, moduleName, configType, prefix, existingProps):

	_app_trace("processApplicationConfig(%s,%s,%s,%s,%s)" %(moduleId, configId, moduleName, configType, prefix),"entry")
	global configInfo
	try:	
		
		# See if we have session settings
		if (checkForPrefix(configInfo,"%s.sessionManagement" %prefix)):
				# We need to handle SessionManager 
				sessionMgrId = AdminConfig.showAttribute(configId,"sessionManagement")
				if (isEmpty(sessionMgrId)):
						sessionMgrId = AdminConfig.create("SessionManager",configId,[])
						
				processModuleSessionManagerSettings(sessionMgrId, "%s.sessionManagement" % prefix, moduleName, configType, existingProps, "config.sessionManagement")
		
		# See if we have drs settings
		if (checkForPrefix(configInfo,"%s.drsSettings" % prefix)):
			# Settings found, process updates
			drssettingsId = AdminConfig.showAttribute(configId,"drsSettings")
			if (isEmpty(drssettingsId)):
					drssettingsId =  AdminConfig.create("DRSSettings", configId, [])
			
			processModuleConfigDRSSettings(drssettingsId, moduleName, configType, "%s.drsSettings"% prefix, existingProps, "config.drsSettings")
							
	except:
		_app_trace("Error processing ApplicationConfig settings", "exception")
		raise StandardError("Error processing ApplicationConfig settings")
		
	_app_trace("processApplicationConfig","exit")
	
#--------------------------------------------------------------------------------------------------
# processEJBModuleConfig
#
# Processes the properties for an EJBModuleConfiguration item.
#--------------------------------------------------------------------------------------------------
def processEJBModuleConfig(moduleId, configId, moduleName, configType, prefix,existingProps):

	_app_trace("processEJBModuleConfig(%s,%s,%s,%s,%s)" %(moduleId, configId, moduleName, configType, prefix),"entry")
	global configInfo
	try:

		# See if we have drs settings
		if (checkForPrefix(configInfo,"%s.drsSettings" % prefix)):
			# Settings found, process updates
			drssettingsId = AdminConfig.showAttribute(configId,"drsSettings")
			if (isEmpty(drssettingsId)):
					drssettingsId =  AdminConfig.create("DRSSettings", configId, [])
			
			processModuleConfigDRSSettings(drssettingsId, moduleName, configType, "%s.drsSettings"% prefix, existingProps, "config.drsSettings")
			
		beanConfigCount = int(configInfo.get("%s.enterpriseBeanConfigs.count" % prefix, "0"))
		for beanIdx in range(1,beanConfigCount+1):
				# See if we have an existing one with this name and type
				beanConfigType = configInfo.get("%s.enterpriseBeanConfigs.%d.type" % (prefix, beanIdx),"")
				ejbName = configInfo.get("%s.enterpriseBeanConfigs.%d.prop.ejbName" % (prefix, beanIdx),"")
				if (isEmpty(beanConfigType) or isEmpty(ejbName)):
						continue
				
				# Find the bean config with the name and type
				beanId = findEnterpriseBeanConfig(configId, ejbName, beanConfigType)
				if (isEmpty(beanId)):
						# Need to create it
						_app_trace("About to call AdminConfig.create(%s,%s,[[ejbName,%s]])" % (beanConfigType, configId, ejbName))
						beanId = AdminConfig.create(beanConfigType,configId,[["ejbName",ejbName]])
						_app_message("Created %s %s for bean %s" % (moduleName, beanConfigType, ejbName))
				
				existingBeanProps = getEnterpriseBeanConfigProperties(beanId)
				subProps = getPropListDifferences(configInfo,"%s.enterpriseBeanConfigs.%d" % (prefix,beanIdx), existingBeanProps, "enterpriseBeanConfig")
				if (subProps.size() > 0):
						retval = updatePropertiesForModule(beanId, "%s EnterpriseBeanConfig %s " % (moduleName,ejbName), subProps)
						if (retval == None):
								_app_message("Error updating EJB configuration properties %s %s %s " % (moduleName,beanConfigType, ejbName))
								exit()
						else:
								_app_message("Updated EJB configuration properties %s %s %s " % (moduleName,beanConfigType, ejbName))
				else:
						_app_message("No need to update EJB configuration properties for %s %s %s " % (moduleName,beanConfigType, ejbName))
				
				# See if we need to update the instancePool
				if (checkForPrefix(configInfo,"%s.enterpriseBeanConfigs.%d.instancePool" % (prefix,beanIdx))):
						subProps = getPropListDifferences(configInfo,"%s.enterpriseBeanConfigs.%d.instancePool" % (prefix,beanIdx), existingBeanProps, "enterpriseBeanConfig.instancePool")
						if (subProps.size() > 0):
								instancePoolId = AdminConfig.showAttribute(beanId,"instancePool")
								if (isEmpty(instancePoolId)):
										_app_trace("About to call AdminConfig.create(InstancePool,%s,[])" % beanId)
										instancePoolId = AdminConfig.create("InstancePool",beanId,[])
										retval = updatePropertiesForModule(instancePoolId, "%s EnterpriseBeanConfig %s InstancePool" % (moduleName,ejbName), subProps)
										if (retval == None):
												_app_message("Error updating %s EnterpriseBeanConfig %s InstancePool" % (moduleName,ejbName))
												exit()
										else:
												_app_message("Update %s EnterpriseBeanConfig %s InstancePool" % (moduleName,ejbName))
						else:
								_app_message("No need to update %s EnterpriseBeanConfig %s InstancePool" % (moduleName,ejbName))
												
								
								
						
						

	
	except:
		_app_trace("Error processing EJBModuleCOnfig settings", "exception")
		raise StandardError("Error processing EJBModuleCOnfig settings")

	_app_trace("processEJBModuleConfig","exit")
		

#--------------------------------------------------------------------------------------------------
# processWebModuleConfig
#
# Process the properties that map to a WebModuleConfig item.
#--------------------------------------------------------------------------------------------------
def processWebModuleConfig(moduleId, configId, moduleName, configType, prefix,existingProps):

	_app_trace("processWebModuleConfig(%s,%s,%s,%s,%s)" %(moduleId, configId, moduleName, configType, prefix),"entry")
	global configInfo
	try:
	
		# See if we have session settings
		if (checkForPrefix(configInfo,"%s.sessionManagement" %prefix)):
				# We need to handle SessionManager 
				sessionMgrId = AdminConfig.showAttribute(configId,"sessionManagement")
				if (isEmpty(sessionMgrId)):
						sessionMgrId = AdminConfig.create("SessionManager",configId,[])
						
				processModuleSessionManagerSettings(sessionMgrId, "%s.sessionManagement" % prefix, moduleName, configType, existingProps, "config.sessionManagement")
	
	except:
		_app_trace("Error processing WebModuleConfig settings", "exception")
		raise StandardError("Error processing WebModuleConfig settings")

	_app_trace("processWebModuleConfig","exit")	
	
#--------------------------------------------------------------------------------------------------
# Each module type has a configs attribute:
#    configs DeployedObjectConfig(ApplicationConfig, ModuleConfig, WebModuleConfig, EJBModuleConfiguration)*
# Generally, there's only one, but this function will loop through the possible additional iterations
#
# returns: 0 - ok, 1 - error
#--------------------------------------------------------------------------------------------------
def processDeployedObjectConfig(moduleId, moduleName, prefix):

	global configInfo
	retval = 0
	_app_trace("processDeployedObjectConfig(%s,%s,%s)" % (moduleId, moduleName, prefix), "entry")
	
	try:
		configCount = int(configInfo.get("%s.configs.count" % prefix,"0"))
		for confIdx in range(1,configCount+1):
				configType = configInfo.get("%s.configs.%d.type" % (prefix, confIdx),"")
				if (isEmpty(configType)):
						continue
				
				# See if the configuration already exists
				configId = getModuleDeployedObjectConfig(moduleId, configType)
				if (isEmpty(configId)):
						# Create it
						configId = AdminConfig.create(configType,moduleId,[])
						_app_message("Created %s for %s" % configType)
				
				# Let's load the configuration properties
				existingProps = getModuleDeployedObjectConfigProperties(configId, configType)
				
				# Let's see if we need to update base properites
				subProps = getPropListDifferences(configInfo,"%s.configs.%d" % (prefix, confIdx), existingProps, "config")
				if (subProps.size() > 0):
						# Do the update
						tempVal = updatePropertiesForModule(configId, "%s %s" % (moduleName, configType), subProps)
						if (tempVal == None):
								_app_message("Error updating base properties for %s %s" % (moduleName, configType))
								exit()
						else:
								_app_message("Updated base properties for %s %s" % (moduleName, configType))
				else:
						_app_message("No need to update base properties for %s %s" % (moduleName, configType))
						
				
				if (configType == "ApplicationConfig"):
						processApplicationConfig(moduleId, configId, moduleName, configType, "%s.configs.%d" % (prefix,confIdx),existingProps)
				elif (configType == "WebModuleConfig"):
						processWebModuleConfig(moduleId, configId, moduleName, configType, "%s.configs.%d" % (prefix,confIdx),existingProps)
				elif (configType == "EJBModuleConfiguration"):
						processEJBModuleConfig(moduleId, configId, moduleName, configType, "%s.configs.%d" % (prefix,confIdx),existingProps)				
						
								
						
				
	
	except:
		_app_trace("Error processing DeployedObjectConfig settings","exception")
		retval = 1
	
	_app_trace("processDeployedObjectConfig(%d)"%retval,"exit")
	return retval

#--------------------------------------------------------------------------------------------------
# processDeploymentTargetMapping
#--------------------------------------------------------------------------------------------------
def processDeploymentTargetMapping(moduleId, prefix, moduleUri, appName):

	_app_trace("processDeploymentTargetMapping(%s,%s, %s, %s)" % (moduleId, prefix, moduleUri, appName),"entry")
	try:
	
		targetMappingsCount = int(configInfo.get("%s.targetMappings.count"%prefix,"0"))
		for idx in range(1,targetMappingsCount+1):
				targetName =  configInfo.get("%s.targetMappings.%d.target.prop.name" % (prefix, idx),"")
				enableValue = configInfo.get("%s.targetMappings.%d.enable" % (prefix, idx),"")
				if (isEmpty(targetName) or isEmpty(enableValue)):
						continue
				
				targetNodeName = configInfo.get("%s.targetMappings.%d.target.prop.nodeName" % (prefix, idx),"")
				
				deploymentTargetMappingId = findDeploymentTargetMapping(moduleId, targetName, targetNodeName)
				if (isEmpty(deploymentTargetMappingId)):
						_app_message("Unable to find matching deployment target mapping for target %s %s" % (targetName,targetNodeName))
						exit()
				
				# Get the current deployment settings
				existingProps = getDeploymentTargetMappingProperties(deploymentTargetMappingId)
				if (existingProps == None):
						_app_message("Error loading deployment target mapping properties for target %s %s" % (targetName,targetNodeName))
						exit()
						
				if (existingProps.get("targetMapping.enable") == enableValue):
						# No need to change enable status
						_app_message("No need to update deployment target mapping enable status of %s for %s %s with target %s %s" % (enableValue, appName, moduleUri, targetName, targetNodeName))
				else:
						attrs = [["enable", enableValue]]
						if (modifyObject(deploymentTargetMappingId,attrs)):
								_app_message("Error updating enable value for %s %s with target %s %s" % (appName, moduleUri, targetName, targetNodeName))
								exit()
						else:
								_app_message("Updated deployment target mapping enable value to %s for %s %s with target %s %s" % (enableValue,appName, moduleUri, targetName, targetNodeName))
	except:
		_app_trace("Error processing DeploymentTargetMapping configurations","exception")
		_app_message("Error processing DeploymentTargetMapping configurations for application %s module %s" % (appName, moduleUri))
		exit()
		
	
	_app_trace("processDeploymentTargetMapping()","exit")


def processModuleResourceAdapater(moduleId, prefix, moduleUri, appName):

	_app_trace("processModuleResourceAdapater(%s,%s,%s,%s)" % (moduleId, prefix, moduleUri, appName),"entry")
	
	try:
		raName = configInfo.get("%s.resourceAdapter.name" % prefix)
		
		resourceAdapterId = AdminConfig.showAttribute(moduleId, "resourceAdapter")
		
		if (isEmpty(resourceAdapterId)):
				# Need to create it
				resourceAdapterId = AdminConfig.create("J2CResourceAdapter",moduleId,[["name",raName]])
				
		# @TODO: In theory, we could also see if base properties need to change (like threadPool)
		
		processJ2CAdminObjects(configInfo,resourceAdapterId, "%s.resourceAdapter" % prefix, raName, "application %s module %s" % (appName, moduleUri))
		
		processJ2CConnectionFactories(configInfo,resourceAdapterId, "%s.resourceAdapter" % prefix, raName, "application %s module %s" % (appName, moduleUri))
				
	except:
		_app_trace("Unexpected error processing module resource adapter configuration","exception")
		_app_message("Unexpected error processing module resource adapter configuration for %s %s" % (appName, moduleUri))
		exit()
		
		
	_app_trace("processModuleResourceAdapater()", "exit")
	
#--------------------------------------------------------------------------------------------------
# processModuleDeployment
#--------------------------------------------------------------------------------------------------
def processModuleDeployment(appdeploymentId,moduleUri, moduleType, prefix, appName):

	global configInfo
	
	_app_trace("processModuleDeployment(%s,%s,%s,%s,%s)" % (appdeploymentId,moduleUri, moduleType, prefix, appName),"entry")
	
	try:
	
		moduleId = findApplicationModule(appdeploymentId, moduleUri, moduleType)
		if (isEmpty(moduleId)):
				_app_message("Unable to find application %s module %s %s" %  (appName, moduleUri, moduleType))
				exit()
		
		existingProps = getModuleDeploymentProperties(moduleId, "module")
		
		# Let's process base settings
		subProps = getPropListDifferences(configInfo,prefix,existingProps, "module")
		if (subProps.size() > 0):
				retval = updatePropertiesForModule(moduleId, "%s %s" % (appName, moduleUri), subProps)
				if (retval == None):
						_app_message("Error updating base properties for %s %s" % (appName, moduleUri))
						exit()
				else:
						_app_message("Updated base deployment properties for %s %s" % (appName, moduleUri))
		else:
			_app_message("No need to update base deployment properties for %s %s" % (appName, moduleUri))
		
		# Custom properties
		if (checkForPrefix(configInfo,"%s.properties" % prefix)):
		  customProps = getPropListDifferences(configInfo,"%s.properties"%prefix,existingProps,"module.properties")
		  if (len(customProps) > 0):
		    errmsg = updateCustomProperties(moduleId, "properties", "Property", customProps)
		    if (not isEmpty(errmsg)):
		      raise StandardError("Unable to update custom properties in %s %s:errmsg" % (appName,moduleUri,errmsg))
		    else:
		      _app_message("Updated custom properties for module %s %s" % (appName,moduleUri))
		  else:
		    _app_message("No need to update custom properties for module %s %s" % (appName,moduleUri))
		
		# Let's see if there's classloader settings
		if (checkForPrefix(configInfo,"%s.classloader"% prefix)):
				# Yes we have classloader settings to process
				if (compareModuleClassloaders(prefix, existingProps ,"module.classloader")) :
						_app_message("No need to update classloader settings for %s" % appName)
				else:
						retval = updateModuleClassloader(moduleId, "%s %s" % (appName,moduleUri), prefix)
						if (isEmpty(retval)):
								_app_message("Error updating classloader settings for application %s module %s" % (appName,moduleUri))
								exit()
						else:
								_app_message("Updated classloader settings for application %s module %s" % (appName,moduleUri))
		
		if (moduleType == "ConnectorModuleDeployment"):
				# Will need to handle resource adapter
				print ""

		# Configs
		if (processDeployedObjectConfig(moduleId, "%s %s" % (appName, moduleUri), prefix)):
				_app_message("Error processing %s %s module configuration settings" % (appName,moduleUri))
				exit()
				
		
		# TargetMappings
		processDeploymentTargetMapping(moduleId, prefix, moduleUri, appName)
		
		# Check for resourceAdapter
		if (checkForPrefix(configInfo,"%s.resourceAdapter" % prefix)):
		
				processModuleResourceAdapater(moduleId, prefix, moduleUri, appName)
	
	except:
		_app_trace("Error processing module deployment settings","exception")
		raise StandardError("Error processing module deployment settings")
	
	_app_trace("processModuleDeployment","exit")
	

#--------------------------------------------------------------------------------------------------
# processAppDeployment
#--------------------------------------------------------------------------------------------------
def processAppDeployment():
  
  global configInfo
  
  _app_trace("processAppDeployment","entry")
  try:
    appCount = int(configInfo.get("app.appdeployment.count","0"))
  
    if (appCount == 0):
        _app_message("Skipping Application Deployment")
    else:
        for idx in range(1,appCount+1):
            prefix = "app.appdeployment.%d" % idx
            
            appName = configInfo.get("%s.name" % prefix,"")
            if (isEmpty(appName)):
                # Partial list, carry on
                continue
            
            # Let's find the deployment object for the application
            appdeploymentId = getApplicationDeployment(appName)
            if (isEmpty(appdeploymentId)):
                _app_message("Unable to find ApplicationDeployment configuration for %s" % appName)
                exit()
            
            # Get the current configuration values
            appDeploymentProps = getModuleDeploymentProperties(appdeploymentId, "appdeployment")
            
            subProps = getPropListDifferences(configInfo, "%s.deploymentObject" % prefix, appDeploymentProps, "appdeployment")
            if (subProps.size() > 0):
                _app_message("Need to update base application deployment properties for %s" % appName)
                retval = updatePropertiesForModule(appdeploymentId, appName, subProps)
                if (retval == None):
                    _app_message("Error updating base properties for %s" % appName)
                    exit()
                else:
                    _app_message("Updated base application deployment properties for %s" % appName)
                
            else:
                _app_message("No need to update base application deployment properties for %s" % appName)
                
            # Custom properties
            if (checkForPrefix(configInfo,"%s.deploymentObject.properties" % prefix)):
              customProps = getPropListDifferences(configInfo,"%s.deploymentObject.properties"%prefix,appDeploymentProps,"appdeployment.properties")
              if (len(customProps) > 0):
                errmsg = updateCustomProperties(appdeploymentId, "properties", "Property", customProps)
                if (not isEmpty(errmsg)):
                  raise StandardError("Unable to update custom properties in %s:errmsg" % (appName,errmsg))
                else:
                  _app_message("Updated custom properties for application %s" % (appName))
              else:
                _app_message("No need to update custom properties for application %s" % (appName))                
                
            # See if we need to update classloader
            if (compareModuleClassloaders("%s.deploymentObject" % prefix, appDeploymentProps,"appdeployment.classloader")) :
                _app_message("No need to update classloader settings for %s" % appName)
            else:
                retval = updateModuleClassloader(appdeploymentId, appName, "%s.deploymentObject" % prefix)
                if (isEmpty(retval)):
                    _app_message("Error updating classloader settings for application %s" % appName)
                    exit()
                else:
                    _app_message("Updated classloader settings for %s" % appName)
                    
            # Process config data for application
            if (processDeployedObjectConfig(appdeploymentId, "application %s" % appName, "%s.deploymentObject" % prefix)):
                _app_message("Error processing application %s deployment configuration" % appName)
                exit()
            
            processDeploymentTargetMapping(appdeploymentId, "%s.deploymentObject" % prefix, "", appName)
            
            # Now we need to process the submodules for the application
            moduleCount = int(configInfo.get("%s.deploymentObject.modules.count" % prefix,"0"))
            for modidx in range(1,moduleCount+1):
                moduleUri = configInfo.get("%s.deploymentObject.modules.%d.uri" % (prefix, modidx), "")
                moduleType = configInfo.get("%s.deploymentObject.modules.%d.type" % (prefix, modidx), "")
                if (isEmpty(moduleUri) or isEmpty(moduleType)):
                    continue
                
                processModuleDeployment(appdeploymentId,moduleUri, moduleType, "%s.deploymentObject.modules.%d" % (prefix,modidx), appName)
          
  except:
    _app_trace("Unexpected error in processAppDeployment","exception")
    _app_message("Unexpected error processing Application Deployment configuration")
    exit()
  
  _app_trace("processAppDeployment","exit")