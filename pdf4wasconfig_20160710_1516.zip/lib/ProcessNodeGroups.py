################################################################################
# ProcessNodeGroups.py - Contains functions for processing input properties and
# processing NodeGroup definitions.
# 
# Requires: NodeGroup.py, Utils.py, common.py
#
# Module Entry Point: processNodeGroups(ngInfo)
#
# Node Group Property Example:
#
# app.nodegroups.3.name = NewNodeGroup
# app.nodegroups.3.prop.description = My new Node Group.
# app.nodegroups.3.properties.prop.MyCustomProp2 = Value2
# app.nodegroups.3.properties.prop.MyCustomProp = Value1|Description
# app.nodegroups.3.members.1.type = NodeGroupMember
# app.nodegroups.3.members.1.prop.nodeName = IMScriptingNode2
# app.nodegroups.3.members.2.type = NodeGroupMember
# app.nodegroups.3.members.2.prop.nodeName = IMScriptingNode1
# app.nodegroups.3.members.2.properties.prop.CustomMemberProperty2 = Value2
#
# ------------------------------------------------
# Deletion Syntax
# You can choose to delete an entire node group or remove specific members
# from a node group.  If deleteMembers = true is specified as shown below,
# only listed members will be deleted, otherwise the entire node group
# will be deleted.
#
# del.nodegroups.1.name = NodeGroup2
# del.nodegroups.1.deleteMembers = true
# del.nodegroups.1.members.1.prop.nodeName = ODRNode1
#
# --------------------------------------------------
# Note on impact of creating node group at same time as dynamic cluster
# that uses node group: There's an odd behavior if the node group is not
# already defined: Dynamic Cluster creation appears to work, but the 
# cluster members are not listed in the admin console, even though underlying
# XML files are created. To work around this, the following special property
# can be set: 
#    app.nodegroups.forceSave = true
#
# This is handled in updateEnvironment.py and will save the configuration of
# the node groups before Dynamic Cluster definitions are processed. With the
# nodegroup saved, there are no issues with the Dynamic Cluster creation.


#-------------------------------------------------------------------------------
# processNodeGroupMemberDeletions
#
# Parameters
#   ngInfo - dictionary with input properties to process
#   ngPrefix - Prefix of node group being processed ("del.nodegroups.1")
#   ngName - Name of node group being processed
#-------------------------------------------------------------------------------
def processNodeGroupMemberDeletions(ngInfo,ngPrefix,ngName):
  _app_entry("processNodeGroupMemberDeletions(ngInfo,%s,%s)" , ngPrefix,ngName)
  retval = None
  try:
    
    delCount = int(ngInfo.get("%s.members.count" % ngPrefix,0))
    if (delCount > 0):
      # Let's get current members
      ngProps = getNodeGroupProperties(ngName=ngName)
      memberDict = ngProps["MEMBERS_DICTIONARY"]
      memberNames = memberDict.keys()
      
      for idx in range(1,delCount+1):
        memberName = ngInfo.get("%s.members.%d.prop.nodeName" % (ngPrefix,delCount))
        if (not isEmpty(memberName)):
          if (memberName in memberNames):
            removeNodeGroupMember(ngName,memberName)
            _app_message("Removed member %s from NodeGroup %s" % (memberName,ngName))
          else:
            _app_message("No removal necessary. %s is not a member of NodeGroup %s" % (memberName,ngName))
            
        
  except:
    _app_exception("Unexpected problem in processNodeGroupMemberDeletions()")
  
  _app_exit("processNodeGroupMemberDeletions(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# processNodeGroupDeletions
#
# Parameters
#
#-------------------------------------------------------------------------------
def processNodeGroupDeletions(ngInfo):
  _app_entry("processNodeGroupDeletions(ngInfo)" )
  retval = None
  try:
    delCount = int(ngInfo.get("del.nodegroups.count",0))
    if (delCount > 0):
      for idx in range(1,delCount+1):
        ngPrefix = "del.nodegroups.%d" % idx
        ngName = ngInfo.get("%s.name" % ngPrefix)
        if (isEmpty(ngName)):
          # partial list
          continue
        deleteMembers = ngInfo.get("%s.deleteMembers"%ngPrefix,"false")
        if (deleteMembers.lower() in ["true","yes"]):
          processNodeGroupMemberDeletions(ngInfo,ngPrefix,ngName)
        else:
          # Just delete the node group
          delId = deleteNodeGroup(ngName)
          if (not isEmpty(delId)):
            _app_message("Node Group %s has been deleted"%ngName)
          else:
            _app_message("No deletion necessary. Node Group %s was not defined" % ngName)
  except:
    _app_exception("Unexpected problem in processNodeGroupDeletions()")
  
  _app_exit("processNodeGroupDeletions(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# parseNodeGroupInput
#
# Turns the input properties into a dictionary that can be compared with 
# the results of getNodeGroupProperties(ngId)
#
# Parameters
#
#-------------------------------------------------------------------------------
def parseNodeGroupInput(ngInfo,ngPrefix,ngName):
  _app_entry("parseNodeGroupInput(ngInfo,%s)" , ngPrefix)
  retval = {}
  membersDict = {}
  
  try:
    retval["nodegroup.prop.name"] = ngName
    subProps = getPropList(ngInfo,ngPrefix)
    for tkey in subProps.keys():
      retval["nodegroup.prop.%s" % tkey] = subProps[tkey]
    
    
    subProps = getPropList(ngInfo,"%s.properties" % ngPrefix)
    for tkey in subProps.keys():
      retval["nodegroup.properties.prop.%s" % tkey] = subProps[tkey]
    
    memCount = int(ngInfo.get("%s.members.count" % ngPrefix,0))
    if (memCount > 0):
      for memIdx in range(1,memCount+1):
        subProps = getPropList(ngInfo,"%s.members.%d" % (ngPrefix,memIdx))
        memberName = subProps.get("nodeName")
        if (not isEmpty(memberName)):
          mDict = {}
          for key in subProps.keys():
            mDict["nodegroupmember.prop.%s" % key] = subProps[key]
          
          customProps = getPropList(ngInfo,"%s.members.%d.properties" % (ngPrefix,memIdx))
          if (len(customProps) > 0):
            for key in customProps.keys():
              mDict["nodegroupmember.properties.prop.%s" % key] = customProps[key]
          
          membersDict[memberName] = mDict
  
    retval["MEMBERS_DICTIONARY"] = membersDict
          
    
  except:
    _app_exception("Unexpected problem in parseNodeGroupInput()")
  
  _app_exit("parseNodeGroupInput(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# processNodeGroup - propcess the properties for an individual node group
#
# Parameters
#   ngInfo - dictionary with input properties
#   ngPrefix - property key prefix for the node group being processed
#   ngName - Name of node group
#
#-------------------------------------------------------------------------------
def processNodeGroup(ngInfo,ngPrefix,ngName):
  _app_entry("processNodeGroup(ngInfo,%s,%s)" , ngPrefix,ngName)
  retval = None
  try:
    # See if it exists
    ngId = getNodeGroupId(ngName)
    if (not isEmpty(ngId)):
      #_app_message("NodeGroup %s is already defined" % ngName)
      # Get the current properties of this node group
      existingProps = getNodeGroupProperties(ngId=ngId)
      
      
      membersIdDict = {}
      membersDict = existingProps.get("MEMBERS_DICTIONARY")

      # Remove IDs so we can compare against input
      for key in membersDict.keys():
        mdict = membersDict[key]
        tempID = mdict["ID"]
        del mdict["ID"]
        membersIdDict[key] = tempID

      inputProps = parseNodeGroupInput(ngInfo,ngPrefix,ngName)
      if (inputProps != existingProps):
        updatedNodeGroup = 0
        
        # See if NodeGroup Settings have changed
        baseProps = getPropListDifferences(inputProps,"nodegroup",existingProps,"nodegroup")
        customProps = getPropListDifferences(inputProps,"nodegroup.properties",existingProps,"nodegroup.properties")
        if (len(baseProps) > 0 or len(customProps) > 0):
          updateNodeGroupSettings(ngId,baseProps,customProps)
          _app_message("Updated properties for NodeGroup %s" % ngName)
          updatedNodeGroup = 1
                    
        # See if Node Group Member settings have changed
        inputMembers = inputProps.get("MEMBERS_DICTIONARY")
        existingMembers = existingProps.get("MEMBERS_DICTIONARY")
        
        if (inputMembers != existingMembers):
          # Some differences - could be in settings or new members
          
          for inputNode in inputMembers.keys():
            inputNodeProps = inputMembers.get(inputNode)
            existingNodeProps = existingMembers.get(inputNode,None)
            if (existingNodeProps == None):
              # Need to add new member
              customProps = getPropList(inputNodeProps,"nodegroupmember.properties")
              addNodeGroupMember(ngName,inputNode,customProps)
              _app_message("Added member %s to Node Group %s" % (inputNode,ngName))
              updatedNodeGroup = 1
            elif (existingNodeProps != inputNodeProps):
              # Need to update member properties
              customProps = getPropListDifferences(inputNodeProps,"nodegroupmember.properties",existingNodeProps,"nodegroupmember.properties")
              
              # There should be at least one difference at this point, but might as well check
              if (len(customProps) > 0):
                updateNodeGroupMemberCustomProperties(membersIdDict.get(inputNode),customProps)
                _app_message("Updated custom properties of member %s in Node Group %s" % (inputNode,ngName))
                updatedNodeGroup = 1
                
        if (not updatedNodeGroup):
          _app_message("No updates necessary for NodeGroup %s" % ngName)      
      else:
        _app_message("No updates necessary for NodeGroup %s" % ngName)
    else:
      _app_message("NodeGroup %s is not defined" % ngName)
      inputProps = parseNodeGroupInput(ngInfo,ngPrefix,ngName)
      membersDict = inputProps.get("MEMBERS_DICTIONARY")
      membersNames = membersDict.keys()
      baseProps = getPropList(inputProps,"nodegroup")
      customProps = getPropList(inputProps,"nodegroup.properties")
      idMap = createNodeGroup(ngName,baseProps,customProps,membersNames)
      ngId = idMap.get("NODE_GROUP_ID")
      _app_message("Created NodeGroup %s with members %s" % (ngName,membersNames))
      
  except:
    _app_exception("Unexpected problem in processNodeGroup()")
  
  _app_exit("processNodeGroup(retval=%s)" % retval)
  return retval



#-------------------------------------------------------------------------------
# processNodeGroups
#
# Parameters
#
#-------------------------------------------------------------------------------
def processNodeGroups(ngInfo):
  _app_entry("processNodeGroups(ngInfo)")
  retval = None
  try:
    ngCount = int(ngInfo.get("app.nodegroups.count","0"))
    if (ngCount > 0):
      for idx in range(1,ngCount+1):
        prefix = "app.nodegroups.%d" % idx
        ngName = ngInfo.get("%s.name" % prefix)
        if (isEmpty(ngName)):
          # Partial list - just skip
          continue
        
        processNodeGroup(ngInfo,prefix,ngName)
    
    # Do deletions afterwards in case input moved nodes to other node groups
    # Nodes can belong to multiple node groups
    processNodeGroupDeletions(ngInfo)    
  except:
    _app_exception("Unexpected problem in processNodeGroups()")
  
  _app_exit("processNodeGroups(retval=%s)" % retval)
  return retval