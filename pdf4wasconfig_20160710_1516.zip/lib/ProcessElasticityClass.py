################################################################################
# ProcessElasticityClass.py
#  
# Handles the property instruction processing for Add/Remove Elasticity Operations
# (ElasticityClass is the WCCM type)configurations used by the 
# Application Placement Controller.
#  
# Required modules: ElasticityClass.py
#                   Utils.py
#                   common.py
#
# Entry function:
#   processElasticityClasses()
#
#      
#--------------------------
# Elasticity Operations Syntax example
#--------------------------
# app.im.elasticityClass.1.name = Add
# app.im.elasticityClass.1.prop.reactionMode = 2
# app.im.elasticityClass.1.prop.description = Hoo boy
# app.im.elasticityClass.1.ElasticityAction.1.type = CustomElasticityAction
# app.im.elasticityClass.1.ElasticityAction.1.prop.actionName = MyCustomAddAction2
# app.im.elasticityClass.1.ElasticityAction.1.prop.actionType = CUSTOM
# app.im.elasticityClass.1.ElasticityAction.1.prop.stepNum = 2
# app.im.elasticityClass.1.ElasticityAction.2.type = CustomElasticityAction
# app.im.elasticityClass.1.ElasticityAction.2.prop.actionName = JavaClassAction
# app.im.elasticityClass.1.ElasticityAction.2.prop.actionType = CUSTOM
# app.im.elasticityClass.1.ElasticityAction.2.prop.stepNum = 1
# app.im.elasticityClass.1.ElasticityAction.count = 2
#
# app.im.elasticityClass.2.name = Remove
# app.im.elasticityClass.2.prop.reactionMode = 2
# app.im.elasticityClass.2.prop.description = Add Elasticity operations
# app.im.elasticityClass.2.ElasticityAction.1.type = CustomElasticityAction
# app.im.elasticityClass.2.ElasticityAction.1.prop.actionName = MyCustomJavaDeleteAction
# app.im.elasticityClass.2.ElasticityAction.1.prop.actionType = CUSTOM
# app.im.elasticityClass.2.ElasticityAction.1.prop.stepNum = 1
# app.im.elasticityClass.2.ElasticityAction.2.type = CustomElasticityAction
# app.im.elasticityClass.2.ElasticityAction.2.prop.actionName = JavaClassAction
# app.im.elasticityClass.2.ElasticityAction.2.prop.actionType = CUSTOM
# app.im.elasticityClass.2.ElasticityAction.2.prop.stepNum = 2
# app.im.elasticityClass.2.ElasticityAction.count = 2
# app.im.elasticityClass.count = 2


#---------------------------------------------------------------------
# getElasticityActionsList
#---------------------------------------------------------------------
def getElasticityActionsList(elasticityClassConfig,prefix):
  elasticityActions = []
  haCount = int(elasticityClassConfig.get("%s.ElasticityAction.count" % prefix,0))
  for idx in range(1,haCount+1):
    eaType = elasticityClassConfig.get("%s.ElasticityAction.%d.type" % (prefix,idx))
    eaProps = getPropList(elasticityClassConfig,"%s.ElasticityAction.%d" % (prefix,idx))
    elasticityActions.append((eaType,toDictionary(eaProps)))
  
  return elasticityActions



#---------------------------------------------------------------------
# processIndividualElasticityClass
#---------------------------------------------------------------------
def processIndividualElasticityClass(elasticityClassConfig,ecName,prefix):
  _app_entry('processIndividualElasticityClass(elasticityClassConfig,%s,%s)' % (ecName,prefix))
 
  try:
    ecId = None
    ecId = findElasticityClass(ecName)
    if (not isEmpty(ecId)):
      #_app_message("ElasticityClass %s has been found" % ecName)
      ecProps = getElasticityClassProperties(ecId)
      #for key in ecProps.keys():
      #  print "   %s = %s" % (key,ecProps[key])
    
      # Get the base properties
      ecBaseProps = getPropListDifferences(elasticityClassConfig,prefix,ecProps,"elasticityClass")
      
      
      # Now see if actions are changed
      elasticityActions = getElasticityActionsList(elasticityClassConfig,prefix)
      existingElasticityActions = getElasticityActionsList(ecProps,"elasticityClass")

      
      if (len(elasticityActions) == len(existingElasticityActions)):
        # Need to see if they are duplicates
        # Lists of tuples can be compared for value equality
        if (elasticityActions == existingElasticityActions):
          # Set to None so we won't update it
          elasticityActions = None
      
     
      if (len(ecBaseProps) > 0 or elasticityActions != None):
        modifyElasticityClass(ecId, ecBaseProps, elasticityActions)
        _app_message("ElasticityClass %s has been updated" % ecName)
        
      else:
        _app_message("ElasticityClass %s does not need to be updated" % ecName)
      
    else:
      # Would not expect to get here, but just in case classes were deleted
      ecProps = getPropList(elasticityClassConfig,prefix)
      elasticityActions = getElasticityActionsList(elasticityClassConfig,prefix)
      
              
      ecId = createElasticityClass(ecName, ecProps, elasticityActions)
      _app_message("ElasticityClass %s has been created" % ecName)
  except:
    _app_exception("Unexpected problem with processIndividualElasticityClass")
  
  _app_exit('processIndividualElasticityClass()')

#---------------------------------------------------------------------
# processElasticityClasses
#---------------------------------------------------------------------
def processElasticityClasses(elasticityClassConfig):
  _app_entry('processElasticityClasses(elasticityClassConfig)')
  
  try:
      
    prefix = "app.im.elasticityClass"
    ecCount = int(elasticityClassConfig.get("%s.count" % prefix,0))
    if (ecCount > 0):
      for idx in range(1,ecCount+1):
        ecName = elasticityClassConfig.get("%s.%d.name" % (prefix,idx),None)
        if (isEmpty(ecName)):
          # Partial list
          continue
          
        processIndividualElasticityClass(elasticityClassConfig,ecName,"%s.%d" % (prefix,idx))
  except:
    _app_exception("Unexpected problem with processElasticityClasses")
  
  _app_exit('processElasticityClasses()')
  