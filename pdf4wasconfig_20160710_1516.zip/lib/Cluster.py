##########################################################################
# File Name:    Cluster.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere Clusters
#
#               createCluster
#               deleteCluster
#               listClusters
#
#               findMatchingClusters
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createCluster: Creates a Cluster
#
# SYNTAX:
#    createCluster name ,node, server, preferLocal
#
# PARAMETERS:
#    name	-	Cluster name
#    node	-	Node/server to be converted as first member or None
#    server	- 	Node/server to be converted as first member or None
#    preferLocal-	Optional flag for enabling node-scoped optimisation
#			within the cluster (defaults = 1)
#
# USAGE NOTES:
#    Creates a cluster, using an optional node/server to use as the first member
#    Set node and server to None to ignore server conversion
#
# RETURNS:
#    ObjID	Object ID of new appserver
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addServerCluster(name, node, server, preferLocal = 1):
	createCluster(name, node, server, preferLocal)

def createServerCluster(name, node, server, preferLocal = 1):
	createCluster(name, node, server, preferLocal)

def addCluster(name, node, server, preferLocal = 1):
	createCluster(name, node, server, preferLocal)

def createCluster(name, node, server, preferLocal = 1, createReplicationDomain = "false"):

	global progInfo

	retval = None

	try:
		traceStr = "createCluster(%s, %s, %s, %d)" % (name, node, server, preferLocal)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		if isEmpty(name):
			raise StandardError("Cluster name not specified")

		if objectExists("ServerCluster", None, name):
			raise StandardError("Cluster %s already exists" % (name))

		if (not isEmpty(node) and isEmpty(server)) or (isEmpty(node) and not isEmpty(server)):
			raise StandardError("Node AND server required, not %s and %s" % (node, server))
			
		if not isEmpty(node) and not objectExists("Server", "/Node:%s/" % (node), server):
			raise StandardError("No such server as %s on node %s to convert as first member" % (server, node))
			
		if preferLocal:
			plFlag = "true"
		else:
			plFlag = "false"
				
		# WAS 6.0 vs WAS 6.1 attributes
		if ( progInfo["dmgrVersion"].startswith("6.0")):
			attributes = "[-clusterConfig [[%s %s]] -replicationDomain [[%s]]]" % (name, plFlag, createReplicationDomain)
		else:
			# @JM - fixed "- clusterName"
			# @JM - looks like replication domain is always created		
			# @JM - For WAS v7, -createDomain needs true parameter  
			attributes = "-clusterConfig [ -clusterName %s] -replicationDomain [ -createDomain %s ]" % (name,createReplicationDomain)

		if not isEmpty(node):
			attributes += " -convertServer [[%s %s '' '' '']]" % (node, server)

		attributes += "]"

		_app_trace("Running command: AdminTask.createCluster(%s)" % (attributes))

		retval = AdminTask.createCluster(attributes);

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()

	except:
		_app_trace("An error was encountered creating the Cluster", "exception")
		retval = None

	_app_trace("createCluster(%s)" %(retval), "exit")
	return retval
	
##########################################################################
#
# FUNCTION:
#    deleteCluster: Delete an Cluster
#
# SYNTAX:
#    deleteCluster name
#
# PARAMETERS:
#    name	-	Cluster name
#
# USAGE NOTES:
#    Deletes a Cluster and all of its members
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeServerCluster(name):
	deleteCluster(name)
	
def deleteServerCluster(name):
	deleteCluster(name)
	
def removeCluster(name):
	deleteCluster(name)
	
def deleteCluster(name):

	global progInfo

	retval = 0

	try:
		traceStr = "deleteCluster(%s)" % (name)
		_app_trace(traceStr, "entry")	

		if isEmpty(name) :
			_app_trace("Cluster name not specified")
			retval = 1
		else:
			#	Check function parameters
			if not objectExists("ServerCluster", None, name):
				_app_trace("No such Cluster as %s" % (name))
				retval = 1
			else:
				attributes = " -clusterName %s" % (name)
				_app_trace("Running command: AdminTask.deleteCluster(%s)" % (attributes))

				AdminTask.deleteCluster(attributes)

				if progInfo["app.autosave"] == "true":
					_app_trace("Saving...")
					AdminConfig.save()
	except:
		_app_trace("An error was encountered deleting the Cluster", "exception")
		retval = 1

	_app_trace("deleteCluster(%d)" %(retval), "exit")
	return retval

##########################################################################
#
# FUNCTION:
#    listClusters: List Clusters on node
#
# SYNTAX:
#    listClusters displayFlag
#
# PARAMETERS:
#    displayFlag-	Boolean indicating whether to print list 
#			(default = 1)
#
# USAGE NOTES:
#    Lists Clusters 
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showClusters(displayFlag = 1):
	listClusters(displayFlag)

def showServerClusters(displayFlag = 1):
	listClusters(displayFlag)

def listServerClusters(displayFlag = 1):
	listClusters(displayFlag)
	
def listClusters(displayFlag = 1):

	global progInfo
	
	retval = None
	
	try:
		traceStr = "listClusters(%d)" % (displayFlag)
		_app_trace(traceStr, "entry")	

		_app_trace("Running command: AdminConfig.list('ServerCluster')")
		str = AdminConfig.list("ServerCluster")

		if isEmpty(str):
			retval = []
		else:
			retval = str.split(progInfo["line.separator"])

		if displayFlag:
			print "\nClusters\n-------------------"
				
			for r in retval:
				print AdminConfig.showAttribute(r, "name")
							
			print "-------------------"
	except:
		_app_trace("An error was encountered listing the Clusters", "exception")
		retval = None

	_app_trace("listClusters(%s)" %(retval), "exit")
	return retval

#-------------------------------------------------------------------------------
# findMatchingClusters
#
# Parameters:
#   clusterPattern - a regexp pattern to use
#
# Returns:
#   A list of server cluster configuration IDs that match the pattern
#-------------------------------------------------------------------------------
def findMatchingClusters(clusterPattern):
  _app_trace("findMatchingClusters(%s)" %(clusterPattern),"entry")
  import re
  retval = []
  try:
    tempList = AdminConfig.list("ServerCluster").split(progInfo["line.separator"])
    for tempId in tempList:
      if (isEmpty(tempId)): continue
      
      tempName = AdminConfig.showAttribute(tempId,"name")
      if (clusterPattern.find("*") >= 0):
        # Do regexp comparison
        if (re.match(clusterPattern,tempName)):
          retval.append(tempId)
      else:
        # Just treat as name search
        if (clusterPattern == tempName):
          retval.append(tempId)
        
  except:
    _app_trace("Unexpected error in findMatchingClusters","exception")
    raise StandardError("Unexpected error in findMatchingClusters")
  
  
    
  _app_trace("findMatchingClusters()","exit")
  return retval
  
#-------------------------------------------------------------------------------
# getServerClusterProperties
#     Returns a dictionary with base and nest properties of a ServerCluster
#     configuration item (except for "members" attribute)
#
# Parameters
#     clusterId - Configuration ID
#  Returns:
#     Dictionary with "cluster.prop"     
#                     "cluster.clusterAddressProperties.prop"
#                     "cluster.clusterAddressProperties.CONFIG_ID"
#                     "cluster.clusterAddressEndPoints.[1-n].prop"
#                     "cluster.clusterAddressEndPoints.[1-n].CONFIG_ID"
#-------------------------------------------------------------------------------
def getServerClusterProperties(clusterId):
  _app_entry("getServerClusterProperties(%s)" , clusterId)
  retval = {}
  try:
    idProps = {}
    collectSimpleProperties(retval, "cluster.prop",clusterId, optionalSkipList=["members"],idProps=idProps,getSimpleChildren=1,childrenSkipList=["members"],
                           collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=1,getChildType=1)
    
    for key in idProps.keys():
      #print "%s %s" % (key,idProps[key])
      val = idProps[key]
      if (not isArray(val)):
        keytokens = key.split(".prop.")
        newkey = ""
        for keytoken in keytokens:
          if (newkey == ""):
            newkey = keytoken
          else:
            newkey = "%s.%s" % (newkey,keytoken)
          
        retval["%s.CONFIG_ID" %newkey] = val
  except:
    _app_exception("Unexpected problem in getServerClusterProperties()")
  
  _app_exit("getServerClusterProperties(retval=%s)" % retval)
  return retval
