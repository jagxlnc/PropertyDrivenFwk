################################################################################
# ProcessTimer.py
#   Module for processing property input and applying to TimerManagerInfo
#   configuration item
#
# Entry point function:
#     processTimerManagerSettings(timerConfig)
#
# Requires: Timer.py, Utils.py, common.py
#
# -------
# Timer property syntax (use dumpConfig.py -timers to produce samples)
#
# app.timer.provider.3.cluster = SampleCluster
# app.timer.provider.3.node = 
# app.timer.provider.3.server = 

# app.timer.provider.3.name = TimerManagerProvider
# app.timer.provider.3.prop.description = Default TimerManager Provider
# app.timer.provider.3.prop.isolatedClassLoader = false

# app.timer.provider.3.timermanager.1.name = DefaultTimerManager
# app.timer.provider.3.timermanager.1.prop.description = WebSphere Default TimerManager
# app.timer.provider.3.timermanager.1.prop.jndiName = tm/default
# app.timer.provider.3.timermanager.1.prop.numAlarmThreads = 2
# app.timer.provider.3.timermanager.1.resourceProperties.prop.lateTimerTime = java.lang.String|false|15
#
# app.timer.provider.3.timermanager.count = 1
# app.timer.provider.count = 1
################################################################################

#-------------------------------------------------------------------------------
# processIndividualTimerManagerSettings
#
# Parameters
#   timerConfig - dictionary with timer properties
#   prefix - property key prefix to use with this timermanagerinfo (e.g. "app.timer.provider.1.timermanager.1")
#   pName - name of provider
#   pCluster - scope setting  (cluster)
#   pNode - scope setting (node)
#   pServer - scope setting (server or dynamic cluster template)
#   pDynamic - scope setting (dynamic cluster)
#   scopeInfo - formatted scope string for logging purposes
#-------------------------------------------------------------------------------
def processIndividualTimerManagerSettings(timerConfig,prefix,providerId,pName,timerName,pCluster,pNode,pServer,pDynamic,scopeInfo):
  _app_entry("processIndividualTimerManagerSettings(timerConfig,%s,%s,%s,%s,%s,%s,%s,%s)" % (prefix,providerId,timerName,pCluster,pNode,pServer,pDynamic,scopeInfo))

  try:
    # See if the timer exists
    timerId = getTimerManagerAtScope(timerName,pCluster,pNode,pServer,pDynamic,providerName=pName)
    if (not isEmpty(timerId)):
      
      
      existingProps = getTimerManagerProperties(timerId)
      
      baseProps = getPropListDifferences(timerConfig,prefix,existingProps,"timermanager")
      resourceProps = getPropListDifferences(timerConfig,"%s.resourceProperties" % prefix,
                                             existingProps, "timermanager.resourceProperties")
      
      if (len(baseProps) > 0 or len(resourceProps) > 0):
        updateTimerManager(timerId,baseProps,resourceProps)
        _app_message("TimerManager %s at scope %s has been updated" % (timerName,scopeInfo))
      else:
        _app_message("No updates required for TimerManager %s at scope %s" % (timerName,scopeInfo))
    else:
      baseProps = getPropList(timerConfig,prefix)
      resourceProps = getPropList(timerConfig,"%s.resourceProperties"% prefix)
      timerId = createTimerManager(providerId,timerName,baseProps,resourceProps)
      
      _app_message("TimerManager %s has been created at scope %s" % (timerName,scopeInfo))
  except:
    _app_exception("Unexpected problem in processIndividualTimerManagerSettings()")
  
  _app_exit("processIndividualTimerManagerSettings()")


#-------------------------------------------------------------------------------
# processTimerManagerProviderSettings
#
# Process the settings for an individual provider.
#
# Parameters
#   timerConfig - dictionary with timer properties
#   prefix - property key prefix to use with this provider (e.g. "app.timer.provider.1")
#   pName - name of provider
#   pCluster - scope setting  (cluster)
#   pNode - scope setting (node)
#   pServer - scope setting (server or dynamic cluster template)
#   pDynamic - scope setting (dynamic cluster)
#-------------------------------------------------------------------------------
def processTimerManagerProviderSettings(timerConfig,prefix,pName,pCluster,pNode,pServer,pDynamic):
  _app_entry("processTimerManagerProviderSettings(timerConfig,%s,%s,%s,%s,%s,%s)" % (pName,prefix,pCluster,pNode,pServer,pDynamic))
  
  try:
    # Lets confirm the scope is correct
    scopeInfo = scopeInfoString(pCluster,pNode,pServer,pDynamic)
    
    providerId = getTimerManagerProviderAtScope(pName,pCluster,pNode,pServer,pDynamic)
    if (isEmpty(providerId)):
      raise StandardError("No TimerManagerProvider found at scope: %s" % scopeInfo)
    else:
      tmCount = int(timerConfig.get("%s.timermanager.count" % prefix,0))
      if (tmCount > 0):
        for idx in range(1,tmCount+1):
          tPrefix = "%s.timermanager.%d" % (prefix,idx)
          timerName = timerConfig.get("%s.name" % tPrefix)
          if (isEmpty(timerName)):
            # partial list
            continue
          
          # Process timer settings
          processIndividualTimerManagerSettings(timerConfig,tPrefix,providerId,pName,timerName,pCluster,pNode,pServer,pDynamic,scopeInfo)
      
  except:
    _app_exception("Unexpected problem in processTimerManagerProviderSettings()")
  
  _app_exit("processTimerManagerProviderSettings()")
  

#-------------------------------------------------------------------------------
# processTimerManagerSettings
#
# Parameters
#   timerConfig - dictionary with timer properties
#----------------------------------------------------------------------------
def processTimerManagerSettings(timerConfig):
  _app_entry("processTimerManagerSettings(timerConfig)")
  retval = None
  try:
      providerCount = int(timerConfig.get("app.timer.provider.count",0))
      if (providerCount > 0):
        for idx in range(1,providerCount+1):
          prefix = "app.timer.provider.%d" % idx
          
          if (not checkForPrefix(timerConfig,prefix)):
            # partial list
            continue
          
          pCluster = timerConfig.get("%s.cluster"%prefix,None)
          pNode = timerConfig.get("%s.node"%prefix,None)
          pServer  = timerConfig.get("%s.server"%prefix,None)
          pDynamic =timerConfig.get("%s.dynamicCluster"%prefix,None)
          
          # Name should always be the same, but just in case
          pName = timerConfig.get("%s.name" % prefix, "TimerManagerProvider")
          
          processTimerManagerProviderSettings(timerConfig,prefix,pName,pCluster,pNode,pServer,pDynamic)
     
  except:
    _app_exception("Unexpected problem in processTimerManagerSettings()")
  
  _app_exit("processTimerManagerSettings()")
  return retval
  