#--------------------------------------------------------------------------------
# ProcessURL.py
#
# This module handles the processing of configuration properties for URLProvider
# and URL resources.
#
# Primary entry point: 
#   processURL()
#
# Related modules:
#   Utils.py
#   URL.py
#   
# Example property sytnax
#
# The following example shows the property syntax used to process the URL 
# resource settings. To see the configuration properties for an existing cell,
# use the dumpConfig.py script with the -url option.
#
#
# app.url.provider.1.cluster = MessagingClusterOne
# app.url.provider.1.node = 
# app.url.provider.1.server = 
# 
# app.url.provider.1.name = Default URL Provider
# app.url.provider.1.prop.isolatedClassLoader = false
# app.url.provider.1.prop.protocol = unused
# app.url.provider.1.prop.streamHandlerClassName = unused
#
# app.url.provider.1.url.1.name = file1
# app.url.provider.1.url.1.prop.description = Location of my file
# app.url.provider.1.url.1.prop.jndiName = url/file1
# app.url.provider.1.url.1.prop.spec = file:///appfiles/myfile.txt
#
# # Resource properties usually not set but supported
# app.url.provider.1.url.1.resourceProperties.prop.CustomProperty1 = java.lang.String|false|value1
#
# app.url.provider.1.url.2.name = file2
# app.url.provider.1.url.2.prop.description = Location of my file
# app.url.provider.1.url.2.prop.jndiName = url/file2
# app.url.provider.1.url.2.prop.spec = file://localhost//appfiles/myfile.txt
#
# app.url.provider.1.url.count = 2
# ...
# app.url.provider.count = n
#

#--------------------------------------------------------------------------------
# processURLSettings
#
# Processes the configuration settings for a single URL resource
#--------------------------------------------------------------------------------
def processURLSettings(urlConfigInfo,providerId,prefix,scopeInfo):
  try:
    urlName = urlConfigInfo.get("%s.name" % prefix)
    if (not isEmpty(urlName)):
      # See if URL is already defined
      urlId = findURL(providerId,urlName)
      if (urlId):
        # See if we need to do updates
        existingProps = getURLProperties(urlId)
        urlProps = getPropListDifferences(urlConfigInfo,prefix,existingProps,"url")
        resourceProps = getPropListDifferences(urlConfigInfo,"%s.resourceProperties" % prefix,existingProps,"url.resourceProperties")
        if (len(urlProps) > 0 or len(resourceProps) > 0):
          modifyURL(urlId,urlProps,resourceProps)
          _app_message("Modified URL %s at scope %s" % (urlName,scopeInfo))
        else:
          _app_message("No need to modify URL %s at scope %s" % (urlName,scopeInfo))
      else:
        # Create this URL
        urlProps = getPropList(urlConfigInfo,prefix)
        resourceProps = getPropList(urlConfigInfo,"%s.resourceProperties" % prefix)
        urlId = createURL(providerId,urlName,urlProps,resourceProps)
        _app_message("Created URL %s at scope %s" % (urlName,scopeInfo))
        
  except:
    _app_exception("Unexpected error in processURL")

#--------------------------------------------------------------------------------
# processURLProvider
#
# Processes the settings for a single URLProvider and the URLs defined under it
#--------------------------------------------------------------------------------
def processURLProvider(urlConfigInfo,providerName,prefix):
  try:
    providerName = urlConfigInfo.get("%s.name"%prefix,"")
    if (not isEmpty(providerName)):
      # Pull scope settings
      cluster = urlConfigInfo.get("%s.cluster" % prefix)
      dynamicCluster = urlConfigInfo.get("%s.dynamicCluster" % prefix)
      node = urlConfigInfo.get("%s.node" % prefix)
      server = urlConfigInfo.get("%s.server" % prefix)
      
      scopeInfo = scopeInfoString(cluster,node,server,dynamicCluster)
      
      # See if the provider exists
      providerId = findURLProvider(providerName,cluster,node,server,dynamicCluster)
      if (not isEmpty(providerId)):
        _app_message("Provider %s exists at scope %s" % (providerName,scopeInfo))
        existingProps = getURLProviderProperties(providerId)
        providerProps = getPropListDifferences(urlConfigInfo,prefix,existingProps,"url.provider")
        resourceProps = getPropListDifferences(urlConfigInfo,"%s.resourceProperties" % prefix, existingProps,"url.provider.resourceProperties")
        if (len(providerProps) > 0 or len(resourceProps) > 0):
          modifyURLProvider(providerId,providerProps,resourceProps)
      else:
        _app_message("Provider %s does not exist at scope %s" % (providerName,scopeInfo))
        providerProps = getPropList(urlConfigInfo,prefix)
        resourceProps = getPropList(urlConfigInfo,"%s.resourceProperties" % prefix)
        providerId = createURLProvider(providerName,cluster,node,server,dynamicCluster,providerProps,resourceProps)
        _app_message("Provider %s created at scope %s" % (providerName,scopeInfo))
        
        
      
      # Now process URL defs
      urlCount = int(urlConfigInfo.get("%s.url.count" % prefix,"0"))
      if (urlCount > 0):
        for idx in range(1,urlCount+1):
          urlPrefix = "%s.url.%d" % (prefix,idx)
          processURLSettings(urlConfigInfo,providerId,urlPrefix,scopeInfo)
  except:
    _app_exception("Unexpected error in processURLProvider")


#--------------------------------------------------------------------------------
# processURL
#
# The primary entry point for this module. It will loop through the configuration
# settings in the urlConfigInfo dictionary and proces
#--------------------------------------------------------------------------------
def processURL(urlConfigInfo):
  try:
    providerCount = int(urlConfigInfo.get("app.url.provider.count","0"))
    if (providerCount > 0):
      for idx in range(1,providerCount+1):
        prefix = "app.url.provider.%d" % idx
        providerName = urlConfigInfo.get("%s.name"%prefix,"")
        if (not isEmpty(providerName)):
            processURLProvider(urlConfigInfo,providerName,prefix)
  except:
    _app_exception("Unexpected error in processURL")
  