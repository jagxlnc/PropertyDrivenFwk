##########################################################################
# File Name:    SIBJMSConnectionFactory.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere SIB JMS Connection Factories
#
#               createSIBJMSConnectionFactory
#               deleteSIBJMSConnectionFactory
#               listSIBJMSConnectionFactories
#               modifySIBJMSConnectionFactory
#
#
# WASX8006I: Detailed help for command: createSIBJMSConnectionFactory
#
#Description: Create a SIB JMS connection factory at the scope identified by the target object.
#
#*Target object: Scope at which to create the SIB JMS connection factory.
#
#Arguments:
# *name - The name of the SIB JMS connection factory.
# *jndiName - The JNDI name of the SIB JMS connection factory.
#  type - Type of connection factory to create. To create a queue connection factory, set to "Queue". To create a topic connection factory, set to "Topic". Leave unset to create a generic connection factory.
#  authDataAlias - Specifies a user ID and password to be used to authenticate connections to the JMS provider for application-managed authentication.
#  containerAuthAlias - Specifies a container managed authentication alias, from which security credentials are to be used when establishing a connection to the JMS provider.
#  mappingAlias - Specifies the JAAS mapping alias to use when determining the security related credentials to use when establishing a connection to the JMS provider.
#  xaRecoveryAuthAlias - The authentication alias used during XA recovery processing.
#  category - Classifies or groups the connection factory.
#  description - Description of the connection factory.
#  logMissingTransactionContext - Whether or not the container logs that there is a missing transaction context when a connection is obtained.
#  manageCachedHandles - Whether cached handles (handles held in instance variables in a bean) should be tracked by the container.
# *busName - The bus name.
#  clientID - User-defined string, only required for durable subscriptions.
#  userName - The user name that is used to create connections from the connection factory.
#  password - The password that is used to create connections from the connection factory.
#  nonPersistentMapping - Non-persistent mapping value. Legal values are "BestEffortNonPersistent", "ExpressNonPersistent", "ReliableNonPersistent", 
#                          "ReliablePersistent", "AssuredPersistent", "AsSIBDestination" and "None".
#  persistentMapping - Persistent mapping value. Legal values are "BestEffortNonPersistent", "ExpressNonPersistent", "ReliableNonPersistent", "ReliablePersistent",
#                          "AssuredPersistent", "AsSIBDestination" and "None".
#  durableSubscriptionHome - Durable subscription home value.
#  readAhead - Read-ahead value. Legal values are "Default", "AlwaysOn" and "AlwaysOff".
#  target - The name of a target that resolves to a group of messaging engines.
#  targetType - Specifies the type of the name in the target parameter. Legal values are "BusMember", "Custom" and "ME".
#  targetSignificance - This property specifies the significance of the target group.
#  targetTransportChain - The name of the protocol that should be used to connect to a remote messaging engine.
#  providerEndPoints - A comma-separated list of endpoint triplets of the form "host:port:chain".
#  connectionProximity - The proximity of acceptable messaging engines. Legal values are "Bus", "Host", "Cluster" and "Server".
#  tempQueueNamePrefix - Temporary queue name prefix.
#  tempTopicNamePrefix - Temporary topic name prefix.
#  shareDataSourceWithCMP - Used to control how data sources are shared.
#  shareDurableSubscriptions - Used to control how durable subscriptions are shared. Legal values are "InCluster", "AlwaysShared" and "NeverShared".
#  consumerDoesNotModifyPayloadAfterGet - When enabled, Object/Bytes Messages received by a message consuming application that has connected to the bus using this 
#             connection factory will only have their message data serialized by the system when absolutely necessary. The data obtained from those messages must be treated
#             as readOnly by applications. Legal values are "true" and "false" (default).
#  producerDoesNotModifyPayloadAfterSet - When enabled, Object/Bytes Messages sent by a message producing application that has connected to the bus using this 
#             connection factory will not have their data copied when set and the system will only serialize the message data when absolutely necessary. Applications 
#             sending such messages must not modify the data once it has been set into the message. Legal values are "true" and "false" (default).
##########################################################################

##########################################################################
#
# FUNCTION:
#    createSIBJMSConnectionFactory: Create a SIB JMS Connection Factory
#
# SYNTAX:
#    createSIBJMSConnectionFactory name, (cluster|node, server), bus
#
# PARAMETERS:
#    name - Name for SIB JMS Connection Factory entry
#    cluster  - Name of cluster for cluster scoped provider
#    node - Name of node for server scoped provider
#    server - Name of server for server scoped provider
#    bus  - Name of bus for this CF
#    factoryAttrs - property set of attributes for factory
#    connPool - property set of attributes for connection pool
#    connPoolCustom - property set for for connection pool custom properties
#
# USAGE NOTES:
#    Creates a SIB JMS Connection Factory on the bus at the desired scope.  
#
# RETURNS:
#    ObjID  Object ID of new appserver
#    None Failure
#
# THROWS:
#    N/A
##########################################################################
def createSIBJMSConnectionFactory(name, cftype, cluster, node, server, bus, factoryAttrs, connPool, connPoolCustom = None,mappingAttrs=None):

  global progInfo

  retval = None
  
  parmMap = { 'providerEndpoints': '-providerEndPoints', 'temporaryTopicNamePrefix' : '-tempTopicNamePrefix', 'temporaryQueueNamePrefix': '-tempQueueNamePrefix'}
  dashParmsV7 = ['name' , 'logMissingTransactionContext' , 'password' , 'readAhead','durableSubscriptionHome' , 'shareDurableSubscriptions' , 'targetTransportChain' , 'authDataAlias' , 'userName' , 'targetSignificance' , 'shareDataSourceWithCMP' , 'persistentMapping' , 'nonPersistentMapping' , 'jndiName' , 'clientID' , 'manageCachedHandles' , 'consumerDoesNotModifyPayloadAfterGet' , 'category'  , 'targetType' , 'xaRecoveryAuthAlias' , 'description' , 'connectionProximity' , 'producerDoesNotModifyPayloadAfterSet' , 'target' ]
  dashParmsV6 = ['name' , 'logMissingTransactionContext' , 'password' , 'readAhead','durableSubscriptionHome' , 'shareDurableSubscriptions' , 'targetTransportChain' , 'authDataAlias' , 'userName' , 'targetSignificance' ,  'shareDataSourceWithCMP' , 'persistentMapping' , 'nonPersistentMapping' , 'jndiName' , 'clientID' , 'manageCachedHandles' , 'category'  , 'targetType' , 'xaRecoveryAuthAlias' , 'description' , 'connectionProximity' , 'target' ]


  try:
    traceStr = "createSIBJMSConnectionFactory(%s, %s, %s, %s, %s, %s, %s, %s, %s)" % (name, cluster, node, server, bus, factoryAttrs, connPool,connPoolCustom,mappingAttrs)
    _app_trace(traceStr, "entry") 
    
    # v7,v8,v8.5 same
    dashParms = dashParmsV7
    
    if ( progInfo["dmgrVersion"].startswith("6")):
        dashParms = dashParmsV6

    # Check function parameters
    configID = getContainmentPath(cluster, node, server)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to create SIB JMS Connection Factory at" % (configID))
      
    if isEmpty(bus):
      raise StandardError("SIBus Name not specified")
      
    if not objectExists("SIBus", None, bus):
      raise StandardError("SIBus %s does not exist" % (bus))
      
    # If object already exists, warn and exit
    j2craID = configID + "J2CResourceAdapter:SIB JMS Resource Adapter/"

    if objectExists("J2CConnectionFactory", j2craID, name):
      raise StandardError("SIB JMS Connection Factory %s already exists at scope %s" % (name, configID))

    parentID  = AdminConfig.getid(configID)

    if isEmpty(parentID):
      raise StandardError("Cannot find ID; check cluster or node/server and SIB values are correct")
      
    _app_trace("Got parent ID = " + parentID)

    attributes = None
    if (name.find(" ") > 0 and not name.startswith('"') and not name.startswith("'")):
      attributes  = " -name '%s'" % (name)
    else:
      attributes  = " -name %s" % (name)
    
    if (not isEmpty(cftype)):
        attributes += " -type %s" % (cftype)
    attributes += ' -busName "%s"' % (bus)
    
    for key in factoryAttrs.keys():
      val = factoryAttrs.get(key)
      if (val == ""):
          continue
      if (key == "description"):
          if not val.startswith('"'):
              val = '"%s"' % val
      
      newkey = parmMap.get(key,"")
      if (newkey == ""):
          if key in dashParms:
              newkey = "-%s" % key
      
      if (val.find(' ') >= 0):
        if (not val.startswith('"') and not val.startswith("'") ) :
          val = '"%s"' % val
      
      if (newkey != ""):
          attributes += " %s %s" % (newkey, val)
      else:
          _app_trace("Skipping input property %s %s" % (key,val))

    _app_trace("Running command: AdminTask.createSIBJMSConnectionFactory(%s, %s)" % (parentID, attributes))
    AdminTask.createSIBJMSConnectionFactory(parentID, attributes)

    if (name.startswith('"') or name.startswith("'")):
      j2craID += "J2CConnectionFactory:%s/" % (name[1:-1])
    else:
      j2craID += "J2CConnectionFactory:%s/" % (name)
      
    newcf = AdminConfig.getid(j2craID)
    _app_trace("Got J2CConnectionFactory ID for %s = %s" % (name, newcf))

    if isEmpty(newcf):
      raise StandardError("Cannot get ID for new SIB JMS Connection Factory %s" % (name))

    if (mappingAttrs != None and len(mappingAttrs) > 0):
      mappingId = AdminConfig.showAttribute(newcf,"mapping")
      attrs = []
      for key in mappingAttrs.keys():
        attrs.append( [key, mappingAttrs.get(key) ])
        
        
      if (isEmpty(mappingId)):
        # Need to create
        _app_trace('About to call AdminConfig.create("MappingModule",%s,%s)' % (cfid,attrs))
        AdminConfig.create("MappingModule",cfid,attrs)
      else:
        if (modifyObject(mappingId,attrs)):
          raise StandardError("Problem updating mapping attributes for %s %s" % (cfid,attrs))


      
    # Now create Connection Pool
    poolSettings = []
    for key in connPool.keys():
        val = connPool.get(key)
        poolSettings.append([key,val])
        
    _app_trace("Running command: AdminConfig.create('ConnectionPool', %s, %s)" % (newcf, poolSettings))
    connPoolId = AdminConfig.create('ConnectionPool', newcf, poolSettings)
    
    
    # See if the connection pool has custom properties
    if (connPoolCustom != None and connPoolCustom.size() > 0):
        errmsg = updateCustomProperties(connPoolId, "properties", "Property", connPoolCustom)
        if (not isEmpty(errmsg)):
            raise StandardError("Error creating connection pool custom properties: %s" % errmsg)
    
    
    retval = newcf

    _app_trace("Created connection pool successfully")

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered creating the SIB JMS Connection Factory", "exception")
    retval = None

  _app_trace("createSIBJMSConnectionFactory(%s)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    modifySIBJMSConnectionFactory: Modify a SIB JMS Connection Factory
#
# SYNTAX:
#    modifySIBJMSConnectionFactory name, (cluster|node, server), bus
#
# PARAMETERS:
#    name - Name for SIB JMS Connection Factory entry
#    cftype - Queue, Topic, or "" for generic (Used only for searching)
#    cluster  - Name of cluster for cluster scoped provider
#    node - Name of node for server scoped provider
#    server - Name of server for server scoped provider
#    bus  - Name of bus for this CF
#    factoryAttrs - property set of attributes for factory
#    connPool - property set of attributes for connection pool
#    connPoolCustom - property set for for connection pool custom properties
#
# USAGE NOTES:
#    Modifies a SIB JMS Connection Factory on the bus at the desired scope.  
#
# RETURNS:
#    ObjID  Object ID of new appserver
#    None Failure
#
# THROWS:
#    N/A
##########################################################################
def modifySIBJMSConnectionFactory(name, cftype, cluster, node, server, factoryAttrs, connPool, connPoolCustom = None,mappingAttrs=None):

  global progInfo

  retval = None

  parmMap = { 'providerEndpoints': '-providerEndPoints', 'temporaryTopicNamePrefix' : '-tempTopicNamePrefix', 'temporaryQueueNamePrefix': '-tempQueueNamePrefix'}
  dashParmsV7 = ['name' , 'logMissingTransactionContext' , 'password' , 'readAhead' ,'durableSubscriptionHome', 'shareDurableSubscriptions' , 'targetTransportChain' , 'authDataAlias' , 'userName' , 'targetSignificance' , 'shareDataSourceWithCMP' , 'persistentMapping' , 'nonPersistentMapping' , 'jndiName' , 'clientID' , 'manageCachedHandles' , 'consumerDoesNotModifyPayloadAfterGet' , 'category'  , 'targetType' , 'xaRecoveryAuthAlias' , 'description' , 'connectionProximity' , 'producerDoesNotModifyPayloadAfterSet' , 'target' ]
  dashParmsV6 = ['name' , 'logMissingTransactionContext' , 'password' , 'readAhead' ,'durableSubscriptionHome', 'shareDurableSubscriptions' , 'targetTransportChain' , 'authDataAlias' , 'userName' , 'targetSignificance' ,  'shareDataSourceWithCMP' , 'persistentMapping' , 'nonPersistentMapping' , 'jndiName' , 'clientID' , 'manageCachedHandles' , 'category'  , 'targetType' , 'xaRecoveryAuthAlias' , 'description' , 'connectionProximity' , 'target' ]


  try:
    traceStr = "modifySIBJMSConnectionFactory(%s, %s, %s, %s, %s, %s, %s,%s)" % (name, cluster, node, server, factoryAttrs, connPool,connPoolCustom,mappingAttrs)
    _app_trace(traceStr, "entry") 

    # Check function parameters
    configID = getContainmentPath(cluster, node, server)
    
    dashParms = dashParmsV7
    if ( progInfo["dmgrVersion"].startswith("6")):
        dashParms = dashParmsV6
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to create SIB JMS Connection Factory at" % (configID))
      
    cfid = findSIBMJMSConnectionFactoryId(cluster,node,server,name, cftype)
    
    if (isEmpty(cfid)):
      raise StandardError("Unable to find connection factory ID %s %s" % (cftype,name))
    
    attributes  = "" 
    
    for key in factoryAttrs.keys():
      val = factoryAttrs.get(key)
      if (val == ""):
          continue
      if (key == "description"):
          if not val.startswith('"'):
              val = '"%s"' % val
      
      newkey = parmMap.get(key,"")
      if (newkey == ""):
          if key in dashParms:
              newkey = "-%s" % key
      
      if (newkey != ""):
          if (val.find(' ') >= 0):
            if (not val.startswith('"') and not val.startswith("'") ) :
              val = '"%s"' % val
          attributes += " %s %s" % (newkey, val)
      else:
          _app_trace("Skipping input property %s %s" % (key,val))

    if (not isEmpty(attributes)):
      _app_trace("Running command: AdminTask.modifySIBJMSConnectionFactory(%s, %s)" % (cfid, attributes))
      AdminTask.modifySIBJMSConnectionFactory(cfid, attributes)
    
    if (mappingAttrs != None and len(mappingAttrs) > 0):
      mappingId = AdminConfig.showAttribute(cfid,"mapping")
      attrs = []
      for key in mappingAttrs.keys():
        attrs.append( [key, mappingAttrs.get(key) ])
        
        
      if (isEmpty(mappingId)):
        # Need to create
        _app_trace('About to call AdminConfig.create("MappingModule",%s,%s)' % (cfid,attrs))
        AdminConfig.create("MappingModule",cfid,attrs)
      else:
        if (modifyObject(mappingId,attrs)):
          raise StandardError("Problem updating mapping attributes for %s %s" % (cfid,attrs))

      
    # Now update Connection Pool
    poolSettings = []
    for key in connPool.keys():
        val = connPool.get(key)
        poolSettings.append([key,val])
    
    connPoolId = AdminConfig.showAttribute(cfid, "connectionPool")
    if (isEmpty(connPoolId)):
        _app_trace("Running command: AdminConfig.create('ConnectionPool', %s, %s)" % (cfid, poolSettings))
        connPoolId = AdminConfig.create('ConnectionPool', cfid, poolSettings)
    elif (len(poolSettings) > 0):
        if (modifyObject(connPoolId,poolSettings)):
            raise StandardError("Problem updating connection pool for factory %s" % name)
    
    
    
    # See if the connection pool has custom properties
    if (connPoolCustom != None and connPoolCustom.size() > 0):
        errmsg = updateCustomProperties(connPoolId, "properties", "Property", connPoolCustom)
        if (not isEmpty(errmsg)):
            raise StandardError("Error creating connection pool custom properties: %s" % errmsg)
    
    
    retval = cfid

    _app_trace("Updated connection pool successfully")

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered modifying the SIB JMS Connection Factory", "exception")
    retval = None

  _app_trace("modifySIBJMSConnectionFactory(%s)" %(retval), "exit")
  return retval

  
##########################################################################
#
# FUNCTION:
#    deleteSIBJMSConnectionFactory: Delete a SIB JMS Connection Factory
#
# SYNTAX:
#    deleteSIBJMSConnectionFactory name, cluster|(node, server)
#
# PARAMETERS:
#    name - Name for SIB JMS Connection Factory entry
#    cluster  - Name of cluster for cluster scoped provider
#    node - Name of node for server scoped provider
#    server - Name of server for server scoped provider
#    configID - known configuration ID if available, otherwise it
#               will be looked up
#
# USAGE NOTES:
#    Deletes a SIB JMS Connection Factory from the desired scope.  

# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBJMSConnectionFactory(name, cluster, node, server,configID=None):
  deleteSIBJMSConnectionFactory(name, cluster, node, server,configID)
  
def deleteSIBJMSConnectionFactory(name, cluster, node, server,configID=None):

  global progInfo

  retval = 1

  try:
    traceStr = "deleteSIBJMSConnectionFactory(%s, %s, %s, %s, %s)" % (name, cluster, node, server, configID)
    _app_trace(traceStr, "entry") 

    if (isEmpty(configID)):
      
      # Check function parameters
      configIDPath = getContainmentPath(cluster, node, server)
      
      if isEmpty(configIDPath):
        raise StandardError("Could not get containment path")
      
      if isEmpty(AdminConfig.getid(configIDPath)):
        raise StandardError("No such target as %s to delete SIB JMS Connection Factory from" % (configID))
        
      if isEmpty(name):
        raise StandardError("SIBus Name not specified")   
      
      # If object doesn't exist, warn and exit
      configIDPath += "J2CResourceAdapter:SIB JMS Resource Adapter/"
  
      if not objectExists("J2CConnectionFactory", configIDPath, name):
        raise StandardError("SIB JMS Connection Factory %s does not exist at scope %s" % (name, configID))
  
      configIDPath += "J2CConnectionFactory:%s/" % (name)
      configID  = AdminConfig.getid(configIDPath)
  
      if isEmpty(configID):
        raise StandardError("Cannot find ID; check cluster or node/server and SIB values are correct")
    #endif
    
    _app_trace("Got J2CConnectionFactory ID = " + configID)
    _app_trace("Running command: AdminTask.deleteSIBJMSConnectionFactory(%s)" % (configID))

    AdminTask.deleteSIBJMSConnectionFactory(configID)

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()
      
    retval = 0
  except:
    _app_trace("An error was encountered creating the SIB JMS Connection Factory", "exception")
    retval = 1

  _app_trace("deleteSIBJMSConnectionFactory(%d)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    listSIBJMSConnectionFactories: List SIB JMS Connection Factories at scope
#
# SYNTAX:
#    listSIBJMSConnectionFactories cluster| (node, server), displayFlag
#
# PARAMETERS:
#    cluster  - Name of cluster for cluster scoped provider
#    node - Name of node for server scoped provider
#    server - Name of server for server scoped provider
#    displayFlag- Boolean indicating whether to print list 
#     (default = 1)
#
# USAGE NOTES:
#    Lists SIB JMS Connection Factorys at the desired scope.  
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showSIBJMSConnectionFactories(cluster, node, server, displayFlag = 1):
  listSIBJMSConnectionFactories(cluster, node, server, displayFlag)
  
def listSIBJMSConnectionFactories(cluster, node, server, displayFlag = 1):

  global progInfo
  
  retval = None
  
  try:
    traceStr = "listSIBJMSConnectionFactories(%s, %s, %s, %d)" % (cluster, node, server, displayFlag)
    _app_trace(traceStr, "entry") 

    # Check function parameters
    configID = getContainmentPath(cluster, node, server)

    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to list SIB JMS Connection Factories at" % (configID))
      
    # Get the parentID
    parentID = AdminConfig.getid(configID)

    _app_trace("Running command: AdminTask.listSIBJMSConnectionFactories(%s)" % (parentID))
    str = AdminTask.listSIBJMSConnectionFactories(parentID)

    if isEmpty(str):
      retval = []
    else:
      retval = str.split(progInfo["line.separator"])

    if displayFlag:
      print "\nSI Bus JMS Connection Factories\n-------------------"

      for r in retval:
        print AdminConfig.showAttribute(r, "name")

      print "-------------------"

  except:
    _app_trace("An error was encountered listing the SIB JMS Connection Factories", "exception")
    retval = None

  _app_trace("listSIBJMSConnectionFactories(%s)" %(retval), "exit")
  return retval



#----------------------------------------------------------------------------------------------------------------------------
# findSIBMJMSConnectionFactoryId
#    Returns the ID of the connection factory
#
#
def findSIBMJMSConnectionFactoryId(cluster,node,server,name, type):
  
  _app_trace("findSIBMJMSConnectionFactoryId(%s,%s,%s,%s,%s)" % (cluster,node,server,name, type),"entry")
  global progInfo
  result = None
  
  
  try:
  
    # See if the factory exists
    cflist = []
    shortName = name
    if (name.startswith('"') or name.startswith("'")):
      shortName = name[1:-1]
        
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        if (not isEmpty(type)):
            parms = "-type %s" % type
        else:
            parms = ""
            type = "generic"
        cflist = AdminTask.listSIBJMSConnectionFactories(scopeId,parms).split(progInfo["line.separator"])
        
    # Find the factory with the name
    for cf in cflist:
        if (not isEmpty(cf)):
          if (cf.find(shortName) >= 0):
            cfname = AdminConfig.showAttribute(cf,"name")
            if (name != cfname and cfname != shortName):
                continue
            else:
                result = cf
                break
                

  except:
    _app_trace("Unexpected error searching for SIBJMSConnectionFactory","exception")
    result = None
  
  _app_trace("findSIBMJMSConnectionFactoryId(result=%s)" % result,"exit")  
  return result

#----------------------------------------------------------------------------------------------------------------------------
# findMatchingSIBMJMSConnectionFactoryIds
#    Returns the connection factories at the specified scope that match the name pattern. The results
#    are returned in a dictionary where ConnectionFactoryName = ID
#
#
def findMatchingSIBMJMSConnectionFactoryIds(cluster,node,server,namePattern, jmstype):
  
  _app_trace("findMatchingSIBMJMSConnectionFactoryIds(%s,%s,%s,%s,%s)" % (cluster,node,server,namePattern, jmstype),"entry")
  global progInfo
  result = None
  
  import re
  retval = {}
  
  try:
  
    # See if the factory exists
    cflist = []
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        if (not isEmpty(jmstype)):
            parms = "-type %s" % jmstype
        else:
            parms = ""
            jmstype = "generic"
        cflist = AdminTask.listSIBJMSConnectionFactories(scopeId,parms).split(progInfo["line.separator"])
        
    # Find the factory with the name
    for cf in cflist:
        if (not isEmpty(cf)):
            cfname = AdminConfig.showAttribute(cf,"name")
            if (namePattern.find("*") >= 0):
              # Regular express
              if (re.match(namePattern,cfname)):
                # Add ID to result list
                retval[cfname] = cf
            else:
              if (namePattern == cfname):
                retval[cfname] = cf
  except:
    _app_trace("Unexpected error searching for SIBJMSConnectionFactory","exception")
    raise StandardError("Unexpected error searching for SIBJMSConnectionFactory")
  
  _app_trace("findMatchingSIBMJMSConnectionFactoryIds(retval = %s)" % (retval),"exit")  
  return retval




#----------------------------------------------------------------------------------------------------------------------------
# getSIBMJMSConnectionFactoryProperties:
# Get properties for an existing SIBJMS connection factory
# Returns connection factory, connection pool and pool custom properties for Generic, Queue, or Topic connection factories with the 
# corresponding prefix:  genericConnectionFactory, queueConnectionFactory, or topicConnectionFactory
#
#
def getSIBMJMSConnectionFactoryProperties(cluster,node,server,name, cftype, checkSettingsOverride = 0):

  global progInfo
  
    
  result = None
  
  try:
  
    _app_trace("getSIBMJMSConnectionFactoryProperties(%s,%s,%s,%s,%s,%d)" % (cluster,node,server,name, cftype,checkSettingsOverride), "entry")
  
    result = java.util.Properties()
  
    # See if the factory exists
    cflist = []
    shortName = name
    if (name.startswith('"') or name.startswith("'")):
      shortName = name[1:-1]
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        if (not isEmpty(cftype)):
            parms = "-type %s" % cftype
        else:
            parms = ""
            cftype = "generic"
        
        _app_trace("About to call AdminTask.listSIBJMSConnectionFactories(%s,%s)" % (scopeId,parms))
        cflist = AdminTask.listSIBJMSConnectionFactories(scopeId,parms).split(progInfo["line.separator"])
        
    # Find the factory with the name
    for cf in cflist:
        if (not isEmpty(cf)):
          cfname = AdminConfig.showAttribute(cf,"name")
          if (name != cfname and shortName != cfname):
              continue
          
          prefix = "%sConnectionFactory" % cftype.lower()
          result.put("%s.name" % prefix, cfname)
          
          if (checkSettingsOverride or isCheckSettingsEnabled("sibjms")):
            # Note: turns oout that showSIBJMSConnectionFactory is very very slow
            # and it is much quicker to pull attributes and custom properties directly 
            # from the J2CAdminObject
            #
            # The only drawback from this approach is that the attribute names may 
            # have an uppercase starting character, which doesn't map to AdminTask.updateSIBJMSConnectionFactory
            # After collecting the properties, we'll need to transform the keys
            
            cftype = cftype.lower()
            prefix = "%sConnectionFactory" % cftype
            result.put("%s.name" % prefix, cfname)
            
            
            
            idProps = java.util.Properties()
            collectSimpleProperties(result, "%s.prop" % prefix ,cf,[],idProps)
            collectCustomProperties(result,prefix, idProps.get("%s.prop.propertySet"% prefix), "resourceProperties")
            tempKeys = []
            for key in result.keys():
              tempKeys.append(key)
            
            for key in tempKeys:
              propMapKey = key.split(".")[-1]
              
              #print propMapKey
              replaceKey = "%s%s" % (propMapKey[0].lower(), propMapKey[1:])
              if (not isEmpty(replaceKey)):
                replaceKey = "%s.prop.%s" % (prefix,replaceKey)
                val = result.get(key)
                #print "%s %s" % (replaceKey, val)
                result.put(replaceKey,val)  
                
            #_app_trace("About to call AdminTask.showSIBJMSConnectionFactory(%s)" % cf)
            #cftext = AdminTask.showSIBJMSConnectionFactory(cf)
            
            #_app_trace("Back from AdminTask.showSIBJMSConnectionFactory(retval = %s)" % cftext)
            
            #cfdict = wsadminToDictionary(cftext)
            
            
            #for key in cfdict.keys():
            #   if (key == "name"):
            #       continue
            #   val = cfdict[key]
            #   result.put("%s.prop.%s" % (prefix,key), val)
                
            cfConnectionPool = AdminConfig.showAttribute(cf,'connectionPool')
            if (not isEmpty(cfConnectionPool)):
                collectSimpleProperties(result,"%s.connectionPool.prop" % (prefix), cfConnectionPool)
                collectCustomPropertiesOrginal(result,"%s.connectionPool.customProperties" % (prefix), cfConnectionPool, "properties")
            
            mappingId = AdminConfig.showAttribute(cf,"mapping")
            if (not isEmpty(mappingId)):
                collectSimpleProperties(result,"%s.mapping.prop" % (prefix), mappingId)
                          
          # end if we should get properties
            
          # Get out of the loop now
          break       
  except:
    _app_trace("Unexpected error loading properties","exception")
    result = None
    
  _app_trace("getSIBMJMSConnectionFactoryProperties()", "exit")
  return result