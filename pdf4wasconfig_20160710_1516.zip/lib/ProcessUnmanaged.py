# ProcessUnmanaged.py
#
# Property syntax example:
#
# app.unmanagednode.1.nodeName = WebNode1
# app.unmanagednode.1.hostName = jjmwnode1
# app.unmanagednode.1.nodeOperatingSystem = linux
# app.unmanagednode.2.nodeName = WebNode2
# app.unmanagednode.2.hostName = jjmwnode2
# app.unmanagednode.2.nodeOperatingSystem = linux
# app.unmanagednode.count = 2
#
# NodeList syntax:
#s
# This alternative syntax allows the user to specify multiple unmanaged nodes in one line
# Useful with variable maps.  Syntax is:
# app.unmanagednode.[0-9]+.nodeList = <nodeName>/<hostName>/<os> [<nodeName2>/<hostName2>/<os2> ...]
#
# app.unmanagednode.1.nodeList = WebNode1/jjmnode1/linux WebNode2/jjmnode2/linux WebNode3/jjmnode3/linux WebNode5/jjmnode5/linux WebNode7/jjmnode7/linux
# app.unmanagednode.count = 1


#-------------------------------------------------------------------------------
# processSingleUnmanagedNode
#
# Parameters
#
#-------------------------------------------------------------------------------
def processSingleUnmanagedNode(nodeName,hostName,nodeos):
  _app_entry("processSingleUnmanagedNode(%s,%s,%s)" , nodeName,hostName,nodeos)
  retval = None
  try:
          # See if node exists
          nodeid = AdminConfig.getid("/Node:%s/"%nodeName)
          
          if (isEmpty(nodeid)):
          
              if (hostName == "" or nodeos == ""):
                  _app_message("Missing required settings to create unmanaged node %s" % nodeName)
                  exit()
                  
              # Go ahead and create managed node
              try:
                _app_trace("Calling AdminTask.createUnmanagedNode(-nodeName %s -hostName %s -nodeOperatingSystem %s)" % (nodeName, hostName, nodeos))
                AdminTask.createUnmanagedNode("-nodeName %s -hostName %s -nodeOperatingSystem %s" % (nodeName, hostName, nodeos))
                result = AdminConfig.getid("/Node:%s/"%nodeName)
              except:
                _app_trace("Unexpected errors in unmanaged node processing trying to create node %s" % nodeName, "exception")
                result = None
              
              
              if (isEmpty(result)):
                _app_message("Failed to create unmanaged node %s " % nodeName)
                exit()
              else:
                _app_message("Created unmanaged node %s" % nodeName)
          else:
              _app_message("Node %s is already defined" % nodeName)

  except:
    _app_exception("Unexpected problem in processSingleUnmanagedNode()")
  
  _app_exit("processSingleUnmanagedNode(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------------
# processSIB
#
# Pull the SIBus settings from the nodeConfigInfo dictionary and process them.
#-------------------------------------------------------------------------------------
def processUnmanaged(nodeConfigInfo):
  try:
    nodeCount = int(nodeConfigInfo.get("app.unmanagednode.count","0"))
    
    if (nodeCount > 0):
        for idx in range(1, nodeCount+1):
          prefix = "app.unmanagednode.%d" % idx
          
          
          nodeName = nodeConfigInfo.get("%s.nodeName"%prefix,"")
          
          nodeList = nodeConfigInfo.get("%s.nodeList"%prefix,"")
          print "Node list: %s" % nodeList
          
          
          if (nodeName == "" and nodeList == ""):
              # Possibly a partial configuration
              continue
          elif (not isEmpty(nodeList)):
            nodeSettingsList = nodeList.split(" ")
            for nodeSettingStr in nodeSettingsList:
              nodeSettings = nodeSettingStr.split("/")
              if (len(nodeSettings) == 3):
                nodeName = nodeSettings[0]
                hostName = nodeSettings[1]
                nodeos = nodeSettings[2]
                
                processSingleUnmanagedNode(nodeName,hostName,nodeos)
          else:
            hostName = nodeConfigInfo.get("%s.hostName"%prefix,"")
            nodeos = nodeConfigInfo.get("%s.nodeOperatingSystem" %prefix, "")
          
            processSingleUnmanagedNode(nodeName,hostName,nodeos)
          
  except:
    _app_trace("Unexpected errors in unmanaged node processing", "exception")
    _app_message("Unexpected errors in unmanaged node processing")
    exit()