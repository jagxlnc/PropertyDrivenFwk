##########################################################################################
# ObjectCache.py
#
# This module contains functions for finding/creating/modifying/fetching properties of 
# ObjectCacheInstance configurations.
#
# createObjectCache
# modifyObjectCache
# findObjectCacheInstanceWithName
# findObjectCacheInstanceAtScope
# findCacheProviderAtScope
# getObjectCacheProperties
##########################################################################################


#---------------------------------------------------------------------------
# createObjectCache
# 
# Create a new ObjectCacheInstance at the specified provider.
#
# Parameters:
#   providerId - Id of parent provider
#   cacheName - Name of cache to create
#   cacheProps - Properties object with key/values for ObjectCacheInstance
#   resourceProps - Properties object with values for J2EE Resource properties if the name=type|required|val|desc format
#   cacheReplicationProps - Properties set containing key/values for DRSSettings
#   diskCacheCustomPerformanceSettingsProps - Properties set containing key/values for DiskCacheCustomPerformanceSettings
#   diskCacheEvictionPolicyProps - Properties set containing key/values for DiskCacheEvictionPolicy
#   memoryCacheEvictionPolicyProps - Properties set containing key/values for MemoryCacheEvictionPolicy (v7)
#---------------------------------------------------------------------------
def createObjectCache(providerId, cacheName, cacheProps, resourceProps=None, cacheReplicationProps=None, diskCacheCustomPerformanceSettingsProps=None, diskCacheEvictionPolicyProps=None, memoryCacheEvictionPolicyProps=None):

	_app_trace("createObjectCache(%s,%s,%s,%s,%s,%s,%s,%s)" %( providerId, cacheName, cacheProps, resourceProps, cacheReplicationProps, diskCacheCustomPerformanceSettingsProps, diskCacheEvictionPolicyProps, memoryCacheEvictionPolicyProps),"entry")
	retval = None

	try:	
		 baseAttrs = "[name '%s']" % cacheName
		 for key in cacheProps.keys():
		 		val = cacheProps.get(key)
		 		baseAttrs = "%s [%s '%s']" % (baseAttrs,key,val)
		 
		 baseAttrs = "[ %s ]" % baseAttrs
		 _app_trace("About to call AdminConfig.create(ObjectCacheInstance, %s, %s)" % (providerId, baseAttrs))
		 cacheId = AdminConfig.create("ObjectCacheInstance", providerId, baseAttrs)
		 
		 # Add cache replication
		 if (cacheReplicationProps != None):
		 		subAttrs = ""
		 		for key in cacheReplicationProps.keys():
		 				val = cacheReplicationProps.get(key)
		 				subAttrs = "%s [%s '%s']"  % (subAttrs, key, val)
		 		
		 		if (subAttrs != ""):
		 				subAttrs = "[ %s ]" % subAttrs
		 				cacheReplicationId = AdminConfig.showAttribute(cacheId, "cacheReplication")
		 				if (isEmpty(cacheReplicationId)):
		 						# Need to create
		 						_app_trace("About to call AdminConfig.create(DRSSettings, %s,%s)" %( cacheId,subAttrs))
		 						cacheReplicationId = AdminConfig.create("DRSSettings", cacheId,subAttrs)
		 						_app_trace("cacheReplicationId = %s" % cacheReplicationId)
		 				else:
		 						# Need to update
		 						if (modifyObject(cacheReplicationId, subAttrs)):
		 								raise StandardError("Unable to update cacheReplication for cache")
		 				
		 
		 # diskCacheCustomPerformanceSettings
		 if (diskCacheCustomPerformanceSettingsProps != None):
		 		subAttrs = ""
		 		for key in diskCacheCustomPerformanceSettingsProps.keys():
		 				val = diskCacheCustomPerformanceSettingsProps.get(key)
		 				subAttrs = "%s [%s '%s']"  % (subAttrs, key, val)
		 		
		 		if (subAttrs != ""):
		 				subAttrs = "[ %s ]" % subAttrs
		 				
		 				diskCacheCustomPerformanceSettingsId = AdminConfig.showAttribute(cacheId,"diskCacheCustomPerformanceSettings")
		 				if (isEmpty(diskCacheCustomPerformanceSettingsId)):
		 						# Need to create
		 						_app_trace("About to call AdminConfig.create(DiskCacheCustomPerformanceSettings, %s,%s)" % (cacheId, subAttrs))
		 						diskCacheCustomPerformanceSettingsId = AdminConfig.create("DiskCacheCustomPerformanceSettings",cacheId, subAttrs)
		 						_app_trace("diskCacheCustomPerformanceSettingsId = %s" % diskCacheCustomPerformanceSettingsId)
		 				else:
		 						# Need to update
		 						if (modifyObject(diskCacheCustomPerformanceSettingsId, subAttrs)):
		 								raise StandardError("Unable to update diskCacheCustomPerformanceSettings in object cache")
 				
		 
		 # diskCacheEvictionPolicy
		 if (diskCacheEvictionPolicyProps != None):
		 		subAttrs = ""
		 		for key in diskCacheEvictionPolicyProps.keys():
		 				val = diskCacheEvictionPolicyProps.get(key)
		 				subAttrs = "%s [%s '%s']" % (subAttrs, key, val)
		 		
		 		if (subAttrs != ""):
		 				subAttrs = "[ %s ]" % subAttrs
		 				diskCacheEvictionPolicyId = AdminConfig.showAttribute(cacheId,"diskCacheEvictionPolicy")
		 				if (isEmpty(diskCacheEvictionPolicyId)):
		 						# Need to create
		 						_app_trace("About to call AdminConfig.create(DiskCacheEvictionPolicy,%s,%s)" % (cacheId,subAttrs))
		 						diskCacheEvictionPolicyId = AdminConfig.create("DiskCacheEvictionPolicy",cacheId,subAttrs)
		 						_app_trace("diskCacheEvictionPolicyId = %s" % diskCacheEvictionPolicyId)
		 				else:
		 						# Need to update
		 						if (modifyObject(diskCacheEvictionPolicyId,subAttrs)):
		 								raise StandardError("Unable to update diskCacheEvictionPolicy in object cache")
		 				
		 
		 # memoryCacheEvictionPolicy
		 if (memoryCacheEvictionPolicyProps != None):
		 		subAttrs = ""
		 		for key in memoryCacheEvictionPolicyProps.keys():
		 				val = memoryCacheEvictionPolicyProps.get(key)
		 				subAttrs = "%s [%s '%s']" % (subAttrs,key,val)
		 		if (subAttrs != ""):
		 				subAttrs = "[ %s ]" % subAttrs
		 				
		 				memoryCacheEvictionPolicyId = AdminConfig.showAttribute(cacheId,"memoryCacheEvictionPolicy")
		 				if (isEmpty(memoryCacheEvictionPolicyId)):
		 						# Need to create
		 						_app_trace("About to call AdminConfig.create(MemoryCacheEvictionPolicy,%s,%s)" % (cacheId,subAttrs))
		 						memoryCacheEvictionPolicyId = AdminConfig.create("MemoryCacheEvictionPolicy",cacheId,subAttrs)
		 						_app_trace("memoryCacheEvictionPolicyId = %s" % memoryCacheEvictionPolicyId)
		 				else:
		 						# Need to update
		 						if (modifyObject(memoryCacheEvictionPolicyId, subAttrs)):
		 								raise StandardError("Error updating memoryCacheEvictionPolicy in object cache")
		 
		 
		 
		 # Now set up resource properties
		 if (not isEmpty(cacheId) and resourceProps != None):
		 		propertySetId = AdminConfig.showAttribute(cacheId,"propertySet")
		 		if (isEmpty(propertySetId)):
		 				propertySetId = AdminConfig.create("J2EEResourcePropertySet", cacheId,[])
		 				
		 		errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
		 		if (not isEmpty(errmsg)):
		 				raise StandardError("Error creating resource properties: %s" % errmsg)
		 
		 # Set up our return value				
		 retval = cacheId
	except:
			_app_trace("Unexpected error creating ObjectCacheInstance","exception")
			retval = None
			
	_app_trace("createObjectCache(retval=%s)" % retval, "exit")
	return retval


#---------------------------------------------------------------------------
# modifyObjectCache
#
# Parameters:
#   cacheId - Ihe Id of the ObjectCacheInstance to be updated
#   cacheName - The name of the Object Cache (logging only)
#   cacheProps - Properties object with base ObjectCacheInstance properties to update
#   resourceProps - Properties object with values for J2EE Resource properties if the name=type|required|val|desc format
#   cacheReplicationProps - Properties set containing key/values for DRSSettings
#   diskCacheCustomPerformanceSettingsProps - Properties set containing key/values for DiskCacheCustomPerformanceSettings
#   diskCacheEvictionPolicyProps - Properties set containing key/values for DiskCacheEvictionPolicy
#   memoryCacheEvictionPolicyProps - Properties set containing key/values for MemoryCacheEvictionPolicy (v7)
#---------------------------------------------------------------------------
def modifyObjectCache(cacheId, cacheProps, resourceProps=None, cacheReplicationProps=None, diskCacheCustomPerformanceSettingsProps=None, diskCacheEvictionPolicyProps=None, memoryCacheEvictionPolicyProps=None):

	_app_trace("modifyObjectCache(%s,%s,%s,%s,%s,%s,%s)" %( cacheId, cacheProps, resourceProps, cacheReplicationProps, diskCacheCustomPerformanceSettingsProps, diskCacheEvictionPolicyProps, memoryCacheEvictionPolicyProps),"entry")
	retval = None

	try:	
		 baseAttrs = "" 
		 for key in cacheProps.keys():
		 		val = cacheProps.get(key)
		 		baseAttrs = "%s [%s '%s']" % (baseAttrs,key,val)
		 		
		 if (baseAttrs != ""):
		 		baseAttrs = "[ %s ]" % baseAttrs
		 		if (modifyObject(cacheId, baseAttrs)):
		 				raise StandardError("Unable to update base properties for cache")
		 
		 
		 # Add cache replication
		 if (cacheReplicationProps != None):
		 		subAttrs = ""
		 		for key in cacheReplicationProps.keys():
		 				val = cacheReplicationProps.get(key)
		 				subAttrs = "%s [%s '%s']"  % (subAttrs, key, val)
		 		
		 		if (subAttrs != ""):
		 				subAttrs = "[ %s ]" % subAttrs
		 				cacheReplicationId = AdminConfig.showAttribute(cacheId, "cacheReplication")
		 				if (isEmpty(cacheReplicationId)):
		 						# Need to create
		 						_app_trace("About to call AdminConfig.create(DRSSettings, %s,%s)" %( cacheId,subAttrs))
		 						cacheReplicationId = AdminConfig.create("DRSSettings", cacheId,subAttrs)
		 						_app_trace("cacheReplicationId = %s" % cacheReplicationId)
		 				else:
		 						# Need to update
		 						if (modifyObject(cacheReplicationId, subAttrs)):
		 								raise StandardError("Unable to update cacheReplication for cache")
		 				
		 
		 # diskCacheCustomPerformanceSettings
		 if (diskCacheCustomPerformanceSettingsProps != None):
		 		subAttrs = ""
		 		for key in diskCacheCustomPerformanceSettingsProps.keys():
		 				val = diskCacheCustomPerformanceSettingsProps.get(key)
		 				subAttrs = "%s [%s '%s']"  % (subAttrs, key, val)
		 		
		 		if (subAttrs != ""):
		 				subAttrs = "[ %s ]" % subAttrs
		 				
		 				diskCacheCustomPerformanceSettingsId = AdminConfig.showAttribute(cacheId,"diskCacheCustomPerformanceSettings")
		 				if (isEmpty(diskCacheCustomPerformanceSettingsId)):
		 						# Need to create
		 						_app_trace("About to call AdminConfig.create(DiskCacheCustomPerformanceSettings, %s,%s)" % (cacheId, subAttrs))
		 						diskCacheCustomPerformanceSettingsId = AdminConfig.create("DiskCacheCustomPerformanceSettings",cacheId, subAttrs)
		 						_app_trace("diskCacheCustomPerformanceSettingsId = %s" % diskCacheCustomPerformanceSettingsId)
		 				else:
		 						# Need to update
		 						if (modifyObject(diskCacheCustomPerformanceSettingsId, subAttrs)):
		 								raise StandardError("Unable to update diskCacheCustomPerformanceSettings in object cache")
 				
		 
		 # diskCacheEvictionPolicy
		 if (diskCacheEvictionPolicyProps != None):
		 		subAttrs = ""
		 		for key in diskCacheEvictionPolicyProps.keys():
		 				val = diskCacheEvictionPolicyProps.get(key)
		 				subAttrs = "%s [%s '%s']" % (subAttrs, key, val)
		 		
		 		if (subAttrs != ""):
		 				subAttrs = "[ %s ]" % subAttrs
		 				diskCacheEvictionPolicyId = AdminConfig.showAttribute(cacheId,"diskCacheEvictionPolicy")
		 				if (isEmpty(diskCacheEvictionPolicyId)):
		 						# Need to create
		 						_app_trace("About to call AdminConfig.create(DiskCacheEvictionPolicy,%s,%s)" % (cacheId,subAttrs))
		 						diskCacheEvictionPolicyId = AdminConfig.create("DiskCacheEvictionPolicy",cacheId,subAttrs)
		 						_app_trace("diskCacheEvictionPolicyId = %s" % diskCacheEvictionPolicyId)
		 				else:
		 						# Need to update
		 						if (modifyObject(diskCacheEvictionPolicyId,subAttrs)):
		 								raise StandardError("Unable to update diskCacheEvictionPolicy in object cache")
		 				
		 
		 # memoryCacheEvictionPolicy
		 if (memoryCacheEvictionPolicyProps != None):
		 		subAttrs = ""
		 		for key in memoryCacheEvictionPolicyProps.keys():
		 				val = memoryCacheEvictionPolicyProps.get(key)
		 				subAttrs = "%s [%s '%s']" % (subAttrs,key,val)
		 		if (subAttrs != ""):
		 				subAttrs = "[ %s ]" % subAttrs
		 				
		 				memoryCacheEvictionPolicyId = AdminConfig.showAttribute(cacheId,"memoryCacheEvictionPolicy")
		 				if (isEmpty(memoryCacheEvictionPolicyId)):
		 						# Need to create
		 						_app_trace("About to call AdminConfig.create(MemoryCacheEvictionPolicy,%s,%s)" % (cacheId,subAttrs))
		 						memoryCacheEvictionPolicyId = AdminConfig.create("MemoryCacheEvictionPolicy",cacheId,subAttrs)
		 						_app_trace("memoryCacheEvictionPolicyId = %s" % memoryCacheEvictionPolicyId)
		 				else:
		 						# Need to update
		 						if (modifyObject(memoryCacheEvictionPolicyId, subAttrs)):
		 								raise StandardError("Error updating memoryCacheEvictionPolicy in object cache")
		 								
		 # Now set up resource properties
		 if (resourceProps != None):
		 		propertySetId = AdminConfig.showAttribute(cacheId,"propertySet")
		 		if (isEmpty(propertySetId)):
		 				propertySetId = AdminConfig.create("J2EEResourcePropertySet", cacheId,[])
		 				
		 		errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
		 		if (not isEmpty(errmsg)):
		 				raise StandardError("Error updating resource properties: %s" % errmsg)
		 				
		 
		 retval = cacheId

	except:
			_app_trace("Unexpected error updating ObjectCacheInstance","exception")
			retval = None
			
	_app_trace("modifyObjectCache(retval=%s)" % retval, "exit")
	return retval
	
	

#--------------------------------------------------------------------------------------
# findObjectCacheInstanceWithName
#
# Returns the ID of the ObjectCacheInstance with the specified name.  Returns None if no match is
# found. Returns "ERROR" if an unexpected error occurs.
#--------------------------------------------------------------------------------------
def findObjectCacheInstanceWithName(cacheName,providerId):

		_app_trace("findObjectCacheInstanceWithName(%s,%s)" % (cacheName,providerId),"entry")
		retval = None
		
		try:
		
				if (isEmpty(providerId)):
						raise StandardError("ObjectCacheInstanceProvider Id not specified")
		
				if (isEmpty(cacheName)):
						raise StandardError("object cache Name is not specified")
				
				cacheList = wsadminToList(AdminConfig.list("ObjectCacheInstance",providerId))
				for cacheId in cacheList:
						if (isEmpty(cacheId)):
								continue
						
						tempName = AdminConfig.showAttribute(cacheId,"name")
						if (tempName == cacheName):
								retval = cacheId
								break
		except:
				_app_trace("Unexpected error looking for object cache %s" % (cacheName), "exception")
				retval = "ERROR"
		
		_app_trace("findObjectCacheInstanceWithName(retval = %s)" % retval, "exit")
		return retval


#--------------------------------------------------------------------------------------
# findObjectCacheInstanceAtScope
#
# Returns the ID of the ObjectCacheInstance with the specified name and scope.  Returns None if no match is
# found. Returns "ERROR" if an unexpected error occurs.
#--------------------------------------------------------------------------------------
def findObjectCacheInstanceAtScope(pCluster, pNode, pServer, cacheName) :

	retval = None
	try:
	
		_app_trace("findObjectCacheInstanceAtScope(%s,%s,%s,%s)" % (pCluster, pNode, pServer, cacheName),"entry")
	
		global progInfo
		global configInfo
		
		pScope = ""

		if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
				pScope = "cell"
				cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
				for cell in cells:
						retval=AdminConfig.getid("/Cell:%s/CacheProvider:CacheProvider/ObjectCacheInstance:%s/" % (AdminConfig.showAttribute(cell,"name"),cacheName))
						break
		else:
			if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer):
					pScope = "cluster"
					
					retval=AdminConfig.getid("/ServerCluster:%s/CacheProvider:CacheProvider/ObjectCacheInstance:%s/" % (pCluster,cacheName))
		
			else:
				if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
						pScope = "node"
						
						scopeId=AdminConfig.getid("/Node:%s/CacheProvider:CacheProvider/" % pNode)
						if (not isEmpty(scopeId)):
								retval = findObjectCacheInstanceWithName(cacheName,scopeId)
						else:
								raise StandardError("CacheProvider not found at node scope %s" % pNode)
								
				else:
						if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
								pScope = "server"
								server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
						
								scopeId=AdminConfig.getid("/Server:%s/CacheProvider:CacheProvider/" % AdminConfig.showAttribute(server,"name"))
								if (not isEmpty(scopeId)):
										retval = findObjectCacheInstanceWithName(cacheName,scopeId)
								else:
										raise StandardError("CacheProvider not found at server scope %s:%s" % (pNode,pServer))

	except:
			_app_trace("Error searching for object cache %s at scope %s%s:%s"%(cacheName,pCluster, pNode, pServer),"exception")
			retval = "ERROR" 
	
	_app_trace("findObjectCacheInstanceAtScope(retval=%s)" % (retval),"exit")
	return retval


#--------------------------------------------------------------------------------------
# findCacheProviderAtScope
#
# Returns the ID of the CacheProvider with the specified name and scope.  Returns None if no match is
# found. Returns "ERROR" if an unexpected error occurs.
#--------------------------------------------------------------------------------------
def findCacheProviderAtScope(pCluster, pNode, pServer, providerName) :

	retval = None
	try:
	
		_app_trace("findCacheProviderAtScope(%s,%s,%s,%s)" % (pCluster, pNode, pServer, providerName),"entry")
	
		global progInfo
		global configInfo
		
		pScope = ""

		if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
				pScope = "cell"
				cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
				for cell in cells:
						retval=AdminConfig.getid("/Cell:%s/CacheProvider:%s/" % (AdminConfig.showAttribute(cell,"name"),providerName))
						break
		else:
			if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer):
					pScope = "cluster"
					
					retval=AdminConfig.getid("/ServerCluster:%s/CacheProvider:%s/" % (pCluster,providerName))
		
			else:
				if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
						pScope = "node"
						
						retval=AdminConfig.getid("/Node:%s/CacheProvider:%s/" % (pNode,providerName))
								
				else:
						if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
								pScope = "server"
				
								retval=AdminConfig.getid("/Node:%s/Server:%s/CacheProvider:%s/" % (pNode,pServer,providerName))

	except:
		_app_trace("Error searching for Cache Provider %s at scope %s%s:%s"%(providerName,pCluster, pNode, pServer),"exception")
		retval = "ERROR" 
	
	_app_trace("findCacheProviderAtScope(retval=%s)" % (retval),"exit")
	return retval




#------------------------------------------------------------------------------------
# getObjectCacheProperties
#
# Propery syntax
#    objectcache.name
#    objectcache.prop.xxx
#    objectcache.resourceProperties.prop.xxxx
#    objectcache.cacheReplication.prop.xxxx
#    objectcache.diskCacheCustomPerformanceSettings.prop.xxx
#    objectcache.diskCacheEvictionPolicy.prop.xxx
#    objectcache.memoryCacheEvictionPolicy.prop.xxx 
#------------------------------------------------------------------------------------
def getObjectCacheProperties(objectCacheId):

	retval = None
	_app_trace("getObjectCacheProperties(%s)" % objectCacheId, "entry")
	try:
		retval = java.util.Properties()
			
		prefix = "objectcache" 
		
		retval.put("objectcache.name", AdminConfig.showAttribute(objectCacheId,"name"))
		
		collectSimpleProperties(retval,"objectcache.prop", objectCacheId, ["name","memoryCacheSizeInMB"])
		
		# cacheReplication DRSSettings
		cacheReplicationId = AdminConfig.showAttribute(objectCacheId,"cacheReplication")
		if (not isEmpty(cacheReplicationId)):
				collectSimpleProperties(retval, "objectcache.cacheReplication.prop" , cacheReplicationId, [])
		
		# diskCacheCustomPerformanceSettings DiskCacheCustomPerformanceSettings
		diskCacheCustomPerformanceSettingsId = AdminConfig.showAttribute(objectCacheId, "diskCacheCustomPerformanceSettings")
		if (not isEmpty(diskCacheCustomPerformanceSettingsId)):
				collectSimpleProperties(retval,"objectcache.diskCacheCustomPerformanceSettings.prop", diskCacheCustomPerformanceSettingsId, [])
		
		# diskCacheEvictionPolicy DiskCacheEvictionPolicy
		diskCacheEvictionPolicyId = AdminConfig.showAttribute(objectCacheId, "diskCacheEvictionPolicy")
		if (not isEmpty(diskCacheEvictionPolicyId)):
				collectSimpleProperties(retval, "objectcache.diskCacheEvictionPolicy.prop" , diskCacheEvictionPolicyId, [])
		
		# memoryCacheEvictionPolicy MemoryCacheEvictionPolicy   # New to v7
		# memoryCacheSizeInMB int                               # New to v7
		try:
			retval.put("objectcache.prop.memoryCacheSizeInMB", AdminConfig.showAttribute(objectCacheId,"memoryCacheSizeInMB"))
			memoryCacheEvictionPolicyId = AdminConfig.showAttribute(objectCacheId,"memoryCacheEvictionPolicy")
			if (not isEmpty(memoryCacheEvictionPolicyId)):
					collectSimpleProperties(retval, "objectcache.memoryCacheEvictionPolicy.prop", memoryCacheEvictionPolicyId,[])
		except:
			pass
		
		collectResourceProperties(retval,objectCacheId,"propertySet",prefix)
	
	except:
			_app_trace("Exception occurred getting properties for object cache", "exception")
			retval = None
	
	_app_trace("getObjectCacheProperties()", "exit")
	return retval