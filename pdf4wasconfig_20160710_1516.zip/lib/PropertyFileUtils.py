################################################################################
# PropertyFilesUtils.py
# 
# This module implements classes that are used to implement a custom property file
# loader for the updateEnvironment scripts.  The property files will be loaded as-is
# and backslashes will not be interpreted as escape characters.  In addition to 
# this functionality, the property file loader can optionally do variable replacement.
################################################################################

#------------------------------------------------------------------------------
# Class ReplacementPair
#
# The AbstractVariableHandler uses an ordered list of replacement pairs for
# special token replacement processing. This class represents a key/value pair.
#------------------------------------------------------------------------------
class ReplacementPair:
    
    
    def __init__(self, searchFor=None, replaceWith=None):
       self.searchForValue = searchFor
       self.replaceWithValue = replaceWith
         
    def setSearchForValue(self, searchForValue):
       self.searchForValue = searchForValue
    
    def getSearchForValue(self):
       return self.searchForValue
     
    def setReplaceWithValue(self, replaceWithValue):
       self.replaceWithValue = replaceWithValue
       
    def getReplaceWithValue(self):
      return self.replaceWithValue

#endclass    
  
    



#-----------------------------------------------------------------------------------------------------
# Class AbstractVariableHandler
#
#This abstract class allows variable substitution to be done in a two-phase approach.
#
#In the first phase, the variable handler uses a list of defined SEARCH-FOR/REPLACE-WITH values
#to process the line.  These search/replace values are processed in the order in which they are
#registered with this class.
#
#In the second phase, the extending class should implement a parseAndProcessVariables() methods that
#handle specific variable syntax.  The parseAndProcessVariables can identify the variable names and then
#use a map of variable/values maintained by this class to determine the replacement value.
#
#An implementing class could use one or both types of logic to do the variable substitution. 
#
#@author martinek
#
#-----------------------------------------------------------------------------------------------------
class AbstractVariableHandler:
  
  def __init__(self):
    self.replacementPairs = []
  
    self.variableMap = java.util.Properties()    
  
  def getVariableValue(self,varName):
    result = None
    
    if (self.variableMap != None):
      result = self.variableMap.getProperty(varName)
    
    return result
  #enddef
  
  def setVariableValue(self, variableName, value):
    
    self.variableMap.setProperty(variableName, value)
    
  
  def setVariableValues(self, variables ):
    
    if (variables == None): return
    
    self.variableMap.putAll(variables)
  #enddef 
  
  def findReplacementPair(self, searchFor):
    
    result = None
    for pair in self.replacementPairs:
      if (pair.getSearchForValue() == searchFor):
        result = pair
        break
   
    return result
  #enddef

  
  def addReplacementPair(self, searchFor, replaceValue):
    
    existing = self.findReplacementPair(searchFor)
    if (existing == None):
      newPair = ReplacementPair(searchFor,replaceValue)
      self.replacementPairs.append(newPair)
    elif (existing.getReplaceWithValue() != replaceValue):
      existing.setReplaceWithValue(replaceValue)
      
  #enddef
  
  def removeReplacementPair(self, searchFor):
    existing = self.findReplacementPair(searchFor)
    if (existing != None):
      self.replacementPairs.remove(existing)
      
  #enddef
  
  # Abstract method that should be overwritten
  def parseAndProcessVariables(self,inputString):
    return inputString

  def substitueValues(self, inputString):
    
    # Do the processing that involves direct string replacements
    replacementResults = self.processReplacementPairs(inputString)
    
    # Now let the implementing class do its processing based on its own variable syntax
    return self.parseAndProcessVariables(replacementResults)
    
  #enddef
  
  def processReplacementPairs(self, inputString):
    
    for pair in self.replacementPairs:
      
      pos = input.indexOf(pair.getSearchForValue())
      if (pos >= 0):
        inputString = inputString.replace(pair.getSearchForValue(), pair.getReplaceWithValue())

    return inputString
  

#endclass



#-------------------------------------------------------------------------------
# Class NoOpVariableHandler
#
# This is the default Variable Handler implementation for the PropertyFileLoader.
# It does no variable replacement processing.
#-------------------------------------------------------------------------------
class NoOpVariableHandler:
   
  def __init__(self):
    
    print "" 
    
  #enddef  
  def substitueValues(self, inputString):
    return inputString
  #enddef

#endclass

#-------------------------------------------------------------------------------
# class BracketedVariableHandler
#
# This VariableHandler implementation is used to perform variable substitution
# on strings where the varialbe name is bracketed by an opening and closing
# string (e.g. %{VAR_NAME}).  The opening and closing bracket strings are 
# customizable and can be set by passing in to the constructor.
#-------------------------------------------------------------------------------
class BracketedVariableHandler(AbstractVariableHandler):
  
  #openingBracket = "%["
  #closingBracket = "%]"
  
 
  def __init__(self, _openingBracket, _closingBracket, variableFileName):
    
    AbstractVariableHandler.__init__(self)
        
    self.openingBracket = _openingBracket
    self.closingBracket = _closingBracket
    
    variables = None
    pfl = PropertyFileLoader(None)
    variables = pfl.loadProperties(variableFileName)
    
    self.setVariableValues(variables)
    
  #enddef

  
  def parseAndProcessVariables(self, inputString):
    
    sb = java.lang.StringBuilder(inputString)
    currentPos = 0
    openingPos = sb.indexOf(self.openingBracket,currentPos)
    while (openingPos >= 0):
      closingPos = sb.indexOf(self.closingBracket,openingPos+len(self.openingBracket))
      
      if (closingPos >= 0):
        varName = sb.substring(openingPos+len(self.openingBracket), closingPos)
        
        varvalue = None
        if (len(varName) > 0):
          varvalue = self.getVariableValue(varName)
          
        
        if (varvalue != None):
          sb.replace(openingPos,closingPos+len(self.closingBracket), varvalue)
          currentPos = openingPos + len(varvalue)
        else:
          # Skip over the variable with no defined value
          currentPos = closingPos + len(self.closingBracket)
      
        
      
      else:
        # No closing position, so we're done with loop
        break
      
      # Find new opening pos
      openingPos = sb.indexOf(self.openingBracket,currentPos)
    
    
    return sb.toString()
  #enddef

#endclass

#-------------------------------------------------------------------------------
# Class PropertyFileLoader
#
# This class will load a property file without doing any processing of 
# backslash characters.  Variable substitution in property values is supported 
# by supplying a VariableHandler to the constructor.
#-------------------------------------------------------------------------------
class PropertyFileLoader:
  
  def __init__(self,vh):
    
    if (vh != None):
      self.variableHandler = vh
    else:
      self.variableHandler = NoOpVariableHandler()
    
  #enddef
  
  #-----------------------------------------------------------------------------
  # loadProperties - Returns a java.util.Properties object with the 
  # properties from the specified file.
  #-----------------------------------------------------------------------------
  def loadProperties(self, fileName):
    
    result = java.util.Properties()
    
    propertyFile = java.io.File(fileName)
    
    fis = None
    brdr = None
    
    try:
      fis = java.io.FileInputStream(propertyFile)
      
      brdr = java.io.BufferedReader(java.io.InputStreamReader(fis))
      
      line = brdr.readLine()
      while (line != None):
        
        line = str(line)
        
        #print "Input Line: %s" % line
        
        if (line.startswith("#")):
          line = brdr.readLine()
          continue
        
        
        line = line.strip()
        
        if (len(line) == 0):
          line = brdr.readLine()
          continue
        
        # Property should start out with letter or digit
        if (not line[0:1].isalnum()):
          line = brdr.readLine()
          continue
        
        splitPos = line.find('=')
        if (splitPos  <= 0 ):
          # Not in property assignment format - skipping
          line = brdr.readLine()
          continue
        
        key = line[0:splitPos].strip()
        val = ""
        if (splitPos < (len(line) - 1) ):
          val = line[splitPos + 1:]
          if (len(val) > 0):
            val = val.strip()
       
          # Do variable substitution          
          val=self.variableHandler.substitueValues(val)
          
        #print "substituted key/val = [%s] [%s]" % (key,val)
        
        
        result.put(key, val)
        
        line = brdr.readLine()
        
      #end while
      
      
    except:
      #print "Unexpected error in loadProperties"
      _app_trace("Unexpected error in loadProperties","exception")
      raise StandardError("Unexpected error in loadProperties")
      
    if (brdr != None):
      try:
        brdr.close()
      except:
        pass
    
    if (fis != None):
      try:
        fis.close()
      except:
        pass
            
    return result
  #enddef
  
#endclass

