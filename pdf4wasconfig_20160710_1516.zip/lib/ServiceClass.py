################################################################################
# ServiceClass.py
#
#   Requires: Utils.py, common.py
#
# Methods for manipulating ServiceClass configuration items, which define service
# policies.
#
#  createServiceClass(scName,baseProps,goalType,goalProps,tcList=None)
#  modifyServiceClass(scName=None,scId=None,baseProps=None,goalType=None,goalProps=None,tcList=None)
#  removeServiceClass(scName)
#  getTransactionClassId(serviceClassName,tcName)
#  getServiceClassId(servicePolicyName)
#  getServiceClassProperties(serviceClassId)
################################################################################




#-------------------------------------------------------------------------------
# createServiceClass
#
# Parameters
#    scName - name of Service Policy
#    baseProps - base properties of service policy
#    goalType - configuration type of service policy goals
#    goalProps - dictionary with properties of goal
#    tcList - TransactionClass list. List of dictionaries where each dictionary
#             defines a new transaction class to create. Note that the default
#             TC should be created automatically and does not need to be specified.
#
# Returns the configuration ID of the ServiceClass
#-------------------------------------------------------------------------------
def createServiceClass(scName,baseProps,goalType,goalProps,tcList=None):
  _app_entry("createServiceClass(%s,%s,%s,%s,%s)" , scName,baseProps,goalType,goalProps,tcList)
  retval = None
  try:
    baseAttrs = propsToAttrList(baseProps)
    baseAttrs.append(["name",scName])
    
    _app_trace('About to call AdminConfig.create("ServiceClass",%s,%s)'% (getCellId(),baseAttrs))
    retval = AdminConfig.create("ServiceClass",getCellId(),baseAttrs)
    
    goalAttrs = propsToAttrList(goalProps)
    _app_trace('About to call AdminConfig.create(%s,%s,%s,"ServiceClassGoal")' % (goalType,retval,goalAttrs))
    goalId = AdminConfig.create(goalType,retval,goalAttrs,"ServiceClassGoal")
    
    if (tcList != None and len(tcList) > 0):
      defaultTCName = "Default_TC_%s" % scName
      for tcDict in tcList:
        tcName = tcDict.get("name")
        if (isEmpty(tcName)):
          raise StandardError("TransactionClass name attribute is required")
        if (tcName == defaultTCName):
          # Only create if for some reason it wasn't created automatically
          tcId = getTransactionClassId(scName,tcName)
          if (not isEmpty(tcId)): continue
        
        tcAttrs = propsToAttrList(tcDict)
        _app_trace('About to call AdminConfig.create("TransactionClass",%s,%s)'% (retval,tcAttrs))
        AdminConfig.create("TransactionClass",retval,tcAttrs)
    
  except:
    _app_exception("Unexpected problem in createServiceClass()")
  
  _app_exit("createServiceClass(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# modifyServiceClass
#
# Updates the ServiceClass configuration 
#
# Parameters - all parameters are optional. Pass in None if a subcomponent is not
#              to be updated.
#
#   scName - Name of the service policy (Optional, will be pulled from the Id if necessary)
#   scId - Configuration ID of the service policy (optional, will be looked up if name supplied)
#   baseProps - base properties of ServiceClass to be updated
#   goalType - WCCM configuration type of ServiceClassGoal attribute to be updated 
#   goalProps - properties to be applied to ServiceClassGoal
#   tcList - A list of dictionaries that define the transaction classes to be 
#            modified/updated. If not None, the existing transaction classes will
#            be replaced by the classes in this list (except for the default TC)
#
#
# Returns - configuration ID of the ServiceClass 
#-------------------------------------------------------------------------------
def modifyServiceClass(scName=None,scId=None,baseProps=None,goalType=None,goalProps=None,tcList=None):
  _app_entry("modifyServiceClass(%s,%s,%s,%s,%s,%s)" , scName,scId,baseProps,goalType,goalProps,tcList)
  retval = None
  newSC = 0
  try:
    if (isEmpty(scId) and not isEmpty(scName)):
      scId = getServiceClassId(scName)
      if isEmpty(scId):
        retval = createServiceClass(scName,baseProps,goalType,goalProps,tcList)
        newSC = 1
    
    if (not newSC):
      if (baseProps != None and len(baseProps) > 0):
        baseAttrs = propsToAttrList(baseProps)
        if (modifyObject(scId,baseAttrs)):
          raise StandardError("Error updating base attributes on ServiceClass")
      
      if (goalProps != None and len(goalProps) > 0):
        goalId = AdminConfig.showAttribute(scId,"ServiceClassGoal")
        currentGoalType = callGetObjectType(goalId)
        if (goalType == None):
          # Use the current type
          goalType = currentGoalType
        goalAttrs = propsToAttrList(goalProps)
        if (currentGoalType != goalType):
          
          # Delete existing and recreate
          _app_trace('About to call AdminConfig.remove(%s)'% goalId)
          AdminConfig.remove(goalId)
          _app_trace('About to call AdminConfig.create(%s,%s,%s,,"ServiceClassGoal")' %( goalType,scId,goalAttrs))
          AdminConfig.create(goalType,scId,goalAttrs,"ServiceClassGoal")
        else: 
          # do update
          if (modifyObject(goalId,goalAttrs)):
            raise StandardError("Unable to update goal type %s with attrs" % (currentGoalType,goalAttrs))
      
      if (tcList != None and len(tcList) > 0):
        if (isEmpty(scName)):
          scName = AdminConfig.showAttribute(scId,"name")
        
        # Remove all but the default TC
        tcIds = wsadminToList(AdminConfig.showAttribute(scId,"TransactionClasses"))
        defaultTCName = "Default_TC_%s" % scName
        for tcId in tcIds:
          if isEmpty(tcId):
            continue
          if tcId.startswith("%s(" % defaultTCName) :
            continue
          else:
            # Remove
            _app_trace('About to call AdminConfig.remove(%s)' % tcId)
            AdminConfig.remove(tcId)
        
        # Now create ones specified in new list
        for tcDict in tcList:
          tcName = tcDict.get("name")
          if (isEmpty(tcName)):
            raise StandardError("TransactionClass name attribute is required")
          
          if (tcName == defaultTCName):
            # Do not create it
            continue
          
          tcAttrs = propsToAttrList(tcDict)
          _app_trace('About to call AdminConfig.create("TransactionClass",%s,%s)'% (retval,tcAttrs))
          AdminConfig.create("TransactionClass",scId,tcAttrs)
          
    retval = scId
  except:
    _app_exception("Unexpected problem in modifyServiceClass()")
  
  _app_exit("modifyServiceClass(retval=%s)" % retval)
  return retval



#-------------------------------------------------------------------------------
# removeServiceClass
#
# Parameters
#    scName - Name of the service policy to delete
# Returns:
#    Configuration ID of removed policy
#
#-------------------------------------------------------------------------------
def removeServiceClass(scName):
  _app_entry("removeServiceClass(%s)" , scName)
  retval = None
  try:
    if (scName == "Default_SP"):
      raise StandardError("Default_SP cannot be removed")
      
    scId = getServiceClassId(scName)
    if (not isEmpty(scId)):
      _app_trace('About to call AdminConfig.remove(%s)' % scId)
      AdminConfig.remove(scId)
      
      retval = scId
  except:
    _app_exception("Unexpected problem in removeServiceClass()")
  
  _app_exit("removeServiceClass(retval=%s)" % retval)
  return retval
  
  

#-------------------------------------------------------------------------------
# getTransactionClassId
#
# Parameters
#    serviceClassName - name of service policy that transaction class is defined under
#    tcName - name of the transaction class
#-------------------------------------------------------------------------------
def getTransactionClassId(serviceClassName,tcName):
  _app_entry("getTransactionClassId(%s,%s)" , serviceClassName,tcName)
  retval = None
  try:
    retval = AdminConfig.getid("/ServiceClass:%s/TransactionClass:%s/"%(serviceClassName,tcName))
  except:
    _app_exception("Unexpected problem in getTransactionClassId()")
  
  _app_exit("getTransactionClassId(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# getServiceClassId
#
# Parameters
#    servicePolicyName - name of service policy to look up
#-------------------------------------------------------------------------------
def getServiceClassId(servicePolicyName):
  _app_entry("getServiceClassId(%s)" , servicePolicyName)
  retval = None
  try:
    retval = AdminConfig.getid("/ServiceClass:%s/" % servicePolicyName)
  except:
    _app_exception("Unexpected problem in getServiceClassId()")
  
  _app_exit("getServiceClassId(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# getServiceClassProperties
#
# Parameters
#    serviceClassId: - Configuration ID of Service Class
#
# Returns a dictionary with the following keys:
#   serviceclass.prop.XXX = YYYY
#   serviceclass.ServiceClassGoal.type = DiscretionaryGoal
#   serviceclass.ServiceClassGoal.prop.XXXXX = YYYY
#   serviceclass.TransactionClasses.1.prop.name = Default_TC_MyServicePolicy
#   serviceclass.TransactionClasses.2.prop.description = Example of a custom transaction class
#   serviceclass.TransactionClasses.2.prop.name = CustomTCMyServicePolicy
#   serviceclass.TransactionClasses.2.prop.description = Example of a custom transaction class
#   serviceclass.TransactionClasses.count = 2
#-------------------------------------------------------------------------------
def getServiceClassProperties(serviceClassId):
  _app_entry("getServiceClassProperties(%s)" , serviceClassId)
  retval = {}
  try:
    collectSimpleProperties(retval, "serviceclass.prop",serviceClassId, getSimpleChildren=1,collectListChildren=1,
                            collectPropertyAttributes=1,useAttrNameWithProperties=1,getChildType=1)
  except:
    _app_exception("Unexpected problem in getServiceClassProperties()")
  
  _app_exit("getServiceClassProperties(retval=%s)" % retval)
  return retval