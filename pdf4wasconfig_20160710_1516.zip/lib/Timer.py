#################################################################################
# Timer.py
#     Methods for manipulating TimerManagerInfo configurations
#
# Requires: Utils.py, common.py 
#
#  createTimerManager(providerId,timerName,baseProps,resourceProps=None):
#  updateTimerManager(timerId,baseProps=None,resourceProps=None):
#  getTimerManagerProviderAtScope(pName="TimerManagerProvider",c=None,n=None,s=None,dc=None):
#  getTimerManagerAtScope(mgrName,c,n,s,dc,providerName="TimerManagerProvider"):
#  getTimerManagerProperties(timerId):
#################################################################################

#-------------------------------------------------------------------------------
# createTimerManager
#
# Parameters
#    providerId - Parent provider of the new TimerManagerInfo object
#    timerName - Name of the timer
#    baseProps - dictionary with base key/values
#    resourceProps - dictionary optional resource properties to apply
#                    in key=type|required|value[|description] format
#
# Returns
#   configuration ID of new timer manager
#-------------------------------------------------------------------------------
def createTimerManager(providerId,timerName,baseProps,resourceProps=None):
  _app_entry("createTimerManager(%s,%s,%s,%s)",providerId,timerName,baseProps,resourceProps )
  retval = None
  try:
    
    attrs = propsToAttrList(baseProps)
    attrs.append(["name",timerName])
    attrs.append(["provider",providerId])
    _app_trace('About to call AdminConfig.create("TimerManagerInfo",%s,%s)' %(providerId,attrs))
    retval = AdminConfig.create("TimerManagerInfo",providerId,attrs)
    
    if (resourceProps != None and len(resourceProps) > 0):
      updateJ2EEResourcePropertySet(retval, resourceProps, attributeName="propertySet")
      
  except:
    _app_exception("Unexpected problem in createTimerManager()")
    
  
  _app_exit("createTimerManager(retval=%s)" % retval)
  return retval
  

#-------------------------------------------------------------------------------
# updateTimerManager
#
# Parameters
#
#    timerId - Configuration ID of the TimerManagerInfo
#    baseProps - dictionary with base key/values
#    resourceProps - dictionary optional resource properties to apply
#                    in key=type|required|value[|description] format
#-------------------------------------------------------------------------------
def updateTimerManager(timerId,baseProps=None,resourceProps=None):
  _app_entry("updateTimerManager(%s,%s,%s)",timerId,baseProps,resourceProps)
  retval = timerId
  try:
    #some stuff
    if (baseProps != None and len(baseProps) > 0):
      attrs = propsToAttrList(baseProps)
      if (modifyObject(timerId,attrs)):
        raise StandardError("Error updating TimerManagerInfo %s" % timerId)
    
    if (resourceProps != None and len(resourceProps) > 0):
      updateJ2EEResourcePropertySet(timerId, resourceProps, attributeName="propertySet")
  except:
    _app_exception("Unexpected problem in updateTimerManager()")
  
  _app_exit("updateTimerManager(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# getTimerManagerProviderAtScope
#
# Parameters
#
#-------------------------------------------------------------------------------
def getTimerManagerProviderAtScope(pName="TimerManagerProvider",c=None,n=None,s=None,dc=None):
  _app_entry("getTimerManagerProviderAtScope(%s,%s,%s,%s,%s)",pName,c,n,s,dc)
  retval = None
  try:
    tlist = findItemsAtScope("TimerManagerProvider:%s/" % pName,cluster=c, node=n, server=s, dyncluster=dc)
    if (len(tlist) > 0):
      retval = tlist[0]  
  except:
    _app_exception("Unexpected problem in getTimerManagerProviderAtScope()")
  
  _app_exit("getTimerManagerProviderAtScope(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# getTimerManagerAtScope
#-------------------------------------------------------------------------------
def getTimerManagerAtScope(mgrName,c,n,s,dc,providerName="TimerManagerProvider"):
  _app_entry("getTimerManagerAtScope(%s,%s,%s,%s,%s,%s)" %(mgrName,c,n,s,dc,providerName))
  retval = None
  try:
    tlist = findItemsAtScope("TimerManagerProvider:%s/TimerManagerInfo:%s/" % (providerName,mgrName),cluster=c, node=n, server=s, dyncluster=dc)
    if (len(tlist) > 0):
      retval = tlist[0]
  except:
    _app_exception("Unexpected error in getTimerManagerAtScope(%s,%s,%s,%s,%s,%s)" %(mgrName,c,n,s,dc,providerName))
  
  _app_exit("getTimerManagerAtScope(retval=%s)" % retval)
  return retval
  


#-------------------------------------------------------------------------------
# getTimerManagerProperties
#
# Parameters
#    timerId - Configuration Id of timermangerinfo
#
# Returns dictionary with the following property prefixes
#    timermanager.prop.XXXX - base attribute XXXX
#    timermanager.resourceProperties.prop.XXXX
#-------------------------------------------------------------------------------
def getTimerManagerProperties(timerId):
  _app_entry("getTimerManagerProperties(%s)" % (timerId))
  retval = {}
  try:
    
    collectSimpleProperties(retval,"timermanager.prop" , timerId, ["name"], getSimpleChildren=1,
                          collectPropertyAttributes=1)
  except:
    _app_exception("Unexpected problem in getTimerManagerProperties()")
  
  _app_exit("getTimerManagerProperties(retval=%s)" % retval)
  return retval
  