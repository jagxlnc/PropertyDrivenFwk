##########################################################################
# File Name:    WebSphereVariable.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere variables
#
#               createWebSphereVariable
#               deleteWebSphereVariable
#               listWebSphereVariables
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createWebSphereVariable: Create a WebSphere Environment Variable
#
# SYNTAX:
#    createWebSphereVariable name, value, cluster|(node, server), 
#
# PARAMETERS:
#    name	-	Name of WebSphere environment variable
#    value 	-	Value for WebSphere environment variable
#    cluster	-	Name of cluster for cluster scoped environment variable
#    node	-	Name of node for server scoped environment variable
#    server	-	Name of server for server scoped environment variable
#
# USAGE NOTES:
#    Creates a WebSphere environment variable named 'name' at the desired scope
#    and sets it to 'value'
#
# RETURNS:
#    ObjID	Object ID of new appserver
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addWebSphereVariable(name, value, desc, cluster, node, server):
	createWebSphereVariable(name, value, desc, cluster, node, server)
	
def createWebSphereVariable(name, value, desc, cluster, node, server):

	global progInfo

	retval = None

	try:
		if (cluster == ""):
			cluster = None

		traceStr = "createWebSphereVariable(%s, %s, %s, %s, %s, %s)" % (name, value, desc, cluster, node, server)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		configID = getContainmentPath(cluster, node, server)

		if isEmpty(configID):
			raise StandardError("Could not get containment path")

		if isEmpty(AdminConfig.getid(configID)):
			raise StandardError("No such target as %s to create WebSphere Variable at" % (configID))
		if isEmpty(name):
			raise StandardError("Variable Name not specified")
			
		#	Check it doesn't already exist at scope
		if existsWebSphereVariable(name, configID, not isEmpty(cluster)):
			#raise StandardError("Cannot create %s, already exists at %s" % (name, configID))
			_app_message("WebSphere Variable %s, already exists at %s" % (name, configID))
			return 1

		mapID = getWebSphereVariableMapID(configID, not isEmpty(cluster))			

		if isEmpty(mapID):
			raise StandardError("Cannot find WebSphere Variable Map")

		#	Add the entry, let the exception handlder handle duplicates
		if (desc == None):
				desc = ""
				
	
		if (desc.startswith("'") or desc.startswith('"')):
				descjs = java.lang.String(desc)
		else:
				descjs = java.lang.String('"%s"' % desc)

		if (value.startswith("'") or value.startswith('"')):
				valuejs = java.lang.String(value)
		else:
				valuejs = java.lang.String("'%s'" % value)
								
		attributes = [ ["symbolicName", name] , ["value" , valuejs],  [ "description" , descjs] ]
		

		_app_trace("Running command: AdminConfig.create('VariableSubstitutionEntry', %s, %s)" % (mapID, attributes))
		retval = AdminConfig.create("VariableSubstitutionEntry", mapID, attributes)

		if progInfo["app.autosave"] == "true":
			_app_trace("Saving...")
			AdminConfig.save()
	except:
		_app_trace("An error was encountered creating the WebSphere Variable", "exception")
		retval = None

	_app_trace("createWebSphereVariable(%s)" %(retval), "exit")
	return retval
	
##########################################################################
#
# FUNCTION:
#    modifyWebSphereVariable: Moidfy a WebSphere Environment Variable
#
# SYNTAX:
#    modifyWebSphereVariable name, value, cluster|(node, server), 
#
# PARAMETERS:
#    name	-	Name of WebSphere environment variable
#    value 	-	Value for WebSphere environment variable
#    cluster	-	Name of cluster for cluster scoped environment variable
#    node	-	Name of node for server scoped environment variable
#    server	-	Name of server for server scoped environment variable
#
# USAGE NOTES:
#    Modifies a WebSphere environment variable named 'name' at the desired scope
#    and sets it to 'value'
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def modifyWebSphereVariable(name, value, desc, cluster, node, server):

	global progInfo

	retval = 1

	try:
		traceStr = "modifyWebSphereVariable(%s, %s, %s, %s, %s, %s)" % (name, value, desc, cluster, node, server)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		configID = getContainmentPath(cluster, node, server)

		if isEmpty(configID):
			raise StandardError("Could not get containment path")
			
		if isEmpty(AdminConfig.getid(configID)):
			raise StandardError("No such target as %s to create WebSphere Variable at" % (configID))
			
		if isEmpty(name):
			raise StandardError("Variable Name not specified")
			
		#	Check it doesn't already exist at scope
		if not existsWebSphereVariable(name, configID, not isEmpty(cluster)):
			raise StandardError("Cannot modify %s, does not exist at %s" % (name, configID))

		mapID = getWebSphereVariableMapID(configID, not isEmpty(cluster))			

		if isEmpty(mapID):
			raise StandardError("Cannot find WebSphere Variable Map")

		found = 0

		if (desc == None):
				desc = ""
				
	
		if (desc.startswith("'") or desc.startswith('"')):
				descjs = java.lang.String(desc)
		else:
				descjs = java.lang.String('"%s"' % desc)

		if (value.startswith("'") or value.startswith('"')):
				valuejs = java.lang.String(value)
		else:
				valuejs = java.lang.String("'%s'" % value)
								
		attributes = [ ["symbolicName", name] , ["value" , valuejs],  [ "description" , descjs] ]
		

		entries = AdminConfig.showAttribute(mapID, "entries")
		entriesLen = len(entries) - 1
		entriesList = entries[1:entriesLen].split(" ")

		for entry in entriesList:
			symName = AdminConfig.showAttribute(entry, "symbolicName")

			if(symName == name):
				#	Modify the entry
				_app_trace("Running command: AdminConfig.modify(%s, %s)" % (entry, attributes))
				AdminConfig.modify(entry, attributes)

				if progInfo["app.autosave"] == "true":
					_app_trace("Saving...")
					AdminConfig.save()

				found = 1							
				break

		if found == 0:
			raise StandardError("Cannot modify %s, does not exist at %s" % (name, configID))
			
		retval = 0

	except:
		_app_trace("An error was encountered creating the WebSphere Variable", "exception")
		retval = 1

	_app_trace("modifyWebSphereVariable(%d)" %(retval), "exit")
	return retval
	
##########################################################################
#
# FUNCTION:
#    deleteWebSphereVariable: Delete a WebSphere Environment Variable
#
# SYNTAX:
#    deleteWebSphereVariable name, cluster|(node, server), 
#
# PARAMETERS:
#    name	-	Name of WebSphere environment variable
#    cluster	-	Name of cluster for cluster scoped environment variable
#    node	-	Name of node for server scoped environment variable
#    server	-	Name of server for server scoped environment variable
#
# USAGE NOTES:
#    Deletes a WebSphere environment variable named 'name' at the desired scope
#
# RETURNS:
#    1   - Variable existed and was deleted
#    0   - Variable did not exist at the specified scope
#
# THROWS:
#    StandardError - problem occurred deleting variable
##########################################################################
def removeWebSphereVariable(name, cluster, node, server):
	deleteWebSphereVariable(name, cluster, node, server)
	
def deleteWebSphereVariable(envname,cluster,node,server):

    _app_trace("deleteWebSphereVariable(%s,%s,%s,%s)" % (envname,cluster,node,server),"entry")
    
    retval = 0
    
    try:

      # See if the variable exists
      existingId = checkForExistingWebSphereVariable(envname, cluster, node, server)
      if (not isEmpty(existingId)):
        _app_trace("About to call AdminConfig.remove(%s)" % existingId)
        AdminConfig.remove(existingId)
        retval = 1
      else:
        _app_trace("Variable %s did not exist at scope %s %s %s" % (envname, cluster, node, server))
        retval = 0
          
    except:
      _app_trace("Error processing variable deletion in deleteWebSphereVariable","exception")
      raise StandardError("Error processing variable deletion in deleteWebSphereVariable: variable name = %s" % envname)
        
    
    _app_trace("deleteWebSphereVariable()","exit")
    return retval

##########################################################################
#
# FUNCTION:
#    listWebSphereVariables: Lists WebSphere Environment Variables
#
# SYNTAX:
#    listWebSphereVariables cluster|(node, server), displayFlag
#
# PARAMETERS:
#    cluster	-	Name of cluster for cluster scoped environment variable
#    node	-	Name of node for server scoped environment variable
#    server	-	Name of server for server scoped environment variable
#    displayFlag- Boolean indicating whether to print list 
#		  (default = 1)
#
# USAGE NOTES:
#    Lists WebSphere environment variables at the desired scope
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showWebSphereVariables(cluster, node, server, displayFlag = 1):
	listWebSphereVariables(cluster, node, server, displayFlag)
	
def listWebSphereVariables(cluster, node, server, displayFlag = 1):

	global progInfo

	retval = None

	try:
		traceStr = "listWebSphereVariables(%s, %s, %s, %d)" % (cluster, node, server, displayFlag)
		_app_trace(traceStr, "entry")	

		#	Check function parameters
		configID = getContainmentPath(cluster, node, server)

		if isEmpty(configID):
			raise StandardError("Could not get containment path")
			
		if isEmpty(AdminConfig.getid(configID)):
			raise StandardError("No such target as %s to list WebSphere Variables at" % (configID))
			

		mapID = getWebSphereVariableMapID(configID, not isEmpty(cluster))			

		if isEmpty(mapID):
			raise StandardError("Cannot find WebSphere Variable Map")

		entries = AdminConfig.showAttribute(mapID, "entries")
		entriesLen = len(entries) - 1
		retval = entries[1:entriesLen].split(" ")

		if displayFlag:
			print "\nWebSphere Environment Variables"
			print   "-------------------------------"
			for entry in retval:
				symName  = AdminConfig.showAttribute(entry, "symbolicName")
				symValue = AdminConfig.showAttribute(entry, "value")
				print "%-30.30s\t%-45.45s" % (symName, symValue)
			print "\n-------------------------------"
	except:
		_app_trace("An error was encountered listing the WebSphere Variables", "exception")
		retval = None

	_app_trace("listWebSphereVariables(%s)" %(retval), "exit")
	return retval

#----------------------------------------------------------------------------------------------------------
# checkForExistingWebSphereVariable
# Looks for the variable and returns the configuration ID if found
#
# @JJM
#----------------------------------------------------------------------------------------------------------
def checkForExistingWebSphereVariable(name, cluster, node, server):

  global progInfo

  retval =  None

  try:
    traceStr = "checkForExistingWebSphereVariable(%s, %s, %s, %s)" % (name, cluster, node, server)
    _app_trace(traceStr, "entry") 

    # Check function parameters
    configID = getContainmentPath(cluster, node, server)

    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to create WebSphere Variable at" % (configID))
      
    if isEmpty(name):
      raise StandardError("Variable Name not specified")
      
    mapID = getWebSphereVariableMapID(configID, not isEmpty(cluster))     

    if isEmpty(mapID):
      raise StandardError("Cannot find WebSphere Variable Map")

    found = 0


    entries = AdminConfig.showAttribute(mapID, "entries")
    entriesLen = len(entries) - 1
    entriesList = entries[1:entriesLen].split(" ")

    for entry in entriesList:
      if (isEmpty(entry)):
        continue
      symName = AdminConfig.showAttribute(entry, "symbolicName")

      if(symName == name):
        retval = entry
        break

  except:
    _app_trace("An error was encountered searching for the WebSphere Variable", "exception")
    retval = None

  _app_trace("checkForExistingWebSphereVariable(%s)" %(retval), "exit")
  return retval
