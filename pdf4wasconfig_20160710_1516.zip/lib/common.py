
#------------------------------------------------------------------------------------------------------
def wsadminToListOld(inStr):
        outList=[]
        if (len(inStr)>0 and inStr[0]=='[' and inStr[-1]==']'):
                inStr = inStr[1:-1]
		if(inStr.startswith('"')):
			k = inStr.split('" ')
			tmpList=[]
			for item in k:
				if(item.startswith('"')):
					item = item[1:]
				if(item.endswith('"')):
					item = item[:-1]
				tmpList.append(item)
		else:
                	tmpList = inStr.split(" ")
        else:
                tmpList = inStr.split("\n")  #splits for Windows or Linux
        for item in tmpList:
                item = item.rstrip();        #removes any Windows "\r"
                if (len(item)>0):
                        outList.append(item)
        return outList
#endDef

def wsadminToList(inStr):
    """
    Translates strings returned by wsadmin functions representing arrays "[ foo bar ]" to real python arrays ['foo', 'bar']
    
    @return: a Python list
    
    >>> wsadminToList("[ foo bar ]")
    ['foo', 'bar']
    >>> wsadminToList("[foo bar]")
    ['foo', 'bar']
    >>> wsadminToList("[ [cell ifa61] [serverType APPLICATION_SERVER] ]")
    ['cell ifa61', 'serverType APPLICATION_SERVER']
    >>> wsadminToList('[(cells/adev61/nodes/foo/servers/dmgr|server.xml#NameServer_1) "Deployment Manager(cells/adev61/nodes/foo/servers/dmgr|server.xml#CellManager_1)"]')
    ['(cells/adev61/nodes/foo/servers/dmgr|server.xml#NameServer_1)', '"Deployment Manager(cells/adev61/nodes/foo/servers/dmgr|server.xml#CellManager_1)"']
    >>> wsadminToList('[TEST_PROP(cells/aci61|resources.xml#J2EEResourceProperty_1271379509181) "wsrp.consumer.cookieforward.sabs:params"(cells/aci61|resources.xml#J2EEResourceProperty_1275873189713) "wer wer(cells/aci61|resources.xml#J2EEResourceProperty_1275875033329)" sfsdf(Sfsdfsdf(cells/aci61|resources.xml#J2EEResourceProperty_1275875113971)]')
    ['TEST_PROP(cells/aci61|resources.xml#J2EEResourceProperty_1271379509181)', '"wsrp.consumer.cookieforward.sabs:params"(cells/aci61|resources.xml#J2EEResourceProperty_1275873189713)', '"wer wer(cells/aci61|resources.xml#J2EEResourceProperty_1275875033329)"', 'sfsdf(Sfsdfsdf(cells/aci61|resources.xml#J2EEResourceProperty_1275875113971)']
    """
    outList = []

    if not inStr: return outList

    if inStr.startswith('[ [') and inStr.endswith('] ]'):
        tmpList = inStr[3:-3].split('] [')
    elif inStr.startswith('[') and inStr.endswith(']'):
        tmpList = []
        inQuotes = 0
        current = ""
        for char in inStr[1:-1]:
            if len(current) == 0 and char == '"':
                inQuotes = 1
                current = '"'
            elif char == '"':
                inQuotes = 0
                current += '"'
            elif not inQuotes and char == " ":
                tmpList.append(current)
                current = ""
            else:
                current += char
        if len(current) > 0: tmpList.append(current)
    else:
        tmpList = inStr.splitlines()

    for item in tmpList:
        item = item.rstrip()
        if len(item) > 0: outList.append(item)
    return outList



#------------------------------------------------------------------------------------------------------
# wsadminToDictionary - turn a string of bracketed key value pairs into a dictionary
# Example:
#		[ [com.ibm.websphere.baseProductVersion 6.1.0.35] [com.ibm.websphere.nodeOperatingSystem aix] ]
#   OR
# '{password=, logMissingTransactionContext=false, readAhead=Default, tempQueueNamePrefix=, shareDurableSubscriptions=InCluster, targetTransportChain=,
#   authDataAlias=ConfigurationScriptingDmgr/Dude, userName=, targetSignificance=Preferred, shareDataSourceWithCMP=false, providerEndPoints=, 
#  nonPersistentMapping=ExpressNonPersistent, persistentMapping=ReliablePersistent, clientID=, jndiName=jms/SampleSIBQueueCF, manageCachedHandles=false, 
#  category=, busName=SampleBus, targetType=BusMember, xaRecoveryAuthAlias=Dude3, description=, connectionProximity=Bus, target=SampleCluster, name=SampleSIBQueueCF}'
#------------------------------------------------------------------------------------------------------
def wsadminToDictionaryOld(inStr):
		outDictionary = {}
		if (len(inStr)>0 and inStr[0]=='[' and inStr[-1]==']'):
				inStr = inStr[1:-1]
				tlist = inStr.split(" ")
				currentKey = ""
				currentVal = ""
				for token in tlist:
					if (isEmpty(token)):
							continue
					if (token[0] == "["):
							token = token[1:]
							currentKey = token
							currentVal = ""
							continue
					
					if (token[-1] == "]"):
							token = token[:-1]
							currentVal = token
					if (currentKey != "" and currentVal != ""):
							outDictionary[currentKey] = currentVal
							currentKey = ""
							currentVal = ""
		elif (len(inStr) > 0 and inStr[0] =='{' and inStr[-1] == '}'):
				# Parse the second format
				inStr = inStr[1:-1]
				tlist = inStr.split(",")
				for token in tlist:
						val = ""
						key = ""
						keyval = token.split("=")
						if (len(keyval) == 1):
								key = keyval[0]
						elif (len(keyval) == 2):
								key = keyval[0]
								val = keyval[1]
						
						key = key.lstrip()
						val = val.rstrip()
						outDictionary[key] = val
		
		return outDictionary

#---
# different version - same code from dumpConfig.py
#---
def wsadminToDictionary(inStr):
    outDictionary = {}
    if (len(inStr)>0 and inStr[0]=='[' and inStr[-1]==']'):
        inStr = inStr[1:-1]
        tlist = inStr.split(" ")
        currentKey = ""
        currentVal = ""
        for token in tlist:
          if (isEmpty(token)):
              continue
          if (token[0] == "["):
              token = token[1:]
              currentKey = token
              currentVal = ""
              continue
          
          if (token[-1] == "]"):
              token = token[:-1]
              currentVal = token
          if (currentKey != "" and currentVal != ""):
              outDictionary[currentKey] = currentVal
              currentKey = ""
              currentVal = ""
    elif (len(inStr) > 0 and inStr[0] =='{' and inStr[-1] == '}'):
      splitOn = ","
      
      if (inStr.find(", ") >0):
        splitOn = ", "
        
      # Parse the second format
      inStr = inStr[1:-1]
      tlist = inStr.split(splitOn)
      for tempToken in tlist:
          val = ""
          key = ""
          equalPos = tempToken.find("=")
          if (equalPos < 0):
            key = tempToken
          else:
            key = tempToken[0:equalPos]
            val = tempToken[equalPos+1:]
                    
          key = key.lstrip()
          val = val.rstrip()
          outDictionary[key] = val
    
    return outDictionary




#------------------------------------------------------------------------------------------------------
def getCookieId(inStr):
	return inStr[inStr.find("("):]
#------------------------------------------------------------------------------------------------------
def getId(inStr):
        if (inStr.startswith("(") and inStr.endswith(")")):
		return inStr[1:-1]
	return inStr
#------------------------------------------------------------------------------------------------------
def isArray(inStr):
        if (inStr.startswith("[") and inStr.endswith("]")):
		return 1
	return 0
#------------------------------------------------------------------------------------------------------
def isId(inStr):
	if (inStr.rfind("#") > 0 and inStr.rfind("/") > 0 and inStr.endswith(")")):
		return 1
	return 0
#------------------------------------------------------------------------------------------------------
def isId1(inStr):
        if (inStr.startswith("(") and inStr.endswith(")")):
		return 1
	return 0
#------------------------------------------------------------------------------------------------------
def toList(inStr):
  if (inStr.startswith('"') and inStr.endswith('"')):
    inStr = inStr[1:-1]
  return inStr.split(" ")
#------------------------------------------------------------------------------------------------------
def toKeyValue(inStr):
    s = inStr[1:-1]
    k = s[:s.find(' ')]
    v = s[len(k) + 1:]
    return k,v
#------------------------------------------------------------------------------------------------------
def getValue(inStr):
    return inStr[inStr.find(":") + 1:].strip()
#------------------------------------------------------------------------------------------------------
def getScope(inStr):
        c=n=s=dc=app=dep=""
        inStr = inStr[:inStr.find("|")]
        a = inStr.split("/")
        #print a
        
        if (inStr.find("dynamicclusters") > -1):
          # This could be a resource at dynamic cluster template level
          dc = a[3]
          
          if (inStr.find("servers") > -1):
            s = a[5]
        else:
          if (inStr.find("applications") > -1):
            app = a[3]
            
            if (inStr.find("deployments") > -1):
              dep=a[5]
          
          else:
            if (inStr.find("clusters") > -1):
                c = a[3]
            else:
                if (inStr.find("servers") > -1):
                        n = a[3]
                        s = a[5]
                else:
                        if (inStr.find("node") > -1):
                                n = a[3]
                                
        return c, n, s, dc, app, dep
#------------------------------------------------------------------------------------------------------
