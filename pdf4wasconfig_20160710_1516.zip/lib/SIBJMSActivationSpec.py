##########################################################################
# File Name:    SIBJMSActivationSpecs.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere SIB JMS Activation Specs
#
#               createSIBJMSActivationSpec
#               deleteSIBJMSActivationSpec
#               listSIBJMSActivationSpecs
#
##########################################################################

##########################################################################
#
# FUNCTION:
#    createSIBJMSActivationSpec: Create a SIB JMS Activation Spec
#
# SYNTAX:
#    createSIBJMSActivationSpec name, (cluster|node, server), destJNDIName, bus
#
# PARAMETERS:
#    name    -  Name for SIB JMS Activation Spec entry
#    cluster    -  Cluster to assign JMS Activation Spec to
#    node    -  Node to assign JMS Activation Spec to
#    server    -  Server to assign JMS Activation Spec to
#    destJNDIName  -  JNDI Name for destination
#    bus    -  Name of bus to connect to
#    attrs    -  Attributes in the form of -name1 value1 -name2 value2 ...
#
# USAGE NOTES:
#    Creates a SIB JMS Activation Spec at the desired scope.  
#
# RETURNS:
#    ObjID  Object ID of new appserver
#    None  Failure
#
# THROWS:
#    N/A
#
#wsadmin>print AdminTask.help("createSIBJMSActivationSpec")
#WASX8006I: Detailed help for command: createSIBJMSActivationSpec
#
#Description: Create an activation specification in the SIB JMS resource adapter.
#
#*Target object: Scope of the SIB JMS resource adapter to which the activation specification will be added.
#
#Arguments:
#  *name - Name of new activation specification.
#  *jndiName - JNDI name of the activation specification.
#  *destinationJndiName - JNDI name of a destination.
#  description - A JMS activation specification is used by the default messaging provider to validate the activation-configuration properties for a JMS message-driven bean (MDB).
#  acknowledgeMode - How the session acknowledges any messages it receives.
#  authenticationAlias - Authentication alias.
#  busName - Name of the bus to connect to.
#  clientId - Client identifier. Required for durable topic subscriptions.
#  destinationType - Whether the message-driven bean uses a queue or topic destination.
#  durableSubscriptionHome - Name of the durable subscription home. This identifies the messaging engine where all durable subscriptions accessed through this activation specification are managed.
#  maxBatchSize - The maximum number of messages received from the messaging engine in a single batch.
#  maxConcurrency - The maximum number of endpoints to which messages are delivered concurrently.
#  messageSelector - The JMS message selector used to determine which messages the message-driven bean (MDB) receives.
#  password - Password.
#  subscriptionDurability - Whether a JMS topic subscription is durable or nondurable.
#  subscriptionName - The subscription name needed for durable topic subscriptions.
#  shareDurableSubscriptions - Used to control how durable subscriptions are shared.
#  userName - User name.
#  readAhead - Read-ahead value. Legal values are "Default", "AlwaysOn" and "AlwaysOff".
#  target - The SIB JMS activation specification new target value.
#  targetType - The SIB JMS activation specification new target type value. Legal values are "BusMember", "Custom" and "ME".
#  targetSignificance - This property specifies the significance of the target group.
#  targetTransportChain - The name of the protocol that should be used to connect to a remote messaging engine.
#  providerEndPoints - A comma-separated list of endpoint triplets of the form "host:port:chain".
#  shareDataSourceWithCMP - Used to control how data sources are shared.
#  consumerDoesNotModifyPayloadAfterGet - When enabled, Object Messages received through this activation spec will only have their message data serialized by the system when absolutely necessary. The data obtained from those messages must be treated as readOnly by applications. Legal values are "true" and "false" (default).
#  forwarderDoesNotModifyPayloadAfterSet - When enabled, Object/Bytes Messages forwarded through this activation spec that have their payload modified will not have the data copied when is is set into the message and the system will only serialize the message data when absolutely necessary. Applications sending such messages must not modify the data once it has been set into the message. Legal values are "true" and "false" (default).
#  alwaysActivateAllMDBs - MDB server-selection rule.  Determines which servers can drive MDBs deployed to them.  This parameter has two possible values: TRUE, FALSE.  The default is FALSE.  Specify TRUE to always activate MDBs in all servers.  Otherwise, only servers with a running messaging engine are used.
#  retryInterval - The delay (in seconds) between attempts to connect to a messaging engine, both for the initial connection, and any subsequent attempts to establish a better connection.  The default is 30.  Must be greater than zero.
#  autoStopSequentialMessageFailure - The endpoint will be stopped when the number of sequentially failing messages reaches the configured limit. Due to processing dependencies in the MDB the actual number of messages processed may exceed this value.
#  failingMessageDelay - Any message that fails to be processed by the MDB but has not reached its maximum failed delivery limit will only be retried after this period of time has passed. Other messages may be tried during this period, unless the sequential failure threshold and the maximum concurrency is set to 1 millisecond.#
#
# Steps:
# None
##########################################################################


def createSIBJMSActivationSpec(name, cluster, node, server,jndiName,  destJNDIName, attrs):

  #Note - dash parms same in V7,V8,V8.5
  dashParmsV7 = ['name' , 'destinationJndiName' , 'failingMessageDelay' , 'retryInterval' , 'password' , 'readAhead' , 'subscriptionDurability' , 'destinationType' , 'forwarderDoesNotModifyPayloadAfterSet' , 'alwaysActivateAllMDBs' , 'shareDurableSubscriptions' , 'durableSubscriptionHome' , 'useServerSubject' , 'acknowledgeMode' , 'targetTransportChain' , 'maxBatchSize' , 'messageSelector' , 'userName' , 'targetSignificance' , 'shareDataSourceWithCMP' , 'providerEndPoints' , 'jndiName' , 'consumerDoesNotModifyPayloadAfterGet' , 'targetType' , 'busName' , 'subscriptionName' , 'description' , 'maxConcurrency' , 'authenticationAlias' , 'clientId' , 'autoStopSequentialMessageFailure' , 'target']
  dashParmsV6 = ['name' , 'destinationJndiName'  , 'password' , 'readAhead' , 'subscriptionDurability' , 'destinationType' , 'shareDurableSubscriptions' , 'durableSubscriptionHome' , 'acknowledgeMode' , 'targetTransportChain' , 'maxBatchSize' , 'messageSelector' , 'userName' , 'targetSignificance' , 'shareDataSourceWithCMP'  , 'jndiName' , 'targetType' , 'busName' , 'subscriptionName' , 'description' , 'maxConcurrency' , 'authenticationAlias' , 'clientId' , 'target' ]
  specParms = [ 'WAS_EndpointInitialState' ]
  
  global progInfo

  retval = None

  try:
    traceStr = "createSIBJMSActivationSpec(%s, %s, %s, %s, %s, %s, %s)" % (name, cluster, node, server, jndiName, destJNDIName, attrs)
    _app_trace(traceStr, "entry")  
    
    dashParms = dashParmsV7
    
    if ( progInfo["dmgrVersion"].startswith("6")):
        dashParms = dashParmsV6

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
    
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to create SIB JMS Activation Spec on" % (configID))
      
    if isEmpty(name) or isEmpty(destJNDIName):
      raise StandardError("SIB JMS Activation Spec name or destination JNDI name not specified")
      
    if existsSIBJMSActivationSpec(name, cluster, node, server):
      raise StandardError("SIB JMS Activation Spec %s already exists at scope %s" % (name, configID))
      
    parentID  = AdminConfig.getid(configID)

    _app_trace("Got parent ID = " + parentID)

    formattedName = name
    if (name.find(" ") > 0 and not name.startswith('"') and not name.startswith("'")):
      formattedName = "'%s'" % name
      
    attributes  = " -name %s" % (formattedName)
    
    formattedName = jndiName
    if (jndiName.find(" ") > 0 and not jndiName.startswith('"') and not jndiName.startswith("'")):
      formattedName = "'%s'" % jndiName            
    attributes += " -jndiName %s" % (formattedName)
    
    formattedName = destJNDIName
    if (destJNDIName.find(" ") > 0 and not destJNDIName.startswith('"') and not destJNDIName.startswith("'")):
      formattedName = "'%s'" % destJNDIName              
    attributes += " -destinationJndiName %s" % (formattedName) 
    
    for key in attrs.keys():
        if key in dashParms:
            val = attrs.get(key)
            if (not isEmpty(val)):
              if (key == "description" and not val.startswith('"')):
                  val = '"%s"' % val
            
              if (val.find(' ') >= 0):
                if (not val.startswith('"') and not val.startswith("'") ) :
                  val = '"%s"' % val

              attributes = "%s -%s %s" % (attributes, key, val)

  
    _app_trace("Running command: AdminTask.createSIBJMSActivationSpec(%s, %s)" % (parentID, attributes))

    retval = AdminTask.createSIBJMSActivationSpec(parentID, attributes)
    
    if (not isEmpty(retval)):
      actSpecId = retval
      specialProps = java.util.Properties()
      # See if there any input parms that need to be handled
      for key in attrs.keys():
        if key in specParms:
            val = attrs.get(key)
            specialProps.put(key, "java.lang.String|false|%s" % (val))
      
      if (len(specialProps) > 0):
        errmsg = updateCustomProperties(actSpecId, "resourceProperties", "J2EEResourceProperty", specialProps)
        if (not isEmpty(errmsg)):
          raise StandardError("Unable to update special properties for activation spec %s: %s" % (name,errmsg))
            
      
      

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered creating the SIB JMS Activation Spec", "exception")
    retval = None

  _app_trace("createSIBJMSActivationSpec(%s)" %(retval), "exit")
  return retval
  
  
############################################################################
# modifySIBJMSActivationSpec
############################################################################
def modifySIBJMSActivationSpec(name, cluster, node, server, attrs):

  
    
  dashParmsV7 = ['name' , 'destinationJndiName' , 'failingMessageDelay' , 'retryInterval' , 'password' , 'readAhead' , 'subscriptionDurability' , 'destinationType' , 'forwarderDoesNotModifyPayloadAfterSet' , 'alwaysActivateAllMDBs' , 'shareDurableSubscriptions' , 'durableSubscriptionHome' , 'useServerSubject' , 'acknowledgeMode' , 'targetTransportChain' , 'maxBatchSize' , 'messageSelector' , 'userName' , 'targetSignificance' , 'shareDataSourceWithCMP' , 'providerEndPoints' , 'jndiName' , 'consumerDoesNotModifyPayloadAfterGet' , 'targetType' , 'busName' , 'subscriptionName' , 'description' , 'maxConcurrency' , 'authenticationAlias' , 'clientId' , 'autoStopSequentialMessageFailure' , 'target','wAS_EndpointInitialState']
  dashParmsV6 = ['name' , 'destinationJndiName'  , 'password' , 'readAhead' , 'subscriptionDurability' , 'destinationType' , 'shareDurableSubscriptions' , 'durableSubscriptionHome' , 'acknowledgeMode'  , 'targetTransportChain' , 'maxBatchSize' , 'messageSelector' , 'userName' , 'targetSignificance' , 'shareDataSourceWithCMP'  , 'jndiName' , 'targetType' , 'busName' , 'subscriptionName' , 'description' , 'maxConcurrency' , 'authenticationAlias' , 'clientId' , 'target' ]

  specParms = [ 'WAS_EndpointInitialState' ]
  
  global progInfo

  retval = None

  try:
    traceStr = "modifySIBJMSActivationSpec(%s, %s, %s, %s, %s)" % (name, cluster, node, server, attrs)
    _app_trace(traceStr, "entry")  
    
    # Determine correct parameters
    dashParms = dashParmsV7
    if ( progInfo["dmgrVersion"].startswith("6")):
        dashParms = dashParmsV6

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
    
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to create SIB JMS Activation Spec on" % (configID))
      
    if isEmpty(name):
      raise StandardError("SIB JMS Activation Spec name not specified")

    actSpecId = getSIBJMSActivationSpecID(cluster, node,server, name)
    if (isEmpty(actSpecId)):
      raise StandardError("Cannot retrieve configuration ID for updating SIB JMS Activation Spec %s at scope %s %s %s" % (name, cluster, node,server))

    attributes = None
    if (name.find(" ") > 0 and not name.startswith("'") and not name.startswith('"')):
      attributes = " -name '%s'" % (name)
    else:  
      attributes  = " -name %s" % (name)        
    
    for key in attrs.keys():
        if key in dashParms:
            val = attrs.get(key)
            if (not isEmpty(val)):
              if (key == "description" and not val.startswith('"')):
                val = '"%s"' % val
                    
              if (val.find(' ') >= 0):
                if (not val.startswith('"') and not val.startswith("'") ) :
                  val = '"%s"' % val

              attributes = "%s -%s %s" % (attributes, key, val)
  

  
    _app_trace("Running command: AdminTask.modifySIBJMSActivationSpec(%s, %s)" % (actSpecId, attributes))

    retval = AdminTask.modifySIBJMSActivationSpec(actSpecId, attributes)
    
    retval = actSpecId
    
    if (not isEmpty(retval)):
      actSpecId = retval
      specialProps = java.util.Properties()
      # See if there any input parms that need to be handled
      for key in attrs.keys():
        if key in specParms:
            val = attrs.get(key)
            specialProps.put(key, "java.lang.String|false|%s" % (val))
      
      if (len(specialProps) > 0):
        errmsg = updateCustomProperties(actSpecId, "resourceProperties", "J2EEResourceProperty", specialProps)
        if (not isEmpty(errmsg)):
          raise StandardError("Unable to update special properties for activation spec %s: %s" % (name,errmsg))

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered modifying the SIB JMS Activation Spec", "exception")
    retval = None

  _app_trace("modifySIBJMSActivationSpec(%s)" %(retval), "exit")
  return retval
  
  
##########################################################################
#
# FUNCTION:
#    deleteSIBJMSActivationSpec: Delete a SIB JMS Activation Spec
#
# SYNTAX:
#    deleteSIBJMSActivationSpec name, cluster|(node, server)
#
# PARAMETERS:
#    name  -  Name for SIB JMS Activation Spec entry
#    cluster  -  Name of cluster for cluster scoped activation spec
#    node  -  Name of node for server scoped activation spec
#    server  -  Name of server for server scoped activation spec
#    actSpecId - configuration ID if known
#
# USAGE NOTES:
#    Deletes a SIB JMS Activation Spec from the desired scope.  
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBJMSActivationSpec(name, cluster, node, server,actSpecId=None):
  deleteSIBJMSActivationSpec(name, cluster, node, server,actSpecId)
  
def deleteSIBJMSActivationSpec(name, cluster, node, server,actSpecId=None):

  global progInfo

  retval = 1

  try:
    traceStr = "deleteSIBJMSActivationSpec(%s, %s, %s, %s,%s)" % (name, cluster, node, server,actSpecId)
    _app_trace(traceStr, "entry")
    
    if (not isEmpty(actSpecId)):
      _app_trace("Running command: AdminTask.deleteSIBJMSActivationSpec(%s)" % (actSpecId))
      AdminTask.deleteSIBJMSActivationSpec(actSpecId)      
    else:  

      #  Check function parameters
      configID = getContainmentPath(cluster, node, server, 1)
      
      if isEmpty(configID):
        raise StandardError("Could not get containment path")
      
      if isEmpty(AdminConfig.getid(configID)):
        raise StandardError("No such target as %s to delete SIB JMS Activation Spec from" % (configID))
        
      if isEmpty(name):
        raise StandardError("SIB JMS Activation Spec name not specified")
        
      if not existsSIBJMSActivationSpec(name, cluster, node, server):
        raise StandardError("SIB JMS Activation Spec %s does not exist at scope %s" % (name, configID))
        
      parentID = AdminConfig.getid(configID)
      idList  = AdminTask.listSIBJMSActivationSpecs(parentID)
  
      if isEmpty(idList):
        raise StandardError("Cannot find ID; check SIB queue name, cluster and node/server values are correct")
  
      qList = idList.split(progInfo["line.separator"])
  
      _app_trace("Got SIB JMS Activation Specs = %s" % (qList))
  
      #  Delete ALL SIB JMS Activation Specs with the same name (hmmmm!) at this scope
      for q in qList:
        nameAttr = AdminConfig.showAttribute(q, 'name')
  
        if nameAttr == name:
          _app_trace("Running command: AdminTask.deleteSIBJMSActivationSpec(%s)" % (q))
          AdminTask.deleteSIBJMSActivationSpec(q)

    #endelse
    
    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()
    
    retval = 0
    
  except:
  
    _app_trace("An error was encountered deleting the SIB JMS Activation Spec", "exception")
    retval = 1

  _app_trace("deleteSIBJMSActivationSpec(%d)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    listSIBJMSActivationSpecs: List SIB JMS Activation Specs at scope
#
# SYNTAX:
#    listSIBJMSActivationSpecs cluster| (node, server), displayFlag
#
# PARAMETERS:
#    cluster  -  Name of cluster for cluster scoped activation spec
#    node  -  Name of node for server scoped activation spec
#    server  -  Name of server for server scoped activation spec
#    displayFlag-  Boolean indicating whether to print list 
#      (default = 1)
# USAGE NOTES:
#    Lists SIB JMS Activation Specs at the desired scope.  
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showSIBJMSActivationSpecs(cluster, node, server, displayFlag = 1):
  listSIBJMSActivationSpecs(cluster, node, server, displayFlag)
  
def listSIBJMSActivationSpecs(cluster, node, server, displayFlag = 1):

  global progInfo
  
  retval = None
  
  try:
    traceStr = "listSIBJMSActivationSpecs(%s, %s, %s, %d)" % (cluster, node, server, displayFlag)
    _app_trace(traceStr, "entry")  

    #  Check function parameters
    configID = getContainmentPath(cluster, node, server, 1)

    if isEmpty(configID):
      raise StandardError("Could not get containment path")
      
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to list SIB JMS Activation Specs at" % (configID))
      
    #  Get the parentID
    parentID = AdminConfig.getid(configID)

    _app_trace("Running command: AdminTask.listSIBJMSActivationSpecs(%s)" % (parentID))
    str = AdminTask.listSIBJMSActivationSpecs(parentID)

    if isEmpty(str):
      retval = []
    else:
      retval = str.split(progInfo["line.separator"])

    if displayFlag:
      print "\nSI Bus JMS Activation Specs\n------------------------------\n%s\n------------------------------\n" % (str)

  except:
    _app_trace("An error was encountered listing the SIB JMS Activation Specs", "exception")
    retval = None

  _app_trace("listSIBJMSActivationSpecs(%s)" %(retval), "exit")
  return retval


#--------------------------------------------------------------------------------------------------------
# getSIBJMSActivationSpecID
#
# Returns the configuration ID of a SIBJMSActivationSpec
#--------------------------------------------------------------------------------------------------------
def getSIBJMSActivationSpecID(cluster, node,server, actSpecName):

  result = None
  
  try:
  
    _app_trace("getSIBJMSActivationSpecID(%s,%s,%s,%s)" % (cluster,node,server,actSpecName), "entry")

    # See if the ActivationSpec exists
    shortName = actSpecName
    if (actSpecName.startswith("'") or actSpecName.startswith('"')):
      shortName = actSpecName[1:-1]
    specList = []
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        specList = AdminTask.listSIBJMSActivationSpecs(scopeId).split(progInfo["line.separator"])
        
        for actSpec in specList:
            if (not isEmpty(actSpec)):
              if (actSpec.find(shortName) >= 0):
                name = AdminConfig.showAttribute(actSpec,"name")
                
                if (name == actSpecName or name == shortName):
                    result = actSpec
                            
                    #Break out of list loop
                    break
  except:
    _app_trace("Unexpected error getting SIBJMSActivationSpec ID","exception")
    result = None

  _app_trace("getSIBJMSActivationSpecID(%s)" % (result),"exit")
  return result

#--------------------------------------------------------------------------------------------
# findMatchingSIBJMSActivationSpecs
#
# Search for the queues with the specified scope and name pattern. Returns matching queues in
# a dictionary where jmsqueuename = id
# 
#--------------------------------------------------------------------------------------------
def findMatchingSIBJMSActivationSpecs(cluster,node,server,namePattern):

  retval = {}
  
  import re
  
  try:
    _app_trace("findMatchingSIBJMSActivationSpecs(%s,%s,%s,%s)" % (cluster,node,server,namePattern), "entry")

    # See if the activation spec exists
    speclist = []
    scopeId = getScopeId(cluster,node,server)
    if (not isEmpty(scopeId)):
        speclist = AdminTask.listSIBJMSActivationSpecs(scopeId).split(progInfo["line.separator"])
        
        for specid in speclist:
            if (not isEmpty(specid)):
                tempName = AdminConfig.showAttribute(specid,"name")
                if (namePattern.find("*") >= 0):
                  # Regular express
                  if (re.match(namePattern,tempName)):
                      # Add ID to result list
                      retval[tempName] = specid
                else:
                  if (namePattern == tempName):
                      retval[tempName] = specid

  except:
    _app_trace("Unexpected error in findMatchingSIBJMSActivationSpecs","exception")
    raise StandardError("Unexpected error in findMatchingSIBJMSActivationSpecs")

  _app_trace("findMatchingSIBJMSActivationSpecs(%s)" % (retval),"exit")
  return retval




#--------------------------------------------------------------------------------------------------------
# getSIBJMSActivationSpecProperties
#
# Returns the attributes of a SIBJMSActivationSpec as a Properties set, using "activationSpec." prefix.
#--------------------------------------------------------------------------------------------------------
def getSIBJMSActivationSpecProperties(cluster, node, server, actSpecName,actSpecId=None):

  result = java.util.Properties()
  
  try:
  
    _app_trace("getSIBJMSActivationSpecProperties(%s,%s,%s,%s)" % (cluster,node,server,actSpecName), "entry")
    
    actspecnamemap = { 'wAS_EndpointInitialState': 'WAS_EndpointInitialState' }
      
    if (isEmpty(actSpecId)):
      # See if the activation spec exists
      specList = []
      scopeId = getScopeId(cluster,node,server)
      if (not isEmpty(scopeId)):
        specList = AdminTask.listSIBJMSActivationSpecs(scopeId).split(progInfo["line.separator"])
        
        for actSpec in specList:
            if (not isEmpty(actSpec)):
                name = AdminConfig.showAttribute(actSpec,"name")
                if (name == actSpecName):
                  actSpecId = actSpec
                  break
    
    if (not isEmpty(actSpecId)):
        actSpec = actSpecId
        dict = wsadminToDictionary(AdminTask.showSIBJMSActivationSpec(actSpec))
        result.put("activationSpec.name", actSpecName)
        # Return dictionary as a property set
        for key in dict.keys():
            val = dict.get(key)
            if (isEmpty(val)):
                continue
            if (actspecnamemap.has_key(key)):
               #Use alternative name
               key = actspecnamemap.get(key)
               
            if (key != "name"):
                result.put("activationSpec.prop.%s" %key, val)
                            
  except:
    _app_trace("Unexpected error getting SIBJMSActivationSpec properties","exception")
    result = None

  _app_trace("getSIBJMSActivationSpecProperties(%s)" % (result),"exit")
  return result
    

