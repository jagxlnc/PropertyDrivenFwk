#------------------------------------------------------------------------------------------
# URL.py
#
# This module contains functions for finding,reading,creating, and updating URLProvider and
# URL resources. 
#
# Functions:
#   createURLProvider(name,c,n,s,dc,providerProperties,providerResourceProps=None):
#   modifyURLProvider(providerId,providerProperties,providerResourceProps=None):
#   createURL(providerId,name,urlProps,urlResourceProps=None):
#   modifyURL(urlId,urlProps,urlResourceProps=None):
#   findURLProvider(name,c,n,s,dc):
#   findURL(providerId=None,urlName=None,jndiName=None,providerName=None,c=None,n=None,s=None,dc=None):
#   getURLProperties(url):
#   getURLProviderProperties(urlProvider):
#
# Related modules:
#   common.py
#   Utils.py



#------------------------------------------------------------------------------------------
# createURLProvider
#
# Parameters:
#   name - the name of the URL provider
#   c - cluster name if at cluster scope
#   n - node name if at node or server scope
#   s - server name if server scope or Dynamic Cluster template
#   dc - dynamic cluster name if dynamic cluster template
#   providerProperties - dictionary with key/value pairs of URLProvider properties to set
#   resourceProperties - key/value definitions of resource properties to be set (if any)
#
# Returns configuration ID of created URLProvider
#------------------------------------------------------------------------------------------
def createURLProvider(name,c,n,s,dc,providerProperties,providerResourceProps=None):
  _app_trace("createURLProvider(%s,%s,%s,%s,%s,%s,%s)" %(name,c,n,s,dc,providerProperties,providerResourceProps),"entry")
  retval = None
  try:
    parentId = getScopeId(c,n,s,dc)
    
    if (isEmpty(parentId)):
      raise StandardError("Unable to find parent for URL provider")
      
    attrs = [["name",name]]
    attrs.extend(propsToAttrList(providerProperties))
    
    _app_trace('About to call AdminConfig.create("URLProvider",%s,%s)'% (parentId,attrs))
    retval = AdminConfig.create("URLProvider",parentId,attrs)
    
    if (providerResourceProps != None and len(providerResourceProps) > 0):
      updateJ2EEResourcePropertySet(retval, providerResourceProps, attributeName="propertySet")
    
  except:
    _app_exception("Unexpected error in createURLProvider")
  
  _app_trace("createURLProvider(retval=%s)" % retval,"exit")
  return retval


#------------------------------------------------------------------------------------------
# modifyURLProvider
#
# Parameters:
#   providerId - Configuration ID of the URL provider
#   providerProperties - dictionary with key/value pairs of URLProvider properties to set
#   resourceProperties - key/value definitions of resource properties to be set (if any)
#------------------------------------------------------------------------------------------
def modifyURLProvider(providerId,providerProperties,providerResourceProps=None):
  _app_trace("modifyURLProvider(%s,%s,%s)" %(providerId,providerProperties,providerResourceProps),"entry")
  retval = None
  try:
    
    if (len(providerProperties) > 0):
      # Call utility method that will properly handle list attributes
      modifyObjectProperties(providerId,providerProperties,configurationType="URLProvider")

    if (providerResourceProps != None and len(providerResourceProps) > 0):
      updateJ2EEResourcePropertySet(providerId, providerResourceProps, attributeName="propertySet")
    
  except:
    _app_exception("Unexpected error in modifyURLProvider")
  
  _app_trace("modifyURLProvider(retval=%s)" % retval,"exit")
  return retval
 

#------------------------------------------------------------------------------------------
# createURL
#   creates a URL resource under an existing URLProvider
#
# Parameters:
#    providerId - configuration ID of URLProvider that is parent of URL
#    urlProps - key/values of base URL properties to set
#    urlResourceProps - key/values of J2EE Resource Properties to set in format
#                       supported by updateJ2EEResourcePropertySet (see Utils.py)

#------------------------------------------------------------------------------------------
def createURL(providerId,name,urlProps,urlResourceProps=None):
  _app_trace("createURL(%s,%s,%s,%s)" % (providerId,name,urlProps,urlResourceProps),"entry")
  retval = None
  try:
    attrs = [["name",name],["provider",providerId]]
    attrs.extend(propsToAttrList(urlProps))
    _app_trace('About to call AdminConfig.create("URL",%s,%s)'%(providerId,attrs))
    retval = AdminConfig.create("URL",providerId,attrs)
    if (urlResourceProps != None and len(urlResourceProps) > 0):
      updateJ2EEResourcePropertySet(retval,urlResourceProps,attributeName="propertySet")
  except:
    _app_exception("Unexpected error in createURL")
  
  _app_trace("createURL(retval=%s)" % retval,"exit")
  return retval

#------------------------------------------------------------------------------------------
# modifyURL
#   Funtion that can be used to update existing URL resource
#
# Parameters:
#    urlId - configuration ID of item to be updated
#    urlProps - key/values of base URL properties to set
#    urlResourceProps - key/values of J2EE Resource Properties to set in format
#                       supported by updateJ2EEResourcePropertySet (see Utils.py)
# 
#------------------------------------------------------------------------------------------
def modifyURL(urlId,urlProps,urlResourceProps=None):
  _app_trace("modifyURL(%s,%s,%s)" % (urlId,urlProps,urlResourceProps),"entry")
  retval = urlId
  try:
    if (urlProps != None and len(urlProps) > 0):
      attrs = propsToAttrList(urlProps)
      if (modifyObject(urlId,attrs)):
        _app_exception("Error modifying URL %s" % urlId)
      
    if (urlResourceProps != None and len(urlResourceProps) > 0):
      updateJ2EEResourcePropertySet(urlId,urlResourceProps,attributeName="propertySet")
  except:
    _app_exception("Unexpected error in modifyURL")
  
  _app_trace("modifyURL(retval=%s)" % retval,"exit")
  return retval

  

#------------------------------------------------------------------------------------------
# findURLProvider
#   Searches for a URLProvider at the specified scope
#
#   name - the name of the URL provider
#   c - cluster name if at cluster scope
#   n - node name if at node or server scope
#   s - server name if server scope or Dynamic Cluster template
#   dc - dynamic cluster name if dynamic cluster template
#------------------------------------------------------------------------------------------
def findURLProvider(name,c,n,s,dc):
  _app_trace("findURLProvider(%s,%s,%s,%s,%s)" % (name,c,n,s,dc),"entry")
  retval = None
  try:
    if (not isEmpty(c)):
       retval = AdminConfig.getid("/ServerCluster:%s/URLProvider:%s/"% (c,name))
    elif (not isEmpty(dc) and not isEmpty(s)):
      retval = AdminConfig.getid("/DynamicCluster:%s/Server:%s/URLProvider:%s/"% (dc,s,name))
    elif (not isEmpty(n)):
      if (isEmpty(s)):
        retval = AdminConfig.getid("/Node:%s/URLProvider:%s/" % (n,name))
      else:
        retval = AdminConfig.getid("/Node:%s/Server:%s/URLProvider:%s/" % (n,s,name))
    elif (isEmpty(c) and isEmpty(n) and isEmpty(s) and isEmpty(dc)):
      retval = AdminConfig.getid("/Cell:%s/URLProvider:%s/" % (getCellName(),name))
  except:
    _app_exception("Unexpected error in findURLProvider(%s,%s,%s,%s,%s)" % (name,c,n,s,dc))

  _app_trace("findURLProvider(retval=%s)" % retval)
  return retval

#------------------------------------------------------------------------------------------
# findURL
#
# Parameters:
#   providerId - The URLProvider to search under
#   urlName - the name of the URL resource to search for
#   jndiName - (optional) the JNDI name to look for
#   providerName - the name of the URL provider if providerId not specified
#   c - cluster name if at cluster scope
#   n - node name if at node or server scope
#   s - server name if server scope or Dynamic Cluster template
#   dc - dynamic cluster name if dynamic cluster template

#------------------------------------------------------------------------------------------
def findURL(providerId=None,urlName=None,jndiName=None,providerName=None,c=None,n=None,s=None,dc=None):
  _app_trace("findURL(%s,%s,%s)" % (providerId,urlName,jndiName),"entry")
  retval = None
  
  try:
    if (providerId==None and not isEmpty(providerName)):
      providerId = findURLProvider(providerName,c,n,s,dc)
      
    if (isEmpty(providerId)):
      raise StandardError("URLProvider not specified or not found")
    
    urls = AdminConfig.list("URL",providerId).splitlines()
    
    for url in urls:
      if (isEmpty(url)):
        continue
      tempName = AdminConfig.showAttribute(url,"name")
      tempJndi = AdminConfig.showAttribute(url,"jndiName")
      if (not isEmpty(urlName)):
        if (tempName == urlName):
          if (isEmpty(jndiName)):
            retval = url
            break
          elif (jndiName == tempJndi):
            retval = url
            break
      elif (not isEmpty(jndiName)):
        if (tempJndi == jndiName):
          retval = url
          break
        

  except:
    _app_exception("Unexpected error in findURL")
  
  _app_trace("findUrl(retval=%s)" % retval,"exit")
  return retval

#---------------------------------------------------------------------------
# getURLProperties(url)
#
# Returns a dictionary of key/values that represent settings of URL
#  url.prop.key = val
#  url.resourceProperties.prop.key = value
#--------------------------------------------------------------------------
def getURLProperties(url):
  _app_trace("getURLProperties(%s)" % (url),"entry")
  props = {}
  try:
    collectSimpleProperties(props,"url.prop",url,getSimpleChildren=1,collectPropertyAttributes=1)
  except:
    _app_exeception("Unexpected error in getURLProperties")

  _app_trace("getURLProperties()","exit")
  return props  
  
#---------------------------------------------------------------------------
# getURLProviderProperties(urlProvider)
#
# Returns a dictionary of key/values that represent settings of URLProvider
#  url.provider.prop.key = val
#  url.provider.resourceProperties.prop.key = value
#--------------------------------------------------------------------------
def getURLProviderProperties(urlProvider):
  _app_trace("getURLProviderProperties(%s)" % (urlProvider),"entry")
  props = {}
  try:
    collectSimpleProperties(props,"url.provider.prop",urlProvider,getSimpleChildren=1,collectPropertyAttributes=1)
  except:
    _app_exeception("Unexpected error in getURLProviderProperties")

  _app_trace("getURLProviderProperties()","exit")
  return props  