##########################################################################################################
# ProcessWorkManager.py
#
# This module contains the functions that processes the Work Manager definition properties
# in the globabl configInfo dictionary.
#
# 
# Primary function: 
#    processWorkManagers()
#
# Related modules:
#		 WorkManager.py - Contains functions used to find/create/modify Work Managers
#    Utils.py - Utility methods
#
# Property Syntax:
#  
# Here's a general breakdown of the property syntax.  For complete examples of the properties, use
# the dumpConfig.py script to produce properties for an existing Work Manager.
#
# # scope settings for the provider, leave all blank for cell scope
# # The @ITERATE keyword can be used to process multiple work manager scopes
# # with a common definition.
# app.workmanager.provider.<index>.cluster = <Cluster-name if cluster-scoped, optionally can be @ITERATE keyword>
# app.workmanager.provider.<index>.node = 	<Node-name if node-scoped or server-scoped, optionally can be @ITERATE keyword>
# app.workmanager.provider.<index>.server = <Server-name if server-scoped, optionally can be @ITERATE keyword>
#
# # The name and description fields of the WorkManagerProvider are always the same
# app.workmanager.provider.<index>.prop.name = WorkManagerProvider
# app.workmanager.provider.<index>.prop.description = Default WorkManager Provider
#
# # Settings for a specific work manager
# app.workmanager.provider.<index>.workmanager.<wmindex>.name = MyClusterWorkManager
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.description = This is my custom work manager
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.isDistributable = false
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.isGrowable = true
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.jndiName = wm/MyClusterWorkManager
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.maxThreads = 3
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.minThreads = 0
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.numAlarmThreads = 2
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.threadPriority = 5
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.workReqQFullAction = 1
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.workReqQSize = 1000
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.workTimeout = 10000
#
# # Optional syntax for creating/modifying a work manager with settings
# # from a previously defined work manager.  The name field for the new
# # WorkManager is required, jndiName is optional if you want a different jndiName
# # than the one used by model Work Manager
# app.workmanager.provider.<index>.workmanager.<wmindex>.name = <Name for new/updated work manager>
# app.workmanager.provider.<index>.workmanager.<wmindex>.prop.jndiName = <OPTIONAL new jndiName>
# app.workmanager.provider.1.workmanager.1.modelName = <Name of existing work manager>
# app.workmanager.provider.1.workmanager.1.modelCluster = <cluster name of model defined at cluster scope>
# app.workmanager.provider.1.workmanager.1.modelNode = <node name of model defined at node or server scope>
# app.workmanager.provider.1.workmanager.1.modelServer = <server name of model defined at server scope>
#
# # Count field for work managers defined at this scope
# app.workmanager.provider.<index>.workmanager.count = <count>
#
# # Count 
# app.workmanager.provider.count = <count of providers>
##########################################################################################################


#---------------------------------------------------------------------------------------------------------
# WorkManagerScopeValues
#
# This class is used to represent a dynamically determined scoped configuration for a work manager provider.
# When processing Work Manager input properties, the @ITERATE flag in a scope field will require that the
# work managers be created/updated at many different scopes.
#---------------------------------------------------------------------------------------------------------
class WorkManagerScopeValues:

		prefix = ""

		cluster = ""
		node = ""
		server = ""
		
		clusterId = ""
		nodeId = ""
		serverId = ""
		
		def __init__(self, c,n,s,p):
				self.cluster = c
				self.node = n
				self.server = s
				self.prefix = p
		
		def setIds(self, cid, nid, sid):
				self.clusterId = cid
				self.nodeId = nid
				self.serverId = sid


#------------------------------------------------------------------------------------------------------
# buildWorkManagerScopeList
# Evaluate the cluster, ndoe, and server settings to see if they are special @ITERATE flag that indicates
# that this Work Manager provider needs to be defined at multiple scopes.
#
# After evaluating the settings (and processing any @ITERATE logic), this function will return the
# list of WorkManagerScopeValues objects that the work managers should be declared at.
#------------------------------------------------------------------------------------------------------
def buildWorkManagerScopeList(clusterSetting, nodeSetting, serverSetting, prefix):

	global progInfo

	result = []
	_app_trace("buildWorkManagerScopeList(%s,%s,%s,%s)" % (clusterSetting, nodeSetting, serverSetting, prefix),"entry")
	try:
		
		if (clusterSetting == None): clusterSetting = ""
		if (nodeSetting == None): nodeSetting = ""
		if (serverSetting == None): serverSetting = ""
		
		iterateNodes = 0
		iterateServers = 0
		iterateClusters = 0
		
		if (nodeSetting.find("@ITERATE") >= 0):
				iterateNodes = 1
				nodeSetting = ""
		
		if (serverSetting.find("@ITERATE") >= 0):
				iterateServers = 1
				serverSetting = ""
		
		if (clusterSetting.find("@ITERATE") >= 0):
				iterateClusters = 1
				clusterSetting = ""
				
		if (iterateClusters):
				# Create cluster level variable for all clusters
				clusterList = AdminConfig.list("ServerCluster").split(progInfo["line.separator"])
				for clusterId in clusterList:
						if not isEmpty(clusterId):
								clusterName = AdminConfig.showAttribute(clusterId,"name")
								
								varscope = WorkManagerScopeValues(clusterName,"","",prefix)
								varscope.setIds(clusterId, "","")
								result.append(varscope)
								
		elif (not iterateNodes and not iterateServers):
				# Simple case, create one scope object
				varscope = WorkManagerScopeValues(clusterSetting, nodeSetting, serverSetting,prefix)
				
				clusterId = nodeId = serverId = ""
				
				if (not isEmpty(clusterSetting)):
						clusterId = AdminConfig.getid("/ServerCluster:%s/"% clusterSetting)
						if (isEmpty(clusterId)):
								raise StandardError("Unable to get ID for ServerCluster %s" % clusterSetting)
				
				if (not isEmpty(nodeSetting)):
						nodeId = AdminConfig.getid("/Node:%s/"%(nodeSetting))
						if (isEmpty(nodeId)):
								raise StandardError("Unable to get ID for Node %s" % nodeSetting)
				
						if (not isEmpty(serverSetting)):
								serverId = AdminConfig.getid("/Node:%s/Server:%s/"% (nodeSetting,serverSetting))
								if (isEmpty(serverId)):
										raise StandardError("Unable to get ID for Server %s:%s" % (nodeSetting,serverSetting))
				
				varscope.setIds(clusterId, nodeId, serverId)
				
				result.append(varscope)
		elif (iterateServers and not isEmpty(clusterSetting)):
				# The variable should be created at server scope on all cluster members
				clusterId = AdminConfig.getid("/ServerCluster:%s/"% clusterSetting)
				
				clusterMembers = AdminConfig.list("ClusterMember", clusterId).split(progInfo["line.separator"])
				for clusterMember in clusterMembers:
						if (isEmpty(clusterMember)):
								continue
						
						mName = AdminConfig.showAttribute(clusterMember, "memberName")
						mNode = AdminConfig.showAttribute(clusterMember, "nodeName")
						
						nodeId = AdminConfig.getid("/Node:%s/" % mNode)
						if (isEmpty(nodeId)):
								raise StandardError("Unable to get ID for Node %s" % mNode)
						
						serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (mNode,mName))
						if (isEmpty(serverId)):
										raise StandardError("Unable to get ID for Server %s:%s" % (mNode,mName))
						
						varscope = WorkManagerScopeValues("",mNode,mName,prefix)
						varscope.setIds(clusterId, nodeId, serverId)
						result.append(varscope)
		elif (iterateNodes and not isEmpty(clusterSetting)):
				# The variable should be created at Node scope for each node in the cluster
				clusterId = AdminConfig.getid("/ServerCluster:%s/"% clusterSetting)
				nodeList = []
				clusterMembers = AdminConfig.list("ClusterMember", clusterId).split(progInfo["line.separator"])
				for clusterMember in clusterMembers:
						if (isEmpty(clusterMember)):
								continue
						
						
						mNode = AdminConfig.showAttribute(clusterMember, "nodeName")
						
						if not mNode in nodeList:
								nodeList.append(mNode)
						
								nodeId = AdminConfig.getid("/Node:%s/" % mNode)
								serverId = ""
						
								varscope = WorkManagerScopeValues("",mNode,"",prefix)
								varscope.setIds(clusterId, nodeId, serverId)
								result.append(varscope)
		elif (iterateServers):
			appserverlist = AdminConfig.list("ApplicationServer").split(progInfo["line.separator"])
			for app in appserverlist:
					if (not isEmpty(app)):
							serverId = AdminConfig.showAttribute(app,"server")

							if not isEmpty(serverId):
								serverName = AdminConfig.showAttribute(serverId, "name")
							
								# determine the node
								nodeId = getNodeForServer(serverId)
								nodeName = AdminConfig.showAttribute(nodeId,"name")
								
								varscope = WorkManagerScopeValues("",nodeName, serverName,prefix)
								varscope.setIds("", nodeId, serverId)
								result.append(varscope)
								
		elif (iterateNodes):
				nodeList = wsadminToList(AdminTask.listManagedNodes())
				#nodeList = AdminConfig.list("Node").split(progInfo["line.separator"])
				for nodeName in nodeList:
						nodeId = AdminConfig.getid("/Node:%s/" % (nodeName))
						if not isEmpty(nodeId):
								nodeName = AdminConfig.showAttribute(nodeId,"name")
								varscope = WorkManagerScopeValues("",nodeName,"",prefix)
								varscope.setIds("",nodeId,"")
								result.append(varscope)
				
	except:
			_app_trace("Error processing workmanager scope settings: %s %s %s" % (clusterSetting, nodeSetting, serverSetting),"exception")
			_app_message("Error processing workmanager scope settings: %s %s %s" % (clusterSetting, nodeSetting, serverSetting))
			exit()
		
	_app_trace("buildWorkManagerScopeList(%d items)" % len(result),"exit")
	return result

				
#-------------------------------------------------------------------------------------------------------------
# The serviceNames attribute is returned as a semi-colan separated string in no-particular order
# This method will compare two values to see if they are actually identical
#
# Returns 1 - identical, 0- not
#-------------------------------------------------------------------------------------------------------------
def equalServiceNames(string1, string2):
		result = 1
		
		if (not isEmpty(string1) and not isEmpty(string2)):
			list1 = string1.split(";")
			list2 = string2.split(";")
			if (len(list1) != len(list2)):
					result = 0
			else:
					for val in list1:
							if not (val in list2): 
									result = 0
									break
		#print string1
		#print string2
		#print result
		return result
		
		
		

#--------------------------------------------------------------------------------------------------------------
# @JJM
# processWorkManagersForProvider
# 
# Process the work manager settings for the specific cluster scope
#--------------------------------------------------------------------------------------------------------------
def processWorkManagersForProvider(wmProvider, scopeId, pScope, prefix):

	try:
	
		_app_trace("processWorkManagersForProvider(%s,%s,%s,%s)" % (wmProvider, scopeId, pScope, prefix), "entry")

		global progInfo
		global configInfo

		if not configInfo.has_key("%s.workmanager.count" %(prefix)):
			_app_message("Skipping Building WorkManagers for provider %s " % (prefix))
			return
		
		for wmidx in range(1, int(configInfo["%s.workmanager.count" %(prefix)]) + 1):
		
				wmName = configInfo.get("%s.workmanager.%d.name" % (prefix, wmidx),"")
				if (isEmpty(wmName)):
						# Possibly partial property file?
						continue
				
				# Get scope Name for logging purposes
				scopeName = "%s %s" % (pScope, AdminConfig.showAttribute(scopeId,"name"))
				
				wmId = findWorkManagerWithName(wmName,wmProvider)
				if (wmId == "ERROR"):
						_app_message("Error searching for WorkManager with name %s at provider %s %s" % (wmName, scopeName, wmProvider))
						exit()
						
				# See if we are copying settings from an existing server
				modelProperties = None
				modelName = configInfo.get("%s.workmanager.%d.modelName" % (prefix, wmidx),"")
				if (not isEmpty(modelName)):
						modelCluster = configInfo.get("%s.workmanager.%d.modelCluster" % (prefix, wmidx),"")
						modelNode = configInfo.get("%s.workmanager.%d.modelNode" % (prefix, wmidx),"")
						modelServer = configInfo.get("%s.workmanager.%d.modelServer" % (prefix, wmidx),"")
						
						modelId = findWorkManagerAtScope(modelCluster, modelNode, modelServer, modelName)
						if (modelId == None or modelId == "ERROR"):
								_app_message("Unable to load properties from model server %s %s %s %s" % (modelCluster, modelNode, modelServer, modelName))
								raise StandardError("Unable to load properties from model server %s %s %s %s" % (modelCluster, modelNode, modelServer, modelName))
								
						modelProperties = getWorkManagerProperties(modelId)
						
						# See if the input properties has the jndiName, and if it does, use it instead of model jndi name
						# All other properties will come from the model
						jndiName = configInfo.get("%s.workmanager.%d.prop.jndiName" % (prefix, wmidx),"")
						if (not isEmpty(jndiName)):
								modelProperties.put("app.workmanager.prop.jndiName",jndiName)
				
				
				if (isEmpty(wmId)):
						# Creating a new work manager
						if (modelProperties == None):
								# Pull properties from configInfo
								subProps = getPropList(configInfo, "%s.workmanager.%d" %(prefix,wmidx))
								resourceProps = getPropList(configInfo, "%s.workmanager.%d.resourceProperties" %(prefix,wmidx))
						else:
								# Pull properties from existing model 
								subProps = getPropList(modelProperties, "app.workmanager" )
								resourceProps = getPropList(modelProperties, "app.workmanager.resourceProperties")

						
						wmID  = createWorkManager(wmProvider, wmName, subProps,resourceProps)
						if (wmID == None):
								_app_message("Error creating work manager %s at scope %s" % (wmName, scopeName))
								exit()
						else:
								_app_message("Created work manager %s at scope %s" % (wmName, scopeName))
				else:
						# Updating an existing work manager
						existingProps = getWorkManagerProperties(wmId)

						if (modelProperties == None):
								# Compare configuration properties against existing setings
								subProps = getPropListDifferences(configInfo, "%s.workmanager.%d" % (prefix,wmidx), existingProps, "app.workmanager")
								subProps.remove("name")
								resourceProps = getPropListDifferences(configInfo, "%s.workmanager.%d.resourceProperties" % (prefix,wmidx), existingProps, "app.workmanager.resourceProperties")
						else:
								# Compare model work manager properties against existing
								subProps = getPropListDifferences(modelProperties, "app.workmanager", existingProps, "app.workmanager")
								resourceProps = getPropListDifferences(modelProperties, "app.workmanager.resourceProperties", existingProps, "app.workmanager.resourceProperties")
						
						
						
						if (subProps.size() > 0):
								serviceNamesInput = subProps.get("serviceNames")
								if (serviceNamesInput != None):
										serviceNamesExisting = existingProps.get("app.workmanager.prop.serviceNames")
										if (equalServiceNames(serviceNamesInput, serviceNamesExisting)):
												subProps.remove("serviceNames")
						
						if (subProps.size() > 0 or resourceProps.size() > 0):
								# Update the work manager
								updateResult = updateWorkManager(wmId, wmName, subProps,resourceProps)
								if (updateResult == None):
										_app_message("Error processing updates for WorkManager %s at scope %s" % (wmName, scopeName))
										exit()
								else:
										_app_message("Updated WorkManager %s at scope %s" % (wmName, scopeName))
						else:
								_app_message("No new updates for WorkManager %s at scope %s" % (wmName, scopeName))
	
	except:
		_app_trace("Unexpected error in processWorkManagersForProvider()","exception")
		_app_message("Unexpected error processing work manager configuration")
		exit()
	
	_app_trace("processWorkManagersForProvider()","exit")			


#--------------------------------------------------------------------------------------------------------------		
# @JJM
# processWorkManagers
# Iterate throught the app.workmanager settings loaded into the configInfo dictionary and process the
# configuration changes.
#--------------------------------------------------------------------------------------------------------------		
def processWorkManagersForScope(pCluster, pNode, pServer, prefix) :

	try:
	
		_app_trace("processWorkManagersForScope(%s,%s,%s,%s)" % (pNode, pServer, pCluster, prefix),"entry")
	
		global progInfo
		global configInfo
		
		pScope = ""

		if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
				pScope = "cell"
				cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
				for cell in cells:
						wmProvider=AdminConfig.getid("/Cell:%s/WorkManagerProvider:WorkManagerProvider/" % AdminConfig.showAttribute(cell,"name"))
						processWorkManagersForProvider(wmProvider, cell, pScope, prefix)
						break
		else:
			if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer):
					pScope = "cluster"
					cluster = AdminConfig.getid("/ServerCluster:%s" % pCluster)
					wmProvider=AdminConfig.getid("/ServerCluster:%s/WorkManagerProvider:WorkManagerProvider/" % AdminConfig.showAttribute(cluster,"name"))
					processWorkManagersForProvider(wmProvider, cluster, pScope, prefix)
			else:
				if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
						pScope = "node"
						node = AdminConfig.getid("/Node:%s" % pNode)
						wmProvider=AdminConfig.getid("/Node:%s/WorkManagerProvider:WorkManagerProvider/" % AdminConfig.showAttribute(node,"name"))
						if (not isEmpty(wmProvider)):
								processWorkManagersForProvider(wmProvider, node, pScope, prefix)
						else:
								_app_message("Skipping work manager processing for node %s" % pNode)
				else:
						if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
								pScope = "server"
								server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
						
								wmProvider=AdminConfig.getid("/Server:%s/WorkManagerProvider:WorkManagerProvider/" % AdminConfig.showAttribute(server,"name"))
								if (not isEmpty(wmProvider)):
										processWorkManagersForProvider(wmProvider, server, pScope, prefix)
								else:
										_app_message("Skipping work manager processing for server %s:%s" % (pNode,pServer))
													
	except:
		_app_trace("Unexpected error in processWorkManagers()","exception")
		_app_message("Unexpected error processing work manager configuration")
		exit()

	_app_trace("processWorkManagers()","exit")

#--------------------------------------------------------------------------------------------------------------		
# @JJM
# processWorkManagers
# Iterate throught the app.workmanager settings loaded into the configInfo dictionary and process the
# configuration changes.
#--------------------------------------------------------------------------------------------------------------		
def processWorkManagers() :

	try:
	
		_app_trace("processWorkManagers()","entry")
	
		global progInfo
		global configInfo
		
		if not configInfo.has_key("app.workmanager.provider.count"):
			_app_message("Skipping Building WorkManagers")
			_app_trace("processWorkManagers()","exit")
			return
			
		pScope = ""
			
		for providx in range(1, int(configInfo["app.workmanager.provider.count"]) + 1):
				prefix = "app.workmanager.provider.%d" % ( providx )
				
				# Check the name just to make sure we have a provider at this point in the list
				providerName = configInfo.get("%s.prop.name"%prefix,"")
				if (isEmpty(providerName)):
						# Must be a partial list
						continue
				
				pNode = configInfo.get("%s.node" % (prefix),"")
				pServer = configInfo.get("%s.server" % (prefix),"")
				pCluster = configInfo.get("%s.cluster" % (prefix),"")
				
				# This might be a definition for multiple providers
				scopeList = buildWorkManagerScopeList(pCluster, pNode, pServer, prefix)
				for wmscopeinfo in scopeList:
						processWorkManagersForScope(wmscopeinfo.cluster, wmscopeinfo.node, wmscopeinfo.server, prefix)
				
													
	except:
		_app_trace("Unexpected error in processWorkManagers()","exception")
		_app_message("Unexpected error processing work manager configuration")
		exit()

	_app_trace("processWorkManagers()","exit")