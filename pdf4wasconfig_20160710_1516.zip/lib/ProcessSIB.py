############################################################################################
# ProcessSIB.py
#
# This module contains the functions that process the properties that define a SIBus,
# SIBusMembers, SIBus Destinations, and Mediations.  These properties are preloaded into the global
# configInfo dictionary prior to calling the processSIB() method.
#
#
# Primary entry point:
#       processSIB()
#
# Related modules:
#				Utils.py						- common utility functions
#				SIBus.py						- Functions for manipulating base SIBus definition
#       SIBusMember.py			- Functions for manipulating SIBusMember definitions
#				SIBEngine.py				- Functions for manipulating SIBEngine definitions
#       SIBDestination.py		- Functions for manipulating SIBDestination definitions
#				dumpConfig.py				- Can produce property file from existing SIBus configuration
#
# Property Syntax overview:
#
# Notes on messaging engine names: Messaging engine names are generated.  If an existing SIBus
# with the specified name is found, it will be updated, otherwise a new messaging engine will
# be created.  If the bus member has been manually updated with added/deleted bus members,
# the messaging engine names may not match up with input properties.
#
#	Notes on uuid properties. The dumpConfig utility will produce uuid properties for the
# different SIBus components. These are ignored as they are generated values.
#
# -----------------------------------------------------------------------------
# Base SIBus properties:
#
# app.sibus.1.name = SampleBus
# app.sibus.1.prop.description = This is my sample bus
# app.sibus.1.prop.configurationReloadEnabled = true
# app.sibus.1.prop.discardMsgsAfterQueueDeletion = false
# app.sibus.1.prop.highMessageThreshold = 50000
# app.sibus.1.prop.interEngineAuthAlias = Dude3
# app.sibus.1.prop.mediationsAuthAlias = Dude4
# app.sibus.1.prop.secure = true
# app.sibus.1.prop.usePermittedChains = SSL_ENABLED
# app.sibus.1.prop.uuid = B66EB8C8AB509343
# app.sibus.1.customProperties.prop.sib.property1 = Value1|This is a sample property
# app.sibus.1.customProperties.prop.sib.property2 = Value2
# ...
# app.sibus.count = <max index for sibus>
#
# -----------------------------------------------------------------------------
# SIBAuthSpace properties
# You can add users and groups to the bus connector,browser,creator,identityAdopter,
# receiver and sender roles for the SIBus. Any entries added to these roles should
# also be specified in the sibauthspace.group or sibauthspace.user lists 
# 
# app.sibus.1.sibauthspace.group.1.prop.identifier = AllAuthenticated
# app.sibus.1.sibauthspace.group.2.prop.identifier = Server
# app.sibus.1.sibauthspace.group.3.prop.identifier = BusGroup1
# app.sibus.1.sibauthspace.group.3.prop.uniqueName = cn=BusGroup1,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.group.count = 3
# app.sibus.1.sibauthspace.user.1.prop.identifier = jjm
# app.sibus.1.sibauthspace.user.1.prop.uniqueName = uid=jjm,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.user.count = 1
# app.sibus.1.sibauthspace.busConnect.group.1.prop.identifier = Server
# app.sibus.1.sibauthspace.busConnect.group.2.prop.identifier = BusGroup1
# app.sibus.1.sibauthspace.busConnect.group.2.prop.uniqueName = cn=BusGroup1,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.busConnect.group.3.prop.identifier = AllAuthenticated
# app.sibus.1.sibauthspace.busConnect.group.count = 3
# app.sibus.1.sibauthspace.busConnect.user.1.prop.identifier = jjm
# app.sibus.1.sibauthspace.busConnect.user.1.prop.uniqueName = uid=jjm,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.busConnect.user.count = 1
# app.sibus.1.sibauthspace.default.browser.group.1.prop.identifier = AllAuthenticated
# app.sibus.1.sibauthspace.default.browser.group.2.prop.identifier = BusGroup2
# app.sibus.1.sibauthspace.default.browser.group.2.prop.uniqueName = cn=BusGroup2,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.browser.group.count = 2
# app.sibus.1.sibauthspace.default.browser.user.1.prop.identifier = jjm
# app.sibus.1.sibauthspace.default.browser.user.1.prop.uniqueName = uid=jjm,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.browser.user.count = 1
# app.sibus.1.sibauthspace.default.creator.group.1.prop.identifier = AllAuthenticated
# app.sibus.1.sibauthspace.default.creator.group.2.prop.identifier = BusGroup2
# app.sibus.1.sibauthspace.default.creator.group.2.prop.uniqueName = cn=BusGroup2,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.creator.group.count = 2
# app.sibus.1.sibauthspace.default.creator.user.1.prop.identifier = jjm
# app.sibus.1.sibauthspace.default.creator.user.1.prop.uniqueName = uid=jjm,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.creator.user.count = 1
# app.sibus.1.sibauthspace.default.identityAdopter.group.1.prop.identifier = BusGroup2
# app.sibus.1.sibauthspace.default.identityAdopter.group.1.prop.uniqueName = cn=BusGroup2,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.identityAdopter.group.count = 1
# app.sibus.1.sibauthspace.default.identityAdopter.user.1.prop.identifier = jjm
# app.sibus.1.sibauthspace.default.identityAdopter.user.1.prop.uniqueName = uid=jjm,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.identityAdopter.user.count = 1
# app.sibus.1.sibauthspace.default.receiver.group.1.prop.identifier = AllAuthenticated
# app.sibus.1.sibauthspace.default.receiver.group.2.prop.identifier = BusGroup2
# app.sibus.1.sibauthspace.default.receiver.group.2.prop.uniqueName = cn=BusGroup2,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.receiver.group.count = 2
# app.sibus.1.sibauthspace.default.receiver.user.1.prop.identifier = jjm
# app.sibus.1.sibauthspace.default.receiver.user.1.prop.uniqueName = uid=jjm,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.receiver.user.count = 1
# app.sibus.1.sibauthspace.default.sender.group.1.prop.identifier = AllAuthenticated
# app.sibus.1.sibauthspace.default.sender.group.2.prop.identifier = BusGroup2
# app.sibus.1.sibauthspace.default.sender.group.2.prop.uniqueName = cn=BusGroup2,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.sender.group.count = 2
# app.sibus.1.sibauthspace.default.sender.user.1.prop.identifier = jjm
# app.sibus.1.sibauthspace.default.sender.user.1.prop.uniqueName = uid=jjm,o=defaultWIMFileBasedRealm
# app.sibus.1.sibauthspace.default.sender.user.count = 1
# 
# -----------------------------------------------------------------------------
# Bus Member and Message Engine properties:
#   A bus member is either a cluster or individual server.  When the Bus Member is created,
#   the first Message Engine properties are included with the member definition.  Additional
#   messaging engines are added after after the member is created.
# 
# app.sibus.1.busmembers.1.cluster = SampleCluster
# app.sibus.1.busmembers.1.node = 
# app.sibus.1.busmembers.1.server = 
# 
# app.sibus.1.busmembers.1.messageEngines.1.name = SampleCluster.000-SampleBus
# app.sibus.1.busmembers.1.messageEngines.1.prop.busName = SampleBus
# app.sibus.1.busmembers.1.messageEngines.1.prop.busUuid = B66EB8C8AB509343
# app.sibus.1.busmembers.1.messageEngines.1.prop.highMessageThreshold = 50000
# app.sibus.1.busmembers.1.messageEngines.1.prop.initialState = STARTED
# app.sibus.1.busmembers.1.messageEngines.1.prop.messageStoreType = DATASTORE
# app.sibus.1.busmembers.1.messageEngines.1.prop.uuid = 9A8E945F847DEAE7
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.authAlias = Dude3
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.createTables = true
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.dataSourceName = jdbc/mysibds
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.permanentTables = 1
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.schemaName = IBMWSSIB
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.temporaryTables = 1
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.uuid = 74FA31F955B9AB1B
# app.sibus.1.busmembers.1.messageEngines.1.customProperties.prop.sib.msgstore.property1 = value one|This is a messaging engine property.
# app.sibus.1.busmembers.1.messageEngines.1.customProperties.prop.sib.msgstore.property2 = value two
#
# app.sibus.1.busmembers.1.messageEngines.count = <max index for messaging engines>
# app.sibus.1.busmembers.count = <max index for bus members>
#
#
# File store example:
# app.sibus.1.busmembers.1.messageEngines.3.name = SampleCluster.002-NewBus
# app.sibus.1.busmembers.1.messageEngines.3.prop.busName = NewBus
# app.sibus.1.busmembers.1.messageEngines.3.prop.busUuid = BBBE19926139C3D3
# app.sibus.1.busmembers.1.messageEngines.3.prop.highMessageThreshold = 50000
# app.sibus.1.busmembers.1.messageEngines.3.prop.initialState = STARTED
# app.sibus.1.busmembers.1.messageEngines.3.prop.messageStoreType = FILESTORE
# app.sibus.1.busmembers.1.messageEngines.3.prop.uuid = D2A82F99CC691FAC
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.logDirectory = d:\mylogpath
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.logSize = 100
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.maxPermanentStoreSize = 500
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.maxTemporaryStoreSize = 500
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.minPermanentStoreSize = 200
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.minTemporaryStoreSize = 200
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.permanentStoreDirectory = d:\mypermstore
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.temporaryStoreDirectory = d;\mytempstore
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.unlimitedPermanentStoreSize = false
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.unlimitedTemporaryStoreSize = false
# app.sibus.1.busmembers.1.messageEngines.3.fileStore.prop.uuid = 5AD092250F49664B
#
# V7 properties for bus member:
# Additional properties can be specified for a cluster SIBus member for the core group policy
# assistance feature. Below are two examples, one for the SCALABILITY_HA and one for CUSTOM:
#
# app.sibus.5.busmembers.1.cluster = SampleCluster
# app.sibus.5.busmembers.1.node = 
# app.sibus.5.busmembers.1.server = 
# app.sibus.5.busmembers.1.prop.assistanceEnabled = true
# app.sibus.5.busmembers.1.prop.policyName = SCALABILITY_HA
#
# app.sibus.5.busmembers.1.cluster = SampleCluster
# app.sibus.5.busmembers.1.node = 
# app.sibus.5.busmembers.1.server = 
# app.sibus.5.busmembers.1.prop.assistanceEnabled = true
# app.sibus.5.busmembers.1.prop.policyName = CUSTOM 
# app.sibus.5.busmembers.1.prop.failover = true
# app.sibus.5.busmembers.1.prop.faileback = true
# app.sibus.5.busmembers.1.prop.preferredServersOnly = true
# app.sibus.5.busmembers.1.prop.preferredServerList = [ [node1 server1] [node2 server2] ]
#
# -----------------------------------------------------------------------------------------
# Preserving messaging engine settings when adding new engines
#
# If you are using this script to add new messaging engines to an existing bus member,
# you will probably want to make sure that all settings are the same.  This script supports
# a special instruction property, messagEngines.propagateSettings, which will cause messaging engine properties
# from the first messaging engine to be applied to new messaging engines 
# (unless overridden in the input property file).
# 
# The properties that are propagated are base properties, custom properties and the localization
# point settings such as highMessageThreshold for each queue/topic point. 
#
# This funcitonality must be enabled by including the following setting. Note that this is
# at the bus member level, not at the messaging engine level.
#
# app.sibus.5.busmembers.1.messageEngines.propagateSettings = true
#
# -----------------------------------------------------------------------------------------
# Creating a messaging engine for each server in a cluster.  If a messageEngine definition
# has the special iterateClusterMembers = true property, then we'll do the following:
#   Get a alphabetically sorted list of cluster members (node name)
#   For each cluster member:
#       Enable support for @{DYNAMIC} keywords CURRENT_CLUSTER, CURRENT_SERVER, CURRENT_NODE, and SERVER_INDEX
#          SERVER_INDEX will be "001", "002", "003", ...
#          SERVER_INDEX0 will be "000", "001", "002", ...
#          SHORT_SERVER_INDEX will be "01", "02", "03", ...
#          SHORT_SERVER_INDEX0 will be "00", "01", "02", ...
#       Create/update a messaging engine with the specific properties.  The name should be determined with
#       the @{DYNAMIC} macro.
#
# The messaging engine distribution can be altered by specifying the 
# iterateClusterMembers.nodes = menode1,menode2,... property.  When this property
# is used, the messaging engines will only be created for cluster members on the specified node. This
# can be used to create more than one messaging engines in the messaging cluster and
# have servers as secondary failover locations for those messaging engines.
#
# If this feature is used to update an existing configuration and the calculated count
# of messaging engine shrinks, this module will delete unused messaging engines and 
# any core group policies that reference the deleted engines.
#
# This function does not automatically create/update core group policies to 
# associate the messaging engines with a specific server.  his would have to
# be done seperately in the coregroup definitons. See the ProcessCoreGroup module for information on how
# the iterateClusterMembers and iterateClusterMembers.nodes properties can be used to create policies
# that assign the messaging engines to specific servers. Examples are included below.
#
# Dynamic messaging engine example 1: In this example, one messaging engine will be created for
# each cluster member. The messaging engines will share the same datasource, but will have
# a unique schema (MSIB000, MSIB001, MSIB002...}.  The core group settings in this example
# pin the messaging engines to their corresponding application servers.
#
# app.sibus.1.busmembers.1.cluster = DynamicTestCluster
# app.sibus.1.busmembers.1.node = 
# app.sibus.1.busmembers.1.server = 
# app.sibus.1.busmembers.1.prop.assistanceEnabled = false
#
# # If this is an update to an existing system, merge settings from the
# # existing engine into the new engines.
# app.sibus.1.busmembers.1.messageEngines.propagateSettings = true
# 
# app.sibus.1.busmembers.1.messageEngines.1.iterateClusterMembers = true
# app.sibus.1.busmembers.1.messageEngines.1.name = DynamicTestCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-DynamicTestBus
# app.sibus.1.busmembers.1.messageEngines.1.prop.busName = DynamicTestBus
# app.sibus.1.busmembers.1.messageEngines.1.prop.highMessageThreshold = 50001
# app.sibus.1.busmembers.1.messageEngines.1.prop.initialState = STARTED
# app.sibus.1.busmembers.1.messageEngines.1.prop.messageStoreType = DATASTORE
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.authAlias = MeAuthAlias
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.createTables = true
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.dataSourceName = jdbc/sibds01
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.permanentTables = 1
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.schemaName = MSIB@{DYNAMIC#KEYWORD#SHORT_SERVER_INDEX0}
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.temporaryTables = 1
#
# app.coregroups.1.name = @CLUSTERCOREGROUP(DynamicTestCluster)
# app.coregroups.1.policies.1.iterateClusterMembers = DynamicTestCluster
# app.coregroups.1.policies.1.policyType = OneOfNPolicy
# app.coregroups.1.policies.1.name = DynamicTestCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-DynamicTestBus
# app.coregroups.1.policies.1.prop.description = None
# app.coregroups.1.policies.1.prop.failback = true
# app.coregroups.1.policies.1.prop.isAlivePeriodSec = 60
# app.coregroups.1.policies.1.prop.policyFactory = com.ibm.ws.hamanager.coordinator.policy.impl.OneOfNPolicyFactory
# app.coregroups.1.policies.1.prop.preferredOnly = true
# app.coregroups.1.policies.1.prop.quorumEnabled = false
# app.coregroups.1.policies.1.matchCriteria.1.name = type
# app.coregroups.1.policies.1.matchCriteria.1.description = None
# app.coregroups.1.policies.1.matchCriteria.1.value = WSAF_SIB
# app.coregroups.1.policies.1.matchCriteria.2.name = WSAF_SIB_MESSAGING_ENGINE
# app.coregroups.1.policies.1.matchCriteria.2.description = None
# app.coregroups.1.policies.1.matchCriteria.2.value = DynamicTestCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-DynamicTestBus
# app.coregroups.1.policies.1.matchCriteria.count = 2 
# app.coregroups.1.policies.1.preferredServers.names = @{DYNAMIC#KEYWORD#PREFERRED_SERVER_LIST}
#
#
# Dynamic messaging engine example 2: In this example, two messaging engines will be created, one for the
# cluster member on ConfigurationNode1 and the second for the cluster member on ConfigurationNode2. The
# coregroup settings in this example will assign additional servers in the cluster to be the preferred
# server list to be used as secondary locations for the messgae engines.
#
# app.sibus.1.busmembers.1.cluster = DynamicTestCluster
# app.sibus.1.busmembers.1.node = 
# app.sibus.1.busmembers.1.server = 
# app.sibus.1.busmembers.1.prop.assistanceEnabled = false
#
# app.sibus.1.busmembers.1.messageEngines.1.iterateClusterMembers = true
# app.sibus.1.busmembers.1.messageEngines.1.iterateClusterMembers.nodes = ConfigurationNode1,ConfigurationNode3
# app.sibus.1.busmembers.1.messageEngines.1.name = DynamicTestCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-DynamicTestBus
# app.sibus.1.busmembers.1.messageEngines.1.prop.busName = DynamicTestBus
# app.sibus.1.busmembers.1.messageEngines.1.prop.highMessageThreshold = 50001
# app.sibus.1.busmembers.1.messageEngines.1.prop.initialState = STARTED
# app.sibus.1.busmembers.1.messageEngines.1.prop.messageStoreType = DATASTORE
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.authAlias = MeAuthAlias
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.createTables = true
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.dataSourceName = jdbc/sibds01
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.permanentTables = 1
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.schemaName = MSIB@{DYNAMIC#KEYWORD#SHORT_SERVER_INDEX0}
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.temporaryTables = 1
#
# app.coregroups.1.name = @CLUSTERCOREGROUP(DynamicTestCluster)
# app.coregroups.1.policies.1.iterateClusterMembers = DynamicTestCluster
# app.coregroups.1.policies.1.iterateClusterMembers.nodes = ConfigurationNode1,ConfigurationNode3
# app.coregroups.1.policies.1.iterateClusterMembers.determineSecondaries = true
# app.coregroups.1.policies.1.policyType = OneOfNPolicy
# app.coregroups.1.policies.1.name = DynamicTestCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-DynamicTestBus
# app.coregroups.1.policies.1.prop.description = None
# app.coregroups.1.policies.1.prop.failback = false
# app.coregroups.1.policies.1.prop.isAlivePeriodSec = 60
# app.coregroups.1.policies.1.prop.policyFactory = com.ibm.ws.hamanager.coordinator.policy.impl.OneOfNPolicyFactory
# app.coregroups.1.policies.1.prop.preferredOnly = true
# app.coregroups.1.policies.1.prop.quorumEnabled = false
# app.coregroups.1.policies.1.matchCriteria.1.name = type
# app.coregroups.1.policies.1.matchCriteria.1.description = None
# app.coregroups.1.policies.1.matchCriteria.1.value = WSAF_SIB
# app.coregroups.1.policies.1.matchCriteria.2.name = WSAF_SIB_MESSAGING_ENGINE
# app.coregroups.1.policies.1.matchCriteria.2.description = None
# app.coregroups.1.policies.1.matchCriteria.2.value = DynamicTestCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-DynamicTestBus
# app.coregroups.1.policies.1.matchCriteria.count = 2 
# app.coregroups.1.policies.1.preferredServers.names = @{DYNAMIC#KEYWORD#PREFERRED_SERVER_LIST}
#
#
# 
# Dynamic messaging engine example 3: In this example, the first ("000") messaging engine
# created with the bus member is not used, while the messageEngines.2 definition is used
# to create one messaging engine per cluster member.
#
# app.sibus.1.busmembers.1.cluster = SampleCluster
# app.sibus.1.busmembers.1.node = 
# app.sibus.1.busmembers.1.server = 
# app.sibus.1.busmembers.1.prop.assistanceEnabled = false
#
# app.sibus.1.busmembers.1.messageEngines.1.name = SampleCluster.000-JohnsNewBus
# app.sibus.1.busmembers.1.messageEngines.1.prop.busName = JohnsNewBus
# app.sibus.1.busmembers.1.messageEngines.1.prop.highMessageThreshold = 50000
# app.sibus.1.busmembers.1.messageEngines.1.prop.initialState = STOPPED
# app.sibus.1.busmembers.1.messageEngines.1.prop.messageStoreType = DATASTORE
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.authAlias = Dude3
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.createTables = true
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.dataSourceName = jdbc/mysibds
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.permanentTables = 1
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.schemaName = IBMWSSIB
# app.sibus.1.busmembers.1.messageEngines.1.dataStore.prop.temporaryTables = 1
#
# app.sibus.1.busmembers.1.messageEngines.2.iterateClusterMembers = true
# app.sibus.1.busmembers.1.messageEngines.2.name = SampleCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX}-JohnsNewBus
# app.sibus.1.busmembers.1.messageEngines.2.prop.busName = JohnsNewBus
# app.sibus.1.busmembers.1.messageEngines.2.prop.highMessageThreshold = 50000
# app.sibus.1.busmembers.1.messageEngines.2.prop.initialState = STARTED
# app.sibus.1.busmembers.1.messageEngines.2.prop.messageStoreType = DATASTORE
# app.sibus.1.busmembers.1.messageEngines.2.prop.uuid = 7B78A3A23BAB7557
# app.sibus.1.busmembers.1.messageEngines.2.dataStore.prop.authAlias = Dude3
# app.sibus.1.busmembers.1.messageEngines.2.dataStore.prop.createTables = true
# app.sibus.1.busmembers.1.messageEngines.2.dataStore.prop.dataSourceName = jdbc/@{DYNAMIC#CURRENT_NODE#name}/@{DYNAMIC#CURRENT_SERVER#name}/sibds
# app.sibus.1.busmembers.1.messageEngines.2.dataStore.prop.permanentTables = 1
# app.sibus.1.busmembers.1.messageEngines.2.dataStore.prop.schemaName = CSIB@{DYNAMIC#KEYWORD#SERVER_INDEX}
# app.sibus.1.busmembers.1.messageEngines.2.dataStore.prop.temporaryTables = 1
# app.sibus.1.busmembers.1.messageEngines.count = 2
# app.sibus.1.busmembers.count = 1
#
# -----------------------------------------------------------------------------
# Mediations:
# app.sibus.1.mediations.2.mediationName = MyTopicMediation
# app.sibus.1.mediations.2.prop.allowConcurrentMediation = false
# app.sibus.1.mediations.2.prop.globalTransaction = true
# app.sibus.1.mediations.2.prop.handlerListName = TopicMediations
# app.sibus.1.mediations.2.prop.selector = customerHeader like Dog%
# app.sibus.1.mediations.2.prop.uuid = 9A51B3DE06ECD44E
# app.sibus.1.mediations.2.contextInfo.1.type = SIBContextInfo
# app.sibus.1.mediations.2.contextInfo.1.prop.name = ContextProp1
# app.sibus.1.mediations.2.contextInfo.1.prop.type = STRING
# app.sibus.1.mediations.2.contextInfo.1.prop.value = ContextValue1_Updated
# app.sibus.1.mediations.2.contextInfo.2.type = SIBContextInfo
# app.sibus.1.mediations.2.contextInfo.2.prop.name = ContextProp2
# app.sibus.1.mediations.2.contextInfo.2.prop.type = STRING
# app.sibus.1.mediations.2.contextInfo.2.prop.value = ContextValue2
# app.sibus.1.mediations.2.contextInfo.3.type = SIBContextInfo
# app.sibus.1.mediations.2.contextInfo.3.prop.name = ContextProp3
# app.sibus.1.mediations.2.contextInfo.3.prop.type = STRING
# app.sibus.1.mediations.2.contextInfo.3.prop.value = ContextValue3
# app.sibus.1.mediations.2.contextInfo.count = 3
# -----------------------------------------------------------------------------
# Queue Destinations:
# 
# app.sibus.1.queueDestinations.6.identifier = SampleQueueDestination
# app.sibus.1.queueDestinations.6.cluster = SampleCluster
# app.sibus.1.queueDestinations.6.node = 
# app.sibus.1.queueDestinations.6.server = 
# app.sibus.1.queueDestinations.6.prop.exceptionDestination = $DEFAULT_EXCEPTION_DESTINATION
# app.sibus.1.queueDestinations.6.prop.blockedRetryTimeout = -1
# app.sibus.1.queueDestinations.6.prop.defaultPriority = 0
# app.sibus.1.queueDestinations.6.prop.maintainStrictMessageOrder = false
# app.sibus.1.queueDestinations.6.prop.maxFailedDeliveries = 5
# app.sibus.1.queueDestinations.6.prop.maxReliability = ASSURED_PERSISTENT
# app.sibus.1.queueDestinations.6.prop.overrideOfQOSByProducerAllowed = true
# app.sibus.1.queueDestinations.6.prop.receiveAllowed = true
# app.sibus.1.queueDestinations.6.prop.receiveExclusive = false
# app.sibus.1.queueDestinations.6.prop.reliability = ASSURED_PERSISTENT
# app.sibus.1.queueDestinations.6.prop.sendAllowed = true
# app.sibus.1.queueDestinations.6.prop.uuid = B304EF4FBF436724B7B06DD9
# ...
# app.sibus.1.queueDestinations.count = <max index>
#
# -----------------------------------------------------------------------------
# Topic Destinations:
#
# app.sibus.1.topicDestinations.2.identifier = SampleTopicDestination
# app.sibus.1.topicDestinations.2.prop.blockedRetryTimeout = -1
# app.sibus.1.topicDestinations.2.prop.defaultPriority = 0
# app.sibus.1.topicDestinations.2.prop.description = This is a sample
# app.sibus.1.topicDestinations.2.prop.exceptionDestination = $DEFAULT_EXCEPTION_DESTINATION
# app.sibus.1.topicDestinations.2.prop.maintainStrictMessageOrder = false
# app.sibus.1.topicDestinations.2.prop.maxFailedDeliveries = 5
# app.sibus.1.topicDestinations.2.prop.maxReliability = ASSURED_PERSISTENT
# app.sibus.1.topicDestinations.2.prop.overrideOfQOSByProducerAllowed = true
# app.sibus.1.topicDestinations.2.prop.receiveAllowed = true
# app.sibus.1.topicDestinations.2.prop.reliability = ASSURED_PERSISTENT
# app.sibus.1.topicDestinations.2.prop.sendAllowed = true
# app.sibus.1.topicDestinations.2.prop.topicAccessCheckRequired = true
# app.sibus.1.topicDestinations.2.prop.uuid = E4AB3210EF12EFE37A303562
# ....
# app.sibus.1.topicDestinations.count = <max index>
#
#------------------------------------------------------------------------------
# Localization points. These settings are processed per messaging engine after
# queue and topics are created/updated. UUID fields are ignored. The identifier
# and type fields are used to find a matching localization point in the ME 
# configuration. The type attribute is required to distinguish between queues,topics,
# and mediations. Earlier versions of the script library did not have support for
# Mediations, so the type identifier is optional and if not specified a best guess
# will be made.
#
# app.sibus.1.busmembers.1.cluster = MessagingClusterFive
# app.sibus.1.busmembers.1.node = 
# app.sibus.1.busmembers.1.server = 
# app.sibus.1.busmembers.1.messageEngines.1.name = MessagingClusterFive.000-PSExampleBus5
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.1.identifier = _SYSTEM.Exception.Destination.MessagingClusterFive.000-PSExampleBus5@MessagingClusterFive.000-PSExampleBus5
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.1.type = SIBQueueLocalizationPoint
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.1.prop.sendAllowed = true
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.1.prop.highMessageThreshold = 50000
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.1.prop.uuid = 0D5B130D75CD8750
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.1.prop.targetUuid = 5B8B329AD52C6F8CDA452219
#
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.2.identifier = Default.Topic.Space@MessagingClusterFive.000-PSExampleBus5
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.2.type = SIBTopicSpaceLocalizationPoint
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.2.prop.sendAllowed = true
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.2.prop.highMessageThreshold = 50001
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.2.prop.targetUuid = DBFB4B665FEB664AF2F6B29E
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.2.prop.uuid = C82996F8F0E6F3BA
#
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.3.identifier = PSExampleTopicSpace@MessagingClusterFive.000-PSExampleBus5
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.3.type = SIBTopicSpaceLocalizationPoint
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.3.prop.uuid = 2A16023F6746D5AD
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.3.prop.sendAllowed = true
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.3.prop.targetUuid = E937D222C10450AF28BDF1BB
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.3.prop.highMessageThreshold = 50000
#
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.4.identifier = PSExampleTopicSpace@MessagingClusterOne.000-PS4xampleBus
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.4.type = SIBMediationLocalizationPoint
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.4.prop.highMessageThreshold = 50013
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.4.prop.sendAllowed = false
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.4.prop.targetUuid = E937D222C10450AF28BDF1BB
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.4.prop.uuid = 0C866D5CFD626D75
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.4.mediationInstance.type = SIBMediationInstance
# app.sibus.1.busmembers.1.messageEngines.1.localizationPoints.4.mediationInstance.prop.initialState = STOPPED
#
# ------------------------------------------------------------------------------------------
# Mediation assignments:
#
# app.sibus.1.topicDestinations.3.destinationMediationRef.prop.enabled = true
# app.sibus.1.topicDestinations.3.destinationMediationRef.prop.externallyMediated = false
# app.sibus.1.topicDestinations.3.destinationMediationRef.localizationPointRefs.1.type = SIBLocalizationPointRef
# app.sibus.1.topicDestinations.3.destinationMediationRef.localizationPointRefs.1.prop.cluster = MessagingClusterOne
# app.sibus.1.topicDestinations.3.destinationMediationRef.localizationPointRefs.count = 1
# app.sibus.1.topicDestinations.3.destinationMediationRef.mediationName = MyTopicMediation
# 
# app.sibus.1.queueDestinations.2.destinationMediationRef.prop.enabled = true
# app.sibus.1.queueDestinations.2.destinationMediationRef.prop.externallyMediated = false
# app.sibus.1.queueDestinations.2.destinationMediationRef.localizationPointRefs.1.type = SIBLocalizationPointRef
# app.sibus.1.queueDestinations.2.destinationMediationRef.localizationPointRefs.1.prop.node = SiemensMessagingNoe1
# app.sibus.1.queueDestinations.2.destinationMediationRef.localizationPointRefs.1.prop.server = StandaloneMember1
# app.sibus.1.queueDestinations.2.destinationMediationRef.localizationPointRefs.count = 1
# app.sibus.1.queueDestinations.2.destinationMediationRef.mediationName = OtherMediation
# ------------------------------------------------------------------------------------------
# Deleting SIBus Configuration Items
# 
# You can use the deletion properties to delete a bus or subcomponents. Parent 
# components must have the corresponding delete property set to true to force the
# deletion of the component (Bus or BusMembers)
#
# Note that the @ITERATE(optional-pattern) macro can be used with bus members or
# destinations to process multiple items that match that pattern.
#
# del.sibus.1.name = MySIBus
# del.sibus.1.deleteBus = false
#
# del.sibus.1.busmembers.1.cluster = MyCluster
# del.sibus.1.busmembers.1.node = 
# del.sibus.1.busmembers.1.server = 
#
# del.sibus.1.busmembers.1.deleteBusMember = true
#
# del.sibus.2.name = DynamicTestBus
#
# del.sibus.2.busmembers.1.cluster = @ITERATE
# del.sibus.2.busmembers.1.deleteBusMember = false
#
# del.sibus.2.queueDestinations.1.identifier = QueueOne
# del.sibus.2.queueDestinations.2.identifier = @ITERATE(QueueF*)
#
# del.sibus.2.topicDestinations.1.identifier = TopicSpaceTwo
# del.sibus.2.topicDestinations.2.identifier = @ITERATE(TopicSpaceF*)
############################################################################################




global progInfo
global configInfo

#----------------------------------------------------------------------
# processSIBDeletionDestination
# 
# Process the directives for deleting queue/topicspace destinations for the specified
# busName.
# 
#  Parameters: 
#     sibConfigInfo - Configuration properties to pull deletion information from
#     busName - Name of the bus being processed
#     busPrefix - property prefix for this bus deletion instructions
#     destinationType - Queue or TopicSpace
#     typeString
#----------------------------------------------------------------------
def processSIBDeletionDestination(sibConfigInfo,busName,busPrefix,destinationType,typeString):
  _app_trace("processSIBDeletionDestination(sibConfigInfo,%s,%s,%s,%s)" %(busName,busPrefix,destinationType,typeString),"entry")
  try:
    destCount = int(sibConfigInfo.get("%s.%sDestinations.count" % (busPrefix,typeString),"0"))
    for idx in range(1,destCount+1):
      destIdentifier = sibConfigInfo.get("%s.%sDestinations.%d.identifier" % (busPrefix,typeString,idx),"")
      if (isEmpty(destIdentifier)):
        continue
      
      if (destIdentifier.find("@ITERATE") >= 0):
        tempArgs = parseFunctionParms(destIdentifier)
        if (len(tempArgs) > 0):
          tPattern = tempArgs[0]
        else:
          tPattern = "*"
    
        tWildcard = wildcardToRegExpString(tPattern)
        
        destMap = findMatchingDestinations(busName, tWildcard,destinationType)
        
        if (len(destMap) == 0):
          _app_message("No %s destinations in bus %s match pattern %s" % (typeString,busName, tPattern))
        else:
          _app_message("%d %s destinations in bus %s match pattern %s" % (len(destMap),typeString,busName, tPattern))
          
          for qidentifier in destMap.keys():
            if (deleteSIBDestination(qidentifier, busName, destMap[qidentifier])):
              # Error
              _app_message("Error occurred removing %s destination %s from bus %s" % (typeString,qidentifier,busName))
              raise StandardError("Error occurred removing %s destination %s from bus %s" % (typeString,qidentifier,busName))
            else:
              _app_message("Removed %s destination %s from bus %s" % (typeString,qidentifier,busName))
          #endfor    
        #endelse
      else:
        # Remove the specific destination
        if (existsSIBDestination(destIdentifier, busName)):
          if (deleteSIBDestination(destIdentifier, busName, skipValidation=1)):    
            _app_message("Error occurred removing %s destination %s from bus %s" % (typeString,destIdentifier,busName))
            raise StandardError("Error occurred removing %s destination %s from bus %s" % (typeString,destIdentifier,busName))
          else:
            _app_message("Removed %s destination %s from bus %s" % (typeString,destIdentifier,busName))
          #endelse
        else:
          _app_message("%s destination %s does not exist on bus %s" % (typeString, destIdentifier,busName))
        #endelse
        
      #endelse
    #endfor
  except:
    _app_trace("Unexpected error in processSIBDeletionDestination","exception")
    raise StandardError("Unexpected error in processSIBDeletionDestination")
    
  _app_trace("processSIBDeletionDestination()","exit")

#enddef processSIBDeletionDestination

#------------------------------------------------------------------------------
# processSIBDeletionQueueDestinations
#------------------------------------------------------------------------------
def processSIBDeletionQueueDestinations(sibConfigInfo,busName,busPrefix):
  processSIBDeletionDestination(sibConfigInfo,busName,busPrefix,"Queue","queue")

#------------------------------------------------------------------------------
# processSIBDeletionTopicSpaceDestination
#------------------------------------------------------------------------------
def processSIBDeletionTopicSpaceDestinations(sibConfigInfo,busName,busPrefix):
  processSIBDeletionDestination(sibConfigInfo,busName,busPrefix,"TopicSpace","topic")

#-------------------------------------------------------------------------------
# processSIBDeletionMessageEngines
#-------------------------------------------------------------------------------
def processSIBDeletionMessageEngines(sibConfigInfo,busName, memberCluster, memberNode, memberServer, memberPrefix):
  _app_trace("processSIBDeletionMessageEngines(sibConfigInfo,%s,%s,%s,%s,%s)" %(busName, memberCluster, memberNode, memberServer, memberPrefix),"entry")
  try:
    meCount = int(sibConfigInfo.get("%s.messageEngines.count"%memberPrefix,"0"))
    for idx in range(1,meCount+1):
      meName = sibConfigInfo.get("%s.messageEngines.%d.name" % (memberPrefix,idx),"")
      
      if (isEmpty(meName)):
        continue
        
      if existsSIBEngine(meName, busName, memberCluster, memberNode, memberServer):
        deleteSIBEngine(meName, memberCluster, memberNode, memberServer, busName)
        _app_message("Messaging engine %s on bus %s has been deleted" % (meName,busName))
        
      else:
        _app_message("Messaging engine %s does not exist in bus %s, no deletion necessary" % (meName, busName))
    
  except:
    _app_trace("Unexpected error in processSIBDeletionMessageEngines","exception")
    exit()
    
  _app_trace("processSIBDeletionMessageEngines()","exit")

#-------------------------------------------------------------------------------
# processSIBDeletionBusMember
#
# Handles the deletion instructions for a single bus member
#-------------------------------------------------------------------------------
def processSIBDeletionBusMember(sibConfigInfo,busName, memberCluster, memberNode, memberServer, memberPrefix):
  
  _app_trace("processSIBDeletionBusMember(sibConfigInfo,%s,%s,%s,%s,%s)" % (busName, memberCluster, memberNode, memberServer, memberPrefix),"entry")
  
  try:
    # See if this is a deletion of bus member
    deleteBusMember = sibConfigInfo.get("%s.deleteBusMember" % memberPrefix,"false")
    if (deleteBusMember.lower() == "true"):
      if (existsSIBusMember(busName, memberCluster, memberNode, memberServer)):
        
        # Get the list of message engine names for policy cleanup 
        meNames = getSIBEngineNamesForBusMember(busName, memberCluster,memberNode,memberServer)
        
        # Do the remove
        removeSIBusMember(busName, memberCluster, memberNode, memberServer)
        _app_message("Bus %s member %s%s %s has been removed" % (busName, memberCluster, memberNode, memberServer))
        
        # Clean up the policies
        if (meNames != None and len(meNames) > 0 and not isEmpty(memberCluster)):
          trimClusterPolicies(memberCluster, meNames)
          _app_message("Core group policies that referenced messaging engines %s for bus member %s have been removed" % (meNames, memberCluster))
            
      else:
        _app_message("Bus %s member %s%s %s is not defined and will not be removed" % (busName, memberCluster, memberNode, memberServer))
        
    else:
      # Process the messaging engines under the bus member
      processSIBDeletionMessageEngines(sibConfigInfo,busName, memberCluster, memberNode, memberServer, memberPrefix)
      
  except:
    _app_trace("Unexpected error in processSIBDeletionBusMember","exception")
    exit()
  
  _app_trace("processSIBDeletionBusMember()","exit")

#-------------------------------------------------------------------------------
# processSIBDeletionsBusMembers
#
# Handle the deletion instructions for bus members.
#-------------------------------------------------------------------------------  
def processSIBDeletionsBusMembers(sibConfigInfo,busName,busPrefix):
  _app_trace("processSIBDeletionsBusMembers(sibConfigInfo,%s,%s)" % (busName,busPrefix),"entry")
  try:

    memberCount = int(sibConfigInfo.get("%s.busmembers.count" % busPrefix,"0"))
    for idx in range(1,memberCount+1):
      memberCluster = sibConfigInfo.get("%s.busmembers.%d.cluster" % (busPrefix,idx),"")
      memberNode = sibConfigInfo.get("%s.busmembers.%d.node" % (busPrefix,idx),"")
      memberServer = sibConfigInfo.get("%s.busmembers.%d.server" % (busPrefix,idx),"")
      
      if (isEmpty(memberCluster) and isEmpty(memberNode) and isEmpty(memberServer)):
        continue
        
      # Check for iterate
      doIteration = 0
      
      # See if we have any special @ITERATE macros to process
      doIteration,clusterPattern,clusterWildcard = parseIterateMacroParms(memberCluster,doIteration)
      doIteration,nodePattern,nodeWildcard = parseIterateMacroParms(memberNode,doIteration)
      doIteration,serverPattern,serverWildcard = parseIterateMacroParms(memberServer,doIteration)
      
      if (doIteration):
        memberList = findMatchingSIBusMembers(busName, None, clusterWildcard, nodeWildcard, serverWildcard)
        if (len(memberList) == 0):
          _app_message("Bus %s has no members matching patterns cluster=%s node=%s server=%s" % (busName, clusterPattern, nodePattern, serverPattern))
        else:
          _app_message("Bus %s has %d members matching patterns cluster=%s node=%s server=%s" % (busName, len(memberList),clusterPattern, nodePattern, serverPattern))
          for memberinfo in memberList:
            tempCluster = memberinfo[0]
            tempNode = memberinfo[1]
            tempServer = memberinfo[2]
            
            memberPrefix = "%s.busmembers.%d" % (busPrefix,idx)
            memberProps = filterProperties(sibConfigInfo,memberPrefix)
            
            memberProps["%s.cluster" % memberPrefix] = tempCluster
            memberProps["%s.node" % memberPrefix] = tempNode
            memberProps["%s.server" % memberPrefix] = tempServer
            
            _app_message("Processing deletion instructions for %s bus member %s%s %s" % (busName,tempCluster,tempNode,tempServer))
            processSIBDeletionBusMember(memberProps,busName, tempCluster, tempNode, tempServer, memberPrefix)
          #endfor  
        #endelse
      else:
        # Process the deletions for this specific busMember
        processSIBDeletionBusMember(sibConfigInfo,busName, memberCluster, memberNode, memberServer, "%s.busmembers.%d" % (busPrefix,idx))
      #endelse
    #endfor
    
  except:
    _app_trace("Unexpected error in processSIBDeletionsBusMembers","exception")
    exit()
    
  _app_trace("processSIBDeletionsBusMembers()","exit")
  
  
#-------------------------------------------------------------------------------
# processSIBDeletionsBus
#-------------------------------------------------------------------------------
def processSIBDeletionsBus(sibConfigInfo, busName, busPrefix):
  _app_trace("processSIBDeletionsBus(sibConfigInfo, %s,%s)" % (busName, busPrefix),"entry")
  
  try:
    # See if this is a deletion of entire bus or subcomponents
    deleteBus = sibConfigInfo.get("%s.deleteBus"%busPrefix,"false")
    if (deleteBus.lower() == "true"):
      # Yes we're just going to delete the bus
      busId = checkExistingBus(busName)
      if (isEmpty(busId)):
        _app_message("Bus %s is not defined - no need to delete" % busName)
      else:
        deleteSIBus(busName)
        _app_message("Bus %s has been deleted" % busName)
    else:
      # No, we have to process sub components
      
      # Bus members
      processSIBDeletionsBusMembers(sibConfigInfo,busName,busPrefix)
              
      # Delete queues and topics
      processSIBDeletionQueueDestinations(sibConfigInfo,busName,busPrefix)
      
      processSIBDeletionTopicSpaceDestinations(sibConfigInfo,busName,busPrefix)
      
      
  except:
    _app_trace("Unexpected error in processSIBDeletionsBus","exception")
    exit()
  
  _app_trace("processSIBDeletionsBus()","exit")
  
#-------------------------------------------------------------------------------
#
#-------------------------------------------------------------------------------
def processSIBDeletions(sibConfigInfo):
  _app_trace("processSIBDeletions()","entry")
  
  try:
    delCount = int(sibConfigInfo.get("del.sibus.count","0"))
    if (delCount > 0):
      for idx in range(1,delCount+1):
        busPrefix = "del.sibus.%d" % idx
        busName = sibConfigInfo.get("%s.name" % busPrefix,"")
        
        if (isEmpty(busName)):
          continue
        
        processSIBDeletionsBus(sibConfigInfo, busName, busPrefix)
        
        
  except:
    _app_trace("Unexpected error in processSIBDeletions","exception")
    exit()
    
  _app_trace("processSIBDeletions()","exit")  

#---------------------------------------------------------------------------------------
# processLocalizationPointsForMessageEngine
#
# This function handles the processing of localization point settings for a specific messaging engine
#---------------------------------------------------------------------------------------
def processLocalizationPointsForMessageEngine(sibConfigInfo,busName,busId,meId,meprefix):
  _app_trace("processLocalizationPointsForMessageEngine(sibConfigInfo,%s,%s,%s,%s)" % (busName,busId,meId,meprefix),"entry")
  try:
    lpcount = sibConfigInfo.get("%s.localizationPoints.count"%meprefix,"0")
    
    if (int(lpcount) > 0):
      
      meName = AdminConfig.showAttribute(meId,"name")
      
      # Load current settings
      currentLPprops = getSIBLocalizationPointProperties(meId)
      
    for lpidx in range(1,int(lpcount)+1):
      lpname = sibConfigInfo.get("%s.localizationPoints.%d.identifier"% (meprefix,lpidx))
      if (isEmpty(lpname)):
        continue
        
      shortIdentifier = lpname
      atidx = shortIdentifier.find("@")
      if (atidx > 0):
        shortIdentifier = shortIdentifier[0:atidx]
      
      # Pull in the type parameter - support for distinquishing based on type was
      # added after original implementation and we'll still support trying to find a match
      # without the type
      lptype = sibConfigInfo.get("%s.localizationPoints.%d.type"% (meprefix,lpidx),None)
      
      # Find current settings for localization point - if match is not found, we can't update it
      currentIdx = 1
      currentId = None
      tempIdentifier = currentLPprops.get("localizationPoints.%d.identifier"%currentIdx)
      tempType = currentLPprops.get("localizationPoints.%d.type"%currentIdx)
      foundType = ""
      while (not isEmpty(tempIdentifier)):
        if (lptype != None and lptype != tempType):
          currentIdx = currentIdx + 1
          tempIdentifier = currentLPprops.get("localizationPoints.%d.identifier"%currentIdx)
          tempType = currentLPprops.get("localizationPoints.%d.type"%currentIdx)
          continue
        
        # See if matches name portion
        if (tempIdentifier.startswith("%s@" % shortIdentifier)):
          currentId = currentLPprops.get("localizationPoints.%d.CONFIG_ID"%currentIdx)
          foundType = tempType
          break
        elif (tempIdentifier.startswith("_SYSTEM.Exception.Destination.") and shortIdentifier.startswith("_SYSTEM.Exception.Destination.")):
          # Special case for handling references to system exception queues
          currentId = currentLPprops.get("localizationPoints.%d.CONFIG_ID"%currentIdx)
          shortIdentifier = "_SYSTEM.Exception.Destination."
          foundType = tempType
          break
        elif (tempType=="SIBMQLinkSenderChannelLocalizationPoint" and tempIdentifier == currentLPprops.get("localizationPoints.%d.identifier"%currentIdx)):
          currentId = currentLPprops.get("localizationPoints.%d.CONFIG_ID"%currentIdx)
          shortIdentifier = tempIdentifier
          foundType = tempType
          break;
        else:
          currentIdx = currentIdx + 1
          tempIdentifier = currentLPprops.get("localizationPoints.%d.identifier"%currentIdx)
          tempType = currentLPprops.get("localizationPoints.%d.type"%currentIdx)
      
      if (currentId == None):
        _app_message("Unable to find configured localization point %s on ME %s" %   (shortIdentifier,meName))
        exit() 
      
      # See if there are updates
      subProps = getPropListDifferences(sibConfigInfo, "%s.localizationPoints.%d"% (meprefix,lpidx), currentLPprops, "localizationPoints.%d"%currentIdx)
      subProps.remove("uuid")
      subProps.remove("targetUuid")
      
      # SIBMediationLocalizationPoint has a nested  SIBMediationInstance
      mediationProps = {}
      if (foundType == "SIBMediationLocalizationPoint"):
        mediationProps = getPropListDifferences(sibConfigInfo, "%s.localizationPoints.%d.mediationInstance"% (meprefix,lpidx), currentLPprops, "localizationPoints.%d.mediationInstance"%currentIdx)
        mediationProps.remove("mediationRefUuid")

      
      if (len(subProps) > 0 or len(mediationProps) > 0):
        # Need to update
        updateLocalizationPoint(currentId,subProps,mediationProps)
        _app_message("Updated %s %s on ME %s"% (foundType,shortIdentifier,meName))
      else:
        _app_message("No need to update localization point %s on ME %s"% (shortIdentifier,meName))
      
      
  except:
    _app_trace("Unexpected error in processLocalizationPointsForMessageEngine","exception")
    exit()
    
  
  _app_trace("processLocalizationPointsForMessageEngine","exit")

#enddef processLocalizationPointsForMessageEngine

#-------------------------------------------------------------------------------------------
# processLocalizationPoints
#
# This function sets up the localization info for queue/publication points on messaging engines.  This 
# has to be done after queues and topics are processed.
#-------------------------------------------------------------------------------------------
def processLocalizationPoints(sibConfigInfo,busPrefix,busName,busId):
  _app_trace("processLocalizationPoints(sibConfigInfo,%s)" %(busPrefix),"entry")
  try:
    membercount = sibConfigInfo.get("%s.busmembers.count"%busPrefix,"0")
    for memberidx in range(1,int(membercount)+1):
      memberprefix = "%s.busmembers.%d" % (busPrefix,memberidx)
      
      memberCluster = sibConfigInfo.get("%s.cluster" % memberprefix,"")
      memberNode = sibConfigInfo.get("%s.node" % memberprefix,"")
      memberServer = sibConfigInfo.get("%s.server" % memberprefix,"")
      
      if (isEmpty(memberCluster) and isEmpty(memberNode) and isEmpty(memberServer)):
        continue
      
      mecount = sibConfigInfo.get("%s.messageEngines.count"%memberprefix,"0")
      meList = []
      
      doLocalization = 0
      if (int(mecount) > 0):
        
        # See if we have any localization settings to process
        for meidx in range(1,int(mecount)+1):
          lcount = int(sibConfigInfo.get("%s.messageEngines.%d.localizationPoints.count" % (memberprefix,meidx),"0"))
          if (lcount > 0):
            doLocalization = 1
            break
            
      if (doLocalization):
        
        meList = getSIBEnginesForBusMember(busName, memberCluster,memberNode,memberServer)
      
        for meidx in range(1,int(mecount)+1):
          meprefix = "%s.messageEngines.%d" % (memberprefix,meidx)
          mename = sibConfigInfo.get("%s.name" % meprefix)
          if (isEmpty(mename)):
            continue
            
          iterateFlag = sibConfigInfo.get("%s.messageEngines.%d.iterateClusterMembers" % (memberprefix,meidx),"false")
          if (iterateFlag.lower() == "true"):
            nodelist = getSortedListFromProperty(sibConfigInfo,"%s.messageEngines.%d.iterateClusterMembers.nodes" %  (memberprefix,meidx))
            serverMEList = buildServerSpecificMessageEngineList(sibConfigInfo, "%s.messageEngines.%d" % (memberprefix, meidx), memberCluster, nodelist)
            for serverME in serverMEList:
              #Determine the meId for this one
              meProps = serverME.meProps
              dynamicPrefix = serverME.mePrefix
              meName = meProps.get("%s.name" % dynamicPrefix)
              meId = None
              for tempId in meList:
                if (tempId.find(meName) >= 0):
                  meId = tempId
                  break
              
              if (meId == None):
                raise StandardError("Unable to find messaging engine ID for generated name %s" % meName)
              
              processLocalizationPointsForMessageEngine(meProps,busName,busId,meId,dynamicPrefix)
            #endfor each dynamic me  
          else:  
            meId = meList[meidx-1]
            
            processLocalizationPointsForMessageEngine(sibConfigInfo,busName,busId,meId,meprefix)
        #endfor
        
    #endfor each bus member
    
  except:
    _app_trace("Unexpected error in processLocalizationPoints","exception")
    exit()
  
  _app_trace("processLocalizationPoints","exit")

#enddef processLocalizationPoints

#-------------------------------------------------------------------------------------------
# getExistingTopicPrefix
# 
# Search the existing properties for a topic definition with the specified name.  If found
# return the prefix (e.g. "app.sibus.topicDestinations.<idx>") so the existing properties can
# be compared to input properties.
#-------------------------------------------------------------------------------------------
def getExistingTopicPrefix(searchName, existingProps):

		_app_trace("getExistingTopicPrefix(%s,existingProps)"% searchName, "entry")
		result = None
		
		if (existingProps != None):
			topicCountString = existingProps.get("app.sibus.topicDestinations.count")
			if (topicCountString != None):
				for idx in range(1,int(topicCountString)+1):
						topicName = existingProps.get("app.sibus.topicDestinations.%d.identifier"%idx)
						if (topicName != None and topicName == searchName):
								result = "app.sibus.topicDestinations.%d" % idx
								break
		
		_app_trace("getExistingTopicPrefix(result = %s)" % result, "exit")
		return result


#-------------------------------------------------------------------------------------------
# processTopicDestinations
#
# Process the Topic Destination settings for a specific bus:
#
# Parameters:
#			busName - name of the bus
#			busId - configuration ID of the bus
#     prefix - the property prefix (e.g. "app.sibus.1")
#     existingProps - a property set with loaded properties representing current configuration
#                     If None, then the bus did not previously exist
#-------------------------------------------------------------------------------------------
def processTopicDestinations(busName, sibId, prefix, existingProps):

  try:
  
    if (existingProps != None):
        delayed = existingProps.get("app.sibus.delayedLoad")
        if (delayed != None and delayed == "true"):
            # Load topic settings now
            getSIBTopicProperties(existingProps,busName, "app.sibus")
            
    topicCount = int(configInfo.get("%s.topicDestinations.count" % prefix,"0"))
    if (topicCount > 0):
        for idx in range(1,topicCount+1):
          topicName = configInfo.get("%s.topicDestinations.%d.identifier" % (prefix, idx),"")
          if (isEmpty(topicName)):
              # Possibly partial configuration
              continue
              
          existingPrefix = getExistingTopicPrefix(topicName, existingProps)
          
          cluster = configInfo.get("%s.topicDestinations.%d.cluster" % (prefix,idx),"")
          node = configInfo.get("%s.topicDestinations.%d.node" % (prefix,idx),"")
          server = configInfo.get("%s.topicDestinations.%d.server" % (prefix,idx),"")
          
          
          if (existingPrefix == None):
          
              if (topicName.startswith("_SYSTEM") or topicName.startswith("Default.Topic.Space")):
                  _app_message("Skipping definition of topic %s" % topicName)
                  continue
                  
              # Creating a new topic definition
              baseProps = getPropList(configInfo, "%s.topicDestinations.%d" % (prefix,idx))
              
              replyDestinationProps = getPropList(configInfo, "%s.topicDestinations.%d.replyDestination" % (prefix,idx))
              
              frpcount = int(configInfo.get("%s.topicDestinations.%d.defaultForwardRoutingPath.count" % (prefix, idx),"0"))
              routingPath = ""
              if (frpcount > 0):
                  for frpidx in range(1,frpcount+1):
                      frpbus = configInfo.get("%s.topicDestinations.%d.defaultForwardRoutingPath.%d.prop.bus" % (prefix, idx,frpidx),"")
                      frpdestination  = configInfo.get("%s.topicDestinations.%d.defaultForwardRoutingPath.%d.prop.destination" % (prefix, idx,frpidx),"")
                      if (routingPath == ""):
                          routingPath = "%s:%s" % (frpbus,frpdestination)
                      else:
                          routingPath = "%s %s:%s" % (routingPath, frpbus,frpdestination)
                      
                      # Only can have one
                      break
                  
                  #baseProps.put("defaultForwardRoutingPath", '["%s"]' % routingPath)
                      
              contextInfoList = contextInfoPropsToListOfDictionaries(configInfo,"%s.topicDestinations.%d.contextInfo" % (prefix,idx) )
          
              result = createSIBDestination(topicName, "TopicSpace", cluster, node, server, busName, baseProps, 
                                            replyDestinationProps.get("destination"), replyDestinationProps.get("bus"),
                                            contextInfoList=contextInfoList)
          
              if (result == None):
                  _app_message("Error creating topic destination %s on bus %s" % (topicName, busName))
                  exit()
              else:
                  _app_message("Created topic destination %s on bus %s" % (topicName, busName))
                  topicId = result
              
                  processMediationAssignments(busName,topicName,topicId,configInfo,"%s.topicDestinations.%d" % (prefix,idx))
               
              
          else:
              # Update an existing topic
              topicId = None
              baseProps = getPropListDifferences(configInfo, "%s.topicDestinations.%d" % (prefix,idx), existingProps, existingPrefix)
              baseProps.remove("uuid")
              
              replyDestinationProps = getPropListDifferences(configInfo, "%s.topicDestinations.%d.replyDestination" % (prefix,idx), existingProps, "%s.replyDestination" % existingPrefix )
              
              updateContextInfoList = getContextListDifferences(configInfo,"%s.topicDestinations.%d" % (prefix,idx),existingProps,existingPrefix)
              
              if (len(baseProps) == 0 and len(replyDestinationProps) == 0 and len(updateContextInfoList) == 0):
                  _app_message("No updates for base properties of topic destination %s on bus %s" % (topicName, busName))
              else:
                  
                  result = modifySIBDestination(topicName, busName, "TopicSpace", baseProps, 
                                                replyDestinationProps.get("destination"), replyDestinationProps.get("bus"),
                                                contextInfoList=updateContextInfoList)
                  if (result == None):
                      _app_message("Error updating topic destination %s on bus %s" % (topicName, busName))
                      exit()
                  else:
                      _app_message("Updated topic destination %s on bus %s" % (topicName, busName))
              
              processMediationAssignments(busName,topicName,topicId,configInfo,"%s.topicDestinations.%d" % (prefix,idx),existingProps=existingProps,existingPrefix=existingPrefix)
              
          #endelse existing topic       
  except:
    _app_trace("Unexpected error processing topic destinations","exception")
    _app_message("Unexpected error processing topic destinations")
    exit()            
              
#enddef processTopicDestinations              
              


#-------------------------------------------------------------------------------------------
# getExistingQueuePrefix
# 
# Search the existing properties for a queue definition with the specified name.  If found
# return the prefix (e.g. "app.sibus.queueDestinations.<idx>") so the existing properties can
# be compared to input properties.
#-------------------------------------------------------------------------------------------
def getExistingQueuePrefix(searchName, existingProps):

		_app_trace("getExistingQueuePrefix(%s,existingProps)"% searchName, "entry")
		result = None
		
		if (existingProps != None):
			queueCountString = existingProps.get("app.sibus.queueDestinations.count")
			if (queueCountString != None):
				for idx in range(1,int(queueCountString)+1):
						queueName = existingProps.get("app.sibus.queueDestinations.%d.identifier"%idx)
						if (queueName != None and queueName == searchName):
								result = "app.sibus.queueDestinations.%d" % idx
								break
		
		_app_trace("getExistingQueuePrefix(result = %s)" % result, "exit")
		return result


#-------------------------------------------------------------------------------------------
# addContextInfoToDestination
# Add destination contextInfo settings to the destination
#-------------------------------------------------------------------------------------------
def addContextInfoToDestination(prefix, destinationId, busName, destinationName):

		# Handling of context info
		try:
			cicount = int(configInfo.get("%s.contextInfo.count" % (prefix),"0"))
			if (cicount > 0):
				for ciidx in range(1,cicount+1):
					ciprops = getPropList(configInfo,"%s.contextInfo.%d" % (prefix, ciidx))
					if (ciprops.size() > 0):
							ciattrs = ""
							for key in ciprops.keys():
									val = ciprops.get(key)
									if (key == "value"):
											if (not val.startswith('"')):
												val = '"%s"' % val
									ciattrs = "%s [%s %s]" % (ciattrs, key, val)
															
							ciattrs = "[ %s ]" % ciattrs
							try:
								_app_trace("Creating context info for bus %s destination %s = %s" % (busName, destinationName, ciattrs))
								ciid = AdminConfig.create("SIBContextInfo",destinationId,ciattrs)
							except:
								_app_trace("Error creating context info for bus %s destination %s = %s" % (busName, destinationName, ciattrs), "exception")
								_app_message("Error creating context info for bus %s destination %s = %s" % (busName, destinationName, ciattrs))
								exit()
												
				_app_message("Created contextInfo entries for bus %s destination %s" % (busName,destinationName))
		except:
			_app_trace("Unexpected error processing contextInfo settings","exception")
			_app_message("Unexpected error processing contextInfo settings")
			exit()

#enddef addContextInfoToDestination


#-------------------------------------------------------------------------------------------
# addContextInfoToDestination
#
# Merge new contextInfo settings with the existing
#-------------------------------------------------------------------------------------------
def mergeContextInfoToDestination(prefix, destinationId, busName, destinationName):
	# @TODO
	return

#-------------------------------------------------------------------------------
# contextInfoPropsToListOfDictionaries
#    Takes a dictionary of input properties and builds a list of dictionaries
#    containing the contextInfo defintions (one per dictionary)
# Parameters
#   masterDictionary:
#   rootPrefix:  e.g. xxx.yyy.contextInfo
#-------------------------------------------------------------------------------
def contextInfoPropsToListOfDictionaries(masterDictionary,rootPrefix):
  _app_entry("contextInfoPropsToListODictionaries(masterDictionary,%s)" , rootPrefix)
  retval = []
  try:
    contextInfoCount = int(masterDictionary.get("%s.count" % rootPrefix,0))
    if (contextInfoCount > 0):
      for idx in range(1,contextInfoCount+1):
        contextDict = toDictionary(getPropList(masterDictionary,"%s.%d"% (rootPrefix,idx)))
        if (len(contextDict) > 0):
          retval.append(contextDict)
  except:
    _app_exception("Unexpected problem in contextInfoPropsToListODictionaries()")
  
  _app_exit("contextInfoPropsToListODictionaries(retval=%s)" % retval)
  return retval

#---------------------------------------------------------------------------------------------
# getContextListDifferences
#--------------------------------------------------------------------------------------------- 
def getContextListDifferences(sibConfigInfo,inputPrefix,existingProps,existingPrefix):
      inputContextInfoList = contextInfoPropsToListOfDictionaries(sibConfigInfo,"%s.contextInfo" % inputPrefix)
      existingContextInfoList = contextInfoPropsToListOfDictionaries(existingProps,"%s.contextInfo" % existingPrefix)
      updateContextInfoList = []
      for tempDict in inputContextInfoList:
        if tempDict not in existingContextInfoList:
          updateContextInfoList.append(tempDict)
      
      return updateContextInfoList
            


#--------------------------------------------------------------------------
# processMediations
# 
# Process mediation definitions in the supplied dictionary.
#--------------------------------------------------------------------------
def processMediations(sibConfigInfo,busName,sibId,prefix,existingProps):
  try:
    # Confirm we have settings to process
    if (checkForPrefix(sibConfigInfo,"%s.mediations" % prefix)):
      
      if (existingProps != None):
        delayed = existingProps.get("app.sibus.delayedLoad")
        if (delayed != None and delayed == "true"):
            # Load mediation settings now
            getSIBDestinationMediationProperties(existingProps,busName, "app.sibus")
        
 
    
      mediationCount = int(sibConfigInfo.get("%s.mediations.count"%prefix,0))
      if (mediationCount > 0):
        for idx in range(1,mediationCount+1):
          medPrefix = "%s.mediations.%d" % (prefix,idx)
          
          mediationName = sibConfigInfo.get("%s.mediationName"%medPrefix,None)
          if (isEmpty(mediationName)):
            # Partial list
            continue
          
          mediationId = None
          existingPrefix = None
          
          # See if mediation is already defined
          if (existingProps != None):
            existingCount = int(existingProps.get("app.sibus.mediations.count",0))
            if (existingCount > 0):
              for existingIdx in range(1,existingCount+1):
                if (mediationName == existingProps.get("app.sibus.mediations.%d.mediationName" % existingIdx)):
                  existingPrefix = "app.sibus.mediations.%d" % existingIdx
                  mediationId = existingProps.get("%s.ID" % existingPrefix)
          
          if (not isEmpty(mediationId)):
            # Need to do updates
            
            subProps = getPropListDifferences(sibConfigInfo,medPrefix,existingProps,existingPrefix)
            if (not isEmpty(subProps.get("uuid"))):
              del subProps["uuid"]
            
            if (not isEmpty(subProps.get("mediationName"))):
              del subProps["mediationName"]
                      
            updateContextInfoList = getContextListDifferences(sibConfigInfo,medPrefix,existingProps,existingPrefix)
            
            if (len(subProps) > 0 or len(updateContextInfoList) > 0):
              updateMediation(mediationId=mediationId,mediationProps=subProps,contextInfoList=updateContextInfoList)
              _app_message("Mediation %s has been updated in SIBus %s" % (mediationName,busName))
            else:
              _app_message("No need to update mediation %s in SIBus %s" % (mediationName,busName))
          else:
            
            contextInfoList = contextInfoPropsToListOfDictionaries(sibConfigInfo,"%s.contextInfo" % medPrefix)
            mediationProps = getPropList(sibConfigInfo,medPrefix)
            
            mediationId = createMediation(busName,mediationName,mediationProps,contextInfoList)
            _app_message("Mediation %s has been created for SIBus %s" % (mediationName,busName))
            
 
          
  except:
    _app_exception("Unexpected problem in processMediations")

#-------------------------------------------------------------------------------------------
# processQueueDestinations
#
# Process the Queue Destination settings for a specific bus:
#
# Parameters:
#     busName - name of the bus
#     busId - configuration ID of the bus
#     prefix - the property prefix (e.g. "app.sibus.1")
#     existingProps - a property set with loaded properties representing current configuration
#                     If None, then the bus did not previously exist
#-------------------------------------------------------------------------------------------
def processQueueDestinations(busName, sibId, prefix, existingProps):

  try:
  
    if (existingProps != None):
        delayed = existingProps.get("app.sibus.delayedLoad")
        if (delayed != None and delayed == "true"):
            # Load queue settings now
            getSIBQueueProperties(existingProps,busName, "app.sibus")
            
    queueCount = int(configInfo.get("%s.queueDestinations.count" % prefix,"0"))
    if (queueCount > 0):
        for idx in range(1,queueCount+1):
          queueName = configInfo.get("%s.queueDestinations.%d.identifier" % (prefix, idx),"")
          if (isEmpty(queueName)):
              # Possibly partial configuration
              continue
              
          existingPrefix = getExistingQueuePrefix(queueName, existingProps)
          
          cluster = configInfo.get("%s.queueDestinations.%d.cluster" % (prefix,idx),"")
          node = configInfo.get("%s.queueDestinations.%d.node" % (prefix,idx),"")
          server = configInfo.get("%s.queueDestinations.%d.server" % (prefix,idx),"")
          
          
          if (existingPrefix == None):
          
              if (queueName.startswith("_SYSTEM")):
                  _app_message("Skipping definition of system queue %s" % queueName)
                  continue
                  
              # Creating a new queue definition
              baseProps = getPropList(configInfo, "%s.queueDestinations.%d" % (prefix,idx))
              
              replyDestinationProps = getPropList(configInfo, "%s.queueDestinations.%d.replyDestination" % (prefix,idx))
              
              frpcount = int(configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.count" % (prefix, idx),"0"))
              routingPath = ""
              if (frpcount > 0):
                  for frpidx in range(1,frpcount+1):
                      frpbus = configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.%d.prop.bus" % (prefix, idx,frpidx),"")
                      frpdestination  = configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.%d.prop.destination" % (prefix, idx,frpidx),"")
                      if (routingPath == ""):
                          routingPath = "%s:%s" % (frpbus,frpdestination)
                      else:
                          routingPath = "%s %s:%s" % (routingPath, frpbus,frpdestination)
                      
                      # Only can have one
                      break
                  
                  #baseProps.put("defaultForwardRoutingPath", '["%s"]' % routingPath)
                      
              contextInfoList = contextInfoPropsToListOfDictionaries(configInfo,"%s.queueDestinations.%d.contextInfo" % (prefix,idx) )
          
              result = createSIBDestination(queueName, "Queue", cluster, node, server, busName, baseProps, replyDestinationProps.get("destination"), replyDestinationProps.get("bus"),
                                            contextInfoList=contextInfoList)
          
              if (result == None):
                  _app_message("Error creating queue destination %s on bus %s" % (queueName, busName))
                  exit()
              else:
                  _app_message("Created queue destination %s on bus %s" % (queueName, busName))
                  queueId = result
                  
                  frpcount = int(configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.count" % (prefix, idx),"0"))
                  routingPath = []
                  if (frpcount > 0):
                    for frpidx in range(1,frpcount+1):
                      frpbus = configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.%d.prop.bus" % (prefix, idx,frpidx),"")
                      frpdestination  = configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.%d.prop.destination" % (prefix, idx,frpidx),"")
                      
                      routingPath.append([ ['bus',frpbus], ['destination',frpdestination]])
                      
                    if (modifyObject(queueId, [['defaultForwardRoutingPath',routingPath]])):
                      _app_message("Error updating default forward routing path for destination %s on bus %s" % (queueName, busName))
                      exit()
                    else:
                      _app_message("Updated default forward routing path for destination %s on bus %s" % (queueName, busName))
                      
                  processMediationAssignments(busName,queueName,queueId,configInfo,"%s.queueDestinations.%d" % (prefix,idx))
                  
          else:
              # Update an existing queue
              queueId = None
              baseProps = getPropListDifferences(configInfo, "%s.queueDestinations.%d" % (prefix,idx), existingProps, existingPrefix)
              baseProps.remove("uuid")
              
              replyDestinationProps = getPropListDifferences(configInfo, "%s.queueDestinations.%d.replyDestination" % (prefix,idx), existingProps, "%s.replyDestination" % existingPrefix )
              
              updateContextInfoList = getContextListDifferences(configInfo,"%s.queueDestinations.%d" % (prefix,idx),existingProps,existingPrefix)
              
              if (baseProps.size() == 0 and replyDestinationProps.size() == 0 and len(updateContextInfoList)==0):
                  _app_message("No updates for base properties of queue destination %s on bus %s" % (queueName, busName))
              else:
                  
                  result = modifySIBDestination(queueName, busName, "Queue", baseProps, replyDestinationProps.get("destination"), replyDestinationProps.get("bus"),
                                                contextInfoList=updateContextInfoList)
                  if (result == None):
                      _app_message("Error updating queue destination %s on bus %s" % (queueName, busName))
                      exit()
                  else:
                      _app_message("Updated queue destination %s on bus %s" % (queueName, busName))
                      queueId = result
              
              
              
              # See if default forwarding settings need to be updated
              comparableSettings1 = getComparableProperties(configInfo,"%s.queueDestinations.%d.defaultForwardRoutingPath" % (prefix, idx), "%s.defaultForwardRoutingPath"%existingPrefix)
              comparableSettings2 = getComparableProperties(existingProps,"%s.defaultForwardRoutingPath"%existingPrefix, None)
              
              
              if (not comparableSettings1.equals(comparableSettings2)):
                  # We are going to treat the new rules as total substitution
                  queueId = getDestinationId(queueName, busName, "Queue")
                  frpcount = int(configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.count" % (prefix, idx),"0"))
                  routingPath = []
                  if (frpcount > 0):
                    for frpidx in range(1,frpcount+1):
                      frpbus = configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.%d.prop.bus" % (prefix, idx,frpidx),"")
                      frpdestination  = configInfo.get("%s.queueDestinations.%d.defaultForwardRoutingPath.%d.prop.destination" % (prefix, idx,frpidx),"")
                      
                      routingPath.append([ ['bus',frpbus], ['destination',frpdestination]])
                      
                    if (modifyObject(queueId, [['defaultForwardRoutingPath',[]]])):
                        _app_message("Error nulling out routing path")
                        exit()
                      
                    if (modifyObject(queueId, [['defaultForwardRoutingPath',routingPath]])):
                      _app_message("Error updating default forward routing path for destination %s on bus %s" % (queueName, busName))
                      exit()
                    else:
                      _app_message("Updated default forward routing path for destination %s on bus %s" % (queueName, busName))
              elif (comparableSettings1.size() > 0 and comparableSettings2.size() > 0):
                  _app_message("No need to update forward routing path for destination %s on bus %s" % (queueName, busName))
              
              processMediationAssignments(busName,queueName,queueId,configInfo,"%s.queueDestinations.%d" % (prefix,idx),existingProps=existingProps,existingPrefix=existingPrefix)
          #endelse existing queue       
  except:
    _app_trace("Unexpected error processing queue destinations","exception")
    _app_message("Unexpected error processing queue destinations")
    exit()            
              
#enddef processQueueDestinations

#-------------------------------------------------------------------------------
# processMediationAssignments
#
# This method will process the properties that indicate that a mediation has been
# assigned to a particular SIBus destination (Queue or Topic)
# 
# Parameters:
#    busName - name of the SIBus
#    destinationName - Name of the queue or topic
#    destinationId - configuration ID of destination
#    sibConfigInfo - dictionary with input properties
#    inputPrefix - prefix of destinations properties (e.g. app.sibus.1.queueDestinations.2)
#    existingProps - existing properties for destination if it was previously defined
#    existingPrefix - prefix of existing destination properties
#
#-------------------------------------------------------------------------------
def processMediationAssignments(busName,destinationName,destinationId,sibConfigInfo,inputPrefix,existingProps=None,existingPrefix=None):
  _app_entry("processMediationAssignments(%s,%s,%s,sibConfigInfo,%s,existingProperties,%s)",busName,destinationName,destinationId,inputPrefix,existingPrefix)
  retval = None
  try:
    mediationName = sibConfigInfo.get("%s.destinationMediationRef.mediationName" % inputPrefix)
    if (not isEmpty(mediationName)):
      clusterTarget = sibConfigInfo.get("%s.destinationMediationRef.localizationPointRefs.1.prop.cluster" % inputPrefix)
      nodeTarget = sibConfigInfo.get("%s.destinationMediationRef.localizationPointRefs.1.prop.node" % inputPrefix)
      serverTarget = sibConfigInfo.get("%s.destinationMediationRef.localizationPointRefs.1.prop.server" % inputPrefix)
      
      if (not isEmpty(existingPrefix)):
        existingMediationName = existingProps.get("%s.destinationMediationRef.mediationName" % existingPrefix)
        if (isEmpty(existingMediationName)):
          # Add new mediation
          addMediationToSIBDestination(busName, mediationName, destinationName,clusterName=clusterTarget,nodeName=nodeTarget,serverName=serverTarget)
          _app_message("Mediation %s has been added to Bus %s Destination %s" % (mediationName,busName,destinationName))

        elif (existingMediationName == mediationName):
          _app_message("Mediation %s is already assigned to destination %s" % (mediationName,destinationName))
        else:
          _app_message("A different mediation (%s) is already assigned to destination %s" % (existingMediationName,destinationName))
      else:
        # This is a new destination being processed
        addMediationToSIBDestination(busName, mediationName, destinationName,clusterName=clusterTarget,nodeName=nodeTarget,serverName=serverTarget)
        _app_message("Mediation %s has been added to Bus %s Destination %s" % (mediationName,busName,destinationName))
        
  except:
    _app_exception("Unexpected problem in processMediationAssignments()")
  
  _app_exit("processMediationAssignments(retval=%s)" % retval)
  return retval
  
					
#-------------------------------------------------------------------------------------------
# getExistingEnginePrefix 
# 
# Search the existing properties for a messaging engine with the specified name and returns
# the prefix (e.g. "app.sibus.busmembers.idx.messageEngines.idx") that will allow the 
# existing propertie sfor the messageEngine to be compared against the input properties.
#
# Parameters:
#    searchName - engine to search for
#    memberPrefix - e.g. "app.sibus.busmembers.<idx>"
#    existingProps - properties to search in
#-------------------------------------------------------------------------------------------
def getExistingEnginePrefix(searchName, memberPrefix, existingProps):
		result = None
		
		if (existingProps == None):
				return result
		
		existingCount = existingProps.get("%s.messageEngines.count" % memberPrefix)
		
		if (existingCount == None):
				existingCount = "0"
		
		if (existingCount != "0"):		
			for idx in range(1,int(existingCount)+1):
					engineName = existingProps.get("%s.messageEngines.%d.name" % (memberPrefix, idx))
				
					if (searchName == engineName):
							result = "%s.messageEngines.%d" % (memberPrefix, idx)
							break
		
		
		return result
		
#enddef


#-------------------------------------------------------------------------------------------
# processEnginesSettings
#
# Process the settings for a messaging engine. This method could be called multiple times with the
# same arguments if dynamic properties are used to set up multiple messaging engines.
#
# Parameters:
#     busName - Name of the bus
#     memberCluster - cluster name if member is a cluster
#     memberNode - Node name if member is a server
#     memberServer - server name if member is a server
#     meprefix - the prefix for the messaging engine, e.g. "app.sibus.<bus-idx>.busmembers.<member-idx>.messageEngines.<idx>"
#     existingProps - property set with current configuration settings if this was an existing bus
# 		existingPrefix - the prefix for the bus member in existingProps, None if bus member is new
#     propagatedMessagingEngineSettings - A collection of settings from first messaging engine to merge with settings for new MEs
#-------------------------------------------------------------------------------------------
def processEngineSettings(busConfigInfo,busName, memberCluster, memberNode, memberServer, meprefix, existingProps, existingPrefix,propagatedMessagingEngineSettings=None):

  _app_trace("processEngineSettings(%s,%s,%s,%s,%s,existingProps,%s)" % (busName, memberCluster, memberNode, memberServer, meprefix, existingPrefix),"entry")
  try:              
      meName = busConfigInfo.get("%s.name" % (meprefix), "")
      if (meName == ""):
          # Possibly a partial configuration
          pass
      else:
        # Valid me name 
         
        # Handle dynamic names
        meName = substituteDynamicValues("name", meName)
        
        existingMEPrefix = None
        if (existingPrefix != None):
            # Possible that we are doing an update
            existingMEPrefix = getExistingEnginePrefix(meName, existingPrefix, existingProps)
        
        if (existingMEPrefix == None):
            # Creating a new messaging engine
            engineProps = getPropList(busConfigInfo,"%s" % (meprefix),1)
            dbProps = getPropList(busConfigInfo,"%s.dataStore" % (meprefix),1)
            fileProps = getPropList(busConfigInfo,"%s.fileStore" % (meprefix),1)
            
            customProps = getPropList(busConfigInfo,"%s.customProperties" % (meprefix),1)
            
            
            if (propagatedMessagingEngineSettings != None):
              mergeMissingProperties(getPropList(propagatedMessagingEngineSettings,"modelEngine") , engineProps)
              mergeMissingProperties(getPropList(propagatedMessagingEngineSettings,"modelEngine.customProperties") , customProps)
              
            
            
            result = createSIBEngine(memberCluster, memberNode, memberServer, busName, engineProps, dbProps, fileProps, customProps)
            if (result == None):
                _app_message("Error creating messaging engine %s for %s %s %s %s" % (meName, busName, memberCluster, memberNode, memberServer))
                exit()
            else:
                _app_message("Created messaging engine %s for %s %s %s %s" % (meName, busName, memberCluster, memberNode, memberServer))
                
                # Now update the localization points for this new messaging engine
                if (propagatedMessagingEngineSettings != None):
                  processLocalizationPointsForMessageEngine(propagatedMessagingEngineSettings,busName,None,result,"modelEngine")
        else:
            # Updating an existing messaging engine
  
            
            engineProps = getPropListDifferences(busConfigInfo, "%s"% (meprefix), existingProps, existingMEPrefix)
            dbProps = getPropListDifferences(busConfigInfo,"%s.dataStore" % (meprefix), existingProps, "%s.dataStore" % existingMEPrefix )
            fileProps = getPropListDifferences(busConfigInfo,"%s.fileStore" % (meprefix), existingProps, "%s.fileStore" % existingMEPrefix )
            customProps = getPropListDifferences(busConfigInfo,"%s.customProperties" % (meprefix), existingProps, "%s.customProperties" % existingMEPrefix )
            
            engineProps.remove("uuid")
            dbProps.remove("uuid")
            fileProps.remove("uuid")
  
            if (engineProps.size() == 0 and dbProps.size() == 0 and fileProps.size() == 0 and customProps.size() == 0):
                _app_message("No changes required for messaging engine %s for %s %s %s %s" % (meName, busName, memberCluster, memberNode, memberServer))
            else:
              result = updateSIBEngine(meName, memberCluster, memberNode, memberServer, busName, engineProps, dbProps, fileProps, customProps)
              if (result == None):
                _app_message("Error updating messaging engine %s for %s %s %s %s" % (meName, busName, memberCluster, memberNode, memberServer))
                exit()
              else:
                _app_message("Updated messaging engine %s for %s %s %s %s" % (meName, busName, memberCluster, memberNode, memberServer))    
                
      #endelse valid me name
  except:
    _app_trace("Error processEngineSettings", "exception") 
    _app_message("Unexpected error in processEngineSettings")
    exit()
  
  _app_trace("processEngineSettings()","exit")


#-------------------------------------------------------------------------------------------
# processEnginesForBusMember
# 
# Process the Message Engine settings in configInfo for a specific Bus Member. This function
# will iterate through the settings and create/update a messaging engine for each definition.
#
# There is special handling for the iterateClusterMembers setting that will cause this
# function to use a single set of properties (with dynamic fields) to create a engine 
# for each member in a cluster.
#
# Parameters:
#     busName - Name of the bus
#     memberCluster - cluster name if member is a cluster
#     memberNode - Node name if member is a server
#     memberServer - server name if member is a server
#     prefix - the prefix for the bus member, e.g. "app.sibus.<idx>.busmembers.<idx>"
#     existingProps - property set with current configuration settings if this was an existing bus
# 		existingPrefix - the prefix for the bus member in existingProps, None if bus member is new
#-------------------------------------------------------------------------------------------
def processEnginesForBusMember(busName, memberCluster, memberNode, memberServer, prefix, existingProps, existingPrefix):

    _app_trace("processEnginesForBusMember(%s,%s,%s,%s,%s,existingProps,%s)" % (busName, memberCluster, memberNode, memberServer, prefix, existingPrefix),"entry")
    skipFirst = 1
    
    propagatedMessagingEngineSettings = None
    
    if (not isEmpty(existingPrefix)):
        # Don't skip processing on first messaging engine
        # Since this is an update
        skipFirst = 0
        
        # And load the settings for the existing messaging engines
        getMessageEnginePropertiesForBusMember(existingProps, existingPrefix, busName, memberCluster, memberNode, memberServer)
        
        # If this is a cluster bus member and has the propagateMessagingEngineSettings setting for the 
        # bus member, then prepare a set of properties to be used as a base for setting up new messaging engines
        if (not isEmpty(memberCluster)):
          propagateFlag = configInfo.get("%s.messageEngines.propagateSettings"%prefix,"false")
          if (propagateFlag.lower() == "true"):
            propagatedMessagingEngineSettings = transformPropertyKeys(existingProps,"%s.messageEngines.1" % existingPrefix, "modelEngine")
              
            # Load the Localization points information also
            modelEngineId = existingProps.get("%s.messageEngines.1.CONFIG_ID" % existingPrefix)
            if (not isEmpty(modelEngineId)):
              modelLocalizationPoints =  getSIBLocalizationPointProperties(modelEngineId)
              for key in modelLocalizationPoints.keys():
                propagatedMessagingEngineSettings["modelEngine.%s" % key] = modelLocalizationPoints[key]
              
                         
             
          #endif
        
        
        
        
    
    meCount = int(configInfo.get("%s.messageEngines.count" % prefix,"0"))
    
    if (meCount > 0):
      try:
        for idx in range(1,meCount+1):
          if (idx == 1 and skipFirst == 1):
              continue
              
          iterateFlag = configInfo.get("%s.messageEngines.%d.iterateClusterMembers" % (prefix,idx),"false")
          
          
          
          if (iterateFlag.lower() != "true"):
              processEngineSettings(configInfo,busName, memberCluster, memberNode, memberServer, "%s.messageEngines.%d" % (prefix, idx), existingProps, existingPrefix, propagatedMessagingEngineSettings)
          else:
              if (isEmpty(memberCluster)):
                  _app_message("Bus member must be a cluster for iterateClusterMember functionality")
                  exit()
                  
              
                  
              _app_message("Creating/updating a messaging engine for each member of cluster %s" % memberCluster)
              
              nodelist = getSortedListFromProperty(configInfo,"%s.messageEngines.%d.iterateClusterMembers.nodes" %  (prefix,idx))
              serverMEList = buildServerSpecificMessageEngineList(configInfo, "%s.messageEngines.%d" % (prefix, idx), memberCluster, nodelist)
              if (len(serverMEList) == 0):
                raise StandardError("Unable to build messaging engine list for nodes")
              
              # Since this is a dynamic list of ME's, see if the list has gotten shorter
              if (existingPrefix != None):
                deletedMEs = trimSIBEngines(busName, memberCluster, len(serverMEList))
                if (len(deletedMEs) > 0):
                  for deletedME in deletedMEs:
                    _app_message("Number of messaging engines has shrunk down to %d, %s has been deleted" % (len(serverMEList), deletedME))
                
                  cgname = trimClusterPolicies(memberCluster, deletedMEs)
                  _app_message("Policies referencing these Messaging engines have been removed from coregroup %s" % cgname)
              
              # Now iterate through sorted list and build a messaging engine that corresponds to each
              # cluster member
              for serverME in serverMEList:
                  processEngineSettings(serverME.meProps,busName, memberCluster, memberNode, memberServer, serverME.mePrefix, existingProps, existingPrefix,propagatedMessagingEngineSettings)
              
              # Clear dynamic values
              setDynamicId("CURRENT_SERVER", "")
              setDynamicId("CURRENT_CLUSTER", "")
              setDynamicId("CURRENT_NODE", "")
              setDynamicId("SERVER_INDEX", "")
              setDynamicId("SERVER_INDEX0", "")
              setDynamicId("SHORT_SERVER_INDEX", "")
              setDynamicId("SHORT_SERVER_INDEX0", "")              
              setDynamicId("CURRENT_SERVER_NAME","")
              setDynamicId("CURRENT_NODE_NAME","")
              setDynamicId("CURRENT_CLUSTER_NAME","")
             
      except:
        _app_trace("Error processEnginesForBusMember", "exception") 
        _app_message("Unexpected error in processEnginesForBusMember")
        exit()  
    
    
    _app_trace("processEnginesForBusMember()","exit")
    
    


#-------------------------------------------------------------------------------------------
# getExistingMemberPrefix
#
# Search the existing properties for a bus member with the specified name and return the prefix
# for the messaging engine. The prefix will allow a comparison between existing properties and 
# input configuration.
# 
# Parameters:
#		memberCluster - The cluster name if member is a cluster
#   memberNode - node name if member is a server
#		memberServer - The server name if the member is a server
#   existingProps - the property set to search in
#
# Returns: Prefix for matching properties:  "app.sibus.busmembers.<idx>" or None if no match
#-------------------------------------------------------------------------------------------
def getExistingMemberPrefix(memberCluster, memberNode, memberServer, existingProps):

		_app_trace("getExistingMemberPrefix(%s, %s, %s, existingProps)" % (memberCluster, memberNode, memberServer),"entry")
		result = None
		
		if (existingProps == None):
				return result
		
		existingCount = existingProps.get("app.sibus.busmembers.count")
		if (existingCount == None):
				existingCount = "0"
				
		if (existingCount != "0"):
			for idx in range(1,int(existingCount)+1):
				existingCluster = existingProps.get("app.sibus.busmembers.%d.cluster" % idx)
				if (existingCluster == None): existingCluster = ""
				existingNode = existingProps.get("app.sibus.busmembers.%d.node" %idx)
				if (existingNode == None): existingNode = ""
				existingServer = existingProps.get("app.sibus.busmembers.%d.server" % idx)
				if (existingServer == None): existingServer = ""
				
				if (memberCluster == existingCluster and memberNode == existingNode and memberServer == existingServer):
						result = "app.sibus.busmembers.%d" % idx
						break
		
		
		_app_trace("getExistingMemberPrefix(result = %s)"% result,"exit")
		return result
		
#-------------------------------------------------------------------------------
# ServerSpecificMessageEngineList
# This class is used to hold the generated settings for a server specific messaging engine
#-------------------------------------------------------------------------------
class ServerSpecificMessageEngine:
  
  def __init__(self,_serverName,_nodeName,_meProps, _mePrefix):
    self.serverName = _serverName
    self.nodeName = _nodeName
    self.meProps = _meProps
    self.mePrefix = _mePrefix

#-------------------------------------------------------------------------------
# buildServerSpecificMessageEngineList
#
# Returns a list of ServerSpecificMessageEngine
#-------------------------------------------------------------------------------
def buildServerSpecificMessageEngineList(busConfigInfo, meprefix, clusterName, nodeList):
  
  retval = []
  
  try:
    clusterId = AdminConfig.getid("/ServerCluster:%s/"%clusterName)
    
    servers = getSortedClusterMemberList(clusterName, None,nodeList)
    sidx = 0
    for server in servers:
      sidx += 1
      mName = server[0]
      mNode = server[1]
      
      serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (mNode,mName))
      
      if (isEmpty(serverId)):
          _app_message("Unable to find server ID for %s %s" % (mNode,mName))
          exit()
      
      nodeId = AdminConfig.getid("/Node:%s/"% mNode)
      
      setDynamicId("CURRENT_SERVER_NAME",mName)
      setDynamicId("CURRENT_NODE_NAME",mNode)
      setDynamicId("CURRENT_CLUSTER_NAME",clusterName)
      setDynamicId("CURRENT_SERVER", serverId)
      setDynamicId("CURRENT_CLUSTER", clusterId)
      setDynamicId("CURRENT_NODE", nodeId)
      setDynamicId("SERVER_INDEX", str(sidx).zfill(3))
      setDynamicId("SERVER_INDEX0", str(sidx-1).zfill(3))  
      setDynamicId("SHORT_SERVER_INDEX", str(sidx).zfill(2))
      setDynamicId("SHORT_SERVER_INDEX0", str(sidx-1).zfill(2))  
      
      meProps = filterProperties(busConfigInfo,meprefix)
      for key in meProps.keys():
        newval = substituteDynamicValues(key, meProps.get(key))
        meProps[key] = newval
        
        
      retval.append(ServerSpecificMessageEngine(mName,mNode,meProps,meprefix))
    
  except:
    _app_trace("Unexpected error in buildServerSpecificMessageEngineList","exception")
    raise StandardError("Unexpected error in buildServerSpecificMessageEngineList")
  
  return retval

#-------------------------------------------------------------------------------------
# processBusMembers
# Process the bus member settings for a specific bus
#
#	Parameters:
# 	busName - name of the bus
#		busId - configuration Id of the bus
#   prefix - prefix of the bus (e.g. app.sibus.<idx>
#   existingProps - existing bus properties if the bus existed prior to script exection
#-------------------------------------------------------------------------------------
def processBusMembers(busName, busId, prefix, existingProps):

  _app_trace("processBusMembers(%s,%s,%s,existingProps)" % (busName, busId, prefix),"entry")
  
  try:
  
    # See if we even have any settings to be worried about
    memberCount = int(configInfo.get("%s.busmembers.count" % prefix,"0"))
  
    if (memberCount == 0):
      _app_message("No bus members to process for bus %s" % busName)
      return
  
    # See if we need to existing member properties
    if (existingProps != None):
      delayed = existingProps.get("app.sibus.delayedLoad")
      if (delayed != None and delayed == "true"):
          getBusMemberAndMessageEngineProperties(existingProps, busId, busName,"app.sibus")
      
    for memberIdx in range(1,memberCount+1):
      
      memberCluster = configInfo.get("%s.busmembers.%d.cluster" % (prefix, memberIdx),"")
      memberNode = configInfo.get("%s.busmembers.%d.node" % (prefix, memberIdx),"")
      memberServer = configInfo.get("%s.busmembers.%d.server" % (prefix, memberIdx),"")
      
      if (isEmpty(memberCluster) and isEmpty(memberNode) and isEmpty(memberServer)):
          # partial definition - go on to the next member
          continue
      
      firstMessageEngineName = configInfo.get("%s.busmembers.%d.messageEngines.1.name" % (prefix, memberIdx),"")
      
      existingPrefix = None
      # See if the member already exists
      if (existingProps != None):
          existingPrefix = getExistingMemberPrefix(memberCluster, memberNode, memberServer, existingProps)
          
      if (existingPrefix == None):
          # We are creating the member for the first time
          _app_message("Creating new member %s %s %s for bus %s" % (memberCluster, memberNode, memberServer, busName))
          
          memberProps = getPropList(configInfo, "%s.busmembers.%d" % (prefix, memberIdx))
          
          iterateFlag = configInfo.get("%s.busmembers.%d.messageEngines.1.iterateClusterMembers" % (prefix,memberIdx),"false")
          
          serverMEList = []
          if (iterateFlag.lower() == "true"):
            # do special processing for first messaging engine
            # We must allow for dynamic templates
            
            nodelist = getSortedListFromProperty(configInfo,"%s.busmembers.%d.messageEngines.1.iterateClusterMembers.nodes" %  (prefix,memberIdx))
            serverMEList = buildServerSpecificMessageEngineList(configInfo, "%s.busmembers.%d.messageEngines.1" % (prefix, memberIdx), memberCluster, nodelist)
            if (len(serverMEList) == 0):
              raise StandardError("Unable to build messaging engine list for nodes")
              
            medata = serverMEList[0]
            meprops = medata.meProps
            
            # Pull the messaging engine settings from the generated properties
            dbProps = getPropList(meprops, "%s.busmembers.%d.messageEngines.1.dataStore" % (prefix, memberIdx))
            fileProps = getPropList(meprops, "%s.busmembers.%d.messageEngines.1.fileStore" % (prefix, memberIdx))
            engineCustomProps = getPropList(meprops, "%s.busmembers.%d.messageEngines.1.customProperties" % (prefix, memberIdx))
            engineProps = getPropList(meprops,"%s.busmembers.%d.messageEngines.1" % (prefix,memberIdx))
            
          else:
            # Just pull the Messaging engine properties as-is
            dbProps = getPropList(configInfo, "%s.busmembers.%d.messageEngines.1.dataStore" % (prefix, memberIdx))
            fileProps = getPropList(configInfo, "%s.busmembers.%d.messageEngines.1.fileStore" % (prefix, memberIdx))
            engineCustomProps = getPropList(configInfo, "%s.busmembers.%d.messageEngines.1.customProperties" % (prefix, memberIdx))
            engineProps = getPropList(configInfo,"%s.busmembers.%d.messageEngines.1" % (prefix,memberIdx))
          
          memberInfo = addSIBusMember(busName, memberCluster, memberNode, memberServer, memberProps, dbProps, fileProps,engineCustomProps,engineProps)
          
          if (isEmpty(memberInfo)):
              _app_message("Error creating member %s %s %s for bus %s" % (memberCluster, memberNode, memberServer, busName))
              exit()
          else:
              _app_message("Created member %s %s %s for bus %s" % (memberCluster, memberNode, memberServer, busName))
              
          if (len(serverMEList) > 1):
            # Handle the rest of dynamically generated messaging engines
            for meidx in range(1,len(serverMEList)):
              medata = serverMEList[meidx]
              meprops = medata.meProps
              meprefix = medata.mePrefix
              
              processEngineSettings(meprops,busName, memberCluster, memberNode, memberServer, meprefix, None, None)
      else:
          # We are updating the member
          _app_message("Bus member already exists: %s %s %s for bus %s" % (memberCluster, memberNode, memberServer, busName))
          
          # Load the engine settings
          #existingPrefix = getExistingMemberPrefix(memberCluster, memberNode, memberServer, existingProps)
      
      # Now process the remaining messaging engines
      processEnginesForBusMember(busName, memberCluster, memberNode, memberServer, "%s.busmembers.%d"  % (prefix,memberIdx), existingProps, existingPrefix)
    
    # end for each bus member definition
    
  except:
    _app_trace("Unexpected error in processBusMembers","exception")
    _app_message("Unexpected error processing Bus Member defintiions")
    exit()
    
  _app_trace("processBusMembers()","exit")
	
#enddef processBusMembers

#---------------------------------------------------------------------------------------------
# checkForAuthMatch
#
# Utility method that check to see if a Identifier/UniqueName is in the existing authorization
# settings by checking the properties loaded from the current SIBAuthSpace settings.  This 
# utility method can be used to check various settings by passing in the prefix identifier to
# check for.
#
# Parameters:
#			authspaceprops - the properties loaded from current SIBAuthSpace settings
#			prefix - the prefix to use for the search (e.g. app.sibus.sibauthspace.busConnect.group )
#			matchIdentifier - the identifier to match against
#			matchUniqueName - the uniqueName value to match against
#
#	Returns:
#			1 - match found
#			0 - no match found
#			
#---------------------------------------------------------------------------------------------
def checkForAuthMatch(authspaceprops, prefix, matchIdentifier, matchUniqueName):
	
	_app_trace("checkForAuthMatch(authspaceprops, %s,%s,%s)" %( prefix, matchIdentifier, matchUniqueName),"entry")
	retval = 0
	
	
	if (isEmpty(matchUniqueName)):
			matchUniqueName = "" 
			
	countVal = authspaceprops.get("%s.count" % prefix)
	if (countVal == None):
			countVal = "0"
			
	for idx in range(1,int(countVal)+1):
			tempIdentifier = authspaceprops.get("%s.%d.prop.identifier" % (prefix,idx))
			tempUniqueName = authspaceprops.get("%s.%d.prop.uniqueName" % (prefix,idx))
				
				
				
			if (tempUniqueName == None):
					tempUniqueName = ""
				
			if (matchIdentifier == tempIdentifier and matchUniqueName == tempUniqueName):
				# found a match in existing props
				retval = 1
				break

	_app_trace("checkForAuthMatch(retval = %d)" % retval,"exit")
	return retval

#----------------------------------------------------------------------------------------------
# determineNewAuthList
#
# Determine which of the authorization identifiers are actually new settings and returns those
# in  a list of [identifier, uniqueName] pairs.
#----------------------------------------------------------------------------------------------
def determineNewAuthList(inputPrefix, existingPrefix, authSpaceProps):
	retval = []
	
	_app_trace("determineNewAuthList(%s,%s,authSpaceProps)" % (inputPrefix, existingPrefix), "entry")
	
	inputCount = int(configInfo.get("%s.count" % inputPrefix, "0"))
	for idx in range(1,inputCount+1):
		inputIdentifier = configInfo.get("%s.%d.prop.identifier" % (inputPrefix,idx),"")
		inputUniqueName = configInfo.get("%s.%d.prop.uniqueName" % (inputPrefix,idx),"")
		
		if (isEmpty(inputIdentifier)):
			# Partial list
			continue
			
		if (isEmpty(inputUniqueName)):
			inputUniqueName = ""
		
		authExists = checkForAuthMatch(authSpaceProps,existingPrefix,inputIdentifier,inputUniqueName)
		if (authExists == 0):
			# The identifier does not exist in current settings
			retval.append([inputIdentifier, inputUniqueName])
	
	_app_trace("determineNewAuthList(result = %s)" % retval, "exit")
	return retval
	 
#-------------------------------------------------------------------------------------
# processSIBAuthSpace
#
# Process the properties that corresponding to the authorization settings in the 
# SIBAuthSpace configuration item.  This is a complex feature and this method only does
# a subset of properties at this point.
#-------------------------------------------------------------------------------------
def processSIBAuthSpace(busName, busId, prefix, existingProps = None):
	_app_trace("processSIBAuthSpace(%s,%s,%s,existingProps)" % (busName, busId, prefix),"entry")
	try:
		if checkForPrefix(configInfo,"%s.sibauthspace" % prefix):
			# We have sibauthspace settings to process
			
			# We fetch properties for new or existing
			authspaceProps = getAuthSpaceProperties(busId,existingProps)
			
			newBusConnectUsers = determineNewAuthList("%s.sibauthspace.busConnect.user" % prefix, "app.sibus.sibauthspace.busConnect.user", authspaceProps)
			newBusConnectGroups = determineNewAuthList("%s.sibauthspace.busConnect.group" % prefix, "app.sibus.sibauthspace.busConnect.group", authspaceProps)

			
			if (len(newBusConnectGroups) > 0 or len(newBusConnectUsers) > 0):
				updateBusConnectorUserGroups(busId, newBusConnectUsers, newBusConnectGroups)
				_app_message("Updated bus connector role settings for bus %s" % busName)
				
			newBrowserUsers = determineNewAuthList("%s.sibauthspace.default.browser.user" % prefix, "app.sibus.sibauthspace.default.browser.user", authspaceProps)
			newBrowserGroups = determineNewAuthList("%s.sibauthspace.default.browser.group" % prefix, "app.sibus.sibauthspace.default.browser.group", authspaceProps)

			newCreatorUsers = determineNewAuthList("%s.sibauthspace.default.creator.user" % prefix, "app.sibus.sibauthspace.default.creator.user", authspaceProps)
			newCreatorGroups = determineNewAuthList("%s.sibauthspace.default.creator.group" % prefix, "app.sibus.sibauthspace.default.creator.group", authspaceProps)

			newReceiverUsers = determineNewAuthList("%s.sibauthspace.default.receiver.user" % prefix, "app.sibus.sibauthspace.default.receiver.user", authspaceProps)
			newReceiverGroups = determineNewAuthList("%s.sibauthspace.default.receiver.group" % prefix, "app.sibus.sibauthspace.default.receiver.group", authspaceProps)			
			
			newSenderUsers = determineNewAuthList("%s.sibauthspace.default.sender.user" % prefix, "app.sibus.sibauthspace.default.sender.user", authspaceProps)
			newSenderGroups = determineNewAuthList("%s.sibauthspace.default.sender.group" % prefix, "app.sibus.sibauthspace.default.sender.group", authspaceProps)
			
			newAdopterUsers = determineNewAuthList("%s.sibauthspace.default.identityAdopter.user" % prefix, "app.sibus.sibauthspace.default.identityAdopter.user", authspaceProps)
			newAdopterGroups = determineNewAuthList("%s.sibauthspace.default.identityAdopter.group" % prefix, "app.sibus.sibauthspace.default.identityAdopter.group", authspaceProps)
			
			newdefaultsettings = len(newBrowserGroups) + len(newBrowserUsers) + len(newCreatorUsers) + len(newCreatorGroups) + len(newReceiverGroups) + len(newReceiverUsers)
			newdefaultsettings = newdefaultsettings + len(newSenderGroups) + len(newSenderUsers) + len(newAdopterGroups) + len(newAdopterUsers)
			
			if (newdefaultsettings > 0):
				# One of these settings has changes
				updateSIBAuthDefaultUsersGroups(busId,newBrowserUsers, newBrowserGroups, newCreatorUsers, newCreatorGroups,	newReceiverUsers, newReceiverGroups,	newSenderUsers, newSenderGroups, newAdopterUsers, newAdopterGroups)
				_app_message("Updated default authorization settings for bus %s" % busName)  
			
	except:
		_app_trace("Error processing SIBAuthSpace settings","exception")
		exit()
		
	_app_trace("processSIBAuthSpace()","exit")

#-------------------------------------------------------------------------------------
# processSIB
#
# Pull the SIBus settings from the configInfo dictionary and process them.
#-------------------------------------------------------------------------------------
def processSIB():

	_app_trace("processSIB()","entry")
	try:
	  
		# Do deletions first
		processSIBDeletions(configInfo)
		
		sibCount = int(configInfo.get("app.sibus.count","0"))
		
		if (sibCount == 0):
				_app_message("Skipping SIBus setup")
		
		for idx in range(1, sibCount+1):
		
				prefix = "app.sibus.%d" % idx
				
				# Get the bus properties
				name = configInfo.get("%s.name"%prefix,"")
				if (isEmpty(name)):
						_app_message("Skipping SIBus %d - missing name" % idx)
						continue
						
				_app_message("Processing settings for bus %s" % name)
				
				# See if this bus already exists
				busId = checkExistingBus(name)
				
				existingProperties = None
				
				if (not isEmpty(busId)):
				
						_app_message("Bus %s already exists" % name)
						existingProps = getBusProperties(busId,0)
						
						subProps = getPropListDifferences(configInfo,  prefix, existingProps, "app.sibus")
						customSubProps = getPropListDifferences(configInfo, "%s.customProperties" % prefix, existingProps, "app.sibus.customProperties")
						subProps.remove('uuid')
						
						if (subProps.size() > 0 or customSubProps.size() > 0):
								retval = updateSIBus(busId, name, subProps, customSubProps)
								if (isEmpty(retval)):
										_app_message("Error updating existing bus %s" % name)
										exit()
								else:
										_app_message("Updated base and custom properties for bus %s" % name)
						
						else:
								_app_message("No new base or custom properties for bus %s" % name)
						
						processSIBAuthSpace(name, busId, prefix, existingProps)
						processBusMembers(name, busId, prefix, existingProps)
						processMediations(configInfo,name,busId,prefix,existingProps)
						processQueueDestinations(name, busId, prefix, existingProps)
						processTopicDestinations(name, busId, prefix, existingProps)
						
						processLocalizationPoints(configInfo,prefix,name,busId)
						
				else:
						_app_message("Creating bus %s" % name)
						
						busProps = getPropList(configInfo, prefix)
						
						busCustomProps = getPropList(configInfo,"%s.customProperties" % prefix)
						
						busId = createSIBus(name, busProps, busCustomProps)
						if (not isEmpty(busId)):
								_app_message("Created bus %s" % (name))
						else:
								_app_message("Error creating new bus %s" % (name))
								exit()
								
						processSIBAuthSpace(name, busId, prefix, None)
						processBusMembers(name, busId, prefix, None)
						processMediations(configInfo,name,busId,prefix,None)
						processQueueDestinations(name, busId, prefix, None)
						processTopicDestinations(name, busId, prefix, None)
						
						processLocalizationPoints(configInfo,prefix,name,busId)
				
		
		#endfor

	except:
		_app_trace("Unexpected error processing SIB settings","exception")
		_app_message("Unexpected error processing SIB settings")
		exit()

	_app_trace("processSIB()","exit")

#enddef setupSIB