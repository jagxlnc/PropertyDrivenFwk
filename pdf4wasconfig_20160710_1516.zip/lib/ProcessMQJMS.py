################################################################################
# ProcessMQJMS.py
# 
# This script contains the functions that process the MQ JMS configuration
# properties that have been loaded into the global configInfo dictionary.
#
# Primary function: 
#    processMQJMS()
#
# Related modules:
#		 MQJMS.py - Contains functions used to create/modify providers and datasources
#    Utils.py - Utility methods
# 
# Sample Property Format:
#
# List of providers is top level
#
# app.mqjms.provider.1.cluster = SampleCluster
# app.mqjms.provider.1.node = 
# app.mqjms.provider.1.server = 
# app.mqjms.provider.1.name = WebSphere MQ JMS Provider
# app.mqjms.provider.1.prop.description = WebSphere MQ Messaging Provider
# app.mqjms.provider.1.prop.isolatedClassLoader = false
# app.mqjms.provider.1.prop.supportsASF = true
# app.mqjms.provider.1.resourceAdapter.propertySet.resourceProperties.prop.connectionConcurrency = int|false|5|connectionConcurrency
# app.mqjms.provider.1.resourceAdapter.propertySet.resourceProperties.prop.maxConnections = int|false|10|maxConnections
# ...
# Support Queue, Topic and Generic connection factories (queueConnectionFactory, topicConnectionFactory, and genericConnectionFactory properties
# app.mqjms.provider.2.genericConnectionFactory.1.name = MyClusterConnectionFactory
# app.mqjms.provider.2.genericConnectionFactory.1.prop.CCSID = 819
# app.mqjms.provider.2.genericConnectionFactory.1.prop.XAEnabled = true
# ...
# app.mqjms.provider.2.genericConnectionFactory.1.connectionPool.prop.agedTimeout = 0
# app.mqjms.provider.2.genericConnectionFactory.1.connectionPool.prop.connectionTimeout = 180
# app.mqjms.provider.2.genericConnectionFactory.1.connectionPool.prop.unusedTimeout = 1800
# ...
# app.mqjms.provider.2.genericConnectionFactory.1.mappingModule.prop.mappingConfigAlias = DefaultPrincipalMapping
# app.mqjms.provider.2.genericConnectionFactory.1.sessionPool.prop.agedTimeout = 0
# ...
# Queues and their resource properties are in this format:
#
# app.mqjms.provider.1.queue.1.name = NewSampleMQQueue
# app.mqjms.provider.1.queue.1.prop.CCSID = 1208
# app.mqjms.provider.1.queue.1.prop.baseQueueName = MYQUEUE
# ...
# app.mqjms.provider.1.queue.1.propertySet.resourceProperties.prop.ResourceProp2 = java.lang.String|false|2|Hello There
# app.mqjms.provider.1.queue.1.propertySet.resourceProperties.prop.ResourceProp1 = java.lang.String|false|One|Hello
#
# Topics and their resource properties are in this format:
#
# app.mqjms.provider.3.topic.1.name = NewServerMQTopic
# app.mqjms.provider.3.topic.1.prop.CCSID = 1208
# app.mqjms.provider.3.topic.1.prop.baseTopicName = MYTOPIC
# ...
# app.mqjms.provider.3.topic.1.propertySet.resourceProperties.prop.ResourceProp1 = java.lang.String|false|Once|Hello
# app.mqjms.provider.3.topic.count = 1
#
# Activation specs are in this format:
#
# app.mqjms.provider.5.activationSpec.1.name = SampleMQActivationSpec
# app.mqjms.provider.5.activationSpec.1.prop.subscriptionDurability = Nondurable
# app.mqjms.provider.5.activationSpec.1.prop.jndiName = jms/SampleMQActSpec
# ...
# app.mqjms.provider.5.activationSpec.count = 1
################################################################################
global configInfo
global progInfo

#-------------------------------------------------------------------------------
# processMQActivationSpecSettings
# 
# Process the settings for a specific activation spec
# 
# Parameters:
#   provider - the JMSProvider ID
#   prefix - the prefix (e.g. "app.mqjms.provider.5.activationSpec.1")
#   pScope - the scope string for logging purposes
#-------------------------------------------------------------------------------
def processMQActivationSpecSettings(provider,prefix,pScope):
  _app_trace("processMQActivationSpecSettings(%s,%s,%s)" % (provider,prefix,pScope),"entry")
  try:
    actSpecName = configInfo.get("%s.name" % prefix, "")
    if (not isEmpty(actSpecName)):
      actSpecId = findMQActivationSpec(provider, actSpecName)
      if (not isEmpty(actSpecId)):
        # Update
        existingProps = getMQJMSActivateSpecProperties(actSpecId)
        subProps = getPropListDifferences(configInfo,prefix,existingProps,"mqjms.actspec")
        if (len(subProps) > 0):
          retval = modifyMQActivationSpec(actSpecId, subProps)
          if (isEmpty(retval)):
            _app_message("Error updating MQ JMS Activation Spec %s at %s scope" % (actSpecName, pScope))
            exit()
          else:
            _app_message("Updated MQ JMS Activation Spec %s at %s scope" % (actSpecName, pScope))
        else:
          _app_message("No need to update MQ JMS Activation Spec %s at %s scope" % (actSpecName, pScope))
      else:
        # Create
        subProps = getPropList(configInfo,prefix)
        retval = createMQActivationSpec(provider, actSpecName, subProps)
        if (isEmpty(retval)):
          _app_message("Error creating MQ JMS Activation Spec %s at %s scope" % (actSpecName, pScope))
        else:
          _app_message("Created MQ JMS Activation Spec %s at %s scope" % (actSpecName, pScope))
  except:
    _app_trace("Unexpected error in processMQActivationSpecSettings","exception")
    exit()
  _app_trace("processMQActivationSpecSettings()","exit")

#-------------------------------------------------------------------------------
# processMQTopicSettings
# 
# Process the settings for a specific topic
# 
# Parameters:
#   provider - the JMSProvider ID
#   prefix - the prefix (e.g. "app.mqjms.provider.5.topic.1")
#   pScope - the scope string for logging purposes
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
def processMQTopicSettings(provider,prefix,pScope):
  _app_trace("processMQTopicSettings(%s,%s,%s)" %(provider,prefix,pScope),"entry")
  try:
    topicName = configInfo.get("%s.name" % prefix,"")
    if (not isEmpty(topicName)):
      topicId = findMQResource(provider,"MQTopic", topicName)
      if (not isEmpty(topicId)):
        # Update
        existingProps = getMQTopicProperties(topicId)
        subProps = getPropListDifferences(configInfo,prefix,existingProps,"mqjms.topic")
        resourceProps = getPropListDifferences(configInfo,"%s.propertySet.resourceProperties" % prefix,existingProps,"mqjms.topic.propertySet.resourceProperties")
        
        if (len(subProps) != 0 or len(resourceProps) != 0):
          retval = updateMQTopic(topicId, subProps, resourceProps)
          if (isEmpty(retval)):
            _app_message("Error updating MQTopic %s at %s scope" % (topicName,pScope))
          else:
            _app_message("Updated MQTopic %s at %s scope" % (topicName,pScope))
        else:
          _app_message("No need to update MQTopic %s at %s scope" % (topicName,pScope))
          
        
      else:
        # Create
        subProps = getPropList(configInfo,prefix)
        resourceProps = getPropList(configInfo,"%s.propertySet.resourceProperties" % prefix)
        
        topicId = createMQTopic(provider, topicName, subProps, resourceProps)
        if (isEmpty(topicId)):
          _app_message("Error creating MQTopic %s at %s scope" % (topicName,pScope))
          exit()
        else:
          _app_message("Created MQTopic %s at %s scope" % (topicName,pScope))
        
        
  except:
    _app_trace("Unexpected error in processMQTopicSettings","exception")
    exit()
    
  _app_trace("processMQTopicSettings()" ,"exit")


#-------------------------------------------------------------------------------
# processMQQueueSettings
#
# Process the settings for a specific queue
# 
# Parameters:
#   provider - the JMSProvider ID
#   prefix - the prefix (e.g. "app.mqjms.provider.5.queue.1")
#   pScope - the scope string for logging purposes

#-------------------------------------------------------------------------------
def processMQQueueSettings(provider,prefix,pScope):
  _app_trace("processMQQueueSettings(%s,%s,%s)" %(provider,prefix,pScope),"entry")
  try:
    queueName = configInfo.get("%s.name" % prefix,"")
    if (not isEmpty(queueName)):
      queueId = findMQResource(provider,"MQQueue", queueName)
      if (not isEmpty(queueId)):
        # Update
        existingProps = getMQQueueProperties(queueId)
        subProps = getPropListDifferences(configInfo,prefix,existingProps,"mqjms.queue")
        resourceProps = getPropListDifferences(configInfo,"%s.propertySet.resourceProperties" % prefix,existingProps,"mqjms.queue.propertySet.resourceProperties")
        
        if (len(subProps) != 0 or len(resourceProps) != 0):
          retval = updateMQQueue(queueId, subProps, resourceProps)
          if (isEmpty(retval)):
            _app_message("Error updating MQQueue %s at %s scope" % (queueName,pScope))
          else:
            _app_message("Updated MQQueue %s at %s scope" % (queueName,pScope))
        else:
          _app_message("No need to update MQQueue %s at %s scope" % (queueName,pScope))
          
        
      else:
        # Create
        subProps = getPropList(configInfo,prefix)
        resourceProps = getPropList(configInfo,"%s.propertySet.resourceProperties" % prefix)
        
        queueId = createMQQueue(provider, queueName, subProps, resourceProps)
        if (isEmpty(queueId)):
          _app_message("Error creating MQQueue %s at %s scope" % (queueName,pScope))
          exit()
        else:
          _app_message("Created MQQueue %s at %s scope" % (queueName,pScope))
        
        
  except:
    _app_trace("Unexpected error in processMQQueueSettings","exception")
    exit()
    
  _app_trace("processMQQueueSettings()" ,"exit")

#------------------------------------------------------------------------------
# processMQConnectionFactorySettings
# Process the settings for a specific connection factory. Used for all three
# types
# 
# Parameters:
#   provider - the JMSProvider ID
#   cftype - MQConnectionFactory, MQQueueConnectionFactory, or MQTopicConnectionFactory
#   prefix - the prefix (e.g. "app.mqjms.provider.5.genericConnectionFactory.1" or "app.mqjms.provider.5.queueConnectionFactory.1")
#   pScope - the scope string for logging purposes
#------------------------------------------------------------------------------
def processMQConnectionFactorySettings(provider,cftype,prefix,pScope):
  _app_trace("processMQConnectionFactorySettings(%s,%s,%s,%s)" % (provider,cftype,prefix,pScope), "entry")
  try:
    if (checkForPrefix(configInfo,prefix)):
      # We have settings to process
      cfName = configInfo.get("%s.name" % prefix,"")
      if (not isEmpty(cfName)):
        # See if this connectionFactory is already defined
        cfId = findMQConnectionFactory(provider, cftype, cfName)
        
        if (not isEmpty(cfId)):
          # This is an update operation
          needConnPool = checkForPrefix(configInfo,"%s.connectionPool" % prefix)
          needMapping = checkForPrefix(configInfo,"%s.mappingModule" % prefix)
          needSession = checkForPrefix(configInfo,"%s.sessionPool" % prefix)
          needResource = checkForPrefix(configInfo,"%s.propertySet" % prefix)
          
          existingProps = getMQConnectionFactoryProperties(cfId,cftype,needConnPool,needSession,needMapping,needResource)
          
          needUpdate = 0
          subProps = getPropListDifferences(configInfo,prefix,existingProps,"mqjms.connectionFactory")
          if (len(subProps) > 0): needUpdate = 1
            
          connPoolProps = getPropListDifferences(configInfo,"%s.connectionPool" % (prefix),existingProps,"mqjms.connectionFactory.connectionPool")
          if (len(connPoolProps) > 0): needUpdate = 1
            
          connPoolCustomProps = getPropListDifferences(configInfo,"%s.connectionPool.customProperties" % prefix, existingProps, "mqjms.connectionFactory.connectionPool.customProperties")
          if (len(connPoolCustomProps) > 0): needUpdate = 1
            
          mappingModuleProps = getPropListDifferences(configInfo,"%s.mappingModule" % (prefix),existingProps,"mqjms.connectionFactory.mappingModule")
          if (len(mappingModuleProps) > 0): needUpdate = 1
            
          sessionPoolProps = getPropListDifferences(configInfo,"%s.sessionPool" % (prefix),existingProps,"mqjms.connectionFactory.sessionPool")
          if (len(sessionPoolProps) > 0): needUpdate = 1
            
          resourceProps = getPropListDifferences(configInfo,"%s.propertySet.resourceProperties" % prefix,existingProps,"mqjms.connectionFactory.propertySet.resourceProperties")
          if (len(resourceProps) > 0): needUpdate = 1
            
          if (needUpdate):
            retval = updateMQConnectionFactory(cfId, cfName, cftype, subProps, connPoolProps, connPoolCustomProps, mappingModuleProps, sessionPoolProps, resourceProps)
            if (isEmpty(retval)):
              _app_message("Error updating %s %s at scope %s" % (cftype,cfName,pScope))
            else:
              _app_message("Updated %s %s at scope %s" % (cftype,cfName,pScope))
          else:
            _app_message("No need to update %s %s at scope %s" % (cftype,cfName,pScope))

        else:
          # This is a create operation
          subProps = getPropList(configInfo,prefix)
          connPoolProps = getPropList(configInfo,"%s.connectionPool" % (prefix))
          connPoolCustomProps = getPropList(configInfo,"%s.connectionPool.customProperties" % (prefix))
          mappingModuleProps = getPropList(configInfo,"%s.mappingModule" % (prefix))
          sessionPoolProps = getPropList(configInfo,"%s.sessionPool" % (prefix))
          resourceProps = getPropList(configInfo,"%s.propertySet.resourceProperties" % prefix)
          
          cfid = createMQConnectionFactory(provider, cfName, cftype, subProps, connPoolProps, connPoolCustomProps, mappingModuleProps, sessionPoolProps, resourceProps)
          if (isEmpty(cfid)):
            _app_message("Error creating %s %s at scope %s" % (cftype,cfName,pScope))
            exit()
          else:
            _app_message("Created %s %s at scope %s" % (cftype,cfName,pScope))
          
  except:
    _app_trace("Unexpected error in processMQConnectionFactorySettings","exception")
    exit()
    
  _app_trace("processMQConnectionFactorySettings()", "exit")
  
#enddef processMQConnectionFactorySettings

#----------------------------------------------------------------------------------------------------------------------------------------
# processMQJMSProviderComponents
#
# Process the provider settings for a specific provider and the process
# the components defined under that provider.
# 
# Parameters:
#   scope - the Scope id (Cell,Node,Server, or Cluster) to search for the
#           JMSProvider
#   pScope - a string name for the scope for logging purposes
#   pName - the name of the provider
#   providerAttrs - the attrs for the provider
#   prefix - the prefix for the provider (e.g. "app.mqjms.provider.5")
#----------------------------------------------------------------------------------------------------------------------------------------
def processMQJMSProviderComponents(scope, pScope, pName, providerAttrs, prefix):
  provider = findMQJMSProvider(scope, pName, providerAttrs)

  if isEmpty(provider):
    _app_message("Failed to find MQ JMS Provider %s at %s scope" % (pName, pScope))
    exit()
  
  # Let's see if we need to update the provider.  Supports the ability in V8
  # to disable MQ Provider support. This will only be done if the .prop or
  # .propertySet attributes are supplied
  if (checkForPrefix(configInfo,"%s.prop" % prefix)):
    existingProps = getMQProviderProperties(provider)
    
    baseProps = getPropListDifferences(configInfo, prefix,existingProps,"mqjms.provider")
    resourceProps = getPropListDifferences(configInfo,"%s.propertySet.resourceProperties" % prefix,existingProps,"mqjms.provider.propertySet.resourceProperties")
    if (len(baseProps) > 0 or len(resourceProps) > 0):
      retval = updateMQProvider(provider, baseProps, resourceProps)
      if (isEmpty(retval)):
        _app_message("Failed to update MQ JMSProvider settings at %s scope" % pScope)
      else:
        _app_message("Updated MQ JMSProvider settings at %s scope" % pScope)
    else:
      _app_message("No need to update provider-level settings of MQ JMSProvider at %s scope" % pScope)
  
  # Let's see if we need to update the resource adapter (V7 onwards)
  if (checkForPrefix(configInfo,"%s.resourceAdapter" % prefix)):
    resourceAdapterId = findMQResourceAdapter(scope)
    if (isEmpty(resourceAdapterId)):
      _app_message("Unable to find WebSphere MQ resource adapter at scope %s" % pScope)
      exit()
    existingAdapterProps = getMQResourceAdapterProperties(resourceAdapterId)
    resourceProps = getPropListDifferences(configInfo,"%s.resourceAdapter.propertySet.resourceProperties" % prefix,existingAdapterProps,"mqjms.provider.resourceAdapter.propertySet.resourceProperties")
    if (len(resourceProps) > 0):
      retval = updateMQResourceAdapter(resourceAdapterId,resourceProps)
      if (isEmpty(retval)):
        _app_message("Error updating WebSphere MQ resource adapter at scope %s" % pScope)
        exit()
      else:
        _app_message("Updated WebSphere MQ resource adapter at scope %s" % pScope)
    else: 
      _app_message("No need to update WebSphere MQ resource adapter at scope %s" % pScope)
        

  #_app_message("Found MQ JMS Provider %s at %s scope" % (pName, pScope))

  if configInfo.has_key("%s.queueConnectionFactory.count" % prefix):
    for jpidx in range(1, int(configInfo["%s.queueConnectionFactory.count" % (prefix)]) + 1):
      
      factoryPrefix = "%s.queueConnectionFactory.%d" % (prefix, jpidx)
      processMQConnectionFactorySettings(provider,"MQQueueConnectionFactory",factoryPrefix,pScope)
  
  if configInfo.has_key("%s.topicConnectionFactory.count" % prefix):
    for jpidx in range(1, int(configInfo["%s.topicConnectionFactory.count" % (prefix)]) + 1):
      
      factoryPrefix = "%s.topicConnectionFactory.%d" % (prefix, jpidx)
      processMQConnectionFactorySettings(provider,"MQTopicConnectionFactory",factoryPrefix,pScope)

  if configInfo.has_key("%s.genericConnectionFactory.count" % prefix):
    for jpidx in range(1, int(configInfo["%s.genericConnectionFactory.count" % (prefix)]) + 1):
      
      factoryPrefix = "%s.genericConnectionFactory.%d" % (prefix, jpidx)
      processMQConnectionFactorySettings(provider,"MQConnectionFactory",factoryPrefix,pScope)

  if configInfo.has_key("%s.queue.count" % prefix):
    for jpidx in range(1, int(configInfo["%s.queue.count" % (prefix)]) + 1):
      
      queuePrefix = "%s.queue.%d" % (prefix, jpidx)
      processMQQueueSettings(provider,queuePrefix,pScope)

  if configInfo.has_key("%s.topic.count" % prefix):
    for jpidx in range(1, int(configInfo["%s.topic.count" % (prefix)]) + 1):
      
      topicPrefix = "%s.topic.%d" % (prefix, jpidx)
      processMQTopicSettings(provider,topicPrefix,pScope)

  if configInfo.has_key("%s.activationSpec.count" % prefix):
    for jpidx in range(1, int(configInfo["%s.activationSpec.count" % (prefix)]) + 1):
      
      actSpecPrefix = "%s.activationSpec.%d" % (prefix, jpidx)
      processMQActivationSpecSettings(provider,actSpecPrefix,pScope)


      
  #if configInfo.has_key("%s.queue.count" % prefix):
  #  for jpidx in range(1, int(configInfo["%s.queue.count" % (prefix)]) + 1):
  #  
  #    _app_message("Getting prop list for %s.queue.%d" % (prefix,jpidx))
  #    subProps = getPropList(configInfo,"%s.queue.%d" % (prefix,jpidx))
  #    
  #    
  #    createMQQueue(scope, provider, subProps)
  #else:
  #  _app_message("No queues factory found for %s" % prefix)


#-----------------------------------------------------------------------------------------------------------------------------------------
# @JJM
# processMQJMSProvider - Process the settings for a specific JMS provider prefix. 
# This method determines the scope of the provider and the calls the function that
# does all all the processing for the providers
#
# Parameters:
#   prefix - The property prefix for the provider (e.g. "app.mqjms.provider.5")
#
#-----------------------------------------------------------------------------------------------------------------------------------------
def processMQJMSProvider(prefix):
  #  Create JMS Provider
  
  pCluster = configInfo.get("%s.cluster"%prefix,"")
  pNode   = configInfo.get("%s.node" % (prefix),"")
  pServer = configInfo.get("%s.server" % (prefix),"")
  
  pName = configInfo.get("%s.name" % (prefix),"")
  
  if (not isEmpty(pName)):

    #  JMS Provider properties
    providerAttrs = []
    subProps = getPropList(configInfo, "%s" % (prefix))
    if (subProps.size() > 0):
      providerAttrs = []
      for key in subProps.keys():
        providerAttrs.append([key,subProps[key]])
  
    if isEmpty(pCluster) and isEmpty(pNode) and isEmpty(pServer):
      pScope = "cell"
      cells = AdminConfig.list("Cell").split(progInfo['line.separator'])
      for cell in cells:
        processMQJMSProviderComponents(cell, pScope, pName, providerAttrs, prefix)
        
    else:
      if (not isEmpty(pCluster)) and isEmpty(pNode) and isEmpty(pServer): 
        pScope = "cluster %s" % pCluster
        cluster = AdminConfig.getid("/ServerCluster:%s" % pCluster)
        processMQJMSProviderComponents(cluster, pScope, pName, providerAttrs, prefix)
        
      else:
        if isEmpty(pCluster) and (not isEmpty(pNode)) and isEmpty(pServer): 
          pScope = "node %s" % pNode
          node = AdminConfig.getid("/Node:%s" % pNode)
          processMQJMSProviderComponents(node, pScope, pName, providerAttrs, prefix)
        else:
          if isEmpty(pCluster) and (not isEmpty(pNode)) and (not isEmpty(pServer)): 
            pScope = "server %s %s" % (pNode,pServer)
            server = AdminConfig.getid("/Node:%s/Server:%s" %( pNode, pServer))
            processMQJMSProviderComponents(server, pScope, pName, providerAttrs, prefix)
            
  #end if providerName supplied


#------------------------------------------------------------------------------------------------------------
# JJM
# processMQJMS - Processes the MQ JMS Provider settings that have been loaded
# into the configInfo object
#
#------------------------------------------------------------------------------------------------------------
def processMQJMS():
  _app_trace("processMQJMS()","entry")
  try:
    if configInfo.has_key("app.mqjms.provider.count"):
      for jpidx in range(1, int(configInfo["app.mqjms.provider.count"]) + 1):
        prefix = "app.mqjms.provider.%d" % (jpidx)
        processMQJMSProvider(prefix)
  except:
    _app_trace("Unexpected error in processMQJMS","exception")
    exit()
    
  _app_trace("processMQJMS()","exit")
