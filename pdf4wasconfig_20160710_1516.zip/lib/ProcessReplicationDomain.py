######################################################################################
# ProcessReplicationDomain.py
#
# This module contains the functions that pull DataReplicationDomain properties from 
# the the global configInfo dictionary and creates/updates replication domain definitions.
#
# Primary function:
#   processReplicationDomain
#
# Syntax Overview:
#
# What follows is an example of the configuration property syntax.  We only support
# settings for modern Data Replication Domain and do not have supported for deprecated
# domains created in earlier releases.
#
#
# app.replicationDomain.1.name = <name>
# app.replicationDomain.1.defaultDataReplicationSettings.prop.encryptionKeyValue = <key value>
# app.replicationDomain.1.defaultDataReplicationSettings.prop.encryptionType = <ENUM(DES, TRIPLE_DES, NONE)>
# app.replicationDomain.1.defaultDataReplicationSettings.prop.numberOfReplicas = <-1,1, or n>
# app.replicationDomain.1.defaultDataReplicationSettings.prop.requestTimeout = <timeout value>
# app.replicationDomain.1.defaultDataReplicationSettings.prop.useSSL = false <Not sure if used>
# ...
# ...
# app.replicationDomain.count = <count>
######################################################################################



#-------------------------------------------------------------------------------------
# processNewReplicationDomain
#
# Process the settings for a new data replication domain configuration.
#-------------------------------------------------------------------------------------
def processNewReplicationDomain(domainName, prefix):

	global configInfo
	
	_app_trace("processNewReplicationDomain(%s,%s)" % (domainName, prefix),"entry")
	
	try:
	
			dataReplicationProps = getPropList(configInfo, "%s.defaultDataReplicationSettings" % prefix)
			
			domainId = createReplicationDomain(domainName, dataReplicationProps)
			
			if (isEmpty(domainId)):
					_app_message("Error creating replication domain %s" % (domainName))
					exit()
			else:
					_app_message("Created Data Replication Domain %s" % (domainName))
	
	except:
			_app_trace("Unexpected error processing new replication domain","exception")
			_app_message("Unexpected error processing new replication domain")
			exit()
	
	_app_trace("processNewReplicationDomain()" ,"exit")


#-------------------------------------------------------------------------------------
# processExistingReplicationDomain
#
# Process the settings in the configInfo
#-------------------------------------------------------------------------------------
def processExistingReplicationDomain(domainName, domainId, prefix):

	global configInfo
	
	_app_trace("processExistingReplicationDomain(%s,%s,%s)" % (domainName,domainId, prefix),"entry")
	
	try:
			# Get the properties for the existing configuration
			existingProps = getReplicationDomainProperties(domainId)
			if (existingProps == None):
					_app_message("Error fetching existing DataReplicationDomain settings for %s" % domainName)
					exit()
			
			# See if there is a difference in data replication settings
			settingsProps = getPropListDifferences(configInfo, "%s.defaultDataReplicationSettings" % prefix, existingProps, "replicationDomain.defaultDataReplicationSettings")
			if (settingsProps.size() == 0):
					_app_message("No updates required for Data Replication Domain %s" % domainName)
			else:
					retval = updateReplicationDomain(domainName, domainId,settingsProps)
					if (retval == None):
							_app_message("Error updating Data Replication Domain %s" % domainName)
							exit()
					else:
							_app_message("Updated Data Replication Domain %s" % domainName)
	
	except:
			_app_trace("Unexpected error processing existing replication domain","exception")
			_app_message("Unexpected error processing existing replication domain")
			exit()
	
	_app_trace("processExistingReplicationDomain()" ,"exit")

#-------------------------------------------------------------------------------------
# processReplicationDomain
#-------------------------------------------------------------------------------------
def processReplicationDomain():
	
	_app_trace("processReplicationDomain()","entry")
	
	global configInfo
	
	try:
	
		domainCount = int(configInfo.get("app.replicationDomain.count","0"))
		if (domainCount == 0):
				_app_message("Skipping DataReplicationDomain...")
		
		else:
				for idx in range(1,domainCount+1):
						prefix = "app.replicationDomain.%d" % idx
						
						domainName = configInfo.get("%s.name" % prefix,"")
						if (isEmpty(domainName)):
								# Most likely a partial def
								continue
						
						# See if this domain already exists
						domainId = findReplicationDomain(domainName)
						if (isEmpty(domainId)):
								# Process new settings
								processNewReplicationDomain(domainName, prefix)
						
						else:
								# Process existing
								processExistingReplicationDomain(domainName, domainId, prefix)
	
	except:
			_app_trace("Unexpected error processing ReplicationDomain settings","exception")
			_app_message("Unexpected error processing ReplicationDomain settings")
			exit()
	
	_app_trace("processReplicationDomain()","exit")