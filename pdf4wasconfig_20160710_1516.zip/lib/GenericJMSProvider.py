
#----------------------------------------------
# GenericJMSProvider.py
#
# This module contains CRUD methods for manipulating generic JMSProviders and resource contained therein
#
#



def createGenericJMSProvider(providerName, clusterName, nodeName, serverName, baseProperties, resourceProperties=None):
  _app_trace("createGenericJMSProvider(%s,%s,%s,%s,%s,%s)" % (providerName, clusterName, nodeName, serverName, baseProperties, resourceProperties),"entry")
  
  providerId = None
 
  try: 
    parentScopeId = getScopeId(clusterName, nodeName, serverName)
  
    attrs = [ [ "name",providerName  ] ]
  
    for key in baseProperties.keys():
        val = baseProperties.get(key)
        if (not val):
          val = ''
        
        attrs.append([key,val])
    
    _app_trace('About to call AdminConfig.create("JMSProvider",%s,%s)' %( parentScopeId,attrs))
    providerId = AdminConfig.create("JMSProvider",parentScopeId,attrs)
    if (not providerId):
      raise StandardError("Failed to create JMSProvider %s" % providerName)
    
    if (resourceProperties and len(resourceProperties) > 0):
      propertySetId = AdminConfig.showAttribute(providerId,"propertySet")
      if (not propertySetId):
        propertySetId = AdminConfig.create("J2EEResourcePropertySet", providerId,[])
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProperties)    
      if (errmsg):
        raise StandardError("Problem updating resource properties: %s" % errmsg)
  

  except:
    _app_trace("Unexpected error in createGenericJMSProvider","exception")
    raise
    
  _app_trace("createGenericJMSProvider(retval=%s)" % providerId, "exit")
  return providerId


def updateGenericJMSProvider(providerId, baseProperties=None, resourceProperties=None):
  _app_trace("updateGenericJMSProvider(%s,%s,%s)" %( providerId, baseProperties, resourceProperties),"entry")
  try:
    if (baseProperties and len(baseProperties) > 0):
      # Convert this to a list
      attrs = []
      for key in baseProperties.keys():
        val = baseProperties.get(key)
        if (not val):
          val = ''
       
        attrs.append( [key,val]) 
        if (modifyObject(providerId,attrs)):
          raise StandardError("Problem updatign %s with %s" % (providerId,attrs))
          
    if (resourceProperties and len(resourceProperties) > 0):
      propertySetId = AdminConfig.showAttribute(providerId,"propertySet")
      if (not propertySetId):
        propertySetId = AdminConfig.create("J2EEResourcePropertySet", providerId,[])
        
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProperties)    
      if (errmsg):
        raise StandardError("Problem updating resource properties: %s" % errmsg)
    
  except:
    _app_trace("Unexpected error in updateGenericJMSProvider","exception")
    raise
  
  
  
  _app_trace("updateGenericJMSProvider()","exit")


# See if the specified provider exists and if so, return the configuration
def findGenericJMSProvider(providerName,clusterName,nodeName,serverName):
  _app_trace("findGenericJMSProvider(%s,%s,%s,%s)" %(providerName,clusterName,nodeName,serverName),"entry")
  
  providerId = None
  try:
    if (not clusterName and not nodeName and not serverName):
      # Cell Scope
      providerId = AdminConfig.getid("/Cell:%s/JMSProvider:%s/" % (AdminControl.getCell(),providerName))
    elif (clusterName):
      # Cluster Scope
      providerId = AdminConfig.getid("/ServerCluster:%s/JMSProvider:%s/" % (clusterName,providerName))
    elif (nodeName and serverName):
      # Server Scope
      providerId = AdminConfig.getid("/Node:%s/Server:%s/JMSProvider:%s/" % (nodeName, serverName,providerName))
    else:
      providerId = AdminConfig.getid("/Node:%s/JMSProvider:%s/" % (nodeName,providerName))
  except:
    _app_trace("Unexpected error in findGenericJMSProvider","exception")
    raise
  
  _app_trace("findGenericJMSProvider(retval=%s)" % providerId,"exit")
  return providerId

# Return a dictionary of the base and base resource properties for the specified JMS provider  
def getGenericJMSProviderProperties(providerId):
  _app_trace("getGenericJMSProviderProperties(%s)" % providerId,"entry")
  retval = {}
  try:
    
    collectSimpleProperties(retval, "jmsprovider.prop",providerId)
    collectResourceProperties(retval,providerId,"propertySet", "jmsprovider.propertySet")
  except:
    _app_trace("Unexpected error in getGenericJMSProviderProperties","exception")
    raise
  
  _app_trace("getGenericJMSProviderProperties()","exit")
  return retval



#---------------------------------------------------
# Factory methods


# createGenericJMSProviderFactory
def createGenericJMSProviderFactory(factoryName,providerId,baseProps,customProps,resourceProps,connectionPoolProps,connectionPoolCustomProps,sessionPoolProps, sessionPoolCustomProps, mappingProps):
  _app_trace("createGenericJMSProviderFactory(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)" % (factoryName,providerId,baseProps,customProps,resourceProps,connectionPoolProps,connectionPoolCustomProps,sessionPoolProps, sessionPoolCustomProps, mappingProps),"entry")
  factoryId = None
  try:
    attrs = [ ["name",factoryName]]
    for key in baseProps.keys():
      val = baseProps[key]
      if (not val):
        val = ""
      attrs.append([key,val])
    
    # Create the factory
    factoryId = AdminConfig.create("GenericJMSConnectionFactory",providerId,attrs)
    if (not factoryId):
      raise StandardError("Unable to create GenericJMSConnectionFactory %s" % factoryName)
      
    # Custom properties for the factory
    if (customProps and len(customProps) > 0):
      errmsg = updateCustomProperties(factoryId, "properties", "Property", customProps)
      if (errmsg):
        raise StandardError("Unable to update custom properties for %s: %s" % (factoryName, errmsg))
    
    # Resource properties for the factory
    if (resourceProps and len(resourceProps) > 0):
      # Update resource properties for the factory
      propertySetId = AdminConfig.showAttribute(factoryId,"propertySet")
      if (not propertySetId):
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",factoryId,[])
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (errmsg):
        raise StandardError("Unable to create resource properties for %s: %s" % (factoryName, errmsg))
        
    connectionPoolId = None
    if ((connectionPoolProps and len(connectionPoolProps) > 0) or
        (connectionPoolCustomProps and len(connectionPoolCustomProps) > 0)):
          # Get connection pool ID
          connectionPoolId = AdminConfig.showAttribute(factoryId,"connectionPool")
          if (not connectionPoolId):
            connectionPoolId = AdminConfig.create("ConnectionPool",factoryId,[],"connectionPool")
          
          if (connectionPoolProps and len(connectionPoolProps) > 0):
            attrs = []
            for key in connectionPoolProps.keys():
              val = connectionPoolProps[key]
              if (not val):
                val = ""
              attrs.append([key,val])
            
            if (modifyObject(connectionPoolId,attrs)):
              raise StandardError("Unable to configure connection pool for %s" % factoryName)
          
          if (connectionPoolCustomProps and len(connectionPoolCustomProps) > 0):
            # Update the custom proeprties
            errmsg = updateCustomProperties(connectionPoolId,"properties","Property",connectionPoolCustomProps)
            if (errmsg):
              raise StandardError("Unable to update custom properties for connection pool of factory %s" % factoryName)

    sessionPoolId = None
    if ((sessionPoolProps and len(sessionPoolProps) > 0) or
        (sessionPoolCustomProps and len(sessionPoolCustomProps) > 0)):
          # Get session pool ID
          sessionPoolId = AdminConfig.showAttribute(factoryId,"sessionPool")
          if (not sessionPoolId):
            sessionPoolId = AdminConfig.create("ConnectionPool",factoryId,[],"sessionPool")
          
          if (sessionPoolProps and len(sessionPoolProps) > 0):
            attrs = []
            for key in sessionPoolProps.keys():
              val = sessionPoolProps[key]
              if (not val):
                val = ""
              attrs.append([key,val])
            
            if (modifyObject(sessionPoolId,attrs)):
              raise StandardError("Unable to configure session pool for %s" % factoryName)
          
          if (sessionPoolCustomProps and len(sessionPoolCustomProps) > 0):
            # Update the custom proeprties
            errmsg = updateCustomProperties(sessionPoolId,"properties","Property",sessionPoolCustomProps)
            if (errmsg):
              raise StandardError("Unable to update custom properties for session pool of factory %s" % factoryName)
              
    # Mapping settings
    if (mappingProps and len(mappingProps) > 0):
      mappingId = AdminConfig.showAttribute(factoryId,"mapping")
      if (not mappingId):
        mappingId = AdminConfig.create("MappingModule",factoryId,[])
      
      attrs = []
      for key in mappingProps.keys():
        val = mappingProps[key]
        if (not val):
          val = ""
        attrs.append([key,val])
      
      if (modifyObject(mappingId,attrs)):
        raise StandardError("Unable to update MappingModule for factory %s" % factoryName)  
    
  except:
    _app_trace("Unexpected error in createGenericJMSProviderFactory","exception")
    raise
    
  _app_trace("createGenericJMSProviderFactory(retval=%s)" % factoryId,"exit")
  return factoryId
  
def updateGenericJMSProviderFactory(factoryName,factoryId,baseProps,customProps,resourceProps,connectionPoolProps,connectionPoolCustomProps,sessionPoolProps, sessionPoolCustomProps, mappingProps):
  _app_trace("updateGenericJMSProviderFactory(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)" % (factoryName,factoryId,baseProps,customProps,resourceProps,connectionPoolProps,connectionPoolCustomProps,sessionPoolProps, sessionPoolCustomProps, mappingProps),"entry")
  
  try:
    
    if (baseProps and len(baseProps) > 0):
      attrs = []
      for key in baseProps.keys():
        val = baseProps[key]
        if (not val):
          val = ""
        attrs.append([key,val])
    
      # modify the factory
      if (modifyObject(factoryId,attrs)):
        raise StandardError("Unable to modify GenericJMSConnectionFactory %s" % factoryName)
      
    # Custom properties for the factory
    if (customProps and len(customProps) > 0):
      errmsg = updateCustomProperties(factoryId, "properties", "Property", customProps)
      if (errmsg):
        raise StandardError("Unable to update custom properties for %s: %s" % (factoryName, errmsg))
    
    # Resource properties for the factory
    if (resourceProps and len(resourceProps) > 0):
      # Update resource properties for the factory
      propertySetId = AdminConfig.showAttribute(factoryId,"propertySet")
      if (not propertySetId):
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",factoryId,[])
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (errmsg):
        raise StandardError("Unable to create resource properties for %s: %s" % (factoryName, errmsg))
        
    connectionPoolId = None
    if ((connectionPoolProps and len(connectionPoolProps) > 0) or
        (connectionPoolCustomProps and len(connectionPoolCustomProps) > 0)):
          # Get connection pool ID
          connectionPoolId = AdminConfig.showAttribute(factoryId,"connectionPool")
          if (not connectionPoolId):
            connectionPoolId = AdminConfig.create("ConnectionPool",factoryId,[],"connectionPool")
          
          if (connectionPoolProps and len(connectionPoolProps) > 0):
            attrs = []
            for key in connectionPoolProps.keys():
              val = connectionPoolProps[key]
              if (not val):
                val = ""
              attrs.append([key,val])
            
            if (modifyObject(connectionPoolId,attrs)):
              raise StandardError("Unable to configure connection pool for %s" % factoryName)
          
          if (connectionPoolCustomProps and len(connectionPoolCustomProps) > 0):
            # Update the custom proeprties
            errmsg = updateCustomProperties(connectionPoolId,"properties","Property",connectionPoolCustomProps)
            if (errmsg):
              raise StandardError("Unable to update custom properties for connection pool of factory %s" % factoryName)

    sessionPoolId = None
    if ((sessionPoolProps and len(sessionPoolProps) > 0) or
        (sessionPoolCustomProps and len(sessionPoolCustomProps) > 0)):
          # Get session pool ID
          sessionPoolId = AdminConfig.showAttribute(factoryId,"sessionPool")
          if (not sessionPoolId):
            sessionPoolId = AdminConfig.create("ConnectionPool",factoryId,[],"sessionPool")
          
          if (sessionPoolProps and len(sessionPoolProps) > 0):
            attrs = []
            for key in sessionPoolProps.keys():
              val = sessionPoolProps[key]
              if (not val):
                val = ""
              attrs.append([key,val])
            
            if (modifyObject(sessionPoolId,attrs)):
              raise StandardError("Unable to configure session pool for %s" % factoryName)
          
          if (sessionPoolCustomProps and len(sessionPoolCustomProps) > 0):
            # Update the custom proeprties
            errmsg = updateCustomProperties(sessionPoolId,"properties","Property",sessionPoolCustomProps)
            if (errmsg):
              raise StandardError("Unable to update custom properties for session pool of factory %s" % factoryName)
              
    # Mapping settings
    if (mappingProps and len(mappingProps) > 0):
      mappingId = AdminConfig.showAttribute(factoryId,"mapping")
      if (not mappingId):
        mappingId = AdminConfig.create("MappingModule",factoryId,[])
      
      attrs = []
      for key in mappingProps.keys():
        val = mappingProps[key]
        if (not val):
          val = ""
        attrs.append([key,val])
      
      if (modifyObject(mappingId,attrs)):
        raise StandardError("Unable to update MappingModule for factory %s" % factoryName)  
    
  except:
    _app_trace("Unexpected error in updateGenericJMSProviderFactory","exception")
    raise
    
  _app_trace("updateGenericJMSProviderFactory(retval=%s)" % factoryId,"exit")
  return factoryId


# See if the specified JMS Connection Factory exists and if so, return the configuration ID
def findGenericJMSProviderConnectionFactory(providerName,connectionFactoryName,clusterName,nodeName,serverName):
  _app_trace("findGenericJMSProviderConnectionFactory(%s,%s,%s,%s,%s)" %(providerName,connectionFactoryName,clusterName,nodeName,serverName),"entry")
  
  factoryId = None
  try:
    if (not clusterName and not nodeName and not serverName):
      # Cell Scope
      factoryId = AdminConfig.getid("/Cell:%s/JMSProvider:%s/GenericJMSConnectionFactory:%s/" % (AdminControl.getCell(),providerName,connectionFactoryName))
    elif (clusterName):
      # Cluster Scope
      factoryId = AdminConfig.getid("/ServerCluster:%s/JMSProvider:%s/GenericJMSConnectionFactory:%s/" % (clusterName,providerName,connectionFactoryName))
    elif (nodeName and serverName):
      # Server Scope
      factoryId = AdminConfig.getid("/Node:%s/Server:%s/JMSProvider:%s/GenericJMSConnectionFactory:%s/" % (nodeName, serverName,providerName,connectionFactoryName))
    else:
      factoryId = AdminConfig.getid("/Node:%s/JMSProvider:%s/GenericJMSConnectionFactory:%s/" % (nodeName,providerName,connectionFactoryName))
  except:
    _app_trace("Unexpected error in findGenericJMSProviderConnectionFactory","exception")
    raise
  
  _app_trace("findGenericJMSProviderConnectionFactory(retval=%s)" % factoryId,"exit")
  return factoryId
  
  
def getGenericJMSProviderConnectionFactoryProperties(factoryId):
  _app_trace("getGenericJMSProviderConnectionFactoryProperties(%s)" % (factoryId),"entry")
  retval = {}
  try:
    idDict = {}
    collectSimpleProperties(retval, "jmsfactory.prop",factoryId,[],idDict)
    collectResourceProperties(retval,factoryId,"propertySet", "jmsfactory.propertySet")
    collectCustomProperties(retval,"jmsfactory.customProperties", factoryId, "properties")
    
    connPoolId = idDict.get("jmsfactory.prop.connectionPool")
    if (connPoolId):
      collectSimpleProperties(retval, "jmsfactory.connectionPool.prop",connPoolId,[])
      collectCustomProperties(retval,"jmsfactory.connectionPool.customProperties", connPoolId, "properties")
      
    mappingId = idDict.get("jmsfactory.prop.mapping")
    if (mappingId):
      collectSimpleProperties(retval, "jmsfactory.mapping.prop",mappingId,[])
      

    sessionPoolId = idDict.get("jmsfactory.prop.sessionPool")
    if (sessionPoolId):
      collectSimpleProperties(retval, "jmsfactory.sessionPool.prop",sessionPoolId,[])
      collectCustomProperties(retval,"jmsfactory.sessionPool.customProperties", sessionPoolId, "properties")    
      
  except:
    _app_trace("Unexpected error in getGenericJMSProviderConnectionFactoryProperties","exception")
    raise
  
  _app_trace("getGenericJMSProviderConnectionFactoryProperties()","exit")
  return retval
  
  
  
  
#------------------------------
# Destination methods
#------------------------------
def createGenericJMSProviderDestination(providerId,destinationName,baseProps,resourceProps):
  _app_trace("createGenericJMSProviderDestination(%s,%s,%s,%s)" % (providerId,destinationName,baseProps,resourceProps),"entry")
  destinationId = None
  try:
    attrs = [["name",destinationName]]
    if (baseProps and len(baseProps) > 0):
      for key in baseProps.keys():
        val = baseProps[key]
        if (not val):
          val = ""
        attrs.append([key,val])
    
    # Create the destination
    _app_trace('About to call AdminConfig.create("GenericJMSDestination",%s,%s)' % (providerId,attrs))
    destinationId = AdminConfig.create("GenericJMSDestination",providerId,attrs)
    
    # Resource properties for the factory
    if (resourceProps and len(resourceProps) > 0):
      # Update resource properties for the factory
      propertySetId = AdminConfig.showAttribute(destinationId,"propertySet")
      if (not propertySetId):
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",destinationId,[])
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (errmsg):
        raise StandardError("Unable to create resource properties for %s: %s" % (destinationName, errmsg))
    
  except:
    _app_trace("Unexpected error in createGenericJMSProviderDestination","exception")
    raise
    
  _app_trace("createGenericJMSProviderDestination()","exit")
  return destinationId


def modifyGenericJMSProviderDestination(destinationId,destinationName,baseProps,resourceProps):
  _app_trace("modifyGenericJMSProviderDestination(%s,%s,%s,%s)" % (destinationId,destinationName,baseProps,resourceProps),"entry")
  try:
    if (baseProps and len(baseProps) > 0):
      attrs = []
      for key in baseProps.keys():
        val = baseProps[key]
        if (not val):
          val = ""
        attrs.append([key,val])
    
      # modify the factory
      if (modifyObject(destinationId,attrs)):
        raise StandardError("Unable to modify GenericJMSDestination %s" % destinationName)
      
    
    # Resource properties for the factory
    if (resourceProps and len(resourceProps) > 0):
      # Update resource properties for the factory
      propertySetId = AdminConfig.showAttribute(destinationId,"propertySet")
      if (not propertySetId):
        propertySetId = AdminConfig.create("J2EEResourcePropertySet",destinationId,[])
      errmsg = updateCustomProperties(propertySetId, "resourceProperties", "J2EEResourceProperty", resourceProps)
      if (errmsg):
        raise StandardError("Unable to create resource properties for %s: %s" % (destinationName, errmsg))
    
  except:
    _app_trace("Unexpected error in modifyGenericJMSProviderDestination","exception")
    raise
    
  _app_trace("modifyGenericJMSProviderDestination()","exit")

# See if the specified JMS Connection Factory exists and if so, return the configuration ID
def findGenericJMSProviderDestination(providerName,destinationName,clusterName,nodeName,serverName):
  _app_trace("findGenericJMSProviderConnectionFactory(%s,%s,%s,%s,%s)" %(providerName,destinationName,clusterName,nodeName,serverName),"entry")
  
  factoryId = None
  try:
    if (not clusterName and not nodeName and not serverName):
      # Cell Scope
      factoryId = AdminConfig.getid("/Cell:%s/JMSProvider:%s/GenericJMSDestination:%s/" % (AdminControl.getCell(),providerName,destinationName))
    elif (clusterName):
      # Cluster Scope
      factoryId = AdminConfig.getid("/ServerCluster:%s/JMSProvider:%s/GenericJMSDestination:%s/" % (clusterName,providerName,destinationName))
    elif (nodeName and serverName):
      # Server Scope
      factoryId = AdminConfig.getid("/Node:%s/Server:%s/JMSProvider:%s/GenericJMSDestination:%s/" % (nodeName, serverName,providerName,destinationName))
    else:
      factoryId = AdminConfig.getid("/Node:%s/JMSProvider:%s/GenericJMSDestination:%s/" % (nodeName,providerName,destinationName))
  except:
    _app_trace("Unexpected error in findGenericJMSProviderConnectionFactory","exception")
    raise
  
  _app_trace("findGenericJMSProviderConnectionFactory(retval=%s)" % factoryId,"exit")
  return factoryId
  
#
def getGenericJMSProviderDestinationProperties(destinationId):
  retval = {}
  _app_trace("getGenericJMSProviderDestinationProperties(%s)" % (destinationId),"entry")
  try:
    collectSimpleProperties(retval, "jmsdestination.prop",destinationId)
    collectResourceProperties(retval,destinationId,"propertySet", "jmsdestination.propertySet")
    
  except:
    _app_trace("Unexpected exception in getGenericJMSProviderDestinationProperties","exception")
    raise
   
  _app_trace("getGenericJMSProviderDestinationProperties()","exit")
  return retval

