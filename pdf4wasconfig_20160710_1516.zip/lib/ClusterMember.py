##########################################################################
# File Name:    ClusterMember.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere cluster members
#
#               createClusterMember
#               deleteClusterMember
#               listClusterMembers
# 
#               checkForExistingClusterMember
#
##########################################################################

global AdminTask

##########################################################################
#
# FUNCTION:
#    createClusterMember: Creates a Cluster Member
#
# SYNTAX:
#    createClusterMember cluster, memberNode, memberName, (template | templateNode, templateServer)
#
# PARAMETERS:
#    cluster		-	Name of cluster
#    memberNode		-	The name of the node where the cluster member will be created
#    memberName		-	Name of cluster member
#    startingPort	-	The port to start at for all ports for this app server
#				If empty, then ports allocated by WebSphere
#	For first members in clusters only:

#    template		- 	Name of ClusterMember template to use (defaults
#				to "default" if first member
#				OR
#    templateNode  	-
#    templateServer	-	Name of Node/Server to use as template if first member
#    resourcesScope - V6.1 onwards
#
#				Use AdminConfig.listTemplates("ClusterMember")
#				for a complete list of templates
#
# USAGE NOTES:
#    Creates a Cluster Member at templateNode.  If this is the first member,
#    uses either a template or a templateNode/templateServer as the template
#    
#
# RETURNS:
# RETURNS:
#    ObjID	Object ID of new cluster member
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addClusterMember(cluster, memberNode, memberName, startingPort = None, template = "default", templateNode = None, templateServer = None, memberWeight=None,resourcesScope=None,keepHostNames=0):
	createClusterMember(cluster, memberName, memberNode, startingPort, template, templateNode, templateServer, memberWeight,resourcesScope,keepHostNames)

def createClusterMember(cluster, memberNode, memberName, startingPort = None, template = "default", templateNode = None, templateServer = None, memberWeight=None, vhost=None,resourcesScope=None,keepHostNames=0):
  
  global progInfo
  retval = None

  try:
    traceStr = "createClusterMember(%s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%d)" % (cluster, memberNode, memberName, startingPort, template, templateNode, templateServer, memberWeight,vhost,resourcesScope,keepHostNames)
    _app_trace(traceStr, "entry") 
    
    configID = "/ServerCluster:%s/" % (cluster)
    
    # Check function parameters
    if isEmpty(memberName) or isEmpty(cluster) or isEmpty(memberNode):
      raise StandardError("Cluster, member name or member node not specified")
    
    if not objectExists("ServerCluster", None, cluster):
      raise StandardError("Cluster %s does not exist" % (cluster))
    
    if not objectExists("Node", None, memberNode):
      raise StandardError("Node %s does not exist" % (memberNode))
    
    if objectExists("ClusterMember", configID, memberName):
      raise StandardError("Cluster Member %s already exists on cluster %s" % (memberName, cluster))

    
    
    nodeid = AdminConfig.getid("/Node:"+memberNode+"/")

    # If this cluster has no members then it is necessary to specify a template for
    # the first member, either a template from AdminConfig.listTemplates or
    # use an existing app templateServer as the template
    clusterID = AdminConfig.getid(configID)
    attrs = AdminConfig.showAttribute(clusterID, "members")


    # @JJM - Major changes on use of templates
    if isEmpty(attrs):

      if isEmpty(template) and isEmpty(templateNode) and isEmpty(templateServer):
        _app_message("No template specified for first cluster member of cluster %s, searching for default" % (cluster))
        #raise StandardError("Cluster %s has no members, template for first member not specified" % (cluster))
        # Dynamically determine the cluster template name
        searchName = "templates/clusters/%s/servers" % (cluster)
        templateIds = AdminConfig.listTemplates("Server",searchName)
        templateList = wsadminToList(templateIds)
        if (len(templateList) == 0):
            searchName = "APPLICATION_SERVER/servers/default|server.xml"
            templateIds = AdminConfig.listTemplates("Server",searchName)
            templateList = wsadminToList(templateIds)
        for templateId in templateList:
            template = AdminConfig.showAttribute(templateId, "name")
            _app_message("Default found. Cluster template %s is using default template %s (%s)" % (cluster, template,templateId))
            break
        
        if (isEmpty(template)):
            template = "default"
            _app_message("No templates found. Cluster template %s is using default template name: %s" % (cluster, template))
      
      if not isEmpty(template) and (not isEmpty(templateNode) or not isEmpty(templateServer)):
        raise StandardError("Template and existing templateNode/templateServer both specified, only 1 can be used")

      
      
      if isEmpty(template):
        _app_trace("Using existing application templateServer %s on templateNode %s as template for first member" % (templateServer, templateNode))
        
        #_app_trace("Issuing command: AdminTask.createClusterMember(['-clusterName', %s, '-memberConfig', ['-memberNode', %, '-memberName', %s], '-firstMember', ['-templateServerNode', %s, '-templateServerName', %s]])" % (cluster, memberNode, memberName, templateNode, templateServer) )
        # Invoke command using Jython list syntax
        memconfig = ['-memberNode', memberNode, '-memberName', memberName]
        fmconfig = ['-templateServerNode', templateNode, '-templateServerName', templateServer]
        cargs = ['-clusterName', cluster, '-memberConfig', memconfig, '-firstMember', fmconfig ]
        retval = AdminTask.createClusterMember(cargs)
      else:
        
        fmconfig = ['-templateName', template]
        if (not isEmpty(resourcesScope)):
          fmconfig.extend(['-resourcesScope',resourcesScope])
        
        _app_trace("Issuing command: AdminTask.createClusterMember(['-clusterName', %s, '-memberConfig', ['-memberNode', %s, '-memberName', %s], '-firstMember', %s ])" % (cluster, memberNode, memberName, fmconfig ))
        clusterMember = AdminTask.createClusterMember(['-clusterName', cluster, '-memberConfig', ['-memberNode', memberNode, '-memberName', memberName], '-firstMember', fmconfig ])
        retval = clusterMember
        
    else:
      # Create non-first cluster member
      _app_trace("Issueing command: AdminConfig.createClusterMember(%s,%s,%s)"%(clusterID, nodeid,memberName))
      retval = AdminConfig.createClusterMember(clusterID,nodeid,[['memberName',memberName]])
      _app_trace("Retval = %s, AdminConfig.createClusterMember(%s,%s,%s)"%(retval,clusterID, nodeid,memberName))

    # See if memberWeight needs to be changed
    if (not isEmpty(retval) and memberWeight != None):
        clusterMember = retval      
        currentWeight = AdminConfig.showAttribute(clusterMember,"weight")
        if (memberWeight != currentWeight):
            if (modifyObject(clusterMember,[["weight", memberWeight]])):
                _app_message("Failed to change weight for %s clusterMember %s on %s)" % (cluster, memberName, memberNode))
                return None
            else:
                _app_message("Modified weight for %s clusterMember %s on %s)" % (cluster, memberName, memberNode))


    # If startingPort not empty then modify ports
    updatevhost = 0
    if (not isEmpty(vhost)):
        updatevhost = 1
    if not isEmpty(startingPort) and modifyApplicationServerPorts(memberName, memberNode, startingPort,updatevhost,vhost,keepHostNames):
      raise StandardError("Failed to allocate port numbers starting at %s" % (startingPort))

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered creating the Cluster Member", "exception")
    retval = None

  _app_trace("createClusterMember(%s)" %(retval), "exit")
  return retval



	
##########################################################################
#
# FUNCTION:
#    deleteClusterMember: Delete a Cluster Member
#
# SYNTAX:
#    deleteClusterMember cluster, memberNode, memberName
#
# PARAMETERS:
#    cluster	-	Name of cluster
#    memberNode	-	The name of the node where the cluster member will be created
#    memberName	-	Name of cluster member
#
# USAGE NOTES:
#    Deletes a Cluster Member from the desired templateNode.  
#
# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeClusterMember(cluster, memberNode, memberName):
	deleteClusterMember(cluster, memberNode, memberName)
	
def deleteClusterMember(cluster, memberNode, memberName):
	
	global progInfo
	retval = 1
	
	try:
		traceStr = "deleteClusterMember(%s, %s, %s)" % (cluster, memberNode, memberName)
		_app_trace(traceStr, "entry")	
		
		configID = "/ServerCluster:%s/" % (cluster)
		
		if isEmpty(memberName) or isEmpty(cluster) or isEmpty(memberNode):
			_app_trace("Cluster, member name or member node not specified")
			retval = 1
		elif not objectExists("ServerCluster", None, cluster):
			_app_trace("Cluster %s does not exist" % (cluster))
			retval = 1
		elif not objectExists("ClusterMember", configID, memberName):
			_app_trace("Cluster Member %s does not exist on cluster %s" % (memberName, cluster))
			retval = 1
		else:
			attributes  = "[-clusterName %s -memberNode %s -memberName %s]" % (cluster, memberNode, memberName)
			
			_app_trace("Attributes = %s" %(attributes))
			_app_trace("Running Command: AdminTask.deleteClusterMember(%s)" % (attributes))
			
			AdminTask.deleteClusterMember(attributes)

			if progInfo["app.autosave"] == "true":
				_app_trace("Saving...")
				AdminConfig.save()
	except:
		_app_trace("An error was encountered deleting the Cluster Member", "exception")
		retval = 1

	_app_trace("deleteClusterMember(%d)" %(retval), "exit")
	return retval
	
#-------------------------------------------------------------------------
# deleteClusterMembers
#
# Parameters:
#     clusterName - name of the cluster
#     memberList - A list of [server, node] tuples
#-------------------------------------------------------------------------
def deleteClusterMembers(clusterName, memberList):
  _app_trace("deleteClusterMembers(%s,%s)" % (clusterName, memberList),"entry")
  
  try:
    for tempMember in memberList:
      tempNode = tempMember[1]
      tempServer = tempMember[0]
      
      _app_trace('About to call AdminTask.deleteClusterMember("[-clusterName %s -memberNode %s -memberName %s]"' % (clusterName, tempNode, tempServer))
      AdminTask.deleteClusterMember("[-clusterName %s -memberNode %s -memberName %s]" % (clusterName, tempNode, tempServer))
      
  except:
    _app_trace("Unexpected error in deleteClusterMembers","exception")
    raise StandardError("Unexpected error in deleteClusterMembers")
  
  _app_trace("deleteClusterMembers()","exit")

##########################################################################
#
# FUNCTION:
#    listClusterMembers: List Cluster Members of a cluster
#
# SYNTAX:
#    listClusterMembers cluster
#
# PARAMETERS:
#    cluster	-	Name of cluster
#    
# USAGE NOTES:
#    Lists Cluster Members .  
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showClusterMembers(cluster, displayFlag = 1):
	listClusterMembers(cluster, displayFlag)
	
def listClusterMembers(cluster, displayFlag = 1):
	
	global progInfo
	retval = None
	
	try:
		traceStr = "listClusterMembers(%s, %d)" % (cluster, displayFlag)
		_app_trace(traceStr, "entry")	

		if isEmpty(cluster):
			_app_trace("Cluster name must be specified")
			retval = None
		elif not objectExists("ServerCluster", None, cluster):
			_app_trace("No such cluster as %s" % (cluster))
			retval = 1
		else:
			parentID = AdminConfig.getid("/ServerCluster:%s/" % (cluster))

			_app_trace("Running command: AdminConfig.list('ClusterMember', %s)" % (parentID))
			str = AdminConfig.list("ClusterMember", parentID)

			if isEmpty(str):
				retval = []
			else:
				retval = str.split(progInfo["line.separator"])

			if displayFlag:
				print "\nCluster Members for %s\n-----------------------------" % (cluster)
				
				for r in retval:
					print AdminConfig.showAttribute(r, "memberName")
							
				print "-----------------------------"

	except:
		_app_trace("An error was encountered listing the Cluster Members", "exception")
		retval = None

	_app_trace("listClusterMembers(%s)" %(retval), "exit")
	return retval

#------------------------------------------------------------------------------------------------
#  Determine if the named cluster member is already defined
#------------------------------------------------------------------------------------------------
def checkForExistingClusterMember(clusterName, memberNode, memberName):

	global progInfo
	retval = None
	
	try:
		traceStr = "checkForExistingClusterMember(%s, %s, %s)" % (clusterName, memberNode, memberName)
		_app_trace(traceStr, "entry")	

		if isEmpty(clusterName):
			_app_trace("Cluster name must be specified")
			retval = None
		elif not objectExists("ServerCluster", None, clusterName):
			_app_trace("No such cluster as %s" % (clusterName))
			retval = None
		else:
			parentID = AdminConfig.getid("/ServerCluster:%s/" % (clusterName))

			_app_trace("Running command: AdminConfig.list('ClusterMember', %s)" % (parentID))
			str = AdminConfig.list("ClusterMember", parentID)

			if isEmpty(str):
				memberList = []
			else:
				memberList = str.split(progInfo["line.separator"])

			for member in memberList:
					mName = AdminConfig.showAttribute(member, "memberName")
					mNode = AdminConfig.showAttribute(member, "nodeName")
					
					if (mName == memberName and mNode == memberNode):
							retval = member
							break
							
				

	except:
		_app_trace("An error was encountered searching for the Cluster Members", "exception")
		retval = None

	_app_trace("checkForExistingClusterMember(%s)" %(retval), "exit")
	return retval

#-------------------------------------------------------------------------------
# getClusterMemberList
#
# Returns cluster member list as a list of [memberName, memberNode] tuples
#-------------------------------------------------------------------------------
def getClusterMemberList(clusterName, clusterId=None):
  
  
  _app_trace("getClusterMemberList(%s,%s)" % (clusterName, clusterId),"entry")
  retval = []
  try:
    if (isEmpty(clusterId)):
      clusterId = AdminConfig.getid("/ServerCluster:%s/" % clusterName)
    
    if (isEmpty(clusterId)):
      raise StandardError("Unable to find configuration ID for cluster %s" % clusterName)
    
    _app_trace("Running command: AdminConfig.list('ClusterMember', %s)" % (clusterId))
    str = AdminConfig.list("ClusterMember", clusterId)

    if isEmpty(str):
      memberList = []
    else:
      memberList = str.split(progInfo["line.separator"])

    for member in memberList:
        mName = AdminConfig.showAttribute(member, "memberName")
        mNode = AdminConfig.showAttribute(member, "nodeName")
          
        retval.append( [mName,mNode])
          
    
  except:
    _app_trace("Unexpected error in getClusterMemberList","exception")
    raise StandardError("Unexpected error in getClusterMemberList")
  
  
  _app_trace("getClusterMemberList(%d members)" % len(retval),"exit")
  return retval


#-------------------------------------------------------------------------------
# getSortedClusterMemberList
#
# Returns cluster member list as a list of [memberName, memberNode] tuples
#
# The list is sorted by node-name values
#
# Parameters: 
#    clusterName - the name of the cluster
#    clusterId - optional clusterId if it is known
#    nodeFilterList - optional list of node names that server must be member of
#-------------------------------------------------------------------------------
def getSortedClusterMemberList(clusterName, clusterId=None,nodeFilterList=[]):
  
  _app_trace("getSortedClusterMemberList(%s,%s,%s)" % (clusterName, clusterId,nodeFilterList),"entry")
  retval = []
  try:
      if (isEmpty(clusterId)):
        clusterId = AdminConfig.getid("/ServerCluster:%s/" % clusterName)

      clusterMembers = wsadminToList(AdminConfig.showAttribute(clusterId,"members"))
      #print clusterMembers
      clusterMemberInfo = []
      for clusterMember in clusterMembers:
          if (isEmpty(clusterMember)):
              continue
          
          mName = AdminConfig.showAttribute(clusterMember,"memberName")
          mNode = AdminConfig.showAttribute(clusterMember,"nodeName")
          
          #print "Considering %s %s" % (mName,mNode)
          if (nodeFilterList == None or len(nodeFilterList) == 0 or mNode in nodeFilterList):
            #print "Adding %s %s" % (mName,mNode)
            clusterMemberInfo.append("%s %s" % (mNode, mName))
      
      
      # Sort the results
      clusterMemberInfo.sort()
      
      for clusterMemberString in clusterMemberInfo:
        tempstrings = clusterMemberString.split(" ")
        mNode = tempstrings[0]
        mName = tempstrings[1]
        
        retval.append( [mName,mNode])
        #print "retval=%s" %  retval
      
      
  except:
    _app_trace("Unexpected error in getSortedClusterMemberList","exception")
    raise StandardError("Unexpected error in getSortedClusterMemberList")

  _app_trace("getSortedClusterMemberList(%d members)" % len(retval),"exit")
  return retval





#-------------------------------------------------------------------------------
# getClusterMemberNodeList
#
# Returns list of node names that cluster members are defined on
#-------------------------------------------------------------------------------
def getClusterMemberNodeList(clusterName, clusterId=None):
  
  
  _app_trace("getClusterMemberList(%s,%s)" % (clusterName, clusterId),"entry")
  retval = []
  try:
    if (isEmpty(clusterId)):
      clusterId = AdminConfig.getid("/ServerCluster:%s/" % clusterName)
    
    if (isEmpty(clusterId)):
      raise StandardError("Unable to find configuration ID for cluster %s" % clusterName)
    
    _app_trace("Running command: AdminConfig.list('ClusterMember', %s)" % (clusterId))
    str = AdminConfig.list("ClusterMember", clusterId)

    if isEmpty(str):
      memberList = []
    else:
      memberList = str.split(progInfo["line.separator"])

    for member in memberList:
        mNode = AdminConfig.showAttribute(member, "nodeName")
          
        if (not mNode in retval):
          retval.append( mNode)
          
    
  except:
    _app_trace("Unexpected error in getClusterMemberNodeList","exception")
    raise StandardError("Unexpected error in getClusterMemberNodeList")
  
  
  _app_trace("getClusterMemberNodeList(%s)" % retval,"exit")
  return retval
  

#----------------------------------------------------------------------
# getClusterMemberId
#
# Utility method for finding a specific ClusterMember configuration ID
#----------------------------------------------------------------------
def getClusterMemberId(clusterName, memberName, nodeName):
  _app_trace("getClusterMemberId(%s,%s,%s)" % (clusterName, memberName, nodeName),"entry")
  retval = None
  try:
     resultList = AdminConfig.getid("/ServerCluster:%s/ClusterMember:%s/" % (clusterName,memberName)).splitlines()
     if (len(resultList) == 1 and not isEmpty(resultList[0])):
      retval = resultList[0]
     else:
      for tempId in resultList:
        if (not isEmpty(tempId)):
          if (AdminConfig.showAttribute(tempId,"nodeName") == nodeName):
            retval = tempId
            break
  except:
    _app_trace("Unexpected error in getClusterMemberId","exception")
    raise StandardError("Unexpected error in getClusterMemberId")
  
  _app_trace("getClusterMemberId(retval=%s)" % retval, "exit")
  return retval