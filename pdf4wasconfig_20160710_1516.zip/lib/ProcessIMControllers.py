################################################################################
# ProcessIMControllers.py
#
# This script processes the key/value settings loaded into a dictionary and
# applies them to the Intelligent Management controllers.  Currently supports
# the HealthController, Application Placement Controller, and the
# Automatic Request Flow Manager
#
# Required Modules: IMControllers.py
#                   Utils.py
#                   common.py
#
# Entry function: processIMControllers()
#
# -- Property Syntax Examples --
#
# -- Health Controller --
# app.im.controllers.health.prop.controlCycleLength = 5
# app.im.controllers.health.prop.enable = true
# app.im.controllers.health.prop.maxConsecutiveRestarts = 3
# app.im.controllers.health.prop.minRestartInterval = 45
# app.im.controllers.health.prop.minRestartIntervalUnits = 2
# app.im.controllers.health.prop.restartTimeout = 5
# app.im.controllers.health.properties.prop.com.ibm.ws.xd.hmm.controller.approvalTimeOutMinutes = 25
#
# -- Application Placement Controller --
# app.im.controllers.apc.prop.approvalTimeOut = 10
# app.im.controllers.apc.prop.consolidationMode = 1
# app.im.controllers.apc.prop.enable = true
# app.im.controllers.apc.prop.enableElasticity = false
# app.im.controllers.apc.prop.minTimeBetweenPlacementChange = 25
# app.im.controllers.apc.prop.minTimeBetweenPlacementChangeUnits = 3
# app.im.controllers.apc.prop.modeTimeOut = 10
# app.im.controllers.apc.prop.modeTimeOutUnits = 2
# app.im.controllers.apc.prop.serverOperationTimeOut = 6
# app.im.controllers.apc.properties.prop.APC.predictor = CPU
#
# -- AutonomicRequestFlowManager --
# app.im.controllers.arfm.prop.aggregationPeriod = 5
# app.im.controllers.arfm.prop.aggregationPeriodUnits = 1
# app.im.controllers.arfm.prop.controlCycleMinimumLength = 59
# app.im.controllers.arfm.prop.controlCycleMinimumLengthUnits = 1
# app.im.controllers.arfm.prop.maximumCPUUtilization = 100
# app.im.controllers.arfm.prop.maximumPercentServerMaxHeap = 100
# app.im.controllers.arfm.prop.maximumQueueLength = 5000
# app.im.controllers.arfm.prop.rejectionThreshold = -1
# app.im.controllers.arfm.prop.smoothingWindow = 12
################################################################################


#---------------------------------------------------------------------
# buildRestartTimesList
#
# --Not used--
#---------------------------------------------------------------------
def buildRestartTimesList(ctrlInfo,prefix):
  retval = []
  restartCount = int(ctrlInfo.get("%s.prohibitedRestartTimes.count" % prefix,0))
  if (restartCount > 0):
    for idx in range(1,restartCount+1):
      restartProps = getPropList(ctrlInfo,"%s.prohibitedRestartTimes.%d" % (prefix,idx))
      startProps = getPropList(ctrlInfo,"%s.prohibitedRestartTimes.%d.startTime" % (prefix,idx))
      endProps = getPropList(ctrlInfo,"%s.prohibitedRestartTimes.%d.endTime" % (prefix,idx))
      
      retval.append( ( toDictionary(restartProps),toDictionary(startProps),toDictionary(endProps)))
  
  return retval
      
  

#---------------------------------------------------------------------
# processHealthController
#---------------------------------------------------------------------
def processHealthController(ctrlInfo):
  _app_entry('processHealthController(ctrlInfo)')

  try:
    prefix = "app.im.controllers.health"
    if (checkForPrefix(ctrlInfo,prefix)):
      # We have health controller settings
      ctrlProps = getHealthControllerProperties()
      baseProps = getPropListDifferences(ctrlInfo,prefix,ctrlProps,"controllers.health")
      customProps = getPropListDifferences(ctrlInfo,"%s.properties" % prefix,ctrlProps,"controllers.health.properties")
      
      #   The prohibited restart times update does not work and is documented in the info center as not supported by wsadmin
      #   http://www-01.ibm.com/support/knowledgecenter/SSUP64_7.0.0/com.ibm.websphere.virtualenterprise.doc/reference/todhmscript.html
      #   http://www-304.ibm.com/support/knowledgecenter/SSAW57_8.5.5/com.ibm.websphere.nd.doc/ae/rwve_odhmscript.html

      #inputRestartList = buildRestartTimesList(ctrlInfo,prefix)
      #existingRestartList = buildRestartTimesList(ctrlProps,"controllers.health")
      
      if ( len(baseProps) > 0 or len(customProps) > 0):
        updateHealthController(baseProps,customProps)
        _app_message("HealthController has been updated")
        #print "bp=%s\ncp=%s\nrl=%s" % (baseProps,customProps,inputRestartList)
      else:
        _app_message("HealthController does not need to be updated")
      
      
      
  except:
    _app_exception("Unexpected problem with processHealthController")
  
  _app_exit('processHealthController()')


#-------------------------------------------------------------------------------
# processAutonomicRequestFlowManager
#
# Parameters
#     ctrlInfo - Dictionary with ARFM settings
#-------------------------------------------------------------------------------
def processAutonomicRequestFlowManager(ctrlInfo):
  _app_entry("processAutonomicRequestFlowManager(ctrlInfo)")
  
  try:

    prefix = "app.im.controllers.arfm"
    if (checkForPrefix(ctrlInfo,prefix)):
      # We have arfm controller settings
      ctrlProps = getAutonomicRequestFlowManagerProperties()
      baseProps = getPropListDifferences(ctrlInfo,prefix,ctrlProps,"controllers.arfm")
      customProps = getPropListDifferences(ctrlInfo,"%s.properties" % prefix,ctrlProps,"controllers.arfm.properties")
      
      if (len(baseProps) > 0 or len(customProps) > 0):
         updateAutonomicRequestFlowManager(baseProps,customProps)
         _app_message("Autonomic Request Flow Manager settings have been updated")
      else:
        _app_message("Autonomic Request Flow Manager does not need to be updated")

  except:
    _app_exception("Unexpected problem in processAutonomicRequestFlowManager()")
  
  _app_exit("processAutonomicRequestFlowManager()")


#-------------------------------------------------------------------------------
# processApplicationPlacementController
#
# Parameters
#     ctrlInfo - Dictionary with ARFM settings
#-------------------------------------------------------------------------------
def processApplicationPlacementController(ctrlInfo):
  _app_entry("processApplicationPlacementController(ctrlInfo)")
  
  try:

    prefix = "app.im.controllers.apc"
    if (checkForPrefix(ctrlInfo,prefix)):
      # We have arfm controller settings
      ctrlProps = getApplicationPlacementControllerProperties()
      baseProps = getPropListDifferences(ctrlInfo,prefix,ctrlProps,"controllers.apc")
      customProps = getPropListDifferences(ctrlInfo,"%s.properties" % prefix,ctrlProps,"controllers.apc.properties")
      
      if (len(baseProps) > 0 or len(customProps) > 0):
         updateApplicationPlacementController(baseProps,customProps)
         _app_message("Application Placement Controller settings have been updated")
      else:
        _app_message("Application Placement Controller does not need to be updated")

  except:
    _app_exception("Unexpected problem in processApplicationPlacementController()")
  
  _app_exit("processApplicationPlacementController()")
  

  

#---------------------------------------------------------------------
# processIMControllers
#---------------------------------------------------------------------
def processIMControllers(ctrlInfo):
  _app_entry('processIMControllers(ctrlInfo)')
  
  try:
    if (checkForPrefix(ctrlInfo,"app.im.controllers.")):
      processHealthController(ctrlInfo)
      processAutonomicRequestFlowManager(ctrlInfo)
      processApplicationPlacementController(ctrlInfo)

  except:
    _app_exception("Unexpected problem with processIMControllers")
  
  _app_exit('processIMControllers()')
  
  
