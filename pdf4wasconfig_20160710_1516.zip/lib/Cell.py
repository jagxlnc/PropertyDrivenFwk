################################################################################
# Cell.py
#   Methods for querying and updating cell properties
#     updateCellProperties(baseProps=None,customProps=None,mddProps=None)
#     getCellProperties():
#
# Requires Utils.py, common.py
#
################################################################################

#-------------------------------------------------------------------------------
# updateCellProperties
#
# Parameters
#    baseProps
#    cusomProps 
#    mddProps - properties to define MonitoredDirectoryDeployment
#-------------------------------------------------------------------------------
def updateCellProperties(baseProps=None,customProps=None,mddProps=None):
  _app_entry("updateCellProperties(%s,%s,%s)" , baseProps,customProps,mddProps)
  retval = None
  try:
    cellId = getCellId()
    
    if (baseProps != None and len(baseProps) > 0):
       modifyObjectProperties(cellId,baseProps)
    
    if (customProps != None and len(customProps) > 0):
      updateCustomProperties(cellId, "properties", "Property", customProps)
    
    if (mddProps != None and len(mddProps) > 0):
      # Update the MonitoredDirectoryDeployment (V8 onwards)
      mddId = AdminConfig.showAttribute(cellId,"monitoredDirectoryDeployment")
      if (mddId == None):
        attrs = propsToAttrList(mddProps)
        _app_trace('About to call AdminConfig.create("MonitoredDirectoryDeployment",%s,%s)' % (cellId,attrs))
        mddId = AdminConfig.create("MonitoredDirectoryDeployment",cellId,attrs)
      else:
        modifyObjectProperties(mddId,mddProps)
    
    retval = cellId
      
  except:
    _app_exception("Unexpected problem in updateCellProperties()")
  
  _app_exit("updateCellProperties(retval=%s)" % retval)
  return retval

#-------------------------------------------------------------------------------
# getCellProperties
#
# Parameters:
#    None
#
#-------------------------------------------------------------------------------
def getCellProperties():
  _app_entry("getCellProperties()")
  retval = {}
  try:
    retval["cell.name"] = getCellName()
    collectSimpleProperties(retval, "cell.prop",getCellId(), optionalSkipList=["name"],getSimpleChildren=1,
                            collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=1,getChildType=1)

  except:
    _app_exception("Unexpected problem in getCellProperties()")
  
  _app_exit("getCellProperties(retval=%s)" % retval)
  return retval