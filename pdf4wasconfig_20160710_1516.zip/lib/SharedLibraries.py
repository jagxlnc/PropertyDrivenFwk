##########################################################################################
# SharedLibary.py
#
# Utility methods for Shared Library manipulation
##########################################################################################

#-----------------------------------------------------------------------------------------
# createSharedLibrary
#
# Create a new Shared Library configuration
#
# Parameters:
#    scopeId - Configuration ID of parent scope
#    libraryName - name of shared library
#    libraryProperties - Properties object or dictionary with library settings
#----------------------------------------------------------------------------------------
def createSharedLibrary(scopeId, libraryName, libraryProperties):
	
	_app_trace("createSharedLibrary(%s,%s,%s)" % (scopeId, libraryName, libraryProperties), "entry")
	retval = None
	try:
		attrs = "[name %s]" % libraryName
		for key in libraryProperties.keys():
				if (key == "name"):
						continue
				val = libraryProperties.get(key)
				if (key == "description" and not val.startswith("'") and not val.startswith('"')):
						val = '"%s"' % val
				
				if (val == "[]"):
						val = "''"
				
				if (val == ""):
						val = "''"
				
				attrs = "%s [%s %s]" % (attrs,key,val)		
		
		attrs = "[ %s ]" % attrs
				
		_app_trace("About to call AdminConfig.create(Library,%s,%s)" % (scopeId,attrs))
		retval = AdminConfig.create("Library",scopeId,attrs)
	except:
		_app_trace("Error creating Shared Library %s" % libraryName, "exception")
		retval = None
	
	_app_trace("createSharedLibrary(retval=%s)" % (retval), "exit")
	return retval

#-----------------------------------------------------------------------------------------
# updateSharedLibrary
#
# Update and existing Shared Library configuration
#
# Parameters:
#    libraryId - Configuration ID of existing library
#    libraryProperties - Properties object or dictionary with library settings
#
# Returns libraryId or None if error occurred
#----------------------------------------------------------------------------------------
def updateSharedLibrary(libraryId, libraryProperties):
	
	_app_trace("updateSharedLibrary(%s,%s)" % (libraryId, libraryProperties), "entry")
	retval = None
	try:
		premodattrs = []
		newclassPath = libraryProperties.get("classPath")
		if (newclassPath != None):
				premodattrs.append(["classPath",""])
		newnativePath = libraryProperties.get("nativePath")
		if (newnativePath != None):
				premodattrs.append(["nativePath",""])
		
		if (len(premodattrs) > 0):
				if (modifyObject(libraryId, premodattrs)):
						# Error modify object
						raise StandardError("Error clearing existing path fields")
		
	
		attrs = ""
		for key in libraryProperties.keys():
				if (key == "name"):
						continue
				val = libraryProperties.get(key)
				if (key == "description" and not val.startswith("'") and not val.startswith('"')):
						val = '"%s"' % val
				if (val == "[]"):
						val = "''"
				
				if (val == ""):
						val = "''"
				
				attrs = "%s [%s %s]" % (attrs,key,val)		
		
		attrs = "[ %s ]" % attrs
				
				
		if (modifyObject(libraryId,attrs)):
				# Error during modify
				retval = None
		else:
				# Modified successfully
				retval = libraryId
				
	except:
		_app_trace("Error updating Shared Library %s" % libraryId, "exception")
		retval = None
	
	_app_trace("updateSharedLibrary(retval=%s)" % (retval), "exit")
	return retval



#----------------------------------------------------------------------------------------
# checkForExistingLibrary
#
# Returns the ID of the library with the specified name and scope
# "" is returned if the library does not exist
# "ERROR" is returned if a processing error occurs
#----------------------------------------------------------------------------------------
def checkForExistingLibrary(cluster, node, server, libraryName):

	retval = None
	global progInfo
	
	_app_trace("checkForExistingLibrary(%s,%s,%s,%s)" % (cluster, node, server, libraryName),"entry")
	
	try:
		if (not isEmpty(cluster)):
				retval = AdminConfig.getid("/ServerCluster:%s/Library:%s/" % (cluster, libraryName))
		elif (not isEmpty(server) and not isEmpty(node)):
				retval = AdminConfig.getid("/Node:%s/Server:%s/Library:%s/" % (node, server, libraryName))
		elif (not isEmpty(node)):
				retval = AdminConfig.getid("/Node:%s/Library:%s/" % (node, libraryName))
		elif (isEmpty(cluster) and isEmpty(node) and isEmpty(server)):
				# Cell scoped
				# Need cell name
				cellName = ""
				cells = AdminConfig.list("Cell").split(progInfo["line.separator"])
				for cell in cells:
						cellName = AdminConfig.showAttribute(cell,"name")
						break
				retval = AdminConfig.getid("/Cell:%s/Library:%s" % (cellName, libraryName))
    
	
	except:
		_app_trace("Error checking for library", "exception")
		retval = "ERROR"
	
	_app_trace("checkForExistingLibrary(retval=%s)"%retval, "exit")
	return retval
	

#-----------------------------------------------------------------------------------------
# getLibraryProperties
# 
# Returns a properties object with the configuration of the shared library as properties
# with the prefix app.library.prop
#-----------------------------------------------------------------------------------------
def getLibraryProperties(libraryId):

	retval = None
	_app_trace("getLibraryProperties(%s)" %libraryId, "entry")
	try:
		retval = java.util.Properties()
		collectSimpleProperties(retval, "app.library.prop",libraryId)
	
	except:
		_app_trace("Exception getting properties for shared library","exception")
		retval = None
	
	_app_trace("getLibraryProperties()","exit")
	return retval