###########################################################################################
# ProcessCoreGroup.py
#
# This module processes the core group settings in the global configInfo dictionary.
#
# Coregroup settings are processed in two stages by the calling updateEnvironment script:
#    1) New core groups are created so they can be referenced during cluster/server creation.
#    2) After server creation, core groups settings are applied, so we can make references to
#       the servers.
#
# Entry points:
#     processCoreGroupCreation - creates new core groups but doesn't apply advanced settings
#     processCoreGroupSettings - Applies settings to existing and core groups created by processCoreGroupCreation
#
# Related modules:
#     Utils.py - utility methods
#     CoreGroup.py - methods for finding,creating,updating coregroup settings.
#
# Property Syntax Example: 
#     app.coregroups.1.name = AnotherCoreGroup
#     app.coregroups.1.prop.channelChainName = DCS
#     app.coregroups.1.prop.description = A non-default core group
#     app.coregroups.1.prop.numCoordinators = 1
#     app.coregroups.1.prop.protocolVersion = 6.0.0
#     app.coregroups.1.prop.transportMemorySize = 100
#     app.coregroups.1.prop.transportType = CHANNEL_FRAMEWORK
#     app.coregroups.1.customProperties.prop.CUSTOMPROP1 = VALUE1|Core Group Custom Property
#     app.coregroups.1.customProperties.prop.CUSTOMPROP2 = VALUE2
#     app.coregroups.1.liveness.prop.discoveryPeriod = 60
#     app.coregroups.1.liveness.prop.heartbeatTimeoutPeriod = 180000
#     app.coregroups.1.liveness.prop.heartbeatTransmissionPeriod = 30000
#     app.coregroups.1.liveness.prop.livenessType = DEFAULT_ONLY
#     app.coregroups.1.preferredCoordinatorServers.1.serverName = NewCoreGroupMemberOne
#     app.coregroups.1.preferredCoordinatorServers.1.nodeName = ConfigurationScriptingNode1
#     app.coregroups.1.preferredCoordinatorServers.2.serverName = NewCoreGroupMemberTwo
#     app.coregroups.1.preferredCoordinatorServers.2.nodeName = ConfigurationScriptingNode2
#     app.coregroups.1.preferredCoordinatorServers.count = 2
#     app.coregroups.1.policies.1.policyType = OneOfNPolicy
#     app.coregroups.1.policies.1.name = Default SIBus Policy
#     app.coregroups.1.policies.1.prop.description = SIBus One-Of-N Policy
#     app.coregroups.1.policies.1.prop.failback = false
#     app.coregroups.1.policies.1.prop.isAlivePeriodSec = 120
#     app.coregroups.1.policies.1.prop.policyFactory = com.ibm.ws.hamanager.coordinator.policy.impl.OneOfNPolicyFactory
#     app.coregroups.1.policies.1.prop.preferredOnly = true
#     app.coregroups.1.policies.1.prop.quorumEnabled = false
#     app.coregroups.1.policies.1.preferredServers.1.serverName = NewCoreGroupMemberOne
#     app.coregroups.1.policies.1.preferredServers.1.nodeName = ConfigurationScriptingNode1
#     app.coregroups.1.policies.1.preferredServers.2.serverName = NewCoreGroupMemberTwo
#     app.coregroups.1.policies.1.preferredServers.2.nodeName = ConfigurationScriptingNode2
#     app.coregroups.1.policies.1.preferredServers.count = 2
#     app.coregroups.1.policies.1.matchCriteria.1.name = type
#     app.coregroups.1.policies.1.matchCriteria.1.description = Default SIBus MatchCriterion
#     app.coregroups.1.policies.1.matchCriteria.1.value = WSAF_SIB
#     app.coregroups.1.policies.1.matchCriteria.count = 1
#     ..
#     app.coregroups.1.policies.count = <max index>
#     ...
#     app.coregroups.count = max coregroup count
#
# ------------------------------------------------------------------------
# Alternative syntax for preferredCoordinatorServers and preferredServers.
# ------------------------------------------------------------------------ 
# Besides the ordered list syntax illustrated above, these settings can be specified as 
# a single .names property as demonstrated below.
#
# These properties also support the @NODEAGENTS and @CLUSTERMEMBERS macros which can be used to identify
# that the prefered servers are node agents or cluster members (including a subset of cluster members).
# The .names property can be a literal list or one of these macros:
#     @NODEAGENTS
#     @NODEAGENTS(ALL)
#     @NODEAGENTS(cluster-name-1 [,cluster-name-2,...])
#     @CLUSTERMEMBERS(cluster-name,ALL)
#     @CLUSTERMEMBERS(cluster-name,count)
#
#     app.coregroups.1.name = AnotherCoreGroup
#     app.coregroups.1.preferredCoordinatorServers.names = nodeagent NODE1 nodeagent NODE2
#     app.coregroups.1.policies.1.policyType = OneOfNPolicy
#     app.coregroups.1.policies.1.name = Default SIBus Policy
#     app.coregroups.1.policies.1.prop.description = SIBus One-Of-N Policy
#     app.coregroups.1.policies.1.prop.failback = false
#     app.coregroups.1.policies.1.prop.isAlivePeriodSec = 120
#     app.coregroups.1.policies.1.prop.policyFactory = com.ibm.ws.hamanager.coordinator.policy.impl.OneOfNPolicyFactory
#     app.coregroups.1.policies.1.prop.preferredOnly = true
#     app.coregroups.1.policies.1.prop.quorumEnabled = false
#     app.coregroups.1.policies.1.preferredServers.names = NewCoreGroupMemberOne NODE1 NewCoreGroupMemberTwo NODE2
#     app.coregroups.1.policies.1.matchCriteria.1.name = type
#     app.coregroups.1.policies.1.matchCriteria.1.description = Default SIBus MatchCriterion
#     app.coregroups.1.policies.1.matchCriteria.1.value = WSAF_SIB
#     app.coregroups.1.policies.1.matchCriteria.count = 1
#     ..
#     app.coregroups.1.policies.count = <max index>
#     ...
#     app.coregroups.count = max coregroup count
#
#---------------------------
# Adding CoreGroup members.
#---------------------------
# A cluster or stand-alone server can be added to a core group by specifying the
# moveToCoreGroup or moveClusterToCoreGroup property for the cluster or core group as shown below. 
# These properties are processed with the other properties for server or cluster definitions.
# app.appserver.2.moveToCoreGroup = DefaultCoreGroup
# app.cluster.2.moveClusterToCoreGroup = DefaultCoreGroup.
#
# In addition to that, the coregroup settings can contain a numbered list of 
# addCoreGroupMember properties that specify clusters, servers, or a list of
# servers to add to the coregroup.
# 
# app.coregroups.3.addCoreGroupMember.1.cluster = SampleCluster
# app.coregroups.3.addCoreGroupMember.2.server = Dude
# app.coregroups.3.addCoreGroupMember.2.node = ConfigurationScriptingNode1
# app.coregroups.3.addCoreGroupMember.3.names = @NODEAGENTS
#
#------------------------------------------
# Creating a policy for each cluster member
#------------------------------------------
# When defining core group policies, there is special support for creating multiple policies that 
# correspond to each application server in a cluster.  The iterateClusterMembers attribute indicates
# that the processing script will evaluate this policy definition multiple times, by iterating through
# the members of a cluster and setting the dynamic variables based on each cluster member.
# 
# This parallels the similar behavior of the SI Bus message engine processing script ProcessSIB. 
# The SERVER_INDEX0 variable starts with an index value of 000 and SERVER_INDEX variable starts with an index value of 001.
# These variables can be used to pair this policy with the corresponding message engine. (Use SERVER_INDEX1 if 
# your setup deletes the first messaging engine)
#
# app.coregroups.2.policies.4.iterateClusterMembers = NewCoreGroupCluster
# app.coregroups.2.policies.4.policyType = OneOfNPolicy
# app.coregroups.2.policies.4.name = NewCoreGroupCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX}-MyNewBus
# app.coregroups.2.policies.4.prop.description = None
# app.coregroups.2.policies.4.prop.failback = true
# app.coregroups.2.policies.4.prop.isAlivePeriodSec = 60
# app.coregroups.2.policies.4.prop.policyFactory = com.ibm.ws.hamanager.coordinator.policy.impl.OneOfNPolicyFactory
# app.coregroups.2.policies.4.prop.preferredOnly = true
# app.coregroups.2.policies.4.prop.quorumEnabled = false
# app.coregroups.2.policies.4.matchCriteria.1.name = type
# app.coregroups.2.policies.4.matchCriteria.1.description = None
# app.coregroups.2.policies.4.matchCriteria.1.value = WSAF_SIB
# app.coregroups.2.policies.4.matchCriteria.2.name = WSAF_SIB_MESSAGING_ENGINE
# app.coregroups.2.policies.4.matchCriteria.2.description = None
# app.coregroups.2.policies.4.matchCriteria.2.value = NewCoreGroupCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-MyNewBus
# app.coregroups.2.policies.4.matchCriteria.count = 2
# app.coregroups.2.policies.4.preferredServers.1.serverName = @{DYNAMIC#CURRENT_SERVER#name}
# app.coregroups.2.policies.4.preferredServers.1.nodeName = @{DYNAMIC#CURRENT_NODE#name}
# app.coregroups.2.policies.4.preferredServers.count = 1
#
# In the case where you may have message engines spread out across a subset of 
# cluster members, there are two additional settings that can control the generation
# of policies. 
# 
# "iterateClusterMembers.nodes" is a list of nodes that is the preferred
# location of a message engine. The iterateClusterMembers logic will only create n policies,
# where n is the number of nodes listed for this property. The code will determine
# which servers live on these nodes and use them to populate the values of the CURRENT_SERVER
# and CURRENT_NODE dynamic values.
#
# "iterateClusterMembers.determineSecondaries" signals that the code should divide the 
# remaining cluster members as additional preferred servers for the policies. The calculated
# list of preferred servers is populated into the PREFERRED_SERVER_LIST replacement keyword.
# 
# app.coregroups.2.policies.4.iterateClusterMembers = NewCoreGroupCluster
# app.coregroups.1.policies.1.iterateClusterMembers.nodes = ConfigurationNode2,ConfigurationNode4
# app.coregroups.1.policies.1.iterateClusterMembers.determineSecondaries = true
# app.coregroups.2.policies.4.policyType = OneOfNPolicy
# app.coregroups.2.policies.4.name = NewCoreGroupCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX}-MyNewBus
# app.coregroups.2.policies.4.prop.description = None
# app.coregroups.2.policies.4.prop.failback = true
# app.coregroups.2.policies.4.prop.isAlivePeriodSec = 60
# app.coregroups.2.policies.4.prop.policyFactory = com.ibm.ws.hamanager.coordinator.policy.impl.OneOfNPolicyFactory
# app.coregroups.2.policies.4.prop.preferredOnly = true
# app.coregroups.2.policies.4.prop.quorumEnabled = false
# app.coregroups.2.policies.4.matchCriteria.1.name = type
# app.coregroups.2.policies.4.matchCriteria.1.description = None
# app.coregroups.2.policies.4.matchCriteria.1.value = WSAF_SIB
# app.coregroups.2.policies.4.matchCriteria.2.name = WSAF_SIB_MESSAGING_ENGINE
# app.coregroups.2.policies.4.matchCriteria.2.description = None
# app.coregroups.2.policies.4.matchCriteria.2.value = NewCoreGroupCluster.@{DYNAMIC#KEYWORD#SERVER_INDEX0}-MyNewBus
# app.coregroups.2.policies.4.matchCriteria.count = 2
# app.coregroups.2.policies.4.preferredServers.names = @{DYNAMIC#KEYWORD#PREFERRED_SERVER_LIST}
#
#-----------------------------------------------------------------------------------------
# Dynamically determining which coregroup to work with
#
# In some cases, you might be setting up services for a cluster and may not be sure
# which coregroup it belongs to.  Instead of specifiying a coregroup name
# you can use the @CLUSTERCOREGROUP macro to dynamically determine which
# coregroup to update.
#
# app.coregroups.1.name = @CLUSTERCOREGROUP(cluster-name)
# ...
#
#-------------------------------------------------------------------------------
# Deleting core group configurations
# 
# This script supports deletions of core groups and core group policies. The deletion
# instructions are processed after the other core group instructions. This allows the
# core group members to be moved to a different core group before a core group is 
# deleted.
# 
# Deletion Example 1: Removing core group policy definitions
# 
# del.coregroups.1.name = DefaultCoreGroup
# del.coregroups.1.deleteCoreGroup = false
#
# del.coregroups.1.policies.1.name = DeleteThisPolicy
# del.coregroups.1.policies.1.deletePolicy = true
#
# del.coregroups.1.policies.2.name = @ITERATE(*OtherDeletion*)
# del.coregroups.1.policies.2.deletePolicy = true
#
# Deletion Example 2: removing a core group
# del.coregroups.2.name = DeleteThisCoreGroup
# del.coregroups.2.deleteCoreGroup = true
# 
###########################################################################################

#-----------------------------------------------------------------------------------------------------------------
# processOneLineServerParmForCoreGroupSettings
#
# This utility method will build a list of "server-name servernode" strings [ "server1 node1" "server2 node2" ...]
# from either a supplied list of names or special macro settings such as 
#  
#    @NODEAGENTS
#    @NODEAGENTS(ALL)
#    @NODEAGENTS(cluster-name-1 [,cluster-name-2,...])
#    @CLUSTERMEMBERS(cluster-name,ALL)
#    @CLUSTERMEMBERS(cluster-name,count)
#-----------------------------------------------------------------------------------------------------------------
def processOneLineServerParmForCoreGroupSettings(oneLine):
  _app_trace("processOneLineServerParmForCoreGroupSettings(%s)"%oneLine,"entry")
  retval = []
  
  try:
    nodemacro = oneLine.find("@NODEAGENTS")
    clustermacro = oneLine.find("@CLUSTERMEMBERS")
    
    if (nodemacro >= 0):
      # See if any parameters were passed
      nodeparms = parseFunctionParms(oneLine)
      if (len(nodeparms) ==0 or (len(nodeparms) == 1 and  nodeparms[0] == "ALL")):
        # Need to build a list of all nodeagents
        managedNodeList = AdminTask.listManagedNodes().split(progInfo['line.separator'])
        for nodename in managedNodeList:
          serverstring = "nodeagent %s" % nodename
          retval.append(serverstring)
          
      else:
        # Parameters are a list of clusters, we'll use the nodeagents from nodes where
        # cluster members are defined
        for cname in nodeparms:
          nodelist = getClusterMemberNodeList(cname)
          for node in nodelist:
            serverstring = "nodeagent %s" % node
            if (serverstring not in retval):
              retval.append(serverstring)
    elif (clustermacro >= 0):
      clusterparms = parseFunctionParms(oneLine)
      cmembers = getClusterMemberList(clusterparms[0])
      memcount = len(cmembers)
      if (len(clusterparms) == 2):
        if (clusterparms[1] != "ALL"):    
          memcount = int(clusterparms[1])
          if (memcount > len(cmembers)):
            memcount = len(cmembers)
      # Now add the designated number of members to this list in the format
      idx = 0;
      for mtuple in cmembers:
        serverstring = "%s %s" % (mtuple[0],mtuple[1])
        retval.append(serverstring)
        idx += 1
        if (idx >= memcount):
          break
    else:
      #print oneLine
      # Parse string as literal list
      servertokens = oneLine.split(" ")
      #print "servertokens: %s" % servertokens
      idx = 0
      while (idx < len(servertokens)):
        serverstring = "%s %s" % (servertokens[idx],servertokens[idx+1])
        retval.append(serverstring)
        idx += 2
      
  except:
    _app_trace("Unexpected error in processOneLineServerParmForCoreGroupSettings","exception")
    raise StandardError("Unexpected error in processOneLineServerParmForCoreGroupSettings")
  
  _app_trace("processOneLineServerParmForCoreGroupSettings(retval = %s)"%retval,"exit")
  return retval

#------------------------------------------------------------------------------------------
# createServerListFromProperties
#
# This utility method will build a list of "server-name servernode" strings [ "server1 node1" "server2 node2" ...]
# from coregroup properties that could be a cgInfo dictionary or the properties returned from
# 
#------------------------------------------------------------------------------------------
def createServerListFromProperties(prop, prefix):
  _app_trace("createServerListFromProperties(prop, %s)" % prefix, "entry")
  retval = []
  try:
      count = prop.get("%s.count" % prefix)
      if (count == None):
        # There just may not be any servers in this list
        retval = []
      else:
        # Iterate through servers
        for idx in range(1,int(count)+1):
            serverName = prop.get("%s.%d.serverName" % (prefix,idx))
            nodeName = prop.get("%s.%d.nodeName" % (prefix,idx))
            
            if (isEmpty(serverName) or isEmpty(nodeName)):
              # partial list?
              continue
            
            serverName = substituteDynamicValues("serverName", serverName)
            nodeName = substituteDynamicValues("nodeName", nodeName)
            
            if (isEmpty(serverName) or isEmpty(nodeName)):
                _app_message("Missing serverName properties in core group configuration")
                exit()
            
            retval.append("%s %s" % (serverName, nodeName))
        
  except:
    _app_trace("Unexpected error building coregroup server list","exception")
    _app_message("Unexpected error building coregroup server list")
    exit()
  
  _app_trace("createServerListFromProperties(result = %s)" % retval, "exit")
  return retval

#------------------------------------------------------------------------------------------
# createMatchCriteriaListFromProperties
#
# This function parses a property list representation of match criteria and builds 
# a list representation in the [ [criteriaName1, criteriaValue1, criteriaDescription1], ...]
# format.
#
# Parameters:
#    prop - dictionary/Map with match criteria in this format:
#             [prefix].1.name = criteriaName1
#             [prefix].1.description = criteriaDescription1
#             [prefix].1.value = criteriaValue1
#
#             ...
#             [prefix].count = total match criteria count
#
#   prefix - the prefix to use
#
# Returns a list in this format:
#     [ [criteriaName1, criteriaValue1, criteriaDescription1], ...]
#   
#
#------------------------------------------------------------------------------------------
def createMatchCriteriaListFromProperties(prop,prefix):
  _app_trace("createMatchCriteriaListFromProperties(prop,%s)" % prefix, "entry")
  retval = []
  try:
      count = prop.get("%s.count" % prefix)
      if (count == None):
        # There just may not be any servers in this list
        retval = []
      else:
        # Iterate through servers
        for idx in range(1,int(count)+1):
            criteriaName = prop.get("%s.%d.name" % (prefix, idx))
            if (criteriaName == None): continue
            criteriaName  = substituteDynamicValues("criteriaName",criteriaName)
            
            criteriaValue = prop.get("%s.%d.value" % (prefix, idx))
            if (criteriaValue == None): criteriaValue = ""
            criteriaValue = substituteDynamicValues("criteriaValue",criteriaValue)
            
            criteriaDescription = prop.get("%s.%d.description" % (prefix,idx))
            if (criteriaDescription == None): criteriaDescription = ""
            criteriaDescription = substituteDynamicValues("criteriaDescription",criteriaDescription)
            
            retval.append([criteriaName, criteriaValue, criteriaDescription])
  
  except:
    _app_trace("Unexpected error in createMatchCriteriaListFromProperties","exception")
    raise StandardError("Unexpected error in createMatchCriteriaListFromProperties")
  
  _app_trace("createMatchCriteriaListFromProperties(retval = %s)" % retval,"exit")
  return retval


#--------------------------------------------------------------------------------------------
# compareMatchCriteria
#
# Utility method that compares match criteria lists in the [ [name val desc] [name2 val2 desc2] ] 
# list format.
#--------------------------------------------------------------------------------------------
def compareMatchCriteria(inputCriteriaList, existingCriteriaList):
  _app_trace("compareMatchCriteria(%s,%s)" % (inputCriteriaList, existingCriteriaList),"entry")
  compResult = 0
  
  if (inputCriteriaList != None and   existingCriteriaList != None):
      if (len(inputCriteriaList) != len(existingCriteriaList)):
          compResult = 1
      else:
          # Iterate
          cidx = 0
          for criteria in inputCriteriaList: 
              cname = criteria[0]
              cval = criteria[1]
              cdesc = criteria[2]
              
              matchCriteria = None
              for ecriteria in existingCriteriaList:
                ename = ecriteria[0]
                eval = ecriteria[1]
                edesc = ecriteria[2]
                
                if (ename == cname):
                  matchCriteria = ecriteria
                  
                  if (eval != cval or edesc != cdesc):
                      compResult = 1
                      break
              
              if (matchCriteria == None):
                # Criteria name did not match any of the existing criteria
                compResult = 1
              
              if (compResult):
                  break
  elif (inputCriteriaList == None and   existingCriteriaList == None):
    compResult = 0
  else:
    compResult = 1
  
  _app_trace("compareMatchCriteria(result = %d)" % compResult, "exit")
  return compResult

#--------------------------------------------------------------------------------------------
# needToUpdatePreferredServerList
#
# Compares two lists of "name node" strings to see if they are identical.  Lists must be 
# in the same order.
#
# Returns 0 - lists are identical no need to update
#         1 - Lists are different, an update is needed
#--------------------------------------------------------------------------------------------
def needToUpdatePreferredServerList(inputList, existingList): 

    # See if the two are identical
    updateFlag = 0
    if (inputList == None and existingList == None):
        updateFlag = 0
    elif (inputList != None and existingList == None):
        updateFlag = 1
    elif (inputList != None and existingList != None):
        if (len(inputList) != len(existingList)):
          updateFlag = 1
        else:
          pcidx = 0
          while (pcidx < len(inputList)):
            if (inputList[pcidx] != existingList[pcidx]):
                updateFlag = 1
                break
            pcidx = pcidx + 1
    
    return updateFlag


#------------------------------------------------------------------------------------------
# findPolicyInExistingProps
#
# Searches the properties set loaded by getCoreGroupProperties for the settings for a
# specific policy. If found, returns the prefix "app.coregroup.policies.[idx]" for these
# properties.  If not found, None is thrown.
#------------------------------------------------------------------------------------------
def findPolicyInExistingProps(policyName, policyType, existingProps):
  _app_trace("findPolicyInExistingProps(%s,%s,existingProps)" % (policyName, policyType),"entry")
  retval = None
  try:
    count = existingProps.get("app.coregroup.policies.count")
    if (count != None):
      for idx in range(1, int(count)+1):
          tempPolicyName = existingProps.get("app.coregroup.policies.%d.name" % idx)
          tempPolicyType = existingProps.get("app.coregroup.policies.%d.policyType" % (idx))
          
          if (tempPolicyName == policyName and tempPolicyType == policyType):
              retval = "app.coregroup.policies.%d" % (idx)
              break
  except:
    _app_trace("Unexpected error in findPolicyInExistingProps","exception")
    raise StandardError("Unexpected error in findPolicyInExistingProps")
  
  _app_trace("findPolicyInExistingProps(retval = %s)" % retval,"exit")
  return retval

#------------------------------------------------------------------------------------------
# processExistingCoreGroupSettings
# 
# Processes the settings in the cgInfo dictionary for existing core groups. This
# function will only do necessary updates and ignore settings that are identical to current
# values.
#------------------------------------------------------------------------------------------
def processExistingCoreGroupSettings(cgInfo,cgName,cgId, prefix, existingProps):
  _app_trace("processExistingCoreGroupSettings(%s, %s, %s,existingProps)" % (cgName,cgId, prefix),"entry")
  
  try:
    baseProps = getPropListDifferences(cgInfo,prefix,existingProps,"app.coregroup")
    customProps = getPropListDifferences(cgInfo,"%s.customProperties" % prefix, existingProps,"app.coregroup.customProperties")
    livenessProps = getPropListDifferences(cgInfo,"%s.liveness" % prefix, existingProps,"app.coregroup.liveness")
    livenessCustomProps = getPropListDifferences(cgInfo,"%s.liveness.customProperties"%prefix,existingProps,"app.coregroup.liveness.customProperties")
    
    # Remove keys from baseProps that we do not handle
    skipProps = ["name","coreGroupUID","multiCastGroupIPEnd","multiCastGroupIPStart","multiCastPort"]
    for key in skipProps:
        baseProps.remove(key)
    
    if (baseProps.size() > 0 or customProps.size() > 0 or livenessProps.size() or livenessCustomProps.size() > 0):
        # Need to do update
        retval = modifyCoreGroup(cgName, cgId, baseProps, customProps, livenessProps, livenessCustomProps)
        if (isEmpty(retval)):
            _app_message("Error updating coregroup %s" % cgName)
            exit()
        else:
            _app_message("Updated base properties for coregroup %s" % cgName)
        
    else:
        _app_message("No need to update base core group properties for %s" % cgName)
      
        
    # Now time for preferred coordinator list
    # This can in two different property formats - a single line that supports Macros or a list
    oneLine = substituteDynamicValues("%s.preferredCoordinatorServers.names"%prefix, cgInfo.get("%s.preferredCoordinatorServers.names"%prefix,""))
    if (not isEmpty(oneLine)):
      preferredCoordinatorList = processOneLineServerParmForCoreGroupSettings(oneLine)
    else:
      preferredCoordinatorList = createServerListFromProperties(cgInfo,"%s.preferredCoordinatorServers" % prefix)
      
    existingPreferredCoordinatorList = createServerListFromProperties(existingProps,"app.coregroup.preferredCoordinatorServers")
    
    # See if the two are identical
    updatePC = needToUpdatePreferredServerList(preferredCoordinatorList, existingPreferredCoordinatorList)
    
    if (len(preferredCoordinatorList) > 0 and updatePC == 1) :
        # Need to update the preferredCoordinatorList
        retval = updateCoreGroupPreferredCoordinatorList(cgName, cgId, preferredCoordinatorList)
        if (isEmpty(retval)):
            _app_message("Unable to update Core Group preferred coordinator list for core group %s" % cgName)
            exit()
        else:
            _app_message("Updated Core Group preferred coordinator list for core group %s" % cgName)
    else:
        _app_message("No need to update preferred coordinator list for core group %s" % cgName)
        
    
    # Now we need to process the policies for this core group
    policyCount = int(cgInfo.get("%s.policies.count" % prefix, "0"))
    for pidx in range(1,policyCount+1):
          policyName = cgInfo.get("%s.policies.%d.name" % (prefix,pidx),"")
          policyType = cgInfo.get("%s.policies.%d.policyType" % (prefix,pidx),"")
          iterateClusterMembers = cgInfo.get("%s.policies.%d.iterateClusterMembers" % (prefix,pidx),"")
          
          if (isEmpty(policyName) or isEmpty(policyType)):
              # partial list
              continue
              
          if (isEmpty(iterateClusterMembers)):
            # Standard policy definition
            
            # See if the policy already exists
            policyId = findPolicyId(cgId, policyName, policyType)
            if (policyId == None):
              # This is a new policy being created for the core group
              policyId = processNewCoreGroupPolicySettings(cgInfo,cgName, cgId, policyName, policyType, "%s.policies.%d" % (prefix, pidx))
            else:
              processExistingCoreGroupPolicySettings(cgInfo,cgName,cgId, policyId, policyName, policyType, "%s.policies.%d" % (prefix,pidx), existingProps)
          else:
            # Not so simple, we'll create a policy that corresponds to each member in a cluster
            iterateClusterForPolicyCreation(cgInfo,iterateClusterMembers, policyName, policyType, cgName, cgId, prefix, pidx, existingProps)
              
        
  except:
    _app_trace("Unexpected error in processExistingCoreGroupSettings()","exception")
    exit()
  
  _app_trace("processExistingCoreGroupSettings()","exit")
  
#-----------------------------------------------------------------------------------------------
# processExistingCoreGroupPolicySettings
#
# Updates core group policy settings for existing core groups.
#-----------------------------------------------------------------------------------------------
def processExistingCoreGroupPolicySettings(cgInfo,cgName, cgId, policyId, policyName, policyType, prefix, existingProps):
  
  _app_trace("processExistingCoreGroupPolicySettings(%s,%s,%s,%s,%s,%s,existingProps)" % (cgName,cgId, policyId, policyName, policyType, prefix), "entry")
  try:
      existingPrefix = findPolicyInExistingProps(policyName, policyType, existingProps)
      if (existingPrefix == None):
          raise StandardError("Unable to find existing properties for %s %s" % (policyType, policyName))
          
      
      policyProps = getPropListDifferences(cgInfo,"%s" % (prefix), existingProps, existingPrefix)
      policyCustomProps = getPropListDifferences(cgInfo,"%s.customProperties" % (prefix),existingProps, "%s.customProperties" %  existingPrefix)
      
      # Preferred server can be in the numbered list format of a single .names property which supports macros
      singleLine = substituteDynamicValues("preferredServers.names",cgInfo.get("%s.preferredServers.names" % (prefix),""))
      if (not isEmpty(singleLine)):
        preferredServerList = processOneLineServerParmForCoreGroupSettings(singleLine)
      else:  
        preferredServerList = createServerListFromProperties(cgInfo,"%s.preferredServers" % (prefix))
      existingPreferredServerList = createServerListFromProperties(existingProps,"%s.preferredServers" % (existingPrefix))
      
      if (preferredServerList != None and len(preferredServerList) > 0):
          # Compare against existing
          compFlag = needToUpdatePreferredServerList(preferredServerList, existingPreferredServerList)
          if (compFlag == 0):
              # No difference, set list to None so we wont process it
              preferredServerList = None
      else:
          preferredServerList = None
      
      # @TODO - How should we handle deletions of criteria? If there's a diff - erase existing and rebuild?
      criteriaList = createMatchCriteriaListFromProperties(cgInfo,"%s.matchCriteria" % (prefix))
      
      
      if (len(criteriaList) > 0):
        # Now pull the current settings for the match criteria  
        getMatchCriteriaPropertiesForPolicy(existingProps,policyId,existingPrefix)
        existingCriteriaList = createMatchCriteriaListFromProperties(existingProps,"%s.matchCriteria" % existingPrefix)
        
        if (compareMatchCriteria(criteriaList, existingCriteriaList) == 0):
            # Match, no need to update
            criteriaList = None
      else:
        # Une none to indicate no update
        criteriaList = None
          
      if (len(policyProps) > 0 or len(policyCustomProps) > 0 or preferredServerList != None or criteriaList != None ):
          retval = updateCoreGroupPolicy(cgId, policyId, policyProps, policyCustomProps,preferredServerList, criteriaList)
  
          if (isEmpty(retval)):
              _app_message("Unable to update %s %s for core group %s" % (policyType, policyName, cgName))
              exit()
          else:
              _app_message("Updated %s %s for core group %s" % (policyType, policyName, cgName))
      else:
          _app_message("No need to update %s %s for core group %s" % (policyType, policyName, cgName))
                  
  except:
    _app_trace("Unexpected error in processExistingCoreGroupPolicySettings","exception")
    raise StandardError("Unexpected error in processExistingCoreGroupPolicySettings")
    
  _app_trace("processExistingCoreGroupPolicySettings()", "exit")

#-----------------------------------------------------------------------------------------------
# processNewCoreGroupPolicySettings
#
# Processes the settings in cgInfo for a new policy. 
#-----------------------------------------------------------------------------------------------
def processNewCoreGroupPolicySettings(cgInfo,cgName, cgId, policyName, policyType, prefix):

  _app_trace("processNewCoreGroupPolicySettings(cgInfo,%s,%s,%s,%s,%s)" % (cgName, cgId, policyName, policyType, prefix), "entry")
  retval = None
  
  try:
      policyProps = getPropList(cgInfo,prefix,1)
      policyCustomProps = getPropList(cgInfo,"%s.customProperties" % (prefix),1)
      
      # The list can be in two formats, check the "one line" version first
      singleLine = substituteDynamicValues("preferredServers.names",cgInfo.get("%s.preferredServers.names" % (prefix),""))
      if (not isEmpty(singleLine)):
        preferredServerList = processOneLineServerParmForCoreGroupSettings(singleLine)
      else:
        preferredServerList = createServerListFromProperties(cgInfo,"%s.preferredServers" % (prefix))
        
      if (preferredServerList != None and len(preferredServerList) == 0):
          preferredServerList = None
      criteriaList = createMatchCriteriaListFromProperties(cgInfo,"%s.matchCriteria" % (prefix))
          
      policyId = createCoreGroupPolicy(cgId, policyName, policyType, policyProps, policyCustomProps,preferredServerList, criteriaList)
          
      if (isEmpty(policyId)):
          _app_message("Unable to create %s %s for core group %s" % (policyType, policyName, cgName))
          exit()
      else:
          _app_message("Created %s %s for core group %s" % (policyType, policyName, cgName))
      
      retval = policyId             
  except:
      _app_trace("Unexpected error creating new core group policy", "exception")
      _app_message("Unexpected error creating new core group policy")
      exit()
  
  _app_trace("processNewCoreGroupPolicySettings(retval = %s)" % retval, "exit")
  return retval
    

#------------------------------------------------------------------------------------------
# iterateClusterForPolicyCreation
#
# This function does the special processing for iterateClusterMembers. The property settings
# for a policy are repeatedly evaluated for each cluster member. The cluster members processed
# can be restricted to those on a certain node by iterateClusterMembers.nodes instruction 
# property.
#
# For each cluster member being processed, this function sets up the keyword values that
# can be referenced by the @{DYNAMIC...} property value macro. The policy properties are 
# reloaded on each iteration with the appropriate values replaced.
#------------------------------------------------------------------------------------------
def iterateClusterForPolicyCreation(cgInfo,memberCluster, policyName, policyType, cgName, cgId, prefix, pidx, existingProps=None):
  
  _app_trace("iterateClusterForPolicyCreation()","entry")
  try:
      _app_message("Building dynamic policies for cluster %s" % memberCluster)
      
      iterateNodes = getSortedListFromProperty(cgInfo,"%s.policies.%d.iterateClusterMembers.nodes" % (prefix,pidx))
      determineSecondaries = cgInfo.get("%s.policies.%d.iterateClusterMembers.determineSecondaries" % (prefix,pidx),"false")
      processedNodes = []
      
      originalPolicyName = policyName
      
      clusterId = AdminConfig.getid("/ServerCluster:%s/" % memberCluster)
      
      if (isEmpty(clusterId)):
        _app_message("Cluster %s specified in iterateClusterMembers settings was not found" % memberCluster)
        raise StandardError("Cluster %s specified in iterateClusterMembers settings was not found" % memberCluster)
      
      
      # Build a list of clusterMembers to be processed. If the nodes property was specified
      # we will also add the cluster members that don't match the node list to a spare 
      # member list
      
      clusterMembers = wsadminToList(AdminConfig.showAttribute(clusterId,"members"))
      clusterMemberInfo = []
      spareMemberInfo = []
      for clusterMember in clusterMembers:
          if (isEmpty(clusterMember)):
              continue
          
          mName = AdminConfig.showAttribute(clusterMember,"memberName")
          mNode = AdminConfig.showAttribute(clusterMember,"nodeName")
          
          # If iterateNodes is non-empty, we'll limit what get's put in clusterMemberInfo
          if (len(iterateNodes) > 0):
            if (mNode in iterateNodes and mNode not in processedNodes):
              clusterMemberInfo.append("%s %s" % (mNode, mName))
              processedNodes.append(mNode)
            else:
              # This server will not be the primary preferred, but is a secondary preferred
              spareMemberInfo.append("%s %s" % (mNode, mName))
          else:
            clusterMemberInfo.append("%s %s" % (mNode, mName))
            
      #end for each clusterMember
      
      # Sort the results
      clusterMemberInfo.sort()
      
      # Assign the spares to build out a preferred server list for each policy
      spareMap = {}
      
      # Seed the dictionary that we'll use to build multiple-preferred server information
      for cmi in clusterMemberInfo:
        # Our sorted list uses node-server, but parsed line uses "server node"
        nodeServers = cmi.split(" ")
        spareMap[cmi] = "%s %s" % (nodeServers[1], nodeServers[0])
          
      if (len(spareMemberInfo) > 0 and determineSecondaries.lower() == "true"):
        spareMemberInfo.sort()
                
        # Now process the spareMemberInfo by distributing it
        # across the lists that start with the primary preferred server  
        while (len(spareMemberInfo) > 0):
          for cmi in clusterMemberInfo:
            if (len(spareMemberInfo) > 0):
                nextServer = spareMemberInfo.pop(0)
                curval = spareMap.get(cmi)
                
                # Our sorted lists are node-server, but one-line syntax is server-node
                nodeServers = nextServer.split(" ")
                spareMap[cmi] = "%s %s %s" % (curval, nodeServers[1], nodeServers[0])
        #endwhile
        
      #end if determineSecondaries processing needed
      
      # Now iterate through sorted list and build a policy that corresponds to each
      # cluster member
      sidx = 0
      for cmi in clusterMemberInfo:

          sidx = sidx + 1
          nodeServer = cmi.split(" ")
          mNode = nodeServer[0]
          mName = nodeServer[1]
          
          serverId = AdminConfig.getid("/Node:%s/Server:%s/" % (mNode,mName))
          
          if (isEmpty(serverId)):
              _app_message("Unable to find server ID for %s %s" % (mNode,mName))
              exit()
          
          nodeId = AdminConfig.getid("/Node:%s/"% mNode)
          
          setDynamicId("CURRENT_SERVER_NAME",mName)
          setDynamicId("CURRENT_NODE_NAME",mNode)
          setDynamicId("CURRENT_CLUSTER_NAME",memberCluster)
          setDynamicId("CURRENT_SERVER", serverId)
          setDynamicId("CURRENT_CLUSTER", clusterId)
          setDynamicId("CURRENT_NODE", nodeId)
          setDynamicId("SERVER_INDEX", str(sidx).zfill(3))
          setDynamicId("SERVER_INDEX0", str(sidx-1).zfill(3))
          
          setDynamicId("PREFERRED_SERVER_LIST",spareMap[cmi])
          
          policyName= substituteDynamicValues("policyName", originalPolicyName);
          
          if (existingProps == None):
            policyId = processNewCoreGroupPolicySettings(cgInfo,cgName, cgId, policyName, policyType, "%s.policies.%d" % (prefix, pidx))
          else:
            # See if the policy already exists
            policyId = findPolicyId(cgId, policyName, policyType)
            if (policyId == None):
              # This is a new policy being created for the core group
              policyId = processNewCoreGroupPolicySettings(cgInfo,cgName, cgId, policyName, policyType, "%s.policies.%d" % (prefix, pidx))
            else:
              processExistingCoreGroupPolicySettings(cgInfo,cgName,cgId, policyId, policyName, policyType, "%s.policies.%d" % (prefix,pidx), existingProps)
            #endelse
          #endelse
      #end for         
      
      # Clear dynamic values
      setDynamicId("CURRENT_SERVER_NAME","")
      setDynamicId("CURRENT_NODE_NAME","")
      setDynamicId("CURRENT_CLUSTER_NAME","")
      
      setDynamicId("CURRENT_SERVER", "")
      setDynamicId("CURRENT_CLUSTER", "")
      setDynamicId("CURRENT_NODE", "")
      setDynamicId("SERVER_INDEX", "")  
      setDynamicId("SERVER_INDEX0", "")
  
  except:
    _app_trace("Unexpected error in iterateClusterForPolicyCreation","exception")
    raise StandardError("Unexpected error in iterateClusterForPolicyCreation")
  
  _app_trace("iterateClusterForPolicyCreation()","exit")


#-----------------------------------------------------------------------------------------------
# processNewCoreGroupSettings
#
# Processes the advanced settings for a core group that was previously created during the current
# wsadmin session.
#
# Parameters:
#   cgName - name of the coregroup
#   cgId - Configuration Id of the coregroup
#   prefix - prefix for coregroups properties in cgInfo
#-----------------------------------------------------------------------------------------------
def processNewCoreGroupSettings(cgInfo,cgName,cgId, prefix):
  
  
  _app_trace("processNewCoreGroupSettings(%s,%s,%s)" % (cgName, cgId,prefix),"entry")
  
  try:
      # coordinator list can be in one-line or indexed format
      preferredCoordinatorList = None
      oneLine = substituteDynamicValues("preferredCoordinatorServers.names",cgInfo.get("%s.preferredCoordinatorServers.names"%prefix,""))
      if (not isEmpty(oneLine)):
        preferredCoordinatorList = processOneLineServerParmForCoreGroupSettings(oneLine)
      else:
        preferredCoordinatorList = createServerListFromProperties(cgInfo,"%s.preferredCoordinatorServers" % prefix)
      if (len(preferredCoordinatorList) > 0):
        # Need to update the preferredCoordinatorList
        retval = updateCoreGroupPreferredCoordinatorList(cgName, cgId, preferredCoordinatorList)
        if (isEmpty(retval)):
            _app_message("Unable to update Core Group preferred coordinator list for core group %s" % cgName)
            exit()
        else:
            _app_message("Updated Core Group preferred coordinator list for core group %s" % cgName)
            
      # Now we need to process the policies for this core group
      policyCount = int(cgInfo.get("%s.policies.count" % prefix, "0"))
      for pidx in range(1,policyCount+1):
          policyName = cgInfo.get("%s.policies.%d.name" % (prefix,pidx),"")
          policyType = cgInfo.get("%s.policies.%d.policyType" % (prefix,pidx),"")
          iterateClusterMembers = cgInfo.get("%s.policies.%d.iterateClusterMembers" % (prefix,pidx),"")
          
          if (isEmpty(policyName) or isEmpty(policyType)):
              # Partial list
              continue
          if (isEmpty(iterateClusterMembers)):
              # Nice and simple, just process the properties
              policyId = processNewCoreGroupPolicySettings(cgInfo,cgName, cgId, policyName, policyType, "%s.policies.%d" % (prefix, pidx))
          else:
              # Not so simple, we'll create a policy that corresponds to each member in a cluster
              iterateClusterForPolicyCreation(cgInfo,iterateClusterMembers, policyName, policyType, cgName, cgId, prefix, pidx)
              
              
          
          
  except:
    _app_trace("Unexpected error processing new core group settings","exception")
    _app_message("Unexpected error processing new core group settings")
    exit()
  
  _app_trace("processNewCoreGroupSettings()","exit")


#--------------------------------------------------------------------------------
# processNewCoreGroupCreation
# 
# Performs the task of creating a new core group based on settings in the cgInfo
# dictionary.
#
# Parameters:
#     cgName - Name of the core group to create
#     prefix - property prefix for this core group  
#--------------------------------------------------------------------------------
def processNewCoreGroupCreation(cgInfo,cgName, prefix):
  
  
  _app_trace("processNewCoreGroupCreation(%s,%s)" % (cgName, prefix),"entry")
  
  try:
    baseProps = getPropList(cgInfo,prefix)
    customProps = getPropList(cgInfo,"%s.customProperties" % prefix)
    livenessProps = getPropList(cgInfo,"%s.liveness" % prefix)
    livenessCustomProps = getPropList(cgInfo,"%s.liveness.customProperties"%prefix)
    
    newId = createCoreGroup(cgName, baseProps, customProps, livenessProps, livenessCustomProps)
    if (isEmpty(newId)):
        _app_message("Unable to create core group %s" % cgName)
        exit()
    else:
        _app_message("Created core group %s" % cgName)
        
  except:
    _app_trace("Unexpected error in processNewCoreGroupCreation","exception")
    exit()
  
  _app_trace("processNewCoreGroupCreation()","exit")


#----------------------------------------------------------------------------
# processCoreGroupAdditions
#
# This function handles the instructions that can be used to servers or
# clusters to the coregroup.
#
# Parameters:
#   cgInfo - the dictionary to pull settings from
#   cgName - The coregroup being processed
#   prefix - the property prefix being processed
#----------------------------------------------------------------------------
def processCoreGroupAdditions(cgInfo, cgName, prefix):
  _app_trace("processCoreGroupAdditions(cgInfo,%s)" % prefix,"entry")
  try:
    addcount = int(cgInfo.get("%s.addCoreGroupMember.count"%prefix,"0"))
    if (addcount > 0):
      for idx in range(1,addcount+1):
        newCluster = cgInfo.get("%s.addCoreGroupMember.%d.cluster" % (prefix,idx),"")
        newServer = cgInfo.get("%s.addCoreGroupMember.%d.server" % (prefix,idx),"")
        newNode = cgInfo.get("%s.addCoreGroupMember.%d.node" % (prefix,idx),"")
        newList = cgInfo.get("%s.addCoreGroupMember.%d.names" % (prefix,idx),"")
        
        if (not isEmpty(newCluster)):
          oldCoreGroupName,newCoreGroupName=addClusterToCoreGroup(newCluster, cgName)
          if (oldCoreGroupName == newCoreGroupName):
            _app_message("Cluster %s was already a member of core group %s" % (newCluster,newCoreGroupName))
          else:
            _app_message("Cluster %s was moved from core group %s to core group %s" % (newCluster,oldCoreGroupName,newCoreGroupName))
          
        elif (not isEmpty(newServer) and not isEmpty(newNode)):
          oldCoreGroupName,newCoreGroupName=addServerToCoreGroup(newServer,newNode,cgName)
          if (oldCoreGroupName == newCoreGroupName):
            _app_message("Server %s\%s was already a member of core group %s" % (newNode,newServer,newCoreGroupName))
          else:
            _app_message("Server %s\%s was moved from core group %s to core group %s" % (newNode,newServer,oldCoreGroupName,newCoreGroupName))
        elif (not isEmpty(newList)):
            serverList = processOneLineServerParmForCoreGroupSettings(newList)
            for serverString in serverList:
              serverTokens = serverString.split(" ")
              newServer = serverTokens[0]
              newNode = serverTokens[1]
              oldCoreGroupName,newCoreGroupName=addServerToCoreGroup(newServer,newNode,cgName)
              if (oldCoreGroupName == newCoreGroupName):
                _app_message("Server %s\%s was already a member of core group %s" % (newNode,newServer,newCoreGroupName))
              else:
                _app_message("Server %s\%s was moved from core group %s to core group %s" % (newNode,newServer,oldCoreGroupName,newCoreGroupName))

  except:
    _app_trace("Unexpected error in processCoreGroupAdditions()","exception")
    exit()
    
  _app_trace("processCoreGroupAdditions()","exit")


#-------------------------------------------------------------------------------
# This section processes deletion instructions for core groups or 
# attributes of a coregroup. Deletions are processed last.
#-------------------------------------------------------------------------------
def processCoreGroupDeletions(cgInfo):
  _app_trace("ProcessCoreGroupDeletions(cgInfo)","entry")
  
  try:
    delCount = int(cgInfo.get("del.coregroups.count","0"))
    if (delCount > 0):
      for idx in range(1,delCount+1):
        delName = cgInfo.get("del.coregroups.%d.name"%idx,"")
        if (isEmpty(delName)):
          continue
          
        if (delName.find("@CLUSTERCOREGROUP") >= 0):
          # This macro is used to process the coregroup for a specific cluster
          parmList  = parseFunctionParms(delName)
          clusterName = parmList[0]
          delName = getClusterCoreGroup(clusterName)
        
        #See if this is an instruction to delete the coregroup. If so, just do it and get it over with 
        delCoreGroup = cgInfo.get("del.coregroups.%d.deleteCoreGroup"%idx,"false")
        if (delCoreGroup.lower() == "true"):
          # Just delete the coregroup
          if (deleteCoreGroup(delName)):
            _app_message("Core group %s has been deleted"%delName)
          else:
            _app_message("Core group %s is not defined, no deletion is necessary"%delName)
        else:
          # We are processing sub-items of the core group 
          policyCount = int(cgInfo.get("del.coregroups.%d.policies.count" % (idx),"0"))
          if (policyCount > 0):
            for policyIdx in range(1,policyCount+1):
              policyName = cgInfo.get("del.coregroups.%d.policies.%d.name" % (idx,policyIdx),"")
              if (isEmpty(policyName)):
                continue
              
              # The policy will be deleted if deletePolicy directive is "true"
              delPolicy = cgInfo.get("del.coregroups.%d.policies.%d.deletePolicy" % (idx,policyIdx),"false")
              if (delPolicy.lower() == "true"):
                # Delete the policy
                
                if (policyName.find("@ITERATE") >= 0):
                  # Get a list of policies to delete
                  doIterate,patternParm,wildcardParm = parseIterateMacroParms(policyName)
                  policies = findMatchingCoreGroupPolicies(delName, wildcardParm)
                  _app_message("%d policies matched deletion pattern %s for core group %s" % (len(policies),patternParm,delName))
                  if (len(policies) > 0):
                    for policyName in policies.keys():
                      policyId = policies.get(policyName)
                      if (deleteCoreGroupPolicy(delName, policyName,policyId)):
                        _app_message("Policy %s of core group %s has been deleted" % (policyName,delName))
                      else:
                        _app_message("Policy %s of core group %s was not defined (no deletion necessary)" % (policyName,delName))
                else:
                  # Deleting an explicit policy
                  if (deleteCoreGroupPolicy(delName, policyName)):
                    _app_message("Policy %s of core group %s has been deleted" % (policyName,delName))
                  else:
                    _app_message("Policy %s of core group %s was not defined (no deletion necessary)" % (policyName,delName))
                    
              else:
                _app_message("Deletion of Policy sub items is not currently supported")
    
  except:
    _app_trace("Unexpected error in ProcessCoreGroupDeletions","exception")
    exit()
  
  _app_trace("ProcessCoreGroupDeletions(cgInfo)","exit")
  

#----------------------------------------------------------------------------
# processCoreGroupSettings
#
# Processes the settings for core groups in the global configInfo dictionary.
# New core groups were previously created by the processCoreGroupCreation function.
# This function will apply advanced settings to new core groups as well as 
# process updates to previously existing coregroups.
#----------------------------------------------------------------------------
def processCoreGroupSettings():
  global configInfo
  global createdCoreGroupList
  
  _app_trace("processCoreGroupSettings()","entry")
  try:
    count = int(configInfo.get("app.coregroups.count","0"))
    for idx in range(1,count+1):
      prefix = "app.coregroups.%d" % idx
      cgName = configInfo.get("%s.name" % prefix,"")
      if (isEmpty(cgName)):
          continue
          
      if (cgName.find("@CLUSTERCOREGROUP") >= 0):
        # This macro is used to update the coregroup for a specific cluster
        parmList  = parseFunctionParms(cgName)
        clusterName = parmList[0]
        cgName = getClusterCoreGroup(clusterName)
          
       
      processCoreGroupAdditions(configInfo, cgName, prefix)
      
      if cgName in createdCoreGroupList:
        # Stub Coregroup was created in call to processCoreGroupCreation
        cgId = getCoreGroupId(cgName)
        processNewCoreGroupSettings(configInfo,cgName,cgId, prefix)
      else:
          cgId = getCoreGroupId(cgName)
          if (isEmpty(cgId)):
              # Somebody skipped call to processCoreGroupCreation
              _app_message("Core group %s does not exist" % cgName)
              exit()
          else:
              # existing core group
              existingProps = getCoreGroupProperties(cgId)

              processExistingCoreGroupSettings(configInfo,cgName,cgId, prefix, existingProps)       
              
    # Now let's process the deletion of coregroup resources that may be obsolete after
    # the settings have been processed
    processCoreGroupDeletions(configInfo)
     
  except:
    _app_trace("Unexpected error in process coregroup","exception")
    exit()
  
  _app_trace("processCoreGroupSettings()","exit")
  
#----------------------------------------------------------------------------
# processCoreGroupCreation
#
# This function should be called to create basic CoreGroup definitions for new
# servers to be added to.
#----------------------------------------------------------------------------
def processCoreGroupCreation():
  global configInfo
  global createdCoreGroupList
  
  _app_trace("processCoreGroupCreation()","entry")
  try:
    createdCoreGroupList = []
    count = int(configInfo.get("app.coregroups.count","0"))
    for idx in range(1,count+1):
      prefix = "app.coregroups.%d" % idx
      cgName = configInfo.get("%s.name" % prefix,"")
      if (isEmpty(cgName)):
          continue
      
      if (cgName.find("@CLUSTERCOREGROUP") >= 0):
        # This is a dynamic name lookup, just skip it
        continue
      
      cgId = getCoreGroupId(cgName)
      if (isEmpty(cgId)):
          # new coregroup
          processNewCoreGroupCreation(configInfo,cgName, prefix)
          createdCoreGroupList.append(configInfo,cgName)
      else:
          # existing core group
          _app_message("Core group %s already exists, settings will be applied later" % cgName)
          
          
  except:
    _app_trace("Unexpected error in processCoreGroupCreation","exception")
    exit()
  
  _app_trace("processCoreGroupCreation()","exit")

    