################################################################################
# ProcessCustomActions.py - process input properties that define custom actions
# used by Intelligent ManagementHealth Policies
#
# Module entry point: processHealthManagementCustomActions()
#
# Requires: CustomActions.py
#           Utils.py
#
# Property syntax examples:
#
# -- Creating or modifying Custom Actions
#
# app.im.customActions.1.name = GrabDumps4
# app.im.customActions.1.definitions.type = NamedProcessDef
# app.im.customActions.1.definitions.prop.executableName = grabDumps.sh
# app.im.customActions.1.definitions.prop.name = GrabDumps4
# app.im.customActions.1.definitions.prop.osnames = unix
# app.im.customActions.1.definitions.prop.workingDirectory = /opt/was/scripts
#
# app.im.customActions.2.name = MyClassAction3
# app.im.customActions.2.definitions.type = NamedJavaProcessDef
# app.im.customActions.2.definitions.prop.executableArguments = -Dude -take -some -action $MyUser $MyPassword;-moreoptions yes
# app.im.customActions.2.definitions.prop.executableName = com.ibm.issw.jjm.TakeAction
# app.im.customActions.2.definitions.prop.executableTarget = /opt/was/actions
# app.im.customActions.2.definitions.prop.executableTargetKind = JAVA_CLASS
# app.im.customActions.2.definitions.prop.name = MyClassAction3
# app.im.customActions.2.definitions.prop.osnames = unix
# app.im.customActions.2.definitions.prop.passwordVal = *****
# app.im.customActions.2.definitions.prop.passwordVar = *****
# app.im.customActions.2.definitions.prop.usernameVal = wsadmin
# app.im.customActions.2.definitions.prop.usernameVar = MyUser
# app.im.customActions.2.definitions.prop.workingDirectory = /opt/was/actions
#
# app.im.customActions.3.name = MyJarAction2
# app.im.customActions.3.definitions.type = NamedJavaProcessDef
# app.im.customActions.3.definitions.prop.executableArguments = -NewOption1;-NewOption2
# app.im.customActions.3.definitions.prop.executableName = MyActions.jar
# app.im.customActions.3.definitions.prop.executableTarget = /opt/was/action/jars
# app.im.customActions.3.definitions.prop.executableTargetKind = EXECUTABLE_JAR
# app.im.customActions.3.definitions.prop.name = MyJarAction
# app.im.customActions.3.definitions.prop.osnames = unix
# app.im.customActions.3.definitions.prop.workingDirectory = /opt/was/action
#
# app.im.customActions.count = 3
#
# -- Syntax for deleting custom actions
#
# del.im.customActions.1.name = GrabDumps3
# del.im.customActions.2.name = MyClassAction2
#
# del.im.customActions.count = 2
################################################################################

#-------------------------------------------------------------------------------
# processHealthManagementCustomActionDeletions
#
# Process the settings that specify deletions of Custom Actions
#-------------------------------------------------------------------------------
def processHealthManagementCustomActionDeletions(actionInfo):

  _app_entry("processHealthManagementCustomActionDeletions(actionInfo)")
  try:
    caCount = int(actionInfo.get("del.im.customActions.count",0))
    if (caCount > 0):
      for idx in range(1,caCount+1):
        prefix = "del.im.customActions.%d" % idx
        caName = actionInfo.get("%s.name" % prefix)
        if (isEmpty(caName)):
          # Partial list
          continue
        else:
          retval = deleteHealthManagementCustomAction(caName)
          if (isEmpty(retval)):
            _app_message("Custom Action %s did not exist - no need to delete" % caName)
          else:
            _app_message("Custom Action %s has been deleted" % caName)
          
  except:
    _app_exception("Unexpected error in processHealthManagementCustomActionDeletions(actionInfo)")
    
  _app_exit("processHealthManagementCustomActionDeletions()")  

#-------------------------------------------------------------------------------
# processHealthManagementCustomAction
#
# Process the settings for a single Custom Action definition
#
# Parameters:
#    actionInfo - dictionary containing settings
#    caName - Name of custom action
#    actionType - NamedProcessDef or NamedJavaProcessDef
#    prefix - property key prefix used to access settings in actionInfo
#-------------------------------------------------------------------------------
def processHealthManagementCustomAction(actionInfo, caName, actionType, prefix):
  _app_entry("processHealthManagementCustomAction(actionInfo, %s,%s,%s)" % (caName, actionType,prefix))
  try:
    # See if the custom action is defined
    actionID = findHealthManagementCustomAction(caName)
    if (not isEmpty(actionID)):
      _app_message("Custom Action %s is defined" % caName)
      actionProps = getHealthManagementCustomActionProperties(actionID)
      existingType = actionProps.get("customAction.definitions.type")
      
      if ( (not isEmpty(actionType)) and existingType != actionType):
        # Will have to redefine this action
        _app_message("Redefinition required")
        pass
      else:
        subProps = getPropListDifferences(actionInfo,"%s.definitions"%prefix,actionProps,"customAction.definitions")
        if (len(subProps) > 0):
          updateHealthManagementCustomAction(actionID,existingType,subProps)
          _app_message("Custom Action %s has been updated" % caName)
        else:
          _app_message("Custom Action %s does not need to be updated" % caName)
        
    else:
      _app_message("Custom Action %s is not defined" % caName)
      subProps = getPropList(actionInfo,"%s.definitions"%prefix)
      actionID = createHealthManagementCustomAction(caName,actionType,subProps)
      _app_message("Custom Action %s has been created" % caName)
      
  except:
    _app_exception("Unexpected error in processHealthManagementCustomAction(actionInfo, %s, %s, %s)" % (caName,actionType, prefix))
    
  _app_exit("processHealthManagementCustomAction()")

#-------------------------------------------------------------------------------
# processHealthManagementCustomActions
# Parameters:
#    actionInfo - dictionary containing settings
#-------------------------------------------------------------------------------
def processHealthManagementCustomActions(actionInfo):
  _app_entry("processHealthManagementCustomActions(actionInfo)")
  try:
    # First, process deletions
    processHealthManagementCustomActionDeletions(actionInfo)
    
    caCount = int(actionInfo.get("app.im.customActions.count",0))
    if (caCount > 0):
      for idx in range(1,caCount+1):
        prefix = "app.im.customActions.%d" % idx
        caName = actionInfo.get("%s.name" % prefix)
        if (isEmpty(caName)):
          # Partial list
          continue
        else:
          actionType = actionInfo.get("%s.definitions.type" % prefix)
          processHealthManagementCustomAction(actionInfo, caName, actionType, prefix)
  except:
    _app_exception("Unexpected error in processHealthManagementCustomActions(actionInfo)")
    
  _app_exit("processHealthManagementCustomActions()")