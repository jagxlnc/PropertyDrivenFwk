################################################################################
# ProcessSecurity.py
#
# This module supports the processing of some basic Security settings that have
# been loaded into the global configInfo.
#
# The supported security settings are pretty basic. Security configuration can be
# complex and in most cases are handled by customized wsadmin scripts.
# 
# Property Syntax Overview:
#
# Basic global security settings
#
# app.security.global.prop.activeProtocol = BOTH
# app.security.global.prop.allowAllPermissionForApplication = false
# app.security.global.prop.allowBasicAuth = true
# app.security.global.prop.appEnabled = false
# app.security.global.prop.cacheTimeout = 800
# app.security.global.prop.dynamicallyUpdateSSLConfig = true
# app.security.global.prop.enableJava2SecRuntimeFiltering = false
# app.security.global.prop.enabled = true
# app.security.global.prop.enforceFineGrainedJCASecurity = false
# app.security.global.prop.enforceJava2Security = false
# app.security.global.prop.issuePermissionWarning = true
# app.security.global.prop.useDomainQualifiedUserNames = false
# app.security.global.prop.useLocalSecurityServer = true
# app.security.global.prop.wsPasswordEncryptions = *****
# app.security.global.prop.wsPasswordLocators = *****
# app.security.global.prop.wsPasswords = *****
#
# -------------------------------------------------------------------------------
# Global security custom properties
#
# app.security.global.properties.prop.com.ibm.websphere.security.krb.allowLTPAAuth = true|Allow LTPA authentication when Kerberos is an active authentication mechanism
# app.security.global.properties.prop.com.ibm.websphere.security.krb.canonical_host = true|Use canonical host name and key to validate the SPNEGO request
# app.security.global.properties.prop.com.ibm.ssl.defaultCertReqSubjectDN = cn=9.65.169.128,ou=ConfigurationCell,ou=ConfigurationDmgr,o=IBM,c=US
# app.security.global.properties.prop.com.ibm.ssl.rootCertSubjectDN = cn=9.65.169.128,ou=Root Certificate,ou=ConfigurationCell,ou=ConfigurationDmgr,o=IBM,c=US
# app.security.global.properties.prop.com.ibm.ssl.rootCertValidDays = 5475
# app.security.global.properties.prop.com.ibm.ssl.defaultCertReqDays = 5475
# ...
#
# ------------------------------------------------------------------------------
# Key stores:
#
# app.security.global.keyStores.1.name = CellDefaultKeyStore
# app.security.global.keyStores.1.managementScope.prop.scopeName = (cell):SecurityConfigCell
# app.security.global.keyStores.1.managementScope.prop.scopeType = cell
# app.security.global.keyStores.1.prop.createStashFileForCMS = false
# app.security.global.keyStores.1.prop.description = Default key store for SecurityConfigCell
# app.security.global.keyStores.1.prop.fileBased = true
# app.security.global.keyStores.1.prop.initializeAtStartup = false
# app.security.global.keyStores.1.prop.location = ${CONFIG_ROOT}/cells/SecurityConfigCell/key.p12
# app.security.global.keyStores.1.prop.password = *****
# app.security.global.keyStores.1.prop.provider = IBMJCE
# app.security.global.keyStores.1.prop.readOnly = false
# app.security.global.keyStores.1.prop.slot = 0
# app.security.global.keyStores.1.prop.type = PKCS12
# app.security.global.keyStores.1.prop.usage = SSLKeys
# ...
# app.security.global.keyStores.count = <number of key stores>
#
# Using dynamic fields in key store settings:
#
# app.security.global.keyStores.6.name = DmgrDefaultSignersStore
# app.security.global.keyStores.6.managementScope.prop.scopeName = (cell):@{DYNAMIC#CURRENT_CELL#name}:(node):@{DYNAMIC#CURRENT_DMGR_NODE#name}
# app.security.global.keyStores.6.managementScope.prop.scopeType = node
# app.security.global.keyStores.6.prop.createStashFileForCMS = false
# app.security.global.keyStores.6.prop.description = Key store containing default signers for SecurityConfigDmgr
# app.security.global.keyStores.6.prop.fileBased = true
# app.security.global.keyStores.6.prop.initializeAtStartup = true
# app.security.global.keyStores.6.prop.location = ${CONFIG_ROOT}/cells/@{DYNAMIC#CURRENT_CELL#name}/nodes/@{DYNAMIC#CURRENT_DMGR_NODE#name}/default-signers.p12
# app.security.global.keyStores.6.prop.password = *****
# app.security.global.keyStores.6.prop.provider = IBMJCE
# app.security.global.keyStores.6.prop.readOnly = false
# app.security.global.keyStores.6.prop.slot = 0
# app.security.global.keyStores.6.prop.type = PKCS12
# app.security.global.keyStores.6.prop.usage = DefaultSigners
# app.security.global.keyStores.6.prop.useForAcceleration = false
#
# ------------------------------------------------------------------------------
# Security domains
# app.security.domain.1.name =  TempSecurityDomain
# app.security.domain.1.prop.activeProtocol = IBM
# app.security.domain.1.prop.allowAllPermissionForApplication = false
# app.security.domain.1.prop.allowBasicAuth = false
# app.security.domain.1.prop.appEnabled = true
# app.security.domain.1.prop.cacheTimeout = 600
# app.security.domain.1.prop.dynamicallyUpdateSSLConfig = false
# app.security.domain.1.prop.enableJava2SecRuntimeFiltering = false
# app.security.domain.1.prop.enabled = false
# app.security.domain.1.prop.enforceFineGrainedJCASecurity = false
# app.security.domain.1.prop.enforceJava2Security = false
# app.security.domain.1.prop.issuePermissionWarning = false
# app.security.domain.1.prop.useDomainQualifiedUserNames = false
# app.security.domain.1.prop.useLocalSecurityServer = false
# app.security.domain.1.prop.wsPasswordEncryptions = *****
# app.security.domain.1.prop.wsPasswordLocators = *****
# app.security.domain.1.prop.wsPasswords = *****
# app.security.domain.1.properties.prop.security.enablePluggableAuthentication = true
# app.security.domain.1.properties.prop.com.ibm.CSI.rmiOutboundPropagationEnabled = true
# app.security.domain.1.properties.prop.com.ibm.CSI.rmiInboundPropagationEnabled = true
# ...
# app.security.domain.count = <number of domains>
################################################################################

#-------------------------------------------------------------------------------
# processKeyStores
#
# Check the settings in the configInfo for any keyStore settings.  This function
# will update existing keystores with new properties. It does not create new key
# stores.
#-------------------------------------------------------------------------------
def processKeyStores():
	_app_trace("processKeyStores()","entry")
	
	try:
		keystoreCount = int(configInfo.get("app.security.global.keyStores.count","0"))
		for idx in range(1,keystoreCount+1):
			keystoreName = configInfo.get("app.security.global.keyStores.%d.name" % idx,"")
			if (isEmpty(keystoreName)):
				continue
			
			scopeType = substituteDynamicValues("scopeType",configInfo.get("app.security.global.keyStores.%d.managementScope.prop.scopeType"%idx,""))
			scopeName = substituteDynamicValues("scopeName",configInfo.get("app.security.global.keyStores.%d.managementScope.prop.scopeName"%idx,""))
			
			# Get the ID for the scope
			keystoreId = getKeyStoreId(keystoreName, scopeName, scopeType)
			if (isEmpty(keystoreId)):
				_app_message("Unable to find KeyStore for updates: %s %s" % (keystoreName, scopeName))
				raise StandardError("Unable to find KeyStore for updates: %s %s" % (keystoreName, scopeName))
			
			existingProps = getKeyStoreProperties(keystoreId)
			
			baseProps = getPropListDifferences(configInfo, "app.security.global.keyStores.%d" % idx, existingProps, "app.security.keyStore")
			additionalProps = getPropListDifferences(configInfo, "app.security.global.keyStores.%d.additionalKeyStoreAttrs" % idx, existingProps, "app.security.keyStore.additionalKeyStoreAttrs")
			
			if ( len(baseProps) > 0):
				modifyKeyStore(keystoreName, scopeName, baseProps)
				_app_message("Updated properties for keystore %s %s" % (keystoreName, scopeName))
			else:
				_app_message("No need to update keystore %s %s" % (keystoreName, scopeName))
	except:
		_app_trace("Unexpected error in processKeyStores()","exception")
		raise StandardError("Unexpected error in processKeyStores")
	
	_app_trace("processKeyStores","exit")
		

#-------------------------------------------------------------------------------------
# processBasicSecurity
#
# Process basic security settings in configInfo dictionary. This function can apply 
# these settings to global security or a security domain.
#
# Parameters:
#			prefix - prefix for global security props or security domain props
#     securityDomainName - (optional) Name of security domain to be updated
#-------------------------------------------------------------------------------------
def processBasicSecurity(prefix, securityDomainName=None):
	_app_trace("processBasicSecurity(%s,%s)"% (prefix, securityDomainName),"entry")
	
	existingProps = getSecurityProperties(securityDomainName)
	if (isEmpty(securityDomainName)):
		baseProps = getPropListDifferences(configInfo, prefix, existingProps, "app.security.global")
		customProps = getPropListDifferences(configInfo, "%s.properties" % prefix, existingProps, "app.security.global.properties")
	else:
		baseProps = getPropListDifferences(configInfo, prefix, existingProps, "app.security.domain")
		customProps = getPropListDifferences(configInfo, "%s.properties" % prefix, existingProps, "app.security.domain.properties")
	
		
	displayName = securityDomainName
	if (isEmpty(displayName)):
		displayName = "global"
	else:
		displayName = "%s domain" % securityDomainName
	
			
	if (len(baseProps) > 0 or len(customProps) > 0):
		updateSecurityProperties(baseProps, customProps, securityDomainName)
		_app_message("Updated %s security: %d properties and %d custom properties were applied" % (displayName,len(baseProps),len(customProps)))
	else:
		_app_message("No base %s security properties or custom properties need to be applied" % displayName)
		
	
	_app_trace("processBasicSecurity()","exit")


#-------------------------------------------------------------------------------
# processSecurityDomains
#
# Iterates through the security domain settings in the configInfo dictionary
# and applies the settings to the security domains. Currently, this function
# performs updates only and does not create new security domains.
#-------------------------------------------------------------------------------
def processSecurityDomains():
	_app_trace("processSecurityDomains","entry")
	try:
		domainCount = int(configInfo.get("app.security.domain.count","0"))
		for idx in range(1,domainCount+1):
			domainName = configInfo.get("app.security.domain.%d.name"%idx,"")
			if (isEmpty(domainName)):
				continue
			
			processBasicSecurity("app.security.domain.%d.name" % idx, domainName)
			
	except:
		_app_trace("Unexpected error in processSecurityDomains","exception")
		raise StandardError("Unexpected error in processSecurityDomains")
	_app_trace("processSecurityDomains","exit")

def processSecurity():
	global configInfo
	
	_app_trace("processSecurity()","entry")
	try:
		if checkForPrefix(configInfo,"app.security"):
			# We have security settings to process
			if checkForPrefix(configInfo,"app.security.global.prop"):
				processBasicSecurity("app.security.global")
			
			# Process key store settings
			processKeyStores()
			
			# 
			
	except:
		_app_trace("Unexpected error in processSecurity","exception")
		exit()
		
		
	_app_trace("processSecurity()","exit")