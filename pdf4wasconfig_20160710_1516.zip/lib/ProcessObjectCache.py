##########################################################################################
# ProcessObjectCache.py
#
# This module contains the functions that process the configuration properties for
# Object Cache definitions from the global configInfo dictionary.  
#
# Primary function:
#      processObjectCache()
#
# Related modules:
#			ObjectCache.py
#     Utils.py
#
# Property Syntax overview:
#
# The Object Cache definitions are ordered by scoped Cache Provider definitions and 
# each cache provider can have 0 or more Object Cache definitions.
#
# For now, the only Cache Provider supported is the Default Cache Provider and we
# don't do any processing of the provider properties.
#
# app.cacheprovider.<pdix>.cluster = 
# app.cacheprovider.<pdix>.node = 
# app.cacheprovider.<pdix>.server = 
# app.cacheprovider.<pdix>.name = CacheProvider
# app.cacheprovider.<pdix>.prop.description = Default Cache Provider
# app.cacheprovider.<pdix>.prop.isolatedClassLoader = false
#
# app.cacheprovider.<pidx>.objectcache.<cidx>.name = SampleObjectCache
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.cacheSize = 2000
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.defaultPriority = 1
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.description = This is my test cache
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.disableDependencyId = false
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.diskCacheCleanupFrequency = 0
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.diskCacheEntrySizeInMB = 5
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.diskCachePerformanceLevel = BALANCED
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.diskCacheSizeInEntries = 100
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.diskCacheSizeInGB = 10
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.diskOffloadLocation = c:\cachedir
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.enableCacheReplication = true
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.enableDiskOffload = true
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.flushToDiskOnStop = true
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.hashSize = 1024
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.jndiName = jms/SampleObjectCache
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.pushFrequency = 1
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.replicationType = PUSH_PULL
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.useListenerContext = false
# app.cacheprovider.<pidx>.objectcache.<cidx>.cacheReplication.prop.dataReplicationMode = BOTH
# app.cacheprovider.<pidx>.objectcache.<cidx>.cacheReplication.prop.messageBrokerDomainName = DomainAlpha
# app.cacheprovider.<pidx>.objectcache.<cidx>.diskCacheCustomPerformanceSettings.prop.maxBufferedCacheIdsPerMetaEntry = 1000
# app.cacheprovider.<pidx>.objectcache.<cidx>.diskCacheCustomPerformanceSettings.prop.maxBufferedDependencyIds = 10000
# app.cacheprovider.<pidx>.objectcache.<cidx>.diskCacheCustomPerformanceSettings.prop.maxBufferedTemplates = 100
# app.cacheprovider.<pidx>.objectcache.<cidx>.diskCacheEvictionPolicy.prop.algorithm = SIZE
# app.cacheprovider.<pidx>.objectcache.<cidx>.diskCacheEvictionPolicy.prop.highThreshold = 80
# app.cacheprovider.<pidx>.objectcache.<cidx>.diskCacheEvictionPolicy.prop.lowThreshold = 70
# # Memory cache settings are v7 specific
# app.cacheprovider.<pidx>.objectcache.<cidx>.prop.memoryCacheSizeInMB = 400
# app.cacheprovider.<pidx>.objectcache.<cidx>.memoryCacheEvictionPolicy.prop.highThreshold = 95
# app.cacheprovider.<pidx>.objectcache.<cidx>.memoryCacheEvictionPolicy.prop.lowThreshold = 80
#
# app.cacheprovider.<pidx>.objectcache.count = <cache count>
# 
# app.cacheprovider.count = <provider count>
#
##########################################################################################


#---------------------------------------------------------------------------------------------------
# processExistingObjectCacheInstance
#
# This function will process the settings for updates to an existing Object Cache Instance.  It pulls
# the properties from the global configInfo dictionary and calls the modifyObjectCache
# method form ObjectCache.py
#
# Parameters:
# 	cacheId - the configuration ID of the ObjectCacheInstance to be updated
# 	scopeString - scope information for logging purposes
#		cacheName - the name of the ObjectCacheInstance to be modified
#		prefix - the prefix of properties in the configInfo dictionary to be used to update
#            the ObjectCacheInstance
#
# Returns:
#  	cacheId - the Id of the updated ObjectCacheInstance, or None if an error occurred
#---------------------------------------------------------------------------------------------------
def processExistingObjectCacheInstance(cacheId, scopeString, cacheName, prefix):
	
	global configInfo
	retval = None
	
	_app_trace("processExistingObjectCacheInstance(%s,%s,%s,%s)" % (cacheId, scopeString, cacheName, prefix),"entry")
	
	try:
	
			existingProps = getObjectCacheProperties(cacheId)
			if (existingProps == None):
					_app_message("Error getting existing configuration for Object Cache %s" % prefix)
					exit()
		
			cacheProps = getPropListDifferences(configInfo,prefix,existingProps,"objectcache")
			resourceProps = getPropListDifferences(configInfo, "%s.resourceProperties" % prefix, existingProps,"objectcache.resourceProperties")
			cacheReplicationProps = getPropListDifferences(configInfo,"%s.cacheReplication" % prefix, existingProps,"objectcache.cacheReplication")
			diskCacheCustomPerformanceSettingsProps =  getPropListDifferences(configInfo,"%s.diskCacheCustomPerformanceSettings" % prefix,  existingProps,"objectcache.diskCacheCustomPerformanceSettings")
			diskCacheEvictionPolicyProps = getPropListDifferences(configInfo,"%s.diskCacheEvictionPolicy" % prefix,  existingProps,"objectcache.diskCacheEvictionPolicy")
			memoryCacheEvictionPolicyProps = getPropListDifferences(configInfo,"%s.memoryCacheEvictionPolicy" % prefix, existingProps,"objectcache.memoryCacheEvictionPolicy")
			
			if (cacheProps.size() > 0 or resourceProps.size() > 0 or cacheReplicationProps.size() > 0 or diskCacheCustomPerformanceSettingsProps.size() > 0 or diskCacheEvictionPolicyProps.size() > 0 or memoryCacheEvictionPolicyProps.size() > 0):
					# Need to do update
					retval = modifyObjectCache(cacheId, cacheProps, resourceProps, cacheReplicationProps, diskCacheCustomPerformanceSettingsProps, diskCacheEvictionPolicyProps, memoryCacheEvictionPolicyProps)
					if (retval == None):
							_app_message("Error updating Object Cache %s at %s scope" % (cacheName, scopeString))
							exit()
					else:
							_app_message("Updated Object Cache %s at %s scope" % (cacheName, scopeString))
			else:
					_app_message("No updates required for Object Cache %s at %s scope" % (cacheName, scopeString))

	
			retval = cacheId
	except:
		_app_trace("Unexpected error processing updates to Object Cache","exception")
		_app_message("Unexpected error processing updates to Object Cache")
		retval = None
	
	_app_trace("processExistingObjectCacheInstance(retval = %s)" % retval,"exit")
	return retval

#enddef processExistingObjectCacheInstance

#-----------------------------------------------------------------------------------------
# processNewObjectCacheInstance
#
# This function will process the settings for single new Object Cache Instance.  It pulls
# the properties from the global configInfo dictionary and calls the createObjectCache
# method form ObjectCache.py
#
# Parameters:
# 	providerId - the configuration ID of the Cache Provider the the instance will be created under
# 	scopeString - scope information for logging purposes
#		cacheName - the name of the ObjectCacheInstance to be created
#		prefix - the prefix of properties in the configInfo dictionary to be used to create
#            the ObjectCacheInstance
#
# Returns:
#  	cacheId - the Id of the created ObjectCacheInstance, or None if an error occurred
#-----------------------------------------------------------------------------------------
def processNewObjectCacheInstance(providerId, scopeString, cacheName, prefix):
	
	global configInfo
	retval = None
	
	_app_trace("processNewObjectCacheInstance(%s,%s,%s,%s)" % (providerId, scopeString, cacheName, prefix),"entry")
	
	try:
		
			cacheProps = getPropList(configInfo,prefix)
			resourceProps = getPropList(configInfo, "%s.resourceProperties" % prefix)
			cacheReplicationProps = getPropList(configInfo,"%s.cacheReplication" % prefix)
			diskCacheCustomPerformanceSettingsProps =  getPropList(configInfo,"%s.diskCacheCustomPerformanceSettings" % prefix)
			diskCacheEvictionPolicyProps = getPropList(configInfo,"%s.diskCacheEvictionPolicy" % prefix)
			memoryCacheEvictionPolicyProps = getPropList(configInfo,"%s.memoryCacheEvictionPolicy" % prefix)
			
			retval = createObjectCache(providerId, cacheName, cacheProps, resourceProps, cacheReplicationProps, diskCacheCustomPerformanceSettingsProps, diskCacheEvictionPolicyProps, memoryCacheEvictionPolicyProps)
			if (retval == None):
					_app_message("Error trying to create new object cache instance %s at %s"%(cacheName, scopeString))
					exit()
			
			_app_message("Created new CacheInstance %s at %s scope" % (cacheName, scopeString))
	
	except:
		_app_trace("Unexpected error processing new ObjectCacheInstance","exception")
		_app_message("Unexpected error processing new ObjectCacheInstance")
		retval = None
	
	_app_trace("processNewObjectCacheInstance(retval = %s)" % retval,"exit")
	return retval

#enddef processNewObjectCacheInstance

#-----------------------------------------------------------------------------------------
# processObjectCacheForProvider
#
# This function will process the object cache properties in the global configInfo
# dictionary for a specific provider.
#
# Parameters:
#			providerId - The configuration ID of the provider the Object Cache Instances will
#							     be created at.
#     scopeString - A string with scope information for logging
#     providerPrefix - The prefix of property keys associated with this provider.
#
#-----------------------------------------------------------------------------------------
def processObjectCacheForProvider(providerId, scopeString, providerPrefix):
	global configInfo
	
	_app_trace("processObjectCacheForProvider(%s,%s,%s)" % (providerId, scopeString, providerPrefix),"entry")
	try:
		cacheCount = int(configInfo.get("%s.objectcache.count" % providerPrefix,"0"))
		if (cacheCount > 0):
			for idx in range(1,cacheCount+1):
					prefix = "%s.objectcache.%d" % (providerPrefix,idx)
					cacheName = configInfo.get("%s.name" % prefix,"")
					if (isEmpty(cacheName)):
							# Partial list
							continue
					
					# See if this cache is currently defined
					cacheId = findObjectCacheInstanceWithName(cacheName,providerId)
					if (cacheId == "ERROR"):
							_app_message("Error looking for ObjectCacheInstance %s" % cacheName)
							exit()
							
					if (isEmpty(cacheId)):
							# Need to create
							retval = processNewObjectCacheInstance(providerId, scopeString, cacheName, prefix)
							if (retval == None):
									# Some error (previously logged)
									exit()
					else:
							# Need to update
							retval = processExistingObjectCacheInstance(cacheId, scopeString, cacheName, prefix)
							if (retval == None):
									# Some error (previously logged)
									exit()
	
	except:
		_app_trace("Error processing ObjectCache defintions for provider", "exception")
		_app_message("Error processing ObjectCache defintions for provider", "exception")
		exit()
	
	_app_trace("processObjectCacheForProvider()","exit")
	
		
		
#-----------------------------------------------------------------------------------------
# processObjectCache
#
# This function will process the Object Cache definitions in the global configInfo
# dictionary.
#-----------------------------------------------------------------------------------------
def processObjectCache():
	global configInfo
	try:
		providerCount = int(configInfo.get("app.cacheprovider.count","0"))
		
		if (providerCount == 0):
				_app_message("Skipping ObjectCache...")
		else:
				for idx in range(1,providerCount+1):
						prefix = "app.cacheprovider.%d" % idx
						providerName =  configInfo.get("%s.name" % prefix,"")
						if (isEmpty(providerName)):
								# Probably a partial list
								continue
						
						clusterName = configInfo.get("%s.cluster" % prefix,"")
						nodeName = configInfo.get("%s.node" % prefix,"")
						serverName = configInfo.get("%s.server" % prefix,"")
						
						providerId = findCacheProviderAtScope(clusterName, nodeName, serverName, providerName)
						if (isEmpty(providerId)):
								_app_message("Unable to find Cache Provider %s at scope %s%s %s" % (providerName, clusterName, nodeName, serverName))
								exit()
						elif (providerId == "ERROR"):
								_app_message("Error trying to find Cache Provider %s at scope %s%s %s" % (providerName, clusterName, nodeName, serverName))
								exit()
						
						if (not isEmpty(serverName)):
								scopeString = "server %s:%s" % (nodeName, serverName)
						elif (isEmpty(clusterName) and isEmpty(nodeName)):
								scopeString = "cell"
						elif (not isEmpty(nodeName)):
								scopeString = "node %s" % nodeName
						else:
								scopeString = "cluster %s" % clusterName
								
						processObjectCacheForProvider(providerId, scopeString, prefix)
								
						
	
	except:
		_app_trace("Unexpected error process Object Cache Provider definitions")
		exit()