##########################################################################
# File Name:    SIBDestination.py
# Description:  This file contains function definitions to create, delete
#               and list WebSphere SIB Destinations and Mediations
#
#               createSIBDestination
#               deleteSIBDestination
#               listSIBDestination
#               findMatchingQueueDestinations
#               findMatchingTopicSpaceDestinations
#               findMatchingDestinations
#               findMediation
#               updateMediation
#               createMediation
#               applyContextInfo
#               getSIBDestinationMediationProperties
#               getMediationProperties
#               addMediationToSIBDestination
#
# wsadmin>AdminTask.help("createSIBDestination")
# 'WASX8006I: Detailed help for command: createSIBDestination
#
# Description: Create bus destination.
#
# Target object:   None
#
#Arguments:
#  *bus - Name of the bus where this destination is to be configured.
#  *name - Destination name.
#  *type - Destination type (Alias | Foreign | Port | Queue | TopicSpace | WebService).
#  cluster - To assign the destination to a cluster, supply cluster name, but not node and server name or WebSphere MQ server name.
#  node - To assign the destination to a server, supply node name server name, but not cluster name or WebSphere MQ server name.
#  server - To assign the destination to a server, supply node name server name, but not cluster name or WebSphere MQ server name.
#  wmqServer - To assign the destination to a WebSphere MQ server, supply a WebSphere MQ server name, but not node, server name or cluster name.
#  aliasBus - If this is an alias destination, the source bus name of alias mapping.
#  targetBus - If this is an alias destination, the name of the bus that the destination it maps to is configured on.
#  targetName - If this is an alias destination, the name of the destination it maps to.
#  foreignBus - If this is a foreign destination, the name of the foreign bus.
#  description - Description.
#  reliability - The reliability quality of service for message flows through this destination, from BEST_EFFORT_NON-PERSISTENT to ASSURED_PERSISTENT, in order of increasing reliability. Higher levels of reliability have higher impacts on the performance.
#  maxReliability - The maximum reliability quality of service that is accepted for values specified by producers.
#  nonPersistentReliability - The quality of service used for inbound messages which WebSphere MQ regards as being non-persistent.  Allowable values are { BEST_EFFORT_NONPERSISTENT | EXPRESS_NONPERSISTENT | RELIABLE_NONPERSISTENT | RELIABLE_PERSISTENT | ASSURED_PERSISTENT }.
#  persistentReliability - The quality of service used for inbound messages which WebSphere MQ regards as being persistent.  Allowable values are { BEST_EFFORT_NONPERSISTENT | EXPRESS_NONPERSISTENT | RELIABLE_NONPERSISTENT | RELIABLE_PERSISTENT | ASSURED_PERSISTENT }.
#  overrideOfQOSByProducerAllowed - Controls the quality of service for message flows between producers and the destination. Select this option to use the quality of service specified by producers instead of the quality defined for the destination.
#  defaultPriority - The default priority for message flows through this destination, in the range 0 (lowest) through 9 (highest). This default priority is used for messages that do not contain a priority value.
#  maxFailedDeliveries - The maximum number of times that service tries to deliver a message to the destination before forwarding it to the exception destination.
#  exceptionDestination - The name of another destination to which the system sends a message that cannot be delivered to this destination within the specified maximum number of failed deliveries.
#  sendAllowed - Clear this option (setting it to false) to stop producers from being able to send messages to this destination.
#  receiveAllowed - Clear this option (setting it to false) to prevent consumers from being able to receive messages from this destination.
#  receiveExclusive - Select this option (setting it to true) to allow only one consumer to attach to a destination.
#  maintainStrictMessageOrder - Select this option (setting it to true) to enforce message order for this destination.
#  topicAccessCheckRequired - Topic access check required.
#  replyDestination - The name of the destination for reply messages.
#  replyDestinationBus - The name of the bus on which the reply destination is configured.
#  delegateAuthorizationCheckToTarget - Indicates whether the authorization check should be delegated to the alias or target destination.
#  wmqQueueName - The name of the WebSphere MQ queue for messages.  This must be specified with the WebSphere MQ server name, but not node, server name or cluster name.
#  useRFH2 - Determines if messages sent to the WebSphere MQ destination have an RFH2 header or not.  This must be specified with the WebSphere MQ server name, but not node, server name or cluster name.
# V8:
#  auditAllowed - Used to allow or prevent the bus from auditing topic level authorization checks when the bus and application server have auditing enabled.
#  blockedRetryTimeout - Override the blocked destination retry interval configured on the messaging engine owning the destination.
#  mqRfh2Allowed - If selected, messages sent to WebSphere MQ will include an RFH2 header. The RFH2 header stores additional information to that which is stored in the WebSphere  MQ message header.
#  
#
# V8.5:
#  persistRedeliveryCount - Set this option (Setting it to true) to persist the redelivery count of JMS messages into the Messagestore.


mediationUUIDCache = {}

def getMediationNameFromUUID(busName,mediationUUID):
  global mediationUUIDCache
  
  mediationName = mediationUUIDCache.get("%s.%s" % (busName,mediationUUID))
  if (isEmpty(mediationName)):
    # Do lookup for this bus and populate the cache
    mediationList = wsadminToList(AdminTask.listSIBMediations('[-bus "%s" ]' % (busName)))
    for mediationId in mediationList:
      if (isEmpty(mediationId)):
        continue
      mediationProps = {}
      collectSimpleProperties(mediationProps,"mediation",mediationId)
      mediationName = mediationProps["mediation.mediationName"]
      uuid = mediationProps["mediation.uuid"]
      mediationUUIDCache["%s.%s" % (busName,uuid)] = mediationName
      
  mediationName = mediationUUIDCache.get("%s.%s" % (busName,mediationUUID))
  
  return mediationName
  
    



#
#Steps:
#   defaultForwardRoutingPath - Default forward routing path.
##########################################################################

##########################################################################
#
# FUNCTION:
#    createSIBDestination: Create a SIB Destination
#
# SYNTAX:
#    createSIBDestination name, (cluster|node, server), bus, type
#
# PARAMETERS:
#    name	-	Destination name
#    type	-	Destination type (Queue, Topic, Alias)
#    cluster	-	Cluster to assign Destination to
#    node	-	Node to assign Destination to
#    server	-	Server to assign Destination to
#    bus	-	Name of bus for this Destination
#    baseProperties	-	Properties - base properties of the destination
#
#
# USAGE NOTES:
#    Creates a SIB Destination on the bus at the desired scope.  
#
# RETURNS:
#    ObjID	Object ID of new appserver
#    None	Failure
#
# THROWS:
#    N/A
##########################################################################
def addSIBDestination(name, type, cluster, node, server, bus, baseProperties):
	createSIBDestination(name, cluster, node, server, bus, baseProperties)

def createSIBDestination(name, type, cluster, node, server, bus, baseProperties, replyDestination = None, replyDestinationBus = None, contextInfoList=None):

  global progInfo
  

  
  parmMapV6 = { 'defaultPriority': '-defaultPriority' , 'description':'-description' , 'exceptionDestination': '-exceptionDestination', 'identifier': '-name', 'maintainStrictMessageOrder':'-maintainStrictMessageOrder' , 'maxFailedDeliveries': '-maxFailedDeliveries', 'maxReliability':'-maxReliability' , 'overrideOfQOSByProducerAllowed': '-overrideOfQOSByProducerAllowed' , 'receiveAllowed':'-receiveAllowed', 'receiveExclusive':'-receiveExclusive', 'reliability':'-reliability','sendAllowed':'-sendAllowed', 'defaultForwardRoutingPath':'-defaultForwardRoutingPath', 'topicAccessCheckRequired':'-topicAccessCheckRequired' }
  parmMapV7 = { 'blockedRetryTimeout' : '-blockedRetryTimeout', 'defaultPriority': '-defaultPriority' , 'description':'-description' , 'exceptionDestination': '-exceptionDestination', 'identifier': '-name', 'maintainStrictMessageOrder':'-maintainStrictMessageOrder' , 'maxFailedDeliveries': '-maxFailedDeliveries', 'maxReliability':'-maxReliability' , 'overrideOfQOSByProducerAllowed': '-overrideOfQOSByProducerAllowed' , 'receiveAllowed':'-receiveAllowed', 'receiveExclusive':'-receiveExclusive', 'reliability':'-reliability','sendAllowed':'-sendAllowed', 'defaultForwardRoutingPath':'-defaultForwardRoutingPath', 'topicAccessCheckRequired':'-topicAccessCheckRequired' }
  parmMapV85 = { 'blockedRetryTimeout' : '-blockedRetryTimeout', 'defaultPriority': '-defaultPriority' , 'description':'-description' , 'exceptionDestination': '-exceptionDestination', 'identifier': '-name', 'maintainStrictMessageOrder':'-maintainStrictMessageOrder' , 'maxFailedDeliveries': '-maxFailedDeliveries', 'maxReliability':'-maxReliability' , 'overrideOfQOSByProducerAllowed': '-overrideOfQOSByProducerAllowed' , 'receiveAllowed':'-receiveAllowed', 'receiveExclusive':'-receiveExclusive', 'reliability':'-reliability','sendAllowed':'-sendAllowed', 'defaultForwardRoutingPath':'-defaultForwardRoutingPath', 'topicAccessCheckRequired':'-topicAccessCheckRequired', 
                 'persistRedeliveryCount':'-persistRedeliveryCount', 'auditAllowed':'-auditAllowed', 'blockedRetryTimeout': '-blockedRetryTimeout','mqRfh2Allowed':'-mqRfh2Allowed'}

  retval = None

  try:
    traceStr = "createSIBDestination(%s, %s, %s, %s, %s, %s)" % (name, cluster, node, server, bus, baseProperties)
    _app_trace(traceStr, "entry") 
    
    parmMap = parmMapV85
    if ( progInfo["dmgrVersion"].startswith("6")):
        parmMap = parmMapV6
    elif (progInfo["dmgrVersion"].startswith("7")):
      parmMap = parmMapV7

    # Check function parameters
    if isEmpty(name):
        raise StandardError("SIB Destination name not specified")
                    
    configID = getContainmentPath(cluster, node, server, 1)
    
    if isEmpty(configID):
      raise StandardError("Could not get containment path")
    
    if isEmpty(AdminConfig.getid(configID)):
      raise StandardError("No such target as %s to create SIB Destinations at" % (configID))
      
    if isEmpty(bus):
      raise StandardError("SIBus Name not specified")
      
    if isEmpty(type):
      raise StandardError("Destination type not specified")
      
    if not objectExists("SIBus", None, bus):
      raise StandardError("SIBus %s does not exist" % (bus))
      
    if existsSIBDestination(name, bus):
      raise StandardError("Destination %s already exists on bus %s" % (name, bus))
      
    if len(AdminTask.listSIBEngines('-bus "%s"' % (bus))) == 0:
      raise StandardError("No Messaging Engines found on bus %s" % (bus))
      
    
    attributes  = ' -name "%s"'   % (name)
    attributes += ' -bus "%s"'  % (bus)
    attributes += " -type %s" % (type)


    if isEmpty(cluster):
      attributes += " -node %s -server %s" % (node, server)
    else:
      attributes += " -cluster %s" % (cluster)

    if (baseProperties != None):
        for key in baseProperties.keys():
            val = baseProperties.get(key)
            if (key == "blockedRetryTimeout" and val.startswith("-")):
                val = '"%s"' % val
            
            if (key == "description"):
                if not val.startswith('"'):
                  val = '"%s"' % val
            if (not isEmpty(val)):
                # Get the argument syntax
                cmdkey  = parmMap.get(key,"")
                if (not isEmpty(cmdkey)):
                    attributes ='%s %s %s' % (attributes, cmdkey, val)
  
    if (not isEmpty(replyDestination)):
        attributes = "%s -replyDestination %s" % (attributes,replyDestination)
    
    if (not isEmpty(replyDestinationBus)):
        attributes = "%s -replyDestinationBus %s" % (attributes,replyDestinationBus)

    _app_trace("Running command: AdminTask.createSIBDestination(%s)" % (attributes))
    retval = AdminTask.createSIBDestination(attributes)
    
    if (not isEmpty(retval)):
        # work around for AdminTask.createSIBDestination not handling -replyDestination  correctly
        repDestAttrs = []
        if (not isEmpty(replyDestination)):
            repDestAttrs.append(["destination", replyDestination])
        
        if (not isEmpty(replyDestinationBus)):
            repDestAttrs.append(["bus",replyDestinationBus])
            
        if (len(repDestAttrs) > 0):
          if (modifyObject(retval, [ ["replyDestination", repDestAttrs]])):
            _app_trace("Error updating replyDestination for destination %s on bus %s" % (name, bus))
            raise StandardError("Error updating replyDestination for destination %s on bus %s" % (name, bus))
        
        # Update the context info
        if (contextInfoList != None and len(contextInfoList) > 0):
            applyContextInfo(retval,contextInfoList,"contextInfo")    

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered creating the SIB Destination", "exception")
    retval = None

  _app_trace("createSIBDestination(%s)" %(retval), "exit")
  return retval
	

###############################################################################################################
# modifySIBDestination
###############################################################################################################
def modifySIBDestination(name, bus, destinationType, baseProperties, replyDestination = None, replyDestinationBus = None,contextInfoList=None):

  global progInfo
  
  parmMap = { 'defaultPriority': '-defaultPriority' , 'description':'-description' , 'exceptionDestination': '-exceptionDestination', 'identifier': '-name', 'maintainStrictMessageOrder':'-maintainStrictMessageOrder' , 'maxFailedDeliveries': '-maxFailedDeliveries', 'maxReliability':'-maxReliability' , 'overrideOfQOSByProducerAllowed': '-overrideOfQOSByProducerAllowed' , 'receiveAllowed':'-receiveAllowed', 'receiveExclusive':'-receiveExclusive', 'reliability':'-reliability','sendAllowed':'-sendAllowed', 'defaultForwardRoutingPath':'-defaultForwardRoutingPath', 'topicAccessCheckRequired':'-topicAccessCheckRequired' }

  retval = None

  try:
    traceStr = "modifySIBDestination(%s,  %s, %s, %s, %s)" % (name,  bus, baseProperties, replyDestination, replyDestinationBus)
    _app_trace(traceStr, "entry") 

    # Check function parameters
    if isEmpty(name):
      raise StandardError("SIB Destination name not specified")
                   
      
    if isEmpty(bus):
      raise StandardError("SIBus Name not specified")
      
      
    if not objectExists("SIBus", None, bus):
      raise StandardError("SIBus %s does not exist" % (bus))
      
    if not existsSIBDestination(name, bus):
      raise StandardError("Destination %s does not exist on bus %s" % (name, bus))
      
    
    attributes  = ' -name "%s"'   % (name)
    attributes += ' -bus "%s"'  % (bus)

    if (baseProperties != None):
        for key in baseProperties.keys():
            val = baseProperties.get(key)
            if (key == "description"):
                if not val.startswith('"'):
                  val = '"%s"' % val
            if (not isEmpty(val)):
                # Get the argument syntax
                cmdkey  = parmMap.get(key,"")
                if (not isEmpty(cmdkey)):
                    attributes ='%s %s %s' % (attributes, cmdkey, val)
  
    if (not isEmpty(replyDestination)):
        attributes = "%s -replyDestination %s" % (attributes,replyDestination)
    
    if (not isEmpty(replyDestinationBus)):
        attributes = "%s -replyDestinationBus %s" % (attributes,replyDestinationBus)

    _app_trace("Running command: AdminTask.modifySIBDestination(%s)" % (attributes))
    retval = AdminTask.modifySIBDestination(attributes)
    
    if (not isEmpty(replyDestination) or not isEmpty(replyDestinationBus)):
        # work around for AdminTask.createSIBDestination not handling -replyDestination  correctly
        repDestAttrs = []
        if (not isEmpty(replyDestination)):
            if (replyDestination == "''"): replyDestination = ""
            repDestAttrs.append(["destination", replyDestination])
        
        if (not isEmpty(replyDestinationBus)):
            if (replyDestinationBus == "''"): replyDestinationBus = ""
            repDestAttrs.append(["bus",replyDestinationBus])
            
        if (len(repDestAttrs) > 0):
          destid = getDestinationId(name, bus, destinationType)
          if (not isEmpty(destid)):
            # See if this is an update to existing replyDestination
            repId = AdminConfig.showAttribute(destid, "replyDestination")
            if (not isEmpty(repId )):
                if (modifyObject(repId, repDestAttrs)):
                    _app_trace("Error updating replyDestination for destination %s on bus %s" % (name, bus))
                    raise StandardError("Error updating replyDestination for destination %s on bus %s" % (name, bus))
            elif (modifyObject(destid, [ ["replyDestination", repDestAttrs]])):
              _app_trace("Error creating replyDestination for existing destination %s on bus %s" % (name, bus))
              raise StandardError("Error creating replyDestination for existing destination %s on bus %s" % (name, bus))

    # Update the context info
    if (contextInfoList != None and len(contextInfoList) > 0):
      applyContextInfo(retval,contextInfoList,"contextInfo")


    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()

  except:
    _app_trace("An error was encountered modifying the SIB Destination", "exception")
    retval = None

  _app_trace("modifySIBDestination(%s)" %(retval), "exit")
  return retval
	
##########################################################################
#
# FUNCTION:
#    deleteSIBDestination: Delete a SIB Destination
#
# SYNTAX:
#    deleteSIBDestination name, bus
#
# PARAMETERS:
#    name	-	Name for SIB Destination entry
#    bus	-	Name of bus for this Destination
#
# USAGE NOTES:
#    Deletes a SIB Destination from the desired bus.  

# RETURNS:
#    0    Success
#    1    Failure
#
# THROWS:
#    N/A
##########################################################################
def removeSIBDestination(name, bus,configurationId=None,skipValidation = 0):
	deleteSIBDestination(name, bus,configurationId,skipValidation)
	
def deleteSIBDestination(name, bus,configurationId=None,skipValidation=0):

  global progInfo

  retval = 1

  try:
    traceStr = "deleteSIBDestination(%s, %s, %s)" % (name, bus,configurationId)
    _app_trace(traceStr, "entry") 

    if (isEmpty(configurationId) and not skipValidation):
      # Do some basic validation
      if isEmpty(name) or isEmpty(bus):
        raise StandardError("Destination name or SIBus Name not specified")   
        
      if not objectExists("SIBus", None, bus):
        raise StandardError("SIBus %s does not exist" % (bus))
        
      if not existsSIBDestination(name, bus):
        raise StandardError("Destination %s does not exist on bus %s" % (name, bus))
    #endif
      
    attributes  = ' -bus "%s"'  % (bus)
    attributes += ' -name "%s"' % (name)

    _app_trace("Running command: AdminTask.deleteSIBDestination(%s)" % (attributes))
    AdminTask.deleteSIBDestination(attributes)

    if progInfo["app.autosave"] == "true":
      _app_trace("Saving...")
      AdminConfig.save()
      
    retval = 0
  except:
    _app_trace("An error was encountered deleting the SIB Destination", "exception")
    retval = 1

  _app_trace("deleteSIBDestination(%d)" %(retval), "exit")
  return retval

##########################################################################
#
# FUNCTION:
#    listSIBDestinations: List SIB Destinations on bus
#
# SYNTAX:
#    listDestinations bus, displayFlag
#
# PARAMETERS:
#    bus	-	Name of bus for this Destination
#    displayFlag-	Boolean indicating whether to print list 
#			(default = 1)
#
# USAGE NOTES:
#    Lists SIB Destinations on the bus.  
#
# RETURNS:
#    The list or None in case of error
#
# THROWS:
#    N/A
##########################################################################
def showSIBDestinations(bus, displayFlag = 1):
	listSIBDestinations(bus, displayFlag)
	
def listSIBDestinations(bus, displayFlag = 1):

	global progInfo
	
	retval = None
	
	try:
		traceStr = "listSIBJMSConnectionDestinations(%s, %d)" % (bus, displayFlag)
		_app_trace(traceStr, "entry")	

		if isEmpty(bus):
			raise StandardError("SIBus Name not specified")
			
		if not objectExists("SIBus", None, bus):
			raise StandardError("SIBus %s does not exist" % (bus))
			
		attributes  = ' -bus "%s"' % (bus)

		_app_trace("Running command: AdminTask.listSIBDestinations(%s)" % (attributes))
		str = AdminTask.listSIBDestinations(attributes)

		if isEmpty(str):
			retval = []
		else:
			retval = str.split(progInfo["line.separator"])

		if displayFlag:
			print "\nSI Bus Destinations\n-----------------------------"

			for r in retval:
				print AdminConfig.showAttribute(r, "identifier")

			print "-----------------------------"
	except:
		_app_trace("An error was encountered listing the SIB Destinations", "exception")
		retval = None

	_app_trace("listSIBDestinations(%s)" %(retval), "exit")
	return retval

#------------------------------------------------------------------------------
# getDestinationId
#
# Returns the configuration ID of the specified destination
#
# Parameters:
#   name - Identifier of the SIB destination
#   busName - name of the bus
#   destinationType - Queue or TopicSpace
#------------------------------------------------------------------------------
def getDestinationId(name, busName, destinationType):

		_app_trace("getDestinationId(%s, %s, %s)"% (name, busName, destinationType), "entry")
		retval = None
		destList = wsadminToList(AdminTask.listSIBDestinations('[-bus "%s" -type %s]' % (busName, destinationType)))
		idx = 0
		for destination in destList:
				if (not isEmpty(destination)):
						identifier = AdminConfig.showAttribute(destination, "identifier")
						if (identifier == name):
								retval = destination
								break
		
		_app_trace("getDestinationId(result = %s)" % retval)
		return retval

#------------------------------------------------------------------------------
# findMatchingDestinations
#
# Return a dictionary with identifier=config_id values for every destination in
# the bus that matches the name pattern and destinationType
#
# Parameters:
#   busName - name of the SIBus
#   namePattern - regular expression pattern to match
#   destinationType - Queue or TopicSpace
#------------------------------------------------------------------------------
def findMatchingQueueDestinations(busName, namePattern):
  return findMatchingDestinations(busName, namePattern, "Queue")
#enddef

def findMatchingTopicSpaceDestinations(busName, namePattern):
  return findMatchingDestinations(busName, namePattern, "TopicSpace")
#enddef

def findMatchingDestinations(busName, namePattern, destinationType):
  _app_trace("findMatchingDestinations(%s,%s,%s)" % (busName, namePattern, destinationType),"entry")
  
  retval = {}
  import re
  
  try:
    destList = wsadminToList(AdminTask.listSIBDestinations('[-bus "%s" -type %s]' % (busName, destinationType)))
    for destination in destList:
      if (not isEmpty(destination)):
        identifier = AdminConfig.showAttribute(destination, "identifier")
        if (namePattern.find("*") >= 0):
          # Regular express
          if (re.match(namePattern,identifier)):
            # Add ID to result list
            retval[identifier] = destination
        elif (namePattern == identifier):
          retval[identifier] = destination
        #endelif
     #endif
   #endfor
            
  except:
    _app_trace("Unexpected error in findMatchingDestinations","exception")
    raise StandardError("Unexpected error in findMatchingDestinations")
  
  _app_trace("findMatchingDestinations(%d destinations found)" % len(retval),"exit")
  return retval
  
#enddef findMatchingDestinations

#------------------------------------------------------------------------------
# getSIBQueueProperties
#
# Return settings for Queue definitions as properties.
#
# Parameters:
#     sibProperties - Property set to update
#     busName - Name of the bus
#     prefix - Prefix string to use with property keys: [prefix].queueDestinations
#------------------------------------------------------------------------------
def getSIBQueueProperties(sibProperties,busName, prefix):

		queueList = wsadminToList(AdminTask.listSIBDestinations('[-bus "%s" -type Queue]' % (busName)))
		idx = 0
		for queue in queueList:
				if (not isEmpty(queue)):
						idx = idx + 1
						qidentifier = AdminConfig.showAttribute(queue, "identifier")
						sibProperties["%s.queueDestinations.%d.identifier" % (prefix,idx)] = qidentifier
						
						# Determine target cluster or target server from the localizationPoint
						localizationPointRefsList = wsadminToList(AdminConfig.showAttribute(queue, "localizationPointRefs"))
						for localizationPoint in localizationPointRefsList:
								
								clusterName = AdminConfig.showAttribute(localizationPoint,"cluster")
								nodeName = AdminConfig.showAttribute(localizationPoint,"node")
								serverName = AdminConfig.showAttribute(localizationPoint,"server")
								if (not isEmpty(clusterName)):
										sibProperties["%s.queueDestinations.%d.cluster" % (prefix, idx)] = clusterName
								else:
										sibProperties["%s.queueDestinations.%d.cluster" % (prefix, idx)] = ""
								
								if (not isEmpty(nodeName)):
										sibProperties["%s.queueDestinations.%d.node" % (prefix, idx)] = nodeName
								else:
										sibProperties["%s.queueDestinations.%d.node" % (prefix, idx)] = ""
										
								if (not isEmpty(serverName)):
										sibProperties["%s.queueDestinations.%d.server" % (prefix, idx)]= serverName
								else:
										sibProperties["%s.queueDestinations.%d.server" % (prefix, idx)] = ""
										
								break

						
						# now print other properties
						# Special handling of exceptionDestination blank values
						val = AdminConfig.showAttribute(queue, "exceptionDestination")
						if (isEmpty(val)):
								val = "''"
						sibProperties["%s.queueDestinations.%d.prop.exceptionDestination" % (prefix,idx)] = val
						collectSimpleProperties(sibProperties,"%s.queueDestinations.%d.prop" % (prefix,idx), queue, ['identifier'])
						
						contextInfoList = wsadminToList(AdminConfig.showAttribute(queue, "contextInfo"))
						ciidx = 0
						for contextInfo in contextInfoList:
								if (not isEmpty(contextInfo)):
										ciidx =  ciidx + 1
										collectSimpleProperties(sibProperties,"%s.queueDestinations.%d.contextInfo.%d.prop" % (prefix, idx, ciidx), contextInfo)
						sibProperties["%s.queueDestinations.%d.contextInfo.count" % (prefix, idx)] =  "%d" % ciidx
						
						replyDestination = AdminConfig.showAttribute(queue,"replyDestination")
						if (not isEmpty(replyDestination)):
								collectSimpleProperties(sibProperties,"%s.queueDestinations.%d.replyDestination.prop" % (prefix,idx), replyDestination)
								
						defaultForwardRoutingPathList = wsadminToList(AdminConfig.showAttribute(queue, "defaultForwardRoutingPath"))
						rpidx = 0
						for defaultForwardRoutingPath in defaultForwardRoutingPathList:
								if (not isEmpty(defaultForwardRoutingPath)):
										rpidx = rpidx + 1
										collectSimpleProperties(sibProperties,"%s.queueDestinations.%d.defaultForwardRoutingPath.%d.prop" % (prefix, idx, rpidx), defaultForwardRoutingPath)
						sibProperties["%s.queueDestinations.%d.defaultForwardRoutingPath.count" % (prefix, idx)] = "%d" % rpidx
						
						localizationPointRefsList = wsadminToList(AdminConfig.showAttribute(queue, "localizationPointRefs"))
						lpidx = 0
						for localizationPoint in localizationPointRefsList:
								lpidx = lpidx + 1
								
								clusterName = AdminConfig.showAttribute(localizationPoint,"cluster")
								nodeName = AdminConfig.showAttribute(localizationPoint,"node")
								serverName = AdminConfig.showAttribute(localizationPoint,"server")
								if (not isEmpty(clusterName)):
										sibProperties["%s.queueDestinations.%d.localizationPointRefs.%d.cluster" % (prefix, idx, lpidx)] = clusterName
								
								if (not isEmpty(nodeName)):
										sibProperties["%s.queueDestinations.%d.localizationPointRefs.%d.node" % (prefix, idx, lpidx)] = nodeName 
										
								if (not isEmpty(serverName)):
										sibProperties["%s.queueDestinations.%d.localizationPointRefs.%d.server" % (prefix, idx, lpidx) ]= serverName

								
								collectSimpleProperties(sibProperties,"%s.queueDestinations.%d.localizationPointRefs.%d.prop" % (prefix, idx, lpidx), localizationPoint, ['cluster','node','server'])
								
						sibProperties["%s.queueDestinations.%d.localizationPointRefs.count" % (prefix, idx)]= "%d" % lpidx
								
						
						
						# Not sure if we need to handle these
						# destinationMediationRef SIBDestinationMediationRef
						mediationRef = AdminConfig.showAttribute(queue,"destinationMediationRef")
						if (not isEmpty(mediationRef)):
						  collectSimpleProperties(sibProperties,"%s.queueDestinations.%d.destinationMediationRef.prop" % (prefix,idx),
						                          mediationRef,getSimpleChildren=1,collectListChildren=1)
						  mediationUUID = sibProperties.get("%s.queueDestinations.%d.destinationMediationRef.prop.mediationUuid" % (prefix,idx))
						  sibProperties["%s.queueDestinations.%d.destinationMediationRef.mediationName" % (prefix,idx)] = getMediationNameFromUUID(busName,mediationUUID)
						 

								
						
		
		sibProperties["%s.queueDestinations.count" % (prefix) ] ="%d" % (idx)

#------------------------------------------------------------------------------
# getSIBTopicProperties
#
# Return settings for TopicSpace definitions as properties.
#
# Parameters:
#     sibProperties - Property set to update
#     busName - Name of the bus
#     prefix - Prefix string to use with property keys: [prefix].topicDestinations
#------------------------------------------------------------------------------
def getSIBTopicProperties(sibProperties,busName, prefix):

		topicList = wsadminToList(AdminTask.listSIBDestinations('[-bus "%s" -type TopicSpace]' % (busName)))
		idx = 0
		for topic in topicList:
				if (not isEmpty(topic)):
						idx = idx + 1
						qidentifier = AdminConfig.showAttribute(topic, "identifier")
						sibProperties["%s.topicDestinations.%d.identifier" % (prefix,idx)] = qidentifier
						
						# now print other properties
						collectSimpleProperties(sibProperties,"%s.topicDestinations.%d.prop" % (prefix,idx), topic, ['identifier'])
						
						contextInfoList = wsadminToList(AdminConfig.showAttribute(topic, "contextInfo"))
						ciidx = 0
						for contextInfo in contextInfoList:
								if (not isEmpty(contextInfo)):
										ciidx =  ciidx + 1
										collectSimpleProperties(sibProperties,"%s.topicDestinations.%d.contextInfo.%d.prop" % (prefix, idx, ciidx), contextInfo)
						#endfor

						sibProperties["%s.topicDestinations.%d.contextInfo.count" % (prefix, idx)] = "%d" % ciidx
						
						replyDestination = AdminConfig.showAttribute(topic,"replyDestination")
						if (not isEmpty(replyDestination)):
								collectSimpleProperties(sibProperties,"%s.topicDestinations.%d.replyDestination.prop" % (prefix,idx), replyDestination)
								
								
						# Localization point references is probably not needed						
						localizationPointRefsList = wsadminToList(AdminConfig.showAttribute(topic, "localizationPointRefs"))
						lpidx = 0
						for localizationPoint in localizationPointRefsList:
								lpidx = lpidx + 1
								
								clusterName = AdminConfig.showAttribute(localizationPoint,"cluster")
								nodeName = AdminConfig.showAttribute(localizationPoint,"node")
								serverName = AdminConfig.showAttribute(localizationPoint,"server")
								if (not isEmpty(clusterName)):
										sibProperties["%s.topicDestinations.%d.localizationPointRefs.%d.cluster" % (prefix, idx, lpidx)] = clusterName
								
								if (not isEmpty(nodeName)):
										sibProperties["%s.topicDestinations.%d.localizationPointRefs.%d.node" % (prefix, idx, lpidx)] = nodeName
										
								if (not isEmpty(serverName)):
										sibProperties["%s.topicDestinations.%d.localizationPointRefs.%d.server" % (prefix, idx, lpidx)] = serverName

								
								collectSimpleProperties(sibProperties,"%s.topicDestinations.%d.localizationPointRefs.%d.prop" % (prefix, idx, lpidx), localizationPoint, ['cluster','node','server'])
						
						#endfor		
						sibProperties["%s.topicDestinations.%d.localizationPointRefs.count" % (prefix, idx)] = "%d" % lpidx
								
						
						# destinationMediationRef SIBDestinationMediationRef
						mediationRef = AdminConfig.showAttribute(topic,"destinationMediationRef")
						if (not isEmpty(mediationRef)):
						  collectSimpleProperties(sibProperties,"%s.topicDestinations.%d.destinationMediationRef.prop" % (prefix,idx),
						                          mediationRef,getSimpleChildren=1,collectListChildren=1)
						  mediationUUID = sibProperties.get("%s.queueDestinations.%d.destinationMediationRef.prop.mediationUuid" % (prefix,idx))
						  sibProperties["%s.topicDestinations.%d.destinationMediationRef.mediationName" % (prefix,idx)] = getMediationNameFromUUID(busName,mediationUUID)						
						

				
		
		sibProperties["%s.topicDestinations.count" % (prefix)] = "%d" % (idx)
#enddef getSIBTopicProperties


#-------------------------------------------------------------------------------
# findMediation
#   Returns the configuration ID for the specified mediation
#
# Parameters
#   busName - Name of SIBus that mediation is defined for
#   mediationName - name to look for
#-------------------------------------------------------------------------------
def findMediation(busName,mediationName):
  _app_entry("findMediation(%s,%s)" , busName,mediationName)
  retval = None
  try:
    mediationIDs = AdminConfig.getid("/SIBus:%s/SIBDestinationMediation:/" % busName).splitlines()
    for mediationID in mediationIDs:
      if (isEmpty(mediationID)): continue
      
      tempName = AdminConfig.showAttribute(mediationID,"mediationName")
      if (tempName == mediationName):
        retval = mediationID
        break
  except:
    _app_exception("Unexpected problem in findMediation()")
  
  _app_exit("findMediation(retval=%s)" % retval)
  return retval




#-------------------------------------------------------------------------------
# updateMediation
#
# Parameters
#   busName - name of Bus mediation is defined for (optional - required if no ID supplied)
#   mediationName - name of mediation (optional - required if no ID supplied)
#   mediationId - Configuration ID of mediation to update (optional - required if bus/name not supplied)
#   contextInfoList - list of dictionaries that define properties for SIBContextInfo objects
#-------------------------------------------------------------------------------
def updateMediation(busName=None,mediationName=None,mediationId=None,mediationProps=None,contextInfoList=None):
  _app_entry("updateMediation(%s,%s,%s,%s,%s)" , busName,mediationName,mediationId,mediationProps,contextInfoList)
  retval = mediationId
  try:
    
    if (isEmpty(mediationId) and not isEmpty(busName) and not isEmpty(mediationName)):
      mediationId = findMediation(busName,mediationName)
      retval = mediationId
    
    if (isEmpty(mediationId)):
      raise StandardError("Mediation ID is empty")

    excludeAttrs = ['mediationName','uuid']
    attrs = []
    for key in mediationProps.keys():
      if key not in excludeAttrs:
        attrs.append([key,mediationProps[key]])
    
    if (len(attrs) > 0):
      if (modifyObject(mediationId,attrs)):
        raise StandardError("Error applying attributes to Mediation %s" % mediationName)
    
    # Update the context info
    if (contextInfoList != None and len(contextInfoList) > 0):
      applyContextInfo(mediationId,contextInfoList,"contextInfo")
    
  except:
    _app_exception("Unexpected problem in updateMediation()")
  
  _app_exit("updateMediation(retval=%s)" % retval)
  return retval
  



#-------------------------------------------------------------------------------
# createMediation
#
# Parameters
#
#   busName - name of Bus mediation is defined for 
#   mediationName - name of mediation 
#   mediationProps - dictionary of mediation attributes (handlerListName is required attribute)
#   contextInfoList - list of dictionaries that define properties for SIBContextInfo objects
#
# Returns:
#   mediationId - Configuration ID of mediation
#-------------------------------------------------------------------------------
def createMediation(busName,mediationName,mediationProps,contextInfoList=None):
  _app_entry("createMediation(%s,%s,%s,%s)" , busName,mediationName,mediationProps,contextInfoList)
  retval = None
  try:
    parms = "[-bus '%s' -mediationName '%s' -handlerListName '%s']" % (busName,mediationName,mediationProps.get("handlerListName"))
    
    _app_trace("About to call AdminTask.createSIBMediation(%s)" % parms)
    retval = AdminTask.createSIBMediation(parms)
    
    excludeAttrs = ['mediationName','handlerListName']
    attrs = []
    for key in mediationProps.keys():
      if key not in excludeAttrs:
        attrs.append([key,mediationProps[key]])
    
    if (len(attrs) > 0):
      if (modifyObject(retval,attrs)):
        raise StandardError("Error applying attributes to Mediation %s" % mediationName)
    
    # Create the context info
    if (contextInfoList != None and len(contextInfoList) > 0):
      applyContextInfo(retval,contextInfoList,"contextInfo")
    
  except:
    _app_exception("Unexpected problem in createMediation()")
  
  _app_exit("createMediation(retval=%s)" % retval)
  return retval
  

#-------------------------------------------------------------------------------
# applyContextInfo
#   Creates or updates SIBContextInfo for a specified configuration item
#
# Parameters
#    configurationId - Parent item
#    contextInfoList - a list of dictionaries containing properties for item to update
#    attributeName - name of SIBContextInfo attribute (defaults to contextInfo) 
#-------------------------------------------------------------------------------
def applyContextInfo(configurationId,contextInfoList,attributeName="contextInfo"):
  _app_entry("applyContextInfo(%s,%s,%s) ",configurationId,contextInfoList,attributeName)
  retval = None
  existingDict = {}
  try:
    # Build dictionary of existing context info
    existingList = wsadminToList(AdminConfig.showAttribute(configurationId,attributeName))
    for contextId in existingList:
      if (not isEmpty(contextId)):
        contextInfoName = contextId.split("(")[0]
        existingDict[contextInfoName] = contextId
    
    # Now loop through list of contextInfo to update/add
    for contextDict in contextInfoList:
      contextName = contextDict.get("name",None)
      if (isEmpty(contextName)): continue
      
      attrs = []
      for key in contextDict.keys():
        if (key == "name"): continue
        
        attrs.append([key,contextDict[key]])
      
      existingId = existingDict.get(contextName,None)
      
      if (not isEmpty(existingId)):
        if (modifyObject(existingId,attrs)):
          raise StandardError("Error updating SIBContextInfo %s" % existingId)
      else:
        attrs.append(["name",contextName])
        _app_trace("About to call AdminConfig.create('SIBContextInfo',%s,%s,%s)" % (configurationId,attrs,attributeName))
        newId = AdminConfig.create("SIBContextInfo",configurationId,attrs,attributeName)
        
    
  except:
    _app_exception("Unexpected problem in applyContextInfo()")
  
  _app_exit("applyContextInfo(retval=%s)" % retval)
  return retval


#-------------------------------------------------------------------------------
# getSIBDestinationMediationProperties
#   get properties for all mediations defined for the SIBus
#    
#
# Parameters
#
#
# Returns:
#   Adds key/value pairs to existingProps to represent mediation settings
#   [prefix].mediations.[idx].medationName = mediationName
#   [prefix].mediations.[idx].ID = configurationID
#-------------------------------------------------------------------------------
def getSIBDestinationMediationProperties(existingProps,busName, prefix="app.sibus"):
  _app_entry("getSIBDestinationMediationProperties(existingProps,%s,%s)" , busName,prefix)
  retval = existingProps
  try:
    #some stuff
    mediationIDs = AdminConfig.getid("/SIBus:%s/SIBDestinationMediation:/" % busName).splitlines()
    medIdx = 0
    for mediationId in mediationIDs:
      if (isEmpty(mediationId)):
        continue
      medIdx += 1
      mediationName = AdminConfig.showAttribute(mediationId,"mediationName")
      
      medPrefix = "%s.mediations.%d" % (prefix,medIdx)
      existingProps["%s.mediationName"% medPrefix] = mediationName
      existingProps["%s.ID" % medPrefix] = mediationId
      collectSimpleProperties(retval, "%s.prop"% medPrefix,mediationId,optionalSkipList=["mediationName"], idProps=None,getSimpleChildren=0,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=1)
                           
    
    existingProps["%s.mediations.count"%prefix] = str(medIdx)
  except:
    _app_exception("Unexpected problem in getSIBDestinationMediationProperties()")
  
  _app_exit("getSIBDestinationMediationProperties(retval=%s)" % retval)
  return retval
  
#-------------------------------------------------------------------------------
# getMediationProperties
#
# Parameters
#
#-------------------------------------------------------------------------------
def getMediationProperties(mediationId=None,busName=None,mediationName=None):
  _app_entry("getMediationProperties(%s,%s,%s)" , mediationId,busName,mediationName)
  retval = {}
  try:
    if (isEmpty(mediationId) and not isEmpty(busName) and not isEmpty(mediationName)):
      mediationId = findMediation(busName,mediationName)
    
    if (isEmpty(mediationId)):
      raise StandardError("Mediation ID is empty")
    
    collectSimpleProperties(retval, "mediation.prop",mediationId, optionalSkipList=["mediationName"],idProps=None,getSimpleChildren=0,childrenSkipList=None,
                           collectPropertyAttributes=1,useAttrNameWithProperties=1,collectListChildren=1)
    
    
  except:
    _app_exception("Unexpected problem in getMediationProperties()")
  
  _app_exit("getMediationProperties(retval=%d items)" % len(retval))
  return retval


#AdminTask.mediateSIBDestination('[-bus PSExampleBus -mediationName MyTopicMediation -destinationName PSExampleTopicSpace -cluster MessagingClusterOne]')


#-------------------------------------------------------------------------------
# addMediationToSIBDestination
#
# Parameters
#    busName
#    mediationName
#    destinationName
#    clusterName
#    nodeName
#    serverName
#-------------------------------------------------------------------------------
def addMediationToSIBDestination(busName, mediationName, destinationName,clusterName=None,nodeName=None,serverName=None):  
  _app_entry("addMediationToSIBDestination(%s,%s,%s,%s,%s,%s)" , busName, mediationName, destinationName,clusterName,nodeName,serverName)
  retval = None
  try:
    parms = "-bus '%s' -mediationName '%s' -destinationName '%s'" % (busName,mediationName,destinationName)
    if (not isEmpty(clusterName)):
      parms = "[ %s -cluster %s ]" % (parms,clusterName)
    else:
      parms = "[ %s -node %s -server %s ]" % (parms,nodeName,serverName)
    
    _app_trace("About to call AdminTask.addMediationToSIBDestination(%s)" % parms)
    retval = AdminTask.mediateSIBDestination(parms)
    
  except:
    _app_exception("Unexpected problem in addMediationToSIBDestination()")
  
  _app_exit("addMediationToSIBDestination(retval=%s)" % retval)
  return retval
  
  

  
  