
# ApplicationUtilities.py
#
# This script contains functions for manipulating Applications. With this script,
# you can do the following:
#
#     -Export the application ear file and the AdminApp installation instructions to 
#      an installation template file.
#     -Install an application using the ear file and installation template file
#     -Update an installed application using an ear file and installation template file.
#
# wsadmin invocation notes:
#    This script requires that wsadmin be invoked with the -profile Profile.py option
#    to set up the sys.modules dictionary correctly.
#
# Related Modules: The following modules are used by this script:
#     LoggingUtils.py - message formatting and exeception stack formatting
#     PropertiesUtils.py - Funncitons for reading and writing sectioned property files,
#     Profile.py - A wsadmin profile script that loads sys.modules
#     Utils.py - Various utility methods for wsadmin programming
#     
#
# Command line options
#
#    -command
#        Format: -command command-name where command-name can be
#                    extract     : Create the ear file and template file
#                    extractall  : Extract ear files and templates files for all applications
#                                  or those that match the pattern passed to -applicationname
#                    apply       : Use a template file and ear file to either install or
#                                  update an application
#                    remove      : Remove an application after extracting the current 
#                                  configuration 
#                        
#
#    -applicationname
#        Format: -applicationname application-name where application-name is the name
#                of the application in the WebSphere configuration.  
#                Used with the following commands: extract,apply,remove,extractall
#
#    -targetdirectory
#        Format: -targetdirectory directory where directory is the directory path used to 
#                 write template files and store ear files. 
#                 Used with the following commands: extract
#    -earfile
#        Format: -earfile ear-file-location where ear-file-location is the fully
#                qualified location of the ear file 
#                Used with the following commands: apply
#    -templatefile
#        Format: -templatefile template-file-location where template-file-location is
#                the fully qualified location of the ear file.
#                Used with the following commands: apply
#    -variablemapfile
#        Format: -variablemapfile var-file-location where var-file-location is the fully
#                qualified location of the property file containing the variable substitution 
#                values that will be applied to the template
#                Used with the following commands: apply
#
#    -variableSection
#        Format: -variableSection section-name where section-name is the section to
#                 load variables from in the variablemapfile. Optional. The cell name
#                 is the default value. 
#                 Used with the following commands: apply
#    -backupdirectory
#                Used with the following commands: apply,remove
#
#    -installOptions
#        Format: -installOptions=option1+option2+option3 or
#                -installOptions=option1 -installOptions=option2 -installOptions=option3
#                Where option is the option that would be passed to AdminApp.install or 
#                AdminApp.update. The AdminApp option should include the "-".
#                Example:  -installOptions=-deployejb+-deployws
#                Used with the following commands: apply
#
#    -skipEarExtraction
#         Format:  -skipEarExtraction [true|false]
                 
#
#    -transformTaskParms
#    -serversToClusters 
#    -webserversToVars
#    -cellToVar
#        Format: -transformTaskParms [-serversToClusters [true|false]] [-webserversToVars [true|false]] [-cellToVar [true|false]]
#                if -transformTaskParms is specified, then certain values in the template file will be replaced based
#                on the other options supplied.
#                -serversToClusters - Modules mapped to servers will be changed to map to a cluster with the name of the server
#                -webserversToVars - WebServer node=,name= value will be replaced with a #{WEB_SERVERn} variable
#                -cellToVar - the cell name will be replaced with a #{CELL_NAME} variable
#                 Used with the following commands: extract, extractall
#
#     
# Example command line:
# $WAS_HOME/wsadmin.bat -lang jython -profile Profile.py -f ApplicationUtilities.py -command apply -applicationName SampleEAR 
#    -templatefile c:/temp/extracted/SampleEARInstallArguments.props -backupdirectory c:/temp/extracted/backups 
#    -variablemapfile repvars.props -earfile c:/temp/Sample.ear
#
# Example command line: Extract
# wsadmin.sh -lang jython -profile Profile.py -f ApplicationUtilities.py -command extract -applicationName SampleEAR2 
#            -targetdirectory /home/extractedApps -transformTaskParms -serversToClusters false -webserversToVars -cellToVar
# 
#
# The following is an example of the sectioned property file format used by the script
'''
[Application-Configuration-Overview]
originatingHost=localhost
originatingCell=ScriptingCell
applicationName=SampleEAR2
[Application-Configuration-Overview->Base-Application-Options]
# This section is currently not used to load installation options
Use Binary Configuration=No
Create MBeans for resources=Yes
Reload interval in seconds=
File Permission=.*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755
Enable class reloading=No
...
[Optional-Install-Options]
# Enter simple install options as the value of options. Example:
# options=-deployejb -deployws
options=

[Tasks]
# The tasks step arguments are represented with positional parameters
# For each task there is a ParmDescription section followed by one 
# or more ParmList sections with unique names
[Tasks->CtxRootForWebMod]
[Tasks->CtxRootForWebMod->ParmDescription]
parm1=Web module
parm2=URI
parm3=ContextRoot
[Tasks->CtxRootForWebMod->ParmList1]
parm1=SampleWebApp
parm2=SampleWebApp.war,WEB-INF/web.xml
parm3=SampleWebApp
[Tasks->CtxRootForWebMod->ParmList2]
parm1=AnotherWebApp
parm2=AnotherWebApp.war,WEB-INF/web.xml
parm3=AnotherWebApp

[Tasks->MapEJBRefToEJB]
[Tasks->MapEJBRefToEJB->ParmDescription]
parm1=Module
...
...
'''


#-----------------------------------------------
# Utils.py - a set of utility functions that ease standard 
# chores in wsadmin programming.
#-----------------------------------------------






def isEmpty(var):
    """
    Used to check some "empty" results that are returned by Admin objects but may
    not be treated as false by the interpreter.
    """
    return (var == "" or var == None or var == "[]" or str(var) == "['']")


def getNodeNameForServer(serverId):
    """
    Utility function that extracts the node name from a 
    server configuration ID
    """
    tokens = serverId.split("nodes/")
    split2 = tokens[1].split("/")
    nodeName =  split2[0]
    
    return nodeName

#enddef

def wsadminToList(inStr):
    """
    Translates strings returned by wsadmin functions representing arrays "[ foo bar ]" to real python arrays ['foo', 'bar']
    
    @return: a Python list
    
    >>> wsadminToList("[ foo bar ]")
    ['foo', 'bar']
    >>> wsadminToList("[foo bar]")
    ['foo', 'bar']
    >>> wsadminToList("[ [cell ifa61] [serverType APPLICATION_SERVER] ]")
    ['cell ifa61', 'serverType APPLICATION_SERVER']
    >>> wsadminToList('[(cells/adev61/nodes/foo/servers/dmgr|server.xml#NameServer_1) "Deployment Manager(cells/adev61/nodes/foo/servers/dmgr|server.xml#CellManager_1)"]')
    ['(cells/adev61/nodes/foo/servers/dmgr|server.xml#NameServer_1)', '"Deployment Manager(cells/adev61/nodes/foo/servers/dmgr|server.xml#CellManager_1)"']
    >>> wsadminToList('[TEST_PROP(cells/aci61|resources.xml#J2EEResourceProperty_1271379509181) "wsrp.consumer.cookieforward.sabs:params"(cells/aci61|resources.xml#J2EEResourceProperty_1275873189713) "wer wer(cells/aci61|resources.xml#J2EEResourceProperty_1275875033329)" sfsdf(Sfsdfsdf(cells/aci61|resources.xml#J2EEResourceProperty_1275875113971)]')
    ['TEST_PROP(cells/aci61|resources.xml#J2EEResourceProperty_1271379509181)', '"wsrp.consumer.cookieforward.sabs:params"(cells/aci61|resources.xml#J2EEResourceProperty_1275873189713)', '"wer wer(cells/aci61|resources.xml#J2EEResourceProperty_1275875033329)"', 'sfsdf(Sfsdfsdf(cells/aci61|resources.xml#J2EEResourceProperty_1275875113971)']
    """
    outList = []

    if not inStr: return outList

    if inStr.startswith('[ [') and inStr.endswith('] ]'):
        tmpList = inStr[3:-3].split('] [')
    elif inStr.startswith('[') and inStr.endswith(']'):
        tmpList = []
        inQuotes = 0
        current = ""
        for char in inStr[1:-1]:
            if len(current) == 0 and char == '"':
                inQuotes = 1
                current = '"'
            elif char == '"':
                inQuotes = 0
                current += '"'
            elif not inQuotes and char == " ":
                tmpList.append(current)
                current = ""
            else:
                current += char
        if len(current) > 0: tmpList.append(current)
    else:
        tmpList = inStr.splitlines()

    for item in tmpList:
        item = item.rstrip()
        if len(item) > 0: outList.append(item)
    return outList



#------------------------------------------------------------------------------------------------------
# wsadminToDictionary - turn a string of bracketed key value pairs into a dictionary
# Example:
#        [ [com.ibm.websphere.baseProductVersion 6.1.0.35] [com.ibm.websphere.nodeOperatingSystem aix] ]
#   OR
# '{password=, logMissingTransactionContext=false, readAhead=Default, tempQueueNamePrefix=, shareDurableSubscriptions=InCluster, targetTransportChain=,
#   authDataAlias=ConfigurationScriptingDmgr/Dude, userName=, targetSignificance=Preferred, shareDataSourceWithCMP=false, providerEndPoints=, 
#  nonPersistentMapping=ExpressNonPersistent, persistentMapping=ReliablePersistent, clientID=, jndiName=jms/SampleSIBQueueCF, manageCachedHandles=false, 
#  category=, busName=SampleBus, targetType=BusMember, xaRecoveryAuthAlias=Dude3, description=, connectionProximity=Bus, target=SampleCluster, name=SampleSIBQueueCF}'
#------------------------------------------------------------------------------------------------------
def wsadminToDictionary(inStr):
        outDictionary = {}
        if (len(inStr)>0 and inStr[0]=='[' and inStr[-1]==']'):
                inStr = inStr[1:-1]
                tlist = inStr.split(" ")
                currentKey = ""
                currentVal = ""
                for token in tlist:
                    if (isEmpty(token)):
                            continue
                    if (token[0] == "["):
                            token = token[1:]
                            currentKey = token
                            currentVal = ""
                            continue
                    
                    if (token[-1] == "]"):
                            token = token[:-1]
                            currentVal = token
                    if (currentKey != "" and currentVal != ""):
                            outDictionary[currentKey] = currentVal
                            currentKey = ""
                            currentVal = ""
        elif (len(inStr) > 0 and inStr[0] =='{' and inStr[-1] == '}'):
                # Parse the second format
                inStr = inStr[1:-1]
                tlist = inStr.split(",")
                for token in tlist:
                        val = ""
                        key = ""
                        keyval = token.split("=")
                        if (len(keyval) == 1):
                                key = keyval[0]
                        elif (len(keyval) == 2):
                                key = keyval[0]
                                val = keyval[1]
                        
                        key = key.lstrip()
                        val = val.rstrip()
                        outDictionary[key] = val
        
        return outDictionary

#------------------------------------------------------------------------------------------------------
def isArray(inStr):
    if (inStr.startswith("[") and inStr.endswith("]")):
        return 1
    return 0
#------------------------------------------------------------------------------------------------------
def isId(inStr):
    if (inStr.find("#") > 0 and inStr.find("/") > 0 and inStr.endswith(")")):
        return 1
    return 0

def toKeyValue(inStr):
    """
      Converts a string representation of a key value pair, "[key value]", to a key value tuple
    """
    s = inStr[1:-1]
    k = s[:s.find(' ')]
    v = s[len(k) + 1:]
    return k,v


def wildcardToRegExpString(inStr,wildcard='*'):
    """
    wildcardToRegExpString - converts a string that treats asterisk as wild card to regular expression 
    string,  "Hello*" -> "Hello.*?"
    
    Parameters:
        inStr - inputString
        wildcard - the wildcard character to use (defaults to "*")
    
    """
 
    retval = ""
    if (isEmpty(inStr)):
        retval = ".*"
    elif (inStr.find(wildcard) <0):
        # Not a supported syntax
        retval = inStr
    elif (inStr == "*"):
        retval = ".*"
    else:
        prefix = "";
        if (inStr.startswith(wildcard)):
            prefix = ".*?"
        suffix = ""
        if (inStr.endswith(wildcard)):
            suffix = ".*?";
        else:
            suffix = "$"
        
        tokens = inStr.split(wildcard)
        retval = ""
        for token in tokens:
       
            if (retval == ""):
                retval = token
            elif (token != ""):
                retval = "%s.*?%s" % (retval,token)
      
        retval = "%s%s%s" % (prefix,retval,suffix)
      
   
    return retval
#enddef

def collectAttributes(objId, prefix=None, optionalSkipList=[]):
    """
    collectAttributes
    
    Put key/value pairs from configuration item into a dictionary. If the item contains sub-items
    or listed attributes, those IDs will be returned in a separate dictionary where the attribute
    name references an ID or a list of IDs
    
    Parameters:
        objId - The configuration item to collect attribute properties from
        prefix - prefix to use for property names. Attribute names will be appended to the prefix
                 with a . separator. If blank, no prefix will be used.
        optionalSkipList - A list of attributes to ignore
    Returns:
         attributeDict,idDict - A tuple containing two dictionaries:
                                 attributeDict - a dictionary of key value pairs for simple attributes
                                 idDict - a dictionary containing either key-ID or key-[list of IDs] pairs
                                          for complex attributes    
    """
                
    attributeDict = {}    
    idDict = {}
    try:
        if (prefix):
            if (not prefix.endswith(".")):
                prefix = "%s." % prefix
        else:
            prefix = ""
            
        attributeDict = {}    
        idDict = {}
        
        if (not objId): return {},{}
        
        skipTags = ["managedObject", "server"]
        attrs = AdminConfig.show(objId).splitlines()
        for attr in attrs:
                key,val= toKeyValue(attr)
                
                if (key in skipTags): continue
                if (key in optionalSkipList): continue
                if (isEmpty(val)): continue
                
                if (val.startswith('"') and val.endswith('"')):
                        val = val[1:-1]
                
                if (isArray(val)):
                    idDict["%s%s" % (prefix, key)] = wsadminToList(val)
                    continue
                  
                if (isId(val) == 1):
                    idDict["%s%s" % (prefix, key)] = val
                    continue
                else:
                    attributeDict["%s%s" % (prefix, key)] = val
    except:
        raise StandardError("Error collecting attributes")
        
    return attributeDict,idDict 


import sys

#----------------------------------------------------
# formatExceptionData
#
# Formats exception data for _app_message or _app_trace
#
# Parameters:
#   tnow - timestamp string to use
#
# Returns formatted string
#----------------------------------------------------
def formatExceptionData(tnow):
    import traceback
    
    exc_type,exc_value,exc_traceback = sys.exc_info()
    exceptionString = "%s %s %s" % (tnow, exc_type, exc_value)
    
    resultString = exceptionString
    
    resultString = resultString + "\n" + "%s Frame stack:"% tnow
    try:
        stacklist = traceback.extract_stack()
        for stackdata in stacklist:
            stackfile,stackln,stackfn,stacktext = stackdata
        
            # Remove calls to _app_message from stack
            if (stackfn != None and stackfn.find("_app_message") >=0):
                break
            if (stacktext != None and stacktext.find("_app_message") >= 0):
                break
        
            resultString = resultString + "\n" + '%s   File "%s", line %s, in %s' % (tnow, stackfile, stackln, stackfn)

    except:
        resultString = resultString + "\n" + "error getting stack"
        pass    

    resultString = resultString + "\n" + "%s Exception stack:" % tnow
    try:
        tb = sys.exc_info()[2]
        tblist = traceback.extract_tb(tb,10)
        for tbdata in tblist:
            stackfile,stackln,stackfn,stacktext = tbdata          
            resultString = resultString + "\n" + '%s   File "%s", line %s, in %s' % (tnow, stackfile, stackln, stackfn)
            if (stacktext != None and stacktext != ""):
                resultString = resultString + "\n" + "%s    %s" % (tnow,stacktext)
    except:
        resultString = resultString + "\n" + "error getting exception stack"
        pass
      
    return resultString

#------------------------------------------------------------
# _app_message - Used to produce formatted message for stdout
#------------------------------------------------------------
def _app_message(instr,exception=None):


    from java.util import Date
    from java.text import SimpleDateFormat
    
    now = Date()
    sdf = SimpleDateFormat("dd/MM/yyyy HH:mm:ss:SSS z")
    tnow = "[%s]" % (sdf.format(now))
    
    printstr = "%s %s" % (tnow, instr)
    
    print printstr
    #writeToLog(printstr)
    
    
    if (exception):
        exceptionString = formatExceptionData(tnow)
        print exceptionString
        #writeToLog(exceptionString)

#enddef



#--------------------------------------------------------------------
# PropertiesUtils.py
#
# This module holds utility functions for reading from and writing to
# sectioned property files, including utilities for handling variable
# replacement when reading from the file.
# 
# The property files are in the following format:
#
#       [Section-Name]
#       KEY1=Val1
#       KEY2=#{VAR2}
#       KEY3=Val3
#       
#       [Section-Name->SubSection1-Name]
#       VAR1=Val1
#       VAR2=Val2
#       
#       [Section-Name->SubSection1-Name->SubSection2-Name(->SubSection3-Name....)]
#       VAR1=Val1
#
#       [Section2-Name]
#       ...



#----------------------------------------------------------------------
# Because some code may repeatedly reads different sections of a 
# property file, we store the string-lists of loaded files in a
# dictionary keyed by the file name.  A fifo list is used to 
# determine who to bump from the cache should it ever reach to
# a predetermine limit (based on # of lines stored)
global cachedFiles
global cachedFifo
global MAX_FILE_LINES

cachedFiles = {}
cachedFifo = []
MAX_FILE_LINES = 1000000


def loadFileAsList(filename,cache=1):
    """
    This utility method will read the specified file name and
    return a list of the lines. If cache is true, then the 
    file might be stored in a cache for later retrieval
    """
    
    resultList = None
    if (cache):
        resultList = cachedFiles.get(filename,None)
    
    if (not resultList):
        # Need to read from a file
        try:
            f = open(filename,"r")
            
            resultList = f.readlines()
            
            f.close()
            
            if (cache and len(resultList) < MAX_FILE_LINES):
                # See if there is room
                numLines = len(resultList)
                
                for filelist in cachedFiles.values():
                    numLines +=  len(filelist)
                
                if (numLines < MAX_FILE_LINES):
                    cachedFiles[filename] = resultList
                    cachedFifo.append(filename)
                else:
                    # Remove files form our cache
                    while (len(cachedFifo) > 0 and numLines >= MAX_FILE_LINES):
                        removedList = cachedFiles[cachedFifo[0]]
                        numLines -= len(removedList)
                        del removedList
                        del cachedFiles[cachedFifo[0]]
                        del cachedFifo[0]
                    
                    # Now that we've freed up room, add file to cache
                    cachedFiles[filename] = resultList
                    cachedFifo.append(filename)
                #end else need to free up room
            #end if file is small enough to cache
        except:
            _app_message("Unable to load file %s"% filename,"exception")
            raise StandardError("Unable to load file %s"%filename)
    
    #endif file needed to be loaded
    
    return resultList 
#enddef


        
    


def replaceVariables(inputString, varDictionary, openingBracket="#{",closingBracket="}"):
    """
    Process a string and replace variable names specified by #{VAR_NAME} with
    the value from varDictionary[VAR_NAME]
    
    If VAR_NAME is not in the dictionary, do not replace it.
    
    There may be multiple variables in the string
    
    returns the updated string
    
    The opening and closing brackets can be specified as other tokens if necessary.
    """
    startindex=0
    outputString = inputString
    length=len(outputString)
    while (startindex < length):
        initindex=outputString.find(openingBracket,startindex)
        if (initindex==-1):
            break
        finalindex=outputString.find(closingBracket,initindex) 
        var=outputString[initindex+2:finalindex]
        oldvar=openingBracket + var + closingBracket
        val = varDictionary.get(var,oldvar)
        outputString=outputString.replace(oldvar,val) 
        startindex=initindex + len(val) 
        length = len(outputString)
    return outputString


def replaceTokens(inputString, replacementMap):
    """
    This method will iterate through the tokens in the replacementMap and replace substrings
    in the inputString with values from the replacementMap.
    
    If a replacement target is identified in the string, this function will determine
    the best replacement for it. The best replacement is the one with longest string.
    
    for example, if the replacementMap is
       { "MyCellManagerNode": "NewCellMgrNode",
         "MyCell": "NewCell" }
         
    The the string "This is the node MyCellManagerNode" should become
    "This is the node NewCellMgrNode" and not "This is the node NewCellManagerNode"
    
    The best way to do this is to process replacement tokens in order of the size of
    the matching string.
    
    A string may have more than one 
    returns the value of the modified string
    """
    
    outputString = inputString
    
    if (replacementMap != None):
        dictkeys = replacementMap.keys()
        dictkeys.sort(lambda x,y: len(x) < len(y)) 

        outputString = inputString
        for key in dictkeys:
            if (outputString.find(key) != -1 ):
                tmpStr = outputString.replace(key, replacementMap[key])
                outputString = tmpStr
   
    return  outputString

#enddef
    
def loadVariables(variablePropertyFileName,sectionName,sectionSeparator="->",*subSections):
    """
    Read a property file in this syntax:
       [Section-Name]
       VAR1=Val1
       VAR2=Val2
       VAR3=Val3
       
       [Section-Name->SubSection1-Name]
       VAR1=Val1
       VAR2=Val2
       
       [Section-Name->SubSection1-Name->SubSection2-Name(->SubSection3-Name....)]
       VAR1=Val1
    
    This method will load the properties from the specified section or sub-section.
    The key-value pairs are returned as a dictionary
    
    The backslash is not treated as a special character.  
    """
    
    variableDictionary={}
    subStr=''
    lines = loadFileAsList(variablePropertyFileName,cache=0)
    if (sectionName):
            # Find the specified section
            if (sectionName.startswith("[")):
                sectionName = sectionName[1:-1].strip() 
            # Find subsection names
            if (subSections): 
                for sub in subSections:
                    subStr= subStr + sectionSeparator + sub
                sectionName += subStr
            idx=0
            sectionidx=0
            found = 0 
            # Find matching section and subsection in the file
            while idx < len(lines):
                    tempLine = lines[idx].strip()
                    if ((tempLine.startswith("[")) and found == 0 ):
                        tempSectionString = tempLine[1:-1].strip()
                        if (tempSectionString == sectionName):
                            found = 1 
                            sectionidx = idx+1
                            break
                        else: 
                            idx += 1 
                            continue
                    idx+=1
            # Finding the variable and value and returning Dictionary 
            while ((sectionidx < len (lines)) and found):  
                    tempLine = lines[sectionidx]
                    tempLine =tempLine.strip()
                    if (not tempLine or tempLine.startswith("#")):
                        sectionidx += 1
                        continue
                    if (not (tempLine.startswith("[")) and found ): 
                        findidx=tempLine.find('=')
                        variableDictionary[tempLine[:findidx].strip()]=tempLine[findidx+1:].strip()
                    if ((tempLine.startswith("[")) and found ):
                        break 
                    sectionidx += 1  

    return variableDictionary   
    

# readTemplatePropertySection("my.file",{},"Tasks")
# readTemplatePropertySection("my.file",{},"Tasks->MapEJB->ParamList1")
# readTemplatePropertySection("my.file",{},"Tasks","->",MapEJB","ParamList1")


def readTemplatePropertySection(templateFileName,variableMap,sectionName,sectionSeparator="->",*subSections):
    """
    Read a template file in this syntax:
       [Section-Name]
       KEY1=Val1
       KEY2=#{VAR2}
       KEY3=Val3
       
       [Section-Name->SubSection1-Name]
       VAR1=Val1
       VAR2=Val2
       
       [Section-Name->SubSection1-Name->SubSection2-Name(->SubSection3-Name....)]
       VAR1=Val1
    
    This method will load the properties from the specified section (and optional
    subsections).  The key-value pairs are returned as a dictionary after variable
    substitution has been performed.
    
    Section headers will also have variables replaced.
    
    The backslash is not treated as a special character.  
    
    This function returns a dictionary
    """
    
    resultDict = {}
    
    try:
        targetName = sectionName
        
        if (targetName.startswith("[")):
            targetName = targetName[1:-1].strip()
        
        if (subSections):
            for subSection in subSections:
                targetName ="%s%s%s" % (targetName,sectionSeparator,subSection)
        
        #print "Target name is %s"%targetName
        
        templateLines = loadFileAsList(templateFileName, cache=1)
        startingIndex = 0
        for templateLine in templateLines:
            templateLine = templateLine.strip()
            if (templateLine.startswith("[")):
                tempSectionName = templateLine[1:-1].strip()
                tempSectionName = replaceVariables(tempSectionName, variableMap)
                #print ("[%s] [%s]" % (tempSectionName,targetName))
                if (tempSectionName == targetName):
                    #print "Found!"
                    break
            
            startingIndex += 1
        #end for
        
        # Advance past section line
        currentIndex = startingIndex +1
        while (currentIndex < len(templateLines)):
            templateLine = templateLines[currentIndex].strip()
            
            if (not templateLine or templateLine.startswith("#")):
                currentIndex += 1
                continue
            
            if (templateLine.startswith("[")):
                break
            
            equalPos = templateLine.find("=")
            if (equalPos > 0):
                key = templateLine[0:equalPos].strip()
                value = templateLine[equalPos+1:].strip()
                
                # Now do variable substitution
                newValue = replaceVariables(value, variableMap)
                resultDict[key]=newValue
            
            currentIndex += 1
        #endwhile
        
            
        
    except:
        _app_message("Error in readTemplatePropertySection","exception")
        raise
    
    return resultDict

def writePropertySection(templateFile,sectionName,sectionProperties,keyorder=[],addLine=1,comment=""):
    """
    This method will add a property section to a sectioned property file.
    
    Parameters:
        templateFile - the file object for an open (writeable) file. Caller is responsible
                       for opening and closing
        sectionName - the name of the section 
        sectionProperties - dictionary with the key/values to write
        keyorder - An optional list of key names to be written first. Does not need to be
                   the full list of keys: [key1,key2,key3]
        addLine - If true, an extra new line will be added at end of section
        
        This method will write the following lines to the end of the file
        [sectionName]       
        key1=val1
        key2=val2
        key3=val3
        key4=val4
        key5=val5
        
                   
    """
    
    try:
        
        templateFile.write("[%s]\n"%sectionName)
        if (comment):
            for commentlines in comment.splitlines():
                templateFile.write("# %s\n"%commentlines)
        
        for key in keyorder:
            if (sectionProperties.has_key(key)):
                templateFile.write("%s=%s\n"% (key,sectionProperties[key]))
        
        for key in sectionProperties.keys():
            if key not in keyorder:
                templateFile.write("%s=%s\n"% (key,sectionProperties[key]))
        
        if (addLine):
            templateFile.write("\n")
    except:
        _app_message("Error writing property section","exception")
        raise StandardError("Error writing property section")
    


def _findSectionsAtDepth(lines,beginningIndex,targetDepth,sectionSeparator,variableMap):
    """
    Utility method that looks for section headers of a specific depth and
    stops when a section header at a higher depth is found
    
    Parameters:
        lines - the lines from the sectionproperties file
        beginningIndex - the line to start the search at
        targetDepth - the depth of section names to return
        sectionSeparator - the separator string used in section names
        variableMap - we will support replacing variables in section names
    
    Returns the section names 
    """
    sectionNames = []
    idx = beginningIndex
    while idx < len(lines):
        tempLine = lines[idx]
        if tempLine.startswith("["):
            tempSectionString = replaceVariables(tempLine.strip(), variableMap)
            tempDepth = len(tempSectionString.split(sectionSeparator))
            if (tempDepth < targetDepth):
                # We've found the start of higher level section - break out
                break
            elif (tempDepth == targetDepth):
                # We've found a subsection of the right depth
                sectionNames.append(tempSectionString)
        idx += 1
                
    return sectionNames

def getSectionNames(templatePropertyFile,targetSection="",sectionSeparator="->",variableMap={}):
    """ 
    Return a list of top level section names or subsection names for specified targetSection
    
    Parameters:
       templatePropertyFile - the file to read from
       targetSection - The section to search for. Default behavior
                       is to return all top-level sections
       sectionSeparator - The token that designates a subsection in a section heading. Used
                          to determine section depth.
       variableMap - Section headers can have variables; this map supplies values for
                     variable replacement 
                      
    """
    
    sectionNames = []
    
    try:
        lines = loadFileAsList(templatePropertyFile,cache=1)
        
        if (targetSection):
            sectionDepth = len(targetSection.split(sectionSeparator))
            targetDepth = sectionDepth+1
        else:
            targetDepth = 1
        
        if (targetSection):
            # Find the specified section
            if (targetSection.startswith("[")):
                targetSection = targetSection[1:-1].strip()
            
            idx = 0
            beginningIndex = -1
            while idx < len(lines):
                tempLine = lines[idx]
                if tempLine.startswith("["):
                    tempSectionString = replaceVariables(tempLine.strip()[1:-1].strip(),variableMap)
                    if (tempSectionString == targetSection):
                        beginningIndex = idx+1
                        break
                idx += 1
            
            if (beginningIndex >=0 and beginningIndex < len(lines)):
                sectionNames = _findSectionsAtDepth(lines,beginningIndex,targetDepth,sectionSeparator,variableMap)
        else:
            #Looking for top level sections
            sectionNames = _findSectionsAtDepth(lines,0,1,sectionSeparator,variableMap)
    except:
        _app_message("Error in getSectionNames","exception")
        raise StandardError("Error in getSectionNames")
    
    return sectionNames



def assignCommandLineParameter(parm,value,parmMap,specialParms):
    """
    This method handles the special command line parameter formatting and then
    stores the result in the parmMap. We'll store the supplied parm name as
    well as lower case and dashless options.
    
    Parameters:
        parm - The parameter key "-parm1"
        value - The value pulled from the command line
        parmMap - The current parameter map
        specialParms: - A dictionary of parameter keys that merit special formatting before
                       the value is stored in the output dictionary.  Dictionary has form
                       parmName: type
                       {"-parm1": "boolean" , "-parm2": "list"}
    
    
    Supported types:
        boolean - parameter value will be stored as 1 or 0 (int)
        list - parameter can repeat and/or have values separated by +
               parameter value will be stored as a list of items
    """
    if (not specialParms.has_key(parm) and not specialParms.has_key(parm.lower())):
        
        # Store literal and lowercase variations, as well as dashless
        parmMap[parm] = value
        parmMap[parm.lower()] = value
        parmMap[parm[1:]]=value
        parmMap[parm[1:].lower()]=value    
        
       
    else:
        parmType = specialParms.get(parm,None)
        if (not parmType):
            parmType = specialParms.get(parm.lower())
        
        if (parmType == "boolean"):
            if (value.lower() == "true"):
                value = 1
            else:
                value = 0
            
            # Store literal and lowercase variations, as well as dashless
            parmMap[parm] = value
            parmMap[parm.lower()] = value
            parmMap[parm[1:]]=value
            parmMap[parm[1:].lower()]=value
        elif (parmType == "list"):
            # A list parameter can be specified multiple times
            currentValue = parmMap.get(parm,[])
            
            # A list parameter can have multiple items separated by a +
            newValues = value.split("+")
            
            currentValue.extend(newValues)
            
            # Store literal and lowercase variations, as well as dashless
            parmMap[parm] = currentValue
            parmMap[parm.lower()] = value
            parmMap[parm[1:]]=value
            parmMap[parm[1:].lower()]=value            

def buildCommandLineParameterMap(argv,specialParms={}):
    """
    Reads the command line input and builds a dictionary. Allows command line parameters to
    be specified as -parm [optional-value] or -parm=value
    
    Parameters:
        argv - The command line parameters 
        specialParms - A dictionary of parameter keys that merit special formatting before
                       the value is stored in the output dictionary.  Dictionary has form
                       parmName: type
                       {"-parm1": "boolean" , "-parm2": "list"}
    
    Returns: the command line dictionary: {"-parm1":"parm1value","-parm2:"parm2value",...}
             The keys in the dictionary will be in lower case
             
    """
    # Parse parameter input
    parmMap = {}
    idx = 0
    while idx < len(argv):
        val = None
        parm = argv[idx]
        
        # Allow -parm=value syntax
        splitPos = parm.find("=")
        if (splitPos > 0):
            val = parm[splitPos+1:]
            parm = parm[0:splitPos]
            
        
        idx = idx + 1
        
        if (val):
            assignCommandLineParameter(parm,val,parmMap,specialParms)
        elif (idx < len(argv)):
            val = argv[idx]
            
            if (val.startswith("-")):
                # next parm is another option, treat this as "true" value
                assignCommandLineParameter(parm,"true",parmMap,specialParms)
            else:
                idx = idx + 1
                assignCommandLineParameter(parm,val,parmMap,specialParms)
        else:
            # treat last parm as a switch
            assignCommandLineParameter(parm,"true",parmMap,specialParms)
            
    #endwhile

    return parmMap

#enddef


def parseTaskArguments(taskText,startingPosition):
    """
    Parameters: taskText - A list consisting of each line from AdminTask.view(app,-taskname)
                startingPosition - Index to start parsing arguments from
    
    Returns: Two lists: The first a list of the argument name/descriptions, in order of appearance
                        The second a list of argument values, in order of appearance
    """
    
    #_app_message("parseTaskArguemnts: %d %s" % (startingPosition,taskText[startingPosition]))
    argumentNames = []
    argumentValues = []
    
    currentPos = startingPosition
    while (currentPos < len(taskText)):
        currentLine = taskText[currentPos].strip()
        
        firstSemicolon = currentLine.find(":")
        if (firstSemicolon >= 0):
            argumentName = currentLine[0:firstSemicolon].strip()
            argumentValue = currentLine[firstSemicolon+1:].strip()
                
            # Special handling for "None" - replace with empty string
            if (argumentValue == "None"):
                argumentValue = ""
            
            argumentNames.append(argumentName)
            argumentValues.append(argumentValue)
        else:
            # We must be done with arguments
            break
        
        currentPos += 1
        
    #_app_message("parseTaskArguemnts results: %s %s" % (argumentNames,argumentValues))
    return argumentNames,argumentValues

def getTaskParameters(applicationName,taskName):
    """
    This function parses the output of AdminApp.view(appname,-taskname) and returns
    a list of lists:
        Element 0: A list of the parameter names
        Element 1: A list of the task parameter values.
        Element 2+: If there are repeating arguments for the task step, each individual will
                   be returned separately.
                   
    Example output:
           [['Web module', 'URI', 'JSP enable class reloading', 'JSP reload interval in seconds']
            ['SampleWebApp', 'SampleWebApp.war,WEB-INF/ibm-web-ext.xmi', 'Yes', '10']
            ['AnotherWebApp', 'AnotherWebApp.war,WEB-INF/ibm-web-ext.xmi', 'Yes', '10']]

    """
    
    resultList = []
    
    try:
        
        taskText = AdminApp.view(applicationName,"[-%s]" %taskName).splitlines()
        
        indexTaskName = -1
        indexFirstArg = -1
        currentIndex = 0
        while (currentIndex < len(taskText) and indexFirstArg == -1):
            currentLine = taskText[currentIndex].strip()
            
            if (indexTaskName == -1):
                # See if this is the start of the task name
                if (currentLine.startswith("%s:" % taskName)):
                    # This is the beginning of the task description
                    indexTaskName = currentIndex
            elif (indexFirstArg == -1):
                if (currentLine.find(":") >= 0):
                    indexFirstArg = currentIndex
                    break
            
            currentIndex += 1
        #endwhile
        
        if (indexFirstArg >= 0):
            # We have a starting position to parse arguments from
            currentIndex = indexFirstArg
            
            while (currentIndex < len(taskText)):
            
                taskArgumentNames,taskArgumentValues=parseTaskArguments(taskText, currentIndex)
            
                if (not resultList):
                    # Add the argument names to start of return list 
                    resultList.append(taskArgumentNames)
            
                resultList.append(taskArgumentValues)
            
                # Bump current index past the arguments we just read
                currentIndex +=  len(taskArgumentValues)
                    
                # Advance to the next set of task arguments
                while (currentIndex < len(taskText)):
                    if (taskText[currentIndex].find(":") >= 0):
                        break
                    else:
                        currentIndex += 1
                #end while 
            #end while
    except:
        errMsg = "Unexpected problem occurred getting task parameters for %s -%s" % (applicationName,taskName)
        _app_message(errMsg,"exception")
        raise StandardError(errMsg)
    
    return resultList
        

def getAllTaskParameters(applicationName):
    """
    Returns task arguments for all applicable installation tasks of the
    
    returns a list of tuples, where each tuple is
        taskname, collected-task-parms
        
        and collected-task-parms is a list of lists:
            Element 0: A list of the parameter names
            Element 1: A list of the task parameter values.
            Element 2+: If there are repeating arguments for the task step, each individual will
                        be returned separately. 
    
    Example tuple:
    ("JSPReloadForWebMod",
       [['Web module', 'URI', 'JSP enable class reloading', 'JSP reload interval in seconds']
        ['SampleWebApp', 'SampleWebApp.war,WEB-INF/ibm-web-ext.xmi', 'Yes', '10']
        ['AnotherWebApp', 'AnotherWebApp.war,WEB-INF/ibm-web-ext.xmi', 'Yes', '10']])
    """
    
    allTaskParameters = []
    try:
        tasknames = AdminApp.view(applicationName,"-tasknames").splitlines()
        
        for taskName in tasknames:
            taskName = taskName.strip()
            if (taskName):
               
                taskParms = getTaskParameters(applicationName,taskName)
            
                if (taskParms):
                    allTaskParameters.append((taskName,taskParms))
        #endfor          
        
    except:
        errMsg = "Unexpected problem occurred getting task parameters for %s" % (applicationName)
        _app_message(errMsg,"exception")
        raise StandardError(errMsg)
    
    return allTaskParameters

#enddef

def getBaseApplicationOptions(appName):
    """
    This function returns the base application settings from AdminApp.view() as
    a dictionary.
    
    Returns a dictionary where the labels from getView() are the keys
    """
    
    appOptionsDict = {}
    try:
        ctr = 0
        appOptions = []
        appOptions = AdminApp.view(appName).splitlines()
        
        pos = 0
        for line in appOptions:
            if (line.find("Specify the various options that are available") != -1):
                ctr += 1
                break
            else:
                ctr += 1
        
        # Now skip past white space
        while ((ctr < len(appOptions)) and not appOptions[ctr].strip()):
             ctr += 1     
        
        # Now process key/values separated by : until blankline
        while ((ctr < len(appOptions)) and appOptions[ctr].strip()):
            list = appOptions[ctr]
            pos = list.find(":")
            key = list[0:pos].strip()
            val = list[pos+1:].strip()
            appOptionsDict[key] = val 
            ctr += 1 
    except:
        _app_message("Unexpected error in getBaseApplicationOptions(%s)"%appName,"exception")
        raise StandardError("Unexpected error in getBaseApplicationOptions(%s)"%appName)
        
    return appOptionsDict



def getWebServerNameReplacementMap():
    """
    Iterates through the webservers in a cell and returns a replacement dictionary
    for webserver names that we'll use to replace hard-coded names with variables:
       { "node=WebServerNode2,server=webserver2': "#{WEB_SERVER1}",
         "node=WebServerNode5,server=webserver5': "#{WEB_SERVER2}",
         ...}
    """
     
    resultDict = {}
    ctr = 1
    try:
        webServers = AdminConfig.list("WebServer").splitlines()
        for webServer in webServers:
            tokens = webServer.split("nodes/")
            split2 = tokens[1].split("/")
            nodeName =  split2[0]
            serverName = split2[2].split("|")[0]

            resultDict['node=%s,server=%s' % (nodeName, serverName)]  = '#{WEB_SERVER%d}' % (ctr)  
            ctr += 1
        #endfor
    except:
        errMsg = "Unexpected problem occurred performing AdminConfig.list('WebServer')" 
        _app_message(errMsg,"exception")
        raise StandardError(errMsg)
    
    return resultDict

# enddef

def getServerToClusterNameReplacementMap():
    """
    Iterates throught the standalone application servers and builds string
    replacment map for the server names used by MapModulesToServer
    for webserver names that we'll use to replace hard-coded names with variables:
       { "node=Node2,server=Alpha": "cluster=Alpha",
         "node=Node1,server=Alpha": "cluster=Alpha",
         "node=Node5,server=Beta': "cluster=Beta",
         ...}
    """
    replacementTokens = {}
    listString = AdminConfig.list("Server")
    serverids = listString.splitlines()
    for serverid in serverids:
        servername = AdminConfig.showAttribute(serverid,"name")
        servertype = AdminConfig.showAttribute(serverid,"serverType")
        if (servertype == 'APPLICATION_SERVER'):
            nodename = getNodeNameForServer(serverid)
            replacekey="node=" + nodename +",server=" + servername
            replacevalue="cluster=" + servername 
            replacementTokens[replacekey]=replacevalue
        #endif
    #endfor

    return replacementTokens

#enddef
    

# enddef


def transformTaskParameters(taskInformationList,serversToClusters=1,webserversToVars=1,cellToVar=1):
    """
    For a task information list in the format returned by getAllTaskParameters, iterate through the
    lists of values (ignoring the field descriptions and task names) and do variable replacement 
    processing on them.
   
    [
     ("JSPReloadForWebMod",
       [['Web module', 'URI', 'JSP enable class reloading', 'JSP reload interval in seconds']
        ['SampleWebApp', 'SampleWebApp.war,WEB-INF/ibm-web-ext.xmi', 'Yes', '10']
        ['AnotherWebApp', 'AnotherWebApp.war,WEB-INF/ibm-web-ext.xmi', 'Yes', '10']]),
     ("NextTaskName",
      [[description list],
       [value-list]
       [value-list2] ]
     ),
     
    The lists are updated in place, if parameters were replaced with variable tokens, the
    variable key/values are returned as a dictionary
    """
    
    variableDictionary = {}
    try:
        replacementTokens = {}
        if cellToVar:
            cellName = AdminControl.getCell()
            replacementTokens["cell=%s"%cellName] = "cell=#{CELL_NAME}"
            variableDictionary["CELL_NAME"]=cellName
    
        if (webserversToVars):
            webServerMap = getWebServerNameReplacementMap()
            replacementTokens.update( webServerMap)
            
            # The values of webserver are the keys that we'll need to 
            # return in the varialbe map. The keys are the values.
            for wsitem in webServerMap.items():
                if wsitem[1].startswith("#{"):
                    varname = wsitem[1][2:-1]
                    varval = wsitem[0]
                    variableDictionary[varname] = varval
            
        
        if (serversToClusters):
            replacementTokens.update(getServerToClusterNameReplacementMap())
            
        for taskItem in taskInformationList:
            for taskParms in taskItem[1][1:] :
                idx = 0
                while (idx < len(taskParms)):
                    taskParms[idx] = replaceTokens(taskParms[idx], replacementTokens)
                    idx +=1
            
    except:
        _app_message("Error in transformTaskParameters","exception")
        raise StandardError("Error in transformTaskParameters")
    
    return variableDictionary
    
#enddef

def writeApplicationVariableFile(applicationName,variableFileName,templateFileName,variableMap):
    """
    Creates a new property file with replacement variables and values for a template file.
    """
    
    
    try:
        # Build out the application-info-section
        cellName = AdminControl.getCell()
        infoDict = {}
        infoDict["applicationName"]=applicationName
        infoDict["originatingCell"]=cellName
        infoDict["originatingHost"]=AdminControl.getHost()
        infoDict["originatingWebSphereVersion"] = AdminTask.getNodeBaseProductVersion("-nodeName %s" % AdminControl.getNode())
        infoDict["templateFileName"] = templateFileName
        
        variableFile = open(variableFileName,"w")
        writePropertySection(variableFile, "Application-Configuration-Overview", infoDict, [], addLine=0, comment="This section describes the environment values were pulled from")
        
        writePropertySection(variableFile, cellName, variableMap, [], addLine=1,comment="Replacement variables for application %s from cell %s" % (applicationName,cellName))
        
        variableFile.close()

    except:
        _app_message("Unexpected error in writeApplicationVariableFile","exception")
        raise
        

def writeApplicationInfoToFile(applicationName,outputFileName,taskInformationList):
    """
    Write an application installation template file, using the taskInformation 
    loaded by getAllTaskParameters() and transformed by transformTaskParameters()
    
    This function creates the file and writes an initial section with the application 
    name and information about the cell that the information was obtained from.
    
    After this initial section, the function then iterates through the tasks in 
    the taskInformationList and writes sections to the file.

    """
    
    
    try:
        # Build out the application-info-section
        infoDict = {}
        infoDict["applicationName"]=applicationName
        infoDict["originatingCell"]=AdminControl.getCell()
        infoDict["originatingHost"]=AdminControl.getHost()
        infoDict["originatingWebSphereVersion"] = AdminTask.getNodeBaseProductVersion("-nodeName %s" % AdminControl.getNode())
        
        templateFile = open(outputFileName,"w")
        
        writePropertySection(templateFile, "Application-Configuration-Overview", infoDict, [], addLine=0)
        
        baseOptions = getBaseApplicationOptions(applicationName)
        writePropertySection(templateFile, "Application-Configuration-Overview->Base-Application-Options", baseOptions, [], addLine=1)
        
        writePropertySection(templateFile, "Optional-Install-Options", {"options":""}, [], addLine=1,comment="Enter simple install options as the value of options. Example:\noptions=-deployejb -deployws")
        
        writePropertySection(templateFile, "Tasks", {}, [], addLine=0)
        
        # Now dump out the task information
        for taskInformation in taskInformationList:
            taskName = taskInformation[0]
            stepList = taskInformation[1]
            
            writePropertySection(templateFile, "Tasks->%s" %taskName, {}, [], addLine=0)
            
            parmNames = stepList[0]
            
            #Build out our key order, should be the same for all parm lists
            keyorder = ["parm%d"%idx for idx in range(1,len(parmNames)+1)]
            
            infoDict = {}
            idx = 1
            for parmName in parmNames:
                infoDict["parm%d"%idx]=parmName
                idx += 1
            
            writePropertySection(templateFile, "Tasks->%s->ParmDescription"%taskName, infoDict, keyorder, addLine=0)
            
            taskStepSection = 1
            for parmValues in stepList[1:]:
                infoDict = {}
                idx = 1
                for parmValue in parmValues:
                    infoDict["parm%d"%idx]=parmValue
                    idx += 1
                writePropertySection(templateFile, "Tasks->%s->ParmList%d"%(taskName,taskStepSection), infoDict, keyorder, addLine=0)
                
                taskStepSection += 1
                
            #end for each list of arguments
            
            templateFile.write("\n")
        #end for each task        
        templateFile.close()
            
        _app_message("Application %s installation information has been stored in %s" %(applicationName,outputFileName))
        
    except:
        _app_message("Unexpected error in writeApplicationInfoToFile","exception")
        raise StandardError("Unexpected error in writeApplicationInfoToFile")
    
#enddef writeApplicationInfoToFile


def extractMultipleApplicationConfigurations(applicationPattern,targetDirectory,**options):
    """
    For all applications that match the pattern name, do an extract to the target directory.
    
    Parameters:
        applicationPattern - A regular expression string that can be used with re.match
        targetDirectory - The directory to store EAR and template files to
    """
    import re
    matchlist = []
    AppList = AdminApp.list().splitlines()
    for application in AppList:
        matchobj = re.match(applicationPattern, application)
        if matchobj:
            matchlist.append(application) 
            try:
                extractApplicationConfiguration(application,targetDirectory,**options)
            except:
                _app_message("Unexpected error in extractMultipleApplicationConfigurations","exception")
                raise StandardError("Unexpected error in extractMultipleApplicationConfigurations")
    if (not matchlist):
        _app_message("No application matches the pattern ")

#enddef extractMultipleApplicationConfigurations


def extractApplicationConfiguration(targetApplicationName,targetDirectory,**options):
    """
    This is one of the entry point functions of this module. Given an applicationName and a target directory,
    it will extract the ear file from the WebSphere configuration and also store the task arguments for 
    AdminApp and AdminConfig in a template file.
    
    This function is also called during update operations to back up a previously installed
    image of the ear file.
    
    Note: This function currently only extracts the ear file to the deployment manager
          box.  In theory, it could be modified to use AdminConfig.extract() to download to
          a local box
    
    Parameters:
        targetApplicationName - The name of the application to extract
        targetDirectory - The directory to store the EAR file and template file in.
        **options - A dictionary of command line arguments
                    checkBeforeExtract - if true, then files are validated before extracting
                    transformTaskParms - if true then task parameters are pre-processed to do
                                         variable replacement
                                         serversToClusters=1,webserversToVars=1,cellToVar=1
    """
    import os
    
    targetEAR = "%s/%s.ear" % (targetDirectory,targetApplicationName)
    targetArgumentFile = "%s/%sInstallArguments.props" % (targetDirectory,targetApplicationName)
    targetVariableFile = "%s/%sInstallVariables.props" % (targetDirectory,targetApplicationName)
    
    if (options.get("checkBeforeExtract",1)):
        # See if the target files exist
        if (os.path.isfile(targetEAR)):
            _app_message("ERROR: EAR file %s already exists"%targetEAR)
            raise StandardError("EAR file %s already exists"%targetEAR)
        if (os.path.isfile(targetArgumentFile)):
            _app_message("ERROR: file %s already exists"%targetArgumentFile)
            raise StandardError("EAR file %s already exists"%targetArgumentFile)
        if (os.path.isfile(targetVariableFile)):
            _app_message("ERROR: file %s already exists"%targetVariableFile)
            raise StandardError("EAR file %s already exists"%targetVariableFile)        
        
    
    # First try to get the application installation options
    try:
        taskInformationList = getAllTaskParameters(targetApplicationName)
        
        if (options.get("transformTaskParms",0)):
            # Do transformation of task parameters before writing file
            serversToClusters=options.get("serversToClusters",1)
            
            webserversToVars=options.get("webserversToVars",1)
            cellToVar=options.get("cellToVar",1)
            variableDictionary = transformTaskParameters(taskInformationList, serversToClusters, webserversToVars, cellToVar)
            
            writeApplicationVariableFile(targetApplicationName, targetVariableFile, targetArgumentFile, variableDictionary)
        
        writeApplicationInfoToFile(targetApplicationName, targetArgumentFile, taskInformationList)
        _app_message("Application installation settings have been stored in %s"%targetArgumentFile)
    except:
        _app_message("Unexpected error in extractApplicationConfiguration: %s"%targetApplicationName,"exception")
        raise StandardError("Unexpected error in extractApplicationConfiguration: %s"%targetApplicationName)
    
    #Now export the ear file
    if (not options.get("skipEarExtraction",0)):
      try:
          AdminApp.export(targetApplicationName,targetEAR) 
          _app_message("EAR file %s has be exported"%targetEAR)
      except:
          _app_message("Unexpected error in extractApplicationConfiguration, Unable to export ear for application %s"%targetApplicationName,"exception")
          raise StandardError("Unexpected error in extractApplicationConfiguration, Unable to export ear for application %s"%targetApplicationName)
    

#enddef
    
        
    





def doApplicationInstallation(applicationName,earFile,taskArguments,additionalInstallOptions=[]):
    """
    Parameters:
        applicationName - The name to use for application installation
        earFile - The ear file to install
        taskArguments - The formatted installation task arguments
        additionalInstallOptions - Additional (non-task) install options that were specified either
                                   in the file or on the command line
        
    """
    raise StandardError("Not supported in this script")


#enddef

def doApplicationUpdate(applicationName,earFile,taskArguments,additionalInstallOptions=[]):
    """
    Parameters:
        applicationName - The name to use for application installation
        earFile - The ear file to install
        taskArguments - The formatted installation task arguments
        additionalInstallOptions - Additional (non-task) install options that were specified either
                                   in the file or on the command line (-installOptions)
    """
    raise StandardError("Not supported in this script")



def applyApplicationConfiguration(targetApplicationName, earFile, templateFile, variableMapFile, backupDirectory,**cmdOptions):
    """
    @todo: This function needs to be implemented
    
    This function will process an application template file and will either update an existing installation or
    install a new application.
    
    Parameters:
        targetApplicationName -Name to use with installation
        earFile - EAR file to be installed
        templateFile - Application installation instructions template file
        variableMapFile - File with replacement values for the variables in the template. This is optional and 
                          can be empty or None
        backupDirectory - Directory to store extracted ear file and application installation template file with
                          current settings
        **cmdOptions - Various command options which may also be used by this function.
                       Known command options include
                           -installOptions - A list of additional installation options specified on command line
                           -variableSection - An optional section-name to use for loading variables.
                                              Defaults to cell name
    
    This function does the following:
        Determines if the application is already installed
        If installed then back up current ear file and installation properties in backup directory
           if the backup directory is specified
        Loads the variables
        get the task parameters from the file using getTaskParametersFromFile
        Validates that the task parameters are in correct format using validateTaskParameters
        Builds the AdminApp argument lists with the task parameter info
        Merges additional options from [Simple-install-options
         
        Calls the appropriate install or update method
        Saves the configuration if installation is successful
        
    
        
    """
    raise StandardError("Not supported in this script")
    
    

def processApplicationRemoval(targetApplicationName,  backupDirectory,**cmdOptions):
    """
    
    This function will remove an application from the configuration after saving a backup copy of the ear 
    and the template file with its configuration in the backup directory.
   
    Parameters:
        targetApplicationName -Name to use with installation
        backupDirectory - Directory to store extracted ear file and application installation template file with
                          current settings
    
    This function does the following:
        Determines if the application is already installed
        If installed then back up current ear file and installation properties in backup directory
           if the backup directory is specified
        Removes the application
        Saves the configuration if installation is successful
        
    """
    raise StandardError("Not supported in this script")
       
#enddef

def dumpGetAllTaskParameters(targetApplicationName):
    """
    Utility method for testing
    """
    taskparms = getAllTaskParameters(targetApplicationName)
    transformTaskParameters(taskparms)
    for tp in taskparms:
        print tp[0]
        for targs in tp[1]:
            print "   %s" % targs
    
    return taskparms


#------------------------------------------------------------------------------------
# Main code-block
#------------------------------------------------------------------------------------
if (__name__ == "__main__" or __name__ == "main"):
    import sys
    
   
    # The specialArgs list is used to convert parameters into specific values
    specialArgs = {"-transformTaskParms": "boolean",
                   "-serversToClusters":"boolean", 
                   "-webserversToVars":"boolean",
                   "-cellToVar":"boolean",
                   "-taskFilter":"list",
                   "-installOptions":"list",
                   "-checkBeforeExtract":"boolean",
                   "-skipEarExtraction":"boolean"                
                  }
    
    # Parse the command line arguments
    commandArgs = buildCommandLineParameterMap(sys.argv, specialArgs)
    
    
    commandParm = commandArgs.get("command","extractall")
    if (commandParm):
        if (commandParm == "extract"):
            applicationName = commandArgs.get("-applicationname","")
            targetDirectory = commandArgs.get("-targetdirectory",".")
            extractApplicationConfiguration(applicationName, targetDirectory,**commandArgs)
        elif (commandParm == "extractall"):
            applicationName = commandArgs.get("-applicationname","")
            targetDirectory = commandArgs.get("-targetdirectory",".")
            wildcard = commandArgs.get("-wildcard","*")
            applicationPattern = wildcardToRegExpString(applicationName, wildcard)
            
            skipEar = commandArgs.get("-skipEarExtraction",1)
            commandArgs["-skipEarExtraction"] = skipEar
            commandArgs["skipEarExtraction"] = skipEar
            
            extractMultipleApplicationConfigurations(applicationPattern,targetDirectory,**commandArgs)
        else:
            _app_message("Unknown command argument: %s" % commandParm)                     
    else:
        _app_message("No command arguments specified")